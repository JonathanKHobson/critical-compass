# Host-AI Quickstart / Current State Context v1.0.0

Use this before changing Critical Compass behavior, calling multiple tools, or explaining the MCP to a user.

## Product Promise

Critical Compass helps people and mission-driven organizations pressure-test text before they use it, so weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads.

Lead with this plain-language purpose. Avoid internal planning language when explaining the product to a user.

## Current Shipped State

Critical Compass is a host-AI-powered critical-thinking coach with local-first defaults. It supports:

- first-session onboarding through `get_started`
- intent-first routing when users have text but no chosen lane yet
- classroom standard-audit guidance through the `classroom_standard_audit_prompt` scaffold
- MCPB/Desktop Extension install and diagnostic guidance through the `mcpb_install_diagnostics_prompt` scaffold
- local PDF/source preparation through `prepare_audit_source`
- lightweight gut-checks through `quick_scan`
- structured audits through `audit_text`, including audience-fit, framing openness, stakeholder fit, missing voices, and persuasion-risk review
- advanced-audit persona discovery through `list_agent_personas`
- staged advanced-audit scaffolding through `advanced_audit` for thorough, multi-perspective, stakeholder-sensitive, or high-stakes review
- claim pressure-testing through `claim_stress_test`
- scaffold-first factual verification through `factcheck_lookup`
- saved audit browsing and comparison through `list_audit_results`, `get_pattern_summary`, and `compare_audit_results`
- stakeholder-ready report generation through `generate_audit_report`
- report dry-runs and schema discovery through `validate_report_payload`
- local read-only report viewers through `generate_audit_artifact_viewer`
- compact readiness-card reports through `generate_audit_report(report_depth="readiness_card")`
- activity fit notes captured inside `save_audit_result` payloads when the user supplies them
- saved-result comparison through saved IDs or already-audited inline payloads, with framing-drift guidance and comparability warnings

Expanded `text_type` support includes `social_media`, `academic_abstract`, `product_copy`, `legal`, and `ai_generated`.

The current beta.11 course-reliability release emphasizes clean first-use routing, classroom standard-audit prompting, native human-loop questions, schema-stable report generation, package/public-surface consistency, silent-mode consent repair, and Markdown-first PDF failure recovery. The `pressure-test-readiness-kit.md` remains the local scenario and guidance kit for evaluating advocacy copy, public statements, grant impact claims, article review, AI-generated summaries, and research-adjacent summaries against the trust/revise/verify/reframe decision contract.

## Non-Negotiable Rules

- Do not add automatic web retrieval to core audits.
- Do not equate check-worthy with false.
- Do not call fact-check retrieval providers unless the user explicitly authorizes that mode.
- Do not generate placeholder final reports unless the user explicitly authorizes placeholders.
- Do not ask human-loop prompts as ordinary chat when the host has native question UI. Treat `human_loop_host_action` as a required interaction contract: in Claude, use `Ask_User_Input_V0` / the `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` question types. `plain_text_questions_valid=false` means prose questions violate the contract when the widget is available; compact inline fallback is allowed only when the widget is unavailable.
- Do not treat `quick_scan` as a full audit.
- Do not treat saved-audit score deltas as improvement proof by themselves, even when the comparison is direct.
- Do not treat external archives as runtime dependencies; project planning material in this repo is build-time evidence distilled into local Critical Compass resources.
- For Indigenous health equity, tribal/First Nations, public-health measurement, data sovereignty, food sovereignty, or community-evaluation text, do not improvise named non-Western lenses from memory. Use `search_knowledge_base` / `get_framework` to retrieve KB IDs for OCAP, CARE Principles, Indigenous data sovereignty, data erasure, food sovereignty, relational accountability, or community authority; if no lookup was performed, mark the label as host inference.
- Do not load or improvise a giant lens prompt. Use compact `lens_card` results and obey `retrieval_budget`: quick up to 3 short cards, standard up to 5 standard cards, advanced up to 8 standard cards with selection reasons. Any named lens, bias, or framework without a KB ID should be labeled `host_inference`.
- Before final bias/framing conclusions, check `fairness_to_text`: preserve the strongest charitable reading, respect the genre, and do not invent critique that appears in `expected_non_findings`.

## Freshness Checks

When behavior seems stale:

1. Call `get_started()`.
2. Call `critical_compass_overview(topic="overview")`.
3. Call `critical_compass_overview(topic="reports")`.
4. Confirm workflow resources include tool inventory, server instructions, fact-check scaffolds, report/viewer runbooks, and install diagnostics.
5. For install questions, confirm workflow resources include `mcpb_install_diagnostics_prompt`.
6. If an attached host MCP still returns old behavior, restart or rebind the MCP session before deeper QA.

## Default Host Path

Start with the user job: pressure-test this before use. Then choose the narrowest workflow:

- text present, no lane chosen: ask goal + intended audience + quick/full/advanced depth, then route to `audit_text` or `advanced_audit`
- course, classroom, assignment, or Week 2 bias-audit exercise: use `classroom_standard_audit_prompt`, standardize audience + intended use + text type + output section order, then route to standard `audit_text`
- one local PDF: `prepare_audit_source` before audit tools
- new user or first audit: `get_started`
- lightweight gut-check: `quick_scan`, then `audit_text` if warranted
- one text needing the normal full analysis or audience-fit read: `audit_text`
- advanced personas: `list_agent_personas`, then `define_audit_agents` or `advanced_audit`
- high-stakes, multi-perspective, stakeholder-sensitive, or persuasion-effectiveness review: `advanced_audit`
- Indigenous health equity, community data, tribal/First Nations, public-health measurement, food sovereignty, or community-evaluation text: run the normal audit path, but add KB-backed data-sovereignty / measurement-accountability lenses before naming OCAP, CARE, data erasure, or related frameworks
- lens-heavy or high-sensitivity audit: use `search_knowledge_base` / `get_framework` for compact lens cards, then cite `selected_lens_ids` or mark `host_inference`
- one claim: `claim_stress_test`
- factual claims worth checking: `factcheck_lookup(provider="guided_research")`
- two saved results: `compare_audit_results`, treating score movement as a diagnostic signal rather than proof of improvement
- two already-audited inline payloads: `compare_audit_results(result_payload_a=..., result_payload_b=...)`, treating score movement as a diagnostic signal rather than proof of improvement
- completed audit data: `generate_audit_report`
- complex or advanced report payload: `validate_report_payload` before `generate_audit_report`
- compact stakeholder summary only: `generate_audit_report(report_depth="readiness_card")`
- first-share report when no full PDF is explicitly requested: prefer `generate_audit_report(report_depth="readiness_card")` after `validate_report_payload`
- completed report manifest: `generate_audit_artifact_viewer`

When improving or evaluating output usefulness, use `pressure-test-readiness-kit.md` and the local `support/evals/atlas_pressure_test_scenarios.json` fixture before proposing new tools.

Audience effectiveness is not a mismatch lane. If the question is really about framing openness, stakeholder fit, missing voices, persuasion quality, or whether a draft works for its intended reader, stay inside Critical Compass first. Offer JTBD or other adjacent frameworks only after the core audit if they clearly add value.

## What This Resource Is Not

This is not an audit result, a retrieval result, or permission to call outside services. It is the current-state context for host AIs and maintainers.
