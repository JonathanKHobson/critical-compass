# Classroom Standard Audit Prompt

Use this prompt for course assignments where students need comparable Critical Compass outputs for peer discussion. It is designed for the Week 2 bias-audit exercise: normal `audit_text`, standard depth, fixed framing fields, and stable section order.

## Student Prompt

```text
Please run a standard Critical Compass audit on the text below.

Use this fixed frame:
- Audience: [who this is for]
- Intended use: [what this writing is meant to do]
- Text type: [memo / pitch / email / report section / social post / proposal / other]
- Audit depth: standard
- Output purpose: classroom bias-audit reflection

Do not run an advanced panel review, multi-agent review, or web research. Do not rewrite the text unless I ask afterward.

Use this exact output structure:
1. Critical Integrity Snapshot
2. Plain-Language Read
3. Before Using This Text
4. Top 3-5 findings
   - finding name
   - severity: high / medium / low
   - specific evidence from the text
   - why it matters for the stated audience and intended use
5. Key tension
6. Recommended next revision
7. Two peer-discussion questions

Here is the text to audit:

[paste text]
```

## Instructor Note

Critical Compass is AI-assisted, so outputs may differ across models and runs. For class discussion, compare the top findings, severity, and revision decisions more than exact point scores.

Before course use, update older Claude Desktop or skill-file installs so students receive the newer score framing and course routing guidance.

## Assignment Tweaks

- Replace the broad standard-audit prompt with the student prompt above.
- Keep advanced audit and advanced panel review out of the core assignment; offer them only as an optional extension.
- Tell students to use the same text if they rerun the audit. If they revise the text, label it `Version 2` and compare findings, not just the score.
- Use `MCPB extension` language for Claude Desktop and separate Claude Desktop setup from ChatGPT or prompt-only skill-file setup.
- If the debrief mentions de-westernization, use a softer question: Did the audit surface any perspective, power, cultural, or missing-voice issue that shifted how you see the text?
