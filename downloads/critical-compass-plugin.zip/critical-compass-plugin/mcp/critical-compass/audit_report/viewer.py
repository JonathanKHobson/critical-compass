from __future__ import annotations

import json
from html import escape
from pathlib import Path
from typing import Any

from .models import clean_text, ensure_list, json_dumps


VIEWER_VERSION = "v1.0.0"
SUPPORT_CONTRAST_LABELS = {
    "needs_evidence": "Needs supporting evidence",
    "needs_support_and_contrast": "Needs support and contrast",
    "not_ranked_for_truth": "Not ranked - claim type does not admit simple truth verification",
}
PRIORITY_LABELS = {
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "not_ranked": "Not ranked",
}


def _safe(value: Any) -> str:
    return escape(clean_text(value), quote=True)


def _safe_attr(value: Any) -> str:
    return escape(str(value or ""), quote=True)


def _file_href(value: Any) -> str:
    text = clean_text(value)
    if not text:
        return ""
    try:
        path = Path(text).expanduser()
        if path.exists():
            return path.resolve().as_uri()
    except (OSError, ValueError):
        return ""
    return ""


def _link(label: str, path: Any) -> str:
    href = _file_href(path)
    text = _safe(path)
    if not href:
        return ""
    return f'<a href="{_safe_attr(href)}">{_safe(label)}</a><span class="path">{text}</span>'


def _list(items: Any) -> str:
    values = [_safe(item) for item in ensure_list(items) if clean_text(item)]
    if not values:
        return '<p class="empty">Not supplied.</p>'
    return "<ul>" + "".join(f"<li>{item}</li>" for item in values) + "</ul>"


def _display_label(value: Any, mapping: dict[str, str]) -> str:
    text = clean_text(value)
    return mapping.get(text, text.replace("_", " ").title() if text else "")


def _before_use_display(value: Any) -> str:
    text = clean_text(value)
    prefix = "Before using this text,"
    if text.lower().startswith(prefix.lower()):
        stripped = text[len(prefix):].strip()
        return stripped[:1].upper() + stripped[1:] if stripped else text
    return text


def _section(title: str, body: str, section_id: str) -> str:
    if not body.strip():
        return ""
    return f'<section id="{_safe_attr(section_id)}"><h2>{_safe(title)}</h2>{body}</section>'


def _score_class(points: int, max_points: int) -> str:
    scaled = points
    if max_points and max_points != 20:
        scaled = round((points / max_points) * 20)
    if scaled >= 16:
        return "good"
    if scaled >= 11:
        return "mixed"
    return "risk"


def _dimension_bars(cis: dict[str, Any]) -> str:
    rows = []
    for dimension in ensure_list(cis.get("dimensions")):
        if not isinstance(dimension, dict):
            continue
        name = _safe(dimension.get("name"))
        points = int(dimension.get("points") or 0)
        max_points = int(dimension.get("max_points") or 20)
        width = max(0, min(100, round((points / max_points) * 100 if max_points else 0)))
        rows.append(
            '<div class="dimension-row">'
            f'<div class="dimension-label">{name}</div>'
            '<div class="bar-track" aria-hidden="true">'
            f'<span class="{_score_class(points, max_points)}" style="width:{width}%"></span>'
            "</div>"
            f'<div class="score">{points}/{max_points}</div>'
            "</div>"
        )
    return "".join(rows)


def _score_interpretation(cis: dict[str, Any]) -> str:
    interpretation = cis.get("score_interpretation") if isinstance(cis.get("score_interpretation"), dict) else {}
    if not interpretation:
        return ""
    details = " ".join(
        _safe(interpretation.get(key))
        for key in ("use_note", "variance_note")
        if clean_text(interpretation.get(key))
    )
    primary = _safe(interpretation.get("primary_note"))
    if not primary and not details:
        return ""
    return (
        '<div class="score-interpretation">'
        f"<p><strong>How to read this score:</strong> {primary}</p>"
        f"<p>{details}</p>"
        "</div>"
    )


def _artifact_links(report: dict[str, Any], payload: dict[str, Any]) -> str:
    argument_map = payload.get("argument_map") if isinstance(payload.get("argument_map"), dict) else {}
    links = [
        _link("Open PDF", report.get("report_path")),
        _link("Open Markdown", report.get("markdown_path")),
        _link("Open Argdown", report.get("argdown_path") or argument_map.get("argdown_path")),
        _link("Open Preview PNG", report.get("preview_image_path")),
        _link("Open Manifest", report.get("manifest_path")),
    ]
    links = [item for item in links if item]
    if not links:
        return '<p class="empty">No linked files were supplied.</p>'
    return '<div class="artifact-links">' + "".join(f"<div>{item}</div>" for item in links) + "</div>"


def _decision_layer(payload: dict[str, Any], report: dict[str, Any]) -> str:
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    label = cis.get("label") if cis.get("display_state") != "profile_only" else "Profile only"
    points = ""
    if cis.get("display_state") == "profile_only":
        points = "Aggregate score withheld."
    elif cis.get("points") is not None:
        points = f"{_safe(cis.get('points'))}/{_safe(cis.get('max_points'))}"
    readiness = payload.get("pressure_test_readiness_card") if isinstance(payload.get("pressure_test_readiness_card"), dict) else {}
    readiness_html = ""
    if readiness:
        readiness_html = f"""
      <div class="callout">
        <h3>Audit Summary</h3>
        <p>{_safe(readiness.get("executive_summary"))}</p>
        <p><strong>Primary action:</strong> {_safe(readiness.get("decision_action"))}</p>
        <p>{_safe(readiness.get("rationale"))}</p>
        <p><strong>CIS signal:</strong> {_safe(readiness.get("cis_signal"))}</p>
        <p><strong>Evidence:</strong> {_safe(readiness.get("evidence_strength_signal"))}</p>
        <p><strong>Missing voice:</strong> {_safe(readiness.get("missing_voice_risk"))}</p>
        <p><strong>Next move:</strong> {_safe(readiness.get("next_move"))}</p>
      </div>
        """
    return f"""
      <div class="verdict-line">
        <span class="verdict">{_safe(label)}</span>
        <span class="points">{points}</span>
      </div>
      <p class="meta">{_safe(meta.get("date"))} · {_safe(meta.get("text_type"))} · {_safe(meta.get("report_audience"))} · {_safe(meta.get("audit_method"))}</p>
      <div class="plain-read">{_safe(cis.get("plain_language_read"))}</div>
      <div class="before-use">{_safe(cis.get("before_using_display") or _before_use_display(cis.get("before_using_this_text")))}</div>
      {_score_interpretation(cis)}
      {readiness_html}
      <div class="dimension-bars">{_dimension_bars(cis)}</div>
      <div class="callout"><strong>Key tension:</strong> {_safe(findings.get("key_tension"))}</div>
      <div class="callout next"><strong>Next step:</strong> {_safe(findings.get("recommended_next_step"))}</div>
      <h3>Artifacts</h3>
      {_artifact_links(report, payload)}
    """


def _argument_map(payload: dict[str, Any]) -> str:
    argument_map = payload.get("argument_map") if isinstance(payload.get("argument_map"), dict) else {}
    if not argument_map:
        return ""
    body = [
        f'<p><strong>Central claim:</strong> {_safe(argument_map.get("central_claim"))}</p>',
        f'<p><strong>Claim type:</strong> {_safe(argument_map.get("claim_type"))} · <strong>Confidence:</strong> {_safe(argument_map.get("confidence"))}</p>',
        "<details open><summary>Supporting reasons</summary>" + _list(argument_map.get("supporting_reasons")) + "</details>",
        "<details><summary>Objections</summary>" + _list(argument_map.get("objections")) + "</details>",
        "<details><summary>Assumptions</summary>" + _list(argument_map.get("assumptions")) + "</details>",
        "<details><summary>Missing voices</summary>" + _list(argument_map.get("missing_voices")) + "</details>",
        "<details><summary>Evidence gaps</summary>" + _list(argument_map.get("evidence_gaps")) + "</details>",
        "<details><summary>Next questions</summary>" + _list(argument_map.get("next_questions")) + "</details>",
    ]
    return "".join(body)


def _claim_groups(checkworthy: Any) -> list[dict[str, Any]]:
    if isinstance(checkworthy, dict):
        if isinstance(checkworthy.get("claims"), list):
            return [item for item in checkworthy["claims"] if isinstance(item, dict)]
        rows: list[dict[str, Any]] = []
        for group in ("factual", "interpretive", "causal", "normative", "policy"):
            for item in ensure_list(checkworthy.get(group)):
                if isinstance(item, dict):
                    row = dict(item)
                    row.setdefault("claim_type", group)
                    rows.append(row)
        return rows
    return [item for item in ensure_list(checkworthy) if isinstance(item, dict)]


def _checkworthy_claims(payload: dict[str, Any]) -> str:
    rows = _claim_groups(payload.get("checkworthy_claims"))
    if not rows:
        return ""
    html = ['<p class="note">Check-worthy means worth verifying, not false. No external lookup is run by this viewer.</p>']
    for item in rows:
        queries = ", ".join(clean_text(query) for query in ensure_list(item.get("suggested_queries")) if clean_text(query))
        sources = ", ".join(clean_text(source) for source in ensure_list(item.get("likely_source_types")) if clean_text(source))
        html.append(
            '<article class="claim-item">'
            f'<h3>{_safe(item.get("claim"))}</h3>'
            f'<p><strong>Type:</strong> {_safe(item.get("claim_type"))} · <strong>Priority:</strong> {_safe(item.get("verification_priority_label") or _display_label(item.get("verification_priority"), PRIORITY_LABELS))}</p>'
            f'<p><strong>Evidence needed:</strong> {_safe(item.get("evidence_needed"))}</p>'
            f'<p><strong>Likely sources:</strong> {_safe(sources)}</p>'
            f'<p><strong>Suggested queries:</strong> {_safe(queries)}</p>'
            f'<p><strong>Support/contrast:</strong> {_safe(item.get("support_contrast_label") or _display_label(item.get("support_contrast_status"), SUPPORT_CONTRAST_LABELS))}</p>'
            f'<p><strong>Uncertainty:</strong> {_safe(item.get("uncertainty_note"))}</p>'
            "</article>"
        )
    return "".join(html)


def _external_fact_check_results(payload: dict[str, Any]) -> list[dict[str, Any]]:
    external = payload.get("external_fact_checks") if isinstance(payload.get("external_fact_checks"), dict) else {}
    rows = []
    for item in ensure_list(external.get("results")):
        if isinstance(item, dict) and ensure_list(item.get("matches")):
            rows.append(item)
    return rows


def _external_fact_checks(payload: dict[str, Any]) -> str:
    rows = _external_fact_check_results(payload)
    if not rows:
        return ""
    html = ['<p class="note">Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.</p>']
    for result in rows:
        html.append(
            '<article class="claim-item">'
            f'<h3>{_safe(result.get("claim_id") or "Retrieved claim")}</h3>'
            f'<p><strong>Status:</strong> {_safe(result.get("status"))}</p>'
            f'<p>{_safe(result.get("summary"))}</p>'
        )
        for match in ensure_list(result.get("matches")):
            if not isinstance(match, dict):
                continue
            review = match.get("review") if isinstance(match.get("review"), dict) else {}
            html.append(
                '<div class="factcheck-match">'
                f'<p><strong>{_safe(review.get("publisher_name") or review.get("publisher_site"))}</strong> · {_safe(review.get("review_date"))}</p>'
                f'<p>{_safe(review.get("title") or match.get("matched_claim_text"))}</p>'
                f'<p><strong>Publisher rating:</strong> "{_safe(review.get("textual_rating"))}"</p>'
                f'<p><strong>URL:</strong> <a href="{_safe_attr(review.get("url"))}">{_safe(review.get("url"))}</a></p>'
                f'<p><strong>Match confidence:</strong> {_safe(match.get("match_confidence"))}</p>'
                "</div>"
            )
        if result.get("status") == "conflicting_reviews":
            html.append('<p class="note">Conflicting publisher assessments are preserved rather than merged into one score.</p>')
        html.append("</article>")
    return "".join(html)


def _dissent_ledger(payload: dict[str, Any]) -> str:
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    rows = ensure_list(advanced.get("dissent_ledger"))
    if not rows:
        return ""
    html = []
    for item in rows:
        if not isinstance(item, dict):
            continue
        name = item.get("agent") or item.get("agent_name") or item.get("name")
        if clean_text(item.get("consensus_note")):
            html.append(
                '<article class="ledger-item">'
                f'<h3>{_safe(name)}</h3>'
                + (f'<p><strong>Shared finding:</strong> {_safe(item.get("top_finding") or item.get("finding"))}</p>' if clean_text(item.get("top_finding") or item.get("finding")) else "")
                + f'<p><strong>Consensus note:</strong> {_safe(item.get("consensus_note"))}</p>'
                + "</article>"
            )
            continue
        html.append(
            '<article class="ledger-item">'
            f'<h3>{_safe(name)}</h3>'
            + (f'<p><strong>Top finding:</strong> {_safe(item.get("top_finding") or item.get("finding"))}</p>' if clean_text(item.get("top_finding") or item.get("finding")) else "")
            + (f'<p><strong>Strongest disagreement:</strong> {_safe(item.get("strongest_disagreement") or item.get("disagreement"))}</p>' if clean_text(item.get("strongest_disagreement") or item.get("disagreement")) else "")
            + (f'<p><strong>Confidence:</strong> {_safe(item.get("confidence"))}</p>' if clean_text(item.get("confidence")) else "")
            + (f'<p><strong>Would change mind if:</strong> {_safe(item.get("what_would_change_its_mind") or item.get("what_would_change_mind"))}</p>' if clean_text(item.get("what_would_change_its_mind") or item.get("what_would_change_mind")) else "")
            + "</article>"
        )
    return "".join(html)


def _reasoning_traps(payload: dict[str, Any]) -> str:
    traps = ensure_list(payload.get("reasoning_traps"))
    if not traps:
        return ""
    html = []
    for item in traps:
        if not isinstance(item, dict):
            continue
        html.append(
            '<article class="trap-item">'
            f'<h3>{_safe(item.get("label") or item.get("name") or item.get("trap"))}</h3>'
            f'<p><strong>Risk:</strong> {_safe(item.get("risk") or item.get("description"))}</p>'
            f'<p><strong>Next check:</strong> {_safe(item.get("next_check") or item.get("check"))}</p>'
            f'<p><strong>Severity:</strong> {_safe(item.get("severity") or item.get("confidence"))}</p>'
            "</article>"
        )
    return "".join(html)


def _activity_card(title: str, item: dict[str, Any]) -> str:
    if not isinstance(item, dict) or not clean_text(item.get("title")):
        return ""
    steps = "".join(f"<li>{_safe(step)}</li>" for step in ensure_list(item.get("steps")) if clean_text(step))
    focus = ", ".join(clean_text(part) for part in ensure_list(item.get("thinking_focus")) if clean_text(part))
    return (
        '<article class="activity-item">'
        f'<h3>{_safe(title)}: {_safe(item.get("title"))}</h3>'
        f'<p><strong>Why this fits:</strong> {_safe(item.get("why_this_fits"))}</p>'
        f'<p><strong>Content focus:</strong> {_safe(item.get("content_focus"))}</p>'
        f'<p><strong>Thinking focus:</strong> {_safe(focus)}</p>'
        f"<ol>{steps}</ol>"
        f'<p class="note">{_safe(item.get("source_note") or "Curated from Critical Compass.")}</p>'
        + (f'<p class="note">{_safe(item.get("safety_note"))}</p>' if clean_text(item.get("safety_note")) else "")
        + "</article>"
    )


def _follow_up_activity(payload: dict[str, Any]) -> str:
    activity = payload.get("follow_up_activity") if isinstance(payload.get("follow_up_activity"), dict) else {}
    if not activity:
        return ""
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    depth = clean_text(meta.get("report_depth")) or "full"
    if depth in {"overview", "readiness_card"}:
        body = _activity_card("Try This Next", activity.get("try_this_next") if isinstance(activity.get("try_this_next"), dict) else {})
    else:
        body = (
            _activity_card("Solo Activity", activity.get("solo_activity") if isinstance(activity.get("solo_activity"), dict) else {})
            + _activity_card("Group Activity", activity.get("group_activity") if isinstance(activity.get("group_activity"), dict) else {})
        )
    guardrails = _list(activity.get("guardrails")) if activity.get("guardrails") else ""
    source = f'<p class="note">{_safe(activity.get("source_note"))}</p>' if clean_text(activity.get("source_note")) else ""
    fit = activity.get("fit_check") if isinstance(activity.get("fit_check"), dict) else {}
    fit_html = ""
    if fit:
        fit_html = (
            '<article class="activity-item">'
            "<h3>Activity Reflection</h3>"
            f'<p><strong>{_safe(fit.get("prompt"))}</strong></p>'
            f'<p>{_safe(fit.get("reflection_question"))}</p>'
            f'<p class="note">{_safe(fit.get("reader_note"))}</p>'
            "</article>"
        )
    return body + source + guardrails + fit_html


def _trust_preflight(payload: dict[str, Any]) -> str:
    preflight = payload.get("source_tool_trust_preflight") if isinstance(payload.get("source_tool_trust_preflight"), dict) else {}
    if not preflight or clean_text(preflight.get("status")) == "not_run":
        return ""
    provenance = preflight.get("source_provenance") if isinstance(preflight.get("source_provenance"), dict) else {}
    ocr = preflight.get("ocr_extraction_confidence") if isinstance(preflight.get("ocr_extraction_confidence"), dict) else {}
    prompt = preflight.get("prompt_injection_checks") if isinstance(preflight.get("prompt_injection_checks"), dict) else {}
    warnings = "".join(f"<li>{_safe(item.get('message') if isinstance(item, dict) else item)}</li>" for item in ensure_list(preflight.get("warnings")))
    return f"""
      <p><strong>Status:</strong> {_safe(preflight.get("status"))}</p>
      <p><strong>Source ID:</strong> {_safe(provenance.get("source_id"))}</p>
      <p><strong>Extraction:</strong> {_safe(provenance.get("extraction_method"))}</p>
      <p><strong>OCR confidence:</strong> {_safe(ocr.get("level"))}</p>
      <p><strong>Prompt-injection signals:</strong> {_safe(prompt.get("present"))}</p>
      <ul>{warnings}</ul>
    """


def _questions(payload: dict[str, Any]) -> str:
    questions = payload.get("questions") if isinstance(payload.get("questions"), dict) else {}
    return "<h3>Probing</h3>" + _list(questions.get("probing")) + "<h3>Follow-up</h3>" + _list(questions.get("follow_up"))


def render_viewer_html(payload: dict[str, Any], report: dict[str, Any], manifest_path: str) -> str:
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    title = clean_text(meta.get("report_title")) or "Critical Compass Audit Viewer"
    dissent_title = "Where the Analysts Reached Consensus" if advanced.get("consensus_only") else "Where the Analysts Disagreed"
    dissent_nav_label = "Consensus" if advanced.get("consensus_only") else "Dissent"
    sections = [
        ("Decision", "decision"),
        ("Argument Map", "argument-map"),
        ("Evidence Needed Next", "checkworthy"),
        ("Follow-Up Activity", "follow-up-activity"),
        ("External Fact Checks", "external-fact-checks"),
        (dissent_nav_label, "dissent"),
        ("Reasoning Traps", "traps"),
        ("Questions", "questions"),
        ("Trust", "trust"),
    ]
    nav = "".join(f'<a href="#{section_id}">{label}</a>' for label, section_id in sections)
    manifest_json = escape(json_dumps({"manifest_path": manifest_path, "viewer_version": VIEWER_VERSION}), quote=True)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{_safe(title)}</title>
  <style>
    :root {{
      --text: #202124;
      --muted: #5f6368;
      --rule: #d7d9dd;
      --surface: #f7f8f9;
      --green: #2d7d46;
      --blue: #3f6f9f;
      --amber: #b56f00;
      --red: #b3261e;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      color: var(--text);
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.45;
      background: #ffffff;
    }}
    header {{
      border-bottom: 1px solid var(--rule);
      padding: 28px 28px 18px;
    }}
    main {{
      display: grid;
      grid-template-columns: minmax(180px, 240px) minmax(0, 920px);
      gap: 28px;
      padding: 24px 28px 56px;
    }}
    nav {{
      align-self: start;
      border-right: 1px solid var(--rule);
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-right: 18px;
      position: sticky;
      top: 16px;
    }}
    nav a {{
      border-radius: 6px;
      color: var(--blue);
      padding: 7px 8px;
      text-decoration: none;
    }}
    nav a:focus, nav a:hover {{ outline: 2px solid var(--blue); outline-offset: 2px; }}
    section {{
      border-bottom: 1px solid var(--rule);
      padding: 0 0 24px;
      margin-bottom: 24px;
    }}
    h1 {{ font-size: 28px; line-height: 1.15; margin: 0 0 8px; }}
    h2 {{ font-size: 20px; line-height: 1.2; margin: 0 0 14px; }}
    h3 {{ font-size: 15px; line-height: 1.25; margin: 14px 0 8px; }}
    p {{ margin: 0 0 10px; }}
    .meta, .path, .empty, .note {{ color: var(--muted); font-size: 13px; }}
    .verdict-line {{ align-items: baseline; display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 10px; }}
    .verdict {{ color: var(--blue); font-size: 30px; font-weight: 800; }}
    .points {{ color: var(--muted); font-size: 16px; }}
    .plain-read {{ font-size: 18px; font-style: italic; margin: 16px 0; max-width: 760px; }}
    .before-use, .callout {{
      border-left: 4px solid var(--amber);
      background: var(--surface);
      border-radius: 6px;
      margin: 12px 0;
      padding: 12px;
    }}
    .score-interpretation {{
      background: var(--soft);
      border-left: 4px solid var(--blue);
      border-radius: 6px;
      color: var(--muted);
      margin: 12px 0;
      padding: 12px;
    }}
    .score-interpretation p {{ margin-bottom: 6px; }}
    .score-interpretation p:last-child {{ margin-bottom: 0; }}
    .callout.next {{ border-left-color: var(--green); }}
    .dimension-row {{
      align-items: center;
      display: grid;
      gap: 10px;
      grid-template-columns: minmax(160px, 260px) minmax(120px, 1fr) 58px;
      margin: 9px 0;
    }}
    .bar-track {{ background: #e8eaed; border-radius: 6px; height: 12px; overflow: hidden; }}
    .bar-track span {{ display: block; height: 100%; }}
    .bar-track .good {{ background: var(--green); }}
    .bar-track .mixed {{ background: var(--amber); }}
    .bar-track .risk {{ background: var(--red); }}
    .artifact-links div, .claim-item, .ledger-item, .trap-item, .activity-item {{
      border: 1px solid var(--rule);
      border-radius: 6px;
      margin: 10px 0;
      padding: 12px;
    }}
    .artifact-links a {{ display: inline-block; font-weight: 700; margin-right: 10px; }}
    details {{ border: 1px solid var(--rule); border-radius: 6px; margin: 9px 0; padding: 10px 12px; }}
    summary {{ cursor: pointer; font-weight: 700; }}
    ul {{ margin-top: 6px; padding-left: 22px; }}
    code {{ white-space: pre-wrap; }}
    @media (max-width: 760px) {{
      main {{ display: block; padding: 18px; }}
      nav {{ border-right: 0; border-bottom: 1px solid var(--rule); margin-bottom: 22px; padding: 0 0 14px; position: static; }}
      .dimension-row {{ grid-template-columns: 1fr; }}
      .score {{ color: var(--muted); }}
    }}
  </style>
</head>
<body data-critical-compass="{manifest_json}">
  <header>
    <h1>{_safe(title)}</h1>
    <p class="meta">Read-only Critical Compass artifact viewer · {VIEWER_VERSION}</p>
  </header>
  <main>
    <nav aria-label="Artifact sections">{nav}</nav>
    <div>
      {_section("Decision Layer", _decision_layer(payload, report), "decision")}
      {_section("Argument Map", _argument_map(payload), "argument-map")}
      {_section("Evidence Needed Next", _checkworthy_claims(payload), "checkworthy")}
      {_section("Follow-Up Activity", _follow_up_activity(payload), "follow-up-activity")}
      {_section("External Fact Checks", _external_fact_checks(payload), "external-fact-checks")}
      {_section(dissent_title, _dissent_ledger(payload), "dissent")}
      {_section("Reasoning Trap Checks", _reasoning_traps(payload), "traps")}
      {_section("Questions To Bring To The Text", _questions(payload), "questions")}
      {_section("Source And Tool Trust", _trust_preflight(payload), "trust")}
    </div>
  </main>
</body>
</html>
"""


def _load_manifest(path: Path) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, str]]]:
    warnings: list[dict[str, str]] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not read report manifest: {exc}") from exc
    payload = data.get("payload") if isinstance(data.get("payload"), dict) else {}
    report = data.get("report") if isinstance(data.get("report"), dict) else {}
    if not payload:
        warnings.append({"code": "missing_payload", "message": "Manifest did not include a payload object."})
    if not report:
        warnings.append({"code": "missing_report", "message": "Manifest did not include a report object."})
    return payload, report, warnings


def generate_audit_artifact_viewer(
    manifest_path: str,
    output_path: str | None = None,
) -> dict[str, Any]:
    try:
        manifest = Path(manifest_path).expanduser().resolve()
        if not manifest.exists():
            return {
                "status": "blocked",
                "viewer_path": "",
                "ui_version": VIEWER_VERSION,
                "source_manifest_path": str(manifest),
                "warnings": [{"code": "manifest_missing", "message": "Manifest path does not exist."}],
                "sections": [],
            }
        payload, report, warnings = _load_manifest(manifest)
        output = Path(output_path).expanduser().resolve() if output_path else manifest.with_name(manifest.stem + "-viewer.html")
        output.parent.mkdir(parents=True, exist_ok=True)
        html = render_viewer_html(payload, report, str(manifest))
        output.write_text(html, encoding="utf-8")
        sections = [
            section
            for section, present in {
                "decision": True,
                "pressure_test_readiness_card": bool(payload.get("pressure_test_readiness_card")),
                "argument_map": bool(payload.get("argument_map")),
                "checkworthy_claims": bool(_claim_groups(payload.get("checkworthy_claims"))),
                "follow_up_activity": bool(payload.get("follow_up_activity")),
                "external_fact_checks": bool(_external_fact_check_results(payload)),
                "dissent_ledger": bool((payload.get("advanced_audit") or {}).get("dissent_ledger")) if isinstance(payload.get("advanced_audit"), dict) else False,
                "reasoning_traps": bool(ensure_list(payload.get("reasoning_traps"))),
                "questions": bool(payload.get("questions")),
                "source_tool_trust_preflight": bool(payload.get("source_tool_trust_preflight")),
            }.items()
            if present
        ]
        return {
            "status": "ready",
            "viewer_path": str(output),
            "ui_version": VIEWER_VERSION,
            "source_manifest_path": str(manifest),
            "sections": sections,
            "warnings": warnings,
            "open_hint": "Open viewer_path in a browser. This is a read-only local artifact viewer; it does not run retrieval or alter audit data.",
        }
    except Exception as exc:  # pragma: no cover - defensive MCP safety
        return {
            "status": "blocked",
            "viewer_path": "",
            "ui_version": VIEWER_VERSION,
            "source_manifest_path": clean_text(manifest_path),
            "warnings": [{"code": "viewer_error", "message": f"{type(exc).__name__}: {exc}"}],
            "sections": [],
        }
