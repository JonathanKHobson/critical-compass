"""Course-facing prompt and guidance resources for Critical Compass."""

from __future__ import annotations

from typing import Any


CLASSROOM_STANDARD_AUDIT_PROMPT_VERSION = "classroom-standard-audit.v1"


CLASSROOM_STANDARD_AUDIT_PROMPT = """Please run a standard Critical Compass audit on the text below.

Use this fixed frame:
- Audience: [who this is for]
- Intended use: [what this writing is meant to do]
- Text type: [memo / pitch / email / report section / social post / proposal / other]
- Audit depth: standard
- Output purpose: classroom bias-audit reflection

Do not run an advanced panel review, multi-agent review, or web research. Do not rewrite the text unless I ask afterward.

Use this exact output structure:
1. Critical Integrity Snapshot
2. Plain-Language Read
3. Before Using This Text
4. Top 3-5 findings
   - finding name
   - severity: high / medium / low
   - specific evidence from the text
   - why it matters for the stated audience and intended use
5. Key tension
6. Recommended next revision
7. Two peer-discussion questions

Here is the text to audit:

[paste text]"""


INSTRUCTOR_COURSE_USE_NOTE = (
    "Critical Compass is AI-assisted, so outputs may differ across models and runs. "
    "For class discussion, compare the top findings, severity, and revision decisions "
    "more than exact point scores."
)


WEEK2_COURSE_FEEDBACK = [
    "Replace the broad standard-audit instruction with the classroom prompt so every student supplies audience, intended use, text type, audit depth, and expected section order.",
    "Keep the variance explanation in instructor guidance, not in the student prompt.",
    "Tell students to use the same text if they rerun the audit; if they revise it, label the next draft Version 2 and compare findings rather than just the score.",
    "Keep advanced audit and advanced panel review out of the core assignment; offer them only as an optional extension for deeper critique.",
    "Use MCPB extension language for Claude Desktop and keep Claude Desktop setup separate from ChatGPT or prompt-only skill-file setup.",
    "Replace any de-westernization debrief wording that overpromises with: Did the audit surface any perspective, power, cultural, or missing-voice issue that shifted how you see the text?",
]


MCP_COURSE_RELIABILITY_BACKLOG = {
    "P0": [
        "Ship the classroom_standard_audit_prompt resource/template without adding a new public tool.",
        "Route course users to standard audit, not advanced panel review, in get_started and overview guidance.",
        "Document course-use guidance: standardize audience, intended use, text type, audit depth, and output section order.",
        "Add an install/version note that older installs may lack newer score framing and should be updated before course use.",
    ],
    "P1": [
        "Consider a classroom or standard_course output profile after the prompt path is validated.",
        "Strengthen score-rationale trace so the score is visibly tied to top findings and dimensions.",
        "Improve compare_audit_results guidance for revised drafts: compare finding changes and dimension movement; do not treat raw score delta as proof of improvement.",
    ],
    "P2": [
        "Add repeated-run calibration evals using the same sample text, fixed prompt, and multiple model or host contexts.",
        "Consider a public course_mode only after the prompt/template path proves useful in the course.",
    ],
}


def classroom_standard_audit_prompt_resource() -> dict[str, Any]:
    """Return the canonical classroom prompt and instructor guidance."""

    return {
        "resource_id": "classroom_standard_audit_prompt",
        "prompt_version": CLASSROOM_STANDARD_AUDIT_PROMPT_VERSION,
        "status": "ready",
        "audience": "students",
        "use_case": "Week 2 Critical Compass classroom bias-audit exercise",
        "recommended_tool": "audit_text",
        "student_prompt": CLASSROOM_STANDARD_AUDIT_PROMPT,
        "student_prompt_rules": {
            "blocks_advanced_panel_review": True,
            "blocks_multi_agent_review": True,
            "blocks_web_research": True,
            "blocks_rewrite_by_default": True,
            "requires_audience": True,
            "requires_intended_use": True,
            "requires_text_type": True,
            "requires_audit_depth": True,
            "requires_fixed_output_structure": True,
            "student_prompt_should_include_variance_disclaimer": False,
        },
        "instructor_note": INSTRUCTOR_COURSE_USE_NOTE,
        "course_feedback": WEEK2_COURSE_FEEDBACK,
        "backlog": MCP_COURSE_RELIABILITY_BACKLOG,
        "version_guidance": "Before course use, update older Claude Desktop or skill-file installs so students receive the newer score framing and course routing guidance.",
        "next_step": "Paste the student prompt into the Week 2 assignment and keep the instructor note outside the prompt.",
    }
