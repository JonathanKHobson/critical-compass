# Critical Compass Claude Plugin Beta

This is a Claude plugin package that bundles:

- Critical Compass skill instructions
- predefined Critical Compass pressure-test agents
- a plugin-local Critical Compass MCP server
- `.mcp.json` configuration for that MCP server

The intended upload file is:

```text
critical-compass-plugin.zip
```

## Where This Fits

Use this zip when Claude Cowork or Claude Code asks you to upload a custom plugin file.

Use the standalone `.mcpb` instead when Claude Desktop Settings > Extensions asks for a Desktop Extension.

## Install

1. Open Claude Desktop.
2. Go to the Cowork tab.
3. Open Customize.
4. Choose the custom plugin upload option.
5. Upload `critical-compass-plugin.zip`.
6. Enable the plugin.

## Updating An Existing Install

If Claude says plugin validation failed while replacing an older Critical Compass upload, remove or disable the existing `critical-compass` custom plugin from My Uploads first, then upload the new zip again.

Claude may reject a same-name plugin upload instead of treating it as an overwrite. The source package version is bumped when the zip changes, but the clean replacement path is still remove old upload, then reinstall.

## First Test

After enabling the plugin, start a new Cowork task and ask:

```text
Use Critical Compass and call get_started.
```

If MCP tools do not appear, ask:

```text
Use the critical-compass:setup skill to diagnose why the bundled MCP connector is not active.
```

The skill can still work in Reference Mode even if the MCP connector does not start.

## Included Agents

The plugin includes focused Critical Compass agents for before-use review:

- `evidence-auditor`: finds weak evidence, overclaiming, and claims worth verifying.
- `assumption-bias-reviewer`: surfaces hidden assumptions, reasoning traps, and loaded framing.
- `plurality-framing-reviewer`: checks missing voices, affected-community absence, and overly narrow framing.
- `publication-readiness-reviewer`: gives a practical ready/revise/verify/reframe call before publication or use.
- `report-synthesis-editor`: turns findings into a plain-language action summary.

## Expected Warning

Claude may warn that this plugin includes local software or local MCP access. That is expected. Only install this plugin if you trust the source.

## Beta Notes

- This plugin is experimental and has not been submitted to Anthropic’s plugin directory.
- It is intended for a friendly beta tester, not broad public distribution.
- The bundled MCP runs locally through `uv`.
- Fact-checking is scaffold-first by default; no Google, Brave, or provider key is required.
