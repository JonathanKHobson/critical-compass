---
description: Guide installation, activation, and troubleshooting for the Critical Compass plugin and bundled MCP server.
---

# Critical Compass Setup

Use this skill when the user is installing, activating, or diagnosing the Critical Compass plugin.

## What This Plugin Includes

- A Critical Compass skill for reference-mode audits and pressure-testing.
- A bundled local Critical Compass MCP server configured through `.mcp.json`.
- The bundled MCP should expose tools such as `get_started`, `critical_compass_overview`, `quick_scan`, `audit_text`, `claim_stress_test`, `factcheck_lookup`, and `generate_audit_report`.

## First Smoke Test

Ask Claude to use the MCP first:

```text
Use Critical Compass and call get_started.
```

Then try:

```text
Use Critical Compass to quick-scan this text before I publish it:
"Our program is the only proven solution for youth mental health, and every school should adopt it immediately."
```

## If MCP Tools Do Not Appear

Diagnose in this order:

1. Confirm the plugin zip was uploaded as a plugin, not installed as a standalone MCPB extension.
2. Confirm the plugin is enabled.
3. Confirm the host supports plugin-bundled local MCP servers.
4. Confirm `uv` is available to the host environment.
5. Check whether the MCP server warning or permission prompt was declined.
6. If the MCP is unavailable, use the Critical Compass skill in Reference Mode and tell the user the MCP connector is not active.

## Safety Rules

- Do not claim `factcheck_lookup` performed retrieval unless its result says `lookup_performed=true`.
- Do not add Google, Brave, or provider keys unless the user explicitly asks.
- Do not treat “no match” as true or false.
- Do not call third-party MCPs while diagnosing Critical Compass.
- Preserve existing plugin, skill, and connector settings.

