# Disambiguation Rules

Use this file when a finding could fit more than one category. The goal is to prevent category bleed.

## Core Distinctions

| If you see... | Prefer | Why |
|---|---|---|
| Authority or credentials replace evidence evaluation | Authority bias | The person is over-weighting status cues. |
| An authority is used as decisive proof in an argument | Appeal to authority | The argument structure treats authority as sufficient support. |
| Popularity changes preference or uptake | Bandwagon effect | The judgment is being shaped by social proof. |
| Popularity is offered as proof that a claim is true | Bandwagon fallacy | The argument treats popularity as evidence of truth. |
| Only successful cases are visible | Survivorship bias | The denominator is missing from judgment. |
| Only successful cases are used as proof of a strategy | Survivorship reasoning risk | The argument structure overgeneralizes from winners. |
| Broad conclusion from too little evidence | Hasty generalization | The problem is the inference from sample to claim. |
| Narrow sample used for a research or policy claim | External validity or WEIRD bias | The problem is transportability, not just rhetoric. |
| Causal language from correlation | Causal overreach | The problem is causal inference. |
| Loaded wording shifts interpretation | Framing effect or frame | Use framing effect only if the wording changes preference or judgment. |
| Missing affected groups or costs | Frame or assumption | Do not force a bias label if no judgment tendency is shown. |

## Tie-Breaking Rules

- Use the most specific label that helps the user think better.
- If a named label adds no practical clarity, describe the concern in plain language.
- Do not double-count one passage with both bias and fallacy unless both are genuinely present.
- Prefer `method/evidence issue` for research design, measurement, sampling, and replication problems.
- Prefer `assumption` for unstated premises, especially cultural, normative, and stakeholder assumptions.

## Anti-Patterns

- Do not label every critique as "bias."
- Do not call a person biased; describe the reasoning pattern in the text.
- Do not use fallacy labels as dismissals.
- Do not treat source confidence as proof that a label fits a passage.
