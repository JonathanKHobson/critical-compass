# Critical Integrity Snapshot

Lightweight version of the MCP's Critical Integrity Snapshot. Use this in Reference Mode without
needing the MCP.

Source note: distilled from the Critical Compass MCP output shape during v2 skill improvement.

## Purpose

The snapshot gives the user a fast read on how much work the text can safely carry before they rely
on it. It is not a school grade, truth score, or moral judgment. It is a traceability signal for the
audit.

## Required Outputs

### Plain-Language Read

Write 1-2 plain sentences. Avoid jargon.

Good pattern:

> Useful starting point, but the main claim needs narrower scope and visible evidence before it should guide decisions.

### Integrity Snapshot

Render the label first and points second.

Labels:

| Points | Label |
|---:|---|
| 90-100 | Exemplary Integrity |
| 75-89 | Strong Integrity |
| 55-74 | Moderate Integrity |
| 35-54 | Limited Integrity |
| 0-34 | Needs Scrutiny |

Use `Profile Only` instead of points when the source is too short, context is missing, or scoring would
create false precision. In profile-only mode, still give the five dimension reads without points.

Dimensions:

| Dimension | Ask | Improvement prompt pattern |
|---|---|---|
| Grounding & Scope Fit | Does the claim stay inside the evidence shown? | Name the evidence type and keep the claim inside that scope. |
| Assumptions & Context | Are the key factual, causal, cultural, or normative assumptions visible? | State the assumption a skeptical reader would test first. |
| Bias Transparency | Does the text own its angle, incentives, or selection choices? | Own the standpoint instead of presenting advocacy as neutral fact. |
| Framing & Audience Openness | Does the text make alternatives, limits, or affected readers visible? | Name the strongest alternative interpretation or missing comparison. |
| Positionality & Power | Are speaker position, beneficiaries, and missing stakeholders visible? | Name who is speaking, who benefits, and whose stakes are missing. |

## Scoring Guidance

- Start each dimension at 12/20 for ordinary partial text.
- Add points for visible evidence, bounded claims, uncertainty, alternatives, and stakeholder clarity.
- Subtract points for universal claims, causal overreach, hidden assumptions, loaded framing, absent sources,
  missing affected groups, or unclear speaker incentives.
- Use score confidence: high, medium, or low.
- For headlines, one-liners, and fragments, prefer `Profile Only` or low score confidence.

## Table Template

```md
## Plain-Language Read
...

## Integrity Snapshot
**Label:** Moderate Integrity (`66/100`, confidence: medium)

| Dimension | Points | Read | To Strengthen |
|---|---:|---|---|
| Grounding & Scope Fit | 18/20 | The text names evidence but claim scope still needs checking. | Name the evidence type and keep the claim scope inside that evidence. |
| Assumptions & Context | 10/20 | Universal language leaves assumptions doing structural work. | State the assumption a skeptical reader would test first. |
| Bias Transparency | 12/20 | The angle is visible but not fully owned. | Own the standpoint instead of presenting advocacy as neutral fact. |
| Framing & Audience Openness | 16/20 | Alternative interpretations are not very visible. | Name the strongest alternative interpretation or missing comparison. |
| Positionality & Power | 10/20 | Speaker, incentives, and centered voices are only partly visible. | Name who is speaking, who benefits, and whose stakes are missing. |

## Before Using This Text
Before using this text, ask what evidence would change the reader's mind about the highest-stakes claim.
```

## Before Using This Text

One sentence, action-oriented. It should tell the user what to check before acting on, publishing,
sharing, teaching, or relying on the text.

Patterns:

- Before using this text, verify the evidence behind the claim carrying the most weight.
- Before sharing this, narrow the claim to the population and context actually supported.
- Before relying on this, ask who is missing from the frame and whether their stakes change the conclusion.
