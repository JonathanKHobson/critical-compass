# Output Templates

Use these shapes. Keep responses compact unless the user asks for depth. Optional sections should appear
only when the text supports them.

## Standard Audit

```md
[Reference Mode]
[Depth: Standard audit]
[Genre: ...] [Domain: ...] [Claim type: ...] [Sensitivity: STANDARD/HIGH]
[Scope: Full/Partial]

## One-Line Orientation

## Plain-Language Read
...

## Integrity Snapshot
**Label:** ... (`../100`, confidence: ...)

| Dimension | Points | Read | To Strengthen |
|---|---:|---|---|
| Grounding & Scope Fit | ../20 | ... | ... |
| Assumptions & Context | ../20 | ... | ... |
| Bias Transparency | ../20 | ... | ... |
| Framing & Audience Openness | ../20 | ... | ... |
| Positionality & Power | ../20 | ... | ... |

## Before Using This Text
Before using this text, ...

## Decision Read
**Primary action:** Trust | Revise | Verify | Reframe
**Why:** ...
**Next move:** ...

## What Holds Up
- ...

## Highest-Priority Concerns
| Passage | Type | Name | KB ID | Match Confidence | Source Confidence | Why It Matters | What Would Reduce Concern | Thinking Move |
|---|---|---|---|---|---|---|---|---|

## Argument Map
- Central claim: ...
- Claim type: factual | causal | interpretive | normative | policy | mixed
- Supporting reasons: ...
- Objections: ...
- Assumptions: ...
- Missing voices: ...
- Evidence gaps: ...

## Assumptions
- ...

## Method & Evidence Check
- ...

## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed | Likely Source Types | Suggested Query |
|---|---|---|---|---|---|

## Reasoning Trap Checks
| Trap | Risk | Next Check |
|---|---|---|

## Alternative Frames
- ...

## What Would Change My Mind?
...

## Follow-Up Activity
**Solo Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate

**Group Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate
- Safety note: ...

## Follow-Up Questions
1. ...
2. ...
3. ...

## Next Steps
1. ...
2. ...
3. ...
```

## Quick Scan

```md
[Reference Mode]
[Depth: Quick scan]
[Genre: ...] [Domain: ...] [Claim type: ...] [Sensitivity: STANDARD/HIGH]
[Scope: Full/Partial]

## Quick Read
- Plain-language read: ...
- Integrity snapshot: ... (`../100`)
- Before using this text: ...
- Decision read: Trust | Revise | Verify | Reframe - ...
- What holds up: ...
- Biggest concern: ...
- Best next question: ...
- Try this next: ...

## Top Concerns
| Passage | Type | Concern | Match Confidence | What To Check |
|---|---|---|---|---|

## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed |
|---|---|---|---|

## Next Step
...
```

## Claim Stress-Test

```md
[Reference Mode]
[Depth: Drill-down]
[Genre: single claim] [Domain: ...] [Claim type: ...] [Sensitivity: STANDARD/HIGH]
[Scope: Partial]

## Claim Stress-Test

## Steelman
...

## Risk, Not Verdict
| Risk | KB ID | Match Confidence | Source Confidence | Why It Fits | What Would Reduce Concern |
|---|---|---|---|---|---|

## When This Reasoning May Be Valid
...

## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed | Likely Source Types |
|---|---|---|---|---|

## Probing Questions
1. ...
2. ...
3. ...

## Tightened Claim
...

## Try This Next
...
```

## Research Review

```md
[Reference Mode]
[Depth: Research review]
[Genre: ...] [Domain: research/health/AI/etc.] [Claim type: empirical/causal/mixed] [Sensitivity: STANDARD/HIGH]
[Scope: Full/Partial]

## One-Line Orientation

## Plain-Language Read
...

## Integrity Snapshot
**Label:** ... (`../100`, confidence: ...)

| Dimension | Points | Read | To Strengthen |
|---|---:|---|---|
| Grounding & Scope Fit | ../20 | ... | ... |
| Assumptions & Context | ../20 | ... | ... |
| Bias Transparency | ../20 | ... | ... |
| Framing & Audience Openness | ../20 | ... | ... |
| Positionality & Power | ../20 | ... | ... |

## Before Using This Text
Before using this text, ...

## Decision Read
**Primary action:** Trust | Revise | Verify | Reframe
**Why:** ...
**Next move:** ...

## What Holds Up
- ...

## Method & Evidence Check
| Check | Concern | Match Confidence | What Would Reduce Concern |
|---|---|---|---|

## Overclaim Risks
| Passage | Type | Name | KB ID | Match Confidence | Source Confidence | Why It Matters | Thinking Move |
|---|---|---|---|---|---|---|---|

## Argument Map
- Central claim: ...
- Claim type: factual | causal | interpretive | normative | policy | mixed
- Supporting reasons: ...
- Objections: ...
- Assumptions: ...
- Missing voices: ...
- Evidence gaps: ...

## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed | Likely Source Types | Suggested Query |
|---|---|---|---|---|---|

## Reasoning Trap Checks
| Trap | Risk | Next Check |
|---|---|---|

## What Would Change My Mind?
...

## Follow-Up Activity
**Solo Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate

**Group Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate
- Safety note: ...

## Follow-Up Questions
1. ...
2. ...
3. ...

## Next Steps
1. ...
2. ...
3. ...
```

## Coaching Rewrite

```md
[Reference Mode]
[Depth: Coaching]
[Genre: draft] [Domain: ...] [Claim type: ...] [Sensitivity: STANDARD/HIGH]
[Scope: Full/Partial]

## What Holds Up
- ...

## Plain-Language Read
...

## Integrity Snapshot
**Label:** ... (`../100`, confidence: ...)

| Dimension | Points | Read | To Strengthen |
|---|---:|---|---|
| Grounding & Scope Fit | ../20 | ... | ... |
| Assumptions & Context | ../20 | ... | ... |
| Bias Transparency | ../20 | ... | ... |
| Framing & Audience Openness | ../20 | ... | ... |
| Positionality & Power | ../20 | ... | ... |

## Before Using This Text
Before using this text, ...

## Decision Read
**Primary action:** Trust | Revise | Verify | Reframe
**Why:** ...
**Next move:** ...

## Main Risks To Fix
| Passage | Type | Concern | Match Confidence | Fix |
|---|---|---|---|---|

## Argument Map
- Central claim: ...
- Claim type: factual | causal | interpretive | normative | policy | mixed
- Supporting reasons: ...
- Objections: ...
- Assumptions: ...
- Missing voices: ...
- Evidence gaps: ...

## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed | Likely Source Types |
|---|---|---|---|---|

## Stronger Version
...

## More Neutral Version
...

## More Evidence-Calibrated Version
...

## Follow-Up Activity
**Solo Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate

**Group Activity:** ...
- Why this fits: ...
- Steps: ...
- Content focus: ...
- Thinking focus: Critical | Creative | Compassionate
- Safety note: ...

## Next Steps
1. ...
2. ...
3. ...
```
