# Activity Layer

Use this reference when an audit should teach the user one practical way to keep thinking with the text.
The activity layer is built from a small curated Critical Compass activity pack; do not perform live
activity lookup in the standalone skill.

## Source Boundary

- Build-time source: curated Critical Compass teaching activity pack distilled before this skill was packaged.
- Runtime dependency: none.
- User-facing source note: "Curated from Critical Compass."

## Activity Roles

Use two distinct roles:

- **Internal scaffolds**: methods the AI may use while auditing, such as Claim-Support-Question, What
  Makes You Say That?, Tug for Truth Evidence Board, 3-2-1 Bridge, and argument mapping.
- **User-facing follow-ups**: activities the user can do after the audit to improve, test, teach, or
  discuss the text.

## Output Rules

- Quick scan or chat output: include at most one compact `Try This Next` idea.
- Standard, research, coaching, full, or advanced report: include one `Solo Activity` and one `Group Activity`.
- Every activity should include:
  - title
  - why this fits
  - 2-4 steps
  - content focus
  - thinking focus: Critical, Creative, Compassionate, or mixed
  - source note
  - safety note when missing voices, identity, power, or group facilitation is involved

## Selection Rules

| Audit cue | Prefer |
|---|---|
| Evidence/source gap | Claim-Support-Question; Tug for Truth Evidence Board; Question-to-Action Research Sprint |
| Draft structure or revision problem | Reverse Outline Repair; I Like / I Wish Self-Critique; Word-Phrase-Sentence |
| Audience, stakeholder, or missing voice | Empathy Map; Micro Lab Protocol; Parts-Perspectives-Me Map |
| Group alignment or review | 1-2-4-All Idea Burst; What / So What / Now What Debrief; Troika Consulting |
| Remote or distance collaboration | 1-2-4-All Idea Burst; Micro Lab Protocol; Chalk Talk Silent Board |
| Dense or technical claim | Tiny Teaching Challenge; Word-Phrase-Sentence |
| Learning/reflection context | Connect-Extend-Challenge; 3-2-1 Bridge |

## Safety And Humility

- Do not recommend therapy-adjacent, sacred/culturally grounded, identity-impersonation, or high-risk
  facilitation practices by default.
- For missing-voice work, say what consultation or evidence is needed. Do not invent lived experience.
- Keep activities tied to the supplied text. Do not turn the audit into a general course or workshop plan.
- Do not claim the activity proves the text true or false.

## Compact Examples

Evidence gap:

```md
## Follow-Up Activity
**Try This Next: Claim-Support-Question**
Why this fits: the text depends on a factual claim whose support is not visible.
Steps: Pick the load-bearing claim. Name the exact support shown. Ask the one question still unresolved.
Content focus: use the sentence that most affects whether a reader should trust the text.
Thinking focus: Critical.
Source note: Curated from Critical Compass.
```

Full report:

```md
## Follow-Up Activity
**Solo Activity: Reverse Outline Repair**
Why this fits: the draft's structure makes the strongest claim harder to evaluate.
Steps: Write what each paragraph does. Mark repeats or unsupported jumps. Repair the weakest paragraph first.
Content focus: use the paragraph that carries the main claim.
Thinking focus: Critical + Creative.

**Group Activity: Micro Lab Protocol**
Why this fits: the text needs bounded feedback from people who can notice audience, evidence, or framing risks.
Steps: Give reviewers one passage and one question. Collect confusion, concern, and persuasion notes. Turn feedback into one revision and one verification task.
Content focus: use the passage most likely to affect trust or action.
Thinking focus: Critical + Compassionate.
Safety note: do not ask participants to impersonate affected groups; seek real consultation when lived experience matters.
```
