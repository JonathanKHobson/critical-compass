# Decision Layer

Use this reference to turn an audit into a next decision. This is a standalone, no-network scaffold.
It may plan verification, but it must not imply that verification or retrieval has happened.

## Decision Read

Choose exactly one primary action.

| Action | Use when | Do next |
|---|---|---|
| Trust | The text is bounded, low-stakes, clear about limits, and not carrying a major unsupported claim. | Use it with ordinary caution. |
| Revise | The core point is useful but wording, certainty, scope, fairness, or category discipline needs repair. | Rewrite the claim before using it. |
| Verify | A factual, empirical, statistical, benchmark, causal, or source-dependent claim carries the weight. | Check the key source, measure, denominator, comparison, or causal design. |
| Reframe | The main issue is missing voice, value frame, audience fit, power, or perspective. | Restate the text through a more appropriate lens or affected stakeholder view. |

Template:

```md
## Decision Read
**Primary action:** Trust | Revise | Verify | Reframe
**Why:** ...
**Next move:** ...
```

## Argument Map

Include when the text has a central claim, recommendation, conclusion, or proposed action. Skip for
neutral notices, raw data fragments, purely descriptive logistics, or text too thin to map fairly.

Keep it compact:

```md
## Argument Map
- Central claim: ...
- Claim type: factual | causal | interpretive | normative | policy | mixed
- Supporting reasons: ...
- Objections: ...
- Assumptions: ...
- Missing voices: ...
- Evidence gaps: ...
```

Claim-type guide:

- **Factual:** can be checked against records or direct evidence.
- **Causal:** says one thing caused, prevented, increased, reduced, or explains another.
- **Interpretive:** explains meaning, significance, motivation, or implication.
- **Normative:** says what should matter, what is responsible, fair, ethical, or good.
- **Policy:** recommends collective action, rules, institutional choices, or implementation.
- **Mixed:** more than one type carries weight.

## Evidence Needed Next

Use this when factual, empirical, statistical, benchmark, policy, source-dependent, or causal claims
matter to the decision.

Rules:

- Say: "Check-worthy means worth verifying, not false."
- Rank only factual claims as `high`, `medium`, or `low`.
- Mark causal, interpretive, normative, and policy claims as `not_ranked`.
- Suggest source classes and search/query ideas, but do not say any lookup was performed.
- For causal claims, name what evidence would distinguish cause from correlation.
- For policy claims, name decision criteria, affected stakeholders, constraints, and tradeoffs.

Template:

```md
## Evidence Needed Next
Check-worthy means worth verifying, not false.

| Claim | Type | Priority | Evidence Needed | Likely Source Types | Suggested Query |
|---|---|---|---|---|---|
```

Priority guide for factual claims:

- **high:** the action, warning, score, statistic, or recommendation depends on it.
- **medium:** it materially shapes interpretation but is not the only support.
- **low:** useful background, but not decision-critical.

Use `not_ranked` for non-factual claims.

## Reasoning Trap Checks

Include only traps with visible cues. Use risk language, not verdict language.

| Trap | Visible cue | Next check |
|---|---|---|
| Missing-denominator risk | Percent change, rate, increase, decrease, or "more/less" with no baseline. | Ask for the denominator, base rate, or absolute numbers. |
| Base-rate neglect risk | A vivid case or subgroup replaces population context. | Compare the case to the relevant baseline population. |
| Anecdotal-evidence risk | One story, example, case study, or testimonial carries a broad conclusion. | Ask whether the example is typical, selected, or illustrative only. |
| Authority-laundering risk | "Experts say," "research proves," or institutional authority substitutes for visible evidence. | Ask who the authority is, whether they are in-scope, and what evidence they cite. |
| Circular-framing risk | The conclusion is smuggled into definitions: "it works because it works." | Restate the premise and conclusion separately. |
| Binary-frame risk | "Either/or," "only option," "must choose," or forced tradeoff language. | Name at least one plausible third option or condition. |
| Causation-leap risk | "Caused," "led to," "proved," or "because" without design or comparison. | Ask what comparison, mechanism, and confounder checks support causality. |
| Comfortable-answer risk | "Clearly," "obviously," or unusually easy certainty around a contested claim. | Ask what would make the conclusion harder to defend. |
| Missing-voice risk | Affected people are described but not heard from. | Ask whose experience or standing is needed before acting. |

Template:

```md
## Reasoning Trap Checks
| Trap | Risk | Next Check |
|---|---|---|
```

If no trap cue is visible, omit the section or write one sentence: "No obvious reasoning-trap cue is
visible from the provided text."

## No-Network Boundary

Reference Mode never performs live fact-checking, browsing, source retrieval, PDF rendering, or MCP
calls. It can only identify what should be checked next. If the host has tools and uses them, label
that separately and do not mix retrieved evidence with the standalone scaffold.
