# MCP Bridge

This file is only for host environments that already expose Critical Compass MCP tools. The skill must
work without this file and without MCP access.

## Principle

Use MCP as enrichment, not as runtime dependency. The response should still follow the lightweight
templates from `output-templates.md`.

## Useful MCP Tools

- `audit_text`: use for a first-pass audit when available.
- `lookup_bias`: verify a named bias before citing it.
- `claim_stress_test` or `challenge_claim`: use for one-sentence drill-downs.
- `factcheck_lookup`: use only when the user explicitly wants verification scaffolding or approved
  retrieval is already available and consented; do not make it a standalone skill dependency.
- `get_framework` / `get_pattern`: verify a reasoning lens.
- `search_knowledge_base`: find a concept when the exact name is unknown.
- `suggest_next_steps`: enrich next steps when a domain and findings are clear.

## Rendering Rules

- Never expose raw MCP JSON.
- If MCP returns an empty `bias_map`, treat that as conservative behavior, not an error.
- Do not announce MCP failure; continue in Reference Mode.
- If MCP and reference files disagree, prefer the MCP definition but keep the lightweight output shape.
- Still separate match confidence from source confidence.
- MCP `argument_map`, `checkworthy_claims`, and `reasoning_traps` may enrich the Decision Layer, but
  render them through `output-templates.md`.
- MCP KB tools may return `lens_card`, `retrieval_budget`, `selected_lens_ids`, and
  `selection_reasons`. Use those compact cards as the active lens context. Do not load or invent broad
  lens material when a selected card is available.
- MCP `fairness_to_text` is a pre-conclusion QA check. Preserve its charitable reading and expected
  non-findings unless the text itself supplies new evidence.
- MCP `follow_up_activity` or legacy `practice_suggestions` may enrich the Activity Layer. Render quick
  outputs as one compact `Try This Next` idea; render full outputs as one solo and one group activity.
- If MCP returns scaffold-only fact-check guidance, label it as planning, not retrieval.
- External fact checks should appear only when real trusted matches exist; no-match is a coverage
  limit, not evidence that the claim is true or false.
- Do not carry over MCP-only sections such as PDF readiness, artifact viewers, saved state, or raw
  human-loop internals into standalone Reference Mode output.
- Do not expose raw external-archive records, DB paths, or implementation notes. The standalone skill
  treats activity guidance as bundled local markdown, not live retrieval.

## Source Confidence Mapping

- MCP `confidence_weight`: source confidence.
- Reference `Source confidence`: source confidence.
- Model judgment about this passage: match confidence.

## Decision Layer Mapping

- MCP `plain_language_read`: Plain-Language Read.
- MCP `before_using_this_text`: Before Using This Text.
- MCP `argument_map`: Argument Map if the text has enough structure.
- MCP `checkworthy_claims`: Evidence Needed Next; factual claims can be ranked, non-factual claims
  stay `not_ranked`.
- MCP `reasoning_traps`: Reasoning Trap Checks with risk language and next checks.
- MCP `follow_up_activity`: Follow-Up Activity, preserving source-note boundaries and safety notes.
- MCP `selected_lens_ids`: KB IDs to cite when naming retrieved lenses. Labels without IDs should be
  marked `host_inference`.
