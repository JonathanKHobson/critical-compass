# Thinking Lenses

Offline reframing frames for the Critical Compass skill.

## Contents

- Live KB
- Claude-native

- Live KB frames come first.
- The live set now includes relational, cultural, and non-Western epistemology frameworks alongside the core reasoning lenses.
- `[Claude-native]` lenses are explicitly marked fallback helpers, not live corpus entries.

## Live KB

### Systems Thinking
- **KB ID:** glossary:systems-thinking
- **Type:** framework
- **Description:** Understands behavior emerging from interacting parts, feedback loops, delays, and stocks/flows. Looks beyond linear chains to cyclical dynamics and leverage points.
- **Prompt:** What feedback loops, delays, or leverage points are missing?
- **Best for:** policy memos, causal claims, org change, messy systems
- **Three Cs:** 🔍
### Socratic Questioning
- **KB ID:** glossary:socratic-questioning
- **Type:** framework
- **Description:** Disciplined inquiry surfacing assumptions, evidence, implications, and alternative viewpoints through targeted questions.
- **Prompt:** What assumption would have to be true for this to hold?
- **Best for:** single claims, threads, interviews, weakly supported assertions
- **Three Cs:** 🔍
### Cross-Cultural Competency
- **KB ID:** ct:methodology-checks:preflight:cross-cultural-competency-training
- **Type:** technique
- **Description:** Train teams to recognize cultural differences and reduce projection.
- **Prompt:** What cultural norm, translation gap, or projection could be distorting this?
- **Best for:** cross-cultural interpretation, localization, identity-sensitive text, global teams
- **Three Cs:** 🤝
### Ubuntu — Relational personhood & communal ethics
- **KB ID:** ct:thinking-lenses:systems:ubuntu
- **Type:** framework
- **Description:** A Southern African relational ethic that treats personhood as formed through community, mutual recognition, and shared responsibility. It asks how a claim changes when dignity, harm, and judgment are understood as collective rather than purely individual matters.
- **Prompt:** What changes if dignity and judgment are treated as communal rather than purely individual?
- **Best for:** relational ethics, community accountability, social repair, governance
- **Three Cs:** 🤝
### Whakapapa — Genealogical epistemology
- **KB ID:** ct:thinking-lenses:systems:whakapapa
- **Type:** framework
- **Description:** A Māori way of knowing that positions claims through genealogical relationship to ancestors, land, events, and obligations. It treats knowledge as relational, situated, and accountable rather than detached and purely propositional.
- **Prompt:** What lineages, places, or obligations make this claim intelligible?
- **Best for:** contextual reasoning, ancestry, place-based accountability, relational knowledge
- **Three Cs:** 🤝
### Sulh — Reconciliation and peaceful settlement
- **KB ID:** ct:thinking-lenses:systems:sulh
- **Type:** framework
- **Description:** An Islamic practice of settling disputes through reconciliation, repair, and peace rather than escalation alone. It asks what agreement can restore dignity, reduce harm, and preserve social bonds.
- **Prompt:** What would repair, dignity, and peace require here?
- **Best for:** conflict repair, mediation, settlement, harm reduction
- **Three Cs:** 🤝
### Shura — Consultative deliberation
- **KB ID:** ct:thinking-lenses:systems:shura
- **Type:** framework
- **Description:** An Islamic consultative principle that values collective deliberation, counsel, and accountable decision-making. It asks who should be consulted, how counsel is weighed, and how authority remains answerable to the community.
- **Prompt:** Who should be consulted, and how does counsel shape authority?
- **Best for:** deliberation, governance, leadership accountability, communal decision-making
- **Three Cs:** 🤝
### Zhengming — Rectification of Names
- **KB ID:** ct:thinking-lenses:systems:zhengming
- **Type:** framework
- **Description:** A Confucian lens holding that right naming is a moral act because language should match role, conduct, and reality. It asks whether words are precise, whether labels are honest, and whether people are acting in ways their names and offices imply.
- **Prompt:** Do the labels, roles, and words match the reality and responsibility?
- **Best for:** precision of language, role clarity, category drift, ethical naming
- **Three Cs:** 🔍
### Seven Generations Principle
- **KB ID:** ct:thinking-lenses:systems:seven-generations-principle
- **Type:** framework
- **Description:** A Haudenosaunee decision lens that evaluates choices by their effects across multiple future generations. It makes time itself part of accountability and asks whether today’s decision can still be defended seven generations from now.
- **Prompt:** Would this still be defensible seven generations from now?
- **Best for:** intergenerational stewardship, policy, ecology, long-horizon planning
- **Three Cs:** 🤝
### Nahua Nepantla — In-between reasoning
- **KB ID:** ct:thinking-lenses:systems:nepantla
- **Type:** framework
- **Description:** A Nahua concept for the in-between space where identities, worlds, or commitments overlap, strain, and transform. It is useful for reasoning about liminality, contradiction, and mixed positions without forcing premature closure.
- **Prompt:** What becomes visible only in the in-between?
- **Best for:** liminality, contradiction, hybridity, identity transitions
- **Three Cs:** 🌀
### Ayni — Reciprocity and mutual aid
- **KB ID:** ct:thinking-lenses:systems:ayni
- **Type:** framework
- **Description:** An Andean principle of reciprocal exchange in which people owe care, labor, and attention back into the web that supports them. It treats reciprocity as a living relationship rather than a transactional trade.
- **Prompt:** What must be given back, and to whom, for this relationship to stay balanced?
- **Best for:** reciprocity, mutual aid, stewardship, relational accountability
- **Three Cs:** 🤝
### Buen Vivir / Sumak Kawsay
- **KB ID:** ct:thinking-lenses:systems:buen-vivir
- **Type:** framework
- **Description:** An Andean worldview that defines flourishing as relational, ecological, and communal rather than as endless individual accumulation. It asks whether a choice supports balanced life, dignity, and collective well-being.
- **Prompt:** What does flourishing look like for the community and land together?
- **Best for:** collective flourishing, ecological balance, policy, wellbeing
- **Three Cs:** 🤝
### Hawaiian — Hāloa / Pono
- **KB ID:** ct:thinking-lenses:systems:haloa-pono
- **Type:** framework
- **Description:** A Hawaiian relational lens that treats humans, land, and community as bound in reciprocity rather than centered on extraction or control. Pono asks whether a choice leaves people and place in balance together.
- **Prompt:** What relationships, nourishment, or balance are missing if land and people are treated separately?
- **Best for:** AI ethics, land relations, intergenerational governance, reciprocity checks
- **Three Cs:** 🤝
### Cree — Wahkohtowin
- **KB ID:** ct:thinking-lenses:systems:wahkohtowin
- **Type:** framework
- **Description:** A Cree kinship lens that understands everything in relation and responsibility, not as isolated objects or hierarchies. It asks who is in the kinship circle, what language or categories are doing the framing, and who is accountable for the effects.
- **Prompt:** Who is in the kinship circle, and what accountability follows from that framing?
- **Best for:** kinship reasoning, language framing, colonial-scale AI governance, accountability audits
- **Three Cs:** 🤝
### Lakota — Wakȟáŋ
- **KB ID:** ct:thinking-lenses:systems:wakan-sacred-mystery
- **Type:** framework
- **Description:** A Lakota relational lens that treats sacred power, mystery, and non-human agency as real constraints on how people make meaning and act. It asks what ethical obligations follow from the materials, beings, and forces a system depends on.
- **Prompt:** What material, ecological, or sacred obligations vanish if this is treated as only mechanical?
- **Best for:** material provenance, non-human agency, sacred limits, AI ethics
- **Three Cs:** 🤝
### Relationality / All My Relations
- **KB ID:** ct:thinking-lenses:systems:relationality-all-my-relations
- **Type:** framework
- **Description:** Treat people, places, beings, and systems as mutually related rather than isolated objects. Ask what responsibilities and dependencies disappear when a claim is framed as purely human-centered.
- **Prompt:** What relationships, obligations, or non-human stakeholders disappear in the human-centered framing?
- **Best for:** AI ethics, ecology, place-based policy, kinship-aware analysis
- **Three Cs:** 🤝
### Reciprocity / Stewardship
- **KB ID:** ct:thinking-lenses:systems:reciprocity-stewardship
- **Type:** framework
- **Description:** Ask what mutual care, consent, and accountability a relationship requires. It resists one-way extraction by checking what is owed back to people, place, and future generations.
- **Prompt:** What mutual care, consent, or accountability is owed back here?
- **Best for:** governance, stewardship, community agreements, long-horizon decisions
- **Three Cs:** 🤝
### Ganma — Knowledge Confluence (Yolŋu)
- **KB ID:** framework:ganma-knowledge-confluence
- **Type:** framework
- **Description:** Ganma is a Yolŋu metaphor describing the meeting of fresh water and salt water, used as a way to think about knowledge confluence. Each stream keeps its identity while creating new qualities in the mixing. It is a practice of holding difference, dialogue, and shared emergence without erasing cultural integrity.
- **Prompt:** Where do two knowledge streams meet without erasing their differences?
- **Best for:** co-design, cross-tradition dialogue, education, stewardship
- **Three Cs:** 🤝
### Kaitiakitanga — Guardianship & Stewardship (Māori)
- **KB ID:** framework:kaitiakitanga-guardianship
- **Type:** framework
- **Description:** A stewardship lens grounded in Māori values that centers kinship with place and beings, protection of taonga (treasures), guardians' obligations, and long-term balance. It emphasizes mauri (life force), tikanga (correct practice), and co-governance with kaitiaki.
- **Prompt:** What guardianship, care, and intergenerational responsibility does this require?
- **Best for:** environmental stewardship, governance, community care, AI ethics
- **Three Cs:** 🤝
### Two-Eyed Seeing (Etuaptmumk): Braiding Indigenous and Western knowledge
- **KB ID:** framework:two-eyed-seeing-etuaptmumk
- **Type:** framework
- **Description:** A practice of holding multiple ways of knowing side by side without forcing one into the other. It braids Indigenous and Western knowledge through relationships, protocol, co-governance, and reciprocal benefit.
- **Prompt:** What can each knowledge system contribute without collapsing one into the other?
- **Best for:** research synthesis, policy, community partnership, mixed-method reasoning
- **Three Cs:** 🤝
### OCAP - First Nations data governance
- **KB ID:** ct:thinking-lenses:systems:ocap-first-nations-data-governance
- **Type:** framework
- **Description:** OCAP stands for Ownership, Control, Access, and Possession. It is a First Nations data governance framework for asking who owns community data, who controls the research or information process, who can access the data, and who physically or practically possesses it.
- **Prompt:** Who owns, controls, accesses, and possesses the data?
- **Best for:** First Nations data governance, research ethics, community data agreements
- **Three Cs:** 🤝
### CARE Principles - Indigenous data governance
- **KB ID:** ct:thinking-lenses:systems:care-indigenous-data-governance
- **Type:** framework
- **Description:** The CARE Principles for Indigenous Data Governance center Collective Benefit, Authority to Control, Responsibility, and Ethics. They complement technical FAIR data principles by asking whether data ecosystems serve Indigenous Peoples' rights, wellbeing, self-determination, and collective benefit.
- **Prompt:** What collective benefit, authority, responsibility, and ethics govern this data use?
- **Best for:** Indigenous data governance, FAIR-plus-CARE checks, research and evaluation
- **Three Cs:** 🤝
### Data erasure and misclassification risk
- **KB ID:** ct:methodology-checks:audit:data-erasure-misclassification-risk
- **Type:** framework
- **Description:** A methodology and power risk where people or communities become invisible because records misclassify them, collapse them into an 'Other' category, omit tribal/community affiliation, or treat missing data as evidence that no need or responsibility exists.
- **Prompt:** Who disappears because of the categories, denominators, or aggregation choices?
- **Best for:** public-health data, demographic categories, dashboards, urban Indigenous visibility
- **Three Cs:** 🔍
### Indigenous food sovereignty and health equity
- **KB ID:** ct:thinking-lenses:systems:indigenous-food-sovereignty-health-equity
- **Type:** framework
- **Description:** An Indigenous health-equity lens that treats food systems as sovereignty, culture, land, governance, and community wellbeing rather than only nutrition access or program delivery.
- **Prompt:** Who governs the food system, and who defines health and success?
- **Best for:** health equity, food systems, recovery, land and community wellbeing
- **Three Cs:** 🤝
### Kaupapa Māori Research — By/with/for Māori communities; sovereignty at the core
- **KB ID:** framework:kaupapa-maori-research-sovereignty-centered
- **Type:** framework
- **Description:** A research scaffold grounded in Kaupapa Māori that upholds rangatiratanga, follows tikanga and kawa, centers mātauranga Māori, and ensures community authority over questions, methods, data, IP, and benefits.
- **Prompt:** Who has authority, whose knowledge is centered, and what sovereignty is protected?
- **Best for:** community research, sovereignty-aware analysis, ethics review, partnership design
- **Three Cs:** 🤝
### Community Capitals
- **KB ID:** framework:community-capitals-framework-seven-capitals
- **Type:** framework
- **Description:** A structured lens from Flora and Flora with seven capitals: natural, cultural, human, social, political, financial, and built. It helps communities see assets, gaps, and investments that build purpose, resilience, and equity.
- **Prompt:** Which capital is being strengthened, depleted, or ignored?
- **Best for:** community planning, grant strategy, place-based policy, asset mapping
- **Three Cs:** 🤝
### Facione's six-skill model
- **KB ID:** glossary:faciones-core-critical-thinking-skills
- **Type:** framework
- **Description:** Defines **analysis**, **evaluation**, **inference**, **explanation**, and **self-regulation** as essential skills in critical thinking.
- **Prompt:** What is the claim, what is the evidence, and what would weaken it?
- **Best for:** research summaries, peer review, argument audits, decision memos
- **Three Cs:** 🔍
### Scenario-Based Deliberative reasoning
- **KB ID:** framework:scenario-based-deliberative
- **Type:** framework
- **Description:** Grounds the model in a concrete situation and explicitly asks it to reason deliberately before answering.
- **Prompt:** If we reason deliberately from the concrete situation, what assumptions and actions matter most?
- **Best for:** coaching, policy-sensitive prompts, decision support, edge cases
- **Three Cs:** 🔍
### Argument Mapping
- **KB ID:** framework:argument-mapping
- **Type:** strategy
- **Description:** Argument mapping lays out claims, supporting premises, objections, and rebuttals as a tree. It surfaces hidden assumptions, clarifies logical structure, and reveals weaknesses. Toulmin elements (grounds, warrant, backing, qualifier, rebuttal) can be layered in for depth.
- **Prompt:** What is the claim, the reasons, the objections, and the rejoinders?
- **Best for:** debates, essays, strategy memos, legal or policy arguments
- **Three Cs:** 🔍
### Pre-mortem
- **KB ID:** framework:pre-mortem-future-failure-safeguards
- **Type:** strategy
- **Description:** A pre-mortem is a prospective hindsight exercise: you assume it’s the future and the plan has failed. You list plausible causes, cluster and score them, then design safeguards and contingencies. The aim is not pessimism; it’s disciplined imagination to reduce avoidable failure.
- **Prompt:** If this fails, what will have caused it?
- **Best for:** plans, roadmaps, launches, high-risk decisions
- **Three Cs:** 🌀
## Claude-native

### [Claude-native] Long-term / intergenerational
- **KB ID:** [Claude-native]
- **Type:** lens
- **Description:** Zooms out from immediate wins to second- and third-order effects over time. Use it when a choice may trade present convenience for future burden, resilience, or trust.
- **Prompt:** What changes if we optimize for people one, five, and twenty years from now?
- **Best for:** strategy, climate, infrastructure, family systems, policy
- **Three Cs:** 🌀
### [Claude-native] Economic / incentive
- **KB ID:** [Claude-native]
- **Type:** lens
- **Description:** Asks how incentives, costs, and benefits shape behavior behind the stated position. Use it when apparent preferences may be responses to rewards, penalties, or risk.
- **Prompt:** Who bears the cost, who captures the benefit, and what incentives are in play?
- **Best for:** organizational decisions, policy, business models, behavior change
- **Three Cs:** 🔍
### [Claude-native] Historical precedent
- **KB ID:** [Claude-native]
- **Type:** lens
- **Description:** Checks whether the current case really resembles a prior case and what transferred across contexts. Use it when arguments rely on analogy, precedent, or 'we've seen this before' reasoning.
- **Prompt:** What similar case has already happened, and what really transferred?
- **Best for:** history, policy, legal analogy, strategy, risk review
- **Three Cs:** 🔍
### [Claude-native] Power & stakeholder mapping
- **KB ID:** [Claude-native]
- **Type:** lens
- **Description:** Identifies who has decision power, who bears consequences, and who is missing from the frame. Use it when the text hides asymmetries, missing voices, or governance gaps.
- **Prompt:** Who has power, who is affected, and who is missing from the table?
- **Best for:** community decisions, negotiations, governance, team conflicts
- **Three Cs:** 🤝
