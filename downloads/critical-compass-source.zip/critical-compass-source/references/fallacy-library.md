# Fallacy Library

Offline claim-interrogation reference. Live KB fallacies appear first; supplemental entries are clearly marked so Claude does not confuse them with live corpus data.

## Contents

- Live KB
- Supplemental

## Live KB

### False dilemma
- **Aliases:** False dilemma, either-or fallacy, false dichotomy, false dilemma, false-dilemma
- **Definition:** Presenting two options as if they are the only possible choices.
- **Signal:** Either we do this now or everything will fail.
- **Example:** Either we do this now or everything will fail.
- **Steelman risk:** Real decisions can still be binary once the constraints are explicit.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:false-dilemma
### Ad hominem
- **Aliases:** Ad hominem, ad hominem, ad-hominem, personal attack
- **Definition:** Attacking a person instead of addressing the claim.
- **Signal:** Ignore the argument because the speaker is unlikeable.
- **Example:** Ignore the argument because the speaker is unlikeable.
- **Steelman risk:** A person's credibility can matter if the claim depends on expertise or conflicts of interest.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:ad-hominem
### Straw man
- **Aliases:** Straw man, straw man, straw-man, strawman
- **Definition:** Misrepresenting an opposing view so it is easier to attack.
- **Signal:** They want safety, so they must want no progress.
- **Example:** They want safety, so they must want no progress.
- **Steelman risk:** People sometimes compress a view before engaging it; check the strongest version first.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:straw-man
### Slippery slope
- **Aliases:** Slippery slope, slippery slope, slippery-slope
- **Definition:** Arguing that one step will inevitably trigger a long chain of worsening outcomes without support.
- **Signal:** If we allow this exception, everything will collapse.
- **Example:** If we allow this exception, everything will collapse.
- **Steelman risk:** Some chains really do have plausible escalation; ask for mechanism and probability at each step.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:slippery-slope
### Appeal to authority
- **Aliases:** Appeal to authority, appeal to authority, appeal-to-authority, authority bias
- **Definition:** Treating an authority as decisive when the supporting evidence is not shown.
- **Signal:** It must be true because an expert said so.
- **Example:** It must be true because an expert said so.
- **Steelman risk:** Expert testimony is valid when the authority is in-scope and the evidence is transparent.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:appeal-to-authority
### Hasty generalization
- **Aliases:** Hasty generalization, generalization, hasty generalization, hasty-generalization
- **Definition:** Drawing a broad conclusion from too little or too narrow evidence.
- **Signal:** One bad meeting means the whole team is incompetent.
- **Example:** One bad meeting means the whole team is incompetent.
- **Steelman risk:** A small sample can still be suggestive when it is representative and properly bounded.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:hasty-generalization
### Circular reasoning
- **Aliases:** Circular Reasoning, begging the question, circular-reasoning
- **Definition:** A loop where the conclusion is assumed in a premise; persuasive rhetorically but invalid logically.
- **Signal:** A loop where the conclusion is assumed in a premise; persuasive rhetorically
- **Example:** A loop where the conclusion is assumed in a premise; persuasive rhetorically but invalid logically.
- **Steelman risk:** A conclusion can appear circular only because the premises were paraphrased too loosely.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** glossary:circular-reasoning
### Bandwagon
- **Aliases:** Bandwagon, appeal to popularity, bandwagon
- **Definition:** Assuming a claim is right because many people believe it.
- **Signal:** Everyone is doing it, so it must be right.
- **Example:** Everyone is doing it, so it must be right.
- **Steelman risk:** Popularity can be a useful proxy when the crowd has relevant expertise or evidence.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:bandwagon
### Causal overreach
- **Aliases:** Causal overreach, causal overreach, causal-overreach, false cause, post hoc
- **Definition:** Treating correlation, sequence, or weak evidence as proof of cause.
- **Signal:** The update happened before the dip, so the update caused it.
- **Example:** The update happened before the dip, so the update caused it.
- **Steelman risk:** Temporal order and correlation can sometimes point to cause when mechanism is strong.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:causal-overreach
### Unsupported certainty
- **Aliases:** Unsupported certainty, certainty inflation, unsupported certainty, unsupported-certainty
- **Definition:** Stating a claim with more certainty than the evidence supports.
- **Signal:** This will definitely work.
- **Example:** This will definitely work.
- **Steelman risk:** Confidence can be appropriate when the evidence base is unusually strong and direct.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:unsupported-certainty
### Argument from ignorance
- **Aliases:** Argument from ignorance, argument from ignorance, argument-from-ignorance
- **Definition:** Treating lack of evidence against a claim as evidence for it.
- **Signal:** No one has disproved it, so it must be true.
- **Example:** No one has disproved it, so it must be true.
- **Steelman risk:** Lack of evidence against a claim is not always decisive when evidence is genuinely hard to obtain.
- **Three Cs:** 🔍
- **Source:** Live KB
- **KB ID:** ct:fallacies:informal:argument-from-ignorance
## Supplemental

### Red herring
- **Aliases:** distraction
- **Definition:** Introducing a distracting side issue that does not address the main claim.
- **Signal:** The text shifts to a side issue instead of the original claim.
- **Example:** We should not talk about emissions because the building project is already behind schedule.
- **Steelman risk:** A side issue can be relevant if it actually changes the conclusion.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
### Appeal to emotion
- **Aliases:** emotion appeal
- **Definition:** Using emotion as the main support for a conclusion instead of evidence.
- **Signal:** The argument tries to make the reader feel, not verify.
- **Example:** You have to support this policy because imagine how heartbreaking failure would be.
- **Steelman risk:** Emotion can indicate stakes, values, or harms even if it is not proof by itself.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
### Appeal to nature
- **Aliases:** —
- **Definition:** Treating something as good because it is natural, or bad because it is unnatural.
- **Signal:** The text treats 'natural' as automatically better or safer.
- **Example:** This option must be best because it is natural.
- **Steelman risk:** Nature can be a relevant clue when mechanism, safety, or context is also shown.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
### Loaded question
- **Aliases:** complex question
- **Definition:** Asking a question that smuggles in an unproven assumption.
- **Signal:** The question presupposes the very thing under dispute.
- **Example:** Why did you stop ignoring the evidence?
- **Steelman risk:** The presupposition may already have been established elsewhere in the exchange.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
### Modus tollens abuse
- **Aliases:** failed prediction fallacy
- **Definition:** Treating one failed prediction as if it fully falsified the broader theory.
- **Signal:** One missed prediction is treated as total disproof.
- **Example:** The prediction failed, so the whole model is useless.
- **Steelman risk:** A failed prediction may reveal a bad premise, boundary condition, or measurement issue rather than a dead theory.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
### Survivorship bias
- **Aliases:** survivorship reasoning
- **Definition:** Overweighting the cases that survived and missing the cases that failed.
- **Signal:** The text only talks about winners or survivors.
- **Example:** We should copy this strategy because every successful founder used it.
- **Steelman risk:** Survivor data can be appropriate when survivors are the exact population of interest.
- **Three Cs:** 🔍
- **Source:** Supplemental
- **KB ID:** Supplemental
