# Schema

- `normalized-record.schema.yaml`
- `retrieval-index.schema.yaml`
