# Client-Specific Host Hints v1.0.0

These are short hints for host AIs. They improve discoverability without adding client-specific runtime behavior.

## Claude

Use Critical Compass when the user asks to pressure-test text before using it: audit a draft, prepare a report, verify factual claims, compare reasoning frames, stress-test a claim, or decide what to trust, revise, verify, or reframe.

Start with `get_started` for new users, installation/onboarding, “what do I do first?”, or first audit setup. Use `critical_compass_overview` for capability lookup, report contracts, output requirements, and existing users choosing among tools. If the user pastes text and only says “use Critical Compass,” first clarify goal, intended audience, and whether they want quick scan, normal full audit, or advanced panel review. When `PAUSE_REQUIRED=true` or `human_loop_host_action.must_pause=true`, treat `human_loop_host_action` as a required interaction contract: render `questions_for_user` through Claude's native `Ask_User_Input_V0` / `ask_user_input widget` using `single-select`, `multi-select`, or `rank-priority` question types before continuing. Plain-text user questions are invalid when the widget is available; compact inline fallback is allowed only when the widget is unavailable. Critical Compass cannot force Claude API `tool_choice`; it exposes `widget_compliance_check`, `tool_compliance_signal`, and `repair_instruction` so the host can route and repair. Audience-fit, framing openness, stakeholder fit, missing voices, and persuasion risk are normal Critical Compass use cases, not mismatch cases. Use `list_agent_personas` before advanced agent mode when users ask what analyst roles are available. Agentic panel review requires explicit opt-in such as `advanced panel review`, `agentic panel review`, `multi-perspective panel`, or `run the agent audit`; generic words like agent, agency, city council, panel, committee, or stakeholders are not enough by themselves. For complex or advanced reports, use `report_ready_payload`, call `validate_report_payload`, then call `generate_audit_report` only after validation passes. If the user asks for a first-share report or stakeholder summary but does not explicitly request the full PDF, prefer `generate_audit_report(report_depth="readiness_card")` as the compact report default; reserve `report_depth="full"` for explicit full-analysis requests. Use the specific tool only after the user provides text, a claim, source path, report data, or saved result IDs. If JTBD or another adjacent lens could help, offer it only after the core Critical Compass audit, never as the initial replacement path.

## Codex

When editing this repo, keep MCP surfaces synchronized: README, `critical_compass_overview`, scaffold manifest, tool inventory, server instructions, docs, tests, and validators.

For Pressure-Test Readiness work, start with `pressure-test-readiness-kit.md` and `support/evals/atlas_pressure_test_scenarios.json`. Ship scenario-backed output improvements before proposing new tools.

## Cursor-Style Coding Hosts

Before code changes, inspect the nearest scaffold/resource/test pattern. Prefer updating existing resources over creating parallel docs.

When adding a public tool or changing a public tool description, update the tool trigger matrix and surface sync checklist in the same slice.

## General Host Rule

If the user is new or asks where to begin, call `get_started`. If text is present but no lane is chosen, ask for goal, intended audience, and quick/full/advanced depth before routing; default to `audit_text` unless the user explicitly opts into advanced panel review. If unsure which capability to inspect for an existing user, call `critical_compass_overview` and keep the user-facing goal plain: what should be trusted, revised, verified, or reframed before use?

If a KB search comes back empty, recover before giving up: narrow the terms, use category filters, and try adjacent canonical concepts. No result means no result for that query, not proof that the concept is absent.

## Anti-Hints

- Do not call `factcheck_lookup` as proof that a claim is false.
- Do not call external providers just because a claim is check-worthy.
- Do not save blind-spot reminders without explicit consent.
- Do not treat `quick_scan` as a full audit.
- Do not present `compare_audit_results` score deltas as proof of improvement unless comparability is `direct`.
- Do not claim real subagents were spawned when the host used sequential fallback.
