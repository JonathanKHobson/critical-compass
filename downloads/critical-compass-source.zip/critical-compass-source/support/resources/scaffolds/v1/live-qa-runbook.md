# Live MCP QA Runbook v1.0.0

Use this when Codex or Claude needs to confirm the attached Critical Compass MCP is fresh and functioning.

## Freshness Gate

Call `critical_compass_overview` with these topics from the attached MCP:

- `overview`
- `reports`
- `app_ui`

Pass only if the live responses mention `generate_audit_artifact_viewer`, the report-to-viewer flow, and workflow resources. If they do not, the attached MCP is stale. Restart or rebind the MCP client, then rerun the same calls before debugging report generation.

## Repo-Local QA Script

Run `python3 scripts/live_mcp_codex_qa.py` from the repo. It validates repo-local overview payloads, scaffold resources, and the smoke report manifest. It does not replace the attached MCP freshness check.

## Smoke Path

After freshness passes, run:

1. `python3 scripts/run_beta_audit_calibration.py`
2. `python3 scripts/validate_audit_report_renderer.py`
3. `python3 scripts/smoke_36_questions_report.py`

The smoke is healthy when report QA is non-blocked, page images exist, `manifest_path` exists, and `viewer_path` points to a local HTML file.

## Failure Handling

- Stale overview: restart/rebind the MCP client before testing further.
- Missing viewer path: inspect `generate_audit_report` manifest writing and viewer generation.
- Blocked report: inspect `missing_report_fields` and `what_to_resubmit`; do not bypass with placeholders unless the user explicitly requested a draft.
- OCR failure: run `prepare_audit_source` directly and check dependency/status warnings before auditing. Expected local providers are Apple Vision on macOS or Tesseract via `pytesseract`/`Pillow` when the `tesseract` binary is installed; otherwise the safe status is `needs_ocr_dependency`.
