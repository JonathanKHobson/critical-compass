# Pressure-Test Readiness Kit v1.0.0

Use this kit when improving or evaluating Critical Compass output for public users and nonprofit teams. It is a scaffold resource, not a new tool, live archive lookup, or external fact-checking path.

## Source Boundary

Earlier planning analysis informed this kit at build time. At runtime, Critical Compass should work from its own tools, local KB, scaffold resources, and host reasoning. Do not require external archives, browser retrieval, provider APIs, or any new MCP surface to use this kit.

## Scenario Pack

The machine-readable fixture is `support/evals/atlas_pressure_test_scenarios.json`.

It covers:

- Advocacy copy: missing voices, persuasion risk, false consensus, stakeholder burden.
- Public statement: vague responsibility, accountability gaps, trust repair.
- Grant impact claim: causal overreach, missing denominator, metric bias, external validity.
- Article review: authority laundering, source gaps, check-worthy factual claims.
- AI-generated summary: hallucination confidence, provenance gaps, sycophancy risk, evaluation bias.
- Research-adjacent summary: sampling, measurement validity, external validity, spin risk.

## Decision Contract

Every pressure-test output should help the user choose one primary next action:

| Action | Use When | Plain-Language Shape |
|---|---|---|
| `Trust` | The text is bounded, adequately supported, and the remaining caveats are visible. | "Use this, but keep the visible caveats attached." |
| `Revise` | The text has useful intent but wording, framing, accountability, or missing voices could mislead. | "Keep the purpose, change the claim or frame." |
| `Verify` | A factual or empirical claim is load-bearing and worth checking before use. | "Worth verifying, not false." |
| `Reframe` | The claim may be useful only under narrower scope, different audience, or alternate framing. | "The idea may hold in a smaller or different frame." |

## Bias Mitigation Next-Step Verbs

Prefer compact action verbs over generic advice:

| Verb | Use For | Example Move |
|---|---|---|
| check | Load-bearing factual or numeric claims. | Check the denominator, baseline, source date, and comparison group. |
| compare | Narrow frames or selected examples. | Compare the strongest alternative explanation before publishing. |
| ask | Missing voices or authority gaps. | Ask who is affected, who is quoted, and who bears the cost. |
| gather | Thin evidence or anecdotal support. | Gather one primary source and one affected-community perspective. |
| disclose | Standpoint, funding, AI mediation, or limits. | Disclose source, method, author position, and uncertainty. |
| bound | Overgeneralized or causal claims. | Bound the claim to the visible sample, context, and time period. |
| test | Confident recommendation or decision. | Name the evidence that would change the decision. |
| revise | Useful but risky wording. | Revise urgency, certainty, or accountability language without losing the point. |

## KB No-Result Recovery

If `search_knowledge_base` returns no results, do not conclude the KB is empty. Try narrower, canonical, or adjacent terms first.

| Broad Query | Try Narrower Terms |
|---|---|
| memory bias | false memory, misinformation effect, source monitoring, recall bias, availability heuristic |
| AI bias | automation bias, algorithmic bias, hallucination confidence, sycophancy, dataset shift |
| social bias | in-group bias, false consensus effect, dehumanization bias, bandwagon effect |
| research evidence bias | p-hacking, HARKing, publication bias, WEIRD bias, attrition bias, nonresponse bias |

Use category filters when appropriate: `biases`, `methodology-checks`, `thinking-lenses`, or `reasoning-frameworks`.

## AI/Data Audit Language

For `text_type="ai_generated"`, name risks as risks visible in the text, not claims about the model's hidden internals.

Good wording:

- "This has hallucination-confidence risk because it states proof without showing sources."
- "This has provenance-gap risk because the summary does not show which source supports which claim."
- "This may have evaluation-bias risk if benchmark or metric claims are treated as real-world performance."
- "No retrieval was performed; these are check prompts, not fact-check results."

Avoid:

- "The model hallucinated" unless external evidence proves it.
- "The AI is biased" without naming the visible cue.
- "This is false" when the issue is source coverage or verification priority.

## Routing Cheat Sheet

| User Need | Route |
|---|---|
| Pressure-test a draft, claim, article, report, or AI summary before use. | Critical Compass. |
| Search broad concepts or source vocabulary for planning evidence. | Use project planning evidence, not a runtime dependency. |
| Improve prompt/task wording or generate task templates. | Prompt Compass. |
| Do research synthesis, literature-style evidence review, or corpus-backed analysis. | Research Compass. |
| Teach a lightweight practice activity after an audit. | Existing Critical Compass next steps first; defer standalone activity tool. |

## Ethical Dilemma Teaching Examples

Use dilemmas to surface competing values and next questions, not to decide the moral answer.

- Privacy vs utility: What data is necessary, who consents, and who benefits?
- Transparency vs proprietary interests: What must be disclosed for public trust, even if full details stay private?
- AI responsibility: Who owns correction when AI-mediated text misleads?
- Privacy vs security: What risk is reduced, what freedom is limited, and who decides?
- Standard mismatch: Whose privacy, evidence, or accountability standard is treated as default?

## Current Output Audit

The machine-readable Slice 2 audit record is `support/evals/atlas_pressure_test_output_audit.json`.

Use it to check whether current Critical Compass outputs are doing useful pressure-test work before adding new tools. A scenario passes when the output:

- Chooses one decision action: `Trust`, `Revise`, `Verify`, or `Reframe`.
- Explains the decision in plain language.
- Names the load-bearing concern without treating check-worthy as false.
- Gives a concrete next action tied to the concern.
- Preserves what is still useful, fair, or promising in the text.

Known watchpoints:

| Scenario | Pass If The Output Does This |
|---|---|
| Advocacy copy | Recommends `Revise` or `Reframe`, names missing voices, and asks who is affected or burdened. |
| Public statement | Recommends `Revise`, separates responsibility from blame, and asks for concrete accountability. |
| Grant impact claim | Recommends `Verify` or `Revise`, asks for denominator, baseline, comparison group, and metric definition. |
| Article review | Recommends `Verify`, treats authority as a cue rather than proof, and suggests source classes. |
| AI-generated summary | Recommends `Verify` or `Reframe`, names provenance-gap risk, and says no retrieval was performed. |
| Research-adjacent summary | Recommends `Verify` or `Reframe`, surfaces validity concerns, and bounds sample or setting. |

## Curated Gap-Fill

The curated build-time risk pack is bundled locally for maintainers and release validation. It is not a runtime dependency and is not a live retrieval source.

It adds only high-value, portable concepts that Critical Compass needs for pressure-test readiness:

- AI/data risks: hallucination-confidence risk, provenance-gap risk, sycophancy risk, metric or benchmark bias, dataset shift, evaluation bias, representation bias.
- Research/evidence risks: citation bias, spin bias, outcome reporting bias, sponsorship bias, recall bias, source monitoring error.

Rules:

- Treat these as visible risk labels and teaching aids, not truth verdicts.
- Do not import external source archives wholesale.
- Do not import persona-like records as biases.
- Do not import broad framework records under the bias category.
- Keep provenance visible in the pack and offline exports.

## Persona Seeds And Practice Pilot

Persona seeds are analytical standpoints, not identity impersonations. Use them to ask better questions from a bounded standpoint:

| Seed | Use For | Guardrail |
|---|---|---|
| Grant reviewer / evidence steward | Impact claims, outcome metrics, funder-facing copy. | Ask for evidence standards and decision consequences; do not pretend to represent a funder. |
| Affected-community reviewer | Public statements, advocacy copy, policy claims. | Ask what affected people might need to see; do not claim lived authority. |
| AI/data auditor | AI summaries, benchmark claims, data-driven recommendations. | Name visible data risks; do not infer hidden model internals. |
| Public accountability editor | Statements after harm, corrections, or controversy. | Separate repair, responsibility, and defensiveness. |
| Accessibility reviewer | Public-facing or service-delivery text. | Ask what barriers or excluded users may be missing; do not speak for disabled communities. |

Optional practice activities should remain inside existing outputs unless the Phase 5 gate is met:

- Claim-Support-Question: choose one claim, name its support, then ask one unresolved question.
- 3-2-1 Bridge: name three visible claims, two assumptions, and one changed view.
- What Makes You Say That: point to the exact words that support the inference.
- See-Think-Wonder: separate observation, interpretation, and curiosity.
- Circles of Action: identify what the user can control, influence, or only monitor.

## Practice Activity Tool Gate

The gate record is `support/evals/practice_activity_tool_gate.json`.

Current decision: defer a standalone Practice Activity Tool. The roadmap is complete by keeping practice as an optional suggestion inside existing outputs, not by adding a new public tool.

Reconsider only when:

- Scenario outputs consistently pass the decision-usefulness checks.
- Users repeatedly ask for teaching follow-ups separate from audits.
- The activity can be evaluated without novelty, engagement, or roleplay as the main success measure.
- The tool can stay local-first, no-network, and free of external archive runtime dependencies.

## Quality Gate

Before shipping a roadmap item from this kit, confirm:

- It helps the user decide what to trust, revise, verify, or reframe.
- It uses existing Critical Compass surfaces first.
- It does not require live external archives, web search, or provider retrieval.
- It keeps check-worthy separate from false.
- It preserves provenance, uncertainty, dissent, and cultural humility.
