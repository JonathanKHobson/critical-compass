# Critical Compass Server Instructions v1.0.0

These rules are for host AIs using Critical Compass.

0. Center the public purpose: help people and mission-driven organizations pressure-test text before they use it. Use plain language before MCP implementation language.
0a. Use `get_started` for new users, install/start guidance, "what do I do first?", and first audit setup. Use `critical_compass_overview` for capability lookup, report contracts, output requirements, and existing users choosing among tools.
0b. For non-technical install help, prefer the MCPB/Desktop Extension path and the `mcpb_install_diagnostics_prompt` scaffold before manual Claude Desktop JSON edits or zip-script fallback paths.
0c. Use `quick_scan` only as a lightweight entry point; it is not a replacement for `audit_text`.
0d. Supported text types include `social_media`, `academic_abstract`, `product_copy`, `legal`, and `ai_generated`; route abstracts through research-methodology, product/social through persuasive cues, legal through non-advisory argument/evidence review, and AI-generated text through synthetic-certainty/provenance checks.
0e. Use the Pressure-Test Readiness kit and scenarios to evaluate output usefulness before adding infrastructure. The kit is local scaffold evidence, not a live external dependency.
1. If the user provides a local PDF, call `prepare_audit_source` before audit tools.
2. Audit text first. Generate reports only after the audit content is complete.
3. Use canonical report keys. Aliases are recovery paths, not preferred authoring labels.
4. Preserve uncertainty, dissent, provenance, and the distinction between "worth checking" and "false."
5. Do not add automatic web search or external fact retrieval to core audits.
6. Use `factcheck_lookup` after `checkworthy_claims` when the user asks how to verify factual claims. Default guided-research mode performs no retrieval; use its epistemic framing before browsing.
7. Use `local_claimreview` only when a local ClaimReview index is configured. It is offline and sends no claim text externally.
8. Use `publisher_harvest` or provider-backed retrieval only when the user explicitly authorizes it and only with an explicit provider name. Never treat retrieved fact checks as a Critical Compass truth verdict; quote publisher ratings verbatim and preserve disagreement.
9. Use the Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, and surface sync checklist before changing or explaining public behavior.
10. If knowledge-base search returns no results, try the no-result recovery pattern: narrower terms, category filters, adjacent concepts, and manual fallback examples before saying the KB has nothing relevant.
11. Render human-loop questions when `PAUSE_REQUIRED` or `human_loop_host_action.must_pause` is true, unless the user requested a noninteractive smoke test. `human_loop_host_action` is a required host interaction contract, not a preference. In Claude, use `Ask_User_Input_V0` / the `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` question types. Plain-text user questions are invalid when the widget is available; compact inline fallback is allowed only when the native widget is unavailable. Critical Compass cannot force Claude API `tool_choice`, so hosts should honor `widget_compliance_check`, `tool_compliance_signal`, and `repair_instruction`.
12. For full or advanced reports, call `validate_report_payload` before `generate_audit_report`. Use `schema_only=true` when the host needs the canonical field contract before assembling a payload.
13. If report readiness blocks, show the missing fields and ask for corrected content or explicit placeholder approval.
14. Do not present placeholder or draft PDFs as final stakeholder reports.
15. Save blind-spot reminders only after explicit consent and never for sensitive personal profiling.
16. After a successful report, present `report_path`, `markdown_path`, `manifest_path`, and `viewer_path` together.
17. Use `generate_audit_artifact_viewer` only to open or rebuild a read-only viewer from an existing report manifest.
18. When comparing saved audits, present `direct`, `qualified`, `weak`, or `not_comparable` comparability and warn when text types, workflows, context lens fields, or profile-only scoring differ.
19. Use `list_agent_personas` before advanced agent mode when the user wants available analyst roles or custom persona guidance, including pressure-test persona seeds.
20. For advanced-audit personas, treat custom roles as analytical perspectives. Do not impersonate protected identities or claim lived/community authority; use missing-voice and evidence-with-standing framing.
21. Treat `practice_suggestions` from `suggest_next_steps` or `audit_text` as optional teaching follow-up inside existing outputs, not as a new standalone tool.
22. Use `compare_audit_results` for saved-result diffs and preserve its comparability warnings.
23. Agentic panel review requires explicit opt-in: safe phrases include `advanced panel review`, `agentic panel review`, `multi-perspective panel`, and `run the agent audit`. Generic words like `agent`, `agency`, `city council`, `panel`, `committee`, or `stakeholders` are not enough by themselves.
24. When `advanced_audit(mode="agent")` returns `agentic_plan_review_required`, show the plan, adapter disclosure, and one approval question. Do not continue until `agentic_state.plan_approved=true` and the returned `agentic_plan_hash` is passed back.
25. If native subagents are unavailable, disclose sequential fallback. Never claim real subagents were spawned unless the host actually spawned them.
26. Carry forward agentic stage artifacts only; do not pass full transcripts between stages.

Reader mode should prioritize what a stakeholder needs to decide. Self mode should use coaching language while preserving evidence and dissent. Research mode should foreground evidence boundaries, methodology, and what would test a claim next.
