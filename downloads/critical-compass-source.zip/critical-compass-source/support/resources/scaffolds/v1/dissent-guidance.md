# Dissent Compression Guidance v1.0.0

Preserve dissent as evidence about uncertainty. Do not flatten disagreement into consensus just to make the report sound cleaner.

## Expand Dissent When

- Agents disagree about the main verdict.
- Confidence differs materially across lenses.
- A power, harm, or missing-voice concern conflicts with a methodology finding.
- The user or stakeholder must decide what evidence would change the conclusion.

## Compress Dissent When

- Agents agree on the main finding and differ only in wording.
- The disagreement is already captured by the key tension.
- The report mode is overview and the dissent does not change the next action.

## Minimum Ledger Fields

Each dissent entry should keep:

- agent name
- top finding
- strongest disagreement
- confidence
- what would change its mind
- provenance or source stage

## Saved Pattern Guidance

Recurring disagreement patterns may be saved through `save_entity_pattern` with `entity_type="disagreement_pattern"`. Keep the note about the disagreement shape, not a profile of the user or agent.
