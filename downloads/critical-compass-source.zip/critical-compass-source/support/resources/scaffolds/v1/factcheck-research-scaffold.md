# Fact-Check Research Scaffold v1.0.0

Use this scaffold when the user asks to verify factual `checkworthy_claims` and the host AI has browsing or research tools.

## Workflow

1. Normalize the claim into one checkable sentence.
2. Classify the claim kind: empirical, statistical, historical, causal, interpretive, policy, or worldview.
3. Run epistemic framing before search:
   - domain
   - domain sensitivity
   - known Western-bias history
   - consensus age
   - knowledge communities with standing
4. Search in this order:
   - existing fact checks
   - primary or official sources
   - reputable secondary sources
   - regional, local-language, or affected-community sources when domain sensitivity is medium or high
5. Fill an evidence trail. Do not invent rows.
6. Separate truth disputes from framing disputes.
7. State coverage limits plainly.

## Required Cautions

- Check-worthy means worth verifying, not false.
- No match is not proof that a claim is true or false.
- Missing non-Western or local coverage is a coverage limit, not proof those perspectives do not exist.
- Do not create false balance for settled empirical claims.
- Do not send private or sensitive claims externally without explicit user authorization.

## Output Shape

```json
{
  "claim_id": "claim-1",
  "normalized_claim": "One clear factual sentence.",
  "epistemic_framing": {
    "domain": "animal_communication",
    "claim_kind": "empirical",
    "domain_sensitivity": "high",
    "known_western_bias_history": "documented",
    "consensus_age": "emerging_or_contested",
    "knowledge_communities_with_standing": ["ethologists", "long-term field observers", "Indigenous/local ecological knowledge holders"],
    "recommended_source_emphasis": ["domain experts", "local or affected-community sources", "primary evidence"],
    "framing_notes": []
  },
  "evidence_trail": [],
  "plurality_review": {
    "regions_represented": [],
    "languages_represented": [],
    "knowledge_systems_present": [],
    "missing_perspectives": [],
    "dominant_bloc_risk": "unknown",
    "framing_gap": "unknown",
    "notes": []
  }
}
```
