# Tool Trigger Matrix v1.0.0

Use this matrix when a host AI needs to decide whether to call a Critical Compass tool.

Tier rule: try Tier 1 front-door/source tools first (`get_started`, `quick_scan`, `audit_text`, `claim_stress_test`, `prepare_audit_source`, `generate_audit_report`), then Tier 2 workflow/KB/report-support tools, then Tier 3 compatibility or persistence-overlay tools only when explicitly needed.

| Tool Or Surface | Call When | Do Not Call When | Ask First | Output Label |
|---|---|---|---|---|
| `get_started` | A new user needs first-session onboarding, install/start guidance, or a first audit path. | The user needs capability lookup, report contracts, output requirements, or already knows the workflow. | If text is present but no lane is chosen, ask for goal, intended audience, and whether the user wants quick, full, or advanced review. | `get_started_ready` |
| `critical_compass_overview` | The user needs routing, discovery, examples, report contracts, output requirements, or current Critical Compass capabilities. | The user has already supplied enough data for a narrower tool. | Ask what they want to inspect only if the goal is unclear after overview. | `overview_ready` |
| `prepare_audit_source` | The user provides a local PDF/source path for auditing. | The user already supplied extracted text or the source is not local. | Ask before OCR if the source is sensitive and OCR output may persist locally. Apple Vision is preferred on macOS; local Tesseract OCR is the cross-platform fallback when installed. | `source_preflight` |
| `quick_scan` | The user wants a lightweight gut-check before deciding on a full audit. | The user needs argument maps, check-worthy claims, report readiness, or full bias detail. | Ask for `audit_text` only after the quick scan suggests a full pass. | `quick_scan_ready` |
| `audit_text` | The user provides text for the normal full Critical Compass audit, including audience effectiveness, framing openness, stakeholder fit, missing voices, or persuasion risk. | The user only asks for a single claim card, pure rewrite, or clearly needs a staged multi-perspective review. | If the user just says “use Critical Compass” or pastes text with no lane, ask goal, intended audience, and whether they want quick, full, or advanced review before running. | `audit_result` |
| `list_agent_personas` | The user wants to choose or customize advanced-audit analyst roles. | The user wants completed analysis now and personas are already defined. | Ask which custom role to include only if the user’s requested role is ambiguous. | `agent_personas_ready` |
| `advanced_audit` | The user explicitly asks for `advanced panel review`, `agentic panel review`, `multi-perspective panel`, `run the agent audit`, or another clearly staged multi-perspective review with dissent preserved. | A normal full audit is enough, the user only said “use Critical Compass,” or words like agent, agency, city council, panel, committee, or stakeholders appear without panel-review intent. | If the user only says “advanced audit” or “use Critical Compass,” clarify goal, intended audience, and whether they want normal full audit or advanced panel review before choosing a flow. | `advanced_audit_scaffold` or `agentic_plan_review_required` |
| `synthesize_audit_verdict` | Independent advanced-audit analyses, tensions, and debate are complete. | The advanced-audit stages have not been run or are missing. | Ask reflection prompts when guided mode requires it. | `audit_synthesis` |
| `claim_stress_test` | The user gives one claim and wants a compact pressure test. | The user needs a full text audit or report. | Ask for context only if the claim is ambiguous. | `claim_stress_test_card` |
| `factcheck_lookup` | Factual `checkworthy_claims` need verification scaffolding. | Claims are interpretive, normative, emotional, policy-only, or sensitive/private without explicit override. | Ask before any external lookup; default guided research performs no retrieval. | `guided_research` or provider-specific retrieval label |
| `validate_report_payload` | Complex, full, or advanced report payloads need dry-run schema/readiness/renderer diagnostics, or the host needs `schema_only=true` before assembly. | The user only needs a quick chat answer and no report artifact. | Ask whether placeholders are draft-only if the payload is intentionally incomplete. | `report_validation` |
| `generate_audit_report` | Audit data has already passed validation and report-critical fields are populated. | Missing fields remain and placeholders were not explicitly authorized. | Ask whether to resubmit missing data or allow a draft placeholder report. | `report_manifest` |
| `generate_audit_artifact_viewer` | A completed report manifest should be opened or rebuilt as a local viewer. | There is no generated manifest. | Ask for the manifest path if absent. | `artifact_viewer` |
| `save_audit_result` / `save_audit_progress` | The user wants persistence or resumable progress. | The user only wants a one-off audit. | Ask before saving user-provided audit state. | `saved_audit` |
| `list_audit_results` / `get_pattern_summary` / `compare_audit_results` | The user asks to browse saved audits, review recurring patterns, or compare two final saved results. | The user has not saved anything yet. | Ask for result IDs only when comparing and not supplied. | `saved_audit_review` |
| `save_blind_spot_reminder` | The user explicitly consents to a non-sensitive reminder. | The reminder is sensitive, profiling-like, or inferred without consent. | Always ask for explicit consent. | `blind_spot_reminder` |

## Global Trigger Rules

- Prefer the narrowest tool that satisfies the user goal.
- If text is present and no lane is chosen, ask for goal, intended audience, and quick/full/advanced depth before selecting a tool.
- For public/nonprofit pressure-test readiness work, use the local scenario kit to evaluate whether existing outputs help users trust, revise, verify, or reframe before proposing new tools.
- Agentic panel review is explicit opt-in only; when unclear, default to `audit_text` or ask one plain lane question.
- Audience effectiveness, framing openness, stakeholder fit, missing voices, and persuasion risk are normal Critical Compass audit questions, not mismatch cases.
- Offer JTBD or other adjacent frameworks only after a core Critical Compass audit if they clearly add value.
- Do not use scaffolds as evidence that retrieval happened.
- Do not call external providers by default.
- If knowledge-base search returns no results, try narrower terms, category filters, and adjacent concepts before concluding nothing is available.
- Preserve provenance labels in summaries and reports.
- When a tool says to pause for human-loop questions, pause before final output. Treat `human_loop_host_action` as a required interaction contract: in Claude, render `questions_for_user` through `Ask_User_Input_V0` / the `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` question types. Plain-text questions are invalid when the widget is available; compact inline fallback is allowed only when the widget is unavailable. Critical Compass cannot force Claude API `tool_choice`, so hosts should honor `widget_compliance_check`, `tool_compliance_signal`, and `repair_instruction`.
