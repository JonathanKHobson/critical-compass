# Self-Audit Mode Guide v1.0.0

Use `report_mode="self"` when the author is using Critical Compass as a coaching tool.

Self mode changes the framing, not the evidence:

- Keep CIS, dimension rationales, assumptions, alternative frames, argument map, check-worthy claims, and dissent ledger intact.
- Use coaching language: "To strengthen this text..." instead of "The author failed to..."
- Do not hide uncertainty or dissent to make the author feel better.
- Do not present placeholders as complete report sections.
- Ask for missing report-critical content before generating a final PDF.

Good plain-language read:

> This draft has a clear direction, but it needs sharper evidence boundaries before a reader can safely act on it.

Good before-use line:

> Before sharing it, name the strongest limitation, the missing affected voice, and the factual claim that still needs checking.
