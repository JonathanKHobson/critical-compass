# Structured Elicitation Examples v1.0.0

Use these prompts when the audit is missing context or a report would otherwise ship with placeholder sections. Keep questions bounded and non-sensitive.

## Missing Context

- What is the text trying to help a reader decide?
- Who is the intended audience?
- What source or evidence should be treated as authoritative here?

## Report Readiness

- What is the one-sentence key tension?
- What should a reader check before using this text?
- What evidence would test the strongest factual claim?
- Which affected perspective is missing or underrepresented?

## Stakeholder Reflection

- Who benefits if this framing is accepted?
- Who may carry the cost or risk if this text is acted on?
- What would make the comfortable answer harder to defend?

## Placeholder Recovery

If a report field is missing, ask:

> The report is missing `<field>`. Do you want to provide it now, or should I generate a clearly marked draft with placeholders?

Do not infer sensitive personal information. Do not save any reminder or pattern unless the user explicitly asks.
