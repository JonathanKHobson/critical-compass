# Critical Integrity Report Checkpoint

## Critical Integrity Snapshot

Label:
Points:
Plain-Language Read:
Before Using This Text:

## Dimension Profile

- Grounding & Scope Fit:
- Assumptions & Context:
- Bias Transparency:
- Framing & Audience Openness:
- Positionality & Power:

## Top Biases Identified

| Bias | Where | Why It Matters | Lens |
| --- | --- | --- | --- |

## Key Tension

One sentence naming the main conflict or trade-off.

## Recommended Next Step

One concrete action.

## Assumption Audit

| Assumption | Testable? | What Would Test It |
| --- | --- | --- |

## Alternative Frames

List frames that would change how a reader interprets the text.

## Questions To Bring To The Text

- [ ] Question one
- [ ] Question two
- [ ] Question three

## Evidence Needed Next / Check-Worthy Claims

Use "check-worthy means worth verifying, not false."

## Argument Map

Central claim, supporting reasons, objections, assumptions, missing voices, evidence gaps, and next questions.

## Where the Analysts Disagreed

Agent top findings, strongest disagreements, confidence, and what would change their minds.
