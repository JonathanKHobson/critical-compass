# Audit To Report Viewer Demo Runbook v1.0.0

This runbook demonstrates the shipped local-first Critical Compass flow for teaching, portfolio walkthroughs, and smoke validation.

## Demo Goal

Show that Critical Compass can prepare a source, audit it, create stakeholder artifacts, and open a read-only viewer without relying on external retrieval.

## Recommended Demo Flow

1. Start with `critical_compass_overview(topic="reports")` so the host AI sees the report contract and tool sequence.
2. If the source is a PDF, call `prepare_audit_source(source_path=...)`.
3. Audit the returned text with `audit_text` or run `advanced_audit` followed by the staged synthesis flow.
4. Before PDF generation, compile the Markdown checkpoint and canonical `audit_data`.
5. Call `generate_audit_report` once.
6. Present the returned `report_path`, `markdown_path`, `manifest_path`, `preview_image_path`, and `viewer_path`.
7. If the viewer needs to be regenerated later, call `generate_audit_artifact_viewer(manifest_path=...)`.

## Local 36 Questions Smoke

The repo includes `scripts/smoke_36_questions_report.py` for the current 36 Questions test path. It exercises source prep, audit scaffolding, synthesis-shaped data, PDF report generation, page images, golden artifact screenshots, manifest writing, and viewer generation.

## Demo Boundaries

- Do not add live web search.
- Do not use placeholder PDFs as final outputs.
- Do not edit findings inside the viewer.
- Do not claim calibration quality from a demo run; use beta calibration cases for that.
