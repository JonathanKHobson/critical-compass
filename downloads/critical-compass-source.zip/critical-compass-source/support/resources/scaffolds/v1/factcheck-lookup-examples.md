# Factcheck Lookup Examples v1.0.0

`factcheck_lookup` is scaffold-first by default. It helps a host AI verify factual `checkworthy_claims` responsibly; it does not prove truth independently and does not run retrieval unless a retrieval mode is explicitly named.

## Default Guided Research

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "Prairie dogs communicate danger information through alarm calls.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "guided_research",
  "allow_external_calls": false
}
```

Expected behavior:

- `lookup_performed=false`
- `mode="guided_research"`
- `epistemic_framing` appears before query suggestions
- `suggested_queries` and `recommended_source_classes` are safe for host browsing
- `evidence_trail_template` is empty until real evidence is gathered

## Deprecated Auto Alias

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "The city reduced bus fares by 25 percent in 2024.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "auto"
}
```

`auto` now returns guided-research scaffolding and includes a loud `provider_auto_deprecated` warning. It no longer selects local indexes, publisher harvest, Google, Brave, or publisher search.

## Local ClaimReview Index

Build the index first:

```bash
python3 scripts/build_claimreview_index.py support/registry/example-claimreview-source.json --output support/registry/local_claimreview_index.json
```

Then call:

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "The city reduced bus fares by 25 percent in 2024.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "local_claimreview",
  "publisher_sites": ["factcheck.org"],
  "allow_external_calls": false
}
```

This mode searches only the local index and sends no claim text externally.

## Direct Publisher Harvest

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "The city reduced bus fares by 25 percent in 2024.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "publisher_harvest",
  "publisher_sites": ["factcheck.org"],
  "allow_external_calls": true
}
```

This mode directly queries approved publisher sites and harvests ClaimReview markup only. It is opt-in because it sends normalized claim text to the publisher search endpoint.

## Experimental Provider Retrieval

Provider retrieval is not the main path. Use it only after explicit user authorization:

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "The city reduced bus fares by 25 percent in 2024.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "publisher_site_search",
  "publisher_sites": ["factcheck.org"],
  "allow_external_calls": true
}
```

Returned matches are evidence artifacts, not Critical Compass truth verdicts. `no_trusted_match` means no trusted match was found in the selected retrieval scope; it does not mean true or false.

## Evidence Trail Pattern

After host browsing or future retrieval, fill evidence rows like this:

```json
{
  "claim_id": "claim-1",
  "evidence_rows": [
    {
      "source_title": "Example official dataset",
      "source_url": "https://example.org/source",
      "source_class": "primary_or_official_source",
      "publisher_or_author": "Example agency",
      "date": "2025-01-10",
      "what_it_supports": "The source supports the numeric claim.",
      "limits": "The dataset does not explain causal impact."
    }
  ]
}
```

Reports should render fact-check/evidence sections only when real evidence rows or trusted matches are supplied.
