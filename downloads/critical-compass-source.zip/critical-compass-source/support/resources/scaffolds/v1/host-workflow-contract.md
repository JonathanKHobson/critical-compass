# Critical Compass Host Workflow Contract v1.0.0

Use this contract before calling Critical Compass tools. It keeps the audit complete, the report payload canonical, and the PDF renderer out of placeholder loops.

## Source First

If the user gives a local PDF, call `prepare_audit_source` first. Use the returned `text` for `audit_text` or `advanced_audit`. Do not silently audit a file path.

## Audit Before Report

Complete the audit before generating a PDF. For guided human-loop mode, ask pending onboarding, judgment, or reflection prompts before final output unless the user explicitly requested a noninteractive smoke test.

## Report-Ready Fields

Before calling `generate_audit_report`, compile these canonical fields:

- `critical_integrity_snapshot.label`
- `critical_integrity_snapshot.points`
- `critical_integrity_snapshot.plain_language_read`
- `critical_integrity_snapshot.before_using_this_text`
- `critical_integrity_snapshot.dimensions[]` with `name`, `points`, `max_points`, `rationale`, `trace`, and `improvement_prompt`
- `biases[]` with `name`, `passage`, `why_it_matters`, and `three_cs_lens`
- `key_tension`
- `recommended_next_step`
- `assumptions[]`
- `alternative_frames[]`
- `questions.probing[]`
- `questions.follow_up[]`
- `next_steps[]`
- `argument_map` when present
- `checkworthy_claims` when present
- `external_fact_checks` only when the user explicitly authorized `factcheck_lookup` and real trusted matches were returned
- `advanced_audit.agents[].top_finding` when advanced agents were used
- `advanced_audit.dissent_ledger` when agents disagree or confidence differs materially

## Optional Fact-Check Lookup

External fact-check retrieval is not part of core audits. If the user asks to verify factual claims, first extract or use existing `checkworthy_claims`, then call `factcheck_lookup` in default `guided_research` mode to get epistemic framing, source classes, and an evidence trail template. Use host browsing or research tools to fill the evidence trail. Use `local_claimreview` when a local index is configured. Use `publisher_harvest` or provider-backed retrieval only after explicit user authorization and only with an explicit provider name.

Do not send full documents, surrounding notes, hidden reasoning, or non-factual claims. Do not call the tool for interpretive, causal, normative, policy, emotional, or sensitive/private claims unless the user explicitly authorizes a sensitive override. Treat returned matches as retrieved publisher evidence, not as a Critical Compass truth verdict. Quote publisher ratings verbatim and preserve conflicts.

## Markdown First

For full reports, produce the Markdown checkpoint before the PDF call. If a section is empty, stop and ask whether the user wants to provide the missing content or explicitly authorize placeholders.

## Post-Call Rules

If `generate_audit_report` returns `qa_status="blocked"`, show `missing_report_fields` and `what_to_resubmit`; do not present a PDF. If warnings appear, ask the user before regenerating. Never present placeholder output as a final polished report.

If report generation succeeds, present `report_path`, `markdown_path`, `manifest_path`, and `viewer_path` together. Use `generate_audit_artifact_viewer(manifest_path)` only when rebuilding or opening the read-only viewer from an existing manifest; it does not create findings, run retrieval, or replace the PDF/Markdown source of truth.
