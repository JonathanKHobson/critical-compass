# Critical Compass Tool Inventory v1.0.0

Use this inventory when a host AI needs to decide which Critical Compass tool to call. Prefer the narrowest tool that matches the user goal. The manifest and live server descriptions use the same tier labels.

## Tool Tiers

- **Tier 1:** start here for first-use, quick audits, full audits, claim cards, PDF/source intake, and report generation: `get_started`, `quick_scan`, `audit_text`, `claim_stress_test`, `prepare_audit_source`, `generate_audit_report`.
- **Tier 2:** use after the lane is known for workflow support, validation, advanced audit stages, KB lookup, fact-check scaffolds, saved results, and comparisons.
- **Tier 3:** use only for compatibility, persistence overlays, legacy helpers, or user-added KB maintenance.

## Start And Routing

- `get_started`: first-session onboarding for new users, install/start guidance, “what do I do first?”, and first audit setup. It also surfaces the beta calibration intake path.
- `critical_compass_overview`: start here for workflow routing, examples, report contracts, output requirements, and local scaffold resources.
- `list_concept_examples`: browse examples of biases, fallacies, thinking lenses, reasoning frameworks, methodology checks, or broader patterns.

## Host-AI Resources

- `host-ai-quickstart-current-state.md`: Host-AI Quickstart / Current State Context for shipped behavior, entry points, freshness checks, and non-negotiable rules.
- `client-host-hints.md`: Client-specific one-line hints for Claude, Codex, and Cursor-style hosts. These are guidance only, not client-specific runtime behavior.
- `tool-trigger-matrix.md`: Tool trigger matrix with call-when, do-not-call-when, ask-first, and output-label guidance.
- `surface-sync-checklist.md`: Surface sync checklist for keeping README, overview, tool inventory, scaffold manifest, and tests aligned.
- `mcpb-install-diagnostics-prompt.md`: pasteable Claude/Codex prompt for installing or diagnosing the Critical Compass MCPB/Desktop Extension without overwriting existing MCP config.
- `pressure-test-readiness-kit.md`: Local scenario and guidance kit for validating whether outputs help public/nonprofit users trust, revise, verify, or reframe before use.

## Source And Audit

- `prepare_audit_source`: use before auditing a local PDF. It extracts embedded text, detects sparse/scanned PDFs, prefers Apple Vision OCR on macOS, falls back to local Tesseract OCR through `pytesseract`/`Pillow` when installed, writes page images/text artifacts, and blocks sparse source failures.
- `quick_scan`: lightweight entry point returning only CIS, top 2 biases, key tension, one action, text type, and guidance to run `audit_text` next. It is not a replacement for `audit_text`.
- `audit_text`: use for a direct structured audit of supplied text. It returns CIS, plain-language read, before-use guidance, argument map, check-worthy claims, traps, human-loop state, and report readiness contract.
- `list_agent_personas`: use before advanced agent mode when the user wants available analyst roles or custom persona guidance. Seeds such as grant reviewer / evidence steward, affected-community reviewer, AI/data auditor, public accountability editor, and accessibility reviewer are analytical standpoints, not identity roleplay.
- `advanced_audit`: use for staged, multi-agent audit scaffolding. The host AI executes scaffold stages and preserves dissent/provenance.
- `synthesize_audit_verdict`: use after advanced-audit stages to produce final synthesis, dissent ledger, report-ready materials, and optional report guidance.

Supported `text_type` values include `social_media`, `academic_abstract`, `product_copy`, `legal`, and `ai_generated` in addition to the original general, advocacy, policy, sales, research, journalism, and narrative lanes.

## Claim And Knowledge Work

- `claim_stress_test`: use for one compact claim card with steelman, fallacy risk, caveat, questions, and next actions.
- `challenge_claim`: compatibility tool for advanced-audit scaffolds.
- `factcheck_lookup`: scaffold-first verification planning for factual `checkworthy_claims`. Default `provider="guided_research"` performs no retrieval and returns epistemic framing, safe queries, source classes, evidence trail template, and plurality review template. `local_claimreview` searches a configured local index without external calls. `publisher_harvest` and external search/API providers require explicit provider names plus `allow_external_calls=true`.
- `suggest_next_steps`: use after findings are chosen to return concrete action verbs and optional practice suggestions inside existing outputs.
- `lookup_bias`, `get_framework`, `get_reasoning_flow`, `search_knowledge_base`, and `list_reasoning_flows`: use when the host needs KB-backed concepts or executable reasoning flows. KB concept tools may return compact `lens_card`, `selected_lens_ids`, `retrieval_budget`, and selection reasons so hosts retrieve only the relevant lens cards instead of loading large prompt material.
- When `search_knowledge_base` returns no results, use the no-result recovery guidance before deciding the KB is empty. Try narrower terms, category filters, and adjacent concepts.
- For Indigenous health equity, tribal/First Nations, public-health measurement, data governance, food sovereignty, or community-evaluation text, retrieve KB-backed lenses before naming OCAP, CARE Principles, Indigenous data sovereignty, data erasure, food sovereignty, relational accountability, or community authority. If the host did not look up the label, mark it as host inference.
- In advanced or sensitive contexts, named lenses/biases/frameworks should include KB IDs. Unsupported labels are allowed only when explicitly marked `host_inference`.

## Reports And Artifacts

- `generate_audit_report`: use only after audit/report-critical fields are complete. It writes PDF, Markdown, manifest, page images, preview image, optional argument-map sidecar, and local viewer metadata. Use `report_depth="readiness_card"` for a compact derived summary from existing audit fields.
- `validate_report_payload`: dry-run the same normalization, readiness, Markdown, activity, and renderer diagnostics used by `generate_audit_report` without writing files. Use `schema_only=true` to inspect canonical report fields, accepted aliases, field constraints, CIS bands, renderer status, and example payload shape.
- `generate_audit_artifact_viewer`: use when a completed report manifest should become or refresh a local read-only HTML viewer. It does not create findings or run retrieval.

## Persistence

- `save_audit_result`: save completed audit results and report metadata. Optional `activity_outcome` notes are stored inside the result payload when the user supplies them; they do not create a separate feedback system.
- `get_audit_result`, `list_audit_results`, and `compare_audit_results`: retrieve, browse, and carefully compare saved final audit results with comparability warnings. `compare_audit_results` can compare two saved IDs or two already-audited inline payloads, but not raw text.
- `save_audit_progress`: save resumable stage progress.
- `save_bias_pattern`, `save_entity_pattern`, and `get_pattern_summary`: store and review recurring patterns only when the user explicitly wants persistence.

## Non-Negotiable Host Rules

- Do not run automatic web verification from core audits.
- Do not use provider-backed retrieval for interpretive, causal, normative, policy, emotional, or private/sensitive claims unless the user explicitly authorizes a sensitive override.
- Do not equate check-worthy with false.
- Do not treat external archives as runtime dependencies. Use planning-derived local resources only after they have been distilled into Critical Compass fixtures or scaffolds.
- Prefer MCPB/Desktop Extension install guidance for non-technical users before manual JSON config or zip-script fallback paths.
- Use the Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, and surface sync checklist before changing or explaining public MCP behavior.
- Do not present placeholder PDFs as final.
- Ask human-loop prompts when `PAUSE_REQUIRED=true` or `human_loop_host_action.must_pause=true`, except in explicit noninteractive smoke tests. Treat `human_loop_host_action` as a required host interaction contract. In Claude, use the native `Ask_User_Input_V0` / `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` question types. Plain-text questions are invalid when the widget is available; compact inline fallback is allowed only when the widget is unavailable.
- Respect retrieval budgets in audit payloads. Quick mode may use up to 3 short lens cards, standard mode up to 5 standard lens cards, and advanced mode up to 8 standard lens cards with per-agent selection reasons.
- Use `fairness_to_text` as a pre-conclusion check: keep expected non-findings out of the final critique unless the text provides new evidence.
- Present report outputs together: `report_path`, `markdown_path`, `manifest_path`, and `viewer_path`.
