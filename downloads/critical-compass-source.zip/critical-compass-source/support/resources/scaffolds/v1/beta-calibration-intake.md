# Real Beta Calibration Intake v1.0.0

Use this template when adding real audit examples to the calibration harness. Do not fabricate real beta cases.

## Required Fields

Each case should include:

- `id`: stable local identifier with no personal data.
- `text_type`: `general`, `advocacy`, `policy`, `sales`, `research`, `journalism`, `narrative`, `social_media`, `academic_abstract`, `product_copy`, `legal`, `ai_generated`, or `other`.
- `text`: a short excerpt that the user is comfortable storing locally.
- `expected_traps`: reasoning-trap IDs expected to appear.
- `expected_triggers`: human-loop interruption trigger IDs expected to appear.
- `expected_absent_traps`: trap IDs that should not appear.

## Consent And Privacy Rules

- Use only text the user explicitly wants included in calibration.
- Remove names, addresses, private organizational details, and sensitive personal information.
- Store only the minimum excerpt needed to reproduce the trap or trigger behavior.
- Label the case as calibration data, not as evidence that the audited claim is true or false.

## Running Custom Cases

Save cases as a JSON object with a top-level `cases` array, then run:

```bash
python3 scripts/run_beta_audit_calibration.py --cases /path/to/cases.json --output-dir /path/to/output
```

Use the default fixture set for regression. Use custom real-user cases for tuning false positives and missed pauses.
