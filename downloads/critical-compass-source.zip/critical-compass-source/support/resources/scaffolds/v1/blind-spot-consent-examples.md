# Blind-Spot Reminder Consent Examples v1.0.0

Blind-spot reminders are optional, consent-confirmed learning notes. They are not a psychological profile and they must not store sensitive personal traits.

## When To Offer

Offer a reminder only when an audit surfaces a repeated, non-sensitive reasoning pattern, such as:

- "You often ask for evidence boundaries after the first draft."
- "You may want a prompt that checks for missing affected stakeholders."
- "You sometimes accept a comfortable answer before testing what would change it."

Do not offer reminders about protected traits, health, religion, politics, sexuality, identity, private relationships, or other sensitive personal categories.

## Consent Prompt

Use clear opt-in language:

> I can save this as a non-sensitive Critical Compass reminder so future audits can nudge you to check for missing affected perspectives. Do you want me to save it?

Do not save if the user says maybe, not now, keep going, or gives no answer.

## Save Call

After explicit consent, call:

```json
{
  "reminder": "Check for missing affected stakeholder perspectives before accepting the comfortable answer.",
  "text_type": "policy",
  "context_note": "User explicitly asked to remember this after a guided audit.",
  "consent_confirmed": true
}
```

## Retrieval Language

When surfacing saved reminders, keep the wording bounded:

> A saved Critical Compass reminder may apply here: check whether affected stakeholder perspectives are missing before accepting the easy answer.

Avoid:

> You are the kind of person who ignores affected stakeholders.

## Refusal Pattern

If the candidate reminder is sensitive or profiling-like, do not save it. Say:

> I will not save that as a blind-spot reminder because it could become sensitive profiling. I can keep it as a one-time audit note instead.
