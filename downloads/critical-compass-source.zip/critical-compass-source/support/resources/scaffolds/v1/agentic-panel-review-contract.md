# Agentic Panel Review Contract

Use advanced panel review when the user explicitly wants a deeper, staged, multi-perspective audit with dissent preserved. Good trigger phrases include `advanced panel review`, `agentic panel review`, `multi-perspective panel`, and `run the agent audit`.

Do not use panel review just because the source text mentions agents, agencies, city council, panels, committees, or stakeholders. When intent is unclear, ask one lane question or run a normal `audit_text` audit.

## Host Capability Disclosure

- Native subagents declared: run real subagents only within the host's normal sandbox and tool approvals.
- Generic host or Claude Desktop: run a sequential labeled panel in one thread and say so.
- Scaffold-only host: show the plan and stage contracts, then stop for a capable executor.

## Compact Stage Skeleton

1. Plan review: show roles, adapter, stages, artifact budget, and ask for approval.
2. Agent definition: map four personas to stable role contracts.
3. Independent analysis: produce one typed artifact per role.
4. Tension map: preserve disagreements and snapshot-changing disputes.
5. Debate: run one three-turn exchange on the sharpest resolvable tension.
6. Synthesis: commit to one verdict, preserve dissent, and confirm/revise/withhold the Critical Integrity Snapshot.
7. Deep mode only: rewrite one problematic sentence.

## Handoff Rules

- Carry forward artifacts, not full transcripts.
- Preserve `agentic_progress_state`.
- Keep `artifact_only_handoff=true`.
- Do not ask the user directly from a role; only the host asks Human Loop or plan-review questions.
- One revision pass is the limit when tensions could change score, confidence, comparability, or profile-only state.
