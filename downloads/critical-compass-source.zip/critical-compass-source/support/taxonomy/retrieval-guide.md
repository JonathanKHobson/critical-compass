# Retrieval Guide

1. Resolve a concept by alias or exact title.
2. Expand with reverse indexes by use, topic, phase, kind, or category.
3. Walk related edges in the concept graph for adjacent concepts.
4. Review the holdout list when confidence is low or routing is adjacent.
