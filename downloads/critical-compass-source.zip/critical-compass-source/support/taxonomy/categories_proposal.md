# Categories Proposal
_Date: 2025-09-28_

## Scope
This proposal defines category-level changes only (not tags), to be applied to `templates.data.js` and the categories registry. It captures Aliases/Merges, Removals (re-homed as tags), Renames, Policy Changes, and Additions. It preserves the **HELPER** category as a protected identifier for master chooser templates.

---

## Protected
- **HELPER**: keep as-is. This category uniquely marks master templates that help users choose which template to use.

---

## Merges
Unify near-duplicates and converge on clearer umbrellas. Counts in parentheses indicate current usage observed during discovery.

- `decision` → `decision-making`  (27 → 3). Clearer and matches the tag idiom for activities.
- `analytics` → `analysis`  (4 → 26). Consolidate under the broader umbrella.
- `ux` → `design`  (2 → 24). “Design” is the established umbrella.
- `privacy` → `governance`  (1 → 24). Privacy work tends to live with governance policy, accountability, review paths.

- `education-training` → `education`  (1 → 34). Reduce compound into the dominant umbrella.
- `journaling` → `reflection`  (1 → 28). Journaling is a modality of reflection.
- `methods` → `methodology`  (1 → 3). Terminology consistency.

---

## Removals (re-home as tags, not categories)
These are methods or QA qualities. Keep the signal by moving to tags so categories stay broad.

- `ethnography`  → tag `method:ethnography`  (count 1)
- `interviews`  → tag `method:interview`  (count 1)
- `experiment`  → tag `method:experiment`  (count 1)
- `experimentation`  → tag `method:experiment`  (count 2)
- `research-quality`  → tag `quality:research`  (count 1)

---

## Renames
Fix casing and clarity for the outlier.

- `storytelling frameworks` → `storytelling`  (count 1 → 24). Non‑kebab outlier; aligns with the dominant umbrella.

---

## Changes (policy level)
- Prefer **noun phrases** for categories. If strict enforcement is desired, consider: `cultural` → `culture` (note: `cultural` is common; defer if churn is a concern).
- Keep categories **short, lowercase, kebab-case**. Avoid near-synonyms where an alias would suffice.

---

## Additions
Introduce one umbrella to reduce drift across prompt work.

- `prompting` — _“General prompt design and reasoning umbrella; sits over prompt-development and prompt-reasoning.”_

---

## Implementation plan (high level)
1. **Alias map**: create `categories_aliases.yaml` reflecting all merges and renames above.
2. **Migration**: run a one-shot script to rewrite `categories` for each template:
   - Apply alias map; drop removals while adding the corresponding tag(s) listed.
   - Preserve **HELPER** untouched.
3. **Registry update**:
   - Recompute category counts/examples.
   - Emit updated `categories_registry.yaml` and a refreshed `categories_taxonomy-reference.md`.
4. **Diff report**:
   - Show before/after per template id.
   - Flag any unknown categories that remain.

---

## Notes
- These changes are intentionally conservative and aimed at reducing fragmentation without obscuring signal.
- The HELPER category is explicitly exempt from merges, renames, and removals.
