# Categories taxonomy (reference)

_Generated 2025-09-28 — source: templates.data.js_

## Summary

- Total templates parsed: **299**
- Unique categories: **110**

## Canonical categories (discovered)

| category | count | example template ids |
|---|---:|---|
| `planning` | 73 | two_min_rule, addie, east_nudge, eisenhower_matrix, goal_breakdown, goal_composition |
| `community` | 58 | participatory_action_research, participatory_decolonial, theory_of_change, v2mom, community_okrs, outcome_mapping |
| `research` | 51 | positionality_statement, reflexive_memo, working_backwards_prfaq_v3, jtbd_interviews_v3, registered_report_prereg, adversarial_collaboration |
| `ethics` | 50 | anekantavada_syadvada, argument-map, bias_impact_assessment, bias_interrupters, eightfold_path, cognitive_debiasing |
| `strategy` | 41 | bias_interrupters, constraint_flip, dao_wu_wei, east_nudge, fab, ganma_confluence |
| `reasoning` | 36 | kipling_5w1h, a3_ps, anekantavada_syadvada, argument-map, eightfold_path, facione-core |
| `education` | 34 | a3_ps, addie, blooms, disney_creative, empty_chair, fab |
| `operations` | 33 | a3_ps, bias_interrupters, cognitive_debiasing, dmaic, ice_scoring, kepner_tregoe |
| `creativity` | 32 | two_min_rule, active_imagination, constraint_flip, disney_creative, eisenhower_matrix, spoon_planner |
| `mental-health` | 30 | abcde, active_imagination, anekantavada_syadvada, argument-map, avm_framework, eisenhower_matrix |
| `wellbeing` | 30 | avm_framework, tarot_spread, three_vaults_practice, focusing_felt_sense, rain_self_inquiry, parts_check_in_ifs |
| `reflection` | 28 | abcde, active_imagination, avm_framework, empty_chair, spoon_planner, epic_quest |
| `communication` | 27 | three_vaults_practice, parts_check_in_ifs, last_2_percent_round, working_out_loud_truth, clear_contracts_exit_ramps, positionality_statement |
| `decision` | 27 | bab, comparative_analysis, dmaic, eisenhower_matrix, facione-core, head_heart_gut |
| `analysis` | 26 | kipling_5w1h, clear, comparative_analysis, first_principles, kansei_engineering, mind_map |
| `facilitation` | 25 | three_vaults_practice, last_2_percent_round, aar_feelings_first, working_out_loud_truth, clear_contracts_exit_ramps, rose_thorn_bud_weather |
| `design` | 24 | addie, argument-map, bias_impact_assessment, blooms, east_nudge, heros_journey |
| `governance` | 24 | collective_impact, arnsteins_ladder, iap2_spectrum, engagement_to_ownership_spectrum, design_justice_principles, community_led_development |
| `storytelling` | 24 | aida, bab, costar, disney_creative, epic_quest, fab |
| `critical-thinking` | 22 | abcde, argument-map, blooms, eightfold_path, cognitive_debiasing, dmaic |
| `brainstorming` | 21 | epic_quest, first_principles, golden, grow, head_heart_gut, hmw_statements |
| `prompt-development` | 21 | aida, clear, clear_path, clear_pm, costar, few_shot |
| `cultural` | 20 | two_min_rule, anekantavada_syadvada, eightfold_path, constraint_flip, dao_wu_wei, spoon_planner |
| `management` | 20 | two_min_rule, abcde, first_principles, kaitiakitanga, kano_model, maslaha_public_interest |
| `teamwork` | 20 | last_2_percent_round, aar_feelings_first, premortem_pregrief, working_out_loud_truth, clear_contracts_exit_ramps, critical_incident_analysis |
| `quality` | 17 | kipling_5w1h, a3_ps, anekantavada_syadvada, dmaic, facts_primer, debiasing-checklist |
| `learning` | 16 | aar_feelings_first, working_out_loud_truth, reflexive_memo, critical_incident_analysis, blameless_postmortem_essence, most_significant_change |
| `writing` | 13 | bab, bias_impact_assessment, spoon_planner, fab, freewrite, heros_journey |
| `engineering` | 11 | decision_record_v3, design_doc_scariest_change, rfc_process_unsaid_objection, tdd_property_based_testing, trunk_feature_flags, engineering_method |
| `safety` | 11 | vmodel_mbse_assumption_ledger, fmea_hazop_fta_unified, ethical_data_stewardship, checklists_gawande, sbar_health_dx, soap_health_dx |
| `reliability` | 10 | design_doc_scariest_change, tdd_property_based_testing, fuzz_mutation_outage_shape, trunk_feature_flags, canary_blue_green_deploys, observability_slos_error_budgets |
| `alignment` | 9 | v2mom, community_okrs, collective_impact, north_star_metric, arnsteins_ladder, iap2_spectrum |
| `product` | 9 | engineering_method, design_science_research, hcd_double_diamond, opportunity_solution_tree, wardley_mapping, user_story_ac_pro |
| `statistics` | 9 | registered_report_prereg, systematic_review_meta, causal_inference_framework, mixed_methods_triangulation, open_science_checklist, bayesian_science |
| `systems` | 8 | systems_mapping_kumu, two_eyed_seeing, ripple_effects_mapping, future_search, soft_systems_methodology_ssm, viable_system_model_vsm |
| `careers` | 7 | targeting_matrix, value_prop_canvas_personal, star_soar_stories, pipeline_kanban_job_search, t_gap_analysis_30day, informational_interview_ladder |
| `delivery` | 7 | trunk_feature_flags, canary_blue_green_deploys, raci_drci_consent, user_story_ac_pro, roadmap_brief_pro, bdd_gwt_pro |
| `equity` | 7 | engagement_to_ownership_spectrum, community_led_development, participatory_budgeting, stakeholder_harm_benefit_forecast, inclusive_language_metaphor_scrubber, cross_cultural_localization_readiness |
| `health` | 7 | sbar_health_dx, soap_health_dx, askme3_health_dx, teach_back_health_dx, red_flag_plan_health_dx, sdm_health_dx |
| `job-search` | 7 | targeting_matrix, value_prop_canvas_personal, star_soar_stories, pipeline_kanban_job_search, t_gap_analysis_30day, informational_interview_ladder |
| `risk` | 7 | premortem_pregrief, premortem_redteam_v3, fmea_hazop_fta_unified, trl_with_exit_ramps, premortem, stakeholder_harm_benefit_forecast |
| `communications` | 6 | brand_archetypes_community, voice_tone_frameworks, public_narrative_action, story_circles_harvesting, cultural_web_johnson_scholes, empathy_personas_jtbd |
| `architecture` | 5 | design_doc_scariest_change, rfc_process_unsaid_objection, threat_model_stride_linddun, vmodel_mbse_assumption_ledger, intent_to_action_patterns |
| `evaluation` | 5 | most_significant_change, outcome_harvesting, ripple_effects_mapping, sensemaker_micro_narratives, cultural_probes_diary_studies |
| `measurement` | 5 | okr, community_okrs, outcome_mapping, north_star_metric, okrs_job_search |
| `notes` | 5 | soap_health_dx, askme3_health_dx, teach_back_health_dx, sdm_health_dx, bpmh_health_dx |
| `personal-development` | 5 | three_vaults_practice, focusing_felt_sense, rain_self_inquiry, noting_mindfulness, memento_mori_micro |
| `philosophy-of-science` | 5 | popperian_falsification, lakatos_research_programs, kuhn_paradigms, feyerabend_pluralism, abductive_reasoning |
| `policy` | 5 | systematic_review_meta, causal_inference_framework, abm_system_dynamics_truth, causal_inference_playbook, participatory_decolonial |
| `prompt-reasoning` | 5 | least_to_most, plan_solve, task_breakdown, tot_brainstorm, tot_decompose |
| `systems-engineering` | 5 | vmodel_mbse_assumption_ledger, fmea_hazop_fta_unified, reliability_growth_burn_in, doe_tolerance_stacks, trl_with_exit_ramps |
| `analytics` | 4 | lean_loop_stop_harm_v3, okrs_kill_criteria_v3, observability_slos_error_budgets, doe_tolerance_stacks |
| `branding` | 4 | brand_archetypes_community, voice_tone_frameworks, public_narrative_action, cultural_web_johnson_scholes |
| `mindfulness` | 4 | focusing_felt_sense, rain_self_inquiry, noting_mindfulness, tonglen_lite_secular |
| `accessibility` | 3 | inclusive_language_metaphor_scrubber, cross_cultural_localization_readiness, accessibility_reality_check |
| `coaching` | 3 | parts_work, three_vaults_practice, parts_check_in_ifs |
| `conflict` | 3 | truth_reconciliation_micro, lara_cri_dialogue, accountability_letter |
| `data` | 3 | ocap_care_governance, sensemaker_micro_narratives, ethical_data_stewardship |
| `decision-making` | 3 | premortem, decision_matrix_weighted, sbar_health_dx |
| `methodology` | 3 | popperian_falsification, bayesian_science, feyerabend_pluralism |
| `project-management` | 3 | premortem, personal_kanban_wip, checklists_gawande |
| `qa` | 3 | user_story_ac_pro, bdd_gwt_pro, intent_to_action_patterns |
| `self-management` | 3 | personal_kanban_wip, decision_matrix_weighted, checklists_gawande |
| `testing` | 3 | tdd_property_based_testing, fuzz_mutation_outage_shape, reliability_growth_burn_in |
| `ttrpg` | 3 | stars_wishes_bleed_check, lines_veils_revisit, safety_pause_with_essence |
| `writing-frameworks` | 3 | rapid_framing_rewriter, inclusive_language_metaphor_scrubber, accessibility_reality_check |
| `execution` | 2 | v2mom, pipeline_kanban_job_search |
| `experimentation` | 2 | lean_loop_stop_harm_v3, trunk_feature_flags |
| `organization` | 2 | sociocracy_consent_governance, holacracy_selective_volunteer |
| `ritual` | 2 | ofrenda_remembrance_board, vow_and_witness |
| `security` | 2 | fuzz_mutation_outage_shape, threat_model_stride_linddun |
| `simulation` | 2 | abm_system_dynamics_truth, computational_science |
| `template-picker` | 2 | pattern-picker, pattern-picker |
| `ux` | 2 | jtbd_interviews_v3, user_story_ac_pro |
| `advocacy` | 1 | power_mapping_inclusive_engagement |
| `budget` | 1 | participatory_budgeting |
| `career` | 1 | framework_ikigai |
| `check-in` | 1 | rose_thorn_bud_weather |
| `commitment` | 1 | vow_and_witness |
| `compassion` | 1 | tonglen_lite_secular |
| `customer-support` | 1 | canary_blue_green_deploys |
| `education-training` | 1 | checklists_gawande |
| `embodiment` | 1 | contact_improv_listening_duet |
| `ethnography` | 1 | cultural_probes_diary_studies |
| `experiment` | 1 | doe_tolerance_stacks |
| `family` | 1 | ofrenda_remembrance_board |
| `healthcare` | 1 | goals_of_care_values_first |
| `interviews` | 1 | star_soar_stories |
| `investment` | 1 | community_capitals_framework |
| `journaling` | 1 | tarot_spread |
| `localization` | 1 | cross_cultural_localization_readiness |
| `manufacturing` | 1 | doe_tolerance_stacks |
| `marketing` | 1 | pas |
| `methods` | 1 | evidence_robustness_reproducibility_check |
| `networking` | 1 | informational_interview_ladder |
| `portfolio` | 1 | roadmap_brief_pro |
| `positioning` | 1 | value_prop_canvas_personal |
| `prioritization` | 1 | targeting_matrix |
| `privacy` | 1 | threat_model_stride_linddun |
| `process-improvement` | 1 | pdsa |
| `productivity` | 1 | personal_kanban_wip |
| `program-management` | 1 | trl_with_exit_ramps |
| `purpose` | 1 | framework_ikigai |
| `qualitative` | 1 | ethnographic_interpretivist |
| `research-quality` | 1 | evidence_robustness_reproducibility_check |
| `resilience` | 1 | gratitude_under_duress |
| `retrospective` | 1 | aar_feelings_first |
| `service` | 1 | service_design_blueprint |
| `storytelling frameworks` | 1 | pas |
| `vision` | 1 | framework_bhag |

## Items to review

| category | count | examples | notes |
|---|---:|---|---|
| `advocacy` | 1 | power_mapping_inclusive_engagement | rare (appears once) |
| `budget` | 1 | participatory_budgeting | rare (appears once) |
| `career` | 1 | framework_ikigai | rare (appears once) |
| `check-in` | 1 | rose_thorn_bud_weather | rare (appears once) |
| `commitment` | 1 | vow_and_witness | rare (appears once) |
| `compassion` | 1 | tonglen_lite_secular | rare (appears once) |
| `cultural` | 20 | two_min_rule, anekantavada_syadvada, eightfold_path, constraint_flip, dao_wu_wei, spoon_planner | check noun vs adjective form (style) |
| `customer-support` | 1 | canary_blue_green_deploys | rare (appears once) |
| `decision` | 27 | bab, comparative_analysis, dmaic, eisenhower_matrix, facione-core, head_heart_gut | consider 'decision-making' for clarity (style) |
| `education-training` | 1 | checklists_gawande | rare (appears once) |
| `embodiment` | 1 | contact_improv_listening_duet | rare (appears once) |
| `ethnography` | 1 | cultural_probes_diary_studies | rare (appears once) |
| `experiment` | 1 | doe_tolerance_stacks | rare (appears once) |
| `family` | 1 | ofrenda_remembrance_board | rare (appears once) |
| `healthcare` | 1 | goals_of_care_values_first | rare (appears once) |
| `interviews` | 1 | star_soar_stories | rare (appears once) |
| `investment` | 1 | community_capitals_framework | rare (appears once) |
| `journaling` | 1 | tarot_spread | rare (appears once) |
| `localization` | 1 | cross_cultural_localization_readiness | rare (appears once) |
| `manufacturing` | 1 | doe_tolerance_stacks | rare (appears once) |
| `marketing` | 1 | pas | rare (appears once) |
| `methods` | 1 | evidence_robustness_reproducibility_check | rare (appears once) |
| `networking` | 1 | informational_interview_ladder | rare (appears once) |
| `portfolio` | 1 | roadmap_brief_pro | rare (appears once) |
| `positioning` | 1 | value_prop_canvas_personal | rare (appears once) |
| `prioritization` | 1 | targeting_matrix | rare (appears once) |
| `privacy` | 1 | threat_model_stride_linddun | rare (appears once) |
| `process-improvement` | 1 | pdsa | rare (appears once) |
| `productivity` | 1 | personal_kanban_wip | rare (appears once) |
| `program-management` | 1 | trl_with_exit_ramps | rare (appears once) |
| `purpose` | 1 | framework_ikigai | rare (appears once) |
| `qualitative` | 1 | ethnographic_interpretivist | rare (appears once) |
| `research-quality` | 1 | evidence_robustness_reproducibility_check | rare (appears once) |
| `resilience` | 1 | gratitude_under_duress | rare (appears once) |
| `retrospective` | 1 | aar_feelings_first | rare (appears once) |
| `ritual` | 2 | ofrenda_remembrance_board, vow_and_witness | check noun vs adjective form (style) |
| `service` | 1 | service_design_blueprint | rare (appears once) |
| `storytelling frameworks` | 1 | pas | non-kebab-case (allowed: a–z, 0–9, hyphen); rare (appears once) |
| `vision` | 1 | framework_bhag | rare (appears once) |

## Dos and Don’ts

**Do**
- Use lowercase, kebab-case nouns.
- Keep terms short and widely intelligible.
- Reuse existing categories where meaning overlaps; add aliases instead of new near-synonyms.
- Document rationale when adding a new category.

**Don’t**
- Don’t use sentence case or spaces.
- Don’t introduce both noun and adjective variants (pick one).
- Don’t mirror `use:` tags here; categories should be broader groupings.
