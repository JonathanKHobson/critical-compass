# Discovery Report (Phase A)
**File scanned:** `/mnt/data/templates.data.js`  
**Templates found:** 298  
**Unique tag keys:** 8  
**Unique tag pairs (key:value):** 585  
**Total tag assignments across all templates:** 2422

## Top tag keys by usage
| Tag key | Assignments |
|---|---:|
| use | 1175 |
| topic | 359 |
| level | 313 |
| phase | 275 |
| type | 255 |
| origin | 42 |
| mode | 2 |
| alt | 1 |

## Kind distribution
| kind | Count |
|---|---:|
| framework | 155 |
| strategy | 92 |
| heuristic | 15 |
| technique | 14 |
| tool | 14 |
| facilitation | 7 |
| helper | 1 |

## Categories (observed; not enforced yet)
| category | Count |
|---|---:|
| planning | 73 |
| community | 58 |
| research | 51 |
| ethics | 50 |
| strategy | 41 |
| reasoning | 36 |
| education | 34 |
| operations | 33 |
| creativity | 32 |
| mental-health | 30 |
| wellbeing | 30 |
| reflection | 28 |
| decision | 27 |
| communication | 27 |
| analysis | 26 |
| facilitation | 25 |
| design | 24 |
| storytelling | 24 |
| governance | 24 |
| critical-thinking | 22 |

## Validation findings
- Violations recorded: 0  
  - Types: Counter()

See `discovery.violations.ndjson` for details.

## Suggested merges / aliases (working theory)
- Consider aliasing `use:ad-copy` → `use:copywriting` for consistency.
- Consider keeping `use:process-improvement` distinct from `use:iteration` (adjacent but not identical).

## Notes
- Tags parsed strictly as `key:value` with lowercase kebab-case. 
- Categories recorded for observation; not treated as tags in Phase A.
- `fields` summarized to (label, key, type) triplets; not validated against a schema yet.
