# Tags Proposal — Canonicalization & Migration (v1)
_Generated: 2025-09-28T19:48:30.634795Z_

## Purpose
This document enumerates the canonicalization plan for tags and related metadata used in `templates.data.js`. It defines merges, aliases, removals, changes, renames, and additions, with an emphasis on **non-breaking migration** of existing data and a clear deprecation path.

## Tag grammar
- Tags are `key:value` with **exactly one colon** (split on the first colon).
- Keys and values are **lowercase ASCII kebab-case** (no spaces).
- Values should be URL-safe; avoid colons inside values.
- Examples: `use:copywriting`, `topic:agent-based-modeling`, `phase:apply`, `type:helper`.

## Scope
Applies to tags in the `tags: []` array of each template object. Other fields are unchanged. The HTML contract remains: a plain script defining `window.TEMPLATES` (or `window.FRAMEWORKS`/`window.templates`).

---

## Merges & Aliases (normalize to the **canonical** value)

### `use:`
- `creative-blocks` + `creative-block` → **`creative-block`**
- `narratives` + `narrative` → **`narrative`**
- `goals` + `goal-setting` → **`goal-setting`**
- `presentations` + `presentation` → **`presentation`** (if both appear)
- `tradeoffs` + `trade-offs` → **`tradeoffs`**
- `ad-copy` → **`copywriting`**
- `reflect` → **`reflection`**
- `retro` → **`retrospective`**
- `roadmapping` → **`roadmap`**
- `prereg` → **`preregistration`**
- `ux` → **`user-experience`**
- `eda` → **`exploratory-data-analysis`**
- `bdd` → **`behavior-driven-development`**
- `tdd` → **`test-driven-development`**
- `adr` → **`architecture-decision-record`**
- `rfc` → **`request-for-comments`**
- `slo` → **`service-level-objective`**
- `faq` → **`frequently-asked-questions`**
- `why` → **`problem-framing`**

### `topic:`
- `abm` → **`agent-based-modeling`**
- `dag` → **`directed-acyclic-graph`**
- `doe` → **`design-of-experiments`**
- `fmea` → **`failure-mode-and-effects-analysis`**
- `fta` → **`fault-tree-analysis`**
- `hazop` → **`hazard-and-operability`**
- `mbse` → **`model-based-systems-engineering`**
- `jtbd` → **`jobs-to-be-done`**
- `ibe` → **`inference-to-best-explanation`**
- `mtbf` → **`mean-time-between-failures`**
- `trl` → **`technology-readiness-level`**

**Special topical guidance**  
- `present-truth` vs any `truth-*` families: keep **`truth-line`** and **`truth-telling`** distinct. If `present-truth` is used to mean “current best account,” merge it into **`truth-line`** and add a scope note.

### `phase:`
- `act` → **`apply`**

### `type:`
- `heuristics` → **`heuristic`**  
- **Retain** `type:helper` as-is (unique identifier for master templates).

### `origin:`
- `mea` → **`modern-elder-academy`**

---

## Renames / Changes

### Plural → singular standardization
- `type:heuristics` → **`type:heuristic`**

### Phase disambiguation
- Collapse `phase:act` into **`phase:apply`** (alias retained).

### Move activity-like items out of `phase`
- **Relocate:** `phase:premortem` → **`use:premortem`**.  
  Rationale: Premortem is an activity, not a project phase. Mark `phase:premortem` deprecated and preserve an alias temporarily.

### Topic-to-use relocation
- **Relocate:** `topic:prd` → **`use:prd`** (or **`use:prd-note`**).  
  Default mapping: `topic:prd` → **`use:prd`**, unless an entry already contains `use:prd-note`, in which case map to **`use:prd-note`**.

### `origin:` standardization
For people/schools use the suffix **`-inspired`**; expand opaque acronyms.
- `popper` → **`popper-inspired`**
- `kuhn` → **`kuhn-inspired`**
- `lakatos` → **`lakatos-inspired`**
- `feyerabend` → **`feyerabend-inspired`**
- `tara-brach` → **`tara-brach-inspired`**
- `dsr` → **`design-science-research`**
- `mea` → **`modern-elder-academy`**

---

## Removals (after mapping)
Remove only after their instances have been migrated to the canonical values.
- `topic:prd` (relocated to `use:` as above)
- Any zero-usage values after migration (to be listed in a follow-up report).

---

## Additions
No new keys are mandated in this proposal. Future-friendly keys (e.g., `evidence:`, `ethics:`) may be introduced later via a separate proposal. This document focuses on normalizing existing data.

---

## Deprecation policy
- Keep deprecated forms for one release cycle as aliases (e.g., `phase:act`, `phase:premortem`, `topic:prd`), then remove after analytics confirm no regressions.
- Maintain a crosswalk file (`aliases.yaml`) so search and suggestions remain robust.

---

## Implementation plan (non-breaking)
1. **Dry-run codemod** against `./js/templates.data.js` to preview changes to `tags: [...]` only.
2. **Apply codemod** (creates one-time `.bak`), then **lint** for syntax/legacy shapes.
3. **Review diff** and spot-check templates (no change to HTML data-loading contract).
4. **Commit** changes; ship in the next minor release.
5. After one cycle, **remove deprecated forms** that show zero usage.

**Note:** The codemod preserves `type:helper` exactly, relocates `phase:premortem` to `use:premortem`, and maps `topic:prd` to `use:prd` (or `use:prd-note` if already present).

---

## Appendix A — Aliases file sketch (`aliases.yaml`)
```yaml
aliases:
  use:
    creative-blocks: creative-block
    narratives: narrative
    goals: goal-setting
    presentations: presentation
    trade-offs: tradeoffs
    ad-copy: copywriting
    reflect: reflection
    retro: retrospective
    roadmapping: roadmap
    prereg: preregistration
    ux: user-experience
    eda: exploratory-data-analysis
    bdd: behavior-driven-development
    tdd: test-driven-development
    adr: architecture-decision-record
    rfc: request-for-comments
    slo: service-level-objective
    faq: frequently-asked-questions
    why: problem-framing
  topic:
    abm: agent-based-modeling
    dag: directed-acyclic-graph
    doe: design-of-experiments
    fmea: failure-mode-and-effects-analysis
    fta: fault-tree-analysis
    hazop: hazard-and-operability
    mbse: model-based-systems-engineering
    jtbd: jobs-to-be-done
    ibe: inference-to-best-explanation
    mtbf: mean-time-between-failures
    trl: technology-readiness-level
  phase:
    act: apply
  type:
    heuristics: heuristic
  origin:
    dsr: design-science-research
    mea: modern-elder-academy
```

## Appendix B — Migration checklist
- [ ] Run codemod (dry-run → apply).
- [ ] Run linter and confirm zero deprecated shapes remain (except transitional aliases).
- [ ] Validate that deep-links and search still resolve (IDs/slugs unchanged).
- [ ] Publish updated `registry.yaml` and `aliases.yaml` alongside the JS change.
