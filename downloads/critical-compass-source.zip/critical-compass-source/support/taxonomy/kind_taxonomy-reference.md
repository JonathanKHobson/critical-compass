# Kind taxonomy (reference)

_Generated 2025-09-28 — source: templates.data.js_

## Canonical kinds (proposed)

- `framework` — _(desc placeholder)_
- `strategy` — _(desc placeholder)_
- `technique` — _(desc placeholder)_
- `heuristic` — _(desc placeholder)_
- `practice` — _(desc placeholder)_
- `helper` — _(desc placeholder)_

## Observed kinds (discovered)

| kind | count | example ids |
|---|---:|---|
| `framework` | 155 | abcde, avm_framework, bab, clear, clear_path, clear_pm, costar, epic_quest |
| `strategy` | 92 | a3_ps, addie, aida, argument-map, bias_impact_assessment, eightfold_path, cognitive_debiasing, comparative_analysis |
| `heuristic` | 15 | two_min_rule, kipling_5w1h, anekantavada_syadvada, bias_interrupters, blooms, east_nudge, first_principles, debiasing-checklist |
| `technique` | 14 | active_imagination, empty_chair, few_shot, facts_primer, feynman, goal_breakdown, goal_composition, goal_prompting |
| `tool` | 14 | personal_kanban_wip, decision_matrix_weighted, checklists_gawande, sbar_health_dx, soap_health_dx, askme3_health_dx, teach_back_health_dx, red_flag_plan_health_dx |
| `facilitation` | 7 | world_cafe, open_space_technology, liberating_structures_bundle, restorative_circles_deep_democracy, nvc_needs_based_dialogue, story_circles_harvesting, dot_voting_heatmap |
| `helper` | 2 | pattern-picker, pattern-picker |


## Items to review

| kind | count | examples | note |
|---|---:|---|---|
| `tool` | 14` | personal_kanban_wip, decision_matrix_weighted, checklists_gawande, sbar_health_dx, soap_health_dx | Not in canonical set; propose mapping or justification. |
| `facilitation` | 7` | world_cafe, open_space_technology, liberating_structures_bundle, restorative_circles_deep_democracy, nvc_needs_based_dialogue | Not in canonical set; propose mapping or justification. |

## Dos and Don’ts

**Do**
- Keep kinds few and stable; prefer mapping long-tail values via aliases.
- Use tags for nuance (method names, modalities, processes).
- Document rationale when introducing a new kind.

**Don’t**
- Don’t mirror categories or tags; kind is the top-level role/shape.
- Don’t proliferate synonyms or adjective variants.
- Don’t encode levels or phases into kind — use tags instead.
