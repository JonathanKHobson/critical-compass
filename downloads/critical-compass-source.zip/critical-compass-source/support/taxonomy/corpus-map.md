# Corpus Map

## Top-level categories

- biases
- reasoning-frameworks
- thinking-lenses
- fallacies
- heuristics
- methodology-checks
- other

## other subdomains

- paradoxes
- prompting
- decision-cases
- social-dynamics
- ai-governance
- adjacent

## Retrieval tips

- Search by alias first, then use/topic/phase facets.
- Use `indexes/reverse/*.json` for deterministic lookup.
- Use `indexes/graph/concept-graph.json` for parent, child, and see-also paths.
- Use `indexes/review-holdout.json` to inspect ambiguous routing.
