# Support

## Subfolders

- `library/` local source metadata and schemas
- `taxonomy/` local taxonomy source copies plus corpus guidance
- `registry/` generated alias registry
- `schema/` generated record and index schema docs
