# Critical Compass Reasoning Flows

Reasoning flows are file-backed, read-only executable protocols for Critical Compass concepts. They are intentionally stored outside the SQLite concept corpus so flow iteration does not require a schema migration.

## Files

- `reasoning-flow.schema.json` defines the required flow and step fields.
- `phase2-step1-gaps.flows.json` contains one flow for each Phase 2 Step 1 concept addition.
- `research-methodology.flows.json` contains research-audit flows for replication readiness, sampling/generalizability, and self-report/demand-effects checks.

## Namespaces

- `epistemic_core` is the default Compass lane for reasoning lenses, bias-reduction models, argumentation, uncertainty, systems, structural, ethical, and methodology flows.
- `applied_reasoning` is the artifact lane for professional documents, communication, product, career, planning, and execution templates. These flows must audit judgment, evidence, constraints, risks, and tradeoffs before producing an artifact.

## Regeneration

1. Run `node scripts/build-phase2-step1-gaps.mjs` to rebuild the concept pack and flow schema/docs.
2. Run `node scripts/build-critical-thinking-corpus.mjs`.
3. Run `node scripts/build-phase2-step1-gaps.mjs --flows` so flows use normalized `ct:<category>:<subcategory>:<slug>` entry IDs.
4. Run `seed_db.py` to refresh the read-only MCP database.

Do not hand-edit generated Phase 2 flows unless the generator is updated to preserve the change.

`research-methodology.flows.json` is a curated MCP ergonomics pack, not generated Phase 2 output. Keep it small and focused on research-audit gaps that affect `advanced_audit(text_type="research")`.
