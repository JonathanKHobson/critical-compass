# advanced_audit MCP Tool

`advanced_audit` is a read-only companion to `audit_text`. Use `audit_text` for a fast conservative bias and assumption scan; use `advanced_audit` when the caller needs model selection, staged reasoning scaffolds, MCP-backed verification calls, or multi-perspective analysis.

## Execution Boundary

Critical Compass is the knowledge-base, retrieval, verification, model-selection, and scaffold layer. The host AI is the reasoning and rendering layer. Unless a future server-side LLM runtime is added, `advanced_audit` and its stage tools return `status: scaffold_ready` and `execution_required: true`; they must not return placeholder Round 1, debate, or synthesis content that looks like completed analysis.

The host AI should execute the returned instructions, call the recommended MCP tools at the requested moments, and render the final user-facing analysis. Raw MCP JSON should not be shown to the user.

## Input

Required:

- `subject`: text, topic, claim, decision, or challenge to analyze.
- `mode`: one of `user_selected`, `ai_selected`, or `agent`.

Optional:

- `selected_flow_id`: required only for the second `user_selected` call.
- `domain_hint`: user-supplied domain context.
- `sensitivity`: passed through the same sensitivity convention used by `audit_text`.
- `text_type`: one of `general`, `advocacy`, `policy`, `sales`, `research`, `journalism`, `narrative`, `social_media`, `academic_abstract`, `product_copy`, `legal`, or `ai_generated`; `other` is accepted as `general`.
- `synthesis_audience`: one of `reader`, `author`, or `both`; defaults to `both`.
- `max_candidate_models`: maximum model-pool size; Agent Mode defaults to eight candidates.
- `resume_from`: one of `agent_definition`, `independent_analysis`, `tension_map`, `debate`, or `synthesis`.
- `prior_stage_payload`: stateless resume payload containing completed prior outputs such as `agents`, `analyses`, `tensions`, `debate`, or `biases_found`.
- `depth`: one of `quick`, `standard`, or `deep`; defaults to `standard`.
- `snapshot_mode`: one of `organizer` or `research`; defaults to `organizer`.
- `scaffold_detail`: one of `compact`, `full`, or `handoff`; defaults to `compact`.

## Flow Namespaces

- `epistemic_core`: default lane for reasoning lenses, bias-reduction models, argumentation, uncertainty, systems, structural, ethical, and methodology flows.
- `applied_reasoning`: artifact lane for professional documents, communication, product, career, planning, and execution templates.

`advanced_audit` defaults to `epistemic_core`. It includes `applied_reasoning` only when the subject clearly asks for a deliverable, such as writing, drafting, rewriting, preparing, polishing, or turning material into a specific artifact.

## Modes

- `user_selected`: first call returns four candidate flow-backed models with rationales and `selection_required`; second call with `selected_flow_id` returns the selected flow execution package.
- `ai_selected`: selects one best-fit flow and returns a scaffold for the host AI to execute.
- `agent`: returns a relevance-ranked model pool, Quick-Scan Card starter, tool inventory check, stage plan, stateless resume contract, and stage-specific execution scaffolds.

## Agent Mode Split-Orchestrator

Agent Mode returns:

- `subject_text`
- `prepopulated_quick_scan_card`
- `prepopulated_critical_integrity_snapshot`
- `candidate_model_pool`
- `low_relevance_model_examples`
- `tool_inventory_check`
- `stage_plan`
- `resume_contract`
- `agent_design_protocol`
- `framework_attachment_rules`
- `execution_protocol`
- `output_format`
- `quality_gates`
- `quality_gate_details`
- `overkill_warning`

Depth behavior:

- `quick`: render only the Quick-Scan Card and Critical Integrity Snapshot scaffold from `audit_text`; do not run agent definitions, independent analyses, tension mapping, debate, or synthesis.
- `standard`: execute the full six-stage scaffold below.
- `deep`: execute the full six-stage scaffold and add Step 6b, a mitigation rewrite of the most problematic sentence.

The host AI executes the standard/deep protocol:

0. Honor the Human Loop gates before exposing advanced audit work. Guided is the default user-facing mode. Silent mode requires user-confirmed consent in `human_loop_state` or an explicit noninteractive smoke-test override. If an unauthorized silent request returns stage `mode_consent`, ask the one consent prompt first and default to guided when the answer is skipped or ambiguous. If `human_loop_host_action.must_pause=true`, use Claude Desktop/Codex native question UI first when available, ask only the current `questions_for_user` block, and never ask the full Human Loop questionnaire at once. If stage `onboarding`, ask the onboarding prompts before the core audit. If stage `judgment`, ask the raw-read prompts before revealing findings, scores, bias labels, or agent scaffolds. If stage `reflection`, show only `preview_before_reflection`, ask the reflection prompts, then generate the final chat/Markdown/PDF output. Only skip a gate for an explicitly noninteractive smoke test, and disclose the skipped pending prompt IDs.
1. `lookup_bias("confirmation bias")` - silently set MCP-Enhanced Mode or Reference Mode.
2. `define_audit_agents` - define four distinct analyst personas before analysis.
3. `run_independent_audit_analysis` - run one first-person analysis per agent and surface evidence relevant to Critical Integrity Snapshot dimensions.
4. `map_audit_tensions` - identify live disagreements, evidence gaps, frame collapses, and disputes that could change the snapshot label, confidence, comparability, or profile-only state.
5. `run_audit_debate` - stage one grounded three-turn debate from the sharpest resolvable tension.
6. `synthesize_audit_verdict` - commit to one verdict, confirm/revise/withhold the Critical Integrity Snapshot, revise the Quick-Scan Card if needed, and call `suggest_next_steps`.
7. Deep mode only: `propose_mitigation_rewrite` - produce the Step 6b sentence rewrite after synthesis.

Optional report output happens after synthesis only. If a report is requested, the host AI calls `generate_audit_report` with completed audit/synthesis data. The MCP normalizes, validates, renders, QA-checks, and returns the PDF path, preview images, versions, payload hash, accepted aliases, and any schema warnings. Report generation is not required for audit completion. If `schema_warnings` or `missing_report_fields` are returned, tell the caller what is missing and ask whether to re-submit the missing data or continue with placeholder text before presenting the PDF as final. If warnings mention pending human-loop prompts, ask those prompts or get explicit noninteractive-test permission before presenting the report as final.

The stage tools are stateless. They return instructions, required inputs, recommended MCP calls, output schemas, and quality gates. They do not store or retrieve prior stage output. The host AI must pass completed stage artifacts forward.

Compact stage responses include `stage_brief`, which states the current stage, required inputs, expected output, required MCP calls, and stop condition before the longer schema. Use `scaffold_detail="handoff"` for small-context agents; it returns the stage handoff, required output fields, and concise visible-reasoning contract without repeating long schemas. Use `scaffold_detail="full"` only when the host AI needs the complete quality-gate list.

## Stage Tool Contracts

Every stage tool returns:

- `tool`
- `status: "scaffold_ready"`
- `execution_required: true`
- `stage`
- `stage_title`
- `host_ai_directive`
- `required_inputs`
- `recommended_mcp_calls`
- `output_schema`
- `quality_gates`
- `quality_gates_core`
- `quality_gate_details`
- `stage_brief`
- `visible_reasoning_contract`

The visible-reasoning contract is: show concise warrant-level reasoning such as `claim -> warrant -> missing evidence -> implication`; do not expose hidden chain-of-thought.

### define_audit_agents

Defines four analyst personas. Each persona must include name, epistemic archetype, reasoning philosophy, primary and secondary reasoning style, tool affinity, decision-making voice, characteristic blind spot, and optional framework attachment.

Available reasoning styles:

- Chain of Thought
- Tree of Thought
- Socratic Questioning
- Systems Thinking
- Steelman-first
- Missing Voice

Frameworks in `candidate_model_pool` are optional attachments. The host AI must attach only high-relevance candidates, use medium-relevance candidates only when the fit is text-grounded, and prefer `framework_attachment: null` over attaching an irrelevant model.

Each persona should have 2-3 tool affinities. Examples: Socratic agents prefer `challenge_claim` and `get_reasoning_flow`; Systems agents prefer `get_framework("systems thinking")` and `search_knowledge_base`; Missing Voice agents prefer stakeholder or cross-cultural lenses plus `lookup_bias`.

For Indigenous health equity, tribal/First Nations, public-health measurement, data governance, food sovereignty, or community-evaluation text, include a data-sovereignty or measurement-accountability lens. Retrieve KB IDs before naming OCAP, CARE Principles, Indigenous data sovereignty, data erasure, food sovereignty, relational accountability, or community authority frameworks. If no lookup was performed, mark the label as host inference rather than KB-grounded.

### run_independent_audit_analysis

Instructs the host AI to perform one first-person analysis per agent. Each analysis must reference actual subject-text language, name at least one bias or structural assumption, challenge one settled claim, surface the agent's own blind spot, map at least one finding to a Critical Integrity Snapshot dimension, and close with one question for the room.

Required MCP threading in MCP-Enhanced Mode:

- Use `lookup_bias` after naming a bias.
- Use `search_knowledge_base` when the bias pattern is visible but the label is uncertain.
- Use `challenge_claim` at least once per agent.
- Use `get_framework` or `get_pattern` for alternative framing.
- Use `list_reasoning_flows` and `get_reasoning_flow` when an agent's reasoning style clearly matches an executable flow.
- For Indigenous health equity or community-data contexts, use `search_knowledge_base` / `get_framework` before naming OCAP, CARE, Indigenous data sovereignty, data erasure, food sovereignty, relational accountability, or community measurement lenses.

Each bias finding should include a Three Cs label: `Critical`, `Compassionate`, or `Creative`.

Every fallacy risk must include Steelman Risk: when the same pattern is not a fallacy.

The output schema includes `snapshot_dimension_evidence`; use it to name which of the five snapshot dimensions the agent's finding could raise, lower, make less comparable, or push toward profile-only display.

### map_audit_tensions

Instructs the host AI to produce 3-5 tensions before debate. Each tension names two agents and uses one label:

- `RESOLVABLE`
- `UNRESOLVABLE`
- `NEEDS_EVIDENCE`
- `FRAME_COLLAPSE`

Use `FRAME_COLLAPSE` when one agent's finding invalidates another agent's framing.
Accept `NEEDS EVIDENCE` as an input alias, but normalize output to `NEEDS_EVIDENCE`.
Flag any tension that could change the Critical Integrity Snapshot label, confidence, comparability, or profile-only state.
The output schema includes `snapshot_impact`; use it when a disagreement could alter the aggregate score, suppress the aggregate, or change confidence/comparability.

### run_audit_debate

Instructs the host AI to select the sharpest `RESOLVABLE` tension and stage a three-turn exchange. At least two turns must quote or tightly reference actual subject-text language. Each agent must keep its defined reasoning style; new bias or fallacy risks surfaced during debate should trigger inline `lookup_bias` or `challenge_claim`.

### synthesize_audit_verdict

Instructs the host AI to commit to one verdict, state the strongest counterargument, give one concrete mitigation, and call:

```json
{
  "tool": "suggest_next_steps",
  "arguments": {
    "domain": "<text_type>",
    "biases_found": ["<bias name or ID>"]
  }
}
```

`biases_found` must be a JSON array of bias names or IDs. In MCP-Enhanced Mode, the primary bias or structural problem should include a KB ID. The synthesis must confirm the prepopulated Critical Integrity Snapshot, revise it with traceable reasons, or withhold the aggregate and return profile-only mode. For research/study text, synthesis should also confirm or revise the separate `replication_readiness` companion signal.

### propose_mitigation_rewrite

Deep mode uses `propose_mitigation_rewrite` as the dedicated Step 6b scaffold after synthesis. It selects one problematic sentence, rewrites it to reduce the primary bias or structural problem, and explains what changed without adding unsupported facts.

## Lens Cards And Fairness-To-Text

Advanced audit scaffolds should retrieve compact lens cards instead of loading broad prompt material. Use the returned `retrieval_budget`, `selected_lens_ids`, and `selection_reasons` fields as the active context. Advanced mode may use up to 8 standard lens cards. Named lenses, biases, frameworks, and non-Western concepts should include KB IDs; if a label comes from host reasoning without lookup, mark it `host_inference`.

Before final bias/framing conclusions, run the `fairness_to_text` check. Preserve the strongest charitable reading, name genre/context constraints, carry forward expected non-findings, and downgrade critique that the text does not actually justify. This stage is host-facing QA metadata in beta.10; it should not create a default PDF page.

## Critical Integrity Snapshot

`audit_text` computes a deterministic `critical_integrity_snapshot` after bias, assumption, methodology, and framing signals are available. It is a criterion-referenced snapshot, not a report card.

Rules:

- Do not output A-F grades.
- Do not render points as percentages.
- Use descriptive labels first and points second.
- Keep confidence and comparability separate from points.
- Use `profile_only` when an aggregate label and points would be misleading.
- Every dimension should trace to concrete findings.
- The final prompt starts with `Before using this text`.

Snapshot labels:

- `85-100`: `Exemplary Integrity`
- `70-84`: `Strong Integrity`
- `50-69`: `Moderate Integrity`
- `25-49`: `Limited Integrity`
- `0-24`: `Needs Scrutiny`

Snapshot dimensions:

- `Grounding & Scope Fit`
- `Assumptions & Context`
- `Bias Transparency`
- `Framing & Audience Openness`
- `Positionality & Power`

The context lens detects evidence convention and rhetorical purpose, not cultural identity:

- `evidence_convention`: `citation_based`, `experiential_testimony`, `institutional_reporting`, `communal_consensus`, `hybrid`, or `unclear`
- `purpose`: `inform`, `persuade`, `mobilize`, `document`, `narrate`, or `mixed`
- `voice`: `first_person`, `collective`, `institutional`, `mixed`, or `unclear`

## Resume Model

`advanced_audit` accepts `resume_from` and `prior_stage_payload` for stateless continuation. For durable continuation, call `save_audit_progress` after each completed stage and call `get_audit_progress` before resuming. Pass the loaded `prior_stage_payload` back into `advanced_audit`. When the CIS changes mid-audit, include `cis_revision_event` in `save_audit_progress`; call `get_cis_revision_timeline` to review confidence decay, score revisions, aggregate withholding, and comparability changes.

Examples:

```json
{
  "resume_from": "independent_analysis",
  "prior_stage_payload": {
    "agents": ["<completed agent cards>"]
  }
}
```

When the audit is complete, call `save_audit_result` with the final Critical Integrity Snapshot, biases found, verdict, and replication readiness. The saved result preserves the context lens plus knowledge/rhetorical tradition so longitudinal CIS comparisons are calibrated to the same evidence frame. `list_audit_results` supports CIS score filters (`cis_score`, `cis_score_min`, `cis_score_max`, `cis_score_below`) and dimension filters (`dimension_name`, `dimension_score_below`) for longitudinal review.

If `generate_audit_report` was called, include `report_id`, `report_path`, `template_version`, `render_version`, `payload_schema_version`, `payload_hash`, and any non-empty `schema_warnings` in `save_audit_result.result_payload`.

Use `scaffold_detail="handoff"` when context is tight. Each stage returns `stage_handoff` with required inputs, required calls, output fields, carry-forward keys, stop condition, common failure, and delta from the prior stage. Handoff mode is still a scaffold; the host AI must perform the reasoning.

Use `save_bias_pattern` or `save_entity_pattern` after synthesis when a recurring bias, thinking lens, reasoning flow, or framework pattern should be tracked across audits.

## User Additions Overlay

The canonical KB is read-only. User-added KB records live in the writable state store and are mirrored to `support/library/user-additions.pack.json` when active. `save_kb_addition` defaults to `status="draft"`; active overlay exposure requires `status="active"` and `confirm_active=true`.

Before saving, the MCP checks canonical and user-overlay entries for duplicate names and aliases. If a likely duplicate is found, the tool should return the existing candidate and suggest using it or adding the new label as an alias instead of creating a competing entry.

Every user-added KB entry should include `rhetorical_tradition`: `western_academic`, `testimonial`, `indigenous_oral`, `ubuntu`, `confucian`, `liberation_pedagogy`, or `other`.

```json
{
  "resume_from": "debate",
  "prior_stage_payload": {
    "agents": ["<agent cards>"],
    "analyses": ["<analysis entries>"],
    "tensions": ["<tension entries>"]
  }
}
```

## Quick-Scan Card

`audit_text` still owns the initial fast scan. `advanced_audit` includes `prepopulated_quick_scan_card` from `audit_text`; the host AI should render that card first and revise it only if the full staged analysis materially changes the top bias, primary tension, verdict, or next action.

The final card should include:

- Mode
- Text type
- Sensitivity
- Top 3 biases with KB IDs where available and Three Cs labels
- Critical Integrity Snapshot: label or profile-only state, points only when scored, confidence, comparability, context lens, five dimensions, and `Before using this text` prompt
- Primary tension
- Verdict
- Recommended action
- Reasoning styles used

## audit_text Calibration Companion

`audit_text` includes a `quick_scan_card`, `critical_integrity_snapshot`, and accepts the same `text_type` values. `research` and `academic_abstract` remain conservative and methodology-heavy; `advocacy`, `policy`, `sales`, `product_copy`, and `social_media` allow deterministic persuasive-text cue detection for uniqueness framing, existential escalation, unsupported certainty, audience-erasing claims, and selected comparison sets. `legal` is reviewed for argument, evidence, assumptions, and power without implying legal advice. `ai_generated` emphasizes LLM-bias risk, synthetic certainty, polished-but-unsupported claims, and missing provenance. `narrative` is accepted for story-shaped inputs; `other` maps to `general`.

`retrieval_profile` accepts `auto`, `general`, and `research_methodology`. In `auto`, research text or method cues select the methodology profile, which prioritizes study-design, validity, and replication concepts before generic cognitive-bias labels.

For research/study-shaped text, `audit_text` also returns `replication_readiness` as a companion signal separate from CIS. It checks sample/population clarity, measures/outcomes, design/analysis, context/conditions, and preregistration/reproducibility.

The research-methodology KB packs add lookups for WEIRD bias, demand characteristics, social desirability bias, overgeneralization, publication bias, p-hacking, HARKing, sampling/selection bias, nonresponse bias, attrition bias, construct validity, external validity, ecological validity, measurement validity, internal validity, replicability, preregistration, and statistical power.

The AIGlossary cross-check target is tracked as an external corpus reference; beta.10 baseline rows with `kind` equal to `bias` or `llm-bias` should resolve to an MCP bias entry by ID or title. Newer draft gap-fill batches in that external glossary should be reported as deferred coverage until they are intentionally imported into the Critical Compass corpus.

## Complementarity

Agent Mode prefers different epistemic jobs when available:

- Evidence / argument
- Systems / causal
- Uncertainty / methodology
- Structural / relational / ethical
- Creative / reframing
- Communication / task execution, only when the user asks for a deliverable

For governance, policy, advocacy, community, equity, stakeholder, or harm-related texts, the host AI should include a Missing Voice or Absent Stakeholder persona by default.

Agent mode must preserve visible agent identity through the final render: include an Agent Roster before independent analyses and an Agent Contribution Matrix in synthesis naming each agent's strongest contribution, affected CIS dimension, blind spot, and whether the agent changed the verdict.
