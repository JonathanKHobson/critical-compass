# Alias Registry

- Total aliases: 2150
- Collisions: 46

Generated alias registry for canonical lookup, exact-match aliases, and near-synonym access.
