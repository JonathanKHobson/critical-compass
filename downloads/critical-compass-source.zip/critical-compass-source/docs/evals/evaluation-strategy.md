# Critical Compass Evaluation Strategy

## Evaluation Goals

- Confirm new audit artifacts are meaningful, conservative, and useful.
- Confirm report readiness prevents blank or placeholder stakeholder reports.
- Confirm host-AI scaffolds reduce malformed tool calls.
- Confirm external-tool trust boundaries are explicit before integrations are enabled.
- Confirm fact-check support stays scaffold-first by default, with provider-backed retrieval consent-gated, factual-claim-only, privacy-guarded, and no-network in automated tests.
- Confirm future prompt/scaffold changes can be traced to eval outcomes before they are treated as product improvements.

## Fixture Families

| Fixture Family | Purpose |
|---|---|
| Short insufficient text | Ensure CIS/profile-only and report readiness do not overclaim. |
| Advocacy or organizer text | Test missing voice, assumptions, action prompts, and report handout. |
| Research-methodology text | Test check-worthy factual claims, evidence-needed table, and methodology traps. |
| Narrative/testimonial text | Test positionality, harmed stakeholder prompts, and non-extractive language. |
| Advanced multi-agent audit | Test dissent ledger and provenance. |
| Host-AI malformed payload | Test scaffold examples and readiness warnings. |
| OCR-heavy PDF source | Test explicit source preflight, Apple Vision OCR, and low-text embedded PDF detection. |
| Report artifact screenshots | Test visual availability for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks. |
| Fact-check lookup fixtures | Test opt-in gating, trusted publisher filtering, no-match, conflicting reviews, sensitivity block, provider errors, and cache behavior without live network. |
| Prompt/scaffold version cases | Test whether a prompt or scaffold version change improves behavior without increasing over-critique, lens over-selection, or report-readiness misses. |
| Trace-to-fixture candidates | Preserve failed run traces as reviewed candidate fixtures before any gold-case mutation. |

## Artifact-Level Checks

- `argument_map` includes central claim, support, objections, assumptions, missing voices, and evidence gaps.
- `.argdown` export preserves claims and relations without inventing evidence.
- `checkworthy_claims` ranks only factual claims and marks interpretive, causal, normative, and policy claims separately.
- Dissent ledger contains each agent's top finding, strongest disagreement, confidence, and what would change its mind.
- Report artifacts include Questions to Bring to the Text and Evidence Needed Next when requested.
- Placeholder and fallback report sections are blocked unless draft placeholders are explicitly allowed.
- OCR preflight returns audit-ready text, page images, extraction method, and warnings before an audit consumes PDF content.
- Report artifact screenshots are generated with stable section-to-page manifests for visual inspection.
- `factcheck_lookup` defaults to guided research with no retrieval, warns loudly for deprecated `auto`, searches a local ClaimReview index when explicitly selected, harvests approved publisher ClaimReview markup only after consent, skips provider-backed retrieval for non-factual claims, blocks sensitive claims by default, quotes publisher ratings verbatim when retrieval is explicitly used, and preserves conflicting reviews.

## Human Review Rubric

Score each new artifact from 1 to 5:

- Clear enough for a non-expert.
- Conservative enough not to overclaim.
- Specific enough to change behavior.
- Traceable enough to understand where it came from.
- Useful enough to survive outside the audit session.

For future Compass Eval Studio work, human review should also mark:

- whether the critique overreaches the text
- whether expected non-findings were violated
- whether selected lenses were relevant to visible text cues
- whether report QA failures are delivery bugs or payload problems
- whether a failed trace should become a candidate fixture

## Agenta-Inspired Reliability Loop

Agenta is a reference model for evaluation workflow shape, not a runtime dependency. The pattern to borrow is:

1. Register prompt/scaffold versions locally.
2. Capture opt-in stage traces for audit runs.
3. Diagnose which stage caused a failure.
4. Convert failed traces into reviewed candidate fixtures.
5. Compare prompt/scaffold versions side by side on the same cases.
6. Add human review for ambiguous failures.
7. Promote only reviewed fixtures into regression gates.

The planned local trace spans are: source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA. Trace metadata must stay host-facing or maintainer-facing and must not appear in reader-facing PDF, HTML, or Markdown reports.

Compass Eval Studio planning is considered complete when `docs/planning/ideas/compass-eval-studio/` contains `overview.md`, `prd.md`, `phase-roadmap.md`, `slice-roadmap.md`, `tickets.md`, and `evaluation.md`; every `CES-01` through `CES-13` ticket maps to a P2/P3 phase; and the docs state that failed traces become reviewed fixture proposals rather than automatic gold fixtures.

## Future Observability / Routing / Provenance Evaluation Notes

The Langfuse, Strata, Graphiti, and Eureka research is captured as a future planning lane, not a runtime dependency. Future tests should verify:

1. `RunTrace` records route decisions, validators, repair counts, latency, token estimates, and artifact paths without raw private text by default.
2. `RetrievalRunSummary` records selected and omitted lens IDs, candidate counts, ranking features, selection reasons, and precision flags.
3. `ToolRouterDecision` narrows allowed next tools while preserving repair instructions and widget-required state.
4. `TemporalFact` preserves provenance and supersession without silent deletion or memory mutation.
5. `ContextSelectionMap` explains selected and omitted context with budget and truncation status.

Planning is complete when `docs/planning/ideas/compass-observability-routing-temporal-map/` contains `overview.md`, `prd.md`, `phase-roadmap.md`, `slice-roadmap.md`, `tickets.md`, and `evaluation.md`; every `CORTM-01` through `CORTM-12` ticket maps to P2 or P3; and the docs state that Critical Compass does not own Atlas or Kyle Second Brain temporal memory implementation in this lane.

## Regression Checks

- Existing writable-state validation still passes.
- Existing research-audit coverage validation still passes.
- Existing report renderer validation still passes.
- Human-loop gates still pause host AIs at onboarding, judgment, and reflection.
- PDF report generation remains optional and does not block audit completion.
- The 36 Questions smoke path passes: `prepare_audit_source -> audit_text -> advanced_audit -> synthesize_audit_verdict -> generate_audit_report`.
- PyMuPDF/WeasyPrint text extraction checks tolerate PDF line-break hyphenation without hiding true missing-content defects.
- Benchmark-coverage docs list implemented, partial, planned, deferred, and rejected ideas to prevent idea drift.
- `scripts/validate_factcheck_lookup.py` passes with mocked provider responses and no live API key.
- Future trace capture remains opt-in or fixture-only and never captures raw private text by default.
- Future prompt/scaffold registries can explain which version shaped a failed eval case.

## Success Threshold

Phase 1 is ready for implementation completion when all golden fixtures produce meaningful `argument_map`, `checkworthy_claims`, and report-readiness outputs with no new blocking regressions.

Current smoke status as of 2026-04-15: the 36 Questions OCR/report smoke passed with Apple Vision OCR, a 15-page report, no PDF QA issues, and golden artifact screenshots written under `reports/smoke-36-questions/golden-report-artifacts/`.
