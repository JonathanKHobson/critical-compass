# Compass Public Page Contract

Critical Compass, Prompt Compass, and UX Heuristics Compass share the same individual-product page contract.

- Tabs must stay in this order: `Get Started`, `About`, `Install Guide`, `Example`, `FAQ`, `Advanced`.
- The top download area uses three cards: plugin, Desktop Extension/MCPB, and skill/prompt-only.
- The skill card must include both `Download Skill` and `Download Skill Zip`.
- `Pick Your Path` must be goal-based `I want...` rows, not a repeat of install methods.
- `What's Inside` owns the tool inventory. Do not add a separate `Tool Overview` section.
- The install guide uses the shared card-grid layout and keeps verified-install notes honest.
- The Advanced tab uses these labels: `View full release notes`, `Download source files`, `Download Source Zip`, and `Advanced: Verify Download`.
- Public validators should fail on `About & FAQ`, `Tool Overview`, local paths, sidecars, placeholders, and stale pending-download copy.
