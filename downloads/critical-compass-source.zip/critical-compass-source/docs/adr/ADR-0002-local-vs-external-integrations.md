# ADR-0002: Local-First Versus External Integrations

## Status

Accepted for planning.

## Context

Some adjacent tools provide external lookup, research search, fact-check APIs, or marketplace discovery. These are useful but introduce privacy, network, availability, cost, prompt-injection, and provenance risks.

## Decision

Critical Compass defaults to local-first, self-hostable, or easily rebuilt capabilities. External integrations are optional later-phase features and must be:

- explicitly requested or enabled by the user;
- separated from core audit scoring;
- labeled as external evidence or external lookup;
- protected by a source/tool trust preflight.

Core audits do not automatically search the web or retrieve facts.

2026-04-15 update: the optional `factcheck_lookup` tool is accepted under this ADR because it is explicit, consent-gated, provider/allowlist scoped, privacy-guarded, separate from core audit scoring, and labeled as retrieved external evidence rather than a truth verdict.

## Consequences

- Check-worthy claims rank verification priority without checking the claims by default.
- `factcheck_lookup` may retrieve published fact checks only when explicitly invoked for factual check-worthy claims.
- Research tools can inspire evidence-needed structures before becoming integrations.
- External APIs such as Google Fact Check Tools, ClaimBuster-style systems, Elicit, Scite, Consensus, or Idea Reality are optional integrations, not dependencies.
