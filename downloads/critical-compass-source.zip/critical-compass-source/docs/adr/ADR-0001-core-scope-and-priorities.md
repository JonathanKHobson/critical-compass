# ADR-0001: Core Scope And Priorities

## Status

Accepted for planning.

## Context

Benchmark research surfaced many adjacent MCPs and products: reasoning tools, ethics checkers, fact-check wrappers, argument mapping apps, prompt workflow managers, and MCP security scanners. Critical Compass could absorb too much from this landscape and lose its identity.

## Decision

Critical Compass remains one focused audit system centered on bias and assumption auditing, CIS, human-in-the-loop reflection, saved patterns, and stakeholder-ready reports.

The first implementation priority is:

1. Argument map output.
2. Check-worthy claims extraction.
3. Scaffold registry and canonical examples.
4. Report-readiness hardening.

## Consequences

- MCP marketplace discovery is not a core product feature.
- Optional integrations are later-phase and consent-gated.
- UI exploration waits until the core artifacts prove useful.
- Planning and tickets must justify every addition against the core audit mission.
