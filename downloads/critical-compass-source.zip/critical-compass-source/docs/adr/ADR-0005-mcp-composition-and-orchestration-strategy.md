# ADR-0005: MCP Composition And Orchestration Strategy

Status: Accepted
Date: 2026-04-15

## Context

Critical Compass has reviewed several adjacent thinking, fact-checking, and reasoning MCPs. Some are useful pattern references, some are too large or license-sensitive, and some should remain external or rejected.

Directly merging many MCPs would create scope bloat, unclear semantics, and trust problems.

## Decision

Critical Compass will classify MCP candidates into five modes:

- `merged_internal`
- `wrapped_internal`
- `orchestrated_external`
- `prompt_scaffold_only`
- `rejected`

The repo will maintain a machine-readable capability registry and internal route-planning helpers. This phase will not add a public orchestration tool.

## Rationale

This keeps one coherent product surface while allowing useful outside ideas to inform local implementation. It also prevents third-party MCPs from replacing Critical Compass judgment, plurality review, report readiness, or synthesis.

## Consequences

Positive:

- clearer integration decisions
- safer use of local study-library evidence
- stable public tool semantics
- explicit fallback paths

Negative:

- more planning overhead before external integrations
- future orchestration requires review work before it can ship
