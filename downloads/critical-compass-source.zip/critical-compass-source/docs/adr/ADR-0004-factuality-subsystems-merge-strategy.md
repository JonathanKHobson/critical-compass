# ADR-0004: Factuality Subsystems Merge Strategy

Status: Accepted
Date: 2026-04-15

## Context

Critical Compass needs stronger support for claim selection, verification scaffolding, factual retrieval, and factuality evaluation without turning the product into a provider-key-dependent fact-check wrapper.

Three adjacent inspirations were reviewed:

- FactRank: check-worthiness ranking, not truth verification.
- Fact-Check Tools MCP: useful adapter shape, but Google-first and API-key-dependent.
- OpenFactCheck: useful factuality-evaluation architecture, but too large and semantically different for a direct merge.

## Decision

Critical Compass will use a layered strategy:

1. Adapt FactRank's distinction between worth checking and false into `checkworthy_claims`.
2. Adapt Fact-Check Tools MCP as an interface pattern only; reject Google-first default behavior.
3. Adapt OpenFactCheck as future evaluation architecture only; do not embed it into the core audit path.
4. Keep `factcheck_lookup` scaffold-first by default, local retrieval opt-in when indexed, direct publisher harvest consent-gated, and optional providers later.
5. Route future third-party MCP decisions through the MCP capability registry and ADR-0005/ADR-0006 before any merge or external orchestration.

## Consequences

Positive:

- Clearer public contract.
- No required API key or provider account.
- Better fit with epistemic framing and plurality review.
- Easier future local ClaimReview/direct publisher retrieval.

Negative:

- Default fact-check output is a scaffold, not retrieval.
- Host AIs must use their own browsing tools for current verification work.
- Local retrieval still requires a later implementation phase.

## Guardrails

- Never treat check-worthy as false.
- Never treat retrieval as complete epistemic coverage.
- Never let factuality subsystems erase framing, assumptions, power, or plurality analysis.
- Preserve conflicts and uncertainty explicitly.
