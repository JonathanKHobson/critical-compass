# ADR-0006: External MCP Trust And Fallback Policy

Status: Accepted
Date: 2026-04-15

## Context

External MCPs can add useful capabilities, but they may also introduce hidden instructions, data exposure, license problems, unstable dependencies, or epistemic drift.

## Decision

No external MCP may be orchestrated by Critical Compass unless it has:

- registry entry
- license notes
- dependency and maintenance notes
- transport/security review notes
- data-exposure notes
- trust-risk classification
- fallback mode
- provenance-labeling requirements

Rejected MCPs cannot be routed. Scaffold-only candidates cannot be described as retrieval or live tool use.

## Fallback Order

1. Native Critical Compass module
2. Approved local helper
3. Prompt scaffold for the host AI
4. Structured not-available result

## User-Facing Disclosure

When an external MCP influences output, the host AI must label that influence and state what data was sent, what the MCP returned, and what Critical Compass still owns in final synthesis.
