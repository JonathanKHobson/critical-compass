# ADR-0003: Tools Versus Prompts Versus Resources Versus UI

## Status

Accepted for planning.

## Context

Critical Compass can expose new capabilities as MCP tools, prompt scaffolds, resources, server instructions, elicitation flows, report artifacts, or an MCP App UI. Choosing the wrong surface increases complexity and host-AI misuse.

## Decision

Use the smallest surface that reliably changes behavior:

- Use **tool outputs** when structured data must be machine-readable or saved.
- Use **resources/prompts** when the host AI needs reusable workflow instructions or examples.
- Use **server instructions** when the host AI must obey ordering, gating, or consent rules.
- Use **elicitation flows** when missing context should come from a human.
- Use **report artifacts** when findings need to travel to stakeholders.
- Use **MCP App UI / local artifact viewer** only after stable artifacts exist; v1 must read existing artifacts and remain read-only.

## Consequences

- Phase 1 focused on tool outputs and resources, not UI.
- Host-AI onboarding rules are product requirements.
- Readiness gates belong near report generation and report workflows.
- A local read-only artifact viewer is acceptable once generated reports, Markdown, Argdown, and trust artifacts are stable.
- Interactive comparison, annotation, and hosted UI remain later optional work.
