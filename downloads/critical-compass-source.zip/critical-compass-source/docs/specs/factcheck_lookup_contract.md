# factcheck_lookup Contract

Status: accepted for scaffold-first default plus opt-in retrieval
Date: 2026-04-15

## Purpose

`factcheck_lookup` helps host AIs verify factual `checkworthy_claims` without pretending Critical Compass is a universal truth engine.

The default mode is `guided_research`. It performs no retrieval and returns a structured verification scaffold.

## Modes

| Mode | Current status | Retrieval? | Notes |
|---|---:|---:|---|
| `guided_research` | shipped default | no | Returns epistemic framing, source classes, queries, evidence trail template, and plurality review template. |
| `auto` | deprecated alias | no | Returns `guided_research` plus `provider_auto_deprecated` warning. |
| `local_claimreview` | shipped opt-in | local only | Searches the configured local ClaimReview index and sends no claim text externally. |
| `publisher_harvest` | shipped opt-in | yes | Harvests ClaimReview markup from approved publisher sites; requires `allow_external_calls=true`. |
| `publisher_site_search` | experimental | yes | Requires explicit provider and `allow_external_calls=true`. |
| `google_fact_check_tools` | experimental | yes | Requires explicit provider, API key, and `allow_external_calls=true`. |
| `brave_search` | experimental | yes | Requires explicit provider, API key, and `allow_external_calls=true`. |

## Default Output Fields

```json
{
  "status": "scaffold_ready",
  "mode": "guided_research",
  "provider": "guided_research",
  "lookup_performed": false,
  "normalized_claims": [],
  "epistemic_framing": [],
  "suggested_queries": [],
  "recommended_source_classes": [],
  "evidence_trail_template": [],
  "epistemic_plurality_review_template": [],
  "cautions": [],
  "warnings": []
}
```

## Structured Cautions

Each caution is:

```json
{
  "code": "retrieval_not_performed",
  "severity": "info",
  "message": "No retrieval was performed.",
  "applies_to_claim_id": "claim-1",
  "recommended_action": "Use host browsing or future local retrieval."
}
```

Required caution codes:

- `provider_auto_deprecated`
- `retrieval_not_performed`
- `checkworthy_not_false`
- `domain_sensitivity_high`
- `recent_or_contested_consensus`
- `non_western_coverage_not_found`
- `affected_community_not_represented`
- `private_or_sensitive_claim`
- `no_match_is_not_disproof`

## Epistemic Framing

Framing runs before verification scaffolding. It determines which sources and cautions are appropriate.

```json
{
  "claim_id": "claim-1",
  "domain": "animal_communication",
  "claim_kind": "empirical",
  "domain_sensitivity": "high",
  "known_western_bias_history": "documented",
  "consensus_age": "emerging_or_contested",
  "knowledge_communities_with_standing": [],
  "recommended_source_emphasis": [],
  "framing_notes": []
}
```

## Provider Retrieval Rules

Retrieval is optional and never runs by default.

- It never runs by default.
- It requires an explicit provider name.
- `local_claimreview` does not require `allow_external_calls=true` and sends no claim text externally.
- External retrieval modes require `allow_external_calls=true`.
- External modes send only the minimum claim text, language, publisher filter, and freshness window.
- It must preserve no-match and conflict states.
- It must never imply that no match means true or false.

## Report Rule

Scaffold-only output must not create an External Fact Checks report section. Reports may render fact-check or evidence sections only when real evidence rows or trusted matches are supplied.
