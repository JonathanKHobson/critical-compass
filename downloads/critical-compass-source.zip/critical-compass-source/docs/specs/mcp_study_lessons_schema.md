# MCP Study Lessons Schema

Status: accepted
Date: 2026-04-15

Machine-readable schema summary: `support/registry/mcp_study_lessons.schema.json`.

Canonical registry: `support/registry/mcp_study_lessons.json`.

## Required Fields

- `lesson_id`
- `source_mcp_id`
- `source_repo_path`
- `source_files`
- `lesson_type`
- `pattern_summary`
- `critical_compass_application`
- `adaptation_mode`
- `copy_policy`
- `license_caution`
- `runtime_dependency`
- `implementation_target`
- `status`
- `notes`

## Lesson Types

- `repo_structure`
- `tool_description`
- `system_prompt`
- `scaffold_resource`
- `schema_contract`
- `eval_fixture`
- `security_guardrail`
- `release_process`
- `negative_pattern`

## Adaptation Modes

- `adopt_pattern`: use the idea as a Critical Compass-owned pattern.
- `adapt_language`: rewrite the idea in Critical Compass terms before use.
- `document_only`: keep the source as planning evidence only.
- `reject`: preserve the lesson as a boundary or anti-pattern.

## Copy Policies

- `no_code_copy`: no source code or prompt text is copied.
- `summarize_only`: only short original Critical Compass summaries are allowed.
- `original_rewrite_required`: the implementation may use the idea but must rewrite it from scratch.

License-cautioned records such as AGPL or unknown-license sources must use `summarize_only` or `original_rewrite_required`.

## Runtime Rule

Every study lesson must set `runtime_dependency=false`. These records are evidence, not installed dependencies, tool calls, or permission to merge external MCPs.

## Validation

Use `mcp_composition.validate_mcp_study_lessons` in tests. Validation should fail on missing fields, unsupported enum values, duplicate lesson IDs, runtime dependencies, empty source files, empty implementation targets, or unsafe copy policy for license-cautioned sources.
