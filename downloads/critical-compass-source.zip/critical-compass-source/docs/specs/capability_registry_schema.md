# Capability Registry Schema

Status: accepted
Date: 2026-04-15

Machine-readable schema summary: `support/registry/mcp_capability_registry.schema.json`.

Canonical registry: `support/registry/mcp_capabilities.json`.

## Integration Modes

- `merged_internal`
- `wrapped_internal`
- `orchestrated_external`
- `prompt_scaffold_only`
- `rejected`

## Current Status Values

- `proposed`
- `reviewed`
- `approved`
- `experimental`
- `implemented`
- `deferred`
- `rejected`

## Local Evidence Fields

When the candidate exists in the local MCP study library, include:

- `local_source_path`
- `source_revision`
- `source_type`
- `local_inventory_status`

These fields explain where the review evidence came from. They do not imply the source is a runtime dependency.

## Validation

Use `mcp_composition.validate_mcp_capability_registry` in tests and scripts. Validation should fail on missing required fields, unsupported modes, duplicate IDs, and entries without capability lists.
