# MCP Orchestration Contract

Status: accepted
Date: 2026-04-15

## Purpose

The orchestration contract lets Critical Compass plan across local modules, prompt scaffolds, and external MCP candidates without exposing a marketplace-like public interface.

No public orchestration MCP tool is shipped in this phase.

Study-library lessons are adjacent planning evidence, not orchestration routes. They may inform routing policy only after being rewritten into a capability registry entry or scaffold resource.

## Route Output

Internal planning helpers return route entries shaped like:

```json
{
  "mcp_id": "factrank",
  "integration_mode": "merged_internal",
  "current_status": "implemented",
  "selected_path": "internal",
  "decision": "use_internal",
  "provenance_label": "internal Critical Compass module",
  "requires_user_consent": false,
  "fallback_mode": "native_checkworthy_claims",
  "rationale": "A native capability is preferred over external orchestration."
}
```

## Provenance Labels

Every routed output must label the source as one of:

- internal Critical Compass module
- external MCP orchestration
- prompt scaffold only
- host browsing
- experimental provider path
- study-library pattern
- rejected candidate
- fallback capability

## External MCP Gate

External MCP orchestration requires:

- registry entry not rejected
- explicit availability
- trust and license review
- data-exposure review
- explicit user consent when text leaves the local context
- fallback mode
- provenance label in the final output

If any gate fails, return the fallback route.
