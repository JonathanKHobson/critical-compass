# PRD Index

Use `docs/planning/master-prd.md` for the top-level product definition.

Use the idea-level `prd.md` files under `docs/planning/ideas/` for the scoped product requirements of each planned capability.
