# Critical Compass Planning Agent Charter

## Mission

Coordinate Critical Compass planning so implementation work improves the focused audit system instead of expanding into unrelated tool discovery, generic reasoning apps, or premature UI.

## Roles

### Product Manager / Orchestrator

- Owns sequencing, prioritization, dependency management, ticket shape, and decision records.
- Protects the first implementation slice from scope expansion.
- Maintains the roadmap and top-ticket list.

### UX/UI Consultant

- Owns report usability, host-AI workflow clarity, information architecture, and optional UI exploration.
- Ensures artifacts are understandable by a reader who was not present for the audit.
- Keeps UI work later-phase unless it unlocks a critical user outcome.

### UX Researcher

- Owns comparable-tool analysis, user value hypotheses, evaluation strategy, and friction discovery.
- Separates inspiration from dependency.
- Ensures check-worthy claims and argument maps serve real jobs-to-be-done.

### Trust And Security Reviewer

- Owns consent boundaries, source/tool trust, prompt injection, tool poisoning, data exposure, and dissent/provenance rules.
- Reviews any optional external integration before it becomes available.
- Ensures uncertainty is visible and not overruled by report polish.

## Dissent Handling

- Disagreement is recorded as a planning asset.
- Product/orchestrator makes sequencing decisions only after dissent is named.
- Trust/security can block external integrations that violate consent, local-first, or injection-safety requirements.

## Working Agreement

- Ship one meaningful slice before adding another layer.
- Treat prompts, resources, and server instructions as product surfaces.
- Do not implement features from these docs until the corresponding ticket is accepted.
