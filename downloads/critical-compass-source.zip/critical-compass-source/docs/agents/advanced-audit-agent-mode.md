# Advanced Audit Agent Mode

Critical Compass agent mode is a disciplined panel review, not an open-ended swarm. It keeps the existing four-perspective audit flow but adds clearer routing, host capability handling, role contracts, compact stage artifacts, and a plan-review gate.

## Entry Contract

Use `advanced_audit(mode="agent")` only after explicit opt-in. Safe user phrases include:

- advanced panel review
- agentic panel review
- multi-perspective panel
- run the agent audit

Do not treat generic words such as agent, agency, city council, panel, committee, or stakeholders as opt-in by themselves. If the user is unclear, ask whether they want a normal full audit or advanced panel review.

Human Loop gates still come first. Mode consent, onboarding, and judgment prompts must clear before agentic plan review or scaffolds are exposed.

## Host Adapter Matrix

`host_capability_profile` declares what the host can actually do.

| Host capability | Adapter |
|---|---|
| `host_family="claude_code"` and `native_subagents=true` | `claude_native_subagents` |
| `host_family="codex"` and `explicit_subagent_spawn=true` | `codex_explicit_subagents` |
| Missing or generic host profile | `sequential_labeled_fallback` |
| `can_execute_stage_scaffolds=false` | `scaffold_only` |

Fallback mode must say that the panel is simulated/sequential in one thread. Do not claim real subagents were spawned unless the host actually spawned them.

## Role Contracts

Every panel uses four stable role buckets:

- `evidence_argument`
- `systems_context`
- `uncertainty_methods`
- `missing_voice_power`

Dynamic persona names are allowed, but each persona must map back to one role contract before analysis. Each contract is read-only, has allowed and forbidden tools, includes an expected artifact schema, and sets `asks_user_directly=false`.

## Stage State

The stage sequence is:

1. `plan_review`
2. `agent_definition`
3. `independent_analysis`
4. `tension_map`
5. `debate`
6. `synthesis`
7. `mitigation_rewrite` for deep mode only
8. `reflection`
9. `report_ready`

Stage payloads use artifact-only handoff. Hosts should carry forward only the typed artifacts: agent roster, analyses, tensions, debate, and Critical Integrity Snapshot decisions. Do not pass full transcripts as stage state.

## Plan Review

The first standard/deep agent-mode call returns `status="agentic_plan_review_required"` with:

- `agentic_plan_hash`
- `agent_execution_adapter`
- `role_contracts`
- `stage_plan`
- `artifact_budget`
- `agentic_progress_state`
- one approval question

To proceed, the host passes `agentic_state.plan_approved=true` and `agentic_state.approved_plan_hash` equal to the returned hash. If the user declines, route to `audit_text`.

## Revision Budget

Agent mode allows at most one revision pass after high-impact `FRAME_COLLAPSE` or `NEEDS_EVIDENCE` tensions. After one pass, finalize with caveats or withhold aggregate scoring as `profile_only`.
