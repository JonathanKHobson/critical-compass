# Top 10 Prioritized Tickets

1. [Done] Define canonical `argument_map` schema and fixture shape.
2. [Done] Add Markdown and `.argdown` export mapping for `argument_map`.
3. [Done] Define claim-type classifier: factual, interpretive, causal, normative, policy.
4. [Done] Add factual-claim verification-priority ranking to audit outputs.
5. [Done] Create canonical scaffold examples with report-ready payloads.
6. [Done] Add report readiness checks for argument maps and check-worthy claims.
7. [Done] Add Questions to Bring to the Text handout and Evidence Needed Next table planning hooks.
8. [Done] Add advanced-audit dissent ledger contract to agent outputs.
9. [Done] Add human-loop interruption prompts for harmed stakeholders, contested assumptions, and comfortable answers.
10. [Done] Add model-agnostic host-AI workflow instructions.

Implementation note: Phase 1 and the core Phase 2 trust hooks are now wired into the MCP as additive fields and report artifacts. The fact-check lane is implemented as a scaffold-first `factcheck_lookup` tool; local ClaimReview retrieval is opt-in when indexed, direct publisher harvest is consent-gated, and provider-backed retrieval remains explicit/experimental. Automatic external retrieval remains rejected for core audits.

See `docs/planning/phase-1-handoff.md` for rationale and sequencing.

## Current Next Tickets

1. [Done] Install compatible Apple Vision PyObjC OCR dependencies in the MCP runtime and rerun the 36 Questions source-preflight validation.
2. [Done] Run the full MCP smoke: `prepare_audit_source -> audit_text -> advanced_audit -> synthesize_audit_verdict -> generate_audit_report`.
3. [Done] Add golden report artifact screenshots for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks.
4. [Done] Add evidence-plan fields to `checkworthy_claims`: suggested queries, likely source types, support/contrast status, and uncertainty notes.
5. [Done] Expand reasoning-trap detectors for base-rate neglect, missing denominator, anecdotal evidence, authority laundering, and circular framing.
6. [Done] Wire saved blind-spot reminders into existing pattern storage with consent-aware copy.
7. [Done] Convert comparable-tools notes into local machine-readable records surfaced through overview/resources.
8. [Done] Create versioned scaffold resource files for canonical examples and report-ready workflow contracts.
9. [Done] Add no-network and report-golden fixtures for the new checkworthy evidence-plan fields.
10. [Done] Add false-positive calibration fixtures for expanded reasoning traps.
11. [Done] Add host-facing consent examples for saving and retrieving blind-spot reminders after the versioned scaffold resource files are in place.
12. [Done] Persist source/tool trust preflight output and expose trust summaries in report metadata.
13. [Done] Add red-team fixtures for prompt-injection and tool-poisoning source text.
14. [Done] Write `.argdown` sidecar artifacts for reports with argument maps.
15. [Done] Add stable golden artifact manifest assertions.
16. [Done] Add a local read-only artifact viewer for completed report manifests.
17. [Done] Add beta calibration harness for reasoning-trap and human-loop trigger drift.
18. [Done] Add standalone checklist-only visual artifact coverage.
19. [Done / scaffold-first] Add `factcheck_lookup` for guided verification scaffolding, epistemic framing, and optional explicit provider-backed retrieval for factual `checkworthy_claims`; automatic live fact-check/research calls remain rejected for core audits.
20. [Done] Refresh overview, tool map, scaffold resources, and runbooks so host AIs can discover source prep, report generation, manifests, and artifact viewers.
21. [Done] Add calibration intake guidance and CLI support for real user-provided beta cases without fabricating examples.
22. [Done] Add a repo-local live MCP freshness QA script; attached MCP staleness remains a client restart/rebind issue, not a report-renderer bug.
23. [Done] Add trusted fact-check publisher allowlist, mocked validation fixtures, and optional External Fact Checks report/viewer sections.
24. [Done] Add MCP composition policy, capability registry, internal route-planning helpers, ADRs, and scaffold resources for merge/wrap/orchestrate/scaffold/reject decisions.

## Active Next Phase: Pressure-Test Readiness

These tickets apply the mission charter. They should prove Critical Compass helps public users and nonprofit teams pressure-test text before use before more infrastructure is added.

25. [Next / PTR-01] Add nonprofit/public-user test scenarios for advocacy copy, article review, grant impact claims, and public statements.
26. [Next / PTR-02] Define the expected user-facing output shape: what to trust, revise, verify, or reframe.
27. [Next / PTR-03] Audit current `audit_text`, `claim_stress_test`, `factcheck_lookup`, and report outputs against plain-language usefulness.
28. [Next / PTR-04] Add a validation checklist that fails if new roadmap items do not pass the mission decision filter.

## MCP Study Library Implementation Roadmap

These tickets converted MCP study-library lessons into roadmap action ordered by verdict. MSL-01 through MSL-04 are complete and are now support infrastructure, not the active roadmap center.

### Completed Ship Next

Status label: `Completed ship-next`.

29. [Done / MSL-01] Add Host-AI Quickstart / Current State Context resource so hosts see shipped behavior, entry points, freshness checks, and non-negotiable rules before acting.
30. [Done / MSL-02] Add client-specific one-line hints for Claude, Codex, and Cursor-style hosts without adding client-specific runtime behavior.
31. [Done / MSL-03] Add a tool trigger matrix: call when, do not call when, ask first, and output label for major Critical Compass tools.
32. [Done / MSL-04] Add a surface sync checklist plus lightweight validator for README, overview, tool inventory, scaffold manifest, and tests.

### Use For Local ClaimReview Phase

33. [Later / MSL-05] Require adapter boundary checklist and golden fixtures before changing local ClaimReview or direct publisher harvest adapters. Resume only if real pressure-test examples show fact-check scaffolding is insufficient.

### Good Next Phase

34. [Later / MSL-06] Add external MCP trust preflight checklist from mcp-shield/mcp-guard lessons without wiring runtime external routes. Keep it policy-only unless a public/nonprofit pressure-test workflow needs it.

### Defer Until Examples Prove Need

35. [Deferred / MSL-07] Evaluate confidence, uncertainty, revision, and branch metadata only against real advanced-audit misses.
36. [Deferred / MSL-08] Promote manifest/resource linter only if lightweight surface-sync validation fails to catch recurring scaffold drift.

### Later / High Effort

37. [Later / MSL-09] Design a separate factuality eval subsystem inspired by OpenFactCheck only after real output-quality failures justify it.
38. [Later / MSL-10] Revisit runtime MCP guard/proxy only after a reviewed external route exists and the user-facing pressure-test value is concrete.

### Reject / Scaffold-Only

39. [Rejected / MSL-11] Do not add a generic public think/scratchpad tool.
40. [Scaffold-only / MSL-12] Keep provider/payment consensus MCPs out of runtime paths unless a transparent local or user-provided provider path is approved.

## Future P2/P3 Reliability Studio Backlog

These tickets capture the Agenta-informed discovery without reopening the active beta.10 delivery-layer hotfix or release closeout. Agenta is a reference model for prompt versioning, trace-level evaluation, human review, and trace-to-test workflows; it is not an approved runtime dependency. Phase order lives in `docs/planning/ideas/compass-eval-studio/phase-roadmap.md`.

41. [P2 Backlog / CES-01] Add a local prompt/scaffold registry for Critical Compass prompt-bearing surfaces with stable IDs, versions, hashes, source paths, statuses, and change notes.
42. [P2 Backlog / CES-02] Define opt-in audit run traces with stage spans for source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA.
43. [P2 Backlog / CES-03] Add a failed-trace-to-candidate-fixture proposal workflow that includes expected findings, expected non-findings, forbidden lens IDs, expected absent traps, CIS range, and report-readiness expectations.
44. [P2 Backlog / CES-04] Extend eval summaries so prompt/scaffold changes are judged by expected finding recall, expected non-finding violations, lens over-selection, report readiness misses, CIS ordering, renderer banned-string leaks, and human-loop compliance.
45. [P2 Backlog / CES-05] Add privacy guardrails so trace capture is opt-in, summary-first, and never reader-facing.
46. [P3 Backlog / CES-06] Build a local HTML reliability dashboard from eval summaries and trace JSON files.
47. [P3 Backlog / CES-07] Add side-by-side prompt/scaffold comparison across the same fixture set.
48. [P3 Backlog / CES-08] Add a lightweight human review queue for domain judgment, critique-overreach, severity, expected non-finding violations, and notes.
49. [P3 Backlog / CES-09] Plan trace replay from saved stage snapshots after the local trace contract proves useful.

## Future P2/P3 Observability, Routing, Temporal Provenance, And Context Map Backlog

These tickets capture the Langfuse, Strata, Graphiti, and Eureka research without reopening beta.10 delivery-layer work. They are design-pattern references, not approved runtime dependencies. Phase order lives in `docs/planning/ideas/compass-observability-routing-temporal-map/phase-roadmap.md`.

50. [P2 Backlog / CORTM-01] Define a future local `RunTrace` contract for MCP calls, validators, repair loops, latency, token estimates, and artifact paths.
51. [P2 Backlog / CORTM-02] Define a future `RetrievalRunSummary` contract for selected lenses, omitted nearby lenses, candidates, ranking features, and precision flags.
52. [P2 Backlog / CORTM-03] Define a future `ToolRouterDecision` contract for intent, domain, stage, allowed/disallowed tools, widget requirement, and repair instruction.
53. [P2 Backlog / CORTM-04] Define a future `ContextSelectionMap` contract for query/input, selected lenses, graph edges, omitted lenses, budget use, and downstream role.
54. [P2 Backlog / CORTM-05] Document `TemporalFact` as a coordination contract for Knowledge Atlas/Kyle Second Brain ownership, not a Critical Compass runtime schema.
55. [P2 Backlog / CORTM-06] Document local-first JSONL/SQLite storage guidance and disable external export by default.
56. [P2 Backlog / CORTM-07] Add cross-system ownership notes so Critical Compass does not absorb Atlas or KSB memory architecture.
57. [P3 Backlog / CORTM-08] Plan a local health dashboard from traces, evals, retrieval summaries, and route decisions.
58. [P3 Backlog / CORTM-09] Plan optional Langfuse export only after local tracing works.
59. [P3 Backlog / CORTM-10] Plan Strata-inspired router experiments that preserve existing MCP tools.
60. [P3 Backlog / CORTM-11] Plan Graphiti-inspired temporal implementation in the owning memory or Atlas system.
61. [P3 Backlog / CORTM-12] Plan Eureka-inspired static explainability maps before any interactive UI.
