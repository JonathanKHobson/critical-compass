# Critical Compass Project Map

Date: 2026-05-20

## Runtime Surfaces

- `server.py` contains the MCP tool payloads, Critical Integrity Snapshot builder, comparison workflow, and host-facing contracts.
- `critical_contracts.py` contains lightweight shared dataclasses used by contract-style outputs and eval traces.
- `audit_report/` owns report normalization, readiness checks, Markdown rendering, PDF rendering, visual QA, and the local artifact viewer.

## Report Rendering Lane

- `audit_report/normalize.py` converts varied host/audit payloads into the canonical report payload.
- `audit_report/markdown.py` renders deterministic Markdown checkpoints and report fallbacks.
- `audit_report/templates/` contains the Jinja HTML templates used for PDF rendering.
- `audit_report/styles/` contains PDF report styling.
- `audit_report/viewer.py` builds the local read-only HTML artifact viewer from a report manifest.

## Planning And Release Hygiene

- `docs/planning/` holds feature briefs, roadmaps, handoffs, and backlog notes.
- `docs/course-use/` holds instructor/student-facing classroom handoff templates derived from runtime resources.
- `docs/adr/` holds architecture decisions.
- `scripts/validate_*` and `scripts/run_*` contain release and regression validation helpers.
- `dist/`, `reports/`, caches, and generated artifacts are not source-of-truth implementation surfaces.

## Current Scoring Stability Lane

- Use `server.py` for in-chat CIS wording and snapshot fields.
- Use `critical_course_resources.py` for course-facing prompt and guidance constants.
- Use `support/resources/scaffolds/v1/classroom-standard-audit-prompt.md` and `docs/course-use/week2-critical-compass-bias-audit.md` for Week 2 classroom prompt handoff.
- Use `audit_report/normalize.py`, `audit_report/markdown.py`, `audit_report/templates/partials/cover.html`, `audit_report/styles/report.css`, and `audit_report/viewer.py` for report/viewer score framing.
- Use `tests/test_report_renderer.py` and `tests/test_release_surface_upgrades.py` for focused regression coverage.
- Use `docs/planning/scoring-stability-and-course-mode-backlog.md` for course-mode prompt, prioritization, and future scoring-stability ideas.
