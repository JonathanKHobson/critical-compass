# Week 2 Critical Compass Bias Audit

Date: 2026-05-20

## Purpose

This handoff supports the Week 2 RAP course exercise where students use Critical Compass to audit their own writing for bias, missing voices, audience fit, and revision decisions. The goal is comparable classroom conversation, not identical AI outputs.

## Student Prompt

```text
Please run a standard Critical Compass audit on the text below.

Use this fixed frame:
- Audience: [who this is for]
- Intended use: [what this writing is meant to do]
- Text type: [memo / pitch / email / report section / social post / proposal / other]
- Audit depth: standard
- Output purpose: classroom bias-audit reflection

Do not run an advanced panel review, multi-agent review, or web research. Do not rewrite the text unless I ask afterward.

Use this exact output structure:
1. Critical Integrity Snapshot
2. Plain-Language Read
3. Before Using This Text
4. Top 3-5 findings
   - finding name
   - severity: high / medium / low
   - specific evidence from the text
   - why it matters for the stated audience and intended use
5. Key tension
6. Recommended next revision
7. Two peer-discussion questions

Here is the text to audit:

[paste text]
```

## Instructor Guidance

Critical Compass is AI-assisted, so outputs may differ across models and runs. For class discussion, compare the top findings, severity, and revision decisions more than exact point scores.

Ask students to use the same text if they rerun the audit. If they revise the text, they should label it `Version 2` and compare findings, not just the score.

Before course use, update older Claude Desktop or skill-file installs so students receive the newer score framing and course routing guidance.

## Exercise Tweaks

- Replace the current broad prompt with the student prompt above.
- Keep advanced audit and advanced panel review out of the core assignment.
- Offer advanced panel review only as an optional extension for deeper critique.
- Use `MCPB extension` for Claude Desktop install wording.
- Separate Claude Desktop setup from ChatGPT or prompt-only skill-file instructions.
- Replace any overpromising de-westernization debrief with: Did the audit surface any perspective, power, cultural, or missing-voice issue that shifted how you see the text?

## MCP Status

Implemented in this slice:

- `classroom_standard_audit_prompt` is exposed through the scaffold manifest.
- `get_started` surfaces course-use guidance and the student prompt.
- `critical_compass_overview` routes course users to standard `audit_text`.
- `compare_audit_results` warns against treating raw score movement as proof of improvement.

Backlog:

- Add a classroom output profile only after this prompt is validated in the course.
- Strengthen score-rationale trace from top findings and dimensions.
- Add repeated-run calibration evals after the course template path has evidence.
