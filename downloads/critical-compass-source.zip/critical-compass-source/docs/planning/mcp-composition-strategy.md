# MCP Composition Strategy

Status: active
Date: 2026-04-15

## Decision

Critical Compass is an orchestrator, not an MCP bundle. Third-party MCPs can inform the system only through a reviewed composition mode:

- `merged_internal`
- `wrapped_internal`
- `orchestrated_external`
- `prompt_scaffold_only`
- `rejected`

The default route is native Critical Compass behavior or scaffold guidance. External orchestration is optional and explicitly labeled.

## Composition Rules

Use `merged_internal` when the capability is core, safe, license-compatible, maintainable, and already aligned with Critical Compass semantics.

Use `wrapped_internal` when the behavior should feel native but remain repo-owned and local.

Use `orchestrated_external` only when the external MCP is valuable, reviewed, available, consented to, and has a fallback.

Use `prompt_scaffold_only` when the idea is useful but direct integration would add fragility, vendor burden, or semantic confusion.

Use `rejected` when the MCP conflicts with scope, trust, license, maintenance, privacy, or epistemic goals.

## What Gets Displaced

Every candidate must name what it would displace:

- a native Critical Compass module
- a host-AI prompt scaffold
- a local data source
- a report artifact
- a user decision point
- nothing current, meaning it belongs later

If a candidate displaces Critical Compass synthesis, plurality review, or report readiness, reject or scaffold it.

## Current Scope

This phase creates registry, policy, docs, internal planning helpers, and a soft-learning registry for downloaded MCP repos. It does not merge third-party MCP repos, install live external MCPs, or expose a public orchestration tool.

## Mission Alignment Pause

Composition work is paused as active product work unless it directly supports a public/nonprofit pressure-test workflow. The mission charter is now the roadmap lens: Critical Compass helps people and mission-driven organizations pressure-test text before use.

MCP composition remains support infrastructure. It should not displace audit quality, plain-language usefulness, Human Loop, fact-check scaffolding, reports, or the ability to help users decide what to trust, revise, verify, or reframe.

## Study Library Soft Learner

The local MCP study library may be scanned and summarized into `support/registry/mcp_study_lessons.json`.

Study lessons can inform:

- repo organization
- prompt/scaffold design
- schema and fixture conventions
- trust and safety preflight
- negative patterns to avoid

Study lessons cannot authorize runtime calls, code imports, or direct prompt copying. They are labeled as `study_library_pattern` or `prompt_scaffold_only` until a later ADR approves stronger integration.

## MCP Study Library Implementation Roadmap

Composition work now uses the verdict-ordered study-library roadmap from `docs/planning/mcp-study-library-soft-learner.md`.

Completed `Ship next` items:

1. Done - Host-AI Quickstart / Current State Context resource.
2. Done - Client-specific one-line hints for Claude, Codex, and Cursor-style hosts.
3. Done - Tool trigger matrix with call-when, do-not-call-when, ask-first, and output-label guidance.
4. Done - Surface sync checklist plus lightweight validator for README, overview, tool inventory, scaffold manifest, and tests.

Non-active verdicts:

- `Use for local ClaimReview phase`: adapter boundary checklist and golden-fixture requirement.
- `Good next phase`: external MCP trust preflight checklist.
- `Defer until examples prove need`: confidence/revision metadata and manifest/resource linter.
- `Later / high effort`: factuality eval subsystem and runtime MCP guard/proxy layer.
- `Reject / scaffold-only`: generic think tool and provider/payment consensus MCPs.

These roadmap items are planning/ticket surfaces only. They do not add a public orchestration tool or authorize live external MCP routing.
