# Implementation Notes

## 2026-04-15 - Core Reasoning Artifacts And Report Hardening

Implemented the approved first shipping sequence as additive MCP behavior:

- `argument_map` normalization with plain-language summary, central claim, claim type, reasons, objections, assumptions, missing voices, evidence gaps, next questions, Markdown export, and `.argdown` export.
- `checkworthy_claims` normalization with factual, interpretive, causal, normative, and policy claim typing. Only factual claims receive verification priority. Check-worthy is explicitly framed as worth verifying, not false.
- Report Markdown/PDF artifacts for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks.
- Readiness checks for empty or placeholder artifact sections, while keeping artifacts optional when no source text or authored artifact is available.
- Advanced-audit scaffold updates for dissent ledger and reasoning-trap outputs.
- Human-loop interruption trigger helpers for harmed stakeholders, contested assumptions, missing affected perspectives, comfortable-answer detection, and report-critical missing context.
- Source/tool trust preflight helper with local-only consent boundaries and prompt-injection/tool-poisoning checks.

No automatic web search or fact retrieval was added to core audits.

Validation status:

- `scripts/validate_audit_report_renderer.py` passed.
- `scripts/validate_research_audit_coverage.py` passed.
- `scripts/validate_writable_state.py` passed.
- New artifact and trust tests passed through direct Python invocation because `pytest` is not installed in the default Python runtime.
- Apple Vision OCR dependencies are now installed in the local Python runtime with the Python 3.9-compatible PyObjC 11.x line. `scripts/validate_audit_source_preflight.py /Users/jonathanhobson/Downloads/36 Questions Experiment.pdf` passed with `extraction_method=apple_vision_ocr`, `ocr_used=True`, 15 pages, and 12,746 OCR words.
- `scripts/smoke_36_questions_report.py` passed the full local smoke: `prepare_audit_source -> audit_text -> advanced_audit -> synthesize_audit_verdict -> generate_audit_report`.
- The smoke writes a report PDF, Markdown contract, manifest, preview PNG, all page PNGs, and golden report artifact screenshots for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks under `reports/smoke-36-questions/`.
- A PDF QA matcher bug was fixed so deterministic text checks tolerate PyMuPDF extraction of line-broken hyphenated words such as `follow-\nup`; the readiness gate remains strict.

## 2026-04-15 - Scaffold-First Fact-Check Lane

Reframed `factcheck_lookup` as scaffold-first verification orchestration for factual `checkworthy_claims`:

- Default `provider="guided_research"` returns no-retrieval scaffolding with `lookup_performed=false`.
- `provider="local_claimreview"` searches a configured local ClaimReview index without external calls.
- `provider="publisher_harvest"` directly harvests ClaimReview markup from approved publisher sites after `allow_external_calls=true`.
- Epistemic framing now runs before verification scaffolding: domain, claim kind, domain sensitivity, Western-bias history, consensus age, knowledge communities with standing, and source emphasis.
- Structured cautions and warnings make provider deprecations, no-match limits, domain sensitivity, sensitive claims, and missing perspectives explicit.
- `provider="auto"` is deprecated and now returns guided-research scaffolding with a loud warning.
- Provider adapters for Google Fact Check Tools, Brave Search, and approved-publisher search remain optional/experimental and require explicit provider names plus consent.
- Trusted publisher allowlist in `support/registry/trusted_factcheck_publishers.json`.
- Minimum-data external requests: claim text, language, publisher filter, and freshness window only.
- Privacy guard for likely sensitive/private claims, with explicit override disabling cache for that claim.
- Local JSON cache keyed by normalized claim, language, provider, publisher scope, and freshness window.
- Explicit statuses for match, multiple matches, conflicting reviews, no trusted match, sensitivity block, and provider error.
- Optional `external_fact_checks` report, Markdown, and artifact-viewer sections that render only when real trusted matches exist.

Validation status:

- `python3 -m pytest tests/test_factcheck_lookup.py tests/test_report_renderer.py -q` passed.
- `scripts/validate_factcheck_lookup.py` provides mocked no-network validation for consent gating, conflicts, sensitive blocks, non-factual skips, and provider errors.

ADR status: ADR-0004 records the factuality subsystem merge strategy. Core audits still do not perform automatic web search or fact retrieval. Current fact-check behavior is scaffold-first by default, local retrieval opt-in when an index is configured, direct publisher harvest explicit, and external providers optional later.
