# Critical Compass Master Roadmap

## Roadmap Logic

Sequence work by mission impact first: does it help a person or nonprofit pressure-test text before use? Local rebuildability and dependency risk still matter, but they are secondary to whether the work helps users decide what to trust, revise, verify, or reframe before sharing, teaching, funding, reporting, publishing, or acting.

## Mission Lens

The mission charter in `docs/planning/mission-audience-purpose-charter.md` is now the active roadmap lens. Critical Compass should prove that its current tools help public users and nonprofit teams find weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing in supplied text.

Local retrieval, provider-adapter experiments, and historical study-library learning are support infrastructure. They are not the product story and should not become active work unless a concrete public/nonprofit pressure-test workflow needs them. Critical Compass does not ship external MCP orchestration.

## Current Status - 2026-04-28

Critical Compass v0.1.0-beta.7 shipped the Atlas-informed Pressure-Test Readiness work. That track is now historical and remains available as planning evidence, scenario context, and source rationale.

The active release track is now **Beta.9 Stabilization And Publish**:

- Release inventory: `docs/planning/beta9-stabilization-and-publish-inventory.md`
- Archive snapshot: `docs/planning/archive/2026-04-27-beta7-planning-snapshot/`
- Product state: local beta.8.x work has added teaching-layer outputs, report preflight/readiness paths, schema/report reliability, native human-loop guidance, corpus-grounding signals, and planning-leak cleanup.
- Boundary: beta.9 is a stability release. No new tools, scoring model changes, or external orchestration belong in this lane unless a release blocker demands them.

## Phase 0: Planning Package

- Create master PRD, roadmap, ADRs, evaluation strategy, file ownership rules, and per-idea planning folders.
- Classify outside inspirations as adopt, adapt/rebuild, optional integration, or reject.
- No feature implementation.

## Phase 1: Core Reasoning Artifacts

- Add `argument_map` to audit outputs.
- Add `checkworthy_claims` to audit outputs.
- Add canonical scaffold examples and resource contracts.
- Update report readiness and Markdown/PDF artifacts for these outputs.

Phase gate:
- Golden fixtures pass.
- Reports do not ship blank or placeholder sections.
- Check-worthy claims clearly separate factual verification priority from truth judgment.

Status as of 2026-04-15: implemented for the active local-first roadmap. Argument Map, Check-Worthy Claims, scaffold examples, report readiness, Markdown/PDF sections, report golden artifacts, check-worthy evidence-plan fields, no-network regressions, `.argdown` sidecars, and fixture coverage now exist.

## Phase 2: Advanced Audit Trust And Reflection

- Add advanced-audit dissent ledger.
- Add reasoning trap detectors.
- Add human-loop interruption triggers.
- Add structured elicitation for missing context and report readiness.

Phase gate:
- Agent disagreement is visible and traceable.
- Human-loop prompts remain non-sensitive and bounded.
- Reasoning-trap outputs improve audit prompts without over-labeling users or texts.

Status as of 2026-04-15: implemented for the active local-first roadmap. Dissent ledger, persistence fixtures, recurring disagreement-pattern tracking, interruption triggers, structured elicitation examples, expanded reasoning-trap checks, false-positive calibration, priority ordering, and consent-gated saved blind-spot reminders are wired into outputs, resources, pattern storage, and reports where applicable.

## Phase 3: Workflow And Trust Hardening

- Add server instructions and prompt/resource workflow layer.
- Add source/tool trust preflight.
- Add comparable tools knowledge layer as an internal resource.

Phase gate:
- Host AIs can discover correct workflow steps before tool calls.
- External tool use is consent-gated and trust-scored.
- Comparable tools layer helps users understand scope without bloating the product.

Status as of 2026-04-15: implemented for the active local-first roadmap. Host-AI workflow contracts, versioned scaffold resources, source preparation, persisted source/tool trust preflight, trust summaries in report metadata, red-team prompt-injection fixtures, and machine-readable comparable-tools records are available through overview/resources.

## Phase 4: Optional Interfaces And Integrations

- Prototype MCP App UI for argument maps, inline review, and report exploration.
- Populate and evaluate the local ClaimReview index/direct publisher harvest before any new fact-check API integration.
- Keep provider-backed fact-check retrieval explicit and experimental; scaffold-first behavior remains the shipped default.
- Add MCP composition policy and capability registry before any third-party MCP merge or orchestration.

Phase gate:
- UI improves comprehension beyond Markdown/PDF.
- External integrations remain opt-in and can be disabled without degrading core audits.

Status as of 2026-04-15: implemented for the current fact-check and MCP-composition cleanup. A read-only local artifact viewer now opens completed report manifests and shows the decision layer, report links, argument map, evidence plan, external fact-check results when explicitly supplied, dissent ledger, reasoning traps, questions, and trust preflight without creating new findings. `factcheck_lookup` is scaffold-first by default for factual `checkworthy_claims`; local ClaimReview retrieval is opt-in when an index is configured, direct publisher harvest is consent-gated, and provider-backed retrieval is explicit/experimental. MCP composition now has a local registry, soft-learning lesson registry, and policy for merge/wrap/orchestrate/scaffold/reject decisions. Automatic retrieval, broad research integrations, and unreviewed external MCP orchestration remain outside core audits.

## Current Next Tickets

The active next phase is **Beta.9 Stabilization And Publish**. Its goal is to publish the current stabilized product without widening scope.

Release inventory and journey map: `docs/planning/beta9-stabilization-and-publish-inventory.md`.
P1 release-closeout PRD and roadmap: `docs/planning/beta9-p1-release-closeout-prd-roadmap.md`.

1. `B9-STAB-01` - Freeze feature work and capture the beta.7 to beta.9 change inventory.
2. `B9-STAB-02` - Verify human and host-AI first-use journeys across plugin, MCPB/Desktop Extension, source zip, and skill fallback.
3. `B9-STAB-03` - Run report smoke fixtures for quick, full, advanced-dissent, and advanced-consensus paths.
4. `B9-STAB-04` - Rebuild MCPB, plugin zip, skill zip, source zip, manual share kit, GitHub Pages kit, examples, and checksums.
5. `B9-STAB-05` - Publish `v0.1.0-beta.9` and verify live download URLs, checksums, release notes, and example links.

Beta.7 historical context:

Pressure-Test Readiness implementation tickets now shipped:

1. `PTR-01` - Added nonprofit/public-user test scenarios for advocacy copy, article review, grant impact claims, and public statements.
2. `PTR-02` - Defined the expected user-facing output shape: what to trust, revise, verify, or reframe.
3. `PTR-03` - Audited current `audit_text`, `claim_stress_test`, `factcheck_lookup`, and report outputs against plain-language usefulness.
4. `PTR-04` - Added validation checks so future roadmap items preserve the mission decision filter.

1. Shipped - Atlas-informed pressure-test scenarios and output audits.
2. Shipped - mitigation next-step verbs, AI/data audit language, KB no-result recovery, routing guidance, and ethical dilemma examples in existing surfaces.
3. Shipped - curated Atlas gap-fill pack, refreshed SQLite index, offline skill export validation, persona seeds, and optional practice suggestions.
4. Deferred - standalone Practice Activity Tool remains unbuilt until evidence shows existing outputs cannot carry the activity layer.

Do not package or publish beta.9 until local validation, package clean scans, and journey smoke tests pass.

## Future Backlog: Compass Eval Studio

The Agenta-informed reliability lane is captured as future P2/P3 work under `docs/planning/ideas/compass-eval-studio/`. Start with `docs/planning/ideas/compass-eval-studio/phase-roadmap.md` for phase order. It borrows Agenta's strongest product pattern - versioned prompts, traces, evals, human review, and trace-to-test workflows - without adding Agenta as a dependency.

This is not part of the active beta.10 delivery-layer hotfix or release-surface work. It should resume only after the publish lane is stable, and it should remain local-first: prompt/scaffold registry, opt-in trace capture, trace-to-candidate-fixture proposals, eval summary upgrades, and later local dashboard/replay work.

## Future Backlog: Observability, Routing, Temporal Provenance, And Context Maps

The Langfuse, Strata, Graphiti, and Eureka research is captured as a separate future P2/P3 planning lane under `docs/planning/ideas/compass-observability-routing-temporal-map/`. Start with `docs/planning/ideas/compass-observability-routing-temporal-map/phase-roadmap.md` for phase order.

This lane extends the Eval Studio idea outward: local run traces, retrieval run summaries, progressive tool routing, temporal provenance coordination, and human-facing context maps. It is not part of beta.10, does not add external SaaS dependencies, and does not move Knowledge Atlas or Kyle Second Brain implementation into Critical Compass.

## MCP Study Library Implementation Roadmap

The MCP study-library soft learner has completed its first `Ship next` documentation/resource slice. These items improved host-AI correctness and stale-surface prevention without merging, installing, importing, or calling third-party MCPs. They are now support infrastructure, not the active roadmap center.

| Verdict | Item | Impact | Effort | Roadmap Action |
|---|---|---:|---:|---|
| `Completed ship-next` | Host-AI Quickstart / Current State Context resource | High | Low | Implemented as scaffold resource and manifest entry. |
| `Completed ship-next` | Client-specific one-line hints | High | Low | Implemented as scaffold resource and host-facing guidance. |
| `Completed ship-next` | Tool trigger matrix | High | Medium | Implemented as call-when/do-not-call/ask-first/output-label resource. |
| `Completed ship-next` | Surface sync checklist plus lightweight validator | High | Medium | Implemented as scaffold resource and `validate_mcp_surface_sync.py`. |
| `Use for local ClaimReview phase` | Adapter boundary checklist and golden-fixture requirement | High | Medium | Apply when extending local ClaimReview/direct publisher retrieval. |
| `Good next phase` | External tool trust preflight checklist | High | Medium | Convert security lessons into a non-runtime trust checklist for future local review work. |
| `Defer until examples prove need` | Confidence/revision metadata and manifest/resource linter | Medium | Low-Medium | Revisit only when real examples or repeated drift justify them. |
| `Later / high effort` | Factuality eval subsystem and runtime MCP guard/proxy | Medium | High | Keep separate from core audits until a specific approved route exists. |
| `Reject / scaffold-only` | Generic think tool and provider/payment consensus MCPs | Low-Medium | Low-High | Keep out of runtime paths; preserve only as scaffold or anti-pattern notes. |

MSL-01 through MSL-04 are complete. Later tickets `MSL-05` through `MSL-12` remain visible in `docs/planning/mcp-study-library-soft-learner.md`, but they are not active implementation work. The active roadmap is Pressure-Test Readiness.

## Cross-Phase Guardrails

- Do not add automatic web search to core audits.
- Do not equate check-worthy with false.
- Preserve dissent, provenance, and uncertainty in output contracts.
- Prefer local rebuilds over direct dependency on proprietary services.
