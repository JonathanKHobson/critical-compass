# MCP Integration Decision Matrix

Status: active
Date: 2026-04-15

| Candidate | Decision | Reason | Fallback |
|---|---|---|---|
| FactRank | `merged_internal` pattern adaptation | Check-worthiness distinction is core and already implemented locally. | `checkworthy_claims` |
| OpenFactCheck | `prompt_scaffold_only` / deferred eval reference | Useful architecture, but AGPL and framework size block direct merge. | fact-check research scaffold |
| Fact-Check Tools MCP | `rejected` as core dependency | No reliable install target in study-library pass; Google/key dependency conflicts with default path. | `factcheck_lookup` guided research |
| ethics-check-mcp | `merged_internal` pattern adaptation | Interruption triggers and blind-spot consent patterns fit Human Loop. | native Human Loop |
| mcp-shield | `wrapped_internal` pattern reference | Useful for external-MCP trust checks, not runtime routing yet. | external MCP trust checklist |
| mcp-guard | `wrapped_internal` pattern reference | Useful proxy/guard ideas, but may need external moderation API. | external MCP trust checklist |
| sequential-thinking | `prompt_scaffold_only` | Generic stage reasoning is already represented by advanced-audit scaffolds. | advanced audit stages |
| think-mcp | `prompt_scaffold_only` | Too generic for a public Critical Compass tool. | native quality gates |
| crash-mcp | `prompt_scaffold_only` | Useful confidence/revision patterns, not a core dependency. | advanced audit stage scaffolds |
| thoughtproof-mcp | deferred `orchestrated_external` | Potentially useful for reasoning verification, but must not replace synthesis. | dissent ledger |
| claude-prompts | `prompt_scaffold_only` | AGPL and path-traversal risk noted by study-library scan. | versioned scaffold resources |
| idea-reality-mcp | deferred `orchestrated_external` | Useful for proposal reality checks, but live scans expose idea text. | proposal reality-check scaffold |
| Argdown CLI | `merged_internal` format reference | Plain-text argument map export is already native. | native argument-map export |

Use this matrix with the registry. The registry is canonical for machine-readable tests; this matrix is the human review surface.

Mission alignment: integration decisions are no longer active product work by default. A candidate must improve a concrete public/nonprofit pressure-test workflow before it can displace current audit, claim, fact-check scaffold, report, or Human Loop work.

## MCP Study Library Implementation Roadmap

This roadmap translated study-library lessons into implementation order. It is separate from integration mode: a lesson can be high-impact while still not being a runtime MCP dependency. The first documentation/resource slice is complete and the active product phase is now Pressure-Test Readiness.

| Verdict | Items | Impact | Effort | Decision |
|---|---|---:|---:|---|
| `Completed ship-next` | Host-AI Quickstart / Current State Context; client-specific one-line hints; tool trigger matrix; surface sync checklist plus lightweight validator | High | Low-Medium | Implemented as docs/resources/tests only. |
| `Use for local ClaimReview phase` | Adapter boundary checklist and golden-fixture requirement | High | Medium | Apply when local ClaimReview and publisher-harvest work resumes. |
| `Good next phase` | External MCP trust preflight checklist | High | Medium | Convert security lessons into non-runtime review criteria. |
| `Defer until examples prove need` | Confidence/revision metadata; manifest/resource linter | Medium | Low-Medium | Wait for real advanced-audit misses or repeated scaffold drift. |
| `Later / high effort` | Factuality eval subsystem; runtime MCP guard/proxy layer | Medium | High | Keep separate from core audits until a concrete approved route exists. |
| `Reject / scaffold-only` | Generic think tool; provider/payment consensus MCPs | Low-Medium | Low-High | Do not add to runtime paths. |

MSL-01 through MSL-04 are complete. Do not resume integration work unless real pressure-test examples show it is needed.
