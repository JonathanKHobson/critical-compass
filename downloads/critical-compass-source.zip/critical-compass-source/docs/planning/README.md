# Critical Compass Planning Package

This package is the planning layer for Critical Compass improvements. Planning docs describe product direction and implementation intent; they do not implement runtime behavior by themselves.

## Start Here

1. `master-prd.md`
2. `master-roadmap.md`
3. `phase-1-handoff.md`
4. `adopt-adapt-reject-matrix.md`
5. `mergeability-matrix.md`
6. `mcp-composition-strategy.md`
7. `mcp-capability-registry.md`
8. `mcp-integration-decision-matrix.md`
9. `file-ownership-and-parallel-work-rules.md`

Per-idea planning packs live under named folders in `ideas/`.

## Current Active Planning Track

`beta9-stabilization-and-publish-inventory.md`

`beta9-p1-release-closeout-prd-roadmap.md`

Beta.8.x is now a local stabilization train, not a public release target. The active release lane is beta.9: freeze feature work, verify the user and host-AI journey, sync package/public surfaces, rebuild artifacts, and publish only after smoke tests pass.

`scoring-stability-and-course-mode-backlog.md` captures the narrow classroom-output consistency lane. Use it for course prompt work, score-framing language, and future rerun-comparison ideas without reopening broad scoring retunes.

Current beta.9 release pillars:

1. Stable first-use routing through `get_started`, `critical_compass_overview`, and host-facing scaffolds.
2. Reliable report payload validation through `report_ready_payload`, `validate_report_payload`, schema hashes, and renderer diagnostics.
3. Clean package/public surfaces with no external MCP orchestration language in runtime bundles.
4. Rebuilt beta.9 release artifacts with checksums and verified live download links.

## Historical / Shipped Planning Tracks

- `ideas/atlas-informed-pressure-test-readiness/` - shipped in beta.7. Keep for source context and pressure-test scenario history.
- `ideas/beta8-teaching-alignment-readiness/` - completed locally during the beta.8.x train. Keep for teaching-layer source context.

Archived beta.7 planning snapshot:

- `archive/2026-04-27-beta7-planning-snapshot/`

## Default First Implementation Slice

The original Phase 1 implementation slice favored:

1. `argument_map`
2. `checkworthy_claims`
3. scaffold registry and canonical examples
4. report-readiness hardening

This slice is local-first, high-impact, and does not require optional external integrations.

That slice is now historical. The beta.8.x implementation train moved through activity review, local pack curation, output contract enforcement, report rendering, schema/report hardening, human-loop guidance, planning-leak cleanup, and standalone skill refresh. The current release slice is beta.9 validation/package/publish only after smoke testing.

## Current Composition Rule

Do not surface third-party MCP planning or orchestration language in runtime MCP guidance, packaged scaffolds, or public product copy. Historical capability registries and study-library notes may remain in planning/ADR/archive contexts only. Shipped Critical Compass behavior is local-first and does not orchestrate other MCPs.

For beta.9, external archives and activity sources are build-time evidence only. They should not become runtime dependencies, product-facing source labels, or new public tools.
