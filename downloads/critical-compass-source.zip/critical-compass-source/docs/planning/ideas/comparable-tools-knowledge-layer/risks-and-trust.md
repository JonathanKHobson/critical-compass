# Comparable Tools Knowledge Layer Risks And Trust

## Risks
- Stale comparisons if the catalog is never refreshed.
- Overconfident "nearest match" language that hides real differences.
- Scope creep into general tool discovery.

## Trust Controls
- Store a source note and decision note with each entry.
- Label the entry as curated, not exhaustive.
- Separate facts about the tool from the product's opinion about fit.

## Mitigations
- Add review dates.
- Keep the default view compact.
- Use optional external sync only as a refresh aid, not as the source of truth.
