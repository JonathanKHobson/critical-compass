# Comparable Tools Knowledge Layer Evaluation

## What To Test
- Can a host AI pick the right workflow faster with the comparison layer?
- Can a new user explain the difference between Critical Compass and the nearest adjacent tool?
- Does the layer reduce routing mistakes without adding confusion?

## Metrics
- Fewer misrouted requests.
- Faster selection of audit vs claim stress-test vs report generation.
- Better explanation quality in onboarding.

## Acceptance Cases
- A user asks for a "truth check" and gets routed to the right workflow.
- A user asks "what is this like?" and receives a short, accurate comparison.
- The catalog stays readable with only local data.
