# Comparable Tools Knowledge Layer PRD

## Problem Statement
The current product lacks a crisp public explanation of what it is adjacent to and what it deliberately does not do. That makes it harder to route users, justify design choices, and avoid scope creep.

## Jobs To Be Done
- "Help me pick the right Critical Compass workflow."
- "Tell me what this is like and what it is not like."
- "Give me a trustworthy comparison without overclaiming."

## Product Behavior
- Maintain a curated comparison map of adjacent tools, methods, and MCPs.
- For each entry, store purpose, fit, trust level, local mergeability, and decision status.
- Show the comparison in onboarding, overview, and report-adjacent contexts.

## Scope
In scope:
- curated local knowledge
- explicit adopt/adapt/reject decisions
- host-AI routing hints

Out of scope:
- auto-searching the web during audits
- live competitor scraping by default
- broad product discovery UX

## Acceptance Criteria
- The system can explain at least the top adjacent inspirations for each core workflow.
- Comparisons distinguish similar goals from different mechanisms.
- The layer helps route users without changing audit results.

## Success Metrics
- Fewer wrong-tool calls.
- Faster onboarding to the right workflow.
- More accurate host-AI summaries of Critical Compass's role.
