# Comparable Tools Knowledge Layer UX Notes

## UX Goal
Help the user and host AI answer one question quickly: "Is Critical Compass the right tool for this job?"

## Good UX
- Short comparison cards.
- Clear "similar / different / take from this" framing.
- No long list of unrelated products.

## Failure Modes
- Tool list becomes a catalog dump.
- Comparisons drift into marketing copy.
- Host AI starts treating the layer as a substitute for the actual audit.

## Content Rules
- Keep comparisons concrete and job-based.
- Lead with what the tool is for.
- Never imply the external tool is the same thing as Critical Compass.
