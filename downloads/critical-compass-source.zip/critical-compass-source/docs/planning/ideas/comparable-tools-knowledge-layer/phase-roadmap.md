# Comparable Tools Knowledge Layer Phase Roadmap

## Phase 1
- Build a curated local comparison catalog.
- Define the comparison fields and adopt/adapt/reject labels.
- Wire the catalog into overview and onboarding text.

## Phase 2
- Add structured routing hints from the catalog to host-AI prompts.
- Add comparison snippets to report preambles and docs.

## Phase 3
- Optional external sync from public MCP registries or GitHub lists.
- Add periodic refresh rules if the optional sync proves useful.

## Stop Condition
Do not add live registry browsing until the local catalog is already useful on its own.
