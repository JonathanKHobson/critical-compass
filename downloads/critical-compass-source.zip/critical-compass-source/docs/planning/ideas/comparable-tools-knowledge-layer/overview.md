# Comparable Tools Knowledge Layer

## Problem / Opportunity
Critical Compass can already audit text, but it still needs a clearer way to explain where it fits among adjacent tools and methods. Without that layer, host AIs and users may overfit the wrong workflow, compare unlike systems, or miss the simplest next step.

## Why This Matters
This product is already a critical-thinking system, not a generic assistant. A comparable-tools layer helps it stay legible: "here is what this does, here is what it is not, and here is the closest tool or method if you need a different job."

## User Segments / Jobs
- Host AIs that need routing guidance before choosing a workflow.
- Users deciding whether to use audit, claim stress-test, report generation, or a different method.
- Maintainers who need a principled way to classify outside inspiration.

## Adjacent Inspirations
- Sequential Thinking MCP
- Ethics Check MCP
- ThoughtProof
- Idea Reality MCP
- Kialo and Rationale
- FactRank and ClaimBuster

## Adopt / Adapt / Reject
- Adopt directly: classification as a read-only knowledge resource.
- Adapt locally: tool comparisons and "best for" guidance.
- Optional external integration: live registry sync to GitHub or MCP directories.
- Reject: turning the layer into a generic recommendation engine.

## Belongs As
Resource, server instruction, and report artifact. Not a core public tool in phase 1.
