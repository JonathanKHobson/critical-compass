# Comparable Tools Knowledge Layer Tickets

- CTK-01: Define comparison schema for tools, methods, and MCPs.
- CTK-02: Curate the first set of adjacent inspirations and decisions.
- CTK-03: Add overview text that uses the catalog for routing.
- CTK-04: Add maintenance rules for catalog updates.
- CTK-05: Add evaluation cases for "wrong tool chosen" failures.

## Status Snapshot - 2026-04-15

- CTK-01 through CTK-05: Done. The local machine-readable registry now includes schema, curated records, maintenance guardrails, and wrong-tool evaluation cases.
- CTK-06: Done - `support/registry/comparable_tools.json` carries adopt/adapt/integrate/reject classification records.
- CTK-07: Done - `critical_compass_overview(topic="comparable_tools")` surfaces the records and evaluation cases through overview/resources only; no marketplace-style public tool was added.
