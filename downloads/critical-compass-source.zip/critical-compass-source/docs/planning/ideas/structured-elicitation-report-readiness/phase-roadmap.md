# Phase Roadmap: Structured Elicitation And Report Readiness

## Phase 1: Readiness Contract
- Define the minimum fields needed for report generation.
- Add a structured missing-context checklist.
- Make placeholders an explicit override, not the default path.

## Phase 2: Elicitation Flow
- Ask short, non-sensitive follow-up questions for missing context.
- Save answers into the audit state.
- Tie the questions to the report sections they unlock.

## Phase 3: Report Hardening
- Prevent blank sections from shipping.
- Add canonical examples and template reports for the host AI to reference.
- Track which prompts most often unblock readiness.

