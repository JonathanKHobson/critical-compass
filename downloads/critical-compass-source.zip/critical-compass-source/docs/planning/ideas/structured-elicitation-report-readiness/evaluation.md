# Evaluation: Structured Elicitation And Report Readiness

## What Success Looks Like
- Final reports are complete enough to stand on their own.
- The host AI asks for missing context before generating a PDF.
- Users can tell what is required and why.

## Evaluation Methods
- Readiness-gate regression tests.
- Missing-field fixtures.
- Review of question quality for clarity and sensitivity.
- Audit of how often placeholders are explicitly chosen versus inferred.

## Metrics
- Readiness pass rate on first try.
- Number of blocked incomplete reports.
- Reduction in blank/fallback sections.
- User-reported clarity of the follow-up questions.

