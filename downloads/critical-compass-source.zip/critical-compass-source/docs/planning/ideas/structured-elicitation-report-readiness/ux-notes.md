# UX Notes: Structured Elicitation And Report Readiness

## Reader Experience
The user should never feel surprised by a missing field after the PDF is already built. The system should ask for what it needs early, plainly, and in a small number of steps.

## Required Question Types
- Missing context for the report section being built.
- Stakeholder reflection prompts.
- Readiness confirmation before final PDF generation.

## UX Risks
- Too many questions will delay completion.
- Too few questions will let blank sections slip through.
- If the host AI guesses instead of asking, the whole gate fails.

## Belongs As
- Elicitation: yes.
- Prompt: yes.
- Report artifact: yes.
- Tool: yes, if the readiness gate needs to block generation.

