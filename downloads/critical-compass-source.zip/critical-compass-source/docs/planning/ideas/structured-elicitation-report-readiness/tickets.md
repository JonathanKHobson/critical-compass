# Tickets: Structured Elicitation And Report Readiness

## Prioritized Tickets
1. P0 - Define the report-ready minimum content contract.
2. P0 - Add structured follow-up questions for missing context.
3. P0 - Gate PDF generation on readiness or explicit placeholder approval.
4. P1 - Persist answer state into the audit lifecycle.
5. P1 - Add canonical examples and template report references.
6. P1 - Add stakeholder reflection prompts tied to report sections.
7. P2 - Track which prompts resolve readiness gaps most often.

## Status Snapshot - 2026-04-15

- Tickets 1, 2, 3, 5, and 6: Done through report readiness gates, missing-field diagnostics, Markdown checkpoint contracts, structured elicitation scaffold examples, and stakeholder reflection prompts.
- Ticket 4: Done for the current lifecycle through human-loop state handling and report payload diagnostics.
- Ticket 7: Evaluation backlog. Prompt-resolution analytics should wait until there is real usage data; no tracking is added by default.
