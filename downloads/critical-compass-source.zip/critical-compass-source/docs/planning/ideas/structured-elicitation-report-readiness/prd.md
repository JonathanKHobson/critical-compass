# PRD: Structured Elicitation And Report Readiness

## Goal
Collect missing context in a structured way and prevent incomplete reports from being treated as finished work.

## User Segments
- Host AI assembling the report payload.
- User answering missing-context questions.
- Reviewer checking whether the report had enough material to justify final output.

## Functional Requirements
- Ask bounded, non-sensitive follow-up questions for missing context.
- Gate final report generation on report readiness.
- Separate onboarding, judgment, reflection, and report-ready questions.
- Preserve answers in the audit state for later use.
- Provide a stable checklist of required content before PDF generation.

## Non-Goals
- No personal data fishing.
- No open-ended interrogation.
- No automatic placeholder promotion to final status.

## Acceptance Criteria
- Missing report fields are surfaced before PDF generation.
- Follow-up questions are short and specific.
- The host AI can tell the user what is still needed and why.

## Success Metrics
- Higher report completion quality.
- Fewer blank or fallback-only pages.
- Reduced regeneration loops.

