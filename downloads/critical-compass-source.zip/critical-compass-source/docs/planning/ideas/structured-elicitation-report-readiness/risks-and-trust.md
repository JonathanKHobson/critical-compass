# Risks And Trust: Structured Elicitation And Report Readiness

## Key Risks
- The host AI may still try to fill gaps by inference.
- A readiness gate can become a rote checkbox if the questions are too generic.
- Users may feel interrupted too late, after work has already been wasted.
- Placeholder mode may be mistaken for final output.

## Mitigations
- Make canonical fields and examples explicit.
- Tie each question to a concrete missing section.
- Log readiness failures and the reason they occurred.
- Label placeholder output as draft-only.

## Trust Boundary
This layer should make incompleteness visible before it becomes expensive. It should not let the model “smooth over” missing substance.

