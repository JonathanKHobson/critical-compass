# Structured Elicitation And Report Readiness

## Problem / Opportunity
The current workflow can drift into report generation before the audit has enough substance. A structured elicitation layer can ask for the missing context, gate report readiness, and keep the final artifact from shipping blank or fallback-heavy sections.

## Why This Matters For Critical Compass
Critical Compass should not just be a better writer of reports; it should be a better judge of when a report is ready. This idea protects the quality of plain-language read, before-use text, questions, next steps, and stakeholder reflection.

## Users And Jobs To Be Done
- Host AI: collect the right missing fields before PDF generation.
- Audit author: supply the smallest useful context without being overwhelmed.
- Reviewer: see that the report was assembled from adequate evidence, not improvisation.

## Borrowed Ideas
- Prompt workflow servers: adapt as scaffolds, not dependencies.
- Readiness-gated report contracts: adopt locally.
- Structured intake forms: adapt for non-sensitive follow-up questions.
- Generic “ask the model later” approaches: reject.

## Adopt / Adapt / Reject
- Adopt: report-readiness gating before PDF generation.
- Adapt: follow-up questions into short, structured elicitation blocks.
- Reject: freeform prompt sprawl that lets the model guess missing content.

## Belonging
- Primary form: elicitation + server instruction + report artifact.
- Secondary form: resource for canonical examples and readiness templates.

## Smallest Shippable Slice
Ask a fixed set of non-sensitive follow-up questions when report-ready fields are missing, then block final report generation until the minimum content contract is satisfied or the user explicitly accepts placeholders.

