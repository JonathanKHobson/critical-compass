# Slice Roadmap: Structured Elicitation And Report Readiness

## Slice 1
- Define report-ready minimum fields and missing-field prompts.
- Block final report generation until those fields are satisfied or placeholders are explicitly approved.

## Slice 2
- Add stakeholder reflection prompts and capture the answer state.
- Provide a compact checklist artifact the host AI can show before PDF generation.

## Slice 3
- Add canonical example payloads and template report references.
- Track which questions most often resolve the gap.

