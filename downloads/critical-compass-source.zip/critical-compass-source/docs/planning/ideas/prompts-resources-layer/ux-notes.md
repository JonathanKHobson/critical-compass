# UX Notes: Prompts / Resources Layer

## Reading Order
The host AI should be able to answer these questions in one pass:

1. What workflow am I in?
2. What fields are required?
3. What canonical names should I use?
4. What example should I mirror?

## Wording Rules
- Canonical names should be visually obvious.
- Examples should show real shape, not just labels.
- Workflow guidance should stay short enough to use during a live audit.
- Do not bury the preferred field names under optional aliases.

## Failure Modes To Avoid
- Prompt sprawl.
- Hidden versions with no change log.
- Duplicate guidance in multiple places.
- The host AI treating examples as optional inspiration instead of a contract.

