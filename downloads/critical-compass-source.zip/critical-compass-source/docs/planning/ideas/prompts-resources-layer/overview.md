# Prompts / Resources Layer

## Problem / Opportunity
Critical Compass already has rich reasoning content, but host AIs still need a cleaner way to discover the right workflow, canonical fields, examples, and output contracts before they start an audit.

The opportunity is to expose the system as a structured resource layer:

- canonical prompts
- reusable workflow contracts
- example payloads
- field glossaries
- reasoning-flow references

## Users And Jobs To Be Done
- Host AI: find the right prompt or contract without improvising.
- Maintainer: version and curate the official workflow guidance.
- Power user: see what fields and outputs the tool expects.
- New contributor: understand the core audit flow without reading code.

## Why It Matters For Critical Compass
This is the strongest defense against alias drift, blank report sections, and tool misuse. The reasoning system is only useful if the host AI can find the right contract quickly and use it consistently.

## Borrowed Patterns Worth Reusing
- Prompt library / prompt pack design.
- Reusable workflow contracts from guardrail and agent systems.
- Sequential thinking and structured scratchpad patterns.
- Documentation-as-interface patterns from developer tools.

## Recommended Form
This idea belongs primarily as a **resource layer**, with some pieces expressed as prompt guidance and some as read-only examples.

## UX Risks And Failure Modes
- Too many prompts or examples can create choice paralysis.
- The host AI may still use the wrong alias if the canonical field names are not prominent.
- Resources can drift from the implementation if they are not versioned.
- The layer can become a junk drawer if it mixes instructions, examples, and references without structure.

## Decision Snapshot
- Adopt: prompt library and canonical example pack.
- Adapt: workflow contract pages and field glossaries.
- Reject: hidden prompt magic that cannot be inspected or versioned.

