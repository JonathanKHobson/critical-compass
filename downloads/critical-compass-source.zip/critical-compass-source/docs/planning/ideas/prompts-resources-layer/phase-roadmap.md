# Phase Roadmap: Prompts / Resources Layer

## Phase 1
- Publish canonical field names and workflow contracts.
- Add one authoritative example payload per major workflow.
- Add concise start-here resources for host AIs.

## Phase 2
- Add versioned prompt packs for audit, report, and self-audit flows.
- Add field glossaries and alias guidance.
- Add references to the most useful reasoning flows.

## Phase 3
- Add reusable examples for advanced audit, report readiness, and human-loop prompts.
- Add resource pages for common failure modes and recovery steps.

## Phase 4
- Add optional UI surfacing for these resources if the MCP App UI is justified later.

