# Slice Roadmap: Prompts / Resources Layer

## Smallest Shippable Slice
1. Canonical prompt page with the expected audit/report fields.
2. Example payload page for report-ready output.
3. Alias glossary that points to the preferred canonical names.

## Follow-On Slices
1. Workflow contract page for audit-to-report generation.
2. Example payloads for advanced audit and self-mode.
3. Reasoning-flow reference pack.
4. Recovery notes for schema warnings and placeholder reports.

