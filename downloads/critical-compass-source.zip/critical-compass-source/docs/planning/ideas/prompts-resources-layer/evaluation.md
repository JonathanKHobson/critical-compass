# Evaluation: Prompts / Resources Layer

## What Success Looks Like
- The host AI uses the canonical field names more often than aliases.
- The first report call happens with the right payload more often.
- Users can find the expected fields without opening code.
- Example payloads match the live tool behavior.

## Evaluation Methods
- Prompt-following review against the canonical contract.
- Alias-usage audit from real outputs.
- Example drift checks against current payload fixtures.
- Host-AI onboarding smoke tests.

## Acceptance Gates
- Canonical prompt, glossary, and example resources are discoverable from one path.
- Resources stay synchronized with the real payload contract.
- Resource changes do not require core code changes.

