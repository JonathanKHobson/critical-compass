# Risks And Trust: Prompts / Resources Layer

## Risks
- Host AIs use the wrong field names anyway.
- Example payloads drift from the real implementation.
- The resource layer becomes too large to navigate.
- Versioning confusion causes stale guidance.

## Mitigations
- Put canonical names first.
- Link examples directly to the live contract.
- Keep the resource index shallow and searchable.
- Version every example and contract page.

## Trust Boundaries
- Prompts should guide behavior, not replace validation.
- Examples should clarify the contract, not bypass it.
- The resource layer should not secretly alter audit logic.

