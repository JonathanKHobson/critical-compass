# PRD: Prompts / Resources Layer

## Goal
Make the Critical Compass workflow legible to the host AI before it calls the tool.

## Scope
The resource layer should include:
- canonical prompts
- example payloads
- field glossaries
- workflow contracts
- reasoning-flow references

## Non-Goals
- No automatic web search by default.
- No new reasoner hidden inside prompt text.
- No duplication of the core audit logic.

## Requirements
1. Canonical field names must be easy to find.
2. Example payloads must match the live tool contract.
3. Workflow prompts must tell the host AI what to assemble before the report call.
4. Resources must be versioned and easy to inspect.
5. The layer must support both reader-mode and self-mode workflows.

## UX And Content Rules
- Put the canonical names first.
- Keep examples short but complete.
- Separate "what to fill" from "how to think."
- Make the resource set discoverable from a single start-here path.

## Acceptance Criteria
- Host AIs can locate the current contract without reading code.
- The canonical examples match the real payload shape.
- Workflow resources reduce alias confusion and regeneration loops.
- The resource layer can be updated without changing core reasoning code.

## Success Metrics
- Fewer blank or placeholder report calls.
- Fewer schema mismatch warnings.
- Faster first successful report generation.
- More consistent use of canonical field names.

## Dependencies
- Stable normalized payload schema.
- Report readiness and alias handling.
- Core reasoning-flow references.

