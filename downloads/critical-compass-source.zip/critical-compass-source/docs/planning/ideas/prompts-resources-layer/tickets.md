# Tickets: Prompts / Resources Layer

1. Write the canonical start-here prompt for report-ready audits.
2. Publish the canonical audit and report payload examples.
3. Publish the alias glossary with preferred field names.
4. Add version labels to workflow resources.
5. Add example prompts for reader mode and self mode.
6. Add recovery guidance for schema warnings and missing fields.
7. Add reasoning-flow references for common audit paths.

## Status Snapshot - 2026-04-15

- Tickets 1 through 6: Done through versioned scaffold resources under `support/resources/scaffolds/v1/`, overview-exposed workflow resources, report-readiness contracts, and server instructions.
- Ticket 7: Addressed by preserving existing reasoning-flow resources in `support/reasoning-flows/` and linking workflow guidance through overview resources. No new public tool was added.
