# Mergeability: Prompts / Resources Layer

## Borrowed Inspirations And Decisions

| Inspiration | Type | Borrow | Decision |
|---|---|---:|---|
| Prompt libraries / prompt packs | Method | Reusable prompt text and examples | Adopt directly |
| Claude Prompts style workflow packs | MCP / tool pattern | Discoverable, reusable host guidance | Adapt locally |
| Sequential Thinking MCP | MCP | Structured reasoning scaffolds | Adapt locally |
| Field glossaries / schema docs | Method | Canonical names and alias mapping | Adopt directly |
| Hidden prompt injection patterns | Risk pattern | Need to avoid opaque behavior | Reject |

## Local Mergeability Assessment
- Open-source or proprietary: mostly method-driven, with some open-source inspiration.
- License risk: low if we author the content ourselves and do not copy proprietary prompts.
- Local/self-hostable status: fully local-first.
- Maturity and maintenance burden: medium; the main burden is keeping examples in sync with the tool contract.
- Dependency footprint: low.
- Security and trust risks: stale prompt examples, alias drift, and host-AI overreliance on outdated guidance.
- Recommendation: build locally as a curated resource layer.

## Adopt / Adapt / Reject Summary
- Adopt directly: prompt pack, field glossary, canonical examples.
- Adapt and rebuild locally: workflow contract pages and reasoning-flow references.
- Reject: hidden or proprietary prompt sets that cannot be inspected or versioned.

