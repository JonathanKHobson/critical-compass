# Risks And Trust: Reasoning Trap Detectors

## Key Risks
- The detector becomes too eager and starts flagging ordinary prose.
- Check-worthiness gets misread as “false.”
- The system treats rhetorical force as evidence of error.
- A trap label is shown without the explanation needed to trust it.

## Mitigations
- Keep the trap set narrow at first.
- Separate truth, confidence, and check-worthiness in the schema.
- Require a human-readable reason and next check for every label.
- Add red-team fixtures for false positives.

## Trust Boundary
The detector should warn the host AI, not override the audit. It is a triage layer, not a judge.

