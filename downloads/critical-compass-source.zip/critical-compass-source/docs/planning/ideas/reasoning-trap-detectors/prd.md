# PRD: Reasoning Trap Detectors

## Goal
Surface common reasoning traps early enough that the host AI can tighten the audit before it becomes a polished but shaky conclusion.

## User Segments
- Host AI running the audit.
- Power user revising a draft.
- Reviewer comparing competing interpretations.

## Functional Requirements
- Detect a bounded set of trap categories.
- Rank only factual claims for verification priority.
- Leave normative, interpretive, and policy claims in a separate lane.
- Never label a claim false just because it is check-worthy.
- Return concise rationale and a recommended next check.

## Non-Goals
- No claim-truth oracle.
- No automatic browsing by default.
- No replacement for human judgment.

## Acceptance Criteria
- Trap labels are specific enough to be useful and conservative enough to avoid overreach.
- Check-worthiness is clearly separated from truth value.
- The host AI can use the result without re-interpreting the whole audit.

## Success Metrics
- Fewer unsupported certainty errors.
- Faster identification of weak claims.
- Lower rate of later correction in reports and summaries.

