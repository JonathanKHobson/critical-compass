# Reasoning Trap Detectors

## Problem / Opportunity
Critical Compass already spots biases and fallacies, but it still relies on the host or user to notice some reasoning failures early. A trap-detector layer can flag overgeneralization, false dilemma, missing denominator, unsupported certainty, and other common failure modes before they harden into a verdict.

## Why This Matters For Critical Compass
This is the difference between “helpful audit” and “strong audit.” Trap detectors make the system more consistent, especially when users are under pressure and likely to miss the weakest part of their own reasoning.

## Users And Jobs To Be Done
- Host AI: get a short list of likely reasoning traps.
- Audit author: see where the argument got loose.
- Reviewer: separate factual risk from rhetorical risk.

## Borrowed Ideas
- Verifiable Thinking-style checks: adapt for confidence and verification gates.
- FactRank-style check-worthiness: adapt to rank claims without calling them false.
- Claim stress-testing: adopt as a drill-down pattern.
- Socratic questioning and pre-mortems: adopt as prompt scaffolds.

## Adopt / Adapt / Reject
- Adopt: distinguish “worth checking” from “false.”
- Adapt: traps as short labels plus explanations, not a giant taxonomy dump.
- Reject: automatic web search as a default audit dependency.

## Belonging
- Primary form: tool + prompt.
- Secondary form: resource for trap examples and report artifacts.

## Smallest Shippable Slice
Detect a small set of high-value traps on audit output, rank factual claims for check-worthiness, and expose the result in the audit summary and report notes.

