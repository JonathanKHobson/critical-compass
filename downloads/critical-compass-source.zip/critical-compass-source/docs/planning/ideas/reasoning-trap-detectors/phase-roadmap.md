# Phase Roadmap: Reasoning Trap Detectors

## Phase 1: Detector Core
- Implement a small trap set with high precision.
- Add check-worthiness ranking for factual claims only.
- Keep the output compact and deterministic.

## Phase 2: Host-AI Guidance
- Add prompt guidance for how to use trap results.
- Attach “next check” language to each trap.
- Integrate the output into audit readiness notes.

## Phase 3: Broader Coverage
- Expand the trap catalog carefully.
- Add pattern tracking for repeated reasoning failures.
- Decide whether any trap classes belong in report artifacts.

