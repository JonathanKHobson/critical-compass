# UX Notes: Reasoning Trap Detectors

## Reader Experience
The output should feel like a calibrated nudge, not a scolding. A good trap detector says, “here is the weak spot, and here is the next question.”

## UX Risks
- Overlabeling can make the system feel hostile.
- Underlabeling makes the tool feel decorative.
- If check-worthiness is confused with falsity, trust drops fast.

## UX Rules
- Use plain language first, labels second.
- Keep factual vs interpretive routing visible.
- Attach one next action to each trap.

## Belongs As
- Tool: yes.
- Prompt: yes.
- Resource: yes, for the trap library.
- Report artifact: yes, for summary notes.

