# Evaluation: Reasoning Trap Detectors

## What Success Looks Like
- Common reasoning traps are found early and labeled conservatively.
- The host AI uses the output to tighten claims instead of amplifying it.
- Users can tell the difference between “check this” and “false.”

## Evaluation Methods
- Precision-focused fixture tests.
- False-positive review on neutral prose.
- Verification that only factual claims are ranked for check-worthiness.
- User review of next-step clarity.

## Metrics
- Trap precision.
- False-positive rate.
- Share of factual claims routed into check-worthiness.
- Reduction in later report corrections.

