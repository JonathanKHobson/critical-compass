# Tickets: Reasoning Trap Detectors

## Prioritized Tickets
1. P0 - Define the trap taxonomy and the factual / interpretive claim split.
2. P0 - Implement check-worthiness ranking for factual claims only.
3. P0 - Add conservative trap detection for a small high-value set.
4. P1 - Add “next check” guidance to each trap result.
5. P1 - Wire trap output into audit summaries and report notes.
6. P2 - Add pattern tracking for recurring trap shapes.
7. P2 - Expand the trap set only after false-positive review.

## Status Snapshot - 2026-04-15

- Tickets 1, 3, 4, and 5: Done with advisory trap outputs and report rendering.
- Ticket 2: Done through the check-worthy claims lane; factual claim ranking remains separate from trap detection.
- Ticket 6: Done - recurring reasoning-trap shapes can be saved through existing entity pattern storage with `entity_type="reasoning_trap"`.
- Ticket 7: Done for the locally rebuilt taxonomy covering base-rate neglect, missing denominator, anecdotal evidence, authority laundering, and circular framing.
- RTD-08: Done - false-positive calibration fixtures cover short-token risks, and trap outputs are priority ordered by severity before report selection.
