# Slice Roadmap: Reasoning Trap Detectors

## Slice 1
- Detect a short list of traps: overgeneralization, false dilemma, unsupported certainty, missing denominator, and causal overreach.
- Rank factual claims by check-worthiness.

## Slice 2
- Add explanation text and “what to check next.”
- Distinguish factual claims from interpretive, causal, normative, and policy claims.

## Slice 3
- Connect trap output to report notes and saved patterns.
- Add regression fixtures for near-miss and false-positive cases.

