# Mergeability: Optional MCP App UI

## Borrowed Inspirations And Decisions

| Inspiration | Type | Borrow | Decision |
|---|---|---:|---|
| Kialo | Proprietary SaaS | Argument-tree browsing | Adapt locally |
| Rationale | Proprietary SaaS | Reasoning inspection and comparison | Adapt locally |
| Document review tools | Method | Inline comment and comparison patterns | Adopt directly |
| MCP App UI surfaces | Platform pattern | Optional visual layer | Adopt directly if needed later |

## Local Mergeability Assessment
- Open-source or proprietary: could be either, but the safest first move is local/self-hosted.
- License risk: medium if third-party UI code or assets are pulled in.
- Local/self-hostable status: should remain local-first if built.
- Maturity and maintenance burden: high compared with the backend planning docs.
- Dependency footprint: high if a browser app is introduced.
- Security and trust risks: UI drift, stale artifact rendering, and UI becoming a second source of truth.
- Recommendation: defer and only build after the artifact contracts are stable.

## Adopt / Adapt / Reject Summary
- Adopt directly: browsing and comparison patterns, read-only inspector behavior.
- Adapt and rebuild locally: argument-map browsing and report review panes.
- Reject: treating the UI as core infrastructure in phase 1.

