# Phase Roadmap: Optional MCP App UI

## Phase 1
- Shipped: local read-only artifact viewer generated from report manifests.
- Shipped: report links, decision layer, argument map, Evidence Needed Next, dissent ledger, reasoning traps, questions, and trust preflight sections.
- Shipped: no editing, no live reasoning, no external retrieval, no second source of truth.

## Phase 2
- Defer side-by-side report comparison until users need multi-version review.
- Defer inline review or comments until a concrete workflow displaces other work.

## Phase 3
- Consider hosted MCP App UI only if local static viewer is insufficient.
- Keep export paths owned by the deterministic report/artifact pipeline.
