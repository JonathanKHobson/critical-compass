# UX Notes: Optional MCP App UI

## Reading Order
The UI should match the report logic:

1. Judgment first.
2. Evidence second.
3. Dissent and uncertainty visible when relevant.
4. Deep detail only on demand.

## Wording Rules
- Keep labels short.
- Preserve canonical field names in the inspector views.
- Do not create a second narrative that competes with the report.
- Make browsing and review feel optional, not mandatory.

## Failure Modes To Avoid
- A shiny UI that hides the actual decision.
- Duplicate views that do not add meaning.
- A build that arrives before the backend is stable enough to support it.

