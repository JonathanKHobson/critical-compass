# Slice Roadmap: Optional MCP App UI

## Smallest Shippable Slice
1. [Done] Read-only report viewer.
2. [Done] Read-only argument map viewer.
3. [Done] No editing, no live reasoning, no workflow replacement.

## Follow-On Slices
1. [Deferred] Side-by-side comparison of two report versions.
2. [Deferred] Inline comments or annotations.
3. [Done] Dissent and uncertainty inspection through static sections.
4. [Done] Export links back to existing Markdown, PDF, and Argdown artifacts.
