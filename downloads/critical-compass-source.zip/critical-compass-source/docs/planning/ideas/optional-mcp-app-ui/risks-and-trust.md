# Risks And Trust: Optional MCP App UI

## Risks
- The UI becomes a distraction from the core audit product.
- The UI duplicates logic that already exists in the artifact layer.
- The UI adds more maintenance than it saves.

## Mitigations
- Keep it optional and later-phase.
- Make it read-only at first.
- Tie it to canonical artifacts only.
- Do not let it redefine the audit contract.

## Trust Boundaries
- The UI should visualize truth already produced by the MCP, not generate new truth.
- Any edit path must remain secondary to the canonical audit and report pipeline.

