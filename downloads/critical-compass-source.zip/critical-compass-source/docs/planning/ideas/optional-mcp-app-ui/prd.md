# PRD: Optional MCP App UI

## Goal
Provide a visual layer for audit exploration without making the UI the primary product.

## Scope
The UI may eventually support:
- argument map viewing
- inline review
- report browsing
- report comparison
- dissent inspection

## Non-Goals
- No replacement for the MCP core.
- No requirement that the UI ship with phase 1.
- No redesign of the reasoning engine.

## Requirements
1. The UI must read existing audit artifacts, not invent new findings.
2. It must preserve the distinction between evidence and interpretation.
3. It must not become a dependency for core server workflows.
4. It must stay useful if the backend is accessed from text or PDF only.

## UX And Content Rules
- Show the decision layer first.
- Keep evidence drill-down available but not forced.
- Make dissent and uncertainty visible.
- Avoid duplicating the same content in too many panes.

## Acceptance Criteria
- A user can inspect an argument map without opening code.
- A user can review a report and its evidence in one place.
- The UI can be deferred until backend contracts stabilize.
- The UI does not create a new source of truth.

## Success Metrics
- Faster review of complex audits.
- Better comprehension of dissent and evidence gaps.
- Fewer requests to manually reconstruct audit structure.

## Dependencies
- Stable argument_map output.
- Stable report artifacts.
- Stable host-AI workflow contracts.

