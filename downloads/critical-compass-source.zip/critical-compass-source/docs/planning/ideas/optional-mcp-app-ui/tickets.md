# Tickets: Optional MCP App UI

1. [Done] Define the minimum read-only views.
2. [Done] Define the artifact navigation model.
3. [Done] Define how the UI reads report and argument-map artifacts.
4. [Deferred] Define comparison view requirements only after at least three real user sessions require multi-report comparison.
5. [Deferred] Define annotation or comment requirements only after at least three real user sessions require inline review.
6. [Done] Add overview/scaffold/runbook surfaces so host AIs can discover the viewer and know it is read-only.

Implementation note: v1 is a local static artifact viewer generated from the report manifest by `generate_audit_artifact_viewer`. It is intentionally read-only and does not create findings, run retrieval, or replace PDF/Markdown artifacts as the source of truth.
