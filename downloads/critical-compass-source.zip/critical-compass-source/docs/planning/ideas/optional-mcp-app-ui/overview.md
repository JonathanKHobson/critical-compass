# Optional MCP App UI

## Problem / Opportunity
Critical Compass is already useful in text and PDF form, but some workflows would benefit from a visual layer: argument maps, inline review, report browsing, and artifact comparison.

The v1 opportunity is now implemented as a local read-only artifact viewer that surfaces the audit without changing the audit engine.

## Users And Jobs To Be Done
- Reviewer: inspect the reasoning path quickly.
- Facilitator: point to specific claims, questions, or evidence gaps.
- Teacher / coach: walk through a report live.
- Power user: compare versions or inspect dissent.

## Why It Matters For Critical Compass
The UI can make the system easier to teach and easier to trust, but only after the core audit and report contracts are stable.

## Borrowed Patterns Worth Reusing
- Kialo-style argument trees.
- Rationale-style reasoning views.
- PDF/report preview and annotation tools.
- Comment-and-review surfaces from document tools.

## Recommended Form
This idea belongs primarily as an **artifact viewer / MCP App UI surface**. The shipped v1 is local static HTML generated from the report manifest. Rich comparison, annotations, and hosted app surfaces remain optional later work.

## UX Risks And Failure Modes
- The UI could become a vanity layer that distracts from the core audit system.
- It could duplicate the logic already captured in Markdown / PDF artifacts.
- It could add maintenance cost before the backend contract is stable.

## Decision Snapshot
- Adopt: read-only visual exploration for argument maps and report browsing.
- Adapt: comment, compare, and side-by-side review patterns only after real use justifies them.
- Reject: UI that creates findings, runs retrieval, or becomes a second source of truth.
