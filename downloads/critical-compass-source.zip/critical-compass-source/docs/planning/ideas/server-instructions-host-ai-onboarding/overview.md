# Server Instructions for Host-AI Onboarding

## Problem / Opportunity
The main failure mode in the repo is not just missing fields; it is the host AI starting the wrong workflow, calling the report tool too early, or using aliases that do not match the canonical contract.

The opportunity is to make the server itself explain a concise, model-agnostic workflow contract before the host AI acts.

## Users And Jobs To Be Done
- Host AI: follow the correct order and use the right field names.
- Maintainer: change the server contract without retraining every prompt.
- Power user: see what the tool expects before submitting an audit.

## Why It Matters For Critical Compass
If onboarding is weak, the whole system wastes time in regeneration loops and placeholder reports. Strong server instructions are the cheapest way to stop that failure at the source.

## Borrowed Patterns Worth Reusing
- Tool metadata that includes input contracts and warnings.
- Safety checklists from guardrail systems.
- Structured readiness gates from report and validation workflows.
- Short workflow contracts from developer-facing APIs.

## Recommended Form
This idea belongs primarily as **server instruction text** and **tool metadata**, with a small amount of structured elicitation support.

## UX Risks And Failure Modes
- Instructions can be too long for a host AI to retain.
- If the rules are vague, the AI will still improvise.
- If the rules are too strict, the AI may over-block useful partial work.

## Decision Snapshot
- Adopt: concise, model-agnostic workflow rules.
- Adapt: readiness-gated report behavior and human-loop pause semantics.
- Reject: long prompt essays that mix instruction, example, and implementation detail.

