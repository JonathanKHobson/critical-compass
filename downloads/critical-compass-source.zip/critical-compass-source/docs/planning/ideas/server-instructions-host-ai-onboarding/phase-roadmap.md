# Phase Roadmap: Server Instructions for Host-AI Onboarding

## Phase 1
- Write the canonical workflow contract.
- Add a short "what to assemble before calling the report tool" block.
- Add the warning / resubmit / continue behavior.

## Phase 2
- Add human-loop pause guidance and skip semantics.
- Add alias preference guidance.
- Add report readiness examples.

## Phase 3
- Add workflow-specific variants for reader mode, self mode, and research mode.
- Add a compact troubleshooting section for common host-AI mistakes.

