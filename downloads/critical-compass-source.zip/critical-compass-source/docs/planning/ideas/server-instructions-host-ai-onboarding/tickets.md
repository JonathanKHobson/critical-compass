# Tickets: Server Instructions for Host-AI Onboarding

1. Draft the concise workflow contract text.
2. Draft the pre-call checklist for report generation.
3. Draft the post-call warning handling rules.
4. Draft the human-loop pause semantics for the server description.
5. Add canonical alias preference language.
6. Add mode-specific notes for reader, self, and research workflows.

## Status Snapshot - 2026-04-15

- Tickets 1 through 6: Done through the `generate_audit_report` tool description, report-readiness contract, overview workflow resources, and `support/resources/scaffolds/v1/server-instructions.md`.
