# UX Notes: Server Instructions for Host-AI Onboarding

## Reading Order
The host AI should learn, in this order:

1. What workflow am I in?
2. What do I need before I call the tool?
3. What happens if I am missing something?
4. What should I do after the tool returns?

## Wording Rules
- Keep the workflow contract short.
- Use canonical names, not aliases, in the primary guidance.
- Put human-loop pause rules where they are hard to miss.
- Make the warning response behavior concrete.

## Failure Modes To Avoid
- Instruction overload.
- Confusing optional fields with required ones.
- Silent regeneration loops.
- Host AI ignoring warnings because the instruction only lives in the tool description.

