# PRD: Server Instructions for Host-AI Onboarding

## Goal
Make the host AI start in the right place, assemble the right payload, and stop before a bad report call.

## Scope
The server instruction layer must define:
- workflow order
- required fields
- readiness gate behavior
- alias preference
- human-loop pause rules
- post-call handling when warnings appear

## Non-Goals
- No new reasoning engine.
- No automatic web retrieval by default.
- No implementation of the audit logic itself.

## Requirements
1. The instructions must be concise enough to read before each run.
2. They must be model-agnostic.
3. They must tell the host AI what to do before calling the report tool.
4. They must tell the host AI what to do when warnings appear.
5. They must preserve the human-loop pause contract.

## UX And Content Rules
- Use imperative, plain language.
- Put the canonical names and order first.
- Make the "do not call yet" rule explicit.
- Make the re-submit / continue decision explicit when fields are missing.

## Acceptance Criteria
- Host AI can follow the workflow without reading implementation code.
- The server description discourages premature report generation.
- Warnings trigger a pause instead of silent regeneration.
- Human-loop prompts clear before final output.

## Success Metrics
- Fewer premature PDF calls.
- Fewer blank or fallback report sections.
- Better canonical-field usage.
- Fewer report retries per audit.

## Dependencies
- Readiness gate logic.
- Report payload contract.
- Human-loop prompt flow.
- Alias-aware normalization.

