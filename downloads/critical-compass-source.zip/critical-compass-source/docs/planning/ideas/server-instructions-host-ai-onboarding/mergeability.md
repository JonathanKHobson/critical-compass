# Mergeability: Server Instructions for Host-AI Onboarding

## Borrowed Inspirations And Decisions

| Inspiration | Type | Borrow | Decision |
|---|---|---:|---|
| MCP tool descriptions | Platform pattern | Tool-level usage contract | Adopt directly |
| Guardrail / safety checklist patterns | Method | Pre-call and post-call behavior rules | Adapt locally |
| Prompt onboarding blocks | Method | Short workflow guidance | Adopt directly |
| Hidden system prompt behavior | Risk pattern | Hard to inspect or debug | Reject |

## Local Mergeability Assessment
- Open-source or proprietary: local server instructions; no external dependency required.
- License risk: low.
- Local/self-hostable status: fully local.
- Maturity and maintenance burden: low to medium; mostly text maintenance.
- Dependency footprint: very low.
- Security and trust risks: instruction drift, stale alias guidance, and conflicting versions of the contract.
- Recommendation: build locally and keep the text close to the live tool behavior.

## Adopt / Adapt / Reject Summary
- Adopt directly: concise workflow contract text, warning-handling text.
- Adapt and rebuild locally: human-loop pause semantics and alias preference language.
- Reject: opaque or long-winded system-prompt only guidance.

