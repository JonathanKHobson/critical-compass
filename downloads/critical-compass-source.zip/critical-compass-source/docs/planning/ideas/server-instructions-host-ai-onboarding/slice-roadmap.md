# Slice Roadmap: Server Instructions for Host-AI Onboarding

## Smallest Shippable Slice
1. One concise onboarding block for audit-to-report workflows.
2. One explicit rule: do not call the report tool until required fields are assembled.
3. One explicit warning-handling block for missing or fallback-only content.

## Follow-On Slices
1. Human-loop pause and resume guidance.
2. Canonical alias preference guidance.
3. Reader / self / research variants.
4. Troubleshooting notes for blank or partial report calls.

