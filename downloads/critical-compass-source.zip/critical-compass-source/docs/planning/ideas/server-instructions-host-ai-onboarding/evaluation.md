# Evaluation: Server Instructions for Host-AI Onboarding

## What Success Looks Like
- The host AI asks for the needed fields before the report call.
- The host AI pauses when human-loop prompts are pending.
- Warnings lead to re-submit decisions instead of silent retries.
- Canonical field names show up in the payload more consistently.

## Evaluation Methods
- Smoke tests with incomplete payloads.
- Host-AI prompt compliance review.
- Regression tests for the report call order.
- Review of warning handling in saved runs.

## Acceptance Gates
- The instruction text is short and model-agnostic.
- It clearly says what to do before, during, and after report generation.
- It reduces premature report generation in test runs.

