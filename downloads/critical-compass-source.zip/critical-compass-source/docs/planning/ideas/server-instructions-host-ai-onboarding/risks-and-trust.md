# Risks And Trust: Server Instructions for Host-AI Onboarding

## Risks
- The host AI still jumps to the report tool too early.
- The instructions become stale after the tool contract changes.
- The host AI treats warnings as cosmetic.

## Mitigations
- Put the workflow contract in the server description and supporting resources.
- Version the instructions alongside the payload contract.
- Make the warning response behavior explicit and mandatory.

## Trust Boundaries
- The server should guide usage, not substitute for validation.
- Warnings should trigger human review or re-submit decisions.
- The host AI should never assume the report is final if readiness failed.

