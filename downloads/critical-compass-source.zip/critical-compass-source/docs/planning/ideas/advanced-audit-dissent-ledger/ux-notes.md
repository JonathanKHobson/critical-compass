# UX Notes: Advanced Audit Dissent Ledger

## Reader Experience
The reader should see that disagreement is a feature, not a failure. The output should answer: who disagreed, on what, and why the final synthesis still made sense.

## UX Risks
- Too much dissent text will bury the verdict.
- Too little context will make the ledger look ceremonial.
- If all agents sound interchangeable, the ledger loses trust value.

## UX Rules
- Show a one-line summary of agreement and disagreement first.
- Keep each agent row short and structurally identical.
- Use expandable detail only for readers who want the reasoning trail.

## Belongs As
- Tool: yes.
- Prompt: yes.
- Report artifact: yes.
- MCP App: optional later if the ledger needs a visual comparison surface.

