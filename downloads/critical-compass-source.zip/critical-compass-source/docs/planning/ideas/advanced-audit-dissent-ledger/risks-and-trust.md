# Risks And Trust: Advanced Audit Dissent Ledger

## Key Risks
- The ledger becomes a decorative appendix instead of a trust surface.
- Agents converge too quickly and manufacture false confidence.
- A verbose dissent trail overwhelms readers and reduces usability.
- Agent outputs could contain prompt injection or misleading provenance labels.

## Mitigations
- Require structured fields, not prose-only debate.
- Keep the ledger compact and stable across runs.
- Preserve raw source-of-finding metadata.
- Treat agent outputs as untrusted until normalized.

## Trust Boundary
The ledger should record disagreement, not resolve it by authority. The synthesis layer can choose a verdict, but it must show what it had to leave behind.

