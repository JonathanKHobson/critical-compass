# Phase Roadmap: Advanced Audit Dissent Ledger

## Phase 1: Schema And Capture
- Add required agent fields to the advanced-audit contract.
- Normalize agent outputs into one ledger shape.
- Block synthesis if the ledger is incomplete.

## Phase 2: Synthesis And Report Rendering
- Add the dissent ledger section to the synthesis payload.
- Render a compact summary in the PDF report.
- Preserve per-agent provenance in saved results.

## Phase 3: Comparison And Learning
- Track repeated disagreement patterns over time.
- Surface which agents are consistently more cautious or more skeptical.
- Use patterns to tune future agent scaffolds.

