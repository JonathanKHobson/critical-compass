# Tickets: Advanced Audit Dissent Ledger

## Prioritized Tickets
1. P0 - Define required dissent-ledger fields in the advanced-audit contract.
2. P0 - Normalize agent outputs into a single ledger object.
3. P0 - Block synthesis when any required dissent field is missing.
4. P1 - Persist ledger data in saved audit results.
5. P1 - Render dissent summary in report artifacts.
6. P1 - Add a compact provenance view for host AI prompts.
7. P2 - Track recurring disagreement patterns across audits.
8. P2 - Add guidance for compressing versus expanding dissent.

## Status Snapshot - 2026-04-15

- Tickets 1, 2, 5, and 6: Done through advanced-audit scaffolds, report-ready materials, Markdown/PDF rendering, and host-facing dissent guidance.
- Ticket 3: Not implemented as a hard block; current behavior preserves report optionality and uses readiness/report gates instead.
- Ticket 4: Done through `save_audit_result` result-payload persistence verification fixtures.
- Tickets 7 and 8: Done for the local-first path. Recurring disagreement patterns can use existing entity pattern storage with `entity_type="disagreement_pattern"`, and versioned scaffold guidance now explains when to compress versus expand dissent.
