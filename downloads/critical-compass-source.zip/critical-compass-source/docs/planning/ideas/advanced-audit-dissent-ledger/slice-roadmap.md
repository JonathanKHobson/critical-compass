# Slice Roadmap: Advanced Audit Dissent Ledger

## Slice 1
- Require top finding, strongest disagreement, confidence, and mind-change condition on each agent.
- Store the ledger in the normalized advanced-audit result.

## Slice 2
- Add a concise dissent section to the report and saved audit result.
- Make disagreement readable without forcing the reader into a long transcript.

## Slice 3
- Add pattern tracking for recurring disagreement shapes.
- Add host-AI guidance for when to highlight dissent versus compress it.

