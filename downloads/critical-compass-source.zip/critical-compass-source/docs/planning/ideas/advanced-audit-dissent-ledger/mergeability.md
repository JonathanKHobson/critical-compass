# Mergeability: Advanced Audit Dissent Ledger

## Local Mergeability Assessment
| Inspiration | Open / Proprietary | License Risk | Local / Self-Hostable | Maturity / Maintenance | Dependency Footprint | Security / Trust Risk | Recommendation |
|---|---|---|---|---|---|---|---|
| ThoughtProof-style consensus protocols | Mixed | Medium | Some patterns can be rebuilt locally | Emerging | Moderate | Medium - consensus can hide dissent if misused | Adapt locally |
| Sequential Thinking servers | Open-source | Low | Yes | Mature enough for reuse | Low | Low | Adapt locally |
| Kialo / Rationale argument maps | Proprietary / mixed | Medium | UI ideas are self-hostable in spirit, not directly | Mature products | Moderate | Low | Adapt patterns, not code |
| Debate / deliberation frameworks | Open concept | Low | Yes | Mature as methods | Low | Medium - easy to over-structure | Adopt as methodology |

## Build / Integrate / Reject
- Build the ledger locally.
- Integrate only the structural ideas, not a dependency on external systems.
- Reject any design that requires external consensus services to function.

