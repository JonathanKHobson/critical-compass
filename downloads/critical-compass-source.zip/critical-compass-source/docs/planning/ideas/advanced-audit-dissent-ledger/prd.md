# PRD: Advanced Audit Dissent Ledger

## Goal
Keep multi-agent audits auditable by preserving disagreement instead of erasing it during synthesis.

## User Segments
- Host AI orchestrating a multi-agent audit.
- Power user reviewing why the final verdict was chosen.
- Downstream stakeholder deciding whether to trust the output.

## Functional Requirements
- Each agent must provide:
  - top finding
  - strongest disagreement
  - confidence
  - what would change its mind
- Synthesis must retain per-agent provenance and note where agents converge or diverge.
- Report output must include a compact dissent ledger section when advanced audit is used.
- Saved audit results must persist the ledger for later comparison.

## Non-Goals
- No freeform transcript dump.
- No automatic consensus scoring that hides minority views.
- No separate debate UI in phase 1.

## Acceptance Criteria
- No advanced audit can synthesize without ledger fields present.
- Readers can identify disagreement at a glance.
- The final report states where the verdict accepted one interpretation over another.

## Success Metrics
- Dissent capture rate at 100 percent for advanced audits.
- Fewer “why did it decide that?” follow-ups from users.
- Higher trust in complex or contested outputs.

