# Evaluation: Advanced Audit Dissent Ledger

## What Success Looks Like
- Every advanced audit has a complete dissent ledger.
- Readers can explain the disagreement in one sentence.
- The final verdict still feels grounded, not arbitrary.

## Evaluation Methods
- Schema validation for required ledger fields.
- Red-team audits with obvious disagreement to ensure it is preserved.
- User review of whether the report made the decision path clearer.
- Regression checks that no agent’s strongest disagreement disappears in synthesis.

## Metrics
- Ledger completeness rate.
- Time to understand final verdict.
- Number of follow-up questions about “why not the other interpretation?”
- Reuse of dissent patterns in later audits.

