# Advanced Audit Dissent Ledger

## Problem / Opportunity
Advanced audits already synthesize multiple lenses, but synthesis can hide disagreement. A dissent ledger keeps the system honest by preserving what each agent found, where it disagreed, how confident it was, and what would change its mind.

## Why This Matters For Critical Compass
Critical Compass is strongest when it makes reasoning visible. This idea protects provenance and uncertainty, prevents false consensus, and gives readers a cleaner trust signal than a single blended verdict.

## Users And Jobs To Be Done
- Host AI: surface disagreement without collapsing it.
- Audit author or reviewer: understand what was contested, not just what won.
- Stakeholder reader: see why the final verdict is credible.

## Borrowed Ideas
- ThoughtProof-style consensus pipelines: adapt for multi-agent traceability.
- Sequential Thinking: adapt for explicit reasoning stages.
- Kialo and Rationale: adapt for visible disagreement structures.
- Generic debate frameworks: adopt as a pattern, not as a new product surface.

## Adopt / Adapt / Reject
- Adopt: preserve dissent as a first-class audit output.
- Adapt: agent summaries into a compact ledger rather than a full transcript.
- Reject: any workflow that forces consensus by flattening minority evidence.

## Belonging
- Primary form: tool + report artifact + server instruction.
- Secondary form: resource for saved patterns and future audits.

## Smallest Shippable Slice
Require every advanced-audit agent to emit top finding, strongest disagreement, confidence, and what would change its mind; then render that ledger in the synthesis payload and report.

## Dependencies
Advanced-audit agent scaffolds, synthesis output, save-audit-result payload, and report rendering templates.

