# Compass Observability, Routing, Temporal Provenance, And Context Maps

## Problem / Opportunity

Critical Compass and the broader Compass ecosystem are becoming powerful enough that reliability problems are no longer only output problems. They are route, retrieval, trace, memory, and explainability problems.

This backlog lane captures four research inspirations as local-first design patterns:

- Langfuse: observability discipline for traces, evals, prompt versions, and dashboards.
- Strata by Klavis AI: progressive tool routing to reduce tool overload.
- Graphiti: temporal provenance for changing knowledge and memory.
- Eureka: human-facing maps that explain why context was selected.

The point is not to add more apps. The point is to make future Compass work measurable: every run traceable, every retrieval explainable, every tool route bounded, every memory update provenance-backed, and every map human-readable.

## Recommended Form

This is a future P2/P3 planning lane. It should not enter the beta.10 delivery-layer hotfix or publish verification path.

The work belongs in Critical Compass only as planning and coordination unless a later implementation slice explicitly changes code. Knowledge Atlas and Kyle Second Brain concerns should be documented as integration boundaries, not absorbed into the Critical Compass repo.

## Design Pattern Mapping

| Inspiration | Pattern to steal | Local adaptation |
|---|---|---|
| Langfuse | Trace, prompt, eval, dashboard discipline | Local `RunTrace`, `RetrievalRunSummary`, eval summaries, and optional future export |
| Strata | Progressive tool discovery | Future thin `ToolRouterDecision` layer that narrows allowed next actions |
| Graphiti | Temporal context graph | Future `TemporalFact` coordination model with provenance and supersession |
| Eureka | Visual knowledge maps | Future `ContextSelectionMap` explaining selected and omitted context |

## What This Displaces

This lane displaces broad "make it smarter" work with measurable reliability surfaces. It should prevent three avoidable habits:

- adding more prompt text instead of tracing runs
- exposing too many tools instead of routing actions
- overwriting memory or graph claims instead of preserving provenance

## Guardrails

- No external SaaS is required.
- No new MCP tool in this planning lane.
- No beta.10 package, release, Pages, or report-renderer change.
- No silent memory mutation.
- No replacement of SQLite/FTS, optional Chroma, or Obsidian-facing surfaces.
- No Knowledge Atlas or Kyle Second Brain implementation inside Critical Compass without a separate approved slice.
