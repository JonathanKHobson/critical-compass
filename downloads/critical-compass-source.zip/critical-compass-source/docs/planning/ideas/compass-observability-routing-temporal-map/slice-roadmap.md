# Slice Roadmap: Observability, Routing, Temporal Provenance, And Context Maps

## P2 Smallest Shippable Slice

1. Document local `RunTrace`, `RetrievalRunSummary`, `ToolRouterDecision`, `TemporalFact`, and `ContextSelectionMap` contracts.
2. Add guardrails that external services are optional inspirations, not dependencies.
3. Add central backlog pointers so future agents do not confuse this with beta.10 work.
4. Document cross-system ownership: Critical Compass owns audit/report trace planning; Knowledge Atlas or Kyle Second Brain owns temporal memory implementation.

## P2 Follow-On Slices

1. Plan local JSONL/SQLite trace storage and retention policy.
2. Plan retrieval summary outputs for calibration and smoke runs.
3. Plan progressive router fixtures that test allowed/disallowed tools and widget-required paths.
4. Plan static context maps for selected and omitted lenses.

## P3 Future Slices

1. Build local health dashboard Markdown or HTML from traces and evals.
2. Add optional Langfuse export adapter only after local tracing works.
3. Add router experiments only after publish stability.
4. Add temporal provenance implementation in the owning Atlas/KSB system.
5. Add interactive context maps only if static maps prove useful.

## Release Boundary

None of these slices belong in beta.10 unless a release blocker specifically requires a documentation-only pointer. No package, release, Pages, public report, or MCP registration changes belong to this planning slice.
