# Phase Roadmap: Observability, Routing, Temporal Provenance, And Context Maps

## Phase Boundary

This is a future P2/P3 lane. It starts only after beta.10 delivery-layer hotfix and publish verification are stable. It does not add Langfuse, Strata, Graphiti, Eureka, a new MCP tool, or a hosted service.

## P2-A: Local Run Trace Contract

What it is: a local `RunTrace` planning contract for MCP calls and audit stages.

Why it exists: future debugging should show tool name, input hash, route decision, validators, repair loops, latency, token estimate, and artifact paths.

What changes: planning defines trace fields and local JSONL/SQLite-first storage expectations.

What does not change: no live trace logging in this planning slice and no external observability dependency.

Acceptance: a future implementation can add trace logging without deciding on Langfuse.

## P2-B: Retrieval Run Summary

What it is: a compact summary of retrieval choices and omissions.

Why it exists: retrieval quality needs precision, not just recall. Maintainers need to see selected lens IDs, omitted nearby lenses, candidate counts, ranking features, and precision flags.

What changes: planning defines `RetrievalRunSummary`.

What does not change: no retrieval reranking or scoring weight change in this planning slice.

Acceptance: future evals can explain why a lens was selected or omitted.

## P2-C: Progressive Tool Router Contract

What it is: a Strata-inspired router decision shape for narrowing host actions.

Why it exists: host AIs degrade when too many tools and interaction choices are visible at once.

What changes: planning defines `ToolRouterDecision` with intent, domain, stage, allowed/disallowed tools, widget requirement, and repair instruction.

What does not change: existing MCP tools remain available and unchanged.

Acceptance: a future router can expose 3-7 valid next actions without replacing the current public surface.

## P2-D: Context Selection Map Contract

What it is: a human-readable explanation of why context was selected.

Why it exists: users and maintainers need to see selected lenses, related edges, omitted nearby lenses, budget use, truncation, and downstream role.

What changes: planning defines `ContextSelectionMap`.

What does not change: no interactive map or hosted UI in this phase.

Acceptance: a future static map can explain selected and omitted context without raw private text.

## P2-E: Temporal Provenance Coordination Boundary

What it is: a Graphiti-inspired coordination plan for temporal facts, episodes, provenance, and supersession.

Why it exists: memory and graph systems need validity windows and provenance so stale facts do not silently pollute future outputs.

What changes: Critical Compass docs define the coordination contract and explicitly hand implementation to Knowledge Atlas or Kyle Second Brain.

What does not change: Critical Compass does not implement Atlas/KSB database migrations in this lane.

Acceptance: future memory or Atlas work can use `TemporalFact` without making Critical Compass the owner.

## P3-A: Local Health Dashboard

What it is: local Markdown or HTML generated from traces, evals, retrieval summaries, and route decisions.

Why it exists: reliability needs a readable pulse check: failures, latency, repair loops, lens precision, widget compliance, and report QA blockers.

What changes: future dashboard planning specifies inputs and output shape.

What does not change: no hosted dashboard.

Acceptance: a future dashboard can render from local artifacts only.

## P3-B: Optional Langfuse Export

What it is: an optional adapter to export local traces after local trace contracts stabilize.

Why it exists: self-hosted or external observability may be useful later, but it should not be required.

What changes: future export planning defines adapter boundaries.

What does not change: local JSONL/SQLite remains canonical.

Acceptance: export can be disabled without degrading local traces.

## P3-C: Router Experiments

What it is: experiments with progressive tool discovery and host action validation.

Why it exists: tool overload and plain-text question drift need runtime contracts that are easier for host AIs to follow.

What changes: future work can test route choices and repair metadata.

What does not change: no existing tool removal.

Acceptance: experiments reduce invalid tool choices without hiding needed tools.

## P3-D: Static Explainability Map

What it is: a local static map of input, selected lenses, omitted lenses, related edges, and final context pack.

Why it exists: retrieval explainability should be human-visible before building any interactive app.

What changes: future static artifacts can show the context map.

What does not change: no hosted Eureka-style service.

Acceptance: the map explains selection and omission reasons with no private-text leakage.
