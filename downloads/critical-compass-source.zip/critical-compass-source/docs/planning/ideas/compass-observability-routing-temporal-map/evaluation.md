# Evaluation: Observability, Routing, Temporal Provenance, And Context Maps

## Evaluation Goals

- Verify future traces explain what happened in a run without exposing private source text.
- Verify future retrieval summaries explain selected and omitted lenses.
- Verify future tool routing narrows the action space without hiding valid next actions.
- Verify temporal provenance preserves old facts through supersession rather than deletion.
- Verify context maps are useful as human-facing explainability artifacts.

## P2 Planning Checks

- All six planning docs exist: `overview.md`, `prd.md`, `phase-roadmap.md`, `slice-roadmap.md`, `tickets.md`, and `evaluation.md`.
- Every `CORTM-01` through `CORTM-12` ticket maps to P2 or P3.
- The docs say Langfuse, Strata, Graphiti, and Eureka are inspirations, not runtime dependencies.
- The docs state that Critical Compass does not implement Knowledge Atlas or Kyle Second Brain temporal memory changes in this lane.

## Future Implementation Test Scenarios

- `RunTrace`: a synthetic MCP run records route decision, validators, repair count, latency, and artifact paths with no raw private text.
- `RetrievalRunSummary`: a retrieval case records selected lens IDs, omitted nearby lens IDs, ranking features, and precision flags.
- `ToolRouterDecision`: a host request exposes allowed next tools, disallowed tools with reasons, widget-required status, and repair instruction.
- `TemporalFact`: a new fact supersedes an old fact without deleting its provenance.
- `ContextSelectionMap`: a local map shows selected lenses, omitted nearby lenses, budget use, and downstream role.

## Regression Checks

- Existing Critical Compass eval and report validators remain unchanged by planning docs.
- No public report includes trace, route, temporal fact, or context map internals by default.
- No external service is required for local tests.
- No package, release, Pages, or public MCP surface file is modified by this planning lane.
