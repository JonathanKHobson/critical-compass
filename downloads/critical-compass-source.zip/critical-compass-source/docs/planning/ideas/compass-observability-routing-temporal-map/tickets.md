# Tickets: Observability, Routing, Temporal Provenance, And Context Maps

## P2 Backlog

1. `CORTM-01` - Define the future `RunTrace` planning contract.
   - Inspiration: Langfuse.
   - Acceptance: fields include run/session/tool IDs, input hash, route decision, retrieval/budget modes, validators, repair count, latency, token estimate, and artifact paths.
2. `CORTM-02` - Define the future `RetrievalRunSummary` planning contract.
   - Inspiration: Langfuse plus retrieval eval needs.
   - Acceptance: fields include selected and omitted lens IDs, candidate count, ranking features, selection reasons, and precision flags.
3. `CORTM-03` - Define the future `ToolRouterDecision` planning contract.
   - Inspiration: Strata.
   - Acceptance: fields include intent, domain, stage, allowed next tools, disallowed tools with reasons, widget requirement, and repair instruction.
4. `CORTM-04` - Define the future `ContextSelectionMap` planning contract.
   - Inspiration: Eureka.
   - Acceptance: fields include input reference, selected lenses, related edges, omitted nearby lenses, budget use, truncation status, and downstream role.
5. `CORTM-05` - Document `TemporalFact` as a coordination contract, not a Critical Compass runtime schema.
   - Inspiration: Graphiti.
   - Acceptance: fields include episode, fact, validity window, supersession, provenance, confidence, and current status.
6. `CORTM-06` - Add local-first storage guidance for future traces and summaries.
   - Acceptance: JSONL/SQLite is canonical; external export is optional and disabled by default.
7. `CORTM-07` - Add cross-system ownership notes for Atlas and Kyle Second Brain.
   - Acceptance: Critical Compass does not own Atlas/KSB migrations or silent memory mutation.

## P3 Backlog

8. `CORTM-08` - Plan a local health dashboard from traces, evals, retrieval summaries, and route decisions.
   - Acceptance: dashboard can be Markdown or static HTML and has no hosted dependency.
9. `CORTM-09` - Plan optional Langfuse export after local traces stabilize.
   - Acceptance: local tracing remains useful when export is disabled.
10. `CORTM-10` - Plan Strata-inspired router experiments.
    - Acceptance: experiments preserve existing MCP tools and test allowed/disallowed next actions.
11. `CORTM-11` - Plan Graphiti-inspired temporal implementation in the owning memory/Atlas system.
    - Acceptance: Critical Compass only documents coordination boundaries.
12. `CORTM-12` - Plan Eureka-inspired static explainability maps.
    - Acceptance: static maps show selected and omitted context before any interactive UI.

## Explicitly Not Addressed

- No Langfuse, Strata, Graphiti, or Eureka integration.
- No hosted dashboard or map.
- No new MCP tool.
- No beta.10 package, Pages, release, manifest, or report-renderer change.
- No Chroma replacement.
- No Obsidian replacement.
- No silent memory mutation.
