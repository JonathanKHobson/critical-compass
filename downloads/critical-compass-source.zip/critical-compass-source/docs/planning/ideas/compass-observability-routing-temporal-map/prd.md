# PRD: Observability, Routing, Temporal Provenance, And Context Maps

## Goal

Capture a future local-first reliability architecture inspired by Langfuse, Strata, Graphiti, and Eureka without making those services runtime dependencies.

The result should help future maintainers answer:

- What happened during this run?
- Why did the system retrieve these lenses?
- Which tool should the host call next?
- What memory or graph fact is current, superseded, or disputed?
- Why was this context selected or omitted?

## Primary Users

- Maintainer diagnosing run failures, retrieval drift, score drift, and report QA blockers.
- Host AI/operator choosing valid next actions without tool overload.
- Knowledge maintainer reviewing provenance and supersession boundaries.
- Human reviewer checking why selected context made it into an audit.

## P2 Requirements

1. Define future local `RunTrace` and `RetrievalRunSummary` planning contracts.
2. Define future progressive `ToolRouterDecision` contract for allowed and disallowed next tools.
3. Define future `ContextSelectionMap` contract for human-visible retrieval explanation.
4. Document the `TemporalFact` model as a coordination boundary with Knowledge Atlas and Kyle Second Brain, not as a Critical Compass implementation.
5. Keep storage local-first: JSONL or SQLite first, optional export later.

## P3 Requirements

1. Plan local dashboard Markdown or HTML generated from traces, evals, and retrieval summaries.
2. Plan optional Langfuse export only after local trace shapes stabilize.
3. Plan Strata-inspired routing experiments only after beta.10/publish stability.
4. Plan Graphiti-inspired temporal provenance only in the owning knowledge/memory system.
5. Plan Eureka-inspired context maps as static explainability artifacts before interactive UI.

## Planning Contracts

These contracts are future planning shapes, not live schemas.

### `RunTrace`

- `run_id`
- `session_id`
- `mcp_tool`
- `input_hash`
- `route_decision`
- `retrieval_mode`
- `budget_mode`
- `validators_run`
- `validator_failures`
- `repair_loop_count`
- `latency_ms`
- `estimated_tokens`
- `output_artifact_paths`

### `RetrievalRunSummary`

- `query_hash`
- `selected_lens_ids`
- `omitted_lens_ids`
- `candidate_count`
- `ranking_features`
- `selection_reasons`
- `precision_flags`

### `ToolRouterDecision`

- `intent`
- `domain`
- `stage`
- `allowed_next_tools`
- `disallowed_tools_with_reason`
- `widget_required`
- `repair_instruction`

### `TemporalFact`

- `episode_id`
- `fact_id`
- `validity_start`
- `validity_end`
- `supersedes_fact_id`
- `provenance_source_id`
- `confidence`
- `current_status`

### `ContextSelectionMap`

- `input_ref`
- `selected_lenses`
- `related_edges`
- `omitted_nearby_lenses`
- `budget_used`
- `truncation_status`
- `downstream_role`

## Non-Goals

- No hosted Langfuse dependency.
- No Strata adoption or wholesale gateway replacement.
- No Graphiti replacement for Knowledge Atlas or Kyle Second Brain.
- No hosted Eureka-style UI.
- No new public MCP tool during planning.
- No automatic memory mutation.
- No beta.10 release-surface change.

## Acceptance Criteria

- Future work can implement local tracing without deciding on a SaaS provider.
- Future tool routing can narrow host choices without removing existing tools.
- Future temporal provenance work is clearly assigned to the owning knowledge or memory system.
- Future context maps can explain selected and omitted lenses without exposing private text.
