# Beta.8 Teaching Alignment Readiness PRD

## Executive Summary

Beta.8 should make Critical Compass more reliably educational without broadening the product into a learning platform. The release should reinforce the audit's reader-facing contract and add a bounded follow-up activity layer from a curated File of Fun / Knowledge Atlas activity snapshot.

The gap-fill source is available in the active Atlas index: 471 File-O-Fun records, including 244 gap-fill records from `file-o-fun-gap-fill-2026-04-27` and 227 Harris/OCR records. Implementation may proceed after a small local activity family pack is curated from that source.

## Target Users

- Public user deciding whether to share, cite, or act on an article or post.
- Nonprofit communicator revising advocacy copy before publication.
- Grant writer or reviewer pressure-testing an impact claim.
- Public statement drafter checking accountability, audience fit, and missing voices.
- AI-generated summary reviewer checking source coverage and polished overconfidence.
- Host AI or maintainer keeping audit outputs consistent across chat, PDF, HTML, and skill surfaces.

## Goals

- Make `Plain-Language Read` reliable in every audit-facing output.
- Make `Before Using This Text` reliable in every audit-facing output, with the exact opener `Before using this text,`.
- Add follow-up activities that help the user improve, test, or further analyze the supplied text.
- Use File of Fun / Knowledge Atlas activities as curated build-time source material.
- Keep beta.8 within existing Critical Compass surfaces.

## Non-Goals

- Do not create a standalone Practice Activity Tool.
- Do not add a new public MCP tool.
- Do not add runtime dependency on File of Fun, Knowledge Atlas, or external retrieval.
- Do not make activities the main product story; audits remain the primary product.
- Do not recommend therapy-adjacent, sacred/culturally grounded, identity-impersonation, or high-risk facilitation practices by default.

## Functional Requirements

| ID | Requirement | Acceptance Criteria |
|---|---|---|
| FR-001 | Require `Plain-Language Read` in every audit-facing output. | Quick scan, standard audit, claim stress-test, coaching, advanced audit synthesis, Markdown, HTML, PDF, and standalone skill outputs include the section or compact equivalent. |
| FR-002 | Define `Plain-Language Read` style. | The read is 1-2 nontechnical sentences that explain what the text is doing and the biggest trust/use issue. |
| FR-003 | Require `Before Using This Text` in every audit-facing output. | The sentence starts exactly with `Before using this text,` and gives one high-priority caution or check. |
| FR-004 | Distinguish caution from activity. | `Before Using This Text` remains a concise pre-use caution; `Follow-Up Activity` is a doing/learning exercise after the audit. |
| FR-005 | Add full-report follow-up activities. | Full/advanced reports recommend one solo activity and one group activity adapted to the text, audience, claim type, and audit concerns. |
| FR-006 | Add quick-output activity hint. | Quick scan and lightweight chat outputs include at most one small follow-up idea when useful. |
| FR-007 | Curate activity family pack from verified gap-fill. | The activity pack includes critical, creative, and compassionate thinking activities with source notes and no live Atlas dependency. |
| FR-008 | Use human-loop answers when available. | Follow-up activity recommendations can adapt to user intent, learning mode, missing context, and reflection choices already collected by the human loop. |
| FR-009 | Preserve deferral gate for standalone tool. | The Practice Activity Tool stays deferred unless future evidence shows existing outputs are too crowded or users repeatedly ask for standalone practice recommendations. |
| FR-010 | Exclude high-risk defaults. | Therapy-adjacent, sacred/culturally grounded, identity-impersonation, or high-facilitation-risk activities are deferred unless explicitly reviewed and safely framed. |

## Activity Family Direction

Candidate families selected for beta.8 curation:

| Role | Examples |
|---|---|
| Internal AI reasoning scaffold | Claim-Support-Question, What Makes You Say That?, Tug for Truth Evidence Board, 3-2-1 Bridge, argument mapping. |
| Solo user follow-up | Reverse Outline Repair, Word-Phrase-Sentence, Tiny Teaching Challenge, I Like / I Wish Self-Critique, Question-to-Action Research Sprint, Connect-Extend-Challenge. |
| Group user follow-up | 1-2-4-All Idea Burst, Micro Lab Protocol, Troika Consulting, What / So What / Now What Debrief, Think-Pair-Share Reflection, Chalk Talk Silent Board. |
| Compassionate/missing-voice follow-up | Empathy Map, Parts-Perspectives-Me Map, Needs Behind Positions Map, Quiet Line of Agreement, with explicit caution not to invent lived experience. |

Selection rules:

- Evidence or source gap -> Claim-Support-Question, Tug for Truth Evidence Board, Question-to-Action Research Sprint.
- Draft structure or revision problem -> Reverse Outline Repair, I Like / I Wish Self-Critique, Word-Phrase-Sentence.
- Audience, stakeholder, or missing-voice concern -> Empathy Map, Micro Lab Protocol, Parts-Perspectives-Me Map.
- Group alignment or review need -> 1-2-4-All Idea Burst, What / So What / Now What Debrief, Troika Consulting.
- Remote or distance collaboration -> Impromptu Networking, 1-2-4-All Idea Burst, Micro Lab Protocol, Chalk Talk Silent Board.

## Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-001 | Keep beta.8 local-first and resource driven. |
| NFR-002 | Keep activities short, practical, and tied to the supplied text. |
| NFR-003 | Preserve Critical Compass category discipline, uncertainty, dissent, provenance, and cultural humility. |
| NFR-004 | Avoid therapeutic, sacred, or identity-impersonation framing unless explicitly appropriate and carefully attributed. |
| NFR-005 | Do not let activity suggestions hide or replace audit findings. |

## Success Metrics

- Every audited output visibly includes the two reader-facing sections.
- Before-use text starts with the exact required opener.
- Full reports provide one solo and one group activity without feeling like a separate course.
- Quick outputs remain compact.
- Activity recommendations are specific to the text and audit concerns, not generic canned advice.
- Implementation does not add new tools or runtime dependencies.

## Risks

| Risk | Mitigation |
|---|---|
| Activities crowd the audit | Put detailed activities only in full/advanced reports; quick outputs get one tiny idea. |
| Generic activity suggestions feel useless | Require content focus, why-this-fits, and text-specific adaptation. |
| File of Fun import creates noise | Review and curate a small activity pack instead of importing wholesale. |
| Product scope expands into a learning platform | Keep the standalone Practice Activity Tool deferred and preserve audits as primary. |
| Culturally grounded activities are flattened | Include attribution and use cautions, or exclude them from beta.8's first activity pack. |
