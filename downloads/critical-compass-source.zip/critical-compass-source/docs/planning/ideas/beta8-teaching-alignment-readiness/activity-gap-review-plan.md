# Activity Gap Review Plan

## Purpose

Review File of Fun / Knowledge Atlas activity records now that the gap-fill exists, then decide which activities should inform Critical Compass beta.8. This review happens before runtime output implementation.

## Verified Corpus Baseline

The active Atlas index currently exposes:

- 471 File-O-Fun records.
- 244 gap-fill records from `file-o-fun-gap-fill-2026-04-27`.
- 227 Harris/OCR records.

These counts are planning evidence for curation only. Beta.8 should distill a small local activity pack from this corpus and must not depend on live Atlas lookup at runtime.

## Review Inputs

- Existing File of Fun / Knowledge Atlas activity records available locally.
- Newly added gap-fill records for workshops, team retrospectives, brainstorming activities, icebreakers, warmups, virtual/distance collaboration, research feedback/testing, solo activities, and group activities.
- Critical Compass beta.7 outputs and planning docs.
- Current beta.8 teaching alignment requirements.

## Review Questions

1. Which activities help a user understand or improve a specific piece of text?
2. Which activities can the AI use internally as reasoning scaffolds during an audit?
3. Which activities should be user-facing follow-up suggestions?
4. Which activities support critical, creative, or compassionate thinking?
5. Which activities require group facilitation, consent, safety setup, cultural attribution, or special caution?
6. Which activities are too broad, too therapeutic, too sacred/culturally grounded, too playful for serious text review, or too unrelated to Critical Compass?

## Classification Buckets

| Bucket | Definition | Example fit |
|---|---|---|
| Internal scaffold | The AI can use the method to reason better during an audit. | Socratic questioning, argument map, premortem, claim-support-question. |
| Solo follow-up | One user can perform it on the text after the audit. | Plain-language rewrite, evidence gap inventory, Feynman explanation, See-Think-Wonder. |
| Group follow-up | A team or audience group can perform it on the text. | 1-2-4-All, Conversation Cafe, retrospective, stakeholder review, focus-group style exercise. |
| Defer | Useful somewhere, but not beta.8. | Deep facilitation, therapeutic exercises, large workshops, culturally grounded practices needing more attribution. |
| Exclude | Not appropriate for Critical Compass. | Activities that require identity impersonation, unsafe disclosure, or unrelated entertainment. |

## Beta.8 Candidate Activity Pack

Initial curated candidates for the local beta.8 pack:

| ID | Activity | Role |
|---|---|---|
| `claim-support-question` | Claim-Support-Question | internal scaffold, solo, group |
| `what-makes-you-say-that` | What Makes You Say That? | internal scaffold, solo, group |
| `tug-for-truth-evidence-board` | Tug for Truth Evidence Board | internal scaffold, solo, group |
| `three-two-one-bridge` | 3-2-1 Bridge | internal scaffold, solo |
| `reverse-outline-repair` | Reverse Outline Repair | solo |
| `word-phrase-sentence` | Word-Phrase-Sentence | solo, group |
| `tiny-teaching-challenge` | Tiny Teaching Challenge | solo, group |
| `i-like-i-wish-self-critique` | I Like / I Wish Self-Critique | solo, group |
| `question-to-action-research-sprint` | Question-to-Action Research Sprint | solo, group |
| `connect-extend-challenge` | Connect-Extend-Challenge | solo, group |
| `one-two-four-all-idea-burst` | 1-2-4-All Idea Burst | group |
| `micro-lab-protocol` | Micro Lab Protocol | group |
| `troika-consulting` | Troika Consulting | group |
| `what-so-what-now-what-debrief` | What / So What / Now What Debrief | group |
| `think-pair-share-reflection` | Think-Pair-Share Reflection | group |
| `chalk-talk-silent-board` | Chalk Talk Silent Board | group or remote |
| `empathy-map` | Empathy Map | internal scaffold, solo, group |
| `parts-perspectives-me-map` | Parts-Perspectives-Me Map | internal scaffold, solo, group |
| `needs-behind-positions-map` | Needs Behind Positions Map | internal scaffold, solo, group |
| `quiet-line-of-agreement` | Quiet Line of Agreement | group |

## Candidate Evaluation Criteria

Score each candidate qualitatively as high, medium, or low:

- Text specificity: can it be conducted on the supplied text?
- Audit usefulness: does it improve evidence, framing, assumptions, missing voices, or revision quality?
- Teaching value: does it build critical, creative, or compassionate thinking?
- Output fit: can it be summarized in a concise report section?
- Safety and humility: does it avoid identity impersonation, therapy claims, or cultural flattening?
- Implementation fit: can it work without a runtime dependency or new tool?

## Expected Curation Output

The review should produce a small activity family pack proposal with:

- Activity title.
- Source or source family.
- Role: internal scaffold, solo follow-up, group follow-up, or both.
- Best-fit claim/text types.
- Critical, creative, or compassionate thinking focus.
- Text-specific adaptation rule.
- Safety/culture note if relevant.
- Reason for inclusion or deferral.

## Gap Areas To Confirm

- Workshops.
- Team retrospectives.
- Brainstorming activities.
- Icebreakers and warmups.
- Virtual and distance collaboration activities.
- Research feedback and testing activities.
- Solo reflection and analysis practices.
- Group review and focus-group style practices.
- Stakeholder and missing-voice activities.
- Evidence and source-checking activities.
- Plain-language rewriting activities.
- Creative reframing activities.

## Beta.8 Decision Gate

Implementation can start only after:

- The gap-fill source exists in the active Atlas index.
- The review identifies a small activity pack.
- The pack has both solo and group candidates.
- The pack keeps File of Fun / Knowledge Atlas as build-time source material only.
- The standalone Practice Activity Tool remains deferred.
