# Beta.8 Teaching Alignment Readiness Slice Roadmap

## Slice 1: Planning Docs And Archive Cleanup Only

Deliverable:

- Archive beta.7 planning docs and create beta.8 planning pack.

Affected surfaces:

- `docs/planning/README.md`
- `docs/planning/master-roadmap.md`
- `docs/planning/ideas/beta8-teaching-alignment-readiness/`
- `docs/planning/archive/2026-04-27-beta7-planning-snapshot/`

Acceptance checks:

- New pack has overview, PRD, phase roadmap, slice roadmap, and activity gap review plan.
- Beta.7 Atlas planning docs are archived and remain available.
- Active docs say beta.8 is no longer blocked on entry creation and is gated on activity review/curation.

Do not expand into:

- Runtime code changes.
- Skill/package rebuilds.
- Release or GitHub publishing.
- New MCP tools.

## Slice 2: File Of Fun Gap Review

Status: complete for beta.8.

Deliverable:

- Review the available File of Fun / Knowledge Atlas activity records for Critical Compass fit, using the verified baseline of 471 File-O-Fun records, 244 gap-fill records, and 227 Harris/OCR records.

Affected surfaces:

- Planning notes and candidate activity inventory only.

Acceptance checks:

- The verified activity corpus baseline is recorded.
- New or changed activity records are identified.
- Candidates are grouped into internal AI scaffolds, solo follow-up activities, and group follow-up activities.
- Workshop, retrospective, brainstorming, icebreaker, warm-up, solo, and group gaps are explicitly checked.

Do not expand into:

- Importing all activities.
- Runtime File of Fun dependency.
- Activity rendering.

## Slice 3: Activity Family Curation

Status: complete in the local working tree.

Deliverable:

- Small local activity family pack for critical, creative, and compassionate thinking.

Affected surfaces:

- Planning docs.
- `support/library/file-o-fun-teaching-activity-pack.json`.

Acceptance checks:

- Each selected family has when-to-use guidance, text-specific adaptation guidance, and source notes.
- Culturally grounded or embodied practices include caution or are deferred.
- The pack supports both content improvement and critical-thinking learning.

Do not expand into:

- Full learning curriculum.
- Standalone Practice Activity Tool.
- Identity impersonation or therapy framing.

## Slice 4: Output Contract Enforcement

Status: complete in the local working tree.

Deliverable:

- Reliable `Plain-Language Read` and `Before Using This Text` across all audit-facing outputs.

Affected surfaces:

- MCP host prompts and scaffolds.
- Report readiness and normalization.
- Markdown, HTML, PDF rendering.
- Standalone skill templates.

Acceptance checks:

- Every mode includes both sections.
- Before-use text starts exactly with `Before using this text,`.
- Missing or placeholder text blocks final full reports unless placeholders are explicitly requested.

Do not expand into:

- Activity rendering before the curated pack is ready.

## Slice 5: Follow-Up Activity Payload And Report Rendering

Status: complete in the local working tree.

Deliverable:

- Full/advanced reports include one solo and one group activity adapted to the audited text.

Affected surfaces:

- Normalized report payload.
- Markdown/HTML/PDF templates.
- Host prompt/report-ready contracts.

Acceptance checks:

- Activities include title, why this fits, steps, and content focus.
- Human-loop answers refine the activity when available.
- Quick outputs use at most one tiny follow-up idea.

Do not expand into:

- Separate activity renderer.
- New activity MCP tool.
- Automatic retrieval.

## Slice 6: Standalone Skill Reference Refresh

Status: complete in the local working tree.

Deliverable:

- Standalone Critical Compass skill receives the same plain-read, before-use, and bounded activity guidance.

Affected surfaces:

- `critical-compass/SKILL.md`
- relevant `critical-compass/references/` files
- offline export script if needed after resource changes

Acceptance checks:

- Skill remains standalone and markdown-only.
- No MCP, DB, browser, network, or script dependency is required at runtime.
- Activity guidance is compact and does not crowd the audit.

Do not expand into:

- MCP-only activity features.
- Large bundled activity library.

## Slice 7: Beta.8 Validation, Package, And Publish

Status: validation complete locally; package and publish are pending future release approval.

Deliverable:

- Validated beta.8 artifacts and public release only after implementation and live smoke tests.

Affected surfaces:

- Local artifacts.
- Source zip.
- MCPB.
- Plugin zip.
- Standalone skill.
- Public Pages/release surfaces.

Acceptance checks:

- Full pytest suite and release validators pass.
- Live smoke testing confirms the two required sections and activity section appear in relevant outputs.
- Archive hygiene and checksums pass before publishing.

Do not expand into:

- Stable release.
- Untested File of Fun dependency.
- New public tools.
