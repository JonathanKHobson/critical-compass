# Beta.8 Teaching Alignment Readiness Phase Roadmap

## Implementation Status - 2026-04-27

Planning is active and the File of Fun gap-fill is available in the active Atlas index.

This roadmap now gates beta.8 implementation on curation of a small local activity family pack, not on new activity creation.

## Phase 0: Planning Cleanup And Archive Snapshot

Status: complete.

Work:

- Archive beta.7 planning state before rewriting active planning docs.
- Create the beta.8 teaching alignment planning pack.
- Update active planning index and master roadmap.

Exit criteria:

- Archive snapshot exists under `docs/planning/archive/2026-04-27-beta7-planning-snapshot/`.
- New planning pack exists under `docs/planning/ideas/beta8-teaching-alignment-readiness/`.
- Active README and master roadmap point to beta.8 as the current planning track.

## Phase 1: File Of Fun Gap-Fill Available

Status: complete for the active Atlas index.

Work:

- Record the verified activity corpus baseline: 471 File-O-Fun records, 244 gap-fill records, and 227 Harris/OCR records.
- Preserve File of Fun and Knowledge Atlas as build-time source material only.
- Confirm the intended gap areas are represented: workshops, team retrospectives, brainstorming activities, icebreakers, warmups, solo practices, group practices, distance activities, and research feedback/testing practices.

Exit criteria:

- The gap-fill source is available for curation.
- The roadmap no longer says beta.8 is blocked on entry creation.

Phase gate:

- Do not implement runtime output changes until the curated local activity family pack exists.

## Phase 2: Review File Of Fun / Knowledge Atlas Activity Records

Status: complete for the beta.8 implementation pass.

Work:

- Review current and newly filled activity records against Critical Compass needs.
- Separate activity candidates into internal AI reasoning scaffolds and user-facing follow-up activities.
- Identify activities that support critical, creative, and compassionate thinking.
- Exclude or defer activities that are too broad, therapeutic, sacred/culturally grounded without adequate attribution, unsafe, or not tied to text review.

Exit criteria:

- Candidate activity list is grouped by role, audience, setting, and risk.
- Each selected family has a source note and a reason it fits Critical Compass.
- Deferred activities have a clear reason.

Phase gate:

- Do not implement activity selection until a small curated family pack is chosen.

## Phase 3: Curate Local Activity Family Pack

Status: complete in the local working tree.

Work:

- Create a small local beta.8 activity family pack from reviewed File of Fun / Knowledge Atlas material.
- Include solo and group candidates.
- Include internal reasoning scaffold candidates.
- Define matching cues such as domain, claim type, missing voice, evidence gap, reasoning trap, audience, and human-loop response.
- Include source notes without raw Atlas JSON, DB paths, or live retrieval claims.

Exit criteria:

- Activity pack is small enough for reliable retrieval and prompt use.
- Each activity includes title, role, when to use, text-specific adaptation guidance, safety/culture notes if needed, and source note.
- No runtime dependency on File of Fun or Knowledge Atlas is introduced.

## Phase 4: Implement Beta.8 Output Contract And Follow-Up Activity Rendering

Status: complete in the local working tree; release packaging/publishing is still pending.

Work:

- Enforce `Plain-Language Read` across all audit-facing outputs.
- Enforce exact `Before using this text,` opener across all audit-facing outputs.
- Add follow-up activity payload and report rendering.
- Update standalone skill references and examples.

Exit criteria:

- Contract tests pass for quick scan, standard audit, claim stress-test, coaching, advanced audit, Markdown, HTML, PDF, and skill outputs.
- Full/advanced reports render one solo and one group activity.
- Quick outputs remain compact.

## Phase 5: Validate, Package, And Publish Beta.8

Status: not started. Future release work only.

Work:

- Run live smoke tests after implementation.
- Rebuild local artifacts only after smoke tests pass.
- Publish only after package, archive, skill, MCPB, and live download checks pass.

Exit criteria:

- Full test suite and release validators pass.
- Manual/live smoke testing is complete enough to support a beta.8 release.
- Release notes clearly describe the teaching alignment scope and the File of Fun build-time source boundary.
