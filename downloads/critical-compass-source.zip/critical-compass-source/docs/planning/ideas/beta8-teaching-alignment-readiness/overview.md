# Beta.8 Teaching Alignment Readiness

## Problem / Opportunity

Critical Compass v0.1.0-beta.7 shipped the Atlas-informed pressure-test readiness track. The next product concern is not another tool. It is making the audit consistently teach while it evaluates.

Two reader-facing sections need to become non-negotiable across chat, skill, Markdown, HTML, and PDF outputs:

- `Plain-Language Read`
- `Before Using This Text`

The next opportunity is a follow-up activity layer that helps the user do something useful with the text after the audit. This should draw from File of Fun / Knowledge Atlas activity records as build-time source material. The active Atlas index now has 471 File-O-Fun records: 244 gap-fill records from `file-o-fun-gap-fill-2026-04-27` plus 227 Harris/OCR records.

## Current Status

Beta.8 is no longer blocked on activity entry creation. The active gate is curation: choose a small local activity family pack before changing runtime outputs.

The beta.7 Atlas pressure-test work is shipped and historical. It remains useful as source context for decision readiness, mitigation next steps, AI/data audit language, KB no-result recovery, and optional practice suggestions, but it is no longer the active next implementation track.

## Product Lens

Use this filter for every beta.8 idea:

- Does it make the audit easier to understand in plain language?
- Does it give the user one useful caution before acting on the text?
- Does it teach critical, creative, or compassionate thinking without turning the audit into a course?
- Does it help improve or further analyze the supplied text?
- Can it ship through existing outputs before adding any new tool?

## Pillars

| Pillar | Product promise |
|---|---|
| Plain-Language Read | The user gets a short, nontechnical read of what the text is doing and the biggest trust/use issue. |
| Before Using This Text | The user gets one concise caution before they act on, share, cite, publish, or rely on the text. |
| Follow-Up Activity | The user gets a solo and group way to keep thinking with the text, adapted to the audit context. |

## Activity Strategy

Use File of Fun / Knowledge Atlas as build-time source material, not as a runtime dependency.

Separate two roles:

- **Internal reasoning scaffolds**: activities or methods the AI may use while auditing, such as Claim-Support-Question, What Makes You Say That?, Tug for Truth Evidence Board, 3-2-1 Bridge, and argument mapping.
- **User-facing follow-up activities**: activities the user can perform after the audit, such as solo reflection, group workshop, retrospective, brainstorming, focus-group style review, warm-up, or stakeholder exercise.

Curated beta.8 candidate families:

- **Internal scaffolds**: Claim-Support-Question, What Makes You Say That?, Tug for Truth Evidence Board, 3-2-1 Bridge, and argument mapping.
- **Solo follow-ups**: Reverse Outline Repair, Word-Phrase-Sentence, Tiny Teaching Challenge, I Like / I Wish Self-Critique, Question-to-Action Research Sprint, and Connect-Extend-Challenge.
- **Group follow-ups**: 1-2-4-All Idea Burst, Micro Lab Protocol, Troika Consulting, What / So What / Now What Debrief, Think-Pair-Share Reflection, and Chalk Talk Silent Board.
- **Compassionate/missing-voice follow-ups**: Empathy Map, Parts-Perspectives-Me Map, Needs Behind Positions Map, and Quiet Line of Agreement, with explicit caution not to invent lived experience or speak for affected groups.

The near-term activity layer should remain inside existing outputs. It should not become a standalone Practice Activity Tool in beta.8.

## Non-Goals

- Do not add a new MCP tool for activities.
- Do not add automatic web search or live retrieval.
- Do not make File of Fun or Knowledge Atlas a runtime dependency.
- Do not import all File of Fun / Knowledge Atlas activities wholesale.
- Do not recommend therapy-adjacent, sacred/culturally grounded, identity-impersonation, or high-risk facilitation practices by default.

## Smallest Useful Outcome

The beta.8 planning refresh is complete when the docs record the verified File of Fun corpus baseline, identify candidate activity families, and define the curation gate for a small local activity pack.
