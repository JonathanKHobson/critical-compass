# Scaffold Registry And Canonical Examples UX Notes

## UX Goal
Make the right output shape easy to copy before the host AI starts inventing its own.

## Good UX
- Concrete examples.
- Short workflow contracts.
- Standardized reader lines that are immediately recognizable.

## Failure Modes
- The registry becomes a dump of prompts with no canonical example.
- Host AIs read it as optional inspiration instead of a contract.
- The standardized reader lines become verbose or formulaic.

## Content Rules
- Keep the examples short and high-signal.
- Prefer "this is the shape" over "here are some ideas."
- Make the required fields obvious at the top.
