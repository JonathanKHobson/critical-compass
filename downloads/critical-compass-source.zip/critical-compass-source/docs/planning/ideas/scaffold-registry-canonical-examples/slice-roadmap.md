# Scaffold Registry And Canonical Examples Slice Roadmap

## Smallest Shippable Slice
Create canonical examples for the audit payload, the report-ready payload, `plain_language_read`, and `before_using_this_text`.

## Follow-On Slices
1. Add workflow contracts for report readiness.
2. Add human-loop prompt examples.
3. Add host-AI guardrails for when to call report generation.

## Dependencies
- Stable core audit fields
- Report readiness contract
- Current human-loop prompt structure
