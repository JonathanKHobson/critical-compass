# Scaffold Registry And Canonical Examples PRD

## Problem Statement
The product needs a stable place to publish the exact shapes of good outputs so host AIs can assemble complete audit payloads before calling report generation.

## Required Content
- Canonical audit payload examples
- Canonical report-ready payload examples
- Canonical `plain_language_read` examples
- Canonical `before_using_this_text` examples
- Host-AI workflow contracts
- Human-loop prompt examples

## Behavioral Goal
Standardize the two strongest reader-facing lines in the system:
- `plain_language_read`
- `before_using_this_text`

These should be concise, powerful, and always present in MCP outputs that are report-ready or audit-ready.

## Product Behavior
- Store one canonical example per workflow.
- Show the minimum required fields before report generation.
- Provide short "good / better / best" examples for tricky outputs.
- Keep the registry local and versioned.

## Acceptance Criteria
- Host AIs can see the needed fields before they call `generate_audit_report`.
- The system provides a concrete example for the output shape, not just prose guidance.
- The canonical reader lines are standardized enough to be reused across workflows.

## Success Metrics
- Fewer blank or fallback-heavy report sections.
- Fewer host-AI regeneration loops.
- More consistent plain-language reads across audits.
