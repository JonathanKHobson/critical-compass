# Scaffold Registry And Canonical Examples Risks And Trust

## Risks
- Examples drift away from the actual tool contract.
- Host AIs treat examples as decorative instead of required.
- Reader-line standardization becomes too rigid or too verbose.

## Trust Controls
- Version the registry.
- Tie examples to the live contract fields.
- Flag canonical examples as authoritative, not illustrative.

## Mitigations
- Review examples when tool contracts change.
- Keep the examples short.
- Prefer one best example over many competing patterns.
