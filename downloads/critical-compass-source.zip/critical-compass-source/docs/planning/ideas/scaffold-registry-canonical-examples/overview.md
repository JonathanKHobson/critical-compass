# Scaffold Registry And Canonical Examples

## Problem / Opportunity
The current failure mode is not just missing data. It is that host AIs often do not know the exact shape of a good Critical Compass output early enough, so they improvise labels, leave sections empty, or regenerate too late.

## Why This Matters
Critical Compass already has strong outputs like `plain_language_read` and `before_using_this_text`. A scaffold registry makes those outputs more standardized, more repeatable, and more likely to appear in every MCP response.

## User Segments / Jobs
- Host AIs that need an execution contract before calling report tools.
- Users who need predictable, concise audit language.
- Maintainers who need canonical examples and templates for new workflows.

## Adjacent Inspirations
- Prompt workflow servers
- Claude prompt libraries
- Example-driven docs systems

## Adopt / Adapt / Reject
- Adopt directly: canonical examples and reusable scaffold templates.
- Adapt locally: workflow contracts for audit, report, and human-loop flows.
- Reject: vague prompt advice that does not define required outputs.

## Belongs As
Resource, server instruction, elicitation layer, and report artifact support.
