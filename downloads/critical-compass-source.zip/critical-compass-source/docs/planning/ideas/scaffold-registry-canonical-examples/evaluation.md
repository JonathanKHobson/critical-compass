# Scaffold Registry And Canonical Examples Evaluation

## What To Test
- Does the host AI assemble better report payloads after reading the registry?
- Do `plain_language_read` and `before_using_this_text` appear consistently?
- Do users find the examples clear enough to reuse?

## Metrics
- Fewer missing required fields.
- Fewer fallback strings in final outputs.
- Better consistency in reader-facing language.

## Acceptance Cases
- A host AI can build a report-ready payload from the registry without guessing.
- The two standardized reader lines appear in every report-ready example.
- The examples are concise enough to be useful at prompt time.
