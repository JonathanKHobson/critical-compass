# Scaffold Registry And Canonical Examples Tickets

- SRC-01: Define registry structure and versioning.
- SRC-02: Draft canonical audit payload examples.
- SRC-03: Draft canonical report-ready examples.
- SRC-04: Standardize `plain_language_read` and `before_using_this_text`.
- SRC-05: Draft host-AI workflow contracts.
- SRC-06: Add sample prompts for report-readiness checks.

## Status Snapshot - 2026-04-15

- SRC-01 through SRC-07: Done. Versioned scaffold resources now live under `support/resources/scaffolds/v1/` and are surfaced through overview resources. Regression tests assert the manifest exposes report-ready JSON, Markdown checkpoint, argument map, check-worthy claim examples, server instructions, structured elicitation examples, blind-spot consent examples, and dissent guidance.
