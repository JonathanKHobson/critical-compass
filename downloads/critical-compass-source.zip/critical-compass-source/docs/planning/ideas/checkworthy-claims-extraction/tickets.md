# Check-Worthy Claims Extraction Tickets

- CCE-01: Define the claim taxonomy and the "worth checking" rule.
- CCE-02: Implement factual claim prioritization.
- CCE-03: Separate factual claims from interpretive, causal, normative, and policy claims.
- CCE-04: Draft user-facing explanation copy.
- CCE-05: Add evaluation cases that prove check-worthy does not equal false.

## Status Snapshot - 2026-04-15

- CCE-01 through CCE-05: Done in the MCP output/report path.
- CCE-06: Done - evidence-plan fields now include `suggested_queries`, `likely_source_types`, `support_contrast_status`, and `uncertainty_note`.
- CCE-07: Done - no-network regressions prove evidence-plan fields remain local plans and do not trigger automatic web retrieval.
- CCE-08: Done - report rendering tests and golden artifact validation cover Evidence Needed Next with suggested queries, likely source types, support/contrast status, and uncertainty notes.
