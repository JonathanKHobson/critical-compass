# Check-Worthy Claims Extraction Risks And Trust

## Risks
- Mislabeling interpretive or policy statements as factual targets.
- Users reading check-worthiness as a truth judgment.
- Optional external fact-check retrieval pulling the product toward generic verification.

## Trust Controls
- Explicit claim-type labels.
- Explicit "worth checking, not false" copy.
- Optional source notes for how a claim was identified.
- `factcheck_lookup` is separate from core audits, scaffold-first by default, factual-claim-only for retrieval, and labeled as verification support rather than truth judgment. Local ClaimReview retrieval sends no claim text externally; publisher harvest and provider-backed retrieval are consent-gated.

## Mitigations
- Rank only factual claims.
- Keep verification confidence separate from truth confidence.
- Make the ranking explanation visible in every output that uses it.
