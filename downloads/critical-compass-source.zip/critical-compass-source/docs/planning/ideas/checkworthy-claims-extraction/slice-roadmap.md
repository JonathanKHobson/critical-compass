# Check-Worthy Claims Extraction Slice Roadmap

## Smallest Shippable Slice
Extract candidate claims from text, classify claim type, and rank only factual claims for verification priority.

## Follow-On Slices
1. Add explanation text for why each claim is prioritized.
2. Add evidence-needed prompts.
3. Add integration with argument maps and report handouts.

## Dependencies
- Claim taxonomy
- Stable notion of factual versus interpretive language
- A place to surface rankings in audit outputs
