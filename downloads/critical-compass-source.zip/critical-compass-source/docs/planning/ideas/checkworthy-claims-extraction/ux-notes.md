# Check-Worthy Claims Extraction UX Notes

## UX Goal
Help the user see where verification effort should go first without turning the product into a fact-check verdict engine.

## Good UX
- Simple labels for claim type.
- Prioritized factual claims first.
- A short explanation of why the claim is worth checking.

## Failure Modes
- The UI suggests "checked" means false.
- Non-factual language gets ranked as if it were evidence.
- The user cannot tell why one claim outranked another.

## Content Rules
- Use plain language.
- Keep the ranking rationale short.
- Make the boundary between claim type and verdict visible.
