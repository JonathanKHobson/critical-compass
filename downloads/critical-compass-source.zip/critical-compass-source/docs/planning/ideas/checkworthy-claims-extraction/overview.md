# Check-Worthy Claims Extraction

## Problem / Opportunity
Critical Compass can already flag weak reasoning, but it needs a cleaner way to identify which factual claims deserve verification effort first. That is different from judging a claim false.

## Why This Matters
This idea fits Critical Compass because it preserves a disciplined split between claim type, evidence need, and verdict. The system should tell the user what is worth checking, not pretend that every check-worthy claim is wrong.

## User Segments / Jobs
- Host AIs that need to prioritize verification work.
- Users who want to know what factual claim to check first.
- Reviewers who need a fast triage layer before deeper audit work.

## Adjacent Inspirations
- FactRank
- ClaimBuster
- Fact-checking APIs and evaluation pipelines

## Adopt / Adapt / Reject
- Adopt directly: check-worthiness as a triage concept.
- Adapt locally: fact-vs-interpretation classification.
- Reject for core: automatic fact-check APIs or research retrieval. Use local Evidence Needed Next planning unless a separate explicit product decision authorizes opt-in retrieval.
- Reject: any design that labels a claim false just because it is check-worthy.

## Belongs As
Tool and elicitation layer, with report-ready summaries when needed.
