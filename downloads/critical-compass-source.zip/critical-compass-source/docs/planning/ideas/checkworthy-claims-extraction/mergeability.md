# Check-Worthy Claims Extraction Mergeability

| Criterion | Assessment |
|---|---|
| Open-source / proprietary | Mixed inspirations; core feature can be local |
| License risk | Low if labels and rules are original |
| Local/self-hostable | High |
| Maturity / maintenance burden | Medium |
| Dependency footprint | Low to medium |
| Security / trust risk | Medium if external verification is added later |
| Build vs integrate vs reject | Build locally, optional integrate later |

## Outside Inspiration Decisions
- FactRank: adapt
- ClaimBuster: adapt
- Fact-check APIs: optional integration
- General fact-check workflows: adapt
