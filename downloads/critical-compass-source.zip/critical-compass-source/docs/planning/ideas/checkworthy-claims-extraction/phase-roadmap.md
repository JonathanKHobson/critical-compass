# Check-Worthy Claims Extraction Phase Roadmap

## Phase 1
- Define the claim taxonomy and ranking rule.
- Build local extraction heuristics and output shape.
- Add "worth checking" language to prompts and docs.

## Phase 2
- Core scope rejects automatic external fact-check integration. The separate `factcheck_lookup` lane is now scaffold-first by default, with opt-in local ClaimReview retrieval, consent-gated direct publisher harvest, explicit/experimental provider-backed retrieval, trusted publisher allowlist, privacy guard, and no-network tests.
- Connect ranked claims to report artifacts and follow-up questions.

## Phase 3
- Add calibration and evaluation against real audit text.
- Add domain-specific prioritization if needed later.

## Stop Condition
Do not add truth verdicts to the check-worthiness layer.
