# Check-Worthy Claims Extraction Evaluation

## What To Test
- Does the system classify claim types correctly?
- Does it prioritize factual claims only?
- Does the copy avoid implying that check-worthy means false?

## Metrics
- Precision on factual-claim detection.
- User understanding of the ranking distinction.
- Reduced time spent checking the wrong thing first.

## Acceptance Cases
- A mixed claim paragraph returns factual claims at the top and interpretive claims elsewhere.
- A policy sentence is classified without being ranked as a factual verification target.
- The user can explain why the top claim was prioritized.
