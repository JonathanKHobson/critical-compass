# Check-Worthy Claims Extraction PRD

## Problem Statement
The product needs a disciplined way to prioritize verification work. Without it, host AIs may waste time checking normative or interpretive language as if it were factual, or may miss the factual claims that matter most.

## Claim Types
- Factual
- Interpretive
- Causal
- Normative
- Policy

## Ranking Rule
Rank only factual claims for verification priority. Other claim types may still matter for the audit, but they do not receive check-worthiness priority scores.

## Core Rule
Check-worthy means worth verifying, not false.

## Output Behavior
- Identify candidate claims.
- Classify each claim by type.
- Rank only factual claims for priority.
- Explain why a claim is worth checking.
- Surface what evidence would change the current confidence.

## Acceptance Criteria
- The system does not rank interpretive, causal, normative, or policy claims as if they were factual verification targets.
- The system never uses check-worthy as a synonym for false.
- The user can see why a factual claim rose to the top.

## Success Metrics
- Less wasted verification effort.
- Clearer separation of reasoning, interpretation, and fact checking.
- Better host-AI routing to the right follow-up question.
