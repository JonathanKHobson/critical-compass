# Argument Map Output Mergeability

| Criterion | Assessment |
|---|---|
| Open-source / proprietary | Mixed inspirations, but the output itself is local |
| License risk | Low if only structural ideas are borrowed |
| Local/self-hostable | High |
| Maturity / maintenance burden | Low to medium |
| Dependency footprint | Low |
| Security / trust risk | Low |
| Build vs integrate vs reject | Build locally |

## Outside Inspiration Decisions
- Kialo: adapt
- Rationale: adapt
- Argdown: adopt directly
- FactRank: adapt
