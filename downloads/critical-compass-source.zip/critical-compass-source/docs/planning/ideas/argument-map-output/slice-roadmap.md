# Argument Map Output Slice Roadmap

## Smallest Shippable Slice
Render a plain-language argument map and the JSON structure from a single audit result.

## Follow-On Slices
1. Add Markdown export.
2. Add `.argdown` export.
3. Add a report appendix view.
4. Add node-to-source trace links.

## Dependencies
- Stable audit output fields
- Check-worthy claim extraction
- Dissent-aware synthesis
