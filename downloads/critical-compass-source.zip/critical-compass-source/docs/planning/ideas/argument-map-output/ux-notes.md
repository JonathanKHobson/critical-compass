# Argument Map Output UX Notes

## UX Goal
Make the reasoning visible without making the user decode the whole audit.

## Good UX
- One central claim at the top.
- Clear branch labels for support, objection, and assumption.
- Plain-language summary first, structure second.

## Failure Modes
- The map becomes a dense logic tree with no narrative.
- Objections and assumptions are mixed together.
- The output reads like a hidden model trace instead of a user artifact.

## Content Rules
- Keep each node short.
- Use labels the reader can act on.
- Avoid adding a node unless it changes the user's decision-making.
