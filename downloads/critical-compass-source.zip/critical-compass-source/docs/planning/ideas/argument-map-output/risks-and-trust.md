# Argument Map Output Risks And Trust

## Risks
- False confidence if the map looks complete but omits key evidence.
- Over-branching into every possible objection.
- Confusing interpretation with factual support.

## Trust Controls
- Keep explicit claim types.
- Keep source trace fields in the map.
- Require a "what would change my mind" node for full maps.

## Mitigations
- Cap the number of nodes in default view.
- Collapse low-value branches.
- Require a clear status when the map is incomplete.
