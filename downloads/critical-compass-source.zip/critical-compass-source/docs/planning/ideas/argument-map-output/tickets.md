# Argument Map Output Tickets

- AM-01: Define canonical argument-map JSON shape.
- AM-02: Draft plain-language rendering rules.
- AM-03: Add Markdown output for the map.
- AM-04: Add `.argdown` export mapping.
- AM-05: Add report artifact placement rules.
- AM-06: Add acceptance cases for factual, causal, and normative claims.

## Status Snapshot - 2026-04-15

- AM-01 through AM-05: Done in normalization, Markdown export, `.argdown` export, and full-report rendering.
- AM-06: Done through artifact tests, smoke coverage, and causal/normative-heavy acceptance fixtures.
- AM-07: Done - `.argdown` remains embedded in Markdown/PDF and is also written as a deterministic sidecar next to generated reports.
