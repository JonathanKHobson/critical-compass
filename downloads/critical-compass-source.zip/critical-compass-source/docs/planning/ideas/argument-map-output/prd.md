# Argument Map Output PRD

## Problem Statement
Current outputs can tell the user what is weak, but they do not always show the reasoning structure in a form that is easy to review. That makes follow-up, collaboration, and repair harder than it needs to be.

## User Jobs
- "Show me the claim and the reasons under it."
- "Let me see the objections and missing evidence."
- "Give me a text artifact I can hand to another person."

## Required Output Forms
1. Plain-language version
2. Structured JSON shape
3. Markdown output
4. `.argdown` export plan

## Canonical JSON Shape
```json
{
  "central_claim": "",
  "claim_type": "factual|interpretive|causal|normative|policy",
  "supporting_reasons": [],
  "objections": [],
  "assumptions": [],
  "evidence_gaps": [],
  "checkworthy_claims": [],
  "confidence": "low|medium|high",
  "next_questions": [],
  "status": "draft|ready|withheld"
}
```

## UX / Behavior
- Keep the plain-language version short and readable first.
- Show structure before polish.
- Make it clear when an item is a reason, an objection, or an assumption.

## Acceptance Criteria
- The map can be read without knowing the JSON schema.
- The map can be exported as Markdown and `.argdown`.
- The map never invents facts that are not present in the audit.

## Success Metrics
- Users report better understanding of "why the audit said that."
- Reviewers can reuse the map in discussion or revision.
- Host AIs stop re-explaining the same reasoning in ad hoc language.
