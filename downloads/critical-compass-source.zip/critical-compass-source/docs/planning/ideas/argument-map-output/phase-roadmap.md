# Argument Map Output Phase Roadmap

## Phase 1
- Define the JSON contract and plain-language view.
- Add Markdown rendering for the same structure.
- Add a deterministic `.argdown` export plan.

## Phase 2
- Add the map to audit and report artifacts.
- Add an argument-map appendix for full reports.

## Phase 3
- Optional UI for browsing and editing maps.
- Optional linking between argument map nodes and source text.

## Stop Condition
Do not add interactive editing until the export path is stable and useful on its own.
