# Argument Map Output Evaluation

## What To Test
- Can a reader explain the argument back after viewing the map?
- Can a host AI reuse the map without inventing facts?
- Does the map make objections and assumptions easier to see?

## Metrics
- Faster comprehension.
- Better reviewer agreement on the central claim.
- Fewer "what do you mean?" follow-ups.

## Acceptance Cases
- A policy text becomes a readable claim tree.
- A user can export the same structure as Markdown and `.argdown`.
- The map preserves uncertainty instead of flattening it into a verdict.
