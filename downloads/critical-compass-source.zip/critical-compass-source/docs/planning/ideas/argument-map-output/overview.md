# Argument Map Output

## Problem / Opportunity
Critical Compass can identify risks and tensions, but users still need a clearer artifact that shows how the reasoning fits together. An argument map makes the structure visible: central claim, support, objections, assumptions, and evidence gaps.

## Why This Matters
This is a direct fit for Critical Compass because the product already works in terms of claims, biases, assumptions, and dissent. Argument mapping turns that structure into something a reader can inspect, discuss, or export.

## User Segments / Jobs
- Host AIs that need a deterministic reasoning artifact.
- Users who want to see the claim structure behind the verdict.
- Reviewers who need a portable map for discussion or revision.

## Adjacent Inspirations
- Kialo
- Rationale
- Argdown
- ClaimBuster and FactRank

## Adopt / Adapt / Reject
- Adopt directly: `Argdown` as an export format.
- Adapt locally: the tree structure from Kialo/Rationale.
- Adapt locally: check-worthiness ideas from FactRank.
- Reject: a visual map that hides source structure or invents evidence.

## Belongs As
Tool, report artifact, and resource. The plain-language map should also be available in Markdown.
