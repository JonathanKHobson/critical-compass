# Risks And Trust: Tool Source Trust Preflight

## Key Risks
- The rubric becomes a rubber stamp.
- A source is trusted because it is convenient, not because it is safe.
- Prompt injection hides inside source material or tool output.
- Consent scope is ignored once the source is technically accessible.

## Mitigations
- Require a visible decision reason.
- Preserve the trust decision in logs and report metadata.
- Treat any source containing instructions as potentially hostile until reviewed.
- Keep the trust model local and reviewable.

## Trust Boundary
This layer is a guardrail, not a guarantee. It should reduce exposure and make risk legible, not pretend to eliminate all harm.

