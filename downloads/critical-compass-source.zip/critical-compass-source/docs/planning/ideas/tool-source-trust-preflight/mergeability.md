# Mergeability: Tool Source Trust Preflight

## Local Mergeability Assessment
| Inspiration | Open / Proprietary | License Risk | Local / Self-Hostable | Maturity / Maintenance | Dependency Footprint | Security / Trust Risk | Recommendation |
|---|---|---|---|---|---|---|---|
| MCP Guard / MCP Shield patterns | Open-source | Low | Yes | Emerging | Low to moderate | Low to medium | Adapt locally |
| Prompt injection checklists | Open concept | Low | Yes | Mature as a security practice | Low | Low | Adopt as method |
| Consent / provenance rubrics | Open concept | Low | Yes | Mature as a governance pattern | Low | Low | Adopt locally |
| External security scanners / sandboxes | Mixed | Medium | Sometimes | Varies | Moderate to high | Low to medium | Optional integration |

## Build / Integrate / Reject
- Build the preflight locally.
- Integrate external security tooling only when a specific risk warrants it.
- Reject any trust design that depends on model intuition alone.

