# Phase Roadmap: Tool Source Trust Preflight

## Phase 1: Trust Rubric
- Define trust categories and severity levels.
- Add consent and provenance checks.
- Add a compact decision reason.

## Phase 2: Injection And Poisoning Checks
- Add prompt-injection heuristics for text and tool outputs.
- Flag suspicious instructions embedded in source materials.
- Make the result visible to the host AI before use.

## Phase 3: Integration And Logging
- Persist trust preflight results in audit state.
- Surface trust summaries in report metadata.
- Add reviewable examples for safe and unsafe sources.

