# Tool Source Trust Preflight

## Problem / Opportunity
Critical Compass can become untrustworthy if it accepts files, sources, or tool outputs without checking provenance, consent, and injection risk first. A trust preflight layer gives the host AI a disciplined way to decide whether a source is safe enough to use and how much confidence to place in it.

## Why This Matters For Critical Compass
The product promises careful judgment. That promise breaks if the system freely ingests poisoned prompts, ambiguous source files, or untrusted tool outputs and then treats them as ground truth.

## Users And Jobs To Be Done
- Host AI: know what is safe to ingest and what is not.
- Audit author: understand whether a source can be trusted for this run.
- Reviewer: see the trust logic, not just the result.

## Borrowed Ideas
- MCP Guard / MCP Shield-style protections: adapt.
- Prompt injection and tool-poisoning checklists: adopt.
- Source credibility and consent rubrics: adapt.
- Security sandboxing patterns: optionally integrate later.

## Adopt / Adapt / Reject
- Adopt: explicit trust rubric, consent boundaries, and injection checks.
- Adapt: source risk scoring into a short preflight decision.
- Reject: blind acceptance of any file or tool output because it was available.

## Belonging
- Primary form: tool + server instruction.
- Secondary form: resource for trust rules and examples.

## Smallest Shippable Slice
Add a preflight gate that classifies source/tool trust, records the reason, and blocks or warns when consent, provenance, or injection risk is too high.

