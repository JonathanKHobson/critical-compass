# Slice Roadmap: Tool Source Trust Preflight

## Slice 1
- Classify source/tool trust as allow, warn, or block.
- Record provenance, consent, and the reason.

## Slice 2
- Add prompt-injection and tool-poisoning checks.
- Surface the preflight result to the host AI before any deeper use.

## Slice 3
- Persist preflight logs and add regression fixtures.
- Add report metadata that shows how trust was handled.

