# UX Notes: Tool Source Trust Preflight

## Reader Experience
The preflight should answer a simple question: is this thing safe enough to use, and what is the catch?

## UX Risks
- If the rubric is opaque, users will ignore it.
- If the system blocks too aggressively, users will route around it.
- If consent is buried, the product will feel untrustworthy.

## UX Rules
- Show trust status before any deeper processing.
- Explain consent boundaries in plain language.
- Make injection risk visible without dramatizing it.

## Belongs As
- Tool: yes.
- Server instruction: yes.
- Resource: yes, for the rubric and examples.
- MCP App: only if a future visual review surface needs it.

