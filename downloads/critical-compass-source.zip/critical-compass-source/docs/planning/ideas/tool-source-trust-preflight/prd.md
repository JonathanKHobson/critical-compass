# PRD: Tool Source Trust Preflight

## Goal
Stop untrusted input from silently entering audits, reports, or agent workflows.

## User Segments
- Host AI deciding whether to call a tool or ingest a file.
- User providing a document or external source.
- Reviewer asking how much trust the system placed in a source.

## Functional Requirements
- Score source/tool trust with a small, explainable rubric.
- Check consent boundaries before using external or user-provided material.
- Detect prompt injection and tool-poisoning signals.
- Emit a clear allow / warn / block outcome.
- Preserve the reason in audit logs and report metadata.

## Non-Goals
- No automatic web search by default.
- No broad antivirus replacement.
- No hidden “trust by model confidence” shortcut.

## Acceptance Criteria
- The system can explain why a source was accepted or rejected.
- High-risk input is blocked or marked with a warning, not silently consumed.
- Trust decisions are reproducible from the saved preflight output.

## Success Metrics
- Fewer unsafe or ambiguous sources entering the audit.
- Clearer host-AI handoffs.
- Lower incidence of injection-like content surviving into final reports.

