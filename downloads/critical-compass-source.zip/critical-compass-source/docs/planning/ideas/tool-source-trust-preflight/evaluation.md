# Evaluation: Tool Source Trust Preflight

## What Success Looks Like
- Unsafe sources are flagged before they enter the workflow.
- The host AI can explain why a source was accepted or blocked.
- Users understand where the trust boundary sits.

## Evaluation Methods
- Red-team with injected instructions inside documents.
- Consent-boundary tests on user-provided material.
- Regression tests for allow / warn / block reproducibility.
- Review of trust reasoning clarity.

## Metrics
- Injection-detection hit rate.
- False-allow rate.
- False-block rate.
- Percentage of preflight decisions with a human-readable reason.

