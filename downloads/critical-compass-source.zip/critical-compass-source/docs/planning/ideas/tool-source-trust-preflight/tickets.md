# Tickets: Tool Source Trust Preflight

## Prioritized Tickets
1. P0 - Define the trust rubric and allow / warn / block outcomes.
2. P0 - Add consent and provenance checks.
3. P0 - Detect prompt injection and tool-poisoning signals.
4. P1 - Persist preflight output in audit state.
5. P1 - Expose trust summaries in host-AI prompts and report metadata.
6. P2 - Add safe/unsafe fixtures and red-team examples.

## Status Snapshot - 2026-04-15

- Tickets 1, 2, and 3: Done through local source/tool trust preflight helpers and explicit PDF source preparation.
- OCR/source-preflight path: Done for the local Apple Vision route on this Mac; the 36 Questions source preflight passed with OCR and page images.
- Tickets 4, 5, and 6: Done - preflight output is persisted beside prepared sources, compact trust summaries are returned in report metadata/save payloads, and red-team fixtures cover prompt injection, tool poisoning, and secret-exfiltration language.
