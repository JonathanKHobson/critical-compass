# PRD: Compass Eval Studio Foundations

## Goal

Make Critical Compass reliability debuggable across the full audit journey by connecting prompts, stage traces, eval fixtures, report QA, and human review.

This is a future P2/P3 lane. It must not interrupt the beta.10 delivery-layer hotfix or release closeout.

## Primary Users

- Maintainer: diagnose why an audit passed or failed and preserve regressions as fixtures.
- Host AI/operator: understand which prompt/scaffold version and lens cards shaped an output.
- Human reviewer: judge over-critique, missed critique, report readiness, and calibration quality.
- Future contributor: improve prompts or scaffolds without guessing which behavior they affect.

## P2 Requirements

1. Add a local prompt/scaffold registry for Critical Compass prompt-bearing surfaces.
2. Track `prompt_id`, `stage`, `version`, `hash`, `source_path`, `status`, and `change_note`.
3. Define an opt-in audit run trace with spans for source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA.
4. Each trace span should record compact input/output summaries, selected lens IDs, scaffold or prompt version IDs, warnings, blockers, and timing.
5. Add a trace-to-candidate-fixture workflow that creates reviewed fixture proposals instead of silently mutating gold cases.
6. Extend evaluation reporting so pass/fail is paired with expected finding recall, expected non-finding violations, lens over-selection, report readiness misses, CIS ordering, renderer banned-string leaks, and human-loop compliance.

## P3 Requirements

1. Render a local HTML dashboard from eval outputs and trace JSON files.
2. Compare two prompt or scaffold versions side by side across the same fixtures.
3. Add a human review queue for pass/fail, severity, critique-overreach, expected non-finding violations, and notes.
4. Add replay planning for saved stage snapshots, keeping local JSON as the source of truth.
5. Consider optional OpenTelemetry-style export only after the local trace contract has proven useful.

## Non-Goals

- No hosted Agenta dependency.
- No new MCP tool in the foundation slice.
- No external observability service.
- No automatic capture of raw private text.
- No automatic promotion of failed traces into gold fixtures.
- No scoring-weight retune without separate calibration evidence.

## Planning Contracts

These are planning contracts only. They document the intended future shapes and must not be treated as live runtime schemas until a later implementation slice explicitly wires them.

### `PromptScaffoldRegistryEntry`

Required fields:

- `prompt_id`: stable ID for a prompt, scaffold, or contract surface.
- `stage`: audit stage the prompt/scaffold affects.
- `version`: local version label.
- `hash`: content hash for drift detection.
- `source_path`: repo-local source file path.
- `status`: `active`, `draft`, `deprecated`, or `archived`.
- `change_note`: short reason for the current version.

Optional fields:

- `owner`
- `last_reviewed`

### `AuditTraceSpan`

Required fields:

- `span_id`
- `stage`
- `started_at`
- `ended_at`
- `input_summary`
- `output_summary`
- `selected_lens_ids`
- `prompt_ids`
- `warnings`
- `blockers`
- `timing_ms`

Trace spans should summarize sensitive input rather than copying raw private text by default.

### `CandidateFixtureProposal`

Required fields:

- `source_trace_id`
- `failure_stage`
- `expected_findings`
- `expected_non_findings`
- `forbidden_lens_ids`
- `expected_absent_traps`
- `acceptable_cis_range`
- `report_readiness_expectations`
- `review_status`

Candidate proposals wait for human or maintainer review before entering gold fixtures.

### `HumanReviewRecord`

Required fields:

- `reviewer`
- `case_id`
- `pass_fail`
- `severity`
- `critique_overreach`
- `expected_non_finding_violation`
- `notes`
- `fixture_recommendation`

## Acceptance Criteria

- Future work can tell which prompt/scaffold version affected a run.
- A failed run can become a reviewed candidate fixture without manual archaeology.
- Evaluation summaries explain why a case passed, not just that it passed.
- Human review can flag over-critique and expected non-finding violations.
- Reader-facing reports never expose traces, registry metadata, or dashboard internals.
