# Slice Roadmap: Compass Eval Studio

## P2-A: Registry Contract

Entry criteria: beta.10 delivery work is closed or explicitly paused.

Work: define the prompt/scaffold registry contract and inventory the surfaces that should eventually receive stable IDs.

Exit criteria: registry fields, lifecycle statuses, and drift-detection expectations are documented.

## P2-B: Trace Contract

Entry criteria: registry contract exists.

Work: define opt-in audit trace spans for source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA.

Exit criteria: trace span fields, privacy defaults, and reader-facing exclusions are documented.

## P2-C: Trace To Candidate Fixture

Entry criteria: trace contract exists.

Work: define the candidate fixture proposal flow, review states, and expected eval fields.

Exit criteria: failed traces can be converted into reviewable proposals without mutating gold fixtures.

## P2-D: Eval Reporting Upgrade

Entry criteria: candidate fixture flow exists.

Work: define summary metrics and stage-linked failure reporting for prompt/scaffold changes.

Exit criteria: future eval summaries can include expected finding recall, expected non-finding violations, lens over-selection, report-readiness misses, CIS ordering, renderer banned-string leaks, and human-loop compliance.

## P3-A: Local Reliability Dashboard

Entry criteria: trace artifacts and eval summaries exist from P2 implementation.

Work: plan a static local dashboard for trends, blockers, version links, and stage failures.

Exit criteria: dashboard input artifacts and privacy exclusions are specified.

## P3-B: Side-By-Side Comparison

Entry criteria: registry versions and eval fixture sets are stable.

Work: plan comparison output for two prompt/scaffold versions over the same cases.

Exit criteria: comparison output includes behavior deltas and regressions, not only a winner.

## P3-C: Human Review Queue

Entry criteria: candidate fixture proposals exist.

Work: plan reviewer records, severity labels, critique-overreach flags, and fixture recommendations.

Exit criteria: human review can bless, reject, or revise candidate fixtures.

## P3-D: Trace Replay And Optional Export

Entry criteria: trace spans have proven useful in real failures.

Work: plan replay boundaries, required stage snapshots, and optional export fields.

Exit criteria: replay requirements are documented before any runner or interoperability export is built.

## Release Boundary

None of these slices belong in beta.10 unless a release blocker specifically requires a documentation-only pointer. Beta.10 remains the delivery-layer hotfix lane.
