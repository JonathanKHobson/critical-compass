# Evaluation: Compass Eval Studio

## Evaluation Goals

- Show which stage caused a failure, not only which final test failed.
- Preserve failed traces as reviewable fixture candidates.
- Make prompt/scaffold version changes measurable.
- Track over-critique and expected non-finding violations as first-class quality failures.
- Keep trace metadata out of reader-facing reports.

## P2 Acceptance Tests

- A registry scan can list all registered prompt/scaffold surfaces with stable IDs and hashes.
- A sample audit trace contains spans for source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA.
- Trace capture is disabled by default or summary-only unless explicitly enabled.
- A failed trace can generate a candidate fixture proposal with expected findings, expected non-findings, forbidden lens IDs, expected absent traps, CIS range, and report-readiness expectations.
- Calibration summaries include stage-linked failures and the existing negative metrics.

## P2 Test Scenarios

- Registry scan: a synthetic registry entry points at an existing scaffold file, computes or records a stable hash, and fails clearly when the source path is missing.
- Trace capture: a synthetic run trace includes all required `AuditTraceSpan` fields and omits raw private text unless explicitly fixture-approved.
- Fixture proposal generation: a failed lens-over-selection trace becomes a candidate fixture proposal with forbidden lens IDs and `review_status`.
- Eval reporting: a calibration summary can distinguish a missed expected finding from an expected non-finding violation.
- Privacy guardrail: reader-facing Markdown, HTML, and PDF outputs contain no trace IDs, registry metadata, or reviewer notes.

## P3 Acceptance Tests

- The dashboard renders from local JSON without live network or external services.
- Side-by-side comparison reports CIS deltas, lens-selection deltas, expected non-finding violations, report-readiness misses, and banned-string leaks.
- Human review exports can be used to bless, reject, or revise candidate fixtures.
- Replay planning can identify which stage snapshots are required before any replay runner is implemented.

## P3 Test Scenarios

- Dashboard rendering: a local HTML dashboard renders from sample eval summary JSON and sample trace JSON with no network access.
- Comparison output: two prompt/scaffold versions run against the same fixture manifest and produce visible deltas for CIS, lens selection, report readiness, and banned-string leaks.
- Human review export: a review record can mark critique overreach, severity, expected non-finding violation, and fixture recommendation.
- Trace replay planning: replay docs identify required source classification, retrieval, fairness, scoring, validation, and report QA snapshots before implementation starts.
- Optional export: any export plan preserves local JSON as canonical and stays disabled by default.

## Regression Checks

- Existing beta calibration remains runnable without trace capture.
- Existing report renderer validation remains unchanged.
- No public report includes prompt registry, trace JSON, reviewer notes, or dashboard metadata.
- No automated test captures raw private input unless the fixture explicitly opts in with synthetic or public text.
- All six planning docs exist in this folder: `overview.md`, `prd.md`, `phase-roadmap.md`, `slice-roadmap.md`, `tickets.md`, and `evaluation.md`.
- Every `CES-01` through `CES-13` ticket maps to a phase.
- Failed traces become reviewed fixture proposals rather than automatic gold fixtures.
