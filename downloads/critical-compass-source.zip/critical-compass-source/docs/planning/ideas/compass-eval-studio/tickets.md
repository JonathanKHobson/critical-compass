# Tickets: Compass Eval Studio

## P2 Backlog

1. `CES-01` - Define the local prompt/scaffold registry schema and registry file location.
   - Phase: P2-A.
   - Implementation note: document the registry before writing a scanner.
   - Acceptance: registry fields include `prompt_id`, `stage`, `version`, `hash`, `source_path`, `status`, `change_note`, optional `owner`, and optional `last_reviewed`.
2. `CES-02` - Inventory current prompt-bearing surfaces and assign stable `prompt_id` values.
   - Phase: P2-A.
   - Implementation note: include server prompts, scaffold resources, human-loop contracts, report contracts, and skill/reference surfaces only after confirming they affect outputs.
   - Acceptance: every inventoried surface maps to a stage and source path.
3. `CES-03` - Define the audit-run trace schema with stage spans for classification, retrieval, fairness, scoring, validation, and report QA.
   - Phase: P2-B.
   - Implementation note: keep trace spans compact and stage-oriented.
   - Acceptance: `AuditTraceSpan` includes `span_id`, `stage`, `started_at`, `ended_at`, `input_summary`, `output_summary`, `selected_lens_ids`, `prompt_ids`, `warnings`, `blockers`, and `timing_ms`.
4. `CES-04` - Add privacy guardrails for trace capture: opt-in, summary-first, no raw private text by default.
   - Phase: P2-B.
   - Implementation note: fixture/public text can opt into fuller capture; private user text cannot be captured automatically.
   - Acceptance: docs state traces are local, opt-in, non-reader-facing, and private-text-minimizing.
5. `CES-05` - Define the trace-to-candidate-fixture proposal format.
   - Phase: P2-C.
   - Implementation note: proposals are review artifacts, not direct edits to `support/evals`.
   - Acceptance: `CandidateFixtureProposal` includes `source_trace_id`, `failure_stage`, `expected_findings`, `expected_non_findings`, `forbidden_lens_ids`, `expected_absent_traps`, `acceptable_cis_range`, `report_readiness_expectations`, and `review_status`.
6. `CES-06` - Update calibration outputs to link failures to trace stages and registry versions.
   - Phase: P2-D.
   - Implementation note: this should augment existing calibration summaries, not require trace capture for normal runs.
   - Acceptance: future summaries can show failing stage and prompt/scaffold version when trace data exists.
7. `CES-07` - Add eval summary fields for expected finding recall, expected non-finding violations, lens over-selection, report readiness misses, CIS ordering, renderer banned-string leaks, and human-loop compliance.
   - Phase: P2-D.
   - Implementation note: preserve existing negative metrics and add missing report/human-loop dimensions.
   - Acceptance: summary output explains both missed critique and over-critique.
8. `CES-08` - Add docs explaining that Agenta is a reference model, not a runtime dependency.
   - Phase: P2-D.
   - Implementation note: keep source links in planning docs only.
   - Acceptance: docs explicitly reject hosted Agenta integration for this lane.

## P3 Backlog

9. `CES-09` - Build a local HTML dashboard from eval summaries and trace JSON files.
   - Phase: P3-A.
   - Implementation note: static local output only; no hosted dashboard.
   - Acceptance: dashboard can show trends, stage failures, prompt/scaffold versions, lens over-selection, CIS ordering, report QA leaks, and human-loop compliance.
10. `CES-10` - Add side-by-side prompt/scaffold comparison across the same fixture set.
    - Phase: P3-B.
    - Implementation note: report deltas and regressions; do not auto-select a winning prompt.
    - Acceptance: comparison includes CIS deltas, lens-selection deltas, expected non-finding violations, report-readiness misses, banned-string leaks, and human-loop compliance.
11. `CES-11` - Add a human review queue for domain judgment, critique-overreach, severity, and expected non-finding violations.
    - Phase: P3-C.
    - Implementation note: reviewer notes stay local and are not report content.
    - Acceptance: `HumanReviewRecord` includes `reviewer`, `case_id`, `pass_fail`, `severity`, `critique_overreach`, `expected_non_finding_violation`, `notes`, and `fixture_recommendation`.
12. `CES-12` - Add trace replay planning for saved stage snapshots.
    - Phase: P3-D.
    - Implementation note: document replay boundaries before building a runner.
    - Acceptance: replay requirements name required stage snapshots and what can be replayed safely.
13. `CES-13` - Revisit optional trace export formats after local JSON proves useful.
    - Phase: P3-D.
    - Implementation note: local JSON remains the source of truth.
    - Acceptance: optional export is documented as deferred and non-blocking.

## Explicitly Not Addressed

- No hosted Agenta integration.
- No new MCP tool.
- No public report UI changes.
- No automatic gold-fixture mutation.
- No scoring-weight retune.
- No beta.10 package, Pages, or release artifact changes.
