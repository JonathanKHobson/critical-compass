# Phase Roadmap: Compass Eval Studio

## Phase Boundary

Compass Eval Studio is a future P2/P3 reliability lane. It starts only after the active delivery hotfix and publish-stability work are closed. It does not add Agenta, a new MCP tool, a hosted dashboard, or beta.10 release-surface changes.

## P2-A: Prompt / Scaffold Registry Contract

What it is: a local contract for identifying the prompt-bearing and scaffold-bearing surfaces that shape Critical Compass outputs.

Why it exists: future prompt edits should be traceable. A failing report, lens selection, or human-loop response should be able to say which prompt or scaffold version shaped the behavior.

What changes: planning and later implementation define registry records with `prompt_id`, `stage`, `version`, `hash`, `source_path`, `status`, `change_note`, and optional `owner` and `last_reviewed`.

What does not change: no prompt behavior changes, no runtime prompt loading changes, and no public MCP tool surface changes in the planning slice.

Acceptance: every future prompt/scaffold registry entry can be located, hashed, and tied to one audit stage.

## P2-B: Opt-In Audit Trace Contract

What it is: a local run-trace shape with stage spans for source classification, lens retrieval, fairness-to-text, CIS scoring, report payload validation, and rendered artifact QA.

Why it exists: current evals can say that a run failed, but future work needs to show where and why it failed.

What changes: planning defines `AuditTraceSpan` with `span_id`, `stage`, `started_at`, `ended_at`, `input_summary`, `output_summary`, `selected_lens_ids`, `prompt_ids`, `warnings`, `blockers`, and `timing_ms`.

What does not change: traces remain opt-in, local, and non-reader-facing. Raw private user text is not captured by default.

Acceptance: a future trace can identify the failed stage without exposing private source text or report internals to readers.

## P2-C: Failed Trace To Candidate Fixture Workflow

What it is: a workflow for turning a failed run trace into a reviewed fixture proposal.

Why it exists: failures should become regression learning without silently mutating gold eval files.

What changes: planning defines `CandidateFixtureProposal` with `source_trace_id`, `failure_stage`, `expected_findings`, `expected_non_findings`, `forbidden_lens_ids`, `expected_absent_traps`, `acceptable_cis_range`, `report_readiness_expectations`, and `review_status`.

What does not change: no automatic gold fixture promotion and no automatic scoring retune.

Acceptance: a failed trace can produce a candidate fixture that waits for review before entering `support/evals`.

## P2-D: Eval Summary / Reporting Upgrades

What it is: a tighter evaluation report shape that connects outcomes to prompt versions, trace stages, and negative metrics.

Why it exists: a green test run can still hide over-selection, over-critique, CIS ordering drift, or renderer leakage.

What changes: future eval summaries should report expected finding recall, expected non-finding violations, lens over-selection, report readiness misses, CIS ordering, renderer banned-string leaks, and human-loop compliance.

What does not change: existing beta calibration remains runnable without trace capture.

Acceptance: a future eval summary can explain why a case passed, why it failed, and which stage or prompt/scaffold version is implicated.

## P3-A: Local HTML Reliability Dashboard

What it is: a local static dashboard over eval summaries and trace JSON.

Why it exists: repeated JSON inspection is too slow for calibration and release-readiness review.

What changes: future dashboard work renders trends, blockers, prompt/scaffold versions, lens over-selection, CIS ordering, report QA leaks, and human-loop compliance.

What does not change: no hosted service, no live network, and no public report UI dependency.

Acceptance: the dashboard renders locally from existing artifacts and does not expose raw private text.

## P3-B: Side-By-Side Scaffold Comparison

What it is: a comparison runner for two prompt/scaffold versions across the same fixture set.

Why it exists: prompt changes need evidence that they improve behavior without creating new failures.

What changes: future comparison output reports CIS deltas, lens-selection deltas, expected non-finding violations, report-readiness misses, banned-string leaks, and human-loop compliance differences.

What does not change: no automatic winner selection and no silent prompt promotion.

Acceptance: a maintainer can compare two versions and see both improvements and regressions before adopting a change.

## P3-C: Human Review Queue

What it is: a lightweight local queue for domain and maintainer judgment on ambiguous cases.

Why it exists: not all critique quality can be validated by automated metrics, especially over-critique and non-Western lens fit.

What changes: planning defines `HumanReviewRecord` with `reviewer`, `case_id`, `pass_fail`, `severity`, `critique_overreach`, `expected_non_finding_violation`, `notes`, and `fixture_recommendation`.

What does not change: no external review service and no automatic publication of reviewer notes.

Acceptance: human review can bless, reject, or revise candidate fixtures and document why.

## P3-D: Trace Replay And Optional Export Planning

What it is: a later planning lane for replaying saved stage snapshots and optionally exporting trace metadata.

Why it exists: once traces are useful, maintainers may need to replay only the failing stage instead of rerunning the entire audit.

What changes: future replay planning identifies required stage snapshots, replay boundaries, and optional interoperability fields.

What does not change: local JSON remains the source of truth, and OpenTelemetry-style export is optional and deferred.

Acceptance: replay requirements are documented before any replay runner or external export is implemented.
