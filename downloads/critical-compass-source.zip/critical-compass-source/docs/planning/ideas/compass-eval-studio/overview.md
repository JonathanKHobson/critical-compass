# Compass Eval Studio

## Problem / Opportunity

Critical Compass has moved beyond single-output testing. The recurring reliability problems now come from stage-level drift: a prompt changes, a lens is over-selected, a report schema blocks late, a renderer leaks a placeholder, or a human-loop contract gets ignored by the host.

The opportunity is to make reliability visible as a local evaluation loop:

- versioned prompts and scaffold resources
- audit-stage traces
- trace-to-fixture conversion
- side-by-side scaffold comparison
- human review of difficult cases
- dashboard-style summaries of calibration, report QA, and host compliance

## Why Agenta Is Useful Here

Agenta is a useful reference model because it treats prompt management, evaluations, traces, and human review as one feedback system rather than separate chores. The pattern worth borrowing is not a hosted dependency; it is the product shape:

- prompts have versions and comparison history
- tests are organized into reusable sets
- full traces can be evaluated, not only final answers
- failed traces can become future tests
- humans can review outputs alongside automated evaluators

Reference sources:

- Product Hunt: https://www.producthunt.com/products/agenta/launches/agenta
- GitHub: https://github.com/Agenta-AI/agenta
- Prompt concepts: https://agenta.ai/docs/prompt-engineering/concepts
- Evaluation concepts: https://agenta.ai/docs/evaluation/concepts
- Observability concepts: https://agenta.ai/docs/observability/concepts
- Trace-to-test-set docs: https://agenta.ai/docs/evaluation/managing-test-sets/create-from-traces

## Recommended Form

This belongs as a **P2/P3 reliability backlog lane**, not as beta.10 work.

P2 should add local contracts and planning for prompt/scaffold registry, trace capture, trace-to-fixture proposals, and eval summary upgrades.

P3 can add a local HTML dashboard, side-by-side scaffold experiments, human review queue, and replay workflows.

## What This Displaces

This lane displaces ad hoc prompt tweaking, one-off JSON inspection, and "why did this pass?" debugging by giving future work a structured reliability loop. It should turn failures into traceable candidate fixtures rather than more prose guidance.

It does not displace the beta.10 delivery-layer hotfix, report renderer recovery work, or publish verification. If a release bug is blocking users, that bug remains higher priority than Eval Studio planning.

## Current Beta.10 Boundary

Beta.10 stays focused on delivery-layer reliability: silent-mode consent, report preflight, Markdown fallback, PDF timeout recovery, and release surfaces. Compass Eval Studio belongs after that ship lane is stable.

The only beta.10-safe Eval Studio work is documentation that prevents future drift. No package, Pages, manifest, public report, MCP tool, or renderer implementation should change for this lane.

## Guardrails

- No Agenta integration or external hosted dependency.
- No new MCP tool in the first slice.
- No automatic capture of private user text.
- No automatic promotion of failed traces into gold fixtures.
- No CIS weight retune from this lane alone.
- No beta.10 release-surface or package changes.

## Decision Snapshot

- Adopt: versioned prompt/scaffold registry, stage traces, trace-to-fixture proposal workflow, human review, side-by-side comparisons.
- Adapt: dashboard and replay as local static/report artifacts, not hosted observability infrastructure.
- Reject for now: external Agenta dependency, automatic private trace capture, and new public MCP surfaces.
