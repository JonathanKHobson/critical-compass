# Upgraded Report Artifacts

## Problem / Opportunity
Critical Compass already produces strong audits, but the current output shape is too narrow for real sharing. A stakeholder often needs a report they can read, print, forward, annotate, or use in a meeting, not just a long PDF.

The opportunity is to turn audit output into a small family of purpose-built artifacts:

- overview report
- full report
- "Questions To Bring To The Text" handout
- "Evidence Needed Next" table

## Users And Jobs To Be Done
- Host AI: turn audit data into the right artifact without inventing layout or missing fields.
- Reader / reviewer: decide whether to trust, challenge, or act on the text.
- Facilitator / manager: bring a short printed handout into a discussion.
- Self-auditor: use the report as a coaching and revision artifact.

## Why It Matters For Critical Compass
This is the best way to make the CIS and human-loop work portable. The audit is already more than a score; the report package should make that judgment usable outside the chat.

## Borrowed Patterns Worth Reusing
- Kialo-style progressive disclosure for argument visibility.
- Rationale-style argument summaries and evidence prompts.
- Argdown-style exportable structure for reasoning artifacts.
- FactRank-style separation between "worth checking" and "false."
- Report / handout split used in workshop and facilitation materials.

## Recommended Form
This idea belongs primarily as a **report artifact**, not as a new tool.

## UX Risks And Failure Modes
- The full report can become a summary dump instead of a decision aid.
- The handout can collapse into generic questions if it is not tied to the actual audit.
- Placeholder text can leak into delivered artifacts if readiness gates are weak.
- A reader can lose the distinction between evidence, interpretation, and recommendation.

## Decision Snapshot
- Adopt: two-tier report structure and printable handout logic.
- Adapt: external argument-map and check-worthy conventions into Critical Compass wording.
- Reject: generic long-form reporting that recaps everything and changes nothing.

