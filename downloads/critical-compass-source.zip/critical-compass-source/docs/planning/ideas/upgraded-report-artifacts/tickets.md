# Tickets: Upgraded Report Artifacts

1. Define the canonical artifact set and naming.
2. Specify the section order for overview and full reports.
3. Add the handout and evidence table layouts.
4. Add readiness gates for placeholder and fallback text.
5. Add Markdown export contracts for all report artifacts.
6. Add versioned example payloads for each artifact type.
7. Add report acceptance tests for overview vs full vs handout.
8. Add long-text sidecar behavior for report appendices.

## Status Snapshot - 2026-04-15

- Tickets 1 through 5 and 8: Done or substantially implemented in the Markdown/PDF report system, readiness gate, appendix sidecar behavior, and generated artifact sections.
- Ticket 6: Done through versioned local scaffold resources and report-ready examples.
- Ticket 7: Done through renderer validation, 36 Questions smoke, and targeted artifact tests.
- URA-09: Done - add golden report artifact screenshots for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks via `scripts/smoke_36_questions_report.py`.
- URA-10: Done - golden artifact manifest validation asserts required sections, PNG paths, page numbers, and labels.
