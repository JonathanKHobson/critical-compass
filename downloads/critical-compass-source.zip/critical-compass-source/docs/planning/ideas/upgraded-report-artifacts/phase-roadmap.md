# Phase Roadmap: Upgraded Report Artifacts

## Phase 1
- Lock the overview report and full report content model.
- Define the handout and evidence table as first-class artifact types.
- Add strict readiness gates so placeholder sections are blocked.

## Phase 2
- Add stable Markdown export for every report artifact.
- Add printable one-page handout output.
- Add "Evidence Needed Next" as a reusable table block.

## Phase 3
- Add advanced-audit attribution blocks and dissent summaries.
- Add report-sidecar handling for long raw text.
- Add versioned templates so reports remain reproducible.

## Phase 4
- Add optional visual preview surfaces for report exploration.
- Add artifact comparison for before/after audits.

