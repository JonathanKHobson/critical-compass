# Slice Roadmap: Upgraded Report Artifacts

## Smallest Shippable Slice
1. Overview report with verdict, plain-language read, before-using-this-text, key tension, and next step.
2. Full report with the same structure plus evidence-layer sections.
3. Readiness gate that blocks placeholder sections.

## Follow-On Slices
1. Printable "Questions To Bring To The Text" handout.
2. "Evidence Needed Next" table.
3. Advanced-audit attribution and dissent summary.
4. Sidecar handling for long raw text.

