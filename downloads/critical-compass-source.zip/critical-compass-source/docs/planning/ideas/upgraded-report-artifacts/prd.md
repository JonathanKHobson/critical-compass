# PRD: Upgraded Report Artifacts

## Goal
Produce report artifacts that help a reader make a decision, not just inspect an audit.

## Scope
The report system must support:
- overview report
- full report
- "Questions To Bring To The Text" handout
- "Evidence Needed Next" table
- readiness gates so placeholder sections never ship

## Non-Goals
- No new reasoning engine.
- No automatic web search in core report generation.
- No freeform PDF layout authored by the host AI.

## Requirements
1. The overview report must contain the decision layer only.
2. The full report must contain both decision and evidence layers.
3. The handout must be printable, short, and question-first.
4. The evidence table must show what would change the reading, not just what was noticed.
5. Readiness gates must block final output when the required content is missing or placeholder-only.
6. The report must preserve the distinction between score, rationale, uncertainty, and recommendation.

## UX And Content Rules
- Use concise plain language.
- Lead with the verdict / recommendation, then show evidence.
- Keep the handout action-oriented and meeting-friendly.
- Keep the evidence table neutral and testable.

## Acceptance Criteria
- Overview and full reports are clearly different artifacts.
- The handout can be printed and used without reading the whole report.
- Placeholder sections do not ship in final output.
- The report always shows the source of the judgment, not just the judgment itself.
- The report can be generated from normalized audit data without the host AI inventing structure.

## Success Metrics
- Fewer regeneration loops.
- Fewer missing-field failures.
- Higher completion rate for reports sent to other people.
- Better reader understanding of next action and evidence gaps.

## Dependencies
- Stable canonical audit payload.
- Report readiness logic.
- Markdown / PDF export path.
- Human-loop and advanced-audit outputs.

