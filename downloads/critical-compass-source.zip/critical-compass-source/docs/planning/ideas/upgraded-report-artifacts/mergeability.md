# Mergeability: Upgraded Report Artifacts

## Borrowed Inspirations And Decisions

| Inspiration | Type | Borrow | Decision |
|---|---|---:|---|
| Kialo | Proprietary SaaS | Progressive disclosure and readable argument flow | Adapt locally |
| Rationale | Proprietary SaaS | Argument-summary readability and decision support | Adapt locally |
| Argdown | Open source | Exportable structure for reasoning artifacts | Adopt directly for format ideas, rebuild locally |
| FactRank | Open source / research method | "Worth checking" versus "false" distinction | Adapt locally |
| Workshop handouts / meeting checklists | Method | Printable decision aid shape | Adopt directly |

## Local Mergeability Assessment
- Open-source or proprietary: mixed.
- License risk: low if we rebuild the layout and do not embed third-party assets.
- Local/self-hostable status: report artifacts are fully local-first.
- Maturity and maintenance burden: low to medium; template versioning is the main burden.
- Dependency footprint: moderate if the artifact set is split into multiple exports.
- Security and trust risks: placeholder leakage, stale data, and mislabeling of evidence.
- Recommendation: build locally rather than integrate external report SaaS.

## Adopt / Adapt / Reject Summary
- Adopt directly: printable handout concept, evidence-first table, versioned artifacts.
- Adapt and rebuild locally: argument-map style, check-worthy framing, progressive disclosure.
- Reject: external report platforms that add trust or licensing risk without unique value.

