# UX Notes: Upgraded Report Artifacts

## Reading Order
The report should answer four questions in order:

1. What is the judgment?
2. Why should I trust it?
3. What should I do next?
4. What would I need to test before acting?

## Wording Rules
- Keep the handout short and reusable in a conversation.
- Make the evidence table concrete and testable.
- Do not bury the recommendation under methodology.
- Do not recapitulate the whole audit on every page.

## Failure Modes To Avoid
- Overlong report sections that nobody finishes.
- Generic questions that could belong to any text.
- A handout that sounds like a summary instead of a prompt.
- Evidence tables that imply certainty where the audit only supports a bounded claim.

