# Risks And Trust: Upgraded Report Artifacts

## Risks
- Placeholder text slips into a delivered artifact.
- The handout becomes too abstract to use in a meeting.
- The report recaps analysis instead of enabling a decision.
- Long raw text overwhelms the useful summary.

## Mitigations
- Block final output when readiness gates fail.
- Keep the handout limited to a small question set.
- Separate decision layer and evidence layer.
- Move raw text to a sidecar when it exceeds the cap.

## Trust Boundaries
- The report should never invent evidence.
- The report should never hide uncertainty behind polish.
- The report should show where the judgment came from.

