# Risks And Trust: Human-Loop Interruption Triggers

## Key Risks
- The system interrupts at the wrong time and creates annoyance rather than insight.
- Comfortable-answer detection becomes a vague vibe check.
- Prompts could push users toward defensiveness if phrased badly.
- A pause might be mistaken for failure instead of reflection.

## Mitigations
- Keep triggers sparse and risk-based.
- Use neutral language and explain why the question matters.
- Preserve the answer state without forcing a restart.
- Log pause reasons so the thresholds can be tuned.

## Trust Boundary
Interruption triggers should improve judgment, not dominate it. They must stay visible, legible, and editable by the user.

