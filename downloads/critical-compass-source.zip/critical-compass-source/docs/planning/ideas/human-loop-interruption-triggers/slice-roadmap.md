# Slice Roadmap: Human-Loop Interruption Triggers

## Slice 1
- Add three interrupt prompts: harmed stakeholders, contested assumptions, comfortable-answer detection.
- Pause only in guided mode.

## Slice 2
- Persist interruption answers and hand them to later audit stages.
- Add a clear “why I am asking” explanation for each prompt.

## Slice 3
- Add risk-based threshold tuning and pattern tracking.
- Expand prompts only after measuring false pauses.

