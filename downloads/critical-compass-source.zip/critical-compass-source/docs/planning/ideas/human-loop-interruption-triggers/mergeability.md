# Mergeability: Human-Loop Interruption Triggers

## Local Mergeability Assessment
| Inspiration | Open / Proprietary | License Risk | Local / Self-Hostable | Maturity / Maintenance | Dependency Footprint | Security / Trust Risk | Recommendation |
|---|---|---|---|---|---|---|---|
| Ethics Check MCP | Open-source | Low | Yes | Emerging | Low | Low to medium - depends on prompt design | Adapt locally |
| Pre-mortem methods | Open concept | Low | Yes | Mature | Low | Low | Adopt as method |
| Socratic questioning | Open concept | Low | Yes | Mature | Low | Low | Adopt as method |
| Red-team / challenge prompts | Open concept | Low | Yes | Mature | Low | Medium - can become adversarial if overused | Adapt locally |

## Build / Integrate / Reject
- Build the trigger logic locally.
- Integrate the question patterns as prompt scaffolds.
- Reject trigger designs that are always-on or emotionally manipulative.

