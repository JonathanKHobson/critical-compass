# UX Notes: Human-Loop Interruption Triggers

## Reader Experience
The prompt should feel like a useful pause, not a stop sign. The user should understand why the system is asking now, not ten minutes later.

## Required Prompt Themes
- Who could be harmed if this framing is wrong?
- What assumption is being treated as settled?
- What answer feels comfortable here, and why might that be a problem?

## UX Risks
- Too many interruptions will train users to ignore them.
- Too much explanation will dilute the pause.
- If the prompt sounds accusatory, users will defend instead of reflect.

## Belongs As
- Elicitation: yes.
- Server instruction: yes.
- Tool: yes, as trigger logic.
- Report artifact: maybe, but only as a concise note that a pause happened.

