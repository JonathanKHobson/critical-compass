# Phase Roadmap: Human-Loop Interruption Triggers

## Phase 1: Trigger Definitions
- Define trigger classes for harmed stakeholders, contested assumptions, and comfort-zone language.
- Connect each trigger to a bounded set of follow-up prompts.

## Phase 2: Guided Interruptions
- Add pause logic into the guided human-loop flow.
- Preserve answers in the state object for later stages.
- Keep the questions short enough to answer in one pass.

## Phase 3: Calibration
- Review which triggers fire too often.
- Tighten the trigger language and thresholds.
- Add audit logging for pause frequency and recovery.

