# Human-Loop Interruption Triggers

## Problem / Opportunity
The current human loop asks useful questions, but it needs stronger interruption logic so the system knows when to pause, not just when to continue. The trigger layer should surface harmed stakeholders, contested assumptions, and comfortable-answer signals that suggest the audit is moving too fast.

## Why This Matters For Critical Compass
Critical Compass is supposed to improve judgment, not just output volume. Better interruption triggers protect against blind spots, confirmation loops, and “this feels right” answers that do not survive scrutiny.

## Users And Jobs To Be Done
- Host AI: decide when to pause and ask.
- Audit author: confront the easiest-to-miss assumptions.
- Stakeholder reviewer: see whether the audit considered harmed or excluded people.

## Borrowed Ideas
- Ethics Check MCP-style interruption prompts: adapt.
- Pre-mortem and red-team methods: adopt.
- Socratic questioning: adopt.
- Comfort-zone / confirmation-bias prompts: adapt.

## Adopt / Adapt / Reject
- Adopt: ask about harmed stakeholders and contested assumptions early.
- Adapt: turn interruption prompts into structured, bounded questions.
- Reject: vague “are you sure?” nags that do not change the workflow.

## Belonging
- Primary form: elicitation + server instruction.
- Secondary form: prompt resource and report-readiness gate.

## Smallest Shippable Slice
Add a small set of risk-triggered prompts that can pause guided audits when the text affects harmed stakeholders, hides contested assumptions, or looks too comfortably resolved.

