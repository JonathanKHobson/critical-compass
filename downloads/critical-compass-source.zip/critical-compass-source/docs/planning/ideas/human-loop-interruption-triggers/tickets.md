# Tickets: Human-Loop Interruption Triggers

## Prioritized Tickets
1. P0 - Define trigger conditions for harmed stakeholders, contested assumptions, and comfortable-answer detection.
2. P0 - Add bounded interruption prompts to the human-loop contract.
3. P0 - Preserve trigger answers in human_loop_state.
4. P1 - Wire trigger pauses into guided audit flow.
5. P1 - Add explicit bypass handling for noninteractive smoke tests.
6. P2 - Calibrate false-pause rate and improve prompt wording.

## Status Snapshot - 2026-04-15

- Tickets 1, 2, 3, 4, and 5: Done in human-loop contracts, guided/minimal/silent mode handling, interruption-trigger tests, and noninteractive smoke behavior.
- Ticket 6: Evaluation backlog - broader false-pause rate measurement remains useful but is not required for the current implementation slice.
- HLI-07: Done - saved blind-spot reminders now use existing pattern storage with explicit consent and sensitive-profiling safeguards.
- HLI-08: Done - versioned scaffold resources now include host-facing examples for asking consent, saving reminders, and retrieving them without turning them into a user profile.
