# Evaluation: Human-Loop Interruption Triggers

## What Success Looks Like
- The system pauses when it should and stays quiet when it should.
- The prompts produce more thoughtful answers, not longer ones.
- Users can explain why the interruption happened.

## Evaluation Methods
- Human review of pause usefulness.
- False-pause and missed-pause tracking.
- Prompt clarity checks on harmed-stakeholder and contested-assumption wording.
- Smoke tests with noninteractive bypass.

## Metrics
- Pause precision.
- Pause recovery rate.
- User-rated usefulness of the interruption.
- Reduction in later correction of overlooked stakeholders.

