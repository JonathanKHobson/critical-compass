# PRD: Human-Loop Interruption Triggers

## Goal
Pause the audit when the system is moving too fast, too confidently, or too neatly for the evidence in front of it.

## User Segments
- Host AI deciding whether to interrupt.
- User who needs to reflect before the audit continues.
- Reviewer who wants to know whether the system asked the hard questions.

## Functional Requirements
- Detect situations where an interruption is warranted.
- Ask about harmed stakeholders, contested assumptions, and comfortable-answer detection.
- Keep prompts structured and non-accusatory.
- Preserve answer state for later stages.
- Allow a clean bypass when a noninteractive smoke test is explicitly intended.

## Non-Goals
- No constant interruption on every audit.
- No emotional language that pressures the user.
- No hidden autonomous escalation outside the human-loop contract.

## Acceptance Criteria
- The trigger logic can justify why it paused.
- The prompts are short, specific, and tied to audit risk.
- The host AI can continue without losing the user’s answers.

## Success Metrics
- Better user reflection quality.
- Fewer rushed conclusions.
- Higher completion of the reflection stage when an interruption is triggered.

