# MCP Capability Registry

Status: active
Date: 2026-04-15

The machine-readable registry is `support/registry/mcp_capabilities.json`.

It records local and external capability candidates with:

- integration mode
- current status
- trust and license notes
- maintenance burden
- epistemic and plurality fit
- fallback mode
- local study-library evidence when available

The local MCP study library at `/Volumes/Kyle SSD II/ExternalApplications/mcp-study-library` is used as evidence for registry seeding. It is not a runtime dependency.

Pattern-level lessons from the same study library live separately in `support/registry/mcp_study_lessons.json`. Capability records answer "what could Critical Compass use"; study lessons answer "what can Critical Compass learn without merging or calling it."

## Required Fields

Each entry must include:

- `mcp_id`
- `name`
- `source_url`
- `summary`
- `primary_domain`
- `capabilities`
- `integration_mode`
- `strategic_value`
- `architecture_fit`
- `licensing_notes`
- `trust_risk`
- `maintenance_burden`
- `epistemic_fit`
- `plurality_fit`
- `fallback_mode`
- `current_status`
- `owner`
- `notes`

Optional local evidence fields:

- `local_source_path`
- `source_revision`
- `source_type`
- `local_inventory_status`

## Registry Rule

An entry is not permission to call an MCP. It is a planning record. Runtime use still requires trust review, explicit user consent when data leaves the machine, and provenance labeling.
