# Mergeability Matrix

| Idea | Phase | Primary Surface | Local Mergeability | Dependency Risk | First Slice |
|---|---:|---|---|---|---|
| argument-map-output | 1 | Tool output, Markdown, report artifact | High | Low | Add JSON shape and Markdown export to audit outputs. |
| checkworthy-claims-extraction | 1 | Tool output, report artifact | High | Low | Extract factual claims and rank verification priority. |
| scaffold-registry-canonical-examples | 1 | Resources, server instructions | High | Low | Add canonical payload and workflow examples. |
| upgraded-report-artifacts | 1 | Report artifact, readiness gates | High | Medium | Add Evidence Needed Next and Questions handout planning hooks. |
| advanced-audit-dissent-ledger | 2 | Advanced audit output | High | Low | Add dissent fields to agent scaffolds and synthesis. |
| reasoning-trap-detectors | 2 | Prompt/resource plus output | Medium | Low | Add small detector set with conservative labels. |
| human-loop-interruption-triggers | 2 | Elicitation flow | Medium | Low | Add three interruption prompt families. |
| structured-elicitation-report-readiness | 2 | Elicitation flow, report gate | Medium | Low | Ask missing-context and report-critical follow-ups. |
| server-instructions-host-ai-onboarding | 3 | Server instruction/resource | High | Low | Add model-agnostic workflow rules. |
| prompts-resources-layer | 3 | Resources/prompts | High | Low | Add workflow prompt registry. |
| tool-source-trust-preflight | 3 | Tool/resource | Medium | Medium | Add rubric before any external source/tool suggestion. |
| comparable-tools-knowledge-layer | 3 | Resource/KB | High | Low | Add curated local comparable-tool notes. |
| optional-mcp-app-ui | 4 | Local artifact viewer, optional MCP App | Medium | Medium | Generate read-only HTML from report manifests; defer comparison and annotations. |
| optional-external-factcheck-lane | 4 | Scaffold-first MCP tool, local retrieval, direct publisher harvest, optional provider artifact | Medium | Medium | `factcheck_lookup` defaults to guided research with epistemic framing; local retrieval is opt-in when indexed; direct publisher harvest is consent-gated; provider-backed retrieval is explicit and experimental. |

## Parallelization Guidance

- Phase 1 can be split into `argument_map`, `checkworthy_claims`, and `scaffold/report-readiness` workstreams.
- Phase 2 should keep human-loop and dissent-ledger changes coordinated because both affect advanced-audit timing.
- Phase 3 trust preflight should be reviewed before any optional integrations are enabled.
- Optional fact-check lookup is mergeable only because it is explicit, consent-gated, factual-claim-only, and separate from core audit scoring.
