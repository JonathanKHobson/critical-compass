# Critical Compass Beta 0.9 Stabilization And Publish Inventory

Date: 2026-04-28

## Release Position

- Latest public GitHub release before this lane: `v0.1.0-beta.7`.
- Local train since beta.7: beta.8.x teaching, report, schema, human-loop, corpus-grounding, and planning-hygiene stabilization.
- Target public release: `v0.1.0-beta.9`.
- Release stance: stability release, not feature expansion.

Beta.8 is intentionally skipped as a public tag. It was the local stabilization train that made beta.9 worth publishing.

## Change Inventory Since Beta.7

Teaching layer:

- Reliable `Plain-Language Read` and `Before Using This Text` output requirements.
- Follow-up activity contract for solo and group activities in full/advanced reports.
- Activity suggestions are local Critical Compass guidance; no runtime external archive or activity database dependency.

Report and PDF reliability:

- Report preflight cards with complete/missing sections, top fixes, accepted aliases, and paste-ready resubmission guidance.
- `report_depth="readiness_card"` for compact summary output.
- WeasyPrint discovery hardened with PyMuPDF fallback and renderer diagnostics.
- Canonical `follow_up_activity.solo_activity` and `follow_up_activity.group_activity` validation.
- Reader-facing report cleanup for placeholder strings, raw enums, empty sections, internal notes, and low-score action contradictions.

Schema and host-AI workflow:

- `validate_report_payload` dry-run path, including `schema_only=true`.
- `report_ready_payload` from advanced synthesis.
- Stable schema hash, field constraints, CIS bands, natural aliases, and clearer diagnostics.
- `cis_score`, `cis_label`, `bias_rows`, and `bias` normalize into canonical report fields.
- `PAUSE_REQUIRED` and Claude `Ask_User_Input_V0` / conversational UI guidance for human-loop gates.

Persistence and comparison:

- Optional `activity_outcome` capture inside `save_audit_result.result_payload`.
- Saved-result comparison can use saved IDs or already-audited inline payloads.
- Framing-drift guidance stays inside `compare_audit_results`; no new drift-monitor tool.

Planning and package hygiene:

- Runtime/public surfaces no longer present Critical Compass as an external MCP orchestrator.
- Dev planning registries remain planning/archive material, not product guidance.
- Runtime MCPB/plugin bundles exclude dev-only planning registries.

Corpus grounding and calibration:

- Advanced prompts ask for KB IDs when naming biases/lenses/frameworks.
- Low KB grounding is host-facing QA, not reader-facing PDF text.
- Score stress testing exists as measurement before future scoring retuning.

## Personas Served

- Nonprofit communicator: wants public statements, policy copy, and stakeholder language to avoid overclaiming or missing affected voices.
- Grant or advocacy writer: wants claims, impact language, and evidence texture to hold up under funder or public scrutiny.
- Educator or research reader: wants study claims, methods, assumptions, and replication limits made easier to question.
- AI-assisted writer: wants a draft strengthened without flattening the original purpose or turning every issue into a generic fact-check.
- Host AI/operator: needs clear routing, canonical schemas, native question UI gates, KB lookup guidance, and report validation before rendering.

## Human User Journey

1. Discover the public page.
2. Choose one install path: plugin zip, MCPB/Desktop Extension, source zip, or skill fallback.
3. Open `get_started` or use a first prompt.
4. Pick a path: quick scan, standard audit, or advanced audit.
5. Answer native UI questions when the host supports them.
6. Review the audit decision: Trust, Revise, Verify, or Reframe.
7. Validate and render a report when the audit needs a durable artifact.
8. Save, compare, or revisit only when useful.

Success means a first-time user can complete one useful audit without seeing planning language, schema churn, blank report sections, or install ambiguity.

## Host AI Journey

1. Start with `get_started` for first-session onboarding or `critical_compass_overview` for workflow lookup.
2. Honor `PAUSE_REQUIRED` immediately and ask human-loop questions through native question UI when available.
3. Choose the smallest correct audit path: `quick_scan`, `audit_text`, or advanced staged tools.
4. Use KB tools when naming biases, lenses, frameworks, or reasoning patterns.
5. Save progress for long or advanced audits.
6. Use `report_ready_payload` from synthesis instead of hand-assembling from scratch.
7. Run `validate_report_payload`; use `schema_only=true` when the schema is unclear.
8. Call `generate_audit_report` only after validation passes or the user explicitly approves draft placeholders.

## Beta.9 Publish Gate

Required checks before publish:

- `python3 -m pytest -q`
- `python3 scripts/validate_mcp_surface_sync.py`
- `python3 scripts/validate_audit_report_renderer.py`
- `python3 scripts/validate_research_audit_coverage.py`
- `python3 scripts/run_cis_score_stress.py`
- Package clean scans for private reports, cache/state, dev-only registries, and public-surface drift.
- Journey smoke checks for `get_started`, `audit_text`, advanced synthesis/report payload, schema-only validation, report generation, and saved-result comparison.

Publish only if remaining issues are minor documentation drift or clearly deferred polish.

Public website drift gate:

- Rebuild the share kits from `scripts/build_shareable_release.py` before touching the live GitHub Pages checkout.
- For website-only corrections that do not change downloadable artifacts, `python3 scripts/build_shareable_release.py --pages-only` is the narrow rebuild path; it refreshes the local GitHub Pages/manual-share HTML and share-kit zips from existing release artifacts.
- Confirm `dist/share/github-pages/index.html`, `dist/share/manual-share/START_HERE.html`, and the live Pages `index.html` all keep the same landing shell: separate `About` and `FAQ` tabs, no combined `About & FAQ` tab, beta.9 release links/checksums, and the current report flow wording (`report_ready_payload` -> `validate_report_payload` -> `generate_audit_report`).
- If the generated share kit would regress the live page, stop and fix the generator/tests first. Do not overwrite the live page with a stale generated artifact.

## Explicit Deferrals

- No new scoring model or silent scoring-weight retune.
- No standalone practice activity tool.
- No external MCP orchestration.
- No raw-text two-draft framing-drift tool.
- No package or public-page release until built artifacts and live links are verified.
