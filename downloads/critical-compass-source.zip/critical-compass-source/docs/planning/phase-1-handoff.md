# Phase 1 Planning Handoff

## What Was Created

- Master PRD, master roadmap, adopt/adapt/reject matrix, mergeability matrix, and parallel file-ownership rules.
- Agent charter for product, UX/UI, UX research, and trust/security workstreams.
- Evaluation strategy and three ADRs locking scope, local-first integrations, and surface-selection rules.
- Thirteen idea planning packs, each with overview, PRD, phase roadmap, slice roadmap, tickets, UX notes, mergeability, risks/trust, and evaluation docs.
- Folder indexes for PRD, phase roadmap, slice roadmap, and ticket navigation.

## Top 10 Prioritized Tickets

| Rank | Ticket | Idea | Why First |
|---:|---|---|---|
| 1 | Define canonical `argument_map` schema and fixture shape. | argument-map-output | Unlocks structured reasoning artifacts and report sections. |
| 2 | Add Markdown and `.argdown` export mapping for `argument_map`. | argument-map-output | Makes reasoning portable without a UI dependency. |
| 3 | Define claim-type classifier: factual, interpretive, causal, normative, policy. | checkworthy-claims-extraction | Prevents "worth checking" from becoming "false." |
| 4 | Add factual-claim verification-priority ranking to audit outputs. | checkworthy-claims-extraction | Gives users a practical next-evidence list. |
| 5 | Create canonical scaffold examples with report-ready payloads. | scaffold-registry-canonical-examples | Reduces host-AI field mismatch and premature PDF calls. |
| 6 | Add report readiness checks for argument maps and check-worthy claims. | upgraded-report-artifacts | Prevents blank or placeholder report sections. |
| 7 | Add Questions to Bring to the Text handout and Evidence Needed Next table to report planning. | upgraded-report-artifacts | Converts audit findings into meeting-ready artifacts. |
| 8 | Add advanced-audit dissent ledger contract to agent outputs. | advanced-audit-dissent-ledger | Preserves disagreement and confidence before synthesis. |
| 9 | Add human-loop interruption prompts for harmed stakeholders, contested assumptions, and comfortable answers. | human-loop-interruption-triggers | Improves reflection without heavy dependencies. |
| 10 | Add model-agnostic host-AI workflow instructions. | server-instructions-host-ai-onboarding | Makes tool use reliable across Claude, Codex, and other hosts. |

## Recommended First Implementation Slice

Implement `argument_map`, `checkworthy_claims`, scaffold examples, and report-readiness additions together. This creates one coherent value loop:

- audits expose clearer reasoning structure;
- reports have better stakeholder artifacts;
- host AIs receive canonical examples before calling report tools;
- no external integrations or MCP App UI are required.

## Unresolved Risks And Assumptions

- It is still undecided whether `checkworthy_claims` should appear by default in `audit_text` or behind a mode flag.
- `.argdown` should initially be an export artifact, not a renderer dependency.
- Trust preflight should start as a rubric/resource before becoming a public tool.
- Fact-check support is implemented as scaffold-first `factcheck_lookup`; local ClaimReview retrieval is opt-in when indexed, direct publisher harvest is consent-gated, and broader research integrations remain later-phase.
- The MCP App UI is useful, but it should wait until backend artifacts are stable.

## Best Local Rebuild Candidates

- Argument mapping patterns from Kialo, Rationale, and Argdown.
- Check-worthiness language from FactRank and ClaimBuster-style systems.
- Dissent/provenance patterns from ThoughtProof-style epistemic consensus.
- Prompt/workflow contracts from prompt-management MCPs.
- Reasoning-trap and verification-gate patterns from Verifiable Thinking and similar MCPs.
- Source/tool trust checks inspired by MCP Guard and MCP Shield.

## Optional Integrations To Defer

- Google Fact Check Tools or similar fact-check APIs.
- OpenFactCheck-style factuality evaluators.
- Elicit, Scite, Consensus, or other research evidence products.
- Idea Reality MCP for proposal/product reality checks.
- MCP App UI for interactive map/report exploration.
