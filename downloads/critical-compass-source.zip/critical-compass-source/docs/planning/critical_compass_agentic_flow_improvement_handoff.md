# Critical Compass Agentic Flow Improvement Handoff

_Created: 2026-04-24_

## Purpose

This handoff captures low-hanging, high-impact improvements Critical Compass can borrow from Prompt Compass Agent Mode testing without redesigning Critical Compass or expanding it into a generic multi-agent platform.

The goal is to make the existing `advanced_audit(mode="agent")` flow cleaner, more exposed, more scaffolded, and more reliable for both users and host AIs. Keep the current Critical Compass strengths intact: human-loop gates, four-perspective analysis, dissent preservation, CIS calibration, source/tool trust boundaries, report readiness, and local-first behavior.

## Source Review

Reviewed local Critical Compass surfaces:

- `server.py`: `advanced_audit_payload`, `advanced_agent_design_protocol`, `advanced_agent_execution_protocol`, `audit_stage_scaffold`, `human_loop_host_action`, `list_agent_personas_payload`
- `README.md`: human-loop, advanced audit, persona, report, and MCP composition sections
- `support/resources/scaffolds/v1/server-instructions.md`
- `support/resources/scaffolds/v1/tool-trigger-matrix.md`
- `support/resources/scaffolds/v1/host-workflow-contract.md`
- `docs/agents/agent-charter.md`
- `docs/agents/mcp-orchestrator-role.md`
- `docs/evals/evaluation-strategy.md`
- `evaluations/critical-compass-arxiv-stress-test-2026-04-14.md`
- `tests/test_human_loop_gates.py`
- `tests/test_release_surface_upgrades.py`

Prompt Compass lessons applied:

- Route before browse or scaffold exposure.
- Treat pause gates as blocking, not advisory.
- Use native question UI first when available.
- Make agent mode explicit opt-in and capability-aware.
- Distinguish real host subagents from sequential simulated fallback.
- Use machine-readable contracts as source of truth, with prose rendered from them.
- Use artifact-only handoff and compact progress state instead of full transcript carryover.
- Fail closed with named recovery actions instead of vague host instructions.
- Keep non-technical users out of internal labels, schemas, and mode jargon unless they ask for it.

## Keep These Strengths

Do not regress these. They are already valuable and aligned with Prompt Compass findings.

- `human_loop_host_action` already has strong `must_pause`, native UI, fallback rendering, and current-block-only directives.
- `advanced_audit(mode="agent")` already exposes a staged flow: agent definition, independent analysis, tension map, debate, synthesis, and optional mitigation rewrite.
- `list_agent_personas` already frames personas as analytical perspectives, not identity impersonation.
- `audit_stage_scaffold` already provides `stage_handoff`, `stage_brief`, `required_inputs`, `recommended_mcp_calls`, `output_schema`, and quality gates.
- Report readiness and PDF generation already block placeholder or incomplete final artifacts.
- External retrieval and MCP composition are explicit, consent-gated, and provenance-aware.
- The ArXiv stress test showed the core idea works; the main pain was orchestration weight, not conceptual weakness.

## Product Posture

Critical Compass Agentic Mode should feel like a disciplined review panel, not an open-ended swarm.

Recommended language:

- User-facing: `Advanced panel review` or `Agentic panel review`
- Host/developer-facing: `advanced_audit agent mode`
- Internal aliases: `agentic`, `multi-perspective`, `panel`, `agent mode`

Avoid implying that real subagents were spawned unless the host actually spawned them. In generic chat or Claude Desktop without native subagents, call it a simulated or sequential panel.

## Non-Goals

- No arbitrary N-agent teams.
- No default web-research agent.
- No automatic external MCP orchestration.
- No server-side multi-model orchestration.
- No broad Critical Compass routing rewrite before the low-hanging reliability layer ships.
- No weakening of human-loop gates, report readiness gates, or source/tool trust boundaries.
- No identity impersonation personas.
- No making CIS a grade or final truth verdict.

## Priority Roadmap

### Phase CCA-1: Agentic Entry Contract And Routing Clarity

**Goal:** make it impossible for host AIs to enter advanced agent mode accidentally or unclearly.

Current issue:

- Critical Compass has strong tool descriptions and a trigger matrix, but no hard entry payload equivalent to Prompt Compass `route_prompt_request`.
- A host AI can still jump into `advanced_audit(mode="agent")`, expose a large scaffold, or browse personas before confirming the user wants a staged panel review.

Recommended implementation:

- Add a small read-only routing surface, preferably `route_critical_request`, or extend `get_started` / `critical_compass_overview` with a route-shaped payload if avoiding a new tool is preferred.
- Return one plain next step:
  - `quick_scan`
  - `audit_text`
  - `advanced_audit`
  - `claim_stress_test`
  - `factcheck_lookup`
  - `prepare_audit_source`
  - `generate_audit_report`
- Return `required_mode`, `required_depth`, `requires_human_loop`, and `agentic_mode_recommended`.
- Require explicit opt-in for agentic mode. Safe phrases: `agentic panel review`, `advanced agent mode`, `multi-perspective panel`, `use analyst agents`, `run the agent audit`.
- Do not trigger agentic mode from generic words like `agent`, `agency`, `council`, `panel`, `committee`, or `stakeholders` unless paired with explicit review-mode intent.

Suggested response fields:

```json
{
  "route_status": "workflow_routed | clarification_required | user_exit",
  "detected_job": "audit_text | advanced_panel_review | claim_stress_test | report_generation | fact_check_scaffold",
  "required_next_tool": "advanced_audit",
  "required_mode": "agent",
  "required_depth": "standard",
  "agentic_mode_recommended": true,
  "agentic_mode_requires_explicit_opt_in": true,
  "plain_user_summary": "This looks like a high-stakes text review. I can run a normal audit or a deeper panel review.",
  "questions_for_user": []
}
```

Acceptance criteria:

- "Use Critical Compass on this text" does not immediately expose agent scaffolds.
- "Run an advanced panel review" routes to `advanced_audit(mode="agent")`.
- A civic sentence mentioning "city council" does not trigger agentic mode.
- New-user routing uses plain labels, not internal tool names, unless `audience="host_ai"`.

Primary files:

- `server.py`
- `support/resources/scaffolds/v1/tool-trigger-matrix.md`
- `support/resources/scaffolds/v1/server-instructions.md`
- `tests/test_release_surface_upgrades.py`

### Phase CCA-2: Host Capability Adapter And Fallback Honesty

**Goal:** make Critical Compass explicit about whether the host should spawn real subagents or run a sequential simulated panel.

Current issue:

- `advanced_audit(mode="agent")` says the host AI must define and execute agents, but it does not distinguish Claude Code/Codex native subagents from a single-chat sequential fallback.
- This can create user confusion: "agents" may sound like actual spawned workers when the host is only simulating roles.

Recommended implementation:

- Add optional `host_capability_profile` to `advanced_audit` and stage tools.
- Add `agent_execution_adapter` to agent-mode payloads.
- Always select one adapter:
  - `claude_native_subagents`
  - `codex_explicit_subagents`
  - `sequential_labeled_fallback`
  - `scaffold_only`
- Sequential fallback is the guaranteed safe path.
- Require a disclosure in fallback mode.

Suggested `host_capability_profile` fields:

```json
{
  "host_family": "claude_desktop | claude_code | codex | generic_chat | unknown",
  "native_question_ui": true,
  "native_subagents": false,
  "explicit_subagent_spawn": false,
  "can_write_progress_log": false,
  "can_call_external_tools": false
}
```

Suggested adapter payload:

```json
{
  "agent_execution_adapter": {
    "selected_adapter": "sequential_labeled_fallback",
    "fallback_disclosure_required": true,
    "fallback_disclosure_text": "Native subagents are unavailable here, so I will run the analyst panel sequentially in this chat with labeled sections.",
    "role_label_format": "## [AGENT_NAME]",
    "output_shape_matches_native": true,
    "user_message": "I can still run the panel review, but it will be simulated in one thread."
  }
}
```

Acceptance criteria:

- Generic chat receives sequential fallback instructions, not native-subagent language.
- Codex/Claude Code can see explicit spawn guidance if declared.
- User-facing output never claims real subagents were spawned in fallback mode.
- Committee/panel approval never bypasses host sandbox, tool approval, or MCP trust policy.

Primary files:

- `server.py`
- `docs/agents/agent-charter.md`
- `support/resources/scaffolds/v1/server-instructions.md`
- `tests/test_human_loop_gates.py`
- Add `tests/test_agentic_host_adapter.py`

### Phase CCA-3: Schema-First Role Contracts

**Goal:** make advanced agent roles machine-readable before they become prose personas.

Current issue:

- Critical Compass already has rich persona guidance, but role execution is still mostly prose plus output schemas.
- Prompt Compass testing showed that prose-only roles drift: agents overlap, skip stop conditions, or ask user questions directly.

Recommended implementation:

- Add canonical `role_contracts` to `advanced_audit(mode="agent")`.
- Keep the current four-agent design, but represent it as structured contracts before human-readable summaries.
- Roles may still be dynamically named and tuned to the text, but they must map to stable epistemic archetype buckets.

Suggested role contract schema:

```json
{
  "role_id": "agent_1",
  "role_type": "evidence_argument",
  "display_name": "The Skeptic",
  "purpose": "Reconstruct claims, warrants, objections, and inference jumps before accepting the conclusion.",
  "inputs": ["subject_text", "text_type", "candidate_model_pool"],
  "allowed_tools": ["lookup_bias", "search_knowledge_base", "challenge_claim", "get_framework", "get_reasoning_flow"],
  "forbidden_tools": ["generate_audit_report", "save_blind_spot_reminder", "factcheck_lookup_provider_backed"],
  "expected_artifact_schema": {
    "required": ["agent_id", "top_finding", "bias_findings", "challenged_claim", "cis_dimension_evidence", "blind_spot_underweighted"]
  },
  "stop_condition": "Stop after one independent analysis artifact is complete.",
  "max_turns": 3,
  "max_tool_calls": 5,
  "permission_profile": "read_only",
  "handoff_target": "tension_map",
  "asks_user_directly": false
}
```

Acceptance criteria:

- `advanced_audit(mode="agent")` returns `role_contracts`.
- Every role has `asks_user_directly=false`.
- Every role has allowed and forbidden tools.
- Every role has an expected artifact schema and stop condition.
- Dynamic persona cards render from role contracts, not the other way around.

Primary files:

- `server.py`
- `docs/agents/agent-charter.md`
- Add `docs/agents/advanced-audit-role-contracts.md` or equivalent.
- `tests/test_release_surface_upgrades.py`
- Add `tests/test_agentic_role_contracts.py`

### Phase CCA-4: Plan Review Gate For Agentic Mode

**Goal:** add one explicit approval checkpoint before the panel runs.

Current issue:

- Human-loop gates protect onboarding, judgment, and reflection, but agent-mode execution itself can still feel like a huge scaffold drop.
- Prompt Compass testing showed users trust agent mode more when they see the plan and approve it before execution.

Recommended implementation:

- When `advanced_audit(mode="agent")` is requested and not already approved, return `stage_agentic_plan_review`.
- Include the panel roles, adapter/fallback mode, expected stages, artifact budgets, and one plain consent question.
- Only after approval should the host execute stage tools.
- If adding confirmation tokens is too much for the first slice, start with `agentic_approval_required=true` and `agentic_plan_hash`; add tokens in a follow-up.

Suggested fields:

```json
{
  "agentic_stage": "stage_agentic_plan_review",
  "agentic_run_id": "uuid",
  "agentic_plan_hash": "sha256",
  "agentic_approval_required": true,
  "agentic_confirmation_token": "opaque-token-if-implemented",
  "token_bound_to": ["subject_summary", "role_contracts", "stage_plan", "host_adapter", "tool_allowlists"],
  "plain_user_summary": "I will run a four-perspective panel: evidence, systems, uncertainty, and missing-voice review.",
  "questions_for_user": [
    {
      "id": "agentic_plan_approval",
      "plain_question": "Do you want to run this deeper panel review?",
      "choices": ["Yes, run the panel", "No, use a normal audit"]
    }
  ]
}
```

Acceptance criteria:

- Agentic mode does not run stages until plan approval is recorded.
- Declining plan approval routes to `audit_text` or `advanced_audit(mode="ai_selected")`.
- Plan review shows fallback disclosure if native subagents are unavailable.
- Token/hash mismatch, if implemented, fails closed with a named recovery action.

Primary files:

- `server.py`
- `tests/test_human_loop_gates.py`
- Add `tests/test_agentic_plan_review.py`

### Phase CCA-5: Compact Stage Cards And Artifact-Only Handoff

**Goal:** reduce orchestration weight without losing rigor.

Current issue:

- The ArXiv stress test found the full-power flow valuable but heavy. The host AI carries large repeated schemas and context across stages.
- `scaffold_detail="handoff"` already helps, but agent mode can make compactness the default for hosts.

Recommended implementation:

- Make `scaffold_detail="handoff"` the recommended default for host-driven agent stages.
- Add `artifact_budget` to the initial agent-mode payload:
  - max role artifact words
  - max total stage artifacts
  - carry-forward keys
  - audit-only keys
- Add `artifact_only_handoff=true` to each stage.
- Add `do_not_pass_full_transcript=true`.

Suggested `artifact_budget`:

```json
{
  "artifact_only_handoff": true,
  "do_not_pass_full_transcript": true,
  "max_words_per_independent_analysis": 220,
  "max_tensions": 5,
  "max_debate_turns": 3,
  "carry_forward_keys": ["agent_roster", "analyses", "tensions", "debate", "critical_integrity_snapshot"],
  "audit_only_keys": ["raw_tool_outputs", "scratch_notes", "discarded_frameworks"]
}
```

Acceptance criteria:

- Stage payloads make the minimal next action obvious.
- Host can execute stages without rereading the full schema each time.
- Synthesis receives compact artifacts, not full transcripts.
- Report artifacts preserve dissent and traceability even with compact handoff.

Primary files:

- `server.py`
- `docs/evals/evaluation-strategy.md`
- `evaluations/critical-compass-arxiv-stress-test-2026-04-14.md`
- Add fixtures under `support/evals/` if useful.

### Phase CCA-6: Agentic Progress State And Resume Contract

**Goal:** make long panel runs recoverable across context resets or partial completion.

Current issue:

- Critical Compass has `save_audit_progress`, and the ArXiv test proved progress persistence is valuable.
- The agent-mode payload could expose a smaller explicit progress object so hosts know exactly what stage is complete and what to resume next.

Recommended implementation:

- Add `agentic_progress_state` to agent-mode payloads.
- Use stable stage names:
  - `plan_review`
  - `agent_definition`
  - `independent_analysis`
  - `tension_map`
  - `debate`
  - `synthesis`
  - `reflection`
  - `report_ready`
- Record `completed_stage_ids`, `current_stage`, `next_tool`, `required_inputs`, `artifact_refs`, and `resume_allowed`.
- If the host can write files, recommend a local progress log. If not, keep progress state in payload.

Suggested progress state:

```json
{
  "agentic_progress_state": {
    "agentic_run_id": "uuid",
    "current_stage": "independent_analysis",
    "completed_stage_ids": ["plan_review", "agent_definition"],
    "next_tool": "run_independent_audit_analysis",
    "resume_allowed": true,
    "artifact_refs": {
      "agent_roster": "inline-or-saved-progress-id"
    },
    "stop_reason": "awaiting_host_stage_execution"
  }
}
```

Acceptance criteria:

- A host can resume an interrupted advanced agent audit from the next stage.
- Progress state does not require a full transcript.
- `resume_from` remains supported and gains clearer recovery messages for missing prior artifacts.

Primary files:

- `server.py`
- `tests/test_human_loop_gates.py`
- Add `tests/test_agentic_resume_state.py`

### Phase CCA-7: One-Pass Judge / Revision Budget

**Goal:** preserve dissent without letting the panel loop indefinitely.

Current issue:

- Critical Compass has debate and synthesis, but no explicit revision budget like Prompt Compass Agent Mode.
- A host AI may over-iterate after tension mapping or flatten dissent too early.

Recommended implementation:

- Add `revision_budget` to agent-mode payloads.
- Allow at most one synthesis revision pass when the tension map shows `FRAME_COLLAPSE` or `NEEDS_EVIDENCE` could change CIS label/confidence/comparability.
- After one pass, final synthesis must either finalize with caveats or withhold the aggregate as `profile_only`.

Suggested state:

```json
{
  "agentic_revision_state": {
    "revision_requested": false,
    "revision_pass_count": 0,
    "max_revision_passes": 1,
    "revision_trigger": null,
    "stop_condition_reached": false
  }
}
```

Acceptance criteria:

- `FRAME_COLLAPSE` and high-impact `NEEDS_EVIDENCE` tensions affect synthesis explicitly.
- The host cannot run endless debate/revision loops under the Critical Compass contract.
- Dissent ledger remains visible even when final verdict commits.

Primary files:

- `server.py`
- `tests/test_human_loop_gates.py`
- `docs/evals/evaluation-strategy.md`

### Phase CCA-8: Non-Technical Agentic UX Copy

**Goal:** make the agentic path understandable before users see internal scaffolds.

Current issue:

- Critical Compass is strong for power users and host AIs, but ordinary users can still encounter words like scaffold, flow, persona, CIS, and mode too early.
- Prompt Compass testing showed front-door phrasing and one-question gates matter as much as backend quality.

Recommended implementation:

- Add plain-language summaries to agent-mode payloads:
  - what will happen
  - how long/deep it is
  - what the user can skip
  - whether this is a simulated panel
  - what the final artifact will include
- Keep technical fields for `audience="host_ai"`.
- Add informal exit recognition if a future router is added: `nvm`, `never mind`, `stop`, frustration-only inputs.

Suggested user copy:

> I can run this as a deeper panel review. That means four analytical perspectives will read the same text separately, compare disagreements, then produce one final verdict with dissent preserved. This is slower than a normal audit but better for high-stakes or stakeholder-sensitive text.

Acceptance criteria:

- New users can choose normal audit vs panel review without knowing MCP terms.
- Fallback mode is explained in one sentence.
- CIS points are never presented as the whole result; confidence and comparability stay visible.

Primary files:

- `server.py`
- `README.md`
- `support/resources/scaffolds/v1/server-instructions.md`
- `support/resources/scaffolds/v1/tool-trigger-matrix.md`
- `docs/public/why-critical-compass.md`

## Suggested New Or Updated Assets

### Root `AGENTS.md`

Prompt Compass benefited from a narrow project-level `AGENTS.md`. Critical Compass should add one, but keep it scoped to Critical Compass, not general agent philosophy.

Suggested sections:

- Project purpose
- Package boundaries
- Human-loop gate rules
- Agentic panel mode boundaries
- External MCP/source trust boundaries
- Report readiness rules
- Validation commands
- Release/packaging exclusions

Key rules to include:

- Start with Critical Compass native tools.
- Do not treat external retrieval as core audit evidence unless explicitly authorized.
- If `human_loop_host_action.must_pause=true`, stop and use native question UI first.
- Agentic panel review is explicit opt-in.
- Sequential fallback must disclose itself.
- Agent personas are analytical standpoints, not identity claims.
- Report generation happens only after report readiness is complete.

### `docs/agents/advanced-audit-agent-mode.md`

Add a dev-facing guide with:

- entry contract
- host adapter matrix
- role contract schema
- stage state machine
- fallback output skeleton
- progress state example
- test checklist

### `support/resources/scaffolds/v1/agentic-panel-review-contract.md`

Add a host-facing resource that can be exposed through `critical_compass_overview`.

Include:

- when to use panel review
- when not to use it
- normal audit fallback
- native subagent vs sequential fallback disclosure
- stage-by-stage compact skeleton

## Test Plan

Add a small regression suite before broader changes.

Recommended file:

- `tests/test_agentic_flow_contract.py`

Minimum tests:

- `use Critical Compass` with pasted text routes to a normal audit or asks one plain lane question, not immediate agent mode.
- Explicit `advanced panel review` reaches agentic plan review.
- `city council` does not trigger agent mode.
- Generic chat host profile selects sequential fallback and requires disclosure.
- Claude Code/Codex host profiles expose native/explicit subagent instructions only when declared.
- Agent-mode payload includes `role_contracts`, `agent_execution_adapter`, and `agentic_progress_state`.
- Every role contract has `asks_user_directly=false`, allowed tools, forbidden tools, expected artifact schema, and stop condition.
- Plan approval decline routes to normal audit.
- Stage payloads include `artifact_only_handoff=true` and compact carry-forward keys.
- Reflection gate still blocks final report/output when pending.
- Report readiness still blocks placeholder PDFs.

Manual smoke:

- Run a normal `audit_text` guided flow.
- Run `advanced_audit(mode="agent", depth="standard", scaffold_detail="handoff")` with generic chat fallback.
- Run the same with a Codex/Claude Code capability profile.
- Generate a final synthesis with reflection pending and confirm the tool pauses.
- Generate report only after report-ready materials are complete.

Validation commands already referenced in the repo:

```bash
python3 scripts/validate_mcp_surface_sync.py
scripts/validate_research_audit_coverage.py
scripts/run_beta_audit_calibration.py
python3 -m pytest
```

## Implementation Order

1. Add route/entry clarity and safe trigger rules.
2. Add host capability adapter and fallback disclosure.
3. Add role contracts to agent-mode payloads.
4. Add plan review gate.
5. Add compact artifact budgets and progress state.
6. Add revision budget.
7. Update docs/resources and sync tests.

Do not start with new personas, new external research workers, or arbitrary agent counts. The first win is making the current advanced agent flow easier to enter, easier to resume, and harder for host AIs to misuse.

## Main Risks

- **Over-contracting the flow:** Critical Compass currently benefits from flexible persona design. Keep dynamic role naming and framework attachment, but bind it to stable role contracts.
- **Making the user approve too much:** One plan approval is useful; repeated approval prompts will feel like friction.
- **False subagent claims:** The fallback must say simulated/sequential when no real workers were spawned.
- **Schema overload:** Use compact handoff by default and reserve full schemas for `scaffold_detail="full"` or developer mode.
- **CIS over-anchoring:** Any agentic UX work should continue to foreground confidence, comparability, and profile-only states when scoring is not defensible.

## Definition Of Done

This upgrade is ready when:

- A host AI can explain the agentic panel flow in plain language before running it.
- A user can decline panel review and still get a normal audit.
- A generic chat host can run the sequential panel honestly.
- Codex/Claude Code can see exactly how to spawn or simulate roles.
- Stage handoffs are compact enough that the host does not need to carry full transcripts.
- Dissent, confidence, comparability, human-loop gates, and report readiness remain intact.
