# Critical Compass Benchmark-Informed Improvement PRD

## Executive Summary

Critical Compass should remain one focused audit system: bias and assumption auditing, Critical Integrity Snapshot (CIS), human-in-the-loop reflection, saved patterns, and stakeholder-ready reporting. The benchmark set points to three high-value upgrades: make reasoning structure more visible, make report readiness harder to misuse, and make host-AI workflows easier to follow before expensive PDF/report generation.

This planning package covers thirteen improvements. Phase 1 implementation should not add automatic web search or make Critical Compass a marketplace. External tools are inspirations or optional integrations only when they provide a capability that cannot be rebuilt locally at reasonable cost.

## Goals

- Add portable reasoning artifacts: `argument_map`, `checkworthy_claims`, dissent ledger, and report-ready Markdown or PDF sections.
- Preserve uncertainty, provenance, and dissent rather than flattening audits into a single confident verdict.
- Improve host-AI compliance through prompts, resources, server instructions, canonical examples, and readiness contracts.
- Keep source/tool trust explicit, consent-aware, and local-first by default.
- Reduce failed reports and silent placeholder output.

## Non-Goals

- No automatic fact retrieval or web search in core audits by default.
- No marketplace or directory of unrelated MCPs as a core product surface.
- No formal claim that check-worthy means false.
- No MCP App UI in the first implementation slice.
- No replacement of the existing CIS, human loop, or PDF renderer in this planning phase.

## Target Users And Jobs

| User Segment | Job To Be Done | Success Signal |
|---|---|---|
| Organizer or nonprofit reviewer | Decide whether a text is safe to share, revise, or challenge. | Clear next action, missing voice, and questions to bring to a meeting. |
| Writer auditing their own draft | See what is under-supported, over-framed, or missing before publishing. | Useful coaching without shaming or false certainty. |
| Research or policy reviewer | Separate evidence quality from persuasive framing. | Check-worthy factual claims and evidence-needed table are visible. |
| Host AI using the MCP | Call tools in the right order with complete payloads. | No premature report calls; warnings are surfaced before regeneration. |
| Team lead or stakeholder reader | Understand verdict, evidence, dissent, and next steps without being in the audit session. | Report artifacts are readable, complete, and action-oriented. |

## Product Principles

- Local-first unless the user explicitly asks for external retrieval or integration.
- Worth checking is not false.
- Dissent is a trust asset; preserve it in structured form.
- Host-AI scaffolding is product surface, not implementation trivia.
- Reports must communicate behavior-changing findings, not just summarize audits.
- The smallest shippable slice should strengthen existing workflows before adding new surfaces.

## Improvement Inventory

| Idea | Primary Surface | Priority | Recommendation |
|---|---|---:|---|
| Argument map output and Markdown/.argdown export | Tool output, report artifact, export | P0 | Adapt/rebuild locally |
| Check-worthy claims extraction | Tool output, report artifact | P0 | Adapt/rebuild locally |
| Scaffold registry and canonical examples | Resources, prompts, server instructions | P0 | Adapt/rebuild locally |
| Upgraded report artifacts and readiness | Report artifact, gating | P0 | Adapt/rebuild locally |
| Advanced-audit dissent ledger | Advanced audit output, report artifact | P1 | Adapt/rebuild locally |
| Reasoning trap detectors | Prompt/resource plus structured output | P1 | Adapt/rebuild locally |
| Human-loop interruption triggers | Elicitation flow | P1 | Adapt/rebuild locally |
| Structured elicitation for reflection and report readiness | Elicitation flow, report gate | P1 | Adapt/rebuild locally |
| Server instructions for host-AI onboarding | Server instruction/resource | P1 | Adapt/rebuild locally |
| Prompts/resources workflow layer | Resources, prompts | P1 | Adapt/rebuild locally |
| Tool/source trust preflight | Tool/resource, optional gate | P2 | Adapt/rebuild locally first |
| Comparable tools knowledge layer | Resource/KB | P2 | Adapt/rebuild locally |
| Optional MCP App UI / artifact viewer | Local artifact viewer, optional MCP App | P3 | Read-only local v1 implemented; rich UI deferred |

## Current Implementation Status

As of 2026-04-15, the active local-first roadmap is implemented in the MCP as additive outputs, resources, and report sections: `argument_map`, `.argdown` sidecars, `checkworthy_claims`, report-readiness gates, Markdown/PDF artifact sections, a local artifact viewer, host-AI report contracts, dissent ledger, structured human-loop interruption triggers, reasoning-trap checks, source/tool trust preflight, comparable-tools records, and versioned scaffold resources.

The OCR/source-preflight path is now operational on this Mac after installing compatible PyObjC Apple Vision dependencies in the runtime. The 36 Questions PDF smoke path passes from `prepare_audit_source` through audit scaffolds and `generate_audit_report`, including golden page images for Argument Map, Evidence Needed Next, Dissent Ledger, and Reasoning Trap Checks.

The benchmark coverage review found no major missing idea category. Previously surfaced follow-on slices are now implemented locally. The fact-check lane is scaffold-first: `factcheck_lookup` defaults to guided research with epistemic framing, query/source scaffolds, evidence trail templates, and plurality review templates. Local ClaimReview retrieval is available when a local index is configured, and direct publisher harvest is explicit and consent-gated. Provider-backed retrieval remains optional/experimental and outside core audits. Remaining work is reserved for later product decisions: broader research retrieval, multi-report comparison, inline annotation, and MCP composition/orchestration.

## Core Requirements

| ID | Requirement |
|---|---|
| FR-001 | Audits can emit an `argument_map` with central claim, supports, objections, assumptions, missing voices, evidence gaps, and confidence notes. |
| FR-002 | Audits can emit `checkworthy_claims` that rank factual claims for verification priority without implying falsity. |
| FR-003 | Advanced audits can emit a dissent ledger with each agent's top finding, strongest disagreement, confidence, and what would change its mind. |
| FR-004 | Human-loop prompts can interrupt comfortable answers by asking about harmed stakeholders, contested assumptions, and missing context. |
| FR-005 | Report artifacts include overview report, full report, Questions to Bring to the Text handout, Evidence Needed Next table, and readiness gates. |
| FR-006 | Host-AI workflow instructions clearly define what to do before and after calling audit, source-preflight, report, and save tools. |
| FR-007 | Scaffold examples use canonical field names and include report-ready payloads. |
| FR-008 | Source/tool trust preflight defines consent boundaries, trust rubric, prompt injection checks, and tool-poisoning checks. |
| FR-009 | Comparable-tool notes classify each inspiration as adopt directly, adapt/rebuild locally, optional external integration, or reject. |
| FR-010 | Fact-check support can scaffold verification for factual check-worthy claims, preserve no-match/sensitivity/provider-error/disagreement states when retrieval is used, and keep retrieval optional outside core audits. |

## Non-Functional Requirements

- Planning and implementation must preserve existing public tool compatibility unless a later ADR explicitly approves a breaking change.
- New outputs must be deterministic enough for fixture tests.
- New report sections must be optional or readiness-gated so placeholder pages do not ship.
- New prompts must avoid sensitive personal data collection by default.
- New external integrations must be disabled by default and consent-gated.

## Recommended First Slice

Ship a narrow local slice:

1. `argument_map` output.
2. `checkworthy_claims` output.
3. scaffold registry and canonical examples.
4. report-readiness additions for the new sections.

This is the first slice because it improves audit value, report value, and host-AI correctness without external dependencies or UI work.

## Success Metrics

- Report generation attempts blocked for missing content decrease across smoke tests.
- Fixture audits include meaningful argument maps and check-worthy claim lists.
- Host-AI payloads use canonical keys more often than aliases.
- Advanced audits preserve dissent without confusing the final verdict.
- Users can answer "what should I check next?" from the report without asking a follow-up.

## Open Questions

- Whether `.argdown` export should remain an embedded artifact or also be written as a sidecar file.
- Whether check-worthy claim extraction should gain optional evidence-plan fields by default or only for research/policy modes.
- Whether source/tool trust preflight should remain an internal helper/resource or become a richer public workflow surface later.
- Whether saved blind-spot reminders should be user-scoped, organization-scoped, or audit-session-scoped.
