# Adopt / Adapt / Reject Matrix

## Classification Rules

- **Adopt directly**: use the outside tool, library, or protocol largely as-is.
- **Adapt/rebuild locally**: borrow the idea or shape, implement with Critical Compass data and code.
- **Optional external integration**: support later as opt-in, consent-gated capability.
- **Reject**: do not borrow because it conflicts with scope, trust, or local-first goals.

## Matrix

| Inspiration | Classification | Rationale | Critical Compass Use |
|---|---|---|---|
| Kialo / Kialo Edu discussion maps | Adapt/rebuild locally | Useful argument visibility, but product is proprietary and collaboration-oriented. | Argument map structure and plain-language debate visibility. |
| Rationale argument mapping | Adapt/rebuild locally | Strong concept fit; no need to depend on external app. | Claim/support/objection/assumption patterns. |
| Argdown | Adapt/rebuild locally | Open argument-markup concept is useful; export can be generated locally. | Optional `.argdown` text export. |
| FactRank | Adapt/rebuild locally | Excellent distinction between check-worthy and true/false; Dutch-specific system is not core dependency. | Pattern adapted into `checkworthy_claims`; no direct dependency. |
| ClaimBuster-style check-worthiness | Optional external integration | Valuable for factual claim detection, but external retrieval is not default. | Later opt-in benchmark or validator. |
| Google Fact Check Tools MCP | Adapt interface only; reject for core default | Useful adapter shape, but Google-first and API-key-dependent. | Optional experimental provider only; not the scaffold-first MVP. |
| Brave Search API | Optional external integration | Useful as a key-backed search layer over approved fact-check publishers. Not a truth API. | Optional experimental provider only; not the scaffold-first MVP. |
| Approved-publisher search fallback | Optional experimental retrieval | Useful as a bridge around approved publishers, but not robust enough to be the product default. | Implemented as `publisher_site_search`; explicitly named provider only. Direct ClaimReview harvest is implemented separately as `publisher_harvest`. |
| OpenFactCheck | Adapt architecture selectively | Strong factuality framework, but broader than core audit and likely heavier dependency. | Future factuality evaluation architecture; no direct runtime merge. |
| Elicit / Scite / Consensus | Optional external integration | Valuable research retrieval; proprietary/external and not core. | Later opt-in evidence retrieval patterns. |
| Ethics Check MCP | Adapt/rebuild locally | Conceptually aligned with bias/ethics checks; direct adoption would duplicate core product. | Comfortable-answer interruptions and blind-spot reminders. |
| Verifiable Thinking MCP | Adapt/rebuild locally | Reasoning gates are useful; direct dependency unnecessary. | Verification checklist and trap detectors. |
| MCP Thinking / think-mcp | Adapt/rebuild locally | Generic thought tools are too broad; useful as pattern references. | Named reasoning checkpoints inside audits. |
| ThoughtProof-style epistemic consensus | Adapt/rebuild locally | Strong advanced-audit fit; local rebuild preserves provenance and avoids dependency. | Dissent ledger and agent confidence rules. |
| Claude Prompts MCP | Adapt/rebuild locally | Workflow templates are useful; Critical Compass should own its own contracts. | Scaffold registry and canonical examples. |
| MCP Guard / MCP Shield | Adapt/rebuild locally first | Security concepts matter; direct scanners can be optional later. | Tool/source trust rubric and prompt-injection checks. |
| Idea Reality MCP | Optional external integration | Useful for product-idea reality checks but outside text-audit core. | Later opt-in comparable-example/reality-check mode for proposals. |
| Broad MCP marketplace discovery | Reject for core audits | Would turn Critical Compass into a marketplace and dilute focus. | Keep only curated comparable-tool notes. |

## Decision

The default is **adapt/rebuild locally**. The fact-check lane is scaffold-first by default, local ClaimReview retrieval is opt-in when indexed, direct publisher harvest is consent-gated, and optional provider-backed retrieval remains later/experimental. External services remain explicit, consent-gated, and outside core audit execution.
