# Critical Compass Beta.9 P1 Release-Closeout PRD And Roadmap

Date: 2026-04-30

## Summary

P1 feature hardening is complete enough to leave the implementation lane. The remaining beta.9 work is release closeout: verify first-use and report journeys, rebuild clean artifacts, publish or refresh `v0.1.0-beta.9`, and verify the live public/download surfaces match the stabilized local product.

Beta.9 remains a stability release. Do not reopen graph-lite retrieval, hybrid/RRF reranking, MCP gateway/proxy work, scoring retunes, DB migrations, new tools, external MCP orchestration, or broad report information-architecture redesign in this lane.

## PRD

### Problem

Critical Compass has strong local beta.9 behavior, but the public release can drift behind the local stabilization train. The highest remaining risk is release drift: stale packages, stale website copy, wrong download links, unverified install paths, or generated share pages clobbering the current landing design.

### Primary Users

- Human first-time user installing from the public page.
- Host AI/operator routing through `get_started`, `critical_compass_overview`, audit tools, validation, and report generation.
- Maintainer preparing GitHub release, Pages updates, checksums, and package surfaces.

### Success Criteria

- A first-time user can install one supported path and complete one useful audit without schema confusion, blank report sections, planning leaks, or install ambiguity.
- A host AI can complete quick/full/advanced report flows using `report_ready_payload`, `validate_report_payload`, and `generate_audit_report`.
- Public release assets, checksums, CTA links, Pages copy, generated share kits, skill, MCPB, plugin zip, and source zip all agree on beta.9.
- Live verification confirms download URLs and example/report links return successfully.
- Manual install QA status is explicit; do not imply it passed unless actually tested.

### Requirements

- Freeze feature work until beta.9 is published or deliberately paused.
- Keep compact `report_depth="readiness_card"` as the safer first-share default when full PDF is not explicitly requested.
- Preserve website design guardrails: separate `About` and `FAQ` tabs, no stale combined `About & FAQ`, beta.9 links/checksums, and current report-flow wording.
- Rebuild release artifacts only in the publish-prep step, not during further hardening.

## Roadmap

1. `P1.1 Journey Smoke Audit` - Verify `get_started`, guided `audit_text`, advanced synthesis with `report_ready_payload`, `validate_report_payload(schema_only=true)`, report generation, and saved-result comparison.
2. `P1.2 Report Smoke Audit` - Verify quick, full, advanced-dissent, advanced-consensus, and readiness-card report paths with no placeholder/debug/internal reader-facing output.
3. `P1.3 Release-Surface Sync` - Sync README, public page kit, release notes, skill, scaffold quickstart/tool inventory, package manifests, examples, and checksums for beta.9 parity.
4. `P1.4 Clean Staging Build` - Rebuild MCPB, plugin zip, skill zip, source zip, manual share kit, GitHub Pages kit, examples, and checksums; run archive integrity and private-file scans.
5. `P1.5 Publish Beta.9` - Publish or refresh GitHub prerelease `v0.1.0-beta.9`, sync Pages from the generated site via a clean temp clone, and verify live links/checksums/example URLs.

## Test Plan

Required local checks before publish:

- `python3 -m pytest -q`
- `python3 scripts/validate_mcp_surface_sync.py`
- `python3 scripts/validate_audit_report_renderer.py`
- `python3 scripts/validate_research_audit_coverage.py`
- `python3 scripts/run_beta_audit_calibration.py`
- `python3 scripts/run_cis_score_stress.py`
- Package clean scans and archive integrity checks.

Required public checks after publish:

- GitHub release asset URLs.
- GitHub Pages canonical URL.
- CTA/download links.
- Checksums.
- Example/report links.
- Generated pages and live Pages shell design parity.

## Assumptions

- P0 and narrow P1 hardening are complete and green locally.
- P1 remaining work is publish-readiness closeout only.
- Beta.9 is a stability release; beta.8.x remains the local stabilization train.
- Any future scoring improvements are measured and documented before retuning.
- P2 can revisit graph-lite retrieval, hybrid reranking, broader report IA, and MCP gateway ideas after beta.9 is public.
