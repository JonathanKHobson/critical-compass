# Critical Compass Planning Package

This package is the Phase 1 planning layer for benchmark-informed Critical Compass improvements. It is documentation only; it does not implement features.

## Start Here

1. `master-prd.md`
2. `master-roadmap.md`
3. `phase-1-handoff.md`
4. `adopt-adapt-reject-matrix.md`
5. `mergeability-matrix.md`
6. `mcp-composition-strategy.md`
7. `mcp-capability-registry.md`
8. `mcp-integration-decision-matrix.md`
9. `file-ownership-and-parallel-work-rules.md`

Per-idea planning packs live under `ideas/<idea-slug>/`.

Current active Pressure-Test Readiness pack:

- `ideas/atlas-informed-pressure-test-readiness/`

## Default First Implementation Slice

The original Phase 1 implementation slice favored:

1. `argument_map`
2. `checkworthy_claims`
3. scaffold registry and canonical examples
4. report-readiness hardening

This slice is local-first, high-impact, and does not require optional external integrations.

The current next implementation slice should start from `ideas/atlas-informed-pressure-test-readiness/` and prove usefulness for public and nonprofit pressure-test scenarios before adding more infrastructure.

## Current Composition Rule

Use the MCP capability registry before proposing any third-party MCP integration. Critical Compass can merge patterns, wrap local capabilities, orchestrate reviewed external MCPs, or fall back to prompt scaffolds, but unreviewed external MCPs do not displace native synthesis, plurality review, or report readiness.
