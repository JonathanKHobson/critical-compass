# Critical Compass Master Roadmap

## Roadmap Logic

Sequence work by mission impact first: does it help a person or nonprofit pressure-test text before use? Local rebuildability and dependency risk still matter, but they are secondary to whether the work helps users decide what to trust, revise, verify, or reframe before sharing, teaching, funding, reporting, publishing, or acting.

## Mission Lens

The mission charter in `docs/planning/mission-audience-purpose-charter.md` is now the active roadmap lens. Critical Compass should prove that its current tools help public users and nonprofit teams find weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing in supplied text.

MCP composition, study-library learning, provider adapters, local retrieval, and external orchestration are support infrastructure. They are not the product story and should not become active work unless a concrete public/nonprofit pressure-test workflow needs them.

## Phase 0: Planning Package

- Create master PRD, roadmap, ADRs, evaluation strategy, file ownership rules, and per-idea planning folders.
- Classify outside inspirations as adopt, adapt/rebuild, optional integration, or reject.
- No feature implementation.

## Phase 1: Core Reasoning Artifacts

- Add `argument_map` to audit outputs.
- Add `checkworthy_claims` to audit outputs.
- Add canonical scaffold examples and resource contracts.
- Update report readiness and Markdown/PDF artifacts for these outputs.

Phase gate:
- Golden fixtures pass.
- Reports do not ship blank or placeholder sections.
- Check-worthy claims clearly separate factual verification priority from truth judgment.

Status as of 2026-04-15: implemented for the active local-first roadmap. Argument Map, Check-Worthy Claims, scaffold examples, report readiness, Markdown/PDF sections, report golden artifacts, check-worthy evidence-plan fields, no-network regressions, `.argdown` sidecars, and fixture coverage now exist.

## Phase 2: Advanced Audit Trust And Reflection

- Add advanced-audit dissent ledger.
- Add reasoning trap detectors.
- Add human-loop interruption triggers.
- Add structured elicitation for missing context and report readiness.

Phase gate:
- Agent disagreement is visible and traceable.
- Human-loop prompts remain non-sensitive and bounded.
- Reasoning-trap outputs improve audit prompts without over-labeling users or texts.

Status as of 2026-04-15: implemented for the active local-first roadmap. Dissent ledger, persistence fixtures, recurring disagreement-pattern tracking, interruption triggers, structured elicitation examples, expanded reasoning-trap checks, false-positive calibration, priority ordering, and consent-gated saved blind-spot reminders are wired into outputs, resources, pattern storage, and reports where applicable.

## Phase 3: Workflow And Trust Hardening

- Add server instructions and prompt/resource workflow layer.
- Add source/tool trust preflight.
- Add comparable tools knowledge layer as an internal resource.

Phase gate:
- Host AIs can discover correct workflow steps before tool calls.
- External tool use is consent-gated and trust-scored.
- Comparable tools layer helps users understand scope without bloating the product.

Status as of 2026-04-15: implemented for the active local-first roadmap. Host-AI workflow contracts, versioned scaffold resources, source preparation, persisted source/tool trust preflight, trust summaries in report metadata, red-team prompt-injection fixtures, and machine-readable comparable-tools records are available through overview/resources.

## Phase 4: Optional Interfaces And Integrations

- Prototype MCP App UI for argument maps, inline review, and report exploration.
- Populate and evaluate the local ClaimReview index/direct publisher harvest before any new fact-check API integration.
- Keep provider-backed fact-check retrieval explicit and experimental; scaffold-first behavior remains the shipped default.
- Add MCP composition policy and capability registry before any third-party MCP merge or orchestration.

Phase gate:
- UI improves comprehension beyond Markdown/PDF.
- External integrations remain opt-in and can be disabled without degrading core audits.

Status as of 2026-04-15: implemented for the current fact-check and MCP-composition cleanup. A read-only local artifact viewer now opens completed report manifests and shows the decision layer, report links, argument map, evidence plan, external fact-check results when explicitly supplied, dissent ledger, reasoning traps, questions, and trust preflight without creating new findings. `factcheck_lookup` is scaffold-first by default for factual `checkworthy_claims`; local ClaimReview retrieval is opt-in when an index is configured, direct publisher harvest is consent-gated, and provider-backed retrieval is explicit/experimental. MCP composition now has a local registry, soft-learning lesson registry, and policy for merge/wrap/orchestrate/scaffold/reject decisions. Automatic retrieval, broad research integrations, and unreviewed external MCP orchestration remain outside core audits.

## Current Next Tickets

The active next phase is **Pressure-Test Readiness**. Its goal is to prove the shipped tools are understandable, useful, and action-guiding for public users and nonprofit teams before adding more infrastructure:

Implementation planning pack: `docs/planning/ideas/atlas-informed-pressure-test-readiness/`. This pack turns the Atlas enhancement analysis into the current Pressure-Test Readiness implementation track while keeping Knowledge Atlas as build-time evidence, not a runtime dependency.

1. `PTR-01` - Add nonprofit/public-user test scenarios for advocacy copy, article review, grant impact claims, and public statements.
2. `PTR-02` - Define the expected user-facing output shape: what to trust, revise, verify, or reframe.
3. `PTR-03` - Audit current `audit_text`, `claim_stress_test`, `factcheck_lookup`, and report outputs against plain-language usefulness.
4. `PTR-04` - Add a validation checklist that fails if new roadmap items do not pass the mission decision filter.

Completed and deferred infrastructure context:

1. Done - local read-only artifact viewer for report manifests, argument maps, evidence plans, dissent, traps, and trust notes.
2. Done / scaffold-first plus opt-in retrieval - `factcheck_lookup` returns guided verification scaffolding and epistemic framing by default. Local ClaimReview retrieval works when indexed; direct publisher harvest is consent-gated; provider-backed retrieval for factual `checkworthy_claims` is explicit/experimental. Rejected for core - automatic live external fact-check/research calls.
3. Done - beta calibration harness for reasoning-trap and human-loop trigger drift across six local cases, with CLI support for consented custom case files.
4. Done - checklist-only handout visual artifact generation is covered by report renderer tests.
5. Done - overview, scaffold resources, examples/templates, and live QA runbook now surface source prep, reports, manifests, and the artifact viewer.
6. Done - MCP composition policy, capability registry, study-library soft-learning registry, ADRs, internal route-planning helpers, and scaffold resources now classify third-party MCP candidates without merging or calling them.
7. Evaluation-only - run real beta audits when consented excerpts are available, then add misses to custom calibration fixtures.
8. Maintenance backlog - refresh comparable-tools and MCP capability records only when product decisions depend on them.
9. Deferred - local ClaimReview expansion, external MCP trust preflight, factuality evals, runtime guard/proxy work, and provider/API work stay inactive until real pressure-test examples show they are needed.

## MCP Study Library Implementation Roadmap

The MCP study-library soft learner has completed its first `Ship next` documentation/resource slice. These items improved host-AI correctness and stale-surface prevention without merging, installing, importing, or calling third-party MCPs. They are now support infrastructure, not the active roadmap center.

| Verdict | Item | Impact | Effort | Roadmap Action |
|---|---|---:|---:|---|
| `Completed ship-next` | Host-AI Quickstart / Current State Context resource | High | Low | Implemented as scaffold resource and manifest entry. |
| `Completed ship-next` | Client-specific one-line hints | High | Low | Implemented as scaffold resource and host-facing guidance. |
| `Completed ship-next` | Tool trigger matrix | High | Medium | Implemented as call-when/do-not-call/ask-first/output-label resource. |
| `Completed ship-next` | Surface sync checklist plus lightweight validator | High | Medium | Implemented as scaffold resource and `validate_mcp_surface_sync.py`. |
| `Use for local ClaimReview phase` | Adapter boundary checklist and golden-fixture requirement | High | Medium | Apply when extending local ClaimReview/direct publisher retrieval. |
| `Good next phase` | External MCP trust preflight checklist | High | Medium | Convert security lessons into a non-runtime trust checklist before any external orchestration. |
| `Defer until examples prove need` | Confidence/revision metadata and manifest/resource linter | Medium | Low-Medium | Revisit only when real examples or repeated drift justify them. |
| `Later / high effort` | Factuality eval subsystem and runtime MCP guard/proxy | Medium | High | Keep separate from core audits until a specific approved route exists. |
| `Reject / scaffold-only` | Generic think tool and provider/payment consensus MCPs | Low-Medium | Low-High | Keep out of runtime paths; preserve only as scaffold or anti-pattern notes. |

MSL-01 through MSL-04 are complete. Later tickets `MSL-05` through `MSL-12` remain visible in `docs/planning/mcp-study-library-soft-learner.md`, but they are not active implementation work. The active roadmap is Pressure-Test Readiness.

## Cross-Phase Guardrails

- Do not add automatic web search to core audits.
- Do not equate check-worthy with false.
- Preserve dissent, provenance, and uncertainty in output contracts.
- Prefer local rebuilds over direct dependency on proprietary services.
