# Atlas-Informed Pressure-Test Readiness Phase Roadmap

## Implementation Status - 2026-04-27

All phases in this roadmap have been implemented to their stated gates.

Implemented artifacts:
- Phase 0: planning pack and roadmap links.
- Phase 1: `support/evals/atlas_pressure_test_scenarios.json`.
- Phase 2: mitigation verbs, AI/data audit language, KB no-result recovery, routing guidance, and ethical dilemma examples in existing surfaces.
- Phase 3: `support/library/atlas-curated-gap-fill.pack.json`, refreshed SQLite index, and offline skill export validation.
- Phase 4: Atlas-informed persona seeds plus optional practice suggestions inside existing outputs and scaffolds.
- Phase 5: `support/evals/practice_activity_tool_gate.json`, with the standalone Practice Activity Tool explicitly deferred because the gates are not yet met.

The Phase 5 outcome is a completed gate decision, not a new public tool.

## Phase 0: Planning Package
Create this idea pack and connect it to the active Pressure-Test Readiness roadmap.

Exit criteria:
- `overview.md`, `prd.md`, `phase-roadmap.md`, and `slice-roadmap.md` exist.
- `docs/planning/README.md` links to the planning pack.
- `docs/planning/master-roadmap.md` references the initiative under Current Next Tickets.

## Phase 1: Now - Scenario Pack And Decision Validation
Build the Atlas-informed pressure-test scenario pack and use it to validate the trust/revise/verify/reframe decision contract.

Required scenarios:
- Advocacy copy.
- Public statement.
- Grant impact claim.
- Article review.
- AI-generated summary.
- Research-adjacent summary.

Exit criteria:
- Each scenario includes intent, audience, text type, likely risks, expected decision output, and pass/fail checks.
- Each scenario maps to current surfaces such as `audit_text`, `claim_stress_test`, `factcheck_lookup`, scaffold resources, and reports.
- The scenario pack can be used to audit output usefulness before adding KB records or new behavior.

Phase gate:
- Do not start curated KB expansion until the scenario pack exists and at least one current-output audit has been run against it.

## Phase 2: Now+ - Output Language And Recovery Upgrades
Use the scenario pack to improve existing outputs and host guidance.

Work items:
- Bias Mitigation Next-Step Upgrade.
- AI/Data Bias Audit Language.
- KB Search No-Result Recovery.
- Atlas Routing Cheat Sheet.
- Ethical Dilemma Examples For Teaching.

Exit criteria:
- Mitigation next steps are concrete, compact, and action-led.
- AI/data audit copy names precise risks without implying live fact-checking.
- KB no-result guidance suggests narrower terms, category filters, adjacent concepts, or manual fallback examples.
- Routing guidance keeps Atlas as evidence, not a new runtime dependency.
- Ethical dilemma examples help users see values conflicts and next questions without becoming verdict engines.

Phase gate:
- Output changes must pass the mission decision filter: they must help a user decide what to trust, revise, verify, or reframe.

## Phase 3: Next - Curated KB Gap Fill
Add selected Atlas-informed concepts only where the scenario pack or retrieval checks show useful missing coverage.

Work items:
- Bias Gap-Fill Pack From Atlas.
- Research/Evidence Bias Expansion.
- Offline skill export validation for any new KB entries.

Exit criteria:
- Candidate entries are de-duplicated against existing Critical Compass records and aliases.
- Entries include conservative labels, examples, mitigations, related links, and provenance.
- New concepts resolve through SQLite FTS, relevant lookup/search surfaces, and offline skill references.

Phase gate:
- Do not import all Atlas bias-family entries. Add only curated records with a demonstrated Critical Compass use.

## Phase 4: Middle - Persona And Practice Pilot
Pilot stakeholder and teaching improvements inside existing surfaces.

Work items:
- Atlas Persona Seeds For Missing Voices.
- Activity Suggestions For Critical-Thinking Practice.

Exit criteria:
- Missing-voice suggestions remain candidate standpoints, not identity impersonations.
- Practice suggestions appear only as optional follow-up blocks when skill-building or teaching is relevant.
- Activity suggestions are easy to ignore when the user only wants an audit.

Phase gate:
- Do not add a standalone activity tool in this phase.

## Phase 5: Later - Practice Activity Tool Reconsideration
Reconsider a standalone `suggest_practice_activity`-style tool only if the existing surfaces prove insufficient.

Required gates:
- Real users repeatedly ask for standalone practice recommendations.
- Optional practice blocks become too crowded for `suggest_next_steps` or reports.
- Activity retrieval needs structured filters that would bloat existing surfaces.
- The practice layer proves high value in pressure-test sessions.

Stop condition:
- If these gates are not met, keep practice work inside next steps, reports, and scaffold resources.
