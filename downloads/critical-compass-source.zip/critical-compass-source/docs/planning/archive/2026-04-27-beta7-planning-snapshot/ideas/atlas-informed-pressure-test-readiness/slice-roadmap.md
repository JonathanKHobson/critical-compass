# Atlas-Informed Pressure-Test Readiness Slice Roadmap

## Implementation Status - 2026-04-27

All slices are now implemented through existing Critical Compass surfaces.

| Slice | Status | Shipped Surface |
|---|---|---|
| Slice 1 | Complete | `support/evals/atlas_pressure_test_scenarios.json` |
| Slice 2 | Complete | `support/evals/atlas_pressure_test_output_audit.json` |
| Slice 3 | Complete | `suggest_next_steps` action verbs and `pressure-test-readiness-kit.md` |
| Slice 4 | Complete | `ai_data_audit_language` and AI/data gap-fill records |
| Slice 5 | Complete | `kb_no_result_recovery` and scaffold recovery guidance |
| Slice 6 | Complete | `support/library/atlas-curated-gap-fill.pack.json`, refreshed SQLite DB, offline skill export path |
| Slice 7 | Complete | `list_agent_personas` seeds and optional `practice_suggestions` in existing outputs |

The standalone Practice Activity Tool remains intentionally unbuilt until the Phase 5 gate criteria are met.

## Slice 1: Six Scenario Pack v0
Deliverable: A Critical Compass-native scenario pack grounded by Atlas but written for the active PTR roadmap.

Affected surfaces:
- Scaffold resources.
- Eval fixtures.
- Report and audit usefulness checks.

Acceptance checks:
- Includes advocacy copy, public statement, grant impact claim, article review, AI-generated summary, and research-adjacent summary.
- Each scenario includes audience, text type, likely risks, expected trust/revise/verify/reframe output, and pass/fail checks.
- No scenario requires a new tool or live Atlas call.

Do not expand into:
- Runtime Atlas dependency.
- Full ethics encyclopedia.
- Practice activity recommender.

## Slice 2: Current Output Audit
Deliverable: A usefulness review of current `audit_text`, `claim_stress_test`, `factcheck_lookup`, and report outputs against the six scenarios.

Affected surfaces:
- Existing audit output.
- Claim stress-test output.
- Fact-check scaffold output.
- Markdown/PDF/report-readiness outputs.

Acceptance checks:
- The review identifies where outputs help users trust, revise, verify, or reframe.
- The review flags where outputs are too vague, too long, too technical, or too verdict-like.
- Check-worthy language remains "worth verifying, not false."

Do not expand into:
- Automatic external verification.
- New factuality provider integrations.
- New agentic workflow steps.

## Slice 3: Mitigation Next Steps v1
Deliverable: Concrete next-step language for common surfaced risks.

Affected surfaces:
- `suggest_next_steps`.
- `audit_text` next actions.
- Report next actions.

Acceptance checks:
- Next steps use compact action verbs such as check, compare, ask, gather, disclose, bound, test, and revise.
- Recommendations stay tied to visible text evidence.
- Output does not become longer, preachier, or less grounded.

Do not expand into:
- A separate mitigation tool.
- Generic self-improvement coaching.
- Moral verdicts about the author.

## Slice 4: AI/Data Bias Language v1
Deliverable: More precise AI-generated and AI-mediated audit language.

Affected surfaces:
- `ai_generated` text type guidance.
- Audit/report copy.
- Future curated KB entries where existing records are absent or too broad.

Acceptance checks:
- Outputs can name risks such as sycophancy, hallucination confidence, prompt-context bias, metric bias, benchmark bias, deployment bias, representation bias, aggregation bias, evaluation bias, and dataset shift.
- The language does not imply retrieval, verification, or model-internal knowledge occurred.
- The user gets a concrete verify/revise/reframe next move.

Do not expand into:
- AI safety glossary work.
- Model benchmarking infrastructure.
- Claims about model internals that the text does not support.

## Slice 5: KB No-Result Recovery v1
Deliverable: Host guidance for recovering from broad or vocabulary-mismatched KB searches.

Affected surfaces:
- Host-AI quickstart.
- Tool-trigger matrix.
- Possible later `search_knowledge_base` fallback behavior.

Acceptance checks:
- Broad no-result searches get suggested narrower concepts, category filters, and adjacent terms.
- Recovery examples cover memory bias, AI bias, social/intergroup bias, and research/evidence bias.
- The host is guided to retry or fall back manually before concluding the KB is empty.

Do not expand into:
- Search ranking rebuilds in the first pass.
- Atlas runtime search.
- Generic glossary browsing.

## Slice 6: Curated Atlas Bias Gap-Fill v1
Deliverable: A selected Critical Compass pack for proven missing concepts.

Affected surfaces:
- `support/library/*.pack.json`.
- SQLite seed and validation workflow.
- Offline skill export.
- Research and AI audit retrieval profiles.

Acceptance checks:
- Candidates are de-duplicated against existing records and aliases.
- Entries include conservative labels, signal cues, examples, mitigations, related links, and provenance.
- Entries resolve through SQLite FTS, lookup/search behavior, and exported offline references.

Do not expand into:
- Wholesale Atlas import.
- Persona-like records stored as biases.
- Framework records incorrectly filed as bias records.

## Slice 7: Persona And Practice Pilot
Deliverable: Middle-lane improvements for missing voices and optional learning follow-up.

Affected surfaces:
- `list_agent_personas`.
- `advanced_audit`.
- `suggest_next_steps`.
- Scaffold resources and reports.

Acceptance checks:
- Personas are framed as analytical standpoints and candidate perspectives.
- Practice activities appear only when teaching or skill-building follow-up is useful.
- Activity suggestions are relevant to the surfaced issue and optional by design.

Do not expand into:
- Identity impersonation.
- Ungated advanced-agent orchestration.
- Standalone `suggest_practice_activity` until the Phase 5 gates pass.
