# Atlas-Informed Pressure-Test Readiness

## Problem / Opportunity
Critical Compass has the core reasoning surface needed to help public users and nonprofit teams pressure-test text before use. The next useful move is not a new tool. It is a small Atlas-informed planning and validation track that proves the shipped outputs help people decide what to trust, revise, verify, or reframe before sharing, publishing, funding, teaching, reporting, or acting.

Knowledge Atlas is source evidence for this initiative, not a runtime dependency. Its bias, mitigation, persona, ethical dilemma, AI/data bias, and activity collections can sharpen Critical Compass examples, next steps, and validation scenarios without turning Critical Compass into Atlas.

## Source Inputs
- `critical-compass-enhancement-suggestions.md`
- `critical-compass-impact-effort-matrix.md`
- `critical-compass-current-state.md`
- `critical-compass-atlas-bridge-map.md`

These files live under `/Volumes/KyleSSD/Documents/My Projects/Compass Suite Atlas Enhancement Analysis/2026-04-27/critical-compass/` and should remain read-only planning evidence.

## Product Lens
Use the active Pressure-Test Readiness roadmap as the filter:

- Does this help a public user or nonprofit team understand the text?
- Does it produce a usable `Trust`, `Revise`, `Verify`, or `Reframe` decision?
- Does it make weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, or narrow framing easier to see?
- Can the improvement ship through existing Critical Compass surfaces before adding infrastructure?

## Ranked Enhancement Set
Do first:

| Enhancement | Why now |
|---|---|
| Atlas-informed Pressure-Test Scenario Pack | Creates the evaluation harness for every later improvement and maps directly to PTR-01 and PTR-03. |
| Bias Mitigation Next-Step Upgrade | Turns findings into concrete action without adding a separate mitigation tool. |
| KB Search No-Result Recovery | Helps host AIs recover from broad or vocabulary-mismatched searches before assuming the KB is empty. |
| AI/Data Bias Audit Language | Improves `ai_generated` reviews with clearer distinctions such as sycophancy, benchmark bias, metric bias, dataset shift, and hallucination confidence. |
| Ethical Dilemma Examples For Teaching | Gives claim and audit examples better values-conflict texture without becoming an ethics encyclopedia. |
| Atlas Routing Cheat Sheet | Keeps Atlas as evidence and prevents scope drift across Critical Compass, Prompt Compass, Research Compass, and Knowledge Atlas. |

Do after the scenario pack:

| Enhancement | Why later |
|---|---|
| Bias Gap-Fill Pack From Atlas | Needs curation and searchability validation so it does not increase KB noise. |
| Research/Evidence Bias Expansion | Useful, but should be judged against scenario and retrieval-profile coverage first. |
| Atlas Persona Seeds For Missing Voices | Valuable for advanced and stakeholder-sensitive reviews, but should preserve persona-as-standpoint guardrails. |
| Activity Suggestions For Critical-Thinking Practice | Useful as optional follow-up, but first belongs inside existing next-step and scaffold surfaces. |

Defer:

| Enhancement | Reason |
|---|---|
| Practice Activity Tool | Existing surfaces can deliver the first version. A new tool is justified only if real users repeatedly ask for standalone practice recommendations and existing outputs become crowded. |

## Non-Goals
- Do not add new Now-phase MCP tools.
- Do not add automatic web search or live retrieval to core audits.
- Do not make Atlas a runtime dependency.
- Do not import Atlas records wholesale.
- Do not treat check-worthy claims as false claims.
- Do not weaken Critical Compass's conservative labeling, provenance, uncertainty, or cultural humility rules.

## Smallest Useful Outcome
Ship the Atlas-informed pressure-test scenario pack first. It should cover advocacy copy, public statements, grant impact claims, article review, AI-generated summaries, and research-adjacent summaries, with expected decision output and pass/fail checks for plain-language usefulness.
