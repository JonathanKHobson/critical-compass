# Atlas-Informed Pressure-Test Readiness PRD

## Executive Summary
This initiative uses Knowledge Atlas as build-time planning evidence to improve Critical Compass's public and nonprofit pressure-test workflow. The goal is to make existing outputs more decision-useful before adding infrastructure: clearer scenarios, clearer mitigation next steps, better AI/data risk language, better KB search recovery, and better teaching examples.

The product promise stays narrow: help users decide what to trust, revise, verify, or reframe before using text.

## Target Users
- Nonprofit communicator reviewing advocacy copy before publication.
- Grant writer or grant reviewer pressure-testing impact claims.
- Public statement drafter checking accountability, evidence, and missing voices.
- Article reviewer looking for framing, source, and check-worthy claim gaps.
- AI-generated summary reviewer looking for provenance and fluent false confidence risks.
- Host AI or maintainer deciding which Critical Compass surface should handle a request.

## Goals
- Add an Atlas-informed pressure-test scenario pack for the active PTR roadmap.
- Improve mitigation next steps so surfaced risks lead to concrete action.
- Improve AI/data audit language for `ai_generated` and AI-mediated text.
- Improve KB no-result recovery for broad natural-language searches.
- Add routing guidance and ethical dilemma examples that keep Critical Compass focused.
- Create a phased path for curated Atlas gap-fill entries without importing wholesale.

## Non-Goals
- Do not build the deferred Practice Activity Tool now.
- Do not turn Critical Compass into Knowledge Atlas, Prompt Compass, or Research Compass.
- Do not add runtime dependencies, external retrieval, or automatic web search.
- Do not expand advanced agentic review unless scenario evidence proves a need.
- Do not add new public MCP tools in the Now phase.

## User Stories
| ID | User Story |
|---|---|
| US-001 | As a nonprofit communicator, I want advocacy copy tested against likely audience, evidence, missing-voice, and persuasion risks so I know what to revise before publishing. |
| US-002 | As a grant reviewer, I want impact claims separated into evidence strength, causal reach, and metric-risk concerns so I know what to verify or reframe. |
| US-003 | As a public statement drafter, I want accountability gaps and vague responsibility language surfaced without moralizing so I can revise responsibly. |
| US-004 | As an AI summary reviewer, I want AI-specific risks named precisely without the system pretending it fact-checked the content. |
| US-005 | As a host AI, I want recovery guidance when KB search returns no results so I can try narrower concepts before declaring the KB empty. |
| US-006 | As a maintainer, I want Atlas-informed KB additions to be curated, provenance-aware, and validated through existing search and offline export paths. |

## Functional Requirements
| ID | Requirement | Acceptance Criteria |
|---|---|---|
| FR-001 | Create a six-scenario pressure-test pack. | The pack includes advocacy copy, public statement, grant impact claim, article review, AI-generated summary, and research-adjacent summary scenarios. |
| FR-002 | Define expected decision output for each scenario. | Each scenario names expected `Trust`, `Revise`, `Verify`, or `Reframe` guidance and the reason that guidance is useful. |
| FR-003 | Map scenarios to current surfaces. | Each scenario names the relevant current surfaces, including `audit_text`, `claim_stress_test`, `factcheck_lookup`, reports, or scaffold resources. |
| FR-004 | Upgrade mitigation next-step guidance. | Common findings map to compact verbs such as check, compare, ask, gather, disclose, bound, test, and revise. |
| FR-005 | Add KB no-result recovery behavior guidance. | Broad queries receive suggested narrower terms, category filters, adjacent concepts, or manual fallback examples before the host concludes nothing exists. |
| FR-006 | Improve AI/data audit language. | AI-generated or AI-mediated reviews distinguish risks such as sycophancy, metric bias, benchmark bias, representation bias, deployment bias, aggregation bias, evaluation bias, dataset shift, and hallucination confidence. |
| FR-007 | Add routing guidance for Atlas-informed material. | Host guidance distinguishes Critical Compass uses from Atlas, Prompt Compass, and Research Compass uses without creating a new tool. |
| FR-008 | Add ethical dilemma teaching examples. | Examples expose values conflicts and next questions without deciding the moral answer for the user. |
| FR-009 | Define curated Atlas gap-fill criteria. | Future KB additions are selected for missing Critical Compass coverage, conservative labeling, aliases, mitigations, related links, and provenance. |

## Non-Functional Requirements
| ID | Requirement |
|---|---|
| NFR-001 | Keep the Now phase local-first and scaffold/resource-driven. |
| NFR-002 | Preserve plain-language usefulness over taxonomy completeness. |
| NFR-003 | Never use check-worthy as a synonym for false. |
| NFR-004 | Preserve dissent, provenance, uncertainty, and cultural humility. |
| NFR-005 | Avoid new public tools unless existing surfaces cannot deliver the proven user value. |
| NFR-006 | Keep Atlas as build-time evidence unless a separate product decision approves a runtime bridge. |

## Success Metrics
- Six scenarios exist and each has audience, text type, likely risks, expected decision output, and pass/fail checks.
- Current outputs can be audited against the scenario pack for plain-language usefulness.
- Mitigation next steps become more concrete without increasing output length or preachiness.
- KB no-result recovery suggests useful fallback searches for broad memory, AI, social, and research/evidence bias queries.
- AI-generated text reviews name precise AI/data risks without implying live retrieval or factual verification.
- Any future Atlas-derived KB entries resolve through the existing KB and offline export workflow before they are treated as shipped.

## Risks
| Risk | Mitigation |
|---|---|
| Scope drift into Atlas replication | Keep the first shipped slice scenario-based and forbid wholesale imports. |
| Tool-surface bloat | Route all Now-phase work through existing outputs and resources. |
| Overconfident fact-check language | Keep fact-check and check-worthy language scaffold-first unless explicit retrieval occurred. |
| Persona misuse | Treat personas as analytical standpoints, not identity impersonation or lived authority. |
| KB noise | Add curated gap-fill entries only after scenario evidence shows a retrieval or audit gap. |

## Implementation Defaults
- Host the first scenario fixtures in the existing scaffold/eval resource lane rather than creating a new runtime surface.
- Audit current outputs in this order: `audit_text`, `claim_stress_test`, `factcheck_lookup`, then reports.
- Start Atlas gap-fill review from concepts proven useful by the scenario pack or no-result recovery pass, then validate exact and alias search coverage before adding records.
