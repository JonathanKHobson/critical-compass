#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
import sys
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from audit_report import generate_audit_artifact_viewer as generate_audit_artifact_viewer_file
from audit_report import generate_audit_report as generate_audit_report_file
from audit_report import prepare_audit_source as prepare_audit_source_file
from factcheck import factcheck_lookup as factcheck_lookup_file
from mcp_composition import (
    load_mcp_capability_registry,
    load_mcp_study_lessons,
    summarize_mcp_capability_registry,
    summarize_mcp_study_lessons,
    validate_mcp_capability_registry,
    validate_mcp_study_lessons,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_DB_PATH = ROOT / "db" / "critical-compass.sqlite"
DEFAULT_STATE_DB_PATH = ROOT / "db" / "critical-compass-state.sqlite"
USER_ADDITIONS_PACK_PATH = ROOT / "support" / "library" / "user-additions.pack.json"
REASONING_FLOWS_DIR = ROOT / "support" / "reasoning-flows"
COMPARABLE_TOOLS_RESOURCE_PATH = ROOT / "support" / "registry" / "comparable_tools.json"
COMPARABLE_TOOLS_EVALUATIONS_PATH = ROOT / "support" / "registry" / "comparable_tools_evaluations.json"
MCP_CAPABILITY_REGISTRY_PATH = ROOT / "support" / "registry" / "mcp_capabilities.json"
MCP_CAPABILITY_SCHEMA_PATH = ROOT / "support" / "registry" / "mcp_capability_registry.schema.json"
MCP_STUDY_LESSONS_PATH = ROOT / "support" / "registry" / "mcp_study_lessons.json"
MCP_STUDY_LESSONS_SCHEMA_PATH = ROOT / "support" / "registry" / "mcp_study_lessons.schema.json"
SCAFFOLD_RESOURCE_MANIFEST_PATH = ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json"
TEACHING_ACTIVITY_PACK_PATH = ROOT / "support" / "library" / "file-o-fun-teaching-activity-pack.json"
FLOW_NAMESPACE_EPISTEMIC_CORE = "epistemic_core"
FLOW_NAMESPACE_APPLIED_REASONING = "applied_reasoning"
FLOW_NAMESPACES = {FLOW_NAMESPACE_EPISTEMIC_CORE, FLOW_NAMESPACE_APPLIED_REASONING}

READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)

WRITE_LOCAL = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)

EXTERNAL_LOOKUP = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=True,
)

REPORT_TOOL_DESCRIPTION = """Generate a stakeholder-ready PDF report from a completed audit.
The MCP owns normalization, schema validation, deterministic HTML/CSS rendering, PyMuPDF QA, preview images, and report metadata.

Host AI prompt: before calling this tool, assemble report-ready audit_data. A polished full report needs a Critical Integrity Snapshot, five dimensions, plain-language read, before-use text, key tension, recommended next step, bias rows, dimension improvement prompts, assumptions, alternative frames, probing/follow-up questions, next steps, follow_up_activity, argument_map and checkworthy_claims when present, dissent_ledger when advanced_audit agents disagree, and agent top findings when advanced_audit is present. A readiness-card report is a compact derived output that still needs CIS, plain-language read, before-use text, pressure_test_readiness_card, and a compact follow_up_activity.try_this_next. By default, incomplete full reports are blocked before Markdown or PDF rendering. If any report-critical field is unavailable, tell the user what is missing and ask whether to re-submit it; only pass allow_placeholders=true when the user explicitly wants a draft placeholder PDF.
Audit workflow prompt: audit_text, advanced_audit, and synthesize_audit_verdict return a report_readiness_contract with the canonical payload template, a complete example, and a Markdown checkpoint template. Treat that contract as the pre-call workflow. Use canonical field names in new payloads; aliases below are compatibility fallbacks only.
Human Loop prompt: guided audits use three blocks: onboarding before the core audit, judgment before findings are revealed, and reflection after a three-bullet preview but before final PDF/Markdown/chat output. Silent mode requires explicit user confirmation or an explicit noninteractive smoke-test override; an unauthorized silent request must stop at mode_consent before any audit/report work. If audit_data includes human_loop.pending_prompt_ids or human_loop_host_action.must_pause=true, ask only the current block through the host's native question UI before generating the final PDF unless the user explicitly requested a noninteractive smoke test. Never ask the full Human Loop questionnaire at once. Pass the updated human_loop.state into audit_data after answers are collected.

Accepted audit_data aliases:
- Plain-language read: critical_integrity_snapshot.plain_language_read, critical_integrity_snapshot.plain_language, critical_integrity_snapshot.executive_summary, critical_integrity_snapshot.summary, plain_language_read, plain_language, executive_summary, summary.
- CIS aggregate points: critical_integrity_snapshot.points or critical_integrity_snapshot.score.
- Dimension score/max: dimensions[].points or score; dimensions[].max_points or max.
- Dimension prompt: dimensions[].improvement_prompt, action, strengthen_prompt, improvement, next_step, or prompt.
- Bias list/name: biases, top_biases, bias_map, quick_scan_card.top_biases, or findings.biases; each bias may use name, bias_name, title, bias_id, or id.
- Key tension: key_tension, quick_scan_card.key_tension, findings.key_tension, or first usable tensions[] item.
- Agent finding: advanced_audit.agents[].top_finding, finding, key_finding, contribution, key_contribution, insight, summary, or matching analyses[].primary_finding.
- Argument map: argument_map, argumentMap, argument_structure, or reasoning_map.
- Check-worthy claims: checkworthy_claims, check_worthy_claims, claims_to_check, or evidence_needed_next. Each claim may include suggested_queries, likely_source_types, support_contrast_status, and uncertainty_note. Check-worthy means worth verifying, not false; do not run automatic web verification from core audits.
- External fact checks: external_fact_checks, factcheck_results, fact_check_results, or retrieved_fact_checks. Only attach results returned by the explicit opt-in factcheck_lookup tool; retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.
- Dissent ledger: advanced_audit.dissent_ledger, dissent_ledger, agent_dissent, or disagreements.
- Reasoning traps: reasoning_traps, trap_detectors, or reasoning_risks. These are advisory risks, not verdicts.
- Follow-up activity: follow_up_activity, followup_activity, teaching_activity, activity_follow_up, or legacy practice_suggestions. Quick/chat outputs use one compact activity idea; full/advanced reports use one solo and one group activity.

Readiness behavior:
- report_depth may be full, overview, checklist_only, or readiness_card. readiness_card is a compact pressure-test card view over existing audit fields; it does not create a new score model.
- Full reports require substantive Tier 1 and Tier 2 content. Empty arrays, blank strings, fallback strings, and numeric-only items like "1", "2", "3" are rejected.
- If readiness fails and allow_placeholders is false, the tool returns qa_status="blocked", preflight_status="blocked_missing_fields", compiled_sections, report_preflight_card, missing_report_fields, what_to_resubmit, accepted_aliases, and no report_path/markdown_path.
- If allow_placeholders is true, the tool renders a draft and returns qa_status="passed_with_cosmetic_issues".
- Successful renders also save a deterministic Markdown contract next to the PDF and return markdown_path and markdown_hash.

Successful reports write a report manifest and a local read-only artifact viewer. The return object includes manifest_path, viewer_path, and artifact_viewer metadata. Use generate_audit_artifact_viewer(manifest_path) to rebuild the viewer from an existing manifest.

Host AI behavior: when qa_status is blocked or warnings appear, show the missing fields and ask whether the caller wants to re-submit the missing data before requesting a PDF. Do not present placeholder reports as final. After a successful report, present report_path, markdown_path, manifest_path, and viewer_path together so the reader can choose PDF, Markdown, or local viewer."""

SOURCE_PREFLIGHT_DESCRIPTION = """Prepare a local PDF for Critical Compass auditing.
Use this before audit_text or advanced_audit when the source is a PDF file. The MCP extracts embedded text with PyMuPDF, detects scanned/sparse text, optionally rasterizes pages, and uses Apple Vision OCR on this Mac when OCR is needed.

Inputs:
- source_path: local PDF path.
- ocr_mode: auto, force, or off. Default auto.
- output_dir: optional directory for extracted text and page images.
- include_page_images: default true.

Returns audit-ready text, text_path, source_id, page_count, extraction_method, OCR status, page image paths, and warnings. If embedded text is sparse and OCR is unavailable/off, status is blocked or needs_ocr_dependency so the host AI does not accidentally audit a copyright notice or near-empty text."""

ARTIFACT_VIEWER_DESCRIPTION = """Generate a local read-only HTML artifact viewer from a generated audit report manifest.
Use this after generate_audit_report when a stakeholder or reviewer needs a lightweight frontend for the completed report artifacts. The viewer reads the existing manifest payload; it does not invent findings, run retrieval, edit reports, or replace the PDF/Markdown source of truth.

Inputs:
- manifest_path: path to the .json manifest returned by generate_audit_report.
- output_path: optional HTML output path. Default writes next to the manifest as *-viewer.html.

Returns viewer_path, ui_version, source_manifest_path, visible sections, warnings, and an open_hint. This is local-first and uses only bundled inline HTML/CSS."""

FACTCHECK_LOOKUP_DESCRIPTION = """Generate a scaffold-first verification plan for factual claims already extracted by checkworthy_claims.
The shipped default is guided_research: no API key required, no live retrieval, and no local index implied. This tool never runs inside audit_text, advanced_audit, synthesize_audit_verdict, generate_audit_report, or report readiness by default.

Host AI workflow:
- Use checkworthy_claims first. The default guided_research mode returns epistemic framing, suggested queries, source classes, evidence trail template, and plurality review template.
- Use the scaffold with the host AI's own browsing tools when the user asks for verification.
- Ask the user before any external lookup. `local_claimreview` is offline; `publisher_harvest`, `publisher_site_search`, `google_fact_check_tools`, and `brave_search` require `allow_external_calls=true`.
- Do not send full documents, surrounding private notes, hidden reasoning, or audit context.
- Do not send interpretive, causal, normative, policy, emotional, or ambiguous claims.
- Treat check-worthy claims as worth checking, not false. Treat retrieved evidence, when present, as evidence artifacts, not a Critical Compass truth verdict.
- Preserve publisher disagreement; do not flatten textual ratings into one score.

Inputs:
- claims: list of claim objects with claim_id/id, text/claim, claim_type or is_factual, and verification_priority.
- provider: guided_research by default. auto is a deprecated alias for guided_research and returns a loud warning. local_claimreview searches a configured local index without external calls. publisher_harvest harvests ClaimReview markup from approved publisher sites and requires allow_external_calls=true. publisher_site_search, google_fact_check_tools, and brave_search are optional/experimental retrieval providers.
- language_code: default en.
- publisher_sites: optional approved publisher domains for experimental provider-backed retrieval.
- max_age_days: freshness window. Default comes from CRITICAL_COMPASS_FACTCHECK_DEFAULT_MAX_AGE_DAYS or 3650.
- allow_external_calls: default false. False blocks external retrieval but still allows guided_research scaffolding and local_claimreview.
- allow_sensitive_claims: default false. True allows sensitive claims but disables caching for those claims and adds cautions.

Trust and privacy:
- Only approved domains from support/registry/trusted_factcheck_publishers.json are queried.
- Likely private/sensitive claims are blocked unless allow_sensitive_claims=true.
- Minimum external data for external modes: normalized claim text, language code, publisher filter, and freshness window. local_claimreview sends no claim text externally.
- Google/Brave keys are advanced experimental provider config only, not the main setup path.

Output:
- guided_research leads with "No retrieval was performed" and returns lookup_performed=false, user_facing_summary, normalized_claims, epistemic_framing, suggested_queries, recommended_source_classes, evidence_trail_template, epistemic_plurality_review_template, structured cautions, warnings, and opt-in retrieval paths.
- results[].status is one of match_found, multiple_matches, conflicting_reviews, no_trusted_match, sensitive_blocked, or provider_error.
- matches preserve matched claim text, claimant/date when present, publisher, URL, title, review date, verbatim textual_rating, language code, and heuristic match_confidence.
- No trusted match, ambiguity, conflicts, sensitivity blocks, and provider errors are explicit."""


REPORT_ACCEPTED_ALIASES: dict[str, list[str]] = {
    "critical_integrity_snapshot.plain_language_read": [
        "critical_integrity_snapshot.plain_language_read",
        "critical_integrity_snapshot.plain_language",
        "critical_integrity_snapshot.executive_summary",
        "critical_integrity_snapshot.summary",
        "plain_language_read",
        "plain_language",
        "executive_summary",
        "summary",
    ],
    "critical_integrity_snapshot.points": ["critical_integrity_snapshot.points", "critical_integrity_snapshot.score"],
    "dimensions[].points": ["dimensions[].points", "dimensions[].score"],
    "dimensions[].max_points": ["dimensions[].max_points", "dimensions[].max"],
    "dimensions[].improvement_prompt": [
        "dimensions[].improvement_prompt",
        "dimensions[].action",
        "dimensions[].strengthen_prompt",
        "dimensions[].improvement",
        "dimensions[].next_step",
        "dimensions[].prompt",
    ],
    "biases": ["biases", "top_biases", "bias_map", "quick_scan_card.top_biases", "findings.biases"],
    "biases[].name": ["biases[].name", "biases[].bias_name", "biases[].title", "biases[].bias_id", "biases[].id"],
    "key_tension": ["key_tension", "quick_scan_card.key_tension", "findings.key_tension", "tensions[]"],
    "advanced_audit.agents[].top_finding": [
        "advanced_audit.agents[].top_finding",
        "advanced_audit.agents[].finding",
        "advanced_audit.agents[].key_finding",
        "advanced_audit.agents[].contribution",
        "advanced_audit.agents[].key_contribution",
        "advanced_audit.agents[].insight",
        "advanced_audit.agents[].summary",
        "analyses[].primary_finding",
    ],
    "argument_map": ["argument_map", "argumentMap", "argument_structure", "reasoning_map"],
    "checkworthy_claims": ["checkworthy_claims", "check_worthy_claims", "claims_to_check", "evidence_needed_next"],
    "checkworthy_claims[].suggested_queries": ["suggested_queries", "queries", "search_queries", "fact_check_queries", "verification_queries"],
    "checkworthy_claims[].likely_source_types": ["likely_source_types", "source_types", "sources_to_check", "evidence_source_types", "likely_sources"],
    "checkworthy_claims[].support_contrast_status": ["support_contrast_status", "support_status", "evidence_status", "support_contrast"],
    "checkworthy_claims[].uncertainty_note": ["uncertainty_note", "uncertainty", "caveat", "limitations"],
    "external_fact_checks": ["external_fact_checks", "factcheck_results", "fact_check_results", "retrieved_fact_checks"],
    "advanced_audit.dissent_ledger": ["advanced_audit.dissent_ledger", "dissent_ledger", "agent_dissent", "disagreements"],
    "reasoning_traps": ["reasoning_traps", "trap_detectors", "reasoning_risks"],
    "follow_up_activity": ["follow_up_activity", "followup_activity", "teaching_activity", "activity_follow_up", "practice_suggestions"],
}


def report_payload_template(*, include_advanced: bool = False) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "critical_integrity_snapshot": {
            "label": "<CIS label or null for profile_only>",
            "points": "<aggregate points or null for profile_only>",
            "display_state": "scored | profile_only",
            "plain_language_read": "<1-2 sentence plain-language verdict>",
            "before_using_this_text": "Before using this text, <what the reader should consider before acting>.",
            "context_lens": {
                "evidence_convention": "<citation_based | experiential_testimony | institutional_reporting | communal_consensus | hybrid | unclear>",
                "scoring_note": "<short scoring note>",
                "sensitive_dimensions": ["<dimension names if applicable>"],
            },
            "dimensions": [
                {
                    "name": "Grounding & Scope Fit",
                    "points": "<0-20>",
                    "max_points": 20,
                    "rationale": "<dimension rationale>",
                    "trace": ["<finding/source reference>"],
                    "improvement_prompt": "<specific coaching line>",
                },
                {
                    "name": "Assumptions & Context",
                    "points": "<0-20>",
                    "max_points": 20,
                    "rationale": "<dimension rationale>",
                    "trace": ["<finding/source reference>"],
                    "improvement_prompt": "<specific coaching line>",
                },
                {
                    "name": "Bias Transparency",
                    "points": "<0-20>",
                    "max_points": 20,
                    "rationale": "<dimension rationale>",
                    "trace": ["<finding/source reference>"],
                    "improvement_prompt": "<specific coaching line>",
                },
                {
                    "name": "Framing & Audience Openness",
                    "points": "<0-20>",
                    "max_points": 20,
                    "rationale": "<dimension rationale>",
                    "trace": ["<finding/source reference>"],
                    "improvement_prompt": "<specific coaching line>",
                },
                {
                    "name": "Positionality & Power",
                    "points": "<0-20>",
                    "max_points": 20,
                    "rationale": "<dimension rationale>",
                    "trace": ["<finding/source reference>"],
                    "improvement_prompt": "<specific coaching line>",
                },
            ],
        },
        "biases": [
            {
                "name": "<human-readable bias name>",
                "kb_id": "<KB ID if available>",
                "passage": "<where this appears, 12 words max>",
                "why_it_matters": "<plain-language impact>",
                "three_cs_lens": "Critical | Compassionate | Creative",
            }
        ],
        "key_tension": "<one sentence naming the core conflict or trade-off>",
        "recommended_next_step": "<one concrete action>",
        "assumptions": [
            {
                "assumption": "<assumption in the text>",
                "testable": "testable | not testable",
                "evidence_needed": "<what would test it>",
            }
        ],
        "alternative_frames": [
            {
                "name": "<frame name>",
                "kb_id": "<KB ID if available>",
                "frame": "<how this frame changes the reading>",
                "three_cs_lens": "Critical | Compassionate | Creative",
            }
        ],
        "probing_questions": ["<question 1>", "<question 2>", "<question 3>"],
        "follow_up_questions": ["<follow-up 1>", "<follow-up 2>", "<follow-up 3>"],
        "next_steps": ["<action step 1>", "<action step 2>", "<action step 3>"],
        "follow_up_activity": {
            "mode": "curated_file_o_fun_snapshot",
            "try_this_next": {
                "title": "<compact activity title for quick/chat outputs>",
                "why_this_fits": "<why this activity fits this text>",
                "steps": ["<step 1>", "<step 2>", "<step 3>"],
                "content_focus": "<which passage/claim to use>",
                "thinking_focus": ["Critical | Creative | Compassionate"],
                "source_note": "<curated File-O-Fun source note>",
            },
            "solo_activity": {
                "title": "<solo activity title>",
                "why_this_fits": "<why this activity fits this text>",
                "steps": ["<step 1>", "<step 2>", "<step 3>"],
                "content_focus": "<which passage/claim to use>",
                "thinking_focus": ["Critical | Creative | Compassionate"],
                "source_note": "<curated File-O-Fun source note>",
            },
            "group_activity": {
                "title": "<group activity title>",
                "why_this_fits": "<why this activity fits this text>",
                "steps": ["<step 1>", "<step 2>", "<step 3>"],
                "content_focus": "<which passage/claim to use>",
                "thinking_focus": ["Critical | Creative | Compassionate"],
                "source_note": "<curated File-O-Fun source note>",
                "safety_note": "<optional caution>",
            },
            "source_note": "Curated from a local File-O-Fun / Knowledge Atlas activity snapshot; no live Atlas lookup was performed.",
            "fit_check": {
                "prompt": "Use this, swap it, or skip activities next time?",
                "reflection_question": "What made it useful or not useful?",
                "persistence": "non_persistent",
                "no_persistence_note": "No activity outcome is saved by Critical Compass in beta.8.1.",
            },
        },
        "argument_map": {
            "plain_language_summary": "<plain-language map summary>",
            "central_claim": "<main claim the text asks readers to accept>",
            "claim_type": "factual | interpretive | causal | normative | policy",
            "supporting_reasons": ["<reason or evidence offered>"],
            "objections": ["<credible objection or counterframe>"],
            "assumptions": ["<assumption the claim depends on>"],
            "missing_voices": ["<stakeholder or perspective not represented>"],
            "evidence_gaps": ["<evidence needed to strengthen or weaken the claim>"],
            "confidence": "low | medium | high",
            "next_questions": ["<question to clarify the argument>"],
            "markdown": "<portable Markdown argument map>",
            "argdown": "<portable .argdown text export>",
            "status": "draft | ready | withheld",
        },
        "checkworthy_claims": {
            "note": "Check-worthy means worth verifying, not false.",
            "claims": [
                {
                    "claim": "<claim from the text>",
                    "claim_type": "factual | interpretive | causal | normative | policy",
                    "is_factual": "true|false",
                    "verification_priority": "high | medium | low | not_ranked",
                    "why_check": "<why this claim is worth checking>",
                    "evidence_needed": "<evidence needed next>",
                    "suggested_queries": ["<query the host AI may run only if the user requests external verification>"],
                    "likely_source_types": ["<primary source | official record | dataset | stakeholder evidence>"],
                    "support_contrast_status": "needs_evidence | needs_support_and_contrast | not_ranked_for_truth",
                    "uncertainty_note": "<what remains uncertain without implying the claim is false>",
                    "source_anchor": "<quote or section anchor>",
                    "confidence": "low | medium | high",
                    "not_false_notice": "Check-worthy means this claim is worth verifying, not that it is false.",
                }
            ],
        },
        "external_fact_checks": {
            "note": "Optional. Attach only after the user explicitly authorizes factcheck_lookup; retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.",
            "results": [
                {
                    "claim_id": "<claim id from checkworthy_claims>",
                    "status": "match_found | multiple_matches | conflicting_reviews",
                    "summary": "<retrieved fact-check summary>",
                    "matches": [
                        {
                            "matched_claim_text": "<provider matched claim>",
                            "claimant": "<claimant or null>",
                            "claim_date": "<claim date or null>",
                            "review": {
                                "publisher_name": "<publisher>",
                                "publisher_site": "<approved domain>",
                                "url": "<direct review URL>",
                                "title": "<review title>",
                                "review_date": "<review date>",
                                "textual_rating": "<verbatim publisher rating>",
                                "language_code": "en",
                            },
                            "match_confidence": 0.75,
                        }
                    ],
                    "cautions": ["Retrieved fact checks do not independently prove truth."],
                }
            ],
        },
        "subject_text": "<audited text or excerpt>",
        "text_type": "<general | advocacy | policy | sales | research | journalism | narrative | social_media | academic_abstract | product_copy | legal | ai_generated | other>",
    }
    if include_advanced:
        payload["advanced_audit"] = {
            "present": True,
            "agents": [
                {
                    "name": "<agent name>",
                    "reasoning_style": "<reasoning style>",
                    "top_finding": "<one-sentence top finding>",
                    "kb_id": "<KB ID if available>",
                }
            ],
            "dissent_ledger": [
                {
                    "agent_name": "<agent name>",
                    "top_finding": "<agent's top finding>",
                    "strongest_disagreement": "<strongest disagreement with another lens or the emerging verdict>",
                    "confidence": "low | medium | high",
                    "what_would_change_mind": "<evidence or reasoning that would shift this agent>",
                    "provenance": "<independent_analysis | tension_map | debate | synthesis>",
                }
            ],
            "verdict_paragraph": "<final synthesis verdict>",
        }
        payload["agents"] = "<optional raw agent definitions>"
        payload["analyses"] = "<optional raw analysis outputs>"
        payload["debate"] = "<optional debate output>"
        payload["verdict"] = "<optional synthesis verdict>"
    return payload


def report_payload_example(*, include_advanced: bool = False) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "critical_integrity_snapshot": {
            "label": "Moderate Integrity",
            "points": 62,
            "display_state": "scored",
            "plain_language_read": "Use this as a starting point, not a final authority; verify the claims doing the most work.",
            "before_using_this_text": "Before using this text, ask whether the evidence supports the claim's scope.",
            "context_lens": {
                "evidence_convention": "citation_based",
                "scoring_note": "Grounding and framing are interpreted relative to a research-evidence convention.",
                "sensitive_dimensions": ["Grounding & Scope Fit"],
            },
            "dimensions": [
                {
                    "name": "Grounding & Scope Fit",
                    "points": 11,
                    "max_points": 20,
                    "rationale": "The text names evidence but stretches beyond the visible sample.",
                    "trace": ["Claim generalized from a narrow participant group."],
                    "improvement_prompt": "Name the population limits before making a broad claim.",
                },
                {
                    "name": "Assumptions & Context",
                    "points": 12,
                    "max_points": 20,
                    "rationale": "Several assumptions about audience and context remain implicit.",
                    "trace": ["Context omitted around who the finding applies to."],
                    "improvement_prompt": "State the key assumptions and what evidence would test them.",
                },
                {
                    "name": "Bias Transparency",
                    "points": 13,
                    "max_points": 20,
                    "rationale": "Likely bias risks are visible but not acknowledged by the text.",
                    "trace": ["Overgeneralization risk appears in the main conclusion."],
                    "improvement_prompt": "Name the main bias risk directly and explain how it was limited.",
                },
                {
                    "name": "Framing & Audience Openness",
                    "points": 14,
                    "max_points": 20,
                    "rationale": "The framing leaves room for some critique but narrows alternatives.",
                    "trace": ["Alternative explanations are not discussed."],
                    "improvement_prompt": "Add one credible alternative explanation and how it would be evaluated.",
                },
                {
                    "name": "Positionality & Power",
                    "points": 12,
                    "max_points": 20,
                    "rationale": "The text does not clearly name who benefits from the framing.",
                    "trace": ["Stakeholder position is implied rather than named."],
                    "improvement_prompt": "Name who benefits, who is represented, and who is absent.",
                },
            ],
        },
        "biases": [
            {
                "name": "Overgeneralization",
                "kb_id": "ct:biases:methodology:overgeneralization",
                "passage": "works for all communities",
                "why_it_matters": "A narrow finding may be treated as broader than the evidence allows.",
                "three_cs_lens": "Critical",
            }
        ],
        "key_tension": "The text wants a clear action claim, but the evidence supports a narrower conclusion.",
        "recommended_next_step": "Revise the conclusion to name the population and context limits.",
        "assumptions": [
            {
                "assumption": "The sample represents the audience the text addresses.",
                "testable": "testable",
                "evidence_needed": "A broader sample or subgroup comparison.",
            }
        ],
        "alternative_frames": [
            {
                "name": "External Validity",
                "kb_id": "ct:methodology:external-validity",
                "frame": "Read the claim as context-bound until a broader sample supports transfer.",
                "three_cs_lens": "Critical",
            }
        ],
        "probing_questions": [
            "Who was included in the evidence?",
            "Who is missing from the evidence?",
            "What result would weaken the central claim?",
        ],
        "follow_up_questions": [
            "What would a skeptic ask first?",
            "What subgroup might experience this differently?",
            "What evidence would justify broader use?",
        ],
        "next_steps": [
            "Narrow the claim to the tested population.",
            "Add one alternative explanation.",
            "Identify evidence needed before scaling the conclusion.",
        ],
        "follow_up_activity": {
            "mode": "curated_file_o_fun_snapshot",
            "try_this_next": {
                "title": "Claim-Support-Question",
                "why_this_fits": "The text depends on an empirical claim whose support needs to be separated from its broader use.",
                "steps": [
                    "Pick the claim doing the most work.",
                    "Name the exact support the text gives.",
                    "Write the one question that would need an answer before relying on it.",
                ],
                "content_focus": "Use the study-result sentence and its broader-use implication.",
                "thinking_focus": ["critical"],
                "source_note": "Adapted from the local File-O-Fun teaching activity pack.",
            },
            "solo_activity": {
                "title": "Question-to-Action Research Sprint",
                "why_this_fits": "The audit points to a verification gap around sample, measure, and transfer.",
                "steps": [
                    "Turn the biggest uncertainty into one searchable question.",
                    "Name two source classes that could answer it.",
                    "Decide what result would make you trust, revise, verify, or reframe the text.",
                ],
                "content_focus": "Use the highest-priority factual or causal claim.",
                "thinking_focus": ["critical"],
                "source_note": "Adapted from the local File-O-Fun teaching activity pack.",
            },
            "group_activity": {
                "title": "Micro Lab Protocol",
                "why_this_fits": "A structured review can test whether the claim is clear, supported, and safe to use with the intended audience.",
                "steps": [
                    "Give reviewers one passage and one feedback question.",
                    "Collect what confused, concerned, or persuaded them.",
                    "Turn the feedback into one revision and one verification task.",
                ],
                "content_focus": "Use the passage most likely to affect trust or action.",
                "thinking_focus": ["critical", "compassionate"],
                "source_note": "Adapted from the local File-O-Fun teaching activity pack.",
            },
            "source_note": "Curated from a local File-O-Fun / Knowledge Atlas activity snapshot; no live Atlas lookup was performed.",
            "fit_check": {
                "prompt": "Use this, swap it, or skip activities next time?",
                "reflection_question": "What made it useful or not useful?",
                "persistence": "non_persistent",
                "no_persistence_note": "No activity outcome is saved by Critical Compass in beta.8.1.",
            },
        },
        "argument_map": {
            "plain_language_summary": "The main claim depends on treating a small empathy study as transferable evidence.",
            "central_claim": "The intervention improved empathy and can guide broader use.",
            "claim_type": "causal",
            "supporting_reasons": ["The study reports improved empathy after the intervention."],
            "objections": ["The sample is small and limited to U.S. college students."],
            "assumptions": ["The sample represents the broader audience."],
            "missing_voices": ["People outside the study population."],
            "evidence_gaps": ["Replication with a broader sample and comparison group."],
            "confidence": "medium",
            "next_questions": ["Would the result hold outside the study population?"],
            "markdown": "Central claim: The intervention improved empathy and can guide broader use.",
            "argdown": "[Central claim]: The intervention improved empathy and can guide broader use.\n  + <Study result>: The study reports improved empathy.\n  - <Scope objection>: The sample is small and narrow.",
            "status": "ready",
        },
        "checkworthy_claims": {
            "note": "Check-worthy means worth verifying, not false.",
            "claims": [
                {
                    "claim": "The intervention improved empathy.",
                    "claim_type": "factual",
                    "is_factual": True,
                    "verification_priority": "high",
                    "why_check": "This is the central empirical claim.",
                    "evidence_needed": "Study design, outcome measure, sample, and comparison group.",
                    "suggested_queries": ["\"intervention improved empathy\" study design outcome measure"],
                    "likely_source_types": ["study methods", "outcome measure", "comparison group"],
                    "support_contrast_status": "needs_evidence",
                    "uncertainty_note": "The priority flags evidence needed next, not that the claim is false.",
                    "source_anchor": "A randomized study of 42 U.S. college students",
                    "confidence": "medium",
                    "not_false_notice": "Check-worthy means this claim is worth verifying, not that it is false.",
                },
                {
                    "claim": "The finding should guide broader use.",
                    "claim_type": "policy",
                    "is_factual": False,
                    "verification_priority": "not_ranked",
                    "why_check": "Policy claims need values and constraints as well as facts.",
                    "evidence_needed": "Stakeholder impact and implementation context.",
                    "suggested_queries": ["implementation context for empathy intervention broader use"],
                    "likely_source_types": ["stakeholder impact evidence", "implementation record", "decision criteria"],
                    "support_contrast_status": "not_ranked_for_truth",
                    "uncertainty_note": "This is a policy judgment, so verification should clarify trade-offs rather than mark it true or false.",
                    "source_anchor": "broader use",
                    "confidence": "medium",
                    "not_false_notice": "Check-worthy means this claim is worth examining, not that it is false.",
                },
            ],
        },
        "external_fact_checks": {
            "note": "Optional. Attach only after explicit user authorization for factcheck_lookup.",
            "results": [
                {
                    "claim_id": "claim-1",
                    "status": "match_found",
                    "summary": "One trusted publisher review was retrieved for a closely related claim.",
                    "matches": [
                        {
                            "matched_claim_text": "The intervention improved empathy.",
                            "claimant": "Example claimant",
                            "claim_date": "2025-01-01",
                            "review": {
                                "publisher_name": "FactCheck.org",
                                "publisher_site": "factcheck.org",
                                "url": "https://factcheck.org/example",
                                "title": "Example retrieved fact check",
                                "review_date": "2025-02-01",
                                "textual_rating": "Mostly True",
                                "language_code": "en",
                            },
                            "match_confidence": 0.75,
                        }
                    ],
                    "cautions": ["Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts."],
                }
            ],
        },
        "subject_text": "A randomized study of 42 U.S. college students found the intervention improved empathy.",
        "text_type": "research",
    }
    if include_advanced:
        payload["advanced_audit"] = {
            "present": True,
            "agents": [
                {
                    "name": "Methodologist",
                    "reasoning_style": "Research validity audit",
                    "top_finding": "The strongest risk is external validity, because the conclusion outruns the sample.",
                    "kb_id": "ct:methodology:external-validity",
                }
            ],
            "dissent_ledger": [
                {
                    "agent_name": "Methodologist",
                    "top_finding": "The conclusion outruns the visible sample.",
                    "strongest_disagreement": "A practitioner lens may still treat the finding as a useful early signal.",
                    "confidence": "medium",
                    "what_would_change_mind": "A replication across broader populations with comparable measures.",
                    "provenance": "independent_analysis",
                }
            ],
            "verdict_paragraph": "The analysis supports a narrower, more cautious claim than the text currently makes.",
        }
    return payload


def report_markdown_checkpoint_template(*, include_advanced: bool = False) -> str:
    sections = [
        "# Critical Integrity Report Content Checkpoint",
        "",
        "## Plain-Language Read",
        "<1-2 sentence plain-language verdict>",
        "",
        "## Before Using This Text",
        "Before using this text, <what the reader should consider before acting>.",
        "",
        "## Pressure-Test Readiness Card",
        "- Primary action: Trust | Revise | Verify | Reframe",
        "- Rationale: <one sentence based on existing audit fields>",
        "- CIS signal: <label/points or profile-only>",
        "- Evidence: <evidence-needed signal>",
        "- Missing voice: <missing-voice risk signal>",
        "- Next move: <one concrete action>",
        "",
        "## Quick-Scan Findings",
        "- Key tension: <one sentence>",
        "- Recommended next step: <one concrete action>",
        "- Top biases: <bias name> — <why it matters>",
        "",
        "## Dimension Improvement Prompts",
        "- To strengthen Grounding & Scope Fit: <prompt>",
        "- To strengthen Assumptions & Context: <prompt>",
        "- To strengthen Bias Transparency: <prompt>",
        "- To strengthen Framing & Audience Openness: <prompt>",
        "- To strengthen Positionality & Power: <prompt>",
        "",
        "## Dimension Deep-Dive",
        "For each of the five CIS dimensions, include points/max, rationale, trace, and improvement prompt.",
        "",
        "## Assumptions",
        "- <assumption> | <testable/not testable> | <what would test it>",
        "",
        "## Alternative Frames",
        "- <frame name> (<KB ID if available>): <applied frame>",
        "",
        "## Questions",
        "1. <probing question>",
        "2. <probing question>",
        "3. <probing question>",
        "",
        "## Next Steps",
        "1. <action step>",
        "2. <action step>",
        "3. <action step>",
        "",
        "## Follow-Up Activity",
        "- Quick/chat outputs: include one compact try_this_next activity idea.",
        "- Full/advanced reports: include one solo activity and one group activity, each with title, why this fits, steps, content focus, thinking focus, and source note.",
        "- Activities come from the local File-O-Fun teaching activity pack; do not imply live Atlas lookup.",
        "",
        "## Argument Map",
        "- Central claim: <claim>",
        "- Claim type: <factual | interpretive | causal | normative | policy>",
        "- Supporting reasons: <reasons>",
        "- Objections: <objections>",
        "- Missing voices: <voices>",
        "- Evidence gaps: <evidence needed>",
        "",
        "## Evidence Needed Next",
        "- Check-worthy factual claim: <claim> | Priority: <high/medium/low> | Evidence needed: <evidence>",
        "- Interpretive, causal, normative, and policy claims may be classified here but are not ranked as factual verification targets.",
        "- Check-worthy means worth verifying, not false.",
        "",
        "## External Fact Checks (optional)",
        "- Include only if factcheck_lookup was explicitly authorized and returned real trusted matches.",
        "- Publisher rating: <quote verbatim> | URL: <direct review link> | Status: <match_found/multiple_matches/conflicting_reviews>",
        "- Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.",
    ]
    if include_advanced:
        sections.extend(
            [
                "",
                "## Agent Findings",
                "- <Agent name> (<reasoning style>) -> <top finding> -> <KB ID if available>",
                "",
                "## Dissent Ledger",
                "- <Agent name> -> Top finding: <finding> -> Strongest disagreement: <disagreement> -> Confidence: <low/medium/high> -> Would change mind if: <evidence>",
            ]
        )
    return "\n".join(sections)


def report_readiness_contract(depth: str | None = None, *, stage: str = "audit", include_advanced: bool = False) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    return {
        "status": "report_contract_ready",
        "stage": stage,
        "purpose": "Use this before generate_audit_report so the host AI compiles the full report payload once, with canonical labels.",
        "canonical_payload_rule": "Use the canonical keys in canonical_audit_data_template. Accepted aliases are compatibility fallbacks only, not the preferred authoring schema.",
        "full_report_required_fields": [
            "critical_integrity_snapshot.label or profile_only display_state",
            "critical_integrity_snapshot.points or profile_only withheld reason",
            "critical_integrity_snapshot.plain_language_read",
            "critical_integrity_snapshot.before_using_this_text",
            "critical_integrity_snapshot.dimensions[] exactly five entries with name, points, max_points, rationale, trace, and improvement_prompt",
            "biases[] with name, passage, why_it_matters, and lens",
            "key_tension",
            "recommended_next_step",
            "assumptions[]",
            "alternative_frames[]",
            "probing_questions[] at least three items",
            "follow_up_questions[] at least three items",
            "next_steps[] at least three meaningful action items",
            "follow_up_activity with a compact try_this_next idea; full/advanced reports also need solo_activity and group_activity",
            "argument_map when available, with central_claim, claim_type, support, objections, assumptions, missing_voices, evidence_gaps, next_questions, Markdown, and .argdown export",
            "checkworthy_claims when available, with factual claims ranked separately from interpretive, causal, normative, and policy claims",
            "external_fact_checks only when factcheck_lookup was explicitly authorized and returned real trusted matches",
            "advanced_audit.agents[].top_finding when advanced_audit agents were used",
            "advanced_audit.dissent_ledger when advanced_audit agents disagree or confidence differs materially",
        ],
        "pre_call_checklist": [
            "Do not call generate_audit_report until every required field is populated or the user explicitly authorizes allow_placeholders=true.",
            "Use canonical field names, especially biases, key_tension, points, max_points, improvement_prompt, and advanced_audit.agents[].top_finding.",
            "Reject numeric-only next steps such as '1', '2', or '3'.",
            "If human_loop_host_action.must_pause is true for mode_consent, onboarding, judgment, or reflection, ask only the current block through native question UI before final PDF generation unless this is an explicitly noninteractive smoke test.",
            "For full reports, write a Markdown checkpoint from markdown_checkpoint_template before the tool call unless the caller explicitly requested a noninteractive smoke test.",
            "If argument_map or checkworthy_claims are present in the audit output, pass them through with canonical keys; do not summarize them away.",
            "Use 'check-worthy means worth verifying, not false' whenever presenting checkworthy_claims.",
            "Ensure every audit-facing output includes Plain-Language Read and a Before Using This Text sentence starting exactly with 'Before using this text,'.",
            "For full reports, include one solo and one group follow-up activity from the local activity pack; for quick/chat outputs include at most one compact try_this_next idea.",
            "Do not call factcheck_lookup unless the user explicitly authorizes external lookup; attach returned results under external_fact_checks without changing the Critical Compass verdict.",
            "Preserve dissent_ledger entries instead of flattening them into consensus.",
            "Call generate_audit_report at most once. If it returns blocked/warnings, show those diagnostics and wait for user approval before regenerating.",
        ],
        "report_preflight_card": {
            "purpose": "Friendly UX layer returned by generate_audit_report when readiness passes or blocks.",
            "shows": ["complete_sections", "missing_fields", "top_fixes", "paste_ready_resubmit_prompt"],
            "strict_gate_note": "This card explains the strict readiness gate; it does not loosen validation or authorize placeholder output.",
        },
        "markdown_first_protocol": {
            "required_for_depth": "full",
            "current_depth": depth_value,
            "rule": "The host AI should compile the content as Markdown first, verify the required headings and fields, then pass the same content in canonical audit_data.",
        },
        "canonical_audit_data_template": report_payload_template(include_advanced=include_advanced),
        "complete_payload_example": report_payload_example(include_advanced=include_advanced),
        "markdown_checkpoint_template": report_markdown_checkpoint_template(include_advanced=include_advanced),
        "accepted_aliases": REPORT_ACCEPTED_ALIASES,
        "post_call_rules": [
            "If qa_status is blocked, present missing_report_fields and what_to_resubmit; do not present a PDF.",
            "If schema_warnings are present, ask whether to re-submit missing fields or continue with placeholders.",
            "Never present allow_placeholders=true output as a final polished report.",
            "If report generation succeeds, present report_path, markdown_path, manifest_path, and viewer_path together.",
            "Use generate_audit_artifact_viewer(manifest_path) only when rebuilding or opening a viewer from an existing report manifest; do not use it to create new findings.",
            "Never regenerate the PDF more than once without explicit user approval.",
        ],
    }


STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "the",
    "to",
    "with",
}


BIAS_TRIGGER_RULES: list[tuple[str, list[str]]] = [
    ("confirmation bias", ["confirming evidence", "cherry-pick", "already believe", "fits my view"]),
    ("anchoring bias", ["anchor", "anchored", "first offer", "starting point", "initial number"]),
    ("availability bias", ["recent", "vivid", "memorable", "headline", "easy to recall"]),
    ("framing effect", ["framed", "wording", "loss vs gain", "presented as"]),
    ("authority bias", ["expert says", "doctor says", "ceo says", "because authority"]),
    ("bandwagon", ["everyone", "most people", "popular", "trending", "everybody"]),
    ("halo effect", ["good at one thing", "must be good at", "halo"]),
    ("hindsight bias", ["knew it all along", "obvious after", "should have known"]),
    ("sunk cost", ["already spent", "can't waste", "too much invested", "keep going because"]),
    ("status quo bias", ["keep things as they are", "don't change", "leave it alone"]),
    ("negativity bias", ["only bad", "all the bad", "focus on the negative"]),
    ("recency bias", ["recent event", "lately", "the last thing", "most recent"]),
    ("base rate neglect", ["one case", "one story", "vivid story", "typical example"]),
    ("selection bias", ["surveyed only", "sampled only", "selected cases", "non-representative"]),
    ("automation bias", ["the model said", "system said", "automation said", "let the ai decide"]),
    ("algorithmic bias", ["different outcomes by group", "dialect", "fairness", "parity"]),
    ("in-group bias", ["people like us", "our side", "their side", "outsiders"]),
    ("fundamental attribution error", ["they are just", "they are lazy", "they are careless"]),
    ("survivorship bias", ["only the winners", "survivors", "success stories only"]),
    ("overconfidence bias", ["definitely", "certainly", "no doubt", "absolutely sure"]),
]


BIAS_FALLBACK_RULES: list[tuple[str, list[str]]] = [
    ("status quo bias", ["natural next step", "continuity", "slower options", "stay the course", "keep things as they are", "same path"]),
    ("framing effect", ["presents as", "frames as", "path forward", "stresses", "emphasizes"]),
    ("bandwagon effect", ["aligned", "alignment", "consensus", "everyone on board", "broad support", "keeping everyone aligned"]),
    ("authority bias", ["leadership team", "experts", "officials", "leaders"]),
    ("sunk cost fallacy", ["months of discussion", "already invested", "so much work", "can't stop now", "cannot stop now"]),
    ("confirmation bias", ["fits our view", "reinforces our view", "confirms", "already believe"]),
    ("availability bias", ["recent", "memorable", "vivid", "headline"]),
    ("selection bias", ["does not compare", "selected", "excluded", "only looks at"]),
]

FALLACY_STEELMAN_RISKS = {
    "false dilemma": "A choice can be genuinely binary when explicit constraints have already ruled out viable alternatives.",
    "causal overreach": "A causal claim can be reasonable when timing, mechanism, comparison, and alternative explanations all point the same way.",
    "unsupported certainty": "High confidence can be warranted when direct evidence is strong, current, and well-bounded.",
    "ad hominem": "A person's credibility can matter when the claim depends on relevant expertise, trust, or conflicts of interest.",
    "bandwagon": "Popularity can be a useful proxy when the crowd has relevant expertise or independent access to evidence.",
    "appeal to authority": "Expert testimony is useful when the authority is in-scope and the underlying evidence is transparent.",
    "hasty generalization": "A small sample can still be suggestive when it is representative and the claim is carefully bounded.",
    "slippery slope": "Escalation concerns can be valid when each step has a plausible mechanism and probability.",
    "straw man": "A compressed summary can be fair when it preserves the strongest version of the opposing view.",
    "circular reasoning": "A claim can look circular when premises were shortened too aggressively or established elsewhere.",
    "argument from ignorance": "Missing disconfirmation can matter when evidence is genuinely hard to obtain and uncertainty is stated plainly.",
}

TEXT_TYPES = {
    "general",
    "advocacy",
    "policy",
    "sales",
    "research",
    "journalism",
    "narrative",
    "social_media",
    "academic_abstract",
    "product_copy",
    "legal",
    "ai_generated",
}
TEXT_TYPE_DESCRIPTIONS = {
    "general": "General-purpose text without a more specific audit lane.",
    "advocacy": "Mission, campaign, nonprofit, movement, or values-forward text.",
    "policy": "Policy, governance, regulation, public-program, or institutional decision text.",
    "sales": "Sales, pitch, competitive, ROI, prospect, or market-facing text.",
    "research": "Research, study, methods, evidence, or methodology-shaped text.",
    "journalism": "News, reporting, article, newsroom, or public-information text.",
    "narrative": "Story, memoir, scene, testimony, or narrative-shaped text.",
    "social_media": "Short public posts, threads, captions, replies, or platform-native copy.",
    "academic_abstract": "Abstracts and compressed scholarly summaries; routes through research-methodology checks.",
    "product_copy": "Product, landing-page, feature, positioning, CTA, or conversion copy.",
    "legal": "Legal-style, compliance, contract, terms, policy, or rights-and-obligations text; this is not legal advice.",
    "ai_generated": "AI-generated or AI-polished text where synthetic certainty, LLM bias, and provenance should be checked.",
}
TEXT_TYPE_OPTIONS = ", ".join(TEXT_TYPE_DESCRIPTIONS)
RESEARCH_TEXT_TYPES = {"research", "academic_abstract"}
PERSUASIVE_TEXT_TYPES = {"advocacy", "policy", "sales", "product_copy", "social_media"}
SYNTHESIS_AUDIENCES = {"reader", "author", "both"}
SNAPSHOT_MODES = {"organizer", "research"}
AUDIT_DEPTHS = {"quick", "standard", "deep"}
SCAFFOLD_DETAILS = {"compact", "full", "handoff"}
RETRIEVAL_PROFILES = {"auto", "general", "research_methodology"}
HUMAN_LOOP_MODES = {"guided", "minimal", "silent"}
KB_ADDITION_STATUSES = {"draft", "active", "inactive"}
RHETORICAL_TRADITIONS = {
    "western_academic",
    "testimonial",
    "indigenous_oral",
    "ubuntu",
    "confucian",
    "liberation_pedagogy",
    "other",
}
AUDIT_RESUME_STAGES = {"agent_definition", "independent_analysis", "tension_map", "debate", "synthesis"}
AGENTIC_PROGRESS_STAGES = [
    "plan_review",
    "agent_definition",
    "independent_analysis",
    "tension_map",
    "debate",
    "synthesis",
    "mitigation_rewrite",
    "reflection",
    "report_ready",
]
AGENTIC_HOST_ADAPTERS = {
    "claude_native_subagents",
    "codex_explicit_subagents",
    "sequential_labeled_fallback",
    "scaffold_only",
}
AUDIT_REASONING_STYLES = [
    "Chain of Thought",
    "Tree of Thought",
    "Socratic Questioning",
    "Systems Thinking",
    "Steelman-first",
    "Missing Voice",
]
AUDIT_THREE_CS = ["Critical", "Compassionate", "Creative"]
SNAPSHOT_DIMENSIONS = [
    ("grounding_scope_fit", "Grounding & Scope Fit"),
    ("assumptions_context", "Assumptions & Context"),
    ("bias_transparency", "Bias Transparency"),
    ("framing_audience_openness", "Framing & Audience Openness"),
    ("positionality_power", "Positionality & Power"),
]

RESEARCH_PROFILE_CUES = {
    "sample",
    "participants",
    "cohort",
    "population",
    "survey",
    "experiment",
    "experimental",
    "randomized",
    "randomised",
    "control",
    "intervention",
    "regression",
    "p value",
    "p-value",
    "confidence interval",
    "effect size",
    "methods",
    "methodology",
    "limitations",
    "discussion",
    "replication",
    "replicability",
    "validity",
    "generalizability",
    "generalisability",
    "external validity",
    "construct validity",
    "measurement validity",
    "statistical power",
    "preregistration",
    "pre registration",
    "pre-registration",
}

RESEARCH_METHODOLOGY_BIAS_NAMES = [
    "WEIRD bias",
    "Demand characteristics",
    "Social desirability bias",
    "Overgeneralization",
    "Publication bias",
    "P-hacking",
    "HARKing",
    "Sampling bias",
    "Selection bias",
    "Nonresponse bias",
    "Attrition bias",
    "Citation bias",
    "Spin bias",
    "Outcome reporting bias",
    "Sponsorship bias",
    "Recall bias",
    "Source monitoring error",
]

RESEARCH_VALIDITY_CONCEPT_NAMES = [
    "Construct validity",
    "External validity",
    "Ecological validity",
    "Measurement validity",
    "Internal validity",
    "Replicability",
    "Preregistration",
    "Statistical power",
]

PERSUASIVE_BIAS_CUES: list[dict[str, Any]] = [
    {
        "bias": "framing effect",
        "confidence": "high",
        "cues": [
            "none of the other",
            "no other framework",
            "other frameworks were not",
            "not built for",
            "only framework",
            "only model",
            "built for this sector",
            "unlike other frameworks",
        ],
        "reason": "The text frames alternatives as structurally inadequate while positioning one option as uniquely fit.",
    },
    {
        "bias": "overconfidence effect",
        "confidence": "medium",
        "cues": [
            "will ensure",
            "will solve",
            "guarantees",
            "must adopt",
            "cannot afford",
            "eliminate the risk",
            "always",
            "never",
            "the only path",
        ],
        "reason": "The text presents a strong outcome or necessity claim with more certainty than the visible evidence supports.",
    },
    {
        "bias": "self-serving bias",
        "confidence": "medium",
        "cues": [
            "our framework",
            "our model",
            "we are uniquely",
            "we alone",
            "created specifically",
            "designed specifically",
            "built by practitioners",
        ],
        "reason": "The text gives special explanatory weight to the author's own framework, model, or position.",
    },
    {
        "bias": "availability cascade",
        "confidence": "medium",
        "cues": [
            "existential threat",
            "urgent crisis",
            "sector crisis",
            "collapse",
            "survival",
            "at stake",
            "cannot wait",
        ],
        "reason": "The text escalates urgency in a way that may make the most vivid risk feel more settled than shown.",
    },
    {
        "bias": "false consensus effect",
        "confidence": "medium",
        "cues": [
            "everyone knows",
            "the sector needs",
            "communities want",
            "stakeholders agree",
            "most organizations",
            "most people",
            "all leaders",
        ],
        "reason": "The text may treat a preferred or assumed audience view as broadly shared.",
    },
    {
        "bias": "selection bias",
        "confidence": "medium",
        "cues": [
            "we compared four",
            "four frameworks",
            "selected examples",
            "case studies show",
            "benchmarking shows",
            "our comparison shows",
        ],
        "reason": "The text may depend on a selected comparison set without showing why that set is representative.",
    },
]

AI_DATA_RISK_CUES: list[dict[str, Any]] = [
    {
        "risk": "hallucination_confidence",
        "label": "Hallucination-confidence risk",
        "cues": ["clearly shows", "proves", "definitely", "always", "never", "ready for immediate adoption"],
        "why": "The text sounds settled before showing source-to-claim support.",
        "next_check": "Verify which source supports the strongest factual claim.",
    },
    {
        "risk": "provenance_gap",
        "label": "Provenance-gap risk",
        "cues": ["ai-generated", "chatgpt", "generated summary", "summary shows", "the report proves"],
        "why": "The text does not show how generated claims map back to original sources.",
        "next_check": "Ask for source coverage, citations, and claim-by-claim traceability.",
    },
    {
        "risk": "sycophancy_risk",
        "label": "Sycophancy risk",
        "cues": ["as requested", "your recommendation is", "confirms your", "supports your plan"],
        "why": "The text may be over-aligning with the requester instead of testing the claim.",
        "next_check": "Ask for the strongest objection or disconfirming evidence.",
    },
    {
        "risk": "metric_or_benchmark_bias",
        "label": "Metric or benchmark bias",
        "cues": ["benchmark", "score", "metric", "accuracy", "performance", "evaluation"],
        "why": "A metric may be treated as real-world fit without checking the evaluation context.",
        "next_check": "Check what the metric measured, whose cases it missed, and whether it matches deployment conditions.",
    },
    {
        "risk": "dataset_shift",
        "label": "Dataset-shift risk",
        "cues": ["all residents", "all users", "statewide", "nationwide", "every community"],
        "why": "The text may generalize from one data context to a different audience or setting.",
        "next_check": "Bound the claim to the source population and check where conditions differ.",
    },
    {
        "risk": "evaluation_bias",
        "label": "Evaluation-bias risk",
        "cues": ["evaluation", "test set", "leaderboard", "judge", "scoring"],
        "why": "An evaluation may favor cases that do not match the intended audience or real-world task.",
        "next_check": "Check who or what was evaluated, what was excluded, and whether the test matches use conditions.",
    },
    {
        "risk": "representation_bias",
        "label": "Representation-bias risk",
        "cues": ["representative", "underrepresented", "training data", "coverage", "non-english"],
        "why": "The data or evidence pool may not represent people affected by the conclusion.",
        "next_check": "Ask who is represented in the data and who is affected by the decision.",
    },
]

KB_NO_RESULT_RECOVERY_PATTERNS: list[dict[str, Any]] = [
    {
        "topic": "memory bias",
        "cues": ["memory", "recall", "remember", "misinformation"],
        "try_narrower_queries": ["false memory", "misinformation effect", "source monitoring", "recall bias", "availability heuristic"],
        "category_filters": ["biases"],
        "adjacent_concepts": ["suggestibility", "telescoping effect", "hindsight bias"],
    },
    {
        "topic": "AI bias",
        "cues": ["ai", "llm", "model", "algorithm", "automation", "synthetic"],
        "try_narrower_queries": ["automation bias", "algorithmic bias", "hallucination confidence", "sycophancy", "dataset shift"],
        "category_filters": ["biases", "methodology-checks"],
        "adjacent_concepts": ["metric bias", "benchmark bias", "evaluation bias", "representation bias"],
    },
    {
        "topic": "social or intergroup bias",
        "cues": ["social", "group", "community", "intergroup", "culture"],
        "try_narrower_queries": ["in-group bias", "false consensus effect", "dehumanization bias", "bandwagon effect"],
        "category_filters": ["biases", "thinking-lenses"],
        "adjacent_concepts": ["missing voices", "stakeholder harm benefit", "cross-cultural anti-flattening"],
    },
    {
        "topic": "research evidence bias",
        "cues": ["research", "study", "evidence", "sample", "validity", "method"],
        "try_narrower_queries": ["p-hacking", "HARKing", "publication bias", "WEIRD bias", "attrition bias", "nonresponse bias", "citation bias", "spin bias", "outcome reporting bias"],
        "category_filters": ["biases", "methodology-checks"],
        "adjacent_concepts": ["construct validity", "external validity", "measurement validity", "statistical power", "sponsorship bias", "recall bias", "source monitoring error"],
    },
]

MITIGATION_VERB_RULES: list[dict[str, Any]] = [
    {
        "verb": "ask",
        "keywords": ["authority", "expert", "missing voice", "stakeholder", "positionality", "cultural"],
        "strategy": "Ask who is affected, who is quoted, and whose evidence has standing.",
        "why": "Missing authority, voice, or standing can make a text sound more settled than it is.",
    },
    {
        "verb": "compare",
        "keywords": ["framing", "selection", "availability", "false consensus", "bandwagon"],
        "strategy": "Compare the strongest alternative frame before treating this one as the default.",
        "why": "A comparison step keeps one frame or selected example from doing all the work.",
    },
    {
        "verb": "bound",
        "keywords": ["overconfidence", "causal", "generalization", "overgeneralization", "dunning"],
        "strategy": "Bound the claim to the visible sample, context, and evidence strength.",
        "why": "Strong claims become safer when their scope matches their support.",
    },
    {
        "verb": "check",
        "keywords": ["base rate", "metric", "benchmark", "statistical", "measurement", "denominator"],
        "strategy": "Check the denominator, baseline, metric definition, and comparison group.",
        "why": "Numbers persuade quickly when the measurement frame is hidden.",
    },
    {
        "verb": "disclose",
        "keywords": ["automation", "algorithmic", "ai", "llm", "data", "provenance"],
        "strategy": "Disclose AI mediation, source coverage, uncertainty, and what was not verified.",
        "why": "AI-mediated text needs traceability before readers rely on polished claims.",
    },
    {
        "verb": "test",
        "keywords": ["confirmation", "belief", "anchoring", "status quo", "sunk cost"],
        "strategy": "Name the evidence that would change the conclusion, then look for it first.",
        "why": "A disconfirmation test prevents the preferred answer from becoming the only answer.",
    },
]

RESEARCH_METHODOLOGY_CUE_RULES: dict[str, list[str]] = {
    "weird": ["weird", "college students", "undergraduates", "university students", "western sample", "online sample", "mturk", "prolific", "humans in general"],
    "demand": ["demand characteristics", "participants guessed", "guess the hypothesis", "hypothesis awareness", "not blinded", "researcher cues", "experimenter cues", "expected response"],
    "social desirability": ["social desirability", "self report", "self-report", "survey", "questionnaire", "sensitive topic", "anonymous", "stigma", "desirable responding"],
    "overgeneralization": ["overgeneralization", "generalize", "generalise", "all people", "all users", "all communities", "universal", "proves", "sample"],
    "publication": ["publication bias", "file drawer", "published studies", "significant results", "null results", "failed replications", "literature review"],
    "p hacking": ["p-hacking", "p hacking", "multiple comparisons", "many tests", "p value", "p-value", "significance threshold", "researcher degrees"],
    "harking": ["harking", "hypothesizing after", "hypothesis after", "post hoc hypothesis", "exploratory finding", "unexpected finding"],
    "nonresponse": ["nonresponse", "non-response", "response rate", "respondents", "survey nonresponse", "missing responses"],
    "attrition": ["attrition", "dropout", "lost to follow up", "lost to follow-up", "excluded participants", "missing follow up"],
    "sampling": ["sampling bias", "selection bias", "sample", "sampling", "recruited", "selected participants", "representative", "population"],
    "citation": ["citation bias", "selective citation", "studies show", "experts say", "widely cited", "sources agree", "failed replications"],
    "spin": ["spin bias", "breakthrough", "game changer", "proves", "findings mean", "headline", "the findings show everyone should"],
    "outcome reporting": ["outcome reporting bias", "selective outcome", "top-line result", "key metric", "planned outcomes", "highlighted outcomes"],
    "sponsorship": ["sponsorship bias", "funded by", "sponsored by", "vendor report", "internal study", "partner research", "conflict of interest"],
    "recall": ["recall bias", "remembered", "self-reported", "self reported", "retrospective", "reported past behavior"],
    "source monitoring": ["source monitoring", "source confusion", "it is well known", "widely reported", "i heard", "sources say"],
}


DOMAIN_HINTS = {
    "research study/report": [
        "study",
        "report",
        "participants",
        "sample",
        "randomized",
        "trial",
        "methods",
        "results",
        "p-value",
        "effect size",
        "analysis",
        "survey",
    ],
    "email": ["subject:", "dear ", "hi ", "hello ", "best,", "thanks,", "regards,", "re:"],
    "social media post": ["#", "@", "retweet", "threads", "likes", "followers", "viral"],
    "speech excerpt": ["ladies and gentlemen", "thank you", "my fellow", "today we", "we gather", "remarks"],
    "news article": ["according to", "reported", "the article", "sources said", "journalist", "headline"],
}


FALLBACK_FRAME_QUERIES = {
    "research study/report": [
        "systematic review & meta-analysis",
        "triangulation methods",
        "cross-cultural anti-flattening",
        "two-eyed seeing",
    ],
    "email": [
        "argument mapping",
        "socratic questioning method",
        "reciprocity stewardship",
    ],
    "social media post": [
        "source quality check",
        "cross-cultural anti-flattening",
        "argument mapping",
    ],
    "speech excerpt": [
        "toulmin’s argument model",
        "argument mapping",
        "ganma knowledge confluence",
    ],
    "news article": [
        "argument mapping",
        "source quality check",
        "all my relations",
    ],
    "default": [
        "argument map",
        "systems thinking",
        "pre-mortem",
        "all my relations",
        "reciprocity stewardship",
        "cross-cultural anti-flattening",
        "first principles",
    ],
}

TECH_GOVERNANCE_FRAME_QUERIES = [
    "accountability ai decisions",
    "systems thinking",
    "cynefin",
    "complex adaptive systems",
    "soft systems methodology",
    "stakeholder harm benefit",
    "intersectionality",
    "pre mortem",
    "ladder of inference",
    "argument map",
]

STRUCTURAL_FRAME_QUERIES = [
    "stakeholder harm benefit",
    "intersectionality",
    "ethical data stewardship",
    "conscientization",
    "collective impact",
]

SYSTEMS_FRAME_QUERIES = [
    "systems thinking",
    "cynefin",
    "complex adaptive systems",
    "soft systems methodology",
    "dependent origination",
]


FOLLOW_UP_BY_DOMAIN = {
    "research study/report": [
        "What was the sample, and how was it selected?",
        "Which outcomes were measured, and which were not?",
        "What would count as a stronger comparison or control?",
    ],
    "email": [
        "What context is missing from the thread or reply chain?",
        "What action is being asked for, and what would make it safer to accept?",
        "What evidence would change your read on the intent?",
    ],
    "social media post": [
        "What is the original source, not just the repost?",
        "What context was trimmed away before the claim reached you?",
        "What would you need to verify before sharing this further?",
    ],
    "speech excerpt": [
        "What claim is the speaker actually trying to support?",
        "What audience pressure or framing is shaping the delivery?",
        "What missing evidence would you want before agreeing?",
    ],
    "news article": [
        "What source or data is the article relying on?",
        "What other explanations does the article not rule out?",
        "What would you need to verify before treating this as settled?",
    ],
    "default": [
        "What context is missing from the excerpt?",
        "What would weaken the strongest version of this claim?",
        "What evidence would you want before acting on it?",
    ],
}


def normalize_text(value: str | None) -> str:
    if not value:
        return ""
    text = unicodedata.normalize("NFKC", value)
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def make_text_id(text: str) -> str:
    normalized = re.sub(r"\s+", " ", (text or "").strip())
    return f"text:{sha256_text(normalized)[:24]}"


def make_record_id(prefix: str) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"{prefix}:{timestamp}:{uuid4().hex[:10]}"


def json_dumps(value: Any) -> str:
    return json.dumps(value if value is not None else {}, ensure_ascii=False, sort_keys=True)


def tokenize(value: str | None) -> list[str]:
    return [part for part in normalize_text(value).split() if part and part not in STOPWORDS]


def first_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for item in value.values():
            text = first_text(item)
            if text:
                return text
        return ""
    if isinstance(value, (list, tuple, set)):
        for item in value:
            text = first_text(item)
            if text:
                return text
        return ""
    return str(value).strip()


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return [item for item in value if item not in (None, "", [], {})]
    if isinstance(value, tuple):
        return [item for item in value if item not in (None, "", [], {})]
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    return [value]


def normalize_flow_namespace(value: str | None) -> str:
    namespace_norm = normalize_text(value)
    if namespace_norm in {"epistemic core", "core", "epistemic"}:
        return FLOW_NAMESPACE_EPISTEMIC_CORE
    if namespace_norm in {"applied reasoning", "applied", "task", "tasks"}:
        return FLOW_NAMESPACE_APPLIED_REASONING
    return ""


def flow_namespace(flow: dict[str, Any]) -> str:
    namespace = normalize_flow_namespace(first_text(flow.get("namespace")))
    if namespace:
        return namespace

    title = normalize_text(flow.get("entry_title"))
    kind = normalize_text(flow.get("kind"))
    if kind == "task" or any(term in title for term in ["bdd given when then", "user stories acceptance criteria"]):
        return FLOW_NAMESPACE_APPLIED_REASONING
    return FLOW_NAMESPACE_EPISTEMIC_CORE


def flatten_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        return " ".join(filter(None, (flatten_text(item) for item in value.values())))
    if isinstance(value, (list, tuple, set)):
        return " ".join(filter(None, (flatten_text(item) for item in value)))
    return str(value)


def text_blob(*values: Any) -> str:
    pieces = [flatten_text(value) for value in values]
    return " ".join(piece for piece in pieces if piece).strip()


def parse_json_field(value: Any, default: list[Any] | None = None) -> list[Any]:
    if value in (None, "", []):
        return list(default or [])
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError:
            return [value]
        if isinstance(loaded, list):
            return loaded
        return [loaded]
    return [value]


def load_row_json(row: sqlite3.Row) -> dict[str, Any]:
    data = dict(row)
    for key in (
        "examples_json",
        "aliases_json",
        "related_json",
        "when_to_use_json",
        "failure_modes_json",
        "signals_json",
        "anti_patterns_json",
        "quality_flags_json",
        "provenance_json",
    ):
        data[key] = parse_json_field(data.get(key), [])
    return data


def word_count(text: str) -> int:
    return len([part for part in re.split(r"\s+", text.strip()) if part])


def split_sentences(text: str) -> list[str]:
    pieces = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [piece.strip() for piece in pieces if piece.strip()]


def cap_words(text: str, max_words: int) -> str:
    words = [part for part in re.split(r"\s+", text.strip()) if part]
    if len(words) <= max_words:
        return " ".join(words)
    return " ".join(words[:max_words])


def short_phrase(text: str, max_words: int = 12) -> str:
    return cap_words(re.sub(r"\s+", " ", text.strip()), max_words)


def sentence_with_trigger(sentence: str, trigger: str) -> str:
    trigger_norm = normalize_text(trigger)
    if not trigger_norm:
        return short_phrase(sentence)
    words = sentence.split()
    for index, word in enumerate(words):
        if trigger_norm in normalize_text(word):
            start = max(index - 4, 0)
            end = min(index + 8, len(words))
            return short_phrase(" ".join(words[start:end]))
    return short_phrase(sentence)


def join_unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        clean = value.strip()
        if not clean:
            continue
        key = normalize_text(clean)
        if key in seen:
            continue
        seen.add(key)
        result.append(clean)
    return result


def confidence_weight(value: Any) -> str:
    if isinstance(value, str) and value.lower() in {"low", "medium", "high"}:
        return value.lower()
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return "medium"
    if numeric >= 0.85:
        return "high"
    if numeric >= 0.65:
        return "medium"
    return "low"


def detect_sensitivity(text: str, sensitivity: str | None) -> tuple[str, list[str]]:
    if sensitivity and sensitivity.lower() == "high":
        return "high", ["user requested high sensitivity"]
    lowered = text.lower()
    signals: list[str] = []
    high_terms = [
        "election",
        "politic",
        "government",
        "policy",
        "vote",
        "voter",
        "president",
        "congress",
        "senate",
        "immigration",
        "health",
        "medical",
        "patient",
        "diagnosis",
        "treatment",
        "vaccine",
        "identity",
        "race",
        "racial",
        "gender",
        "transgender",
        "queer",
        "lgbt",
        "religion",
        "disability",
        "ethnic",
        "indigenous",
    ]
    for term in high_terms:
        if term in lowered:
            signals.append(term)
    return ("high", signals) if signals else ("low", [])


def detect_domain(text: str) -> tuple[str, list[str]]:
    lowered = text.lower()
    for domain, hints in DOMAIN_HINTS.items():
        if any(hint in lowered for hint in hints):
            return domain, [hint for hint in hints if hint in lowered][:3]
    if len(text.split()) <= 40:
        return "short-form claim", []
    return "general text", []


def normalize_text_type(value: str | None) -> str:
    text_type = normalize_text(value).replace(" ", "_")
    aliases = {
        "other": "general",
        "other_general": "general",
        "advocacy_doc": "advocacy",
        "advocacy_document": "advocacy",
        "persuasive": "advocacy",
        "persuasive_document": "advocacy",
        "consulting": "sales",
        "sales_doc": "sales",
        "sales_document": "sales",
        "policy_doc": "policy",
        "policy_document": "policy",
        "research_report": "research",
        "study": "research",
        "scholarly": "academic_abstract",
        "scholarly_abstract": "academic_abstract",
        "abstract": "academic_abstract",
        "paper_abstract": "academic_abstract",
        "academic": "academic_abstract",
        "news": "journalism",
        "article": "journalism",
        "story": "narrative",
        "storytelling": "narrative",
        "narrative_doc": "narrative",
        "narrative_document": "narrative",
        "tweet": "social_media",
        "thread": "social_media",
        "post": "social_media",
        "social": "social_media",
        "social_post": "social_media",
        "social_media_post": "social_media",
        "linkedin": "social_media",
        "product": "product_copy",
        "product_marketing": "product_copy",
        "marketing": "product_copy",
        "landing_page": "product_copy",
        "landing_page_copy": "product_copy",
        "copy": "product_copy",
        "legal_doc": "legal",
        "legal_document": "legal",
        "contract": "legal",
        "terms": "legal",
        "terms_of_service": "legal",
        "compliance_doc": "legal",
        "ai": "ai_generated",
        "ai_text": "ai_generated",
        "ai_generated_text": "ai_generated",
        "llm": "ai_generated",
        "llm_generated": "ai_generated",
        "synthetic": "ai_generated",
    }
    text_type = aliases.get(text_type, text_type)
    return text_type if text_type in TEXT_TYPES else ""


def infer_text_type(text: str, domain: str) -> str:
    lowered = text.lower()
    normalized = normalize_text(text)
    if text_has_any(lowered, ["chatgpt", "claude", "gemini", "llm-generated", "ai-generated", "generated by ai", "written by ai", "model output"]):
        return "ai_generated"
    if text_has_any(lowered, ["abstract:", "background:", "methods:", "results:", "conclusion:", "doi:", "keywords:"]) and word_count(text) <= 350:
        return "academic_abstract"
    if is_study_report(text):
        return "research"
    if domain == "news article" or any(term in lowered for term in ["reported by", "according to officials", "newsroom", "journalist"]):
        return "journalism"
    if text_has_any(lowered, ["whereas", "hereby", "shall", "terms of service", "privacy policy", "contract", "agreement", "compliance", "liability", "jurisdiction"]):
        return "legal"
    if text_has_any(lowered, ["sign up", "try it", "buy now", "features", "pricing", "cta", "landing page", "product", "customers choose", "conversion"]):
        return "product_copy"
    if text_has_any(lowered, ["retweet", "repost", "like and share", "follow for", "thread:", "link in bio", "#", "@"]) or (word_count(text) <= 80 and text_has_any(normalized, ["post", "thread", "caption"])):
        return "social_media"
    if any(term in lowered for term in ["policy", "regulation", "legislation", "public program", "government", "compliance"]):
        return "policy"
    if any(term in lowered for term in ["buy", "sales", "customer", "competitive", "market", "prospect", "pricing", "roi"]):
        return "sales"
    if any(term in lowered for term in ["story", "narrative", "scene", "character", "memoir", "case narrative"]):
        return "narrative"
    if any(
        term in lowered
        for term in [
            "nonprofit",
            "mission",
            "movement",
            "advocacy",
            "sector",
            "community voices",
            "equity",
            "justice",
            "framework",
        ]
    ):
        return "advocacy"
    return "general"


def resolve_text_type(text: str, domain: str, text_type: str | None) -> tuple[str, str]:
    explicit = normalize_text_type(text_type)
    if explicit:
        return explicit, "explicit"
    return infer_text_type(text, domain), "inferred"


def normalize_synthesis_audience(value: str | None) -> str:
    audience = normalize_text(value)
    if audience in SYNTHESIS_AUDIENCES:
        return audience
    return "both"


def normalize_snapshot_mode(value: str | None) -> str:
    mode = normalize_text(value)
    aliases = {
        "": "organizer",
        "community": "organizer",
        "nonprofit": "organizer",
        "non_profit": "organizer",
        "ngo": "organizer",
        "organiser": "organizer",
        "academic": "research",
        "researcher": "research",
        "peer_review": "research",
    }
    mode = aliases.get(mode, mode)
    return mode if mode in SNAPSHOT_MODES else "organizer"


def normalize_audit_depth(value: str | None) -> str:
    depth = normalize_text(value)
    aliases = {
        "": "standard",
        "normal": "standard",
        "full": "standard",
        "default": "standard",
        "fast": "quick",
        "scan": "quick",
        "quick_scan": "quick",
        "deeper": "deep",
        "expanded": "deep",
    }
    depth = aliases.get(depth, depth)
    return depth if depth in AUDIT_DEPTHS else "standard"


def normalize_human_loop_mode(value: str | None) -> str:
    mode = normalize_text(value)
    aliases = {
        "": "guided",
        "default": "guided",
        "interactive": "guided",
        "questions": "guided",
        "yes": "guided",
        "yes guided": "guided",
        "not sure": "guided",
        "not sure guided": "guided",
        "light": "minimal",
        "minimal check ins": "minimal",
        "minimal checkins": "minimal",
        "low_friction": "minimal",
        "low friction": "minimal",
        "power_user": "minimal",
        "power user": "minimal",
        "automation": "silent",
        "pipeline": "silent",
        "none": "silent",
        "off": "silent",
        "no": "silent",
        "no check ins": "silent",
        "no checkins": "silent",
        "run silently": "silent",
    }
    mode = aliases.get(mode, mode)
    return mode if mode in HUMAN_LOOP_MODES else "guided"


def human_loop_budget(depth: str, mode: str) -> dict[str, int]:
    mode_value = normalize_human_loop_mode(mode)
    if mode_value == "silent":
        onboarding_count = judgment_count = reflection_count = 0
    elif mode_value == "minimal":
        onboarding_count = judgment_count = reflection_count = 1
    else:
        onboarding_count = 4
        judgment_count = 3
        reflection_count = 3
    base = {
        "mode_consent": 1,
        "onboarding": onboarding_count,
        "judgment": judgment_count,
        "reflection": reflection_count,
    }
    # Legacy aliases stay in the contract so older host prompts do not break.
    base["pre_audit"] = base["onboarding"]
    base["mid_audit"] = base["judgment"]
    base["post_audit_reflection"] = base["reflection"]
    return base


def normalize_human_loop_stage(value: str | None) -> str:
    stage = normalize_text(value).replace(" ", "_")
    aliases = {
        "": "onboarding",
        "consent": "mode_consent",
        "mode_consent": "mode_consent",
        "silent_mode_consent": "mode_consent",
        "human_loop_mode_consent": "mode_consent",
        "pre_audit": "onboarding",
        "preflight": "onboarding",
        "preflight_pending": "onboarding",
        "setup": "onboarding",
        "middle": "judgment",
        "mid_audit": "judgment",
        "user_judgment": "judgment",
        "raw_judgment": "judgment",
        "post_audit": "reflection",
        "post_audit_reflection": "reflection",
        "pre_output": "reflection",
        "pre_output_reflection": "reflection",
        "final_reflection": "reflection",
    }
    stage = aliases.get(stage, stage)
    return stage if stage in {"mode_consent", "onboarding", "judgment", "reflection"} else "onboarding"


def human_loop_gate_overridden(state: dict[str, Any]) -> bool:
    for key in (
        "explicit_noninteractive_override",
        "noninteractive_smoke_test",
        "override_human_loop_gates",
        "override_gate",
        "explicit_override",
    ):
        if bool(state.get(key)):
            return True
    return False


def human_loop_response_values(state: dict[str, Any], prompt_id: str) -> list[Any]:
    for source_key in ("responses", "prompt_responses", "answers"):
        source = state.get(source_key)
        if not isinstance(source, dict):
            continue
        response = source.get(prompt_id)
        if isinstance(response, dict):
            for value_key in ("selected_values", "selected", "value", "selected_mode", "mode"):
                values = ensure_list(response.get(value_key))
                if values:
                    return values
        values = ensure_list(response)
        if values:
            return values
    return []


def human_loop_mode_consent_state(state: dict[str, Any]) -> dict[str, Any]:
    consent = state.get("mode_consent") if isinstance(state.get("mode_consent"), dict) else {}
    answered_ids = {first_text(item) for item in ensure_list(state.get("answered_prompt_ids")) if first_text(item)}
    skipped_ids = {first_text(item) for item in ensure_list(state.get("skipped_prompt_ids")) if first_text(item)}
    response_values = human_loop_response_values(state, "human_loop_mode_consent")
    response_confirmed = False
    for source_key in ("responses", "prompt_responses", "answers"):
        source = state.get(source_key)
        response = source.get("human_loop_mode_consent") if isinstance(source, dict) else None
        if isinstance(response, dict) and bool(response.get("confirmed_by_user")):
            response_confirmed = True
            break
    selected_raw = (
        first_text(consent.get("selected_mode"))
        or first_text(consent.get("mode"))
        or first_text(state.get("selected_human_loop_mode"))
        or first_text(response_values[0] if response_values else "")
    )
    selected_mode = normalize_human_loop_mode(selected_raw) if selected_raw else ""
    consent_prompt_seen = "human_loop_mode_consent" in answered_ids or "human_loop_mode_consent" in skipped_ids
    confirmed = bool(
        consent.get("confirmed_by_user")
        or consent.get("confirmed")
        or response_confirmed
        or state.get("mode_consent_confirmed")
        or state.get("silent_mode_confirmed_by_user")
    )
    source = first_text(consent.get("source")) or "explicit_user_selection"

    if bool(state.get("silent_mode_confirmed_by_user")):
        selected_mode = "silent"
        confirmed = True
        source = "silent_mode_confirmed_by_user"
    elif "human_loop_mode_consent" in skipped_ids:
        selected_mode = "guided"
        confirmed = True
        source = "skipped_default_guided"
    elif consent_prompt_seen and not selected_mode:
        selected_mode = "guided"
        confirmed = True
        source = "ambiguous_default_guided"
    elif selected_mode in {"guided", "minimal"} and consent_prompt_seen:
        confirmed = True
    elif selected_mode == "silent" and consent_prompt_seen and bool(consent.get("confirmed_by_user")):
        confirmed = True

    return {
        "selected_mode": selected_mode or None,
        "confirmed_by_user": bool(confirmed),
        "source": source if selected_mode else "not_collected",
        "default_if_skipped_or_ambiguous": "guided",
    }


def human_loop_silent_mode_authorized(state: dict[str, Any]) -> bool:
    if human_loop_gate_overridden(state):
        return True
    consent = human_loop_mode_consent_state(state)
    return bool(
        consent.get("selected_mode") == "silent"
        and consent.get("confirmed_by_user")
    )


def human_loop_mode_consent_required(human_loop_mode: str | None, state: dict[str, Any]) -> bool:
    requested = normalize_human_loop_mode(human_loop_mode)
    if requested != "silent":
        return False
    if human_loop_silent_mode_authorized(state):
        return False
    consent = human_loop_mode_consent_state(state)
    if consent.get("selected_mode") in {"guided", "minimal"} and consent.get("confirmed_by_user"):
        return False
    return True


def resolve_human_loop_mode(human_loop_mode: str | None, state: dict[str, Any]) -> str:
    requested = normalize_human_loop_mode(human_loop_mode)
    consent = human_loop_mode_consent_state(state)
    if requested == "silent":
        selected = first_text(consent.get("selected_mode"))
        if selected in {"guided", "minimal"} and consent.get("confirmed_by_user"):
            return selected
        if selected == "silent" and consent.get("confirmed_by_user"):
            return "silent"
        if human_loop_gate_overridden(state):
            return "silent"
    return requested


def normalize_scaffold_detail(value: str | None) -> str:
    detail = normalize_text(value)
    aliases = {
        "": "compact",
        "default": "compact",
        "brief": "compact",
        "short": "compact",
        "tl dr": "compact",
        "tldr": "compact",
        "handoff only": "handoff",
        "stage handoff": "handoff",
        "small context": "handoff",
        "small_context": "handoff",
        "verbose": "full",
        "debug": "full",
        "expanded": "full",
    }
    detail = aliases.get(detail, detail)
    return detail if detail in SCAFFOLD_DETAILS else "compact"


def normalize_retrieval_profile(value: str | None) -> str:
    profile = normalize_text(value).replace(" ", "_")
    aliases = {
        "": "auto",
        "default": "auto",
        "methodology": "research_methodology",
        "research": "research_methodology",
        "research_audit": "research_methodology",
        "research_methods": "research_methodology",
        "study": "research_methodology",
        "study_methods": "research_methodology",
    }
    profile = aliases.get(profile, profile)
    return profile if profile in RETRIEVAL_PROFILES else "auto"


def research_profile_requested(
    text: str,
    *,
    text_type: str | None = None,
    domain: str | None = None,
    retrieval_profile: str | None = None,
) -> bool:
    profile = normalize_retrieval_profile(retrieval_profile)
    if profile == "research_methodology":
        return True
    if profile == "general":
        return False
    if normalize_text_type(text_type) in RESEARCH_TEXT_TYPES or domain == "research study/report":
        return True
    lowered = normalize_text(text)
    return any(cue in lowered for cue in RESEARCH_PROFILE_CUES)


def resolve_retrieval_profile(
    text: str,
    *,
    text_type: str | None = None,
    domain: str | None = None,
    retrieval_profile: str | None = None,
) -> str:
    profile = normalize_retrieval_profile(retrieval_profile)
    if profile in {"general", "research_methodology"}:
        return profile
    return "research_methodology" if research_profile_requested(text, text_type=text_type, domain=domain, retrieval_profile=profile) else "general"


def human_loop_source_completeness(text: str, insufficient: bool) -> tuple[str, str, str]:
    lowered = text.lower()
    if insufficient:
        return "too_thin", "inferred", "low"
    if text_has_any(lowered, ["excerpt", "abstract", "partial", "selected passage", "selection from"]):
        return "excerpt_limited", "inferred", "medium"
    if word_count(text) < 80:
        return "visible_text_only", "inferred", "medium"
    return "visible_text_only", "inferred", "medium"


def human_loop_config_item(
    value: Any,
    *,
    source: str = "inferred",
    confidence: str = "medium",
    confirmed_by_user: bool = False,
) -> dict[str, Any]:
    return {
        "value": value,
        "source": source,
        "confidence": confidence,
        "confirmed_by_user": bool(confirmed_by_user),
    }


def human_loop_state_input(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def human_loop_input_lists(state: dict[str, Any]) -> dict[str, list[Any]]:
    source = state.get("human_inputs") if isinstance(state.get("human_inputs"), dict) else {}
    return {
        "configuration": ensure_list(source.get("configuration")),
        "evidence": ensure_list(source.get("evidence")),
        "commentary": ensure_list(source.get("commentary")),
        "quarantined_opinions": ensure_list(source.get("quarantined_opinions")),
    }


def human_loop_verified_evidence_inputs(state: dict[str, Any]) -> list[dict[str, Any]]:
    evidence = []
    for item in human_loop_input_lists(state).get("evidence", []):
        if not isinstance(item, dict):
            continue
        evidence_class = normalize_text(item.get("evidence_class")).replace(" ", "_")
        bucket = normalize_text(item.get("bucket"))
        requires_rerun = bool(item.get("requires_rerun"))
        if evidence_class == "verified_evidence" or (bucket == "evidence" and requires_rerun):
            evidence.append(item)
    return evidence


def human_loop_rerun_marker(state: dict[str, Any]) -> dict[str, Any] | None:
    verified = human_loop_verified_evidence_inputs(state)
    if not verified:
        return None
    try:
        prior_version = int(state.get("audit_version") or 1)
    except (TypeError, ValueError):
        prior_version = 1
    stale: list[str] = []
    for item in verified:
        affects = ensure_list(item.get("affects_sections"))
        stale.extend(first_text(section) for section in affects if first_text(section))
    stale = join_unique(stale or ["bias_map", "methodology_check", "critical_integrity_snapshot"])
    return {
        "needs_rerun": True,
        "rerun_reason": "new_verified_evidence",
        "stale_sections": stale,
        "prior_audit_version": prior_version,
        "next_audit_version": prior_version + 1,
    }


def human_loop_choice(
    label: str,
    value: str,
    *,
    skill_tags: list[str] | None = None,
    snippet: str | None = None,
) -> dict[str, Any]:
    choice: dict[str, Any] = {"label": label, "value": value}
    if skill_tags:
        choice["skill_tags"] = skill_tags
    if snippet:
        choice["snippet"] = snippet
    return choice


def human_loop_prompt(
    *,
    prompt_id: str,
    group_id: str,
    stage: str,
    bucket: str,
    priority: str,
    question: str,
    choices: list[dict[str, str]],
    default: Any,
    why: str,
    can_change: list[str],
    cannot_change: list[str],
    on_skip_action: str,
    on_skip_value: Any,
    selection_mode: str = "single",
    max_selections: int = 1,
    allow_free_text: bool = False,
    free_text_prompt: str = "",
    skill_tags: list[str] | None = None,
    dynamic_options: dict[str, Any] | None = None,
    confidence_effect: str = "keep_medium_confidence",
    skippable: bool = True,
    blocking: bool = False,
    batchable: bool = True,
    disclosure: str | None = None,
) -> dict[str, Any]:
    return {
        "id": prompt_id,
        "group_id": group_id,
        "stage": stage,
        "bucket": bucket,
        "priority": priority,
        "batchable": batchable,
        "skippable": skippable,
        "blocking": blocking,
        "question": question,
        "choices": choices,
        "default": default,
        "selection_mode": selection_mode,
        "max_selections": max(1, int(max_selections or 1)),
        "allow_free_text": bool(allow_free_text),
        "free_text_prompt": free_text_prompt,
        "skill_tags": skill_tags or [],
        "dynamic_options": dynamic_options or {},
        "why_i_am_asking": why,
        "what_this_can_change": can_change,
        "what_this_cannot_change": cannot_change,
        "this_can_change": can_change,
        "this_cannot_change": cannot_change,
        "on_skip": {
            "action": on_skip_action,
            "value": on_skip_value,
            "confidence_effect": confidence_effect,
            "disclosure": disclosure or "",
        },
    }


def human_loop_mode_consent_prompts(answered_ids: set[str], skipped_ids: set[str]) -> list[dict[str, Any]]:
    prompts = [
        human_loop_prompt(
            prompt_id="human_loop_mode_consent",
            group_id="mode_consent",
            stage="mode_consent",
            bucket="configuration",
            priority="critical",
            question="Do you want Critical Compass to ask check-in questions during this audit?",
            choices=[
                human_loop_choice("Yes, use guided check-ins", "guided", skill_tags=["user_control", "confidence_calibration"]),
                human_loop_choice("Use minimal check-ins", "minimal", skill_tags=["user_control"]),
                human_loop_choice("No, run silently for this audit", "silent", skill_tags=["user_control"]),
                human_loop_choice("Not sure, use guided", "not_sure_guided", skill_tags=["user_control"]),
            ],
            default="guided",
            selection_mode="single",
            max_selections=1,
            allow_free_text=False,
            free_text_prompt="",
            skill_tags=["user_control", "human_loop_consent"],
            why="Silent mode was requested, but the user has not confirmed they want to skip Human Loop check-ins.",
            can_change=["Human Loop mode for this audit", "number of check-in prompts"],
            cannot_change=["audit findings", "evidence standards", "score logic"],
            on_skip_action="default_to_guided",
            on_skip_value="guided",
            disclosure="Silent mode consent was skipped or ambiguous, so Critical Compass defaulted to guided check-ins.",
            blocking=True,
        )
    ]
    return [
        prompt
        for prompt in prompts
        if not human_loop_prompt_satisfied(first_text(prompt.get("id")), answered_ids, skipped_ids)
    ]


def human_loop_prompt_satisfied(prompt_id: str, answered_ids: set[str], skipped_ids: set[str]) -> bool:
    aliases = {
        "human_loop_mode_consent": {"mode_consent", "silent_mode_consent"},
        "onboarding_intended_audience": {"preflight_intended_audience"},
        "onboarding_relationship_to_text": {"preflight_relationship_to_text"},
        "onboarding_output_format": {"preflight_output_format"},
        "reflection_takeaway": {"post_audit_human_commentary"},
        "reflection_reason_anchor": {"post_audit_learning_note"},
    }.get(prompt_id, set())
    ids = {prompt_id, *aliases}
    return bool(ids & answered_ids or ids & skipped_ids)


def human_loop_filter_prompts(prompts: list[dict[str, Any]], answered_ids: set[str], skipped_ids: set[str], *, depth: str, mode: str, stage: str) -> list[dict[str, Any]]:
    available = [prompt for prompt in prompts if not human_loop_prompt_satisfied(first_text(prompt.get("id")), answered_ids, skipped_ids)]
    return available[: human_loop_budget(depth, mode).get(stage, 0)]


def human_loop_onboarding_prompts(
    *,
    mode: str,
    depth: str,
    answered_ids: set[str],
    skipped_ids: set[str],
) -> list[dict[str, Any]]:
    if mode == "silent":
        return []
    prompts = [
        human_loop_prompt(
            prompt_id="onboarding_goal_for_text",
            group_id="onboarding",
            stage="onboarding",
            bucket="configuration",
            priority="high",
            question="What are you trying to do with this text?",
            choices=[
                human_loop_choice("Check whether it's sound", "check_soundness", skill_tags=["evidence_attention", "confidence_calibration"]),
                human_loop_choice("Improve it", "improve_text", skill_tags=["revision_orientation"]),
                human_loop_choice("Decide whether to trust/use it", "decide_trust", skill_tags=["confidence_calibration"]),
                human_loop_choice("Prepare a response", "prepare_response", skill_tags=["action_orientation"]),
                human_loop_choice("Compare viewpoints", "compare_viewpoints", skill_tags=["perspective_taking"]),
                human_loop_choice("Learn from it", "learn_from_it", skill_tags=["learning_orientation"]),
                human_loop_choice("Other", "other"),
            ],
            default=["decide_trust"],
            selection_mode="multi",
            max_selections=2,
            allow_free_text=True,
            free_text_prompt="Add a short goal or context note if useful.",
            skill_tags=["goal_setting", "confidence_calibration"],
            why="The user's goal sets the output lane without preloading the verdict.",
            can_change=["audit framing", "final output emphasis", "coaching level"],
            cannot_change=["evidence standards", "bias definitions", "frozen findings"],
            on_skip_action="continue_with_unknown_goal",
            on_skip_value="unknown",
            disclosure="Audit goal was skipped and treated as unknown.",
        ),
        human_loop_prompt(
            prompt_id="onboarding_intended_audience",
            group_id="onboarding",
            stage="onboarding",
            bucket="configuration",
            priority="high",
            question="Who is the intended audience or target reader?",
            choices=[
                human_loop_choice("General/public audience", "public_general", skill_tags=["framing_awareness"]),
                human_loop_choice("Decision-makers or leadership", "decision_makers", skill_tags=["perspective_taking"]),
                human_loop_choice("Peers or subject-matter experts", "peers_experts"),
                human_loop_choice("Funders, donors, or grant reviewers", "funders_donors_grant_reviewers", skill_tags=["perspective_taking"]),
                human_loop_choice("Community members or affected stakeholders", "community_affected_stakeholders", skill_tags=["perspective_taking"]),
                human_loop_choice("Internal team or collaborators", "internal_team"),
                human_loop_choice("Not sure or mixed audience", "unknown_or_mixed"),
                human_loop_choice("Other", "other"),
            ],
            default=["unknown_or_mixed"],
            selection_mode="multi",
            max_selections=2,
            allow_free_text=True,
            free_text_prompt="Add the target reader in your own words if useful.",
            skill_tags=["audience_fit", "perspective_taking", "framing_awareness"],
            why="Audience changes how Critical Compass reads framing openness, stakeholder fit, persuasion risk, and what would count as effective communication.",
            can_change=["audit framing", "stakeholder emphasis", "final output emphasis"],
            cannot_change=["evidence standards", "frozen findings", "score logic"],
            on_skip_action="continue_with_unknown_audience",
            on_skip_value="unknown",
            disclosure="Intended audience was skipped and left unknown.",
        ),
        human_loop_prompt(
            prompt_id="onboarding_relationship_to_text",
            group_id="onboarding",
            stage="onboarding",
            bucket="configuration",
            priority="high",
            question="What's your relationship to the text?",
            choices=[
                human_loop_choice("I wrote it", "author", skill_tags=["contamination_safeguard"]),
                human_loop_choice("I'm reviewing someone else's writing", "reviewer"),
                human_loop_choice("Someone sent it to me", "received_text"),
                human_loop_choice("I mostly agree with it", "mostly_agree", skill_tags=["confirmation_bias_awareness"]),
                human_loop_choice("I'm skeptical of it", "skeptical", skill_tags=["confidence_calibration"]),
                human_loop_choice("I haven't read it closely", "not_read_closely", skill_tags=["source_awareness"]),
                human_loop_choice("Other", "other"),
            ],
            default="unknown",
            selection_mode="single",
            max_selections=1,
            skill_tags=["relationship_context", "contamination_safeguard"],
            why="Relationship changes safeguards and wording, not the audit standard.",
            can_change=["contamination safeguards", "report framing", "tone"],
            cannot_change=["substantive audit criteria", "bias definitions", "score logic"],
            on_skip_action="leave_unknown",
            on_skip_value="unknown",
            disclosure="Relationship to the text was skipped and left unknown.",
        ),
        human_loop_prompt(
            prompt_id="onboarding_output_format",
            group_id="onboarding",
            stage="onboarding",
            bucket="configuration",
            priority="high",
            question="What kind of output would help most?",
            choices=[
                human_loop_choice("Quick summary", "quick_summary"),
                human_loop_choice("Full audit", "full_audit"),
                human_loop_choice("Evidence check", "evidence_check", skill_tags=["evidence_attention"]),
                human_loop_choice("Bias/fallacy breakdown", "bias_fallacy_breakdown"),
                human_loop_choice("Rewrite suggestions", "rewrite_suggestions", skill_tags=["revision_orientation"]),
                human_loop_choice("Stakeholder impact", "stakeholder_impact", skill_tags=["perspective_taking"]),
                human_loop_choice("Learning/coaching mode", "learning_coaching", skill_tags=["learning_orientation"]),
                human_loop_choice("PDF/report", "pdf_report"),
                human_loop_choice("Markdown/chat response", "markdown_chat"),
                human_loop_choice("Other", "other"),
            ],
            default=["full_audit"],
            selection_mode="multi",
            max_selections=3,
            skill_tags=["output_routing"],
            why="Output choice controls presentation and reflection prompts, not the audit verdict.",
            can_change=["rendering", "report generation", "reflection option bank"],
            cannot_change=["findings", "scoring", "bias detection"],
            on_skip_action="use_default",
            on_skip_value=["full_audit"],
            disclosure="Output preference was skipped and defaulted to full audit.",
        ),
    ]
    return human_loop_filter_prompts(prompts, answered_ids, skipped_ids, depth=depth, mode=mode, stage="onboarding")


def human_loop_judgment_pressure_choices(silent_parse: dict[str, Any] | None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    parse = silent_parse if isinstance(silent_parse, dict) else {}
    dynamic: list[dict[str, Any]] = []
    for index, item in enumerate(ensure_list(parse.get("top_claims_or_sections"))[:3], start=1):
        snippet = first_text(item.get("snippet") if isinstance(item, dict) else item)
        if not snippet:
            continue
        label = short_phrase(snippet, 10)
        dynamic.append(
            human_loop_choice(
                f"Claim {index}: {label}",
                f"dynamic_claim_{index}",
                skill_tags=["focus_target", "evidence_attention"],
                snippet=snippet,
            )
        )
    fallback = [
        human_loop_choice("Main claim", "main_claim"),
        human_loop_choice("Supporting evidence or sources", "supporting_evidence", skill_tags=["evidence_attention"]),
        human_loop_choice("Definitions or ambiguity", "definitions_ambiguity", skill_tags=["assumption_spotting"]),
        human_loop_choice("Framing or tone", "framing_tone", skill_tags=["framing_awareness"]),
        human_loop_choice("Stakeholder impact", "stakeholder_impact", skill_tags=["perspective_taking"]),
        human_loop_choice("Alternative explanations", "alternative_explanations", skill_tags=["creative_reframing"]),
        human_loop_choice("Choose for me", "choose_for_me"),
        human_loop_choice("Other", "other"),
    ]
    return [*dynamic, *fallback][:10], {
        "source": "silent_parse_top_claims" if dynamic else "fallback",
        "dynamic_count": len(dynamic),
        "fallback_included": True,
    }


def human_loop_judgment_prompts(
    *,
    mode: str,
    depth: str,
    answered_ids: set[str],
    skipped_ids: set[str],
    silent_parse: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    if mode == "silent":
        return []
    pressure_choices, dynamic_options = human_loop_judgment_pressure_choices(silent_parse)
    prompts = [
        human_loop_prompt(
            prompt_id="judgment_current_read",
            group_id="judgment",
            stage="judgment",
            bucket="quarantined_opinions",
            priority="high",
            question="Before I show findings, what's your current read on this text?",
            choices=[
                human_loop_choice("Mostly clear and grounded", "clear_grounded", skill_tags=["confidence_calibration"]),
                human_loop_choice("Mixed - some strong, some weak", "mixed_strength", skill_tags=["confidence_calibration"]),
                human_loop_choice("Persuasive but under-supported", "persuasive_undersupported", skill_tags=["evidence_attention"]),
                human_loop_choice("Emotionally loaded", "emotionally_loaded", skill_tags=["framing_awareness"]),
                human_loop_choice("One-sided or unfair", "one_sided_unfair", skill_tags=["perspective_taking"]),
                human_loop_choice("Overconfident", "overconfident", skill_tags=["confidence_calibration"]),
                human_loop_choice("Vague or slippery", "vague_slippery", skill_tags=["assumption_spotting"]),
                human_loop_choice("Missing context", "missing_context", skill_tags=["context_awareness"]),
                human_loop_choice("Not sure yet", "not_sure_yet"),
                human_loop_choice("Other", "other"),
            ],
            default=["not_sure_yet"],
            selection_mode="multi",
            max_selections=2,
            skill_tags=["raw_judgment", "confidence_calibration"],
            why="This captures the user's own read before model conclusions can anchor it.",
            can_change=["focus metadata", "human commentary comparison", "learning signal"],
            cannot_change=["frozen findings", "score", "bias labels"],
            on_skip_action="continue_without_raw_read",
            on_skip_value="skipped",
            disclosure="Raw current-read prompt was skipped.",
        ),
        human_loop_prompt(
            prompt_id="judgment_suspected_issues",
            group_id="judgment",
            stage="judgment",
            bucket="quarantined_opinions",
            priority="high",
            question="What issues do you already suspect?",
            choices=[
                human_loop_choice("Weak or missing evidence", "weak_missing_evidence", skill_tags=["evidence_attention"]),
                human_loop_choice("Hidden assumption", "hidden_assumption", skill_tags=["assumption_spotting"]),
                human_loop_choice("Leap in logic", "leap_in_logic", skill_tags=["logic_checking"]),
                human_loop_choice("Too broad from too few examples", "too_broad_few_examples", skill_tags=["evidence_attention"]),
                human_loop_choice("A contested assumption is doing heavy work", "contested_assumption", skill_tags=["assumption_spotting"]),
                human_loop_choice("Framed as only two choices", "only_two_choices", skill_tags=["alternative_generation"]),
                human_loop_choice("Cherry-picked examples", "cherry_picked_examples", skill_tags=["evidence_attention"]),
                human_loop_choice("Loaded language", "loaded_language", skill_tags=["framing_awareness"]),
                human_loop_choice("Missing context", "missing_context", skill_tags=["context_awareness"]),
                human_loop_choice("Missing affected perspective", "missing_affected_perspective", skill_tags=["perspective_taking"]),
                human_loop_choice("Possible harm to a stakeholder is undernamed", "harmed_stakeholder_undernamed", skill_tags=["perspective_taking"]),
                human_loop_choice("The comfortable answer may be too easy", "comfortable_answer_too_easy", skill_tags=["confidence_calibration"]),
                human_loop_choice("Ignores alternatives or counterarguments", "ignores_alternatives", skill_tags=["alternative_generation"]),
                human_loop_choice("Not sure yet", "not_sure_yet"),
                human_loop_choice("Other", "other"),
            ],
            default=["not_sure_yet"],
            selection_mode="multi",
            max_selections=3,
            skill_tags=["raw_diagnosis", "assumption_spotting", "evidence_attention"],
            why="Plain-language suspicions create a comparison point without turning the prompt into fallacy bingo.",
            can_change=["focus metadata", "human-vs-AI divergence notes", "learning signal"],
            cannot_change=["frozen findings", "score", "formal taxonomy selection"],
            on_skip_action="continue_without_suspected_issues",
            on_skip_value="skipped",
            disclosure="Suspected-issues prompt was skipped.",
        ),
        human_loop_prompt(
            prompt_id="judgment_pressure_test_target",
            group_id="judgment",
            stage="judgment",
            bucket="quarantined_opinions",
            priority="high",
            question="Which part should I pressure-test hardest?",
            choices=pressure_choices,
            default="choose_for_me",
            selection_mode="single",
            max_selections=1,
            allow_free_text=True,
            free_text_prompt="Quote the sentence or section that jumped out.",
            skill_tags=["focus_target", "evidence_attention"],
            dynamic_options=dynamic_options,
            why="Target selection lets the user choose where to spend effort without steering what the audit concludes.",
            can_change=["pressure-test focus", "reported human priority", "learning signal"],
            cannot_change=["findings", "score", "evidence standards"],
            on_skip_action="choose_for_user",
            on_skip_value="choose_for_me",
            disclosure="Pressure-test target was skipped; the MCP/host should choose the target.",
        ),
    ]
    return human_loop_filter_prompts(prompts, answered_ids, skipped_ids, depth=depth, mode=mode, stage="judgment")


def human_loop_selected_prompt_values(state: dict[str, Any], prompt_id: str) -> list[str]:
    values: list[str] = []
    for key in ("responses", "prompt_responses", "answers"):
        source = state.get(key) if isinstance(state.get(key), dict) else {}
        response = source.get(prompt_id)
        if isinstance(response, dict):
            values.extend(first_text(item) for item in ensure_list(response.get("selected_values") or response.get("values") or response.get("value")) if first_text(item))
            values.extend(first_text(item) for item in ensure_list(response.get("selection")) if first_text(item))
        else:
            values.extend(first_text(item) for item in ensure_list(response) if first_text(item))
    for bucket_items in human_loop_input_lists(state).values():
        for item in bucket_items:
            if not isinstance(item, dict) or first_text(item.get("prompt_id")) != prompt_id:
                continue
            values.extend(first_text(value) for value in ensure_list(item.get("selected_values") or item.get("values") or item.get("value")) if first_text(value))
    return join_unique(values)


def human_loop_reflection_bank(state: dict[str, Any], configuration: dict[str, Any]) -> str:
    selected = set(human_loop_selected_prompt_values(state, "onboarding_output_format"))
    output_config = configuration.get("output_format") if isinstance(configuration.get("output_format"), dict) else {}
    selected.update(first_text(value) for value in ensure_list(output_config.get("value")) if first_text(value))
    goal_selected = set(human_loop_selected_prompt_values(state, "onboarding_goal_for_text"))
    if selected & {"learning_coaching"} or goal_selected & {"learn_from_it"}:
        return "learning_coaching"
    return "decision_report"


def human_loop_reflection_prompts(
    *,
    mode: str,
    depth: str,
    answered_ids: set[str],
    skipped_ids: set[str],
    state: dict[str, Any],
    configuration: dict[str, Any],
) -> list[dict[str, Any]]:
    if mode == "silent":
        return []
    bank = human_loop_reflection_bank(state, configuration)
    if bank == "learning_coaching":
        e1_choices = [
            human_loop_choice("Evidence checking got sharper", "evidence_checking_sharper", skill_tags=["evidence_attention"]),
            human_loop_choice("Assumption spotting got sharper", "assumption_spotting_sharper", skill_tags=["assumption_spotting"]),
            human_loop_choice("I noticed framing more clearly", "framing_clearer", skill_tags=["framing_awareness"]),
            human_loop_choice("I noticed missing perspectives more clearly", "missing_perspectives_clearer", skill_tags=["perspective_taking"]),
            human_loop_choice("I considered alternatives more clearly", "alternatives_clearer", skill_tags=["alternative_generation"]),
            human_loop_choice("I feel more calibrated or less certain", "more_calibrated", skill_tags=["confidence_calibration"]),
            human_loop_choice("Nothing clicked yet", "nothing_clicked_yet"),
            human_loop_choice("Other", "other"),
        ]
        e2_choices = [
            human_loop_choice("A specific quote", "specific_quote"),
            human_loop_choice("A flagged example from the preview", "preview_example"),
            human_loop_choice("A pattern across the text", "pattern_across_text"),
            human_loop_choice("A contradiction", "contradiction"),
            human_loop_choice("A rewrite example", "rewrite_example"),
            human_loop_choice("The stakeholder lens", "stakeholder_lens", skill_tags=["perspective_taking"]),
            human_loop_choice("My own reflection", "own_reflection"),
            human_loop_choice("Other", "other"),
        ]
        e3_choices = [
            human_loop_choice("Practice evidence checks", "practice_evidence_checks", skill_tags=["evidence_attention"]),
            human_loop_choice("Practice spotting assumptions", "practice_assumption_spotting", skill_tags=["assumption_spotting"]),
            human_loop_choice("Practice counterarguments", "practice_counterarguments", skill_tags=["alternative_generation"]),
            human_loop_choice("Practice fair rewrites", "practice_fair_rewrites", skill_tags=["revision_orientation"]),
            human_loop_choice("Practice stakeholder analysis", "practice_stakeholder_analysis", skill_tags=["perspective_taking"]),
            human_loop_choice("Practice confidence calibration", "practice_confidence_calibration", skill_tags=["confidence_calibration"]),
            human_loop_choice("I'm ready for the final output", "ready_final_output"),
            human_loop_choice("Other", "other"),
        ]
    else:
        e1_choices = [
            human_loop_choice("The weakest point matters most", "weakest_point_matters", skill_tags=["evidence_attention"]),
            human_loop_choice("The strongest point matters most", "strongest_point_matters"),
            human_loop_choice("Missing evidence stands out", "missing_evidence", skill_tags=["evidence_attention"]),
            human_loop_choice("A hidden assumption stands out", "hidden_assumption", skill_tags=["assumption_spotting"]),
            human_loop_choice("Missing context stands out", "missing_context", skill_tags=["context_awareness"]),
            human_loop_choice("Unfair framing stands out", "unfair_framing", skill_tags=["framing_awareness"]),
            human_loop_choice("Missing affected perspective stands out", "missing_affected_perspective", skill_tags=["perspective_taking"]),
            human_loop_choice("Nothing shifted yet", "nothing_shifted_yet"),
            human_loop_choice("Other", "other"),
        ]
        e2_choices = [
            human_loop_choice("A specific quote", "specific_quote"),
            human_loop_choice("A repeated pattern across the text", "repeated_pattern"),
            human_loop_choice("Source or evidence quality", "source_evidence_quality", skill_tags=["evidence_attention"]),
            human_loop_choice("Contradiction or inconsistency", "contradiction_inconsistency"),
            human_loop_choice("Emotional framing", "emotional_framing", skill_tags=["framing_awareness"]),
            human_loop_choice("Omitted counterpoint", "omitted_counterpoint", skill_tags=["alternative_generation"]),
            human_loop_choice("Stakeholder impact", "stakeholder_impact", skill_tags=["perspective_taking"]),
            human_loop_choice("The preview explanation", "preview_explanation"),
            human_loop_choice("My prior knowledge", "prior_knowledge"),
            human_loop_choice("Other", "other"),
        ]
        e3_choices = [
            human_loop_choice("Help me make a judgment", "make_judgment"),
            human_loop_choice("Help me prepare a reply", "prepare_reply"),
            human_loop_choice("Help me improve or rewrite the text", "improve_rewrite"),
            human_loop_choice("Help me compare perspectives", "compare_perspectives", skill_tags=["perspective_taking"]),
            human_loop_choice("Help me document risks/issues", "document_risks"),
            human_loop_choice("Help me generate a shareable report/PDF", "generate_report_pdf"),
            human_loop_choice("I'm ready for the final output as-is", "ready_final_output"),
            human_loop_choice("Other", "other"),
        ]
    prompts = [
        human_loop_prompt(
            prompt_id="reflection_takeaway",
            group_id="reflection",
            stage="reflection",
            bucket="commentary",
            priority="high",
            question="After this preview, what stands out most now?",
            choices=e1_choices,
            default=e1_choices[0]["value"],
            selection_mode="single",
            max_selections=1,
            skill_tags=["takeaway", "confidence_calibration"],
            dynamic_options={"option_bank": bank},
            why="The preview gives the user something concrete to react to before the final artifact is produced.",
            can_change=["human commentary", "learning notes", "final-output emphasis"],
            cannot_change=["frozen AI findings", "score", "bias map unless new evidence triggers rerun"],
            on_skip_action="continue_without_takeaway",
            on_skip_value="skipped",
            disclosure="Reflection takeaway was skipped.",
        ),
        human_loop_prompt(
            prompt_id="reflection_reason_anchor",
            group_id="reflection",
            stage="reflection",
            bucket="commentary",
            priority="high",
            question="What most shaped that view?",
            choices=e2_choices,
            default=[e2_choices[0]["value"]],
            selection_mode="multi",
            max_selections=2,
            skill_tags=["reason_anchor", "self_explanation"],
            dynamic_options={"option_bank": bank},
            why="A short reason anchor makes the user's reasoning visible without requiring a long explanation.",
            can_change=["human commentary", "divergence map", "learning notes"],
            cannot_change=["frozen findings", "score", "bias definitions"],
            on_skip_action="continue_without_reason_anchor",
            on_skip_value="skipped",
            disclosure="Reflection reason anchor was skipped.",
        ),
        human_loop_prompt(
            prompt_id="reflection_next_action",
            group_id="reflection",
            stage="reflection",
            bucket="commentary",
            priority="high",
            question="What should the final output help you do next?",
            choices=e3_choices,
            default="ready_final_output",
            selection_mode="single",
            max_selections=1,
            allow_free_text=True,
            free_text_prompt="Anything you want emphasized in the final output?",
            skill_tags=["next_action", "output_emphasis"],
            dynamic_options={"option_bank": bank},
            why="This shapes final presentation and coaching emphasis after findings are frozen.",
            can_change=["final output emphasis", "report framing", "learning note selection"],
            cannot_change=["findings", "score", "evidence standards"],
            on_skip_action="continue_with_default_output",
            on_skip_value="ready_final_output",
            disclosure="Final-output emphasis was skipped.",
        ),
    ]
    return human_loop_filter_prompts(prompts, answered_ids, skipped_ids, depth=depth, mode=mode, stage="reflection")


def human_loop_silent_parse(text: str) -> dict[str, Any]:
    sentences = [sentence for sentence in split_sentences(text) if word_count(sentence) >= 4]
    claim_cues = ["should", "must", "because", "therefore", "proves", "shows", "means", "will", "always", "never", "best", "only"]
    evidence_cues = ["study", "data", "evidence", "according", "source", "survey", "percent", "%", "because", "found", "shows"]
    loaded_cues = ["obvious", "clearly", "disaster", "dangerous", "radical", "everyone", "nobody", "always", "never", "failed", "crisis"]
    stakeholder_cues = ["patients", "students", "workers", "parents", "community", "voters", "customers", "teachers", "families", "residents"]

    scored: list[tuple[int, int, str]] = []
    for index, sentence in enumerate(sentences):
        lowered = normalize_text(sentence)
        score = sum(2 for cue in claim_cues if cue in lowered)
        score += 1 if 6 <= word_count(sentence) <= 35 else 0
        scored.append((score, -index, sentence))
    ranked = [sentence for score, _index, sentence in sorted(scored, reverse=True) if score > 0] or sentences[:3]
    top_claims = [
        {
            "id": f"claim_{index}",
            "label": f"Claim {index}",
            "snippet": short_phrase(sentence, 24),
        }
        for index, sentence in enumerate(ranked[:3], start=1)
    ]
    evidence_refs = [
        {"snippet": short_phrase(sentence, 24)}
        for sentence in sentences
        if any(cue in normalize_text(sentence) for cue in evidence_cues)
    ][:3]
    issues: list[str] = []
    lowered_text = normalize_text(text)
    issue_rules = [
        ("weak_or_missing_evidence", ["evidence", "data", "source"]),
        ("hidden_assumption", ["assume", "obvious", "clearly"]),
        ("loaded_language", loaded_cues),
        ("only_two_choices", [" either ", " only ", " choice"]),
        ("missing_context", ["context", "background", "before", "after"]),
        ("alternative_explanations", ["alternative", "counter", "however"]),
    ]
    for issue, cues in issue_rules:
        if any(cue.strip() in lowered_text for cue in cues):
            issues.append(issue)
    stakeholders = [cue for cue in stakeholder_cues if cue in lowered_text]
    charged = [
        {"phrase": cue}
        for cue in loaded_cues
        if cue in lowered_text
    ][:5]
    thesis = top_claims[0]["snippet"] if top_claims else short_phrase(text, 24)
    return {
        "thesis_or_main_claim": thesis,
        "top_claims_or_sections": top_claims,
        "likely_evidence_references": evidence_refs,
        "likely_issue_categories": join_unique(issues),
        "stakeholder_groups_mentioned_or_missing": join_unique(stakeholders),
        "emotionally_charged_phrases": charged,
        "disclosure": "Silent parse is used only to propose judgment options; it is not a finding or score.",
    }


def human_loop_reflection_preview(
    text: str,
    *,
    bias_hits: list[dict[str, Any]] | None = None,
    assumptions: list[dict[str, Any]] | None = None,
    methodology: dict[str, Any] | None = None,
    silent_parse: dict[str, Any] | None = None,
) -> dict[str, str]:
    parse = silent_parse if isinstance(silent_parse, dict) else human_loop_silent_parse(text)
    evidence_refs = ensure_list(parse.get("likely_evidence_references"))
    top_claims = ensure_list(parse.get("top_claims_or_sections"))
    strongest = first_text((evidence_refs[0] if evidence_refs else {}).get("snippet") if evidence_refs and isinstance(evidence_refs[0], dict) else "")
    if not strongest:
        strongest = first_text((top_claims[0] if top_claims else {}).get("snippet") if top_claims and isinstance(top_claims[0], dict) else "")
    if not strongest:
        strongest = short_phrase(text, 18)

    first_bias = (bias_hits or [None])[0]
    if isinstance(first_bias, dict) and first_text(first_bias.get("bias_name")):
        weakest = f"{first_text(first_bias.get('bias_name'))}: {short_phrase(first_text(first_bias.get('evidence')) or first_text(first_bias.get('claim_passage')), 16)}"
    else:
        issue = first_text(ensure_list(parse.get("likely_issue_categories"))[0] if ensure_list(parse.get("likely_issue_categories")) else "")
        weakest = issue.replace("_", " ") if issue else "The core claim may need clearer support or boundaries."

    missing_piece = ""
    for assumption in ensure_list(assumptions):
        if isinstance(assumption, dict) and first_text(assumption.get("assumption")):
            missing_piece = first_text(assumption.get("assumption"))
            break
    if not missing_piece and isinstance(methodology, dict):
        missing_piece = first_text(methodology.get("assessment") or methodology.get("status"))
    if not missing_piece:
        missing_piece = "The strongest next step is clearer evidence, context, or counterexample testing."

    return {
        "likely_strongest_point": strongest,
        "likely_weakest_point": weakest,
        "biggest_missing_piece": missing_piece,
    }


def human_loop_learning_signals(state: dict[str, Any]) -> dict[str, Any]:
    tags: list[str] = []
    tag_map = {
        "evidence": "evidence_attention",
        "source": "evidence_attention",
        "assumption": "assumption_spotting",
        "context": "context_awareness",
        "stakeholder": "perspective_taking",
        "perspective": "perspective_taking",
        "alternative": "alternative_generation",
        "counter": "alternative_generation",
        "loaded": "framing_awareness",
        "framing": "framing_awareness",
        "calibrated": "confidence_calibration",
        "certain": "confidence_calibration",
        "not_sure": "confidence_calibration",
        "rewrite": "revision_orientation",
        "improve": "revision_orientation",
        "learning": "learning_orientation",
        "learn": "learning_orientation",
    }
    response_blob = normalize_text(
        " ".join(
            [
                flatten_text(state.get("responses")),
                flatten_text(state.get("prompt_responses")),
                flatten_text(state.get("answers")),
                flatten_text(state.get("human_inputs")),
            ]
        )
    )
    for cue, tag in tag_map.items():
        if cue in response_blob:
            tags.append(tag)
    return {
        "session_only": True,
        "skill_tags": join_unique(tags),
        "note": "Learning signals are session metadata only; no persistent reasoning profile is written in this version.",
    }


def human_loop_disclosures(state: dict[str, Any], mode: str) -> list[str]:
    disclosures: list[str] = []
    configuration = state.get("configuration") if isinstance(state.get("configuration"), dict) else {}
    for key, value in configuration.items():
        if not isinstance(value, dict):
            continue
        source = first_text(value.get("source"))
        confirmed = bool(value.get("confirmed_by_user"))
        if source in {"inferred", "recommended_default", "default", "not_asked"} and not confirmed:
            label = key.replace("_", " ")
            disclosures.append(f"{label.title()} was {source.replace('_', ' ')} as {value.get('value')} and not user-confirmed.")
    if mode == "silent":
        disclosures.append("Human-loop prompts were suppressed because human_loop_mode is silent; assumptions are disclosed for review.")
    if bool(state.get("human_loop_override")):
        disclosures.append("Human-loop prompts were bypassed by an explicit noninteractive override; preserve pending IDs or skipped-stage disclosure in the final result.")
    mode_consent = state.get("mode_consent") if isinstance(state.get("mode_consent"), dict) else {}
    if first_text(mode_consent.get("source")) in {"skipped_default_guided", "ambiguous_default_guided"}:
        disclosures.append("Silent-mode consent was skipped or ambiguous, so guided Human Loop check-ins were used.")
    return join_unique(disclosures)


def human_loop_stage_label(stage: str) -> str:
    return {
        "mode_consent": "Human Loop Mode Consent",
        "onboarding": "Onboarding",
        "judgment": "Raw Judgment",
        "reflection": "Reflection",
    }.get(stage, "Human Loop")


def human_loop_next_stage(stage: str) -> str:
    return {
        "mode_consent": "onboarding",
        "onboarding": "judgment",
        "judgment": "reflection",
        "reflection": "final_output",
    }.get(stage, "next_step")


def human_loop_interaction_batch(stage: str, mode: str, depth: str, prompts: list[dict[str, Any]]) -> dict[str, Any]:
    question_count = len(prompts)
    max_questions = 1 if stage == "mode_consent" else human_loop_budget(depth, mode).get(stage, question_count)
    return {
        "stage": stage,
        "block_label": human_loop_stage_label(stage),
        "max_questions_this_turn": max_questions,
        "question_count": question_count,
        "ask_together": True,
        "next_stage": human_loop_next_stage(stage),
        "do_not_prefetch_future_questions": True,
    }


def build_human_loop(
    *,
    stage: str,
    human_loop_mode: str | None,
    human_loop_state: dict[str, Any] | None,
    text_type: str,
    text_type_source: str,
    domain: str,
    sensitivity: str,
    depth: str,
    snapshot_mode: str,
    retrieval_profile: str,
    source_completeness: str,
    silent_parse: dict[str, Any] | None = None,
    preview_before_reflection: dict[str, Any] | None = None,
) -> dict[str, Any]:
    prompt_stage = normalize_human_loop_stage(stage)
    incoming = human_loop_state_input(human_loop_state)
    requested_mode = normalize_human_loop_mode(human_loop_mode)
    mode = "guided" if prompt_stage == "mode_consent" else resolve_human_loop_mode(human_loop_mode, incoming)
    mode_consent = human_loop_mode_consent_state(incoming)
    configuration = dict(incoming.get("configuration")) if isinstance(incoming.get("configuration"), dict) else {}
    configuration.setdefault("text_type", human_loop_config_item(text_type, source=text_type_source, confidence="medium"))
    configuration.setdefault("domain", human_loop_config_item(domain, source="inferred", confidence="medium"))
    configuration.setdefault("depth", human_loop_config_item(depth, source="recommended_default", confidence="medium"))
    configuration.setdefault("snapshot_mode", human_loop_config_item(snapshot_mode, source="inferred" if snapshot_mode == "research" else "default", confidence="medium"))
    configuration.setdefault("retrieval_profile", human_loop_config_item(retrieval_profile, source="inferred", confidence="medium"))
    configuration.setdefault("goal_for_text", human_loop_config_item("unknown", source="not_asked", confidence="unknown"))
    configuration.setdefault("intended_audience", human_loop_config_item("unknown", source="not_asked", confidence="unknown"))
    configuration.setdefault("relationship_to_text", human_loop_config_item("unknown", source="not_asked", confidence="unknown"))
    configuration.setdefault("stakes", human_loop_config_item("high_stakes" if sensitivity == "high" else "routine", source="inferred", confidence="medium"))
    configuration.setdefault("output_format", human_loop_config_item(["full_audit"], source="default", confidence="medium"))
    configuration.setdefault("source_completeness", human_loop_config_item(source_completeness, source="inferred", confidence="medium"))

    try:
        audit_version = int(incoming.get("audit_version") or 1)
    except (TypeError, ValueError):
        audit_version = 1
    answered_ids = {first_text(item) for item in ensure_list(incoming.get("answered_prompt_ids")) if first_text(item)}
    skipped_ids = {first_text(item) for item in ensure_list(incoming.get("skipped_prompt_ids")) if first_text(item)}
    rerun_marker = human_loop_rerun_marker(incoming)
    stale_sections = ensure_list(incoming.get("stale_sections"))
    if rerun_marker:
        stale_sections = rerun_marker["stale_sections"]

    if human_loop_gate_overridden(incoming) and prompt_stage != "mode_consent":
        prompts: list[dict[str, Any]] = []
    elif prompt_stage == "mode_consent":
        prompts = human_loop_mode_consent_prompts(answered_ids, skipped_ids)
    elif prompt_stage == "reflection":
        prompts = human_loop_reflection_prompts(
            mode=mode,
            depth=depth,
            answered_ids=answered_ids,
            skipped_ids=skipped_ids,
            state=incoming,
            configuration=configuration,
        )
    elif prompt_stage == "judgment":
        prompts = human_loop_judgment_prompts(
            mode=mode,
            depth=depth,
            answered_ids=answered_ids,
            skipped_ids=skipped_ids,
            silent_parse=silent_parse,
        )
    else:
        prompts = human_loop_onboarding_prompts(
            mode=mode,
            depth=depth,
            answered_ids=answered_ids,
            skipped_ids=skipped_ids,
        )
    pending_ids = [prompt["id"] for prompt in prompts]
    phase = first_text(incoming.get("phase"))
    if rerun_marker:
        phase = "evidence_rerun_required"
    elif human_loop_gate_overridden(incoming) and prompt_stage != "mode_consent":
        phase = f"{prompt_stage}_overridden"
    elif prompt_stage == "mode_consent":
        phase = "mode_consent_pending" if pending_ids else "mode_consent_answered"
    elif prompt_stage == "reflection":
        phase = "reflection_pending" if pending_ids else "report_ready"
    elif prompt_stage == "judgment":
        phase = "judgment_pending" if pending_ids else "findings_ready"
    elif pending_ids:
        phase = "onboarding_pending"
    else:
        phase = "configured"

    state = {
        "audit_session_id": first_text(incoming.get("audit_session_id")) or make_record_id("audit"),
        "audit_version": audit_version,
        "phase": phase,
        "human_loop_mode": mode,
        "requested_human_loop_mode": requested_mode,
        "mode_consent": mode_consent,
        "configuration": configuration,
        "pending_prompt_ids": pending_ids,
        "answered_prompt_ids": sorted(answered_ids),
        "skipped_prompt_ids": sorted(skipped_ids),
        "stale_sections": stale_sections,
        "needs_rerun": bool(rerun_marker),
        "findings_frozen_at": incoming.get("findings_frozen_at") if incoming.get("findings_frozen_at") else (utc_now() if prompt_stage == "reflection" else None),
        "human_inputs": human_loop_input_lists(incoming),
        "learning_signals": human_loop_learning_signals(incoming),
    }
    if human_loop_gate_overridden(incoming):
        state["human_loop_override"] = True
    if skipped_ids:
        state["skipped_prompt_defaults"] = {
            prompt.get("id"): (prompt.get("on_skip") or {}).get("value")
            for prompt in [
                *human_loop_mode_consent_prompts(answered_ids=set(), skipped_ids=set()),
                *human_loop_onboarding_prompts(mode="guided", depth=depth, answered_ids=set(), skipped_ids=set()),
                *human_loop_judgment_prompts(mode="guided", depth=depth, answered_ids=set(), skipped_ids=set(), silent_parse=silent_parse),
                *human_loop_reflection_prompts(mode="guided", depth=depth, answered_ids=set(), skipped_ids=set(), state=incoming, configuration=configuration),
            ]
            if prompt.get("id") in skipped_ids
        }
    if silent_parse:
        state["silent_parse"] = silent_parse
    if preview_before_reflection:
        state["preview_before_reflection"] = preview_before_reflection
    if rerun_marker:
        state["rerun_marker"] = rerun_marker

    payload = {
        "stage": prompt_stage,
        "stage_aliases": {
            "mode_consent": ["silent_mode_consent", "human_loop_mode_consent"],
            "onboarding": ["pre_audit", "preflight"],
            "judgment": ["mid_audit", "middle"],
            "reflection": ["post_audit_reflection", "pre_output_reflection"],
        },
        "mode": mode,
        "requested_mode": requested_mode,
        "mode_consent": mode_consent,
        "question_budget": human_loop_budget(depth, mode),
        "state": state,
        "prompts": prompts,
        "interaction_batch": human_loop_interaction_batch(prompt_stage, mode, depth, prompts),
        "assumption_disclosure": human_loop_disclosures(state, mode),
        "pending_prompt_ids": pending_ids,
        "answered_prompt_ids": sorted(answered_ids),
        "skipped_prompt_ids": sorted(skipped_ids),
        "stale_sections": stale_sections,
        "needs_rerun": bool(rerun_marker),
        "audit_version": audit_version,
        "bounded_decision_rights": {
            "configuration": "Can affect audit setup, routing, wording, and report format.",
            "evidence": "Can affect findings only when new factual material marks sections stale and triggers rerun/version increment.",
            "commentary": "Can appear as labeled human commentary, but cannot change frozen findings.",
            "quarantined_opinion": "Early interpretive input is stored until after findings freeze.",
        },
        "input_classification_rules": {
            "verified_evidence": "Source material or document-backed factual correction; may change findings after rerun.",
            "user_asserted_context": "Unverified user context; label it and use caution before letting it affect framing.",
            "commentary": "Reflection, disagreement, author intent, or interpretation; never changes findings without rerun.",
            "quarantined_opinion": "Interpretive input volunteered before findings freeze; surface after the audit as prior expectation.",
        },
    }
    if silent_parse:
        payload["silent_parse"] = silent_parse
    if preview_before_reflection:
        payload["preview_before_reflection"] = preview_before_reflection
    return payload


def human_loop_host_action(human_loop: dict[str, Any] | None) -> dict[str, Any]:
    loop = human_loop if isinstance(human_loop, dict) else {}
    prompts = [prompt for prompt in ensure_list(loop.get("prompts")) if isinstance(prompt, dict)]
    mode = first_text(loop.get("mode"))
    state = loop.get("state") if isinstance(loop.get("state"), dict) else {}
    mode = mode or first_text(state.get("human_loop_mode"))
    stage = first_text(loop.get("stage") or state.get("phase"))
    interaction_batch = (
        loop.get("interaction_batch")
        if isinstance(loop.get("interaction_batch"), dict)
        else human_loop_interaction_batch(stage or "onboarding", mode or "guided", "standard", prompts)
    )
    native_ui_directive = (
        "Use Claude Desktop/Codex native question UI first when available. "
        "Do not ask these as a long inline chat questionnaire unless native UI is unavailable. "
        "Do not ask the full Human Loop questionnaire at once; ask only the current Human Loop block in questions_for_user."
    )
    fallback_directive = (
        "If native question UI is unavailable, render one compact inline multiple-choice block using only questions_for_user, "
        "respect selection_mode/max_selections, and do not prefetch or ask future-stage prompts."
    )
    base_action = {
        "preferred_interaction_surface": "native_host_question_ui",
        "fallback_interaction_surface": "compact_inline_question_block",
        "native_ui_directive": native_ui_directive,
        "fallback_rendering_directive": fallback_directive,
        "interaction_batch": interaction_batch,
    }
    if prompts and mode != "silent":
        if stage == "mode_consent":
            directive = (
                "PAUSE before the audit, silent parse, findings, scaffold exposure, or report generation. "
                "Silent mode was requested without confirmed user consent. Ask the one mode-consent prompt; if skipped or ambiguous, default to guided."
            )
        elif stage == "onboarding":
            directive = (
                "PAUSE before the core audit. Ask the onboarding prompts first. "
                "Skipped answers are allowed; pass updated human_loop.state back before continuing."
            )
        elif stage == "judgment":
            directive = (
                "PAUSE before revealing audit findings, scores, or bias labels. Ask the judgment prompts so the user can give a raw read first. "
                "Store answers as quarantined judgment; do not let them change findings unless they introduce verified evidence and trigger rerun."
            )
        elif stage == "reflection":
            directive = (
                "PAUSE before final PDF, Markdown, chat, save, or report output. Show only preview_before_reflection, ask the reflection prompts, "
                "then pass updated human_loop.state into the final output/report call."
            )
        else:
            directive = (
                "PAUSE before continuing. Ask the pending human_loop prompts, then pass the updated human_loop.state back on the next MCP call."
            )
        return {
            **base_action,
            "status": "human_loop_pending",
            "must_pause": True,
            "stage": stage,
            "directive": (
                directive
                + " "
                + native_ui_directive
                + " "
                + fallback_directive
                + " If the user explicitly requested a noninteractive smoke test, disclose skipped prompts and preserve pending_prompt_ids."
            ),
            "questions_for_user": [
                {
                    "id": prompt.get("id"),
                    "question": prompt.get("question"),
                    "choices": prompt.get("choices", []),
                    "default": prompt.get("default"),
                    "selection_mode": prompt.get("selection_mode", "single"),
                    "max_selections": prompt.get("max_selections", 1),
                    "allow_free_text": bool(prompt.get("allow_free_text")),
                    "free_text_prompt": prompt.get("free_text_prompt", ""),
                    "skill_tags": prompt.get("skill_tags", []),
                    "dynamic_options": prompt.get("dynamic_options", {}),
                    "why_i_am_asking": prompt.get("why_i_am_asking"),
                    "what_this_can_change": prompt.get("what_this_can_change") or prompt.get("this_can_change"),
                    "what_this_cannot_change": prompt.get("what_this_cannot_change") or prompt.get("this_cannot_change"),
                    "blocking": bool(prompt.get("blocking")),
                    "skippable": bool(prompt.get("skippable", True)),
                }
                for prompt in prompts
            ],
        }
    return {
        **base_action,
        "status": "no_human_loop_pause_required",
        "must_pause": False,
        "stage": stage,
        "directive": "No pending human-loop prompt needs to be asked before continuing. " + native_ui_directive,
        "questions_for_user": [],
    }


def normalize_kb_addition_status(value: str | None) -> str:
    status = normalize_text(value)
    if status in KB_ADDITION_STATUSES:
        return status
    return "draft"


def normalize_rhetorical_tradition(value: str | None) -> str:
    tradition = normalize_text(value)
    aliases = {
        "": "other",
        "western academic": "western_academic",
        "academic": "western_academic",
        "testimonial advocacy": "testimonial",
        "testimony": "testimonial",
        "lived experience": "testimonial",
        "indigenous oral": "indigenous_oral",
        "indigenous": "indigenous_oral",
        "oral": "indigenous_oral",
        "ubuntu": "ubuntu",
        "communal ubuntu": "ubuntu",
        "confucian daoist": "confucian",
        "confucian": "confucian",
        "daoist": "confucian",
        "liberation": "liberation_pedagogy",
        "liberation pedagogy": "liberation_pedagogy",
    }
    tradition = aliases.get(tradition, tradition.replace(" ", "_"))
    return tradition if tradition in RHETORICAL_TRADITIONS else "other"


def normalize_entity_type(value: str | None) -> str:
    entity_type = normalize_text(value).replace(" ", "_")
    aliases = {
        "bias": "bias",
        "biases": "bias",
        "thinking_lens": "thinking_lens",
        "lens": "thinking_lens",
        "framework": "framework",
        "reasoning_framework": "framework",
        "reasoning_flow": "reasoning_flow",
        "flow": "reasoning_flow",
        "fallacy": "fallacy",
        "methodology": "methodology",
        "reasoning_trap": "reasoning_trap",
        "reasoning_traps": "reasoning_trap",
        "reasoning_risk": "reasoning_trap",
        "reasoning_risks": "reasoning_trap",
        "trap": "reasoning_trap",
        "trap_detector": "reasoning_trap",
        "trap_detectors": "reasoning_trap",
        "disagreement": "disagreement_pattern",
        "disagreement_pattern": "disagreement_pattern",
        "dissent": "disagreement_pattern",
        "dissent_pattern": "disagreement_pattern",
        "kb_entry": "kb_entry",
        "blind_spot": "blind_spot_reminder",
        "blindspot": "blind_spot_reminder",
        "blind_spot_reminder": "blind_spot_reminder",
        "blindspot_reminder": "blind_spot_reminder",
        "blind_spot_reminders": "blind_spot_reminder",
    }
    return aliases.get(entity_type, entity_type or "kb_entry")


SENSITIVE_BLIND_SPOT_TERMS = {
    "age",
    "citizenship",
    "diagnosis",
    "disability",
    "ethnicity",
    "gender identity",
    "genetic",
    "health condition",
    "medical",
    "national origin",
    "pregnancy",
    "race",
    "religion",
    "sexual orientation",
}


def has_sensitive_blind_spot_text(*values: Any) -> bool:
    haystack = " ".join(normalize_text(value) for value in values if value is not None)
    return any(term in haystack for term in SENSITIVE_BLIND_SPOT_TERMS)


def blind_spot_slug(value: Any) -> str:
    text = normalize_text(value)
    slug = "".join(char if char.isalnum() else "-" for char in text)
    slug = "-".join(part for part in slug.split("-") if part)
    return slug[:80] or "reminder"


def normalize_activity_outcome(activity_outcome: dict[str, Any] | None, *, captured_at: str | None = None) -> dict[str, Any]:
    if not isinstance(activity_outcome, dict) or not activity_outcome:
        return {}
    choice = normalize_text(activity_outcome.get("choice") or activity_outcome.get("fit") or activity_outcome.get("decision"))
    choice_aliases = {
        "use it": "use",
        "use": "use",
        "used": "use",
        "swap it": "swap",
        "swap": "swap",
        "replace": "swap",
        "skip it": "skip",
        "skip": "skip",
    }
    normalized_choice = choice_aliases.get(choice, choice)
    if normalized_choice not in {"use", "swap", "skip"}:
        normalized_choice = ""
    normalized = {
        "activity_title": first_text(activity_outcome.get("activity_title") or activity_outcome.get("title")),
        "choice": normalized_choice,
        "usefulness": first_text(activity_outcome.get("usefulness") or activity_outcome.get("rating")),
        "notes": first_text(activity_outcome.get("notes") or activity_outcome.get("what_made_it_useful")),
        "captured_at": first_text(activity_outcome.get("captured_at")) or captured_at or utc_now(),
        "persistence": "saved_with_audit_result_only",
    }
    return {key: value for key, value in normalized.items() if value not in ("", None, [], {})}


def is_study_report(text: str) -> bool:
    lowered = text.lower()
    study_terms = [
        "study",
        "report",
        "participants",
        "sample",
        "randomized",
        "trial",
        "methods",
        "results",
        "survey",
        "experiment",
        "analysis",
        "effect size",
        "p-value",
        "confidence interval",
    ]
    return any(term in lowered for term in study_terms)


def is_vague_or_short(text: str) -> bool:
    return word_count(text) < 25 or len(split_sentences(text)) <= 1


def parse_concept_row(row: sqlite3.Row) -> dict[str, Any]:
    data = load_row_json(row)
    data["aliases"] = data["aliases_json"]
    data["related"] = data["related_json"]
    data["when_to_use"] = data["when_to_use_json"]
    data["failure_modes"] = data["failure_modes_json"]
    data["signals"] = data["signals_json"]
    data["anti_patterns"] = data["anti_patterns_json"]
    data["quality_flags"] = data["quality_flags_json"]
    data["provenance"] = data["provenance_json"]
    return data


def trim_sentences(text: str, limit: int = 3) -> str:
    sentences = split_sentences(text)
    if not sentences:
        return short_phrase(text, 40)
    return " ".join(sentences[:limit]).strip()


STATE_SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS state_metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS texts (
  text_id TEXT PRIMARY KEY,
  text_hash TEXT NOT NULL UNIQUE,
  full_text TEXT NOT NULL,
  summary TEXT,
  text_type TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_sessions (
  audit_id TEXT PRIMARY KEY,
  text_id TEXT NOT NULL,
  status TEXT NOT NULL,
  current_stage TEXT,
  resume_from TEXT,
  current_payload_json TEXT NOT NULL DEFAULT '{}',
  notes TEXT,
  next_action TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (text_id) REFERENCES texts (text_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_progress_events (
  event_id TEXT PRIMARY KEY,
  audit_id TEXT NOT NULL,
  stage TEXT,
  resume_from TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  notes TEXT,
  next_action TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (audit_id) REFERENCES audit_sessions (audit_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_results (
  result_id TEXT PRIMARY KEY,
  audit_id TEXT,
  text_id TEXT NOT NULL,
  text_type TEXT,
  cis_display_state TEXT,
  cis_label TEXT,
  cis_points INTEGER,
  cis_max_points INTEGER,
  score_confidence TEXT,
  comparability TEXT,
  snapshot_mode TEXT,
  evidence_convention TEXT,
  purpose TEXT,
  voice TEXT,
  knowledge_tradition TEXT,
  rhetorical_tradition TEXT,
  context_lens_json TEXT NOT NULL DEFAULT '{}',
  critical_integrity_snapshot_json TEXT NOT NULL DEFAULT '{}',
  replication_readiness_json TEXT NOT NULL DEFAULT '{}',
  biases_found_json TEXT NOT NULL DEFAULT '[]',
  verdict_json TEXT NOT NULL DEFAULT '{}',
  result_payload_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  FOREIGN KEY (audit_id) REFERENCES audit_sessions (audit_id) ON DELETE SET NULL,
  FOREIGN KEY (text_id) REFERENCES texts (text_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_result_dimensions (
  result_id TEXT NOT NULL,
  dimension_key TEXT NOT NULL,
  dimension_name TEXT NOT NULL,
  points INTEGER,
  max_points INTEGER,
  rationale TEXT,
  trace_json TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (result_id, dimension_key),
  FOREIGN KEY (result_id) REFERENCES audit_results (result_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_result_biases (
  result_id TEXT NOT NULL,
  bias_id TEXT,
  bias_name TEXT NOT NULL,
  confidence_weight TEXT,
  PRIMARY KEY (result_id, bias_name),
  FOREIGN KEY (result_id) REFERENCES audit_results (result_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS entity_patterns (
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  text_type TEXT NOT NULL,
  frequency INTEGER NOT NULL DEFAULT 0,
  last_context_note TEXT,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  PRIMARY KEY (entity_type, entity_id, text_type)
);

CREATE TABLE IF NOT EXISTS entity_pattern_events (
  event_id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  text_type TEXT NOT NULL,
  audit_id TEXT,
  frequency INTEGER NOT NULL DEFAULT 1,
  context_note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS kb_additions (
  addition_id TEXT PRIMARY KEY,
  entry_id TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  subcategory TEXT,
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  rhetorical_tradition TEXT NOT NULL DEFAULT 'other',
  aliases_json TEXT NOT NULL DEFAULT '[]',
  duplicate_candidates_json TEXT NOT NULL DEFAULT '[]',
  payload_json TEXT NOT NULL DEFAULT '{}',
  search_text TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_sessions_status ON audit_sessions (status, updated_at);
CREATE INDEX IF NOT EXISTS idx_audit_results_filters ON audit_results (text_type, cis_points, cis_label, created_at);
CREATE INDEX IF NOT EXISTS idx_audit_dimensions_score ON audit_result_dimensions (dimension_name, points);
CREATE INDEX IF NOT EXISTS idx_audit_biases_lookup ON audit_result_biases (bias_name, bias_id);
CREATE INDEX IF NOT EXISTS idx_entity_patterns_lookup ON entity_patterns (entity_type, entity_id, text_type);
CREATE INDEX IF NOT EXISTS idx_kb_additions_lookup ON kb_additions (status, category, kind, title);
"""


class StateStore:
    def __init__(self, db_path: Path, additions_pack_path: Path = USER_ADDITIONS_PACK_PATH) -> None:
        self.db_path = db_path
        self.additions_pack_path = additions_pack_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys = ON")
        self.connection.executescript(STATE_SCHEMA_SQL)
        self.connection.execute(
            "INSERT OR REPLACE INTO state_metadata (key, value) VALUES (?, ?)",
            ("schema_version", "1"),
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def ensure_text(
        self,
        subject_text: str | None,
        *,
        text_id: str | None = None,
        text_type: str | None = None,
        summary: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        text = subject_text or ""
        if not text and text_id:
            row = self.connection.execute("SELECT text_id FROM texts WHERE text_id = ?", (text_id,)).fetchone()
            if row:
                return str(row["text_id"])
            raise ValueError("text_id was provided but no saved text exists for it; include subject_text.")
        if not text:
            raise ValueError("subject_text is required when text_id is not already saved.")
        text_hash = sha256_text(re.sub(r"\s+", " ", text.strip()))
        existing = self.connection.execute("SELECT text_id FROM texts WHERE text_hash = ?", (text_hash,)).fetchone()
        computed_text_id = str(existing["text_id"]) if existing else text_id or make_text_id(text)
        now = utc_now()
        self.connection.execute(
            """
            INSERT INTO texts (text_id, text_hash, full_text, summary, text_type, metadata_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(text_id) DO UPDATE SET
              full_text=excluded.full_text,
              summary=COALESCE(excluded.summary, texts.summary),
              text_type=COALESCE(excluded.text_type, texts.text_type),
              metadata_json=excluded.metadata_json,
              updated_at=excluded.updated_at
            """,
            (
                computed_text_id,
                text_hash,
                text,
                summary or short_phrase(text, 28),
                normalize_text_type(text_type) if text_type else None,
                json_dumps(metadata or {}),
                now,
                now,
            ),
        )
        self.connection.commit()
        return computed_text_id

    def save_audit_progress(
        self,
        *,
        subject_text: str | None,
        audit_id: str | None = None,
        text_id: str | None = None,
        text_type: str | None = None,
        stage: str | None = None,
        resume_from: str | None = None,
        progress_payload: dict[str, Any] | None = None,
        cis_revision_event: dict[str, Any] | None = None,
        notes: str | None = None,
        next_action: str | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        saved_text_id = self.ensure_text(subject_text, text_id=text_id, text_type=text_type)
        audit_id = audit_id or make_record_id("audit")
        now = utc_now()
        payload = dict(progress_payload or {})
        if cis_revision_event:
            payload["cis_revision_event"] = {
                "stage": first_text(cis_revision_event.get("stage")) or stage or resume_from or "unknown",
                "prior_label": cis_revision_event.get("prior_label"),
                "prior_points": cis_revision_event.get("prior_points"),
                "new_label": cis_revision_event.get("new_label"),
                "new_points": cis_revision_event.get("new_points"),
                "prior_confidence": cis_revision_event.get("prior_confidence"),
                "new_confidence": cis_revision_event.get("new_confidence"),
                "comparability": cis_revision_event.get("comparability"),
                "reason": first_text(cis_revision_event.get("reason")),
                "evidence_ref": cis_revision_event.get("evidence_ref"),
            }
        current_stage = stage or resume_from or "unknown"
        self.connection.execute(
            """
            INSERT INTO audit_sessions (
              audit_id, text_id, status, current_stage, resume_from, current_payload_json,
              notes, next_action, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(audit_id) DO UPDATE SET
              text_id=excluded.text_id,
              status=excluded.status,
              current_stage=excluded.current_stage,
              resume_from=excluded.resume_from,
              current_payload_json=excluded.current_payload_json,
              notes=excluded.notes,
              next_action=excluded.next_action,
              updated_at=excluded.updated_at
            """,
            (
                audit_id,
                saved_text_id,
                status or "in_progress",
                current_stage,
                resume_from,
                json_dumps(payload),
                notes,
                next_action,
                now,
                now,
            ),
        )
        event_id = make_record_id("event")
        self.connection.execute(
            """
            INSERT INTO audit_progress_events (
              event_id, audit_id, stage, resume_from, payload_json, notes, next_action, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (event_id, audit_id, current_stage, resume_from, json_dumps(payload), notes, next_action, now),
        )
        self.connection.commit()
        return {
            "saved": True,
            "audit_id": audit_id,
            "text_id": saved_text_id,
            "status": status or "in_progress",
            "current_stage": current_stage,
            "resume_from": resume_from,
            "next_action": next_action,
            "saved_at": now,
        }

    def get_cis_revision_timeline(self, audit_id: str) -> dict[str, Any]:
        rows = self.connection.execute(
            "SELECT event_id, stage, payload_json, created_at FROM audit_progress_events WHERE audit_id = ? ORDER BY created_at ASC",
            (audit_id,),
        ).fetchall()
        timeline: list[dict[str, Any]] = []
        previous_points: int | None = None
        previous_confidence: str | None = None
        previous_comparability: str | None = None
        confidence_order = {"very_low": 0, "low": 1, "medium": 2, "high": 3, "very_high": 4}
        for row in rows:
            payload = json.loads(row["payload_json"] or "{}")
            event = payload.get("cis_revision_event") if isinstance(payload, dict) else None
            if not isinstance(event, dict):
                continue
            prior_points = event.get("prior_points")
            new_points = event.get("new_points")
            prior_confidence = first_text(event.get("prior_confidence")) or previous_confidence
            new_confidence = first_text(event.get("new_confidence")) or prior_confidence
            comparability = first_text(event.get("comparability")) or previous_comparability
            flags = {
                "confidence_dropped": confidence_order.get(new_confidence, 99) < confidence_order.get(prior_confidence, 99),
                "score_revised_upward": isinstance(prior_points, int) and isinstance(new_points, int) and new_points > prior_points,
                "score_revised_downward": isinstance(prior_points, int) and isinstance(new_points, int) and new_points < prior_points,
                "aggregate_withheld": first_text(event.get("new_label")).lower() in {"", "none", "null"} and new_points is None,
                "comparability_changed": bool(previous_comparability and comparability and comparability != previous_comparability),
            }
            timeline.append(
                {
                    "event_id": row["event_id"],
                    "stage": first_text(event.get("stage")) or row["stage"],
                    "created_at": row["created_at"],
                    "prior_label": event.get("prior_label"),
                    "prior_points": prior_points,
                    "new_label": event.get("new_label"),
                    "new_points": new_points,
                    "prior_confidence": prior_confidence,
                    "new_confidence": new_confidence,
                    "comparability": comparability,
                    "reason": event.get("reason"),
                    "evidence_ref": event.get("evidence_ref"),
                    "flags": flags,
                }
            )
            if isinstance(new_points, int):
                previous_points = new_points
            if new_confidence:
                previous_confidence = new_confidence
            if comparability:
                previous_comparability = comparability
        return {
            "found": bool(rows),
            "audit_id": audit_id,
            "revision_event_count": len(timeline),
            "timeline": timeline,
            "latest": timeline[-1] if timeline else None,
        }

    def get_audit_progress(self, audit_id: str) -> dict[str, Any]:
        row = self.connection.execute(
            """
            SELECT s.*, t.full_text, t.summary, t.text_type
            FROM audit_sessions s
            JOIN texts t ON t.text_id = s.text_id
            WHERE s.audit_id = ?
            """,
            (audit_id,),
        ).fetchone()
        if not row:
            return {"found": False, "audit_id": audit_id}
        events = self.connection.execute(
            "SELECT event_id, stage, resume_from, notes, next_action, created_at FROM audit_progress_events WHERE audit_id = ? ORDER BY created_at ASC",
            (audit_id,),
        ).fetchall()
        return {
            "found": True,
            "audit_id": row["audit_id"],
            "text_id": row["text_id"],
            "text_type": row["text_type"],
            "subject_text": row["full_text"],
            "summary": row["summary"],
            "status": row["status"],
            "current_stage": row["current_stage"],
            "resume_from": row["resume_from"],
            "prior_stage_payload": json.loads(row["current_payload_json"] or "{}"),
            "notes": row["notes"],
            "next_action": row["next_action"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "events": [dict(event) for event in events],
        }

    def list_audit_progress(self, status: str | None = None, text_type: str | None = None, limit: int = 20) -> dict[str, Any]:
        clauses = []
        params: list[Any] = []
        if status:
            clauses.append("s.status = ?")
            params.append(status)
        if text_type:
            clauses.append("t.text_type = ?")
            params.append(normalize_text_type(text_type))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        safe_limit = max(1, min(int(limit or 20), 100))
        rows = self.connection.execute(
            f"""
            SELECT s.audit_id, s.text_id, s.status, s.current_stage, s.resume_from, s.notes, s.next_action,
                   s.created_at, s.updated_at, t.summary, t.text_type
            FROM audit_sessions s
            JOIN texts t ON t.text_id = s.text_id
            {where}
            ORDER BY s.updated_at DESC
            LIMIT ?
            """,
            (*params, safe_limit),
        ).fetchall()
        return {"count": len(rows), "audits": [dict(row) for row in rows]}

    def _snapshot_columns(self, snapshot: dict[str, Any] | None, knowledge_tradition: str | None) -> dict[str, Any]:
        snapshot = snapshot or {}
        context_lens = snapshot.get("context_lens") if isinstance(snapshot.get("context_lens"), dict) else {}
        tradition = (
            knowledge_tradition
            or first_text(snapshot.get("knowledge_tradition"))
            or first_text(snapshot.get("rhetorical_tradition"))
            or first_text(context_lens.get("knowledge_tradition"))
            or first_text(context_lens.get("rhetorical_tradition"))
        )
        return {
            "display_state": first_text(snapshot.get("display_state")),
            "label": first_text(snapshot.get("label")) or None,
            "points": snapshot.get("points") if isinstance(snapshot.get("points"), int) else None,
            "max_points": snapshot.get("max_points") if isinstance(snapshot.get("max_points"), int) else None,
            "score_confidence": first_text(snapshot.get("score_confidence")) or None,
            "comparability": first_text(snapshot.get("comparability")) or None,
            "snapshot_mode": normalize_snapshot_mode(first_text(snapshot.get("snapshot_mode"))),
            "context_lens": context_lens,
            "evidence_convention": first_text(context_lens.get("evidence_convention")) or None,
            "purpose": first_text(context_lens.get("purpose")) or None,
            "voice": first_text(context_lens.get("voice")) or None,
            "knowledge_tradition": tradition or None,
            "rhetorical_tradition": normalize_rhetorical_tradition(tradition),
        }

    def save_audit_result(
        self,
        *,
        subject_text: str | None = None,
        text_id: str | None = None,
        audit_id: str | None = None,
        text_type: str | None = None,
        critical_integrity_snapshot: dict[str, Any] | None = None,
        biases_found: list[Any] | None = None,
        verdict: dict[str, Any] | str | None = None,
        replication_readiness: dict[str, Any] | None = None,
        result_payload: dict[str, Any] | None = None,
        activity_outcome: dict[str, Any] | None = None,
        timestamp: str | None = None,
        knowledge_tradition: str | None = None,
    ) -> dict[str, Any]:
        saved_text_id = self.ensure_text(subject_text, text_id=text_id, text_type=text_type)
        result_id = make_record_id("result")
        snapshot = critical_integrity_snapshot or {}
        cols = self._snapshot_columns(snapshot, knowledge_tradition)
        created_at = timestamp or utc_now()
        verdict_payload = verdict if isinstance(verdict, dict) else {"verdict": verdict} if verdict else {}
        payload = dict(result_payload or {})
        normalized_activity_outcome = normalize_activity_outcome(activity_outcome, captured_at=created_at)
        if normalized_activity_outcome:
            payload["activity_outcome"] = normalized_activity_outcome
        biases = ensure_list(biases_found)
        self.connection.execute(
            """
            INSERT INTO audit_results (
              result_id, audit_id, text_id, text_type, cis_display_state, cis_label,
              cis_points, cis_max_points, score_confidence, comparability, snapshot_mode,
              evidence_convention, purpose, voice, knowledge_tradition, rhetorical_tradition,
              context_lens_json, critical_integrity_snapshot_json, replication_readiness_json,
              biases_found_json, verdict_json, result_payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result_id,
                audit_id,
                saved_text_id,
                normalize_text_type(text_type) if text_type else None,
                cols["display_state"],
                cols["label"],
                cols["points"],
                cols["max_points"],
                cols["score_confidence"],
                cols["comparability"],
                cols["snapshot_mode"],
                cols["evidence_convention"],
                cols["purpose"],
                cols["voice"],
                cols["knowledge_tradition"],
                cols["rhetorical_tradition"],
                json_dumps(cols["context_lens"]),
                json_dumps(snapshot),
                json_dumps(replication_readiness or {}),
                json_dumps(biases),
                json_dumps(verdict_payload),
                json_dumps(payload),
                created_at,
            ),
        )
        for dimension in ensure_list(snapshot.get("dimensions") if isinstance(snapshot, dict) else []):
            if not isinstance(dimension, dict):
                continue
            name = first_text(dimension.get("name")) or "Unknown"
            dimension_key = normalize_text(name).replace(" ", "_")
            self.connection.execute(
                """
                INSERT INTO audit_result_dimensions (
                  result_id, dimension_key, dimension_name, points, max_points, rationale, trace_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result_id,
                    dimension_key,
                    name,
                    dimension.get("points") if isinstance(dimension.get("points"), int) else None,
                    dimension.get("max_points") if isinstance(dimension.get("max_points"), int) else None,
                    first_text(dimension.get("rationale")),
                    json_dumps(ensure_list(dimension.get("trace"))),
                ),
            )
        for item in biases:
            if isinstance(item, dict):
                bias_id = first_text(item.get("bias_id") or item.get("id") or item.get("kb_id") or item.get("entry_id")) or None
                bias_name = first_text(item.get("bias_name") or item.get("name") or item.get("title") or bias_id)
                confidence = first_text(item.get("confidence_weight") or item.get("confidence")) or None
            else:
                bias_id = None
                bias_name = first_text(item)
                confidence = None
            if bias_name:
                self.connection.execute(
                    "INSERT OR IGNORE INTO audit_result_biases (result_id, bias_id, bias_name, confidence_weight) VALUES (?, ?, ?, ?)",
                    (result_id, bias_id, bias_name, confidence),
                )
        self.connection.commit()
        return {
            "saved": True,
            "result_id": result_id,
            "audit_id": audit_id,
            "text_id": saved_text_id,
            "cis": {
                "display_state": cols["display_state"],
                "label": cols["label"],
                "points": cols["points"],
                "max_points": cols["max_points"],
                "score_confidence": cols["score_confidence"],
                "comparability": cols["comparability"],
            },
            "knowledge_tradition": cols["knowledge_tradition"],
            "rhetorical_tradition": cols["rhetorical_tradition"],
            "activity_outcome_saved": bool(normalized_activity_outcome),
            "saved_at": created_at,
        }

    def get_audit_result(self, result_id: str) -> dict[str, Any]:
        row = self.connection.execute(
            """
            SELECT r.*, t.full_text, t.summary
            FROM audit_results r
            JOIN texts t ON t.text_id = r.text_id
            WHERE r.result_id = ?
            """,
            (result_id,),
        ).fetchone()
        if not row:
            return {"found": False, "result_id": result_id}
        dimensions = self.connection.execute(
            "SELECT dimension_name, points, max_points, rationale, trace_json FROM audit_result_dimensions WHERE result_id = ? ORDER BY dimension_name",
            (result_id,),
        ).fetchall()
        biases = self.connection.execute(
            "SELECT bias_id, bias_name, confidence_weight FROM audit_result_biases WHERE result_id = ? ORDER BY bias_name",
            (result_id,),
        ).fetchall()
        result_payload = json.loads(row["result_payload_json"] or "{}")
        return {
            "found": True,
            **{key: row[key] for key in row.keys() if not key.endswith("_json")},
            "subject_text": row["full_text"],
            "summary": row["summary"],
            "context_lens": json.loads(row["context_lens_json"] or "{}"),
            "critical_integrity_snapshot": json.loads(row["critical_integrity_snapshot_json"] or "{}"),
            "replication_readiness": json.loads(row["replication_readiness_json"] or "{}"),
            "biases_found": [dict(item) for item in biases],
            "dimensions": [
                {
                    "name": item["dimension_name"],
                    "points": item["points"],
                    "max_points": item["max_points"],
                    "rationale": item["rationale"],
                    "trace": json.loads(item["trace_json"] or "[]"),
                }
                for item in dimensions
            ],
            "verdict": json.loads(row["verdict_json"] or "{}"),
            "result_payload": result_payload,
            "activity_outcome": result_payload.get("activity_outcome") if isinstance(result_payload.get("activity_outcome"), dict) else {},
        }

    def list_audit_results(
        self,
        *,
        text_type: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        bias: str | None = None,
        cis_label: str | None = None,
        cis_score: int | None = None,
        cis_score_min: int | None = None,
        cis_score_max: int | None = None,
        cis_score_below: int | None = None,
        dimension_name: str | None = None,
        dimension_score_below: int | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        clauses: list[str] = []
        params: list[Any] = []
        joins = ""
        if text_type:
            clauses.append("r.text_type = ?")
            params.append(normalize_text_type(text_type))
        if date_from:
            clauses.append("r.created_at >= ?")
            params.append(date_from)
        if date_to:
            clauses.append("r.created_at <= ?")
            params.append(date_to)
        if cis_label:
            clauses.append("r.cis_label = ?")
            params.append(cis_label)
        if cis_score is not None:
            clauses.append("r.cis_points = ?")
            params.append(int(cis_score))
        if cis_score_min is not None:
            clauses.append("r.cis_points >= ?")
            params.append(int(cis_score_min))
        if cis_score_max is not None:
            clauses.append("r.cis_points <= ?")
            params.append(int(cis_score_max))
        if cis_score_below is not None:
            clauses.append("r.cis_points < ?")
            params.append(int(cis_score_below))
        if bias:
            joins += " JOIN audit_result_biases b ON b.result_id = r.result_id"
            like = f"%{bias.lower()}%"
            clauses.append("(lower(b.bias_name) LIKE ? OR lower(COALESCE(b.bias_id, '')) LIKE ?)")
            params.extend([like, like])
        if dimension_score_below is not None:
            joins += " JOIN audit_result_dimensions d ON d.result_id = r.result_id"
            clauses.append("d.points < ?")
            params.append(int(dimension_score_below))
            if dimension_name:
                clauses.append("lower(d.dimension_name) = ?")
                params.append(dimension_name.lower())
        elif dimension_name:
            joins += " JOIN audit_result_dimensions d ON d.result_id = r.result_id"
            clauses.append("lower(d.dimension_name) = ?")
            params.append(dimension_name.lower())
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sort_field = "r.created_at"
        if normalize_text(sort_by) in {"cis score", "cis_score", "score", "points"}:
            sort_field = "r.cis_points"
        elif normalize_text(sort_by) in {"label", "cis label", "cis_label"}:
            sort_field = "r.cis_label"
        direction = "ASC" if normalize_text(sort_order) in {"asc", "ascending", "low to high"} else "DESC"
        safe_limit = max(1, min(int(limit or 25), 200))
        rows = self.connection.execute(
            f"""
            SELECT DISTINCT r.result_id, r.audit_id, r.text_id, r.text_type, r.cis_display_state,
                   r.cis_label, r.cis_points, r.cis_max_points, r.score_confidence,
                   r.comparability, r.evidence_convention, r.knowledge_tradition,
                   r.rhetorical_tradition, r.created_at, t.summary
            FROM audit_results r
            JOIN texts t ON t.text_id = r.text_id
            {joins}
            {where}
            ORDER BY {sort_field} {direction}, r.created_at DESC
            LIMIT ?
            """,
            (*params, safe_limit),
        ).fetchall()
        return {
            "count": len(rows),
            "filters": {
                "text_type": text_type,
                "date_from": date_from,
                "date_to": date_to,
                "bias": bias,
                "cis_label": cis_label,
                "cis_score": cis_score,
                "cis_score_min": cis_score_min,
                "cis_score_max": cis_score_max,
                "cis_score_below": cis_score_below,
                "dimension_name": dimension_name,
                "dimension_score_below": dimension_score_below,
                "sort_by": sort_by,
                "sort_order": sort_order,
            },
            "results": [dict(row) for row in rows],
        }

    def save_entity_pattern(
        self,
        *,
        entity_type: str,
        entity_id: str,
        text_type: str | None = None,
        frequency: int = 1,
        context_note: str | None = None,
        audit_id: str | None = None,
    ) -> dict[str, Any]:
        entity_type = normalize_entity_type(entity_type)
        entity_id = first_text(entity_id)
        if not entity_id:
            raise ValueError("entity_id is required")
        text_type_value = normalize_text_type(text_type)
        increment = max(1, int(frequency or 1))
        now = utc_now()
        self.connection.execute(
            """
            INSERT INTO entity_patterns (
              entity_type, entity_id, text_type, frequency, last_context_note, first_seen_at, last_seen_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(entity_type, entity_id, text_type) DO UPDATE SET
              frequency=entity_patterns.frequency + excluded.frequency,
              last_context_note=excluded.last_context_note,
              last_seen_at=excluded.last_seen_at
            """,
            (entity_type, entity_id, text_type_value, increment, context_note, now, now),
        )
        event_id = make_record_id("pattern")
        self.connection.execute(
            """
            INSERT INTO entity_pattern_events (
              event_id, entity_type, entity_id, text_type, audit_id, frequency, context_note, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (event_id, entity_type, entity_id, text_type_value, audit_id, increment, context_note, now),
        )
        self.connection.commit()
        row = self.connection.execute(
            "SELECT * FROM entity_patterns WHERE entity_type = ? AND entity_id = ? AND text_type = ?",
            (entity_type, entity_id, text_type_value),
        ).fetchone()
        return {"saved": True, "event_id": event_id, "pattern": dict(row)}

    def save_blind_spot_reminder(
        self,
        *,
        reminder_id: str,
        text_type: str | None = None,
        frequency: int = 1,
        context_note: str | None = None,
        audit_id: str | None = None,
        consent_confirmed: bool = False,
    ) -> dict[str, Any]:
        reminder = first_text(reminder_id)
        note = first_text(context_note)
        if not consent_confirmed:
            return {
                "saved": False,
                "requires_explicit_consent": True,
                "sensitive_profile_blocked": False,
                "error": "Explicit user consent is required before saving a blind-spot reminder.",
                "fix": "Ask the user whether they want to save this non-sensitive reasoning reminder, then retry with consent_confirmed=true.",
            }
        if not reminder:
            return {
                "saved": False,
                "requires_explicit_consent": True,
                "sensitive_profile_blocked": False,
                "error": "reminder_id is required.",
                "fix": "Provide a short non-sensitive reminder id such as comfortable-answer-risk.",
            }
        if has_sensitive_blind_spot_text(reminder, note):
            return {
                "saved": False,
                "requires_explicit_consent": True,
                "sensitive_profile_blocked": True,
                "error": "Blind-spot reminders must not profile sensitive personal traits.",
                "fix": "Save only non-sensitive reasoning patterns the user explicitly chooses to track.",
            }
        entity_id = reminder if reminder.startswith("ct:blind-spot:") else f"ct:blind-spot:{blind_spot_slug(reminder)}"
        bounded_note = cap_words(
            f"Consent-confirmed blind-spot reminder; non-sensitive pattern only. {note}".strip(),
            36,
        )
        result = self.save_entity_pattern(
            entity_type="blind_spot_reminder",
            entity_id=entity_id,
            text_type=text_type,
            frequency=frequency,
            context_note=bounded_note,
            audit_id=audit_id,
        )
        result.update(
            {
                "requires_explicit_consent": True,
                "consent_confirmed": True,
                "sensitive_profile_blocked": False,
                "entity_type": "blind_spot_reminder",
                "entity_id": entity_id,
                "guidance": "Use this as a user-approved reminder in future audits; do not infer sensitive traits or profile the user.",
            }
        )
        return result

    def get_pattern_summary(
        self,
        *,
        entity_type: str | None = None,
        text_type: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        clauses = []
        params: list[Any] = []
        if entity_type:
            clauses.append("entity_type = ?")
            params.append(normalize_entity_type(entity_type))
        if text_type:
            clauses.append("text_type = ?")
            params.append(normalize_text_type(text_type))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        safe_limit = max(1, min(int(limit or 20), 100))
        rows = self.connection.execute(
            f"""
            SELECT entity_type, entity_id, text_type, frequency, last_context_note, first_seen_at, last_seen_at
            FROM entity_patterns
            {where}
            ORDER BY frequency DESC, last_seen_at DESC
            LIMIT ?
            """,
            (*params, safe_limit),
        ).fetchall()
        return {"count": len(rows), "patterns": [dict(row) for row in rows]}

    def format_kb_addition(self, row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
        data = dict(row)
        payload = json.loads(data.get("payload_json") or "{}")
        aliases = json.loads(data.get("aliases_json") or "[]")
        return {
            "id": data["entry_id"],
            "entry_id": data["entry_id"],
            "addition_id": data["addition_id"],
            "name": data["title"],
            "title": data["title"],
            "category": data["category"],
            "subcategory": data.get("subcategory"),
            "kind": data["kind"],
            "definition": payload.get("definition"),
            "summary": payload.get("summary"),
            "example": first_text(payload.get("examples")),
            "examples": payload.get("examples"),
            "impact": payload.get("impact"),
            "mitigation": payload.get("mitigation"),
            "confidence_weight": payload.get("confidence_weight") or "medium",
            "three_cs_lens": payload.get("three_cs_lens") or "Critical",
            "related": payload.get("related_entry_ids") or payload.get("related") or [],
            "aliases": aliases,
            "rhetorical_tradition": data.get("rhetorical_tradition"),
            "editable": True,
            "source_scope": "user_overlay",
            "status": data.get("status"),
            "source": {
                "path": str(self.additions_pack_path),
                "source_type": "json",
                "source_collection": "user_overlay",
            },
            "payload": payload,
        }

    def lookup_kb_addition(
        self,
        query: str,
        *,
        category: str | None = None,
        categories: set[str] | None = None,
        active_only: bool = True,
    ) -> dict[str, Any] | None:
        q_norm = normalize_text(query)
        if not q_norm:
            return None
        clauses = []
        params: list[Any] = []
        if active_only:
            clauses.append("status = 'active'")
        if category:
            clauses.append("category = ?")
            params.append(category)
        if categories:
            placeholders = ",".join("?" for _ in categories)
            clauses.append(f"category IN ({placeholders})")
            params.extend(sorted(categories))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = self.connection.execute(
            f"SELECT * FROM kb_additions {where} ORDER BY updated_at DESC"
            ,
            params,
        ).fetchall()
        for row in rows:
            aliases = json.loads(row["aliases_json"] or "[]")
            values = [row["entry_id"], row["title"], *aliases]
            if any(normalize_text(value) == q_norm for value in values):
                return self.format_kb_addition(row)
        for row in rows:
            if q_norm in normalize_text(f"{row['title']} {row['search_text']}"):
                return self.format_kb_addition(row)
        return None

    def search_kb_additions(self, query: str, *, kind: str | None = None, category: str | None = None, limit: int = 10) -> list[dict[str, Any]]:
        q_norm = normalize_text(query)
        clauses = ["status = 'active'"]
        params: list[Any] = []
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        if category:
            clauses.append("category = ?")
            params.append(category)
        where = f"WHERE {' AND '.join(clauses)}"
        rows = self.connection.execute(
            f"SELECT * FROM kb_additions {where} ORDER BY updated_at DESC",
            params,
        ).fetchall()
        scored: list[tuple[int, dict[str, Any]]] = []
        for row in rows:
            text = normalize_text(f"{row['title']} {row['search_text']}")
            score = 0
            if q_norm and normalize_text(row["title"]) == q_norm:
                score += 100
            if q_norm and q_norm in text:
                score += 30
            score += len(set(tokenize(query)) & set(text.split())) * 5
            if score > 0 or not q_norm:
                scored.append((score, self.format_kb_addition(row)))
        scored.sort(key=lambda item: (-item[0], item[1].get("title") or ""))
        return [item for _, item in scored[: max(1, min(int(limit or 10), 50))]]

    def find_kb_addition_duplicates(self, title: str, aliases: list[str] | None = None) -> list[dict[str, Any]]:
        probes = [title, *(aliases or [])]
        rows = self.connection.execute(
            "SELECT * FROM kb_additions WHERE status != 'inactive' ORDER BY updated_at DESC"
        ).fetchall()
        duplicates = []
        probe_norms = {normalize_text(probe) for probe in probes if normalize_text(probe)}
        for row in rows:
            row_aliases = json.loads(row["aliases_json"] or "[]")
            values = {normalize_text(row["title"]), normalize_text(row["entry_id"]), *(normalize_text(alias) for alias in row_aliases)}
            if probe_norms & values:
                duplicates.append(
                    {
                        "source_scope": "user_overlay",
                        "id": row["entry_id"],
                        "addition_id": row["addition_id"],
                        "title": row["title"],
                        "status": row["status"],
                        "suggested_action": "Use this existing user addition or add the new label as an alias.",
                    }
                )
        return duplicates

    def save_kb_addition(
        self,
        *,
        payload: dict[str, Any],
        duplicate_candidates: list[dict[str, Any]] | None = None,
        status: str | None = None,
        confirm_active: bool = False,
    ) -> dict[str, Any]:
        requested_status = normalize_kb_addition_status(status)
        final_status = "active" if requested_status == "active" and confirm_active else "draft"
        title = first_text(payload.get("title"))
        if not title:
            raise ValueError("title is required")
        category = first_text(payload.get("category")) or "other"
        kind = first_text(payload.get("kind")) or "framework"
        aliases = [first_text(alias) for alias in ensure_list(payload.get("aliases")) if first_text(alias)]
        entry_id = first_text(payload.get("entry_id"))
        if not entry_id:
            slug = normalize_text(title).replace(" ", "-") or uuid4().hex[:8]
            entry_id = f"ct:user:{category}:{slug}-{uuid4().hex[:8]}"
        addition_id = make_record_id("kbadd")
        now = utc_now()
        rhetorical_tradition = normalize_rhetorical_tradition(first_text(payload.get("rhetorical_tradition")))
        payload = {
            **payload,
            "entry_id": entry_id,
            "category": category,
            "kind": kind,
            "aliases": aliases,
            "rhetorical_tradition": rhetorical_tradition,
            "status": final_status,
            "provenance": {
                **(payload.get("provenance") if isinstance(payload.get("provenance"), dict) else {}),
                "source_kind": "user-addition",
                "source_path": str(self.additions_pack_path),
                "source_type": "json",
                "source_collection": "user-overlay",
                "source_title": title,
            },
        }
        search_text = normalize_text(
            " ".join(
                [
                    title,
                    first_text(payload.get("summary")),
                    first_text(payload.get("definition")),
                    " ".join(aliases),
                    " ".join(first_text(tag) for tag in ensure_list(payload.get("tags"))),
                    rhetorical_tradition,
                ]
            )
        )
        self.connection.execute(
            """
            INSERT INTO kb_additions (
              addition_id, entry_id, title, category, subcategory, kind, status,
              rhetorical_tradition, aliases_json, duplicate_candidates_json,
              payload_json, search_text, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                addition_id,
                entry_id,
                title,
                category,
                first_text(payload.get("subcategory")) or None,
                kind,
                final_status,
                rhetorical_tradition,
                json_dumps(aliases),
                json_dumps(duplicate_candidates or []),
                json_dumps(payload),
                search_text,
                now,
                now,
            ),
        )
        self.connection.commit()
        self.export_active_kb_additions()
        return {
            "saved": True,
            "addition_id": addition_id,
            "entry_id": entry_id,
            "status": final_status,
            "requested_status": requested_status,
            "activation_note": None if final_status == "active" else "Saved as draft. Set status='active' with confirm_active=true after review to expose it in lookup/search.",
            "duplicate_candidates": duplicate_candidates or [],
            "rhetorical_tradition": rhetorical_tradition,
        }

    def list_kb_additions(self, status: str | None = None, category: str | None = None, limit: int = 50) -> dict[str, Any]:
        clauses = []
        params: list[Any] = []
        if status:
            clauses.append("status = ?")
            params.append(normalize_kb_addition_status(status))
        if category:
            clauses.append("category = ?")
            params.append(category)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        safe_limit = max(1, min(int(limit or 50), 200))
        rows = self.connection.execute(
            f"SELECT * FROM kb_additions {where} ORDER BY updated_at DESC LIMIT ?",
            (*params, safe_limit),
        ).fetchall()
        return {"count": len(rows), "additions": [self.format_kb_addition(row) for row in rows]}

    def get_kb_addition(self, addition_id_or_entry_id: str) -> dict[str, Any]:
        row = self.connection.execute(
            "SELECT * FROM kb_additions WHERE addition_id = ? OR entry_id = ?",
            (addition_id_or_entry_id, addition_id_or_entry_id),
        ).fetchone()
        if not row:
            return {"found": False, "query": addition_id_or_entry_id}
        return {"found": True, **self.format_kb_addition(row)}

    def update_kb_addition(
        self,
        addition_id_or_entry_id: str,
        *,
        updates: dict[str, Any] | None = None,
        status: str | None = None,
        confirm_active: bool = False,
    ) -> dict[str, Any]:
        existing = self.connection.execute(
            "SELECT * FROM kb_additions WHERE addition_id = ? OR entry_id = ?",
            (addition_id_or_entry_id, addition_id_or_entry_id),
        ).fetchone()
        if not existing:
            return {"found": False, "query": addition_id_or_entry_id}
        payload = json.loads(existing["payload_json"] or "{}")
        if updates:
            payload.update(updates)
        requested_status = normalize_kb_addition_status(status) if status is not None else str(existing["status"])
        final_status = "active" if requested_status == "active" and (confirm_active or status is None and existing["status"] == "active") else requested_status
        if status is not None and requested_status == "active" and not confirm_active:
            final_status = "draft"
        rhetorical_tradition = normalize_rhetorical_tradition(first_text(payload.get("rhetorical_tradition")) or existing["rhetorical_tradition"])
        payload["status"] = final_status
        payload["rhetorical_tradition"] = rhetorical_tradition
        aliases = [first_text(alias) for alias in ensure_list(payload.get("aliases")) if first_text(alias)]
        now = utc_now()
        search_text = normalize_text(
            " ".join([existing["title"], first_text(payload.get("summary")), first_text(payload.get("definition")), " ".join(aliases), rhetorical_tradition])
        )
        self.connection.execute(
            """
            UPDATE kb_additions
            SET status = ?, rhetorical_tradition = ?, aliases_json = ?, payload_json = ?,
                search_text = ?, updated_at = ?, deleted_at = CASE WHEN ? = 'inactive' THEN COALESCE(deleted_at, ?) ELSE deleted_at END
            WHERE addition_id = ?
            """,
            (
                final_status,
                rhetorical_tradition,
                json_dumps(aliases),
                json_dumps(payload),
                search_text,
                now,
                final_status,
                now,
                existing["addition_id"],
            ),
        )
        self.connection.commit()
        self.export_active_kb_additions()
        return {
            "updated": True,
            "addition_id": existing["addition_id"],
            "entry_id": existing["entry_id"],
            "status": final_status,
            "activation_note": None if final_status == "active" else "Not active in lookup/search until explicitly activated with confirm_active=true.",
        }

    def soft_delete_kb_addition(self, addition_id_or_entry_id: str, reason: str | None = None) -> dict[str, Any]:
        existing = self.connection.execute(
            "SELECT * FROM kb_additions WHERE addition_id = ? OR entry_id = ?",
            (addition_id_or_entry_id, addition_id_or_entry_id),
        ).fetchone()
        if not existing:
            return {"found": False, "query": addition_id_or_entry_id}
        payload = json.loads(existing["payload_json"] or "{}")
        payload["deleted_reason"] = reason
        now = utc_now()
        self.connection.execute(
            "UPDATE kb_additions SET status='inactive', payload_json=?, updated_at=?, deleted_at=? WHERE addition_id=?",
            (json_dumps(payload), now, now, existing["addition_id"]),
        )
        self.connection.commit()
        self.export_active_kb_additions()
        return {"deleted": True, "soft_delete": True, "addition_id": existing["addition_id"], "entry_id": existing["entry_id"], "deleted_at": now}

    def export_active_kb_additions(self) -> dict[str, Any]:
        rows = self.connection.execute(
            "SELECT payload_json FROM kb_additions WHERE status = 'active' ORDER BY title"
        ).fetchall()
        payloads = [json.loads(row["payload_json"] or "{}") for row in rows]
        self.additions_pack_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self.additions_pack_path.with_suffix(self.additions_pack_path.suffix + ".tmp")
        tmp_path.write_text(json.dumps(payloads, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        tmp_path.replace(self.additions_pack_path)
        return {"path": str(self.additions_pack_path), "active_count": len(payloads)}


class Repository:
    def __init__(self, db_path: Path) -> None:
        if not db_path.exists():
            raise FileNotFoundError(
                f"Critical Compass database not found at {db_path}. Run seed_db.py first."
            )
        self.connection = sqlite3.connect(
            f"file:{db_path}?mode=ro", uri=True, check_same_thread=False
        )
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA query_only = ON")
        self.metadata = {
            row["key"]: row["value"]
            for row in self.connection.execute("SELECT key, value FROM metadata").fetchall()
        }
        self.concepts = [parse_concept_row(row) for row in self.connection.execute("SELECT * FROM concepts").fetchall()]
        self.by_id = {row["concept_id"]: row for row in self.concepts}
        self.by_norm: dict[str, list[str]] = defaultdict(list)
        self.alias_to_ids: dict[str, list[str]] = defaultdict(list)
        self.bias_rows = [row for row in self.concepts if row["category"] == "biases"]
        self.framework_rows = [
            row
            for row in self.concepts
            if row["public_schema"] == "framework"
            or row["category"] in {"reasoning-frameworks", "thinking-lenses", "methodology-checks"}
            or row["kind"] in {"framework", "pattern", "methodology", "technique", "helper"}
        ]
        self.fallacy_rows = [row for row in self.concepts if row["category"] == "fallacies"]
        self.related_by_source: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in self.connection.execute(
            "SELECT source_concept_id, relation_type, target_concept_id, target_ref, confidence, metadata_json FROM relations"
        ).fetchall():
            self.related_by_source[row["source_concept_id"]].append(dict(row))

        for row in self.concepts:
            for value in [
                row["concept_id"],
                row.get("entry_id"),
                row.get("slug"),
                row.get("title"),
            ]:
                key = normalize_text(value)
                if key:
                    self.by_norm[key].append(row["concept_id"])
            for alias in row.get("aliases", []):
                key = normalize_text(alias)
                if key:
                    self.by_norm[key].append(row["concept_id"])

        for row in self.connection.execute("SELECT alias_norm, concept_id FROM aliases").fetchall():
            self.alias_to_ids[row["alias_norm"]].append(row["concept_id"])

        self.reasoning_flows = self._load_reasoning_flows()
        self.flows_by_id: dict[str, dict[str, Any]] = {}
        self.flows_by_entry_id: dict[str, dict[str, Any]] = {}
        self.flow_lookup: dict[str, list[str]] = defaultdict(list)
        self.flow_search_text: dict[str, str] = {}
        for flow in self.reasoning_flows:
            flow_id = str(flow.get("flow_id") or "")
            entry_id = str(flow.get("entry_id") or "")
            if not flow_id:
                continue
            self.flows_by_id[flow_id] = flow
            if entry_id:
                self.flows_by_entry_id[entry_id] = flow
            source_entry = flow.get("source_entry") if isinstance(flow.get("source_entry"), dict) else {}
            for value in [
                flow_id,
                entry_id,
                flow.get("entry_title"),
                source_entry.get("id"),
                source_entry.get("title"),
                source_entry.get("source_slug"),
            ]:
                key = normalize_text(first_text(value))
                if key:
                    self.flow_lookup[key].append(flow_id)
            self.flow_search_text[flow_id] = self._flow_text(flow)

    def close(self) -> None:
        self.connection.close()

    def _load_reasoning_flows(self) -> list[dict[str, Any]]:
        if not REASONING_FLOWS_DIR.exists():
            return []
        flows: list[dict[str, Any]] = []
        for path in sorted(REASONING_FLOWS_DIR.glob("*.flows.json")):
            if path.name.startswith("._"):
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(payload, list):
                continue
            for flow in payload:
                if not isinstance(flow, dict):
                    continue
                flow_copy = dict(flow)
                flow_copy["_source_path"] = str(path)
                flows.append(flow_copy)
        return flows

    def _flow_text(self, flow: dict[str, Any]) -> str:
        source_entry = flow.get("source_entry") if isinstance(flow.get("source_entry"), dict) else {}
        parts: list[str] = [
            first_text(flow.get("flow_id")),
            first_text(flow.get("entry_id")),
            first_text(flow.get("entry_title")),
            first_text(flow.get("category")),
            first_text(flow.get("subcategory")),
            first_text(flow.get("kind")),
            flow_namespace(flow),
            first_text(flow.get("purpose")),
            first_text(flow.get("output_contract")),
            first_text(source_entry.get("source_slug")),
        ]
        parts.extend(first_text(item) for item in ensure_list(flow.get("best_used_when")))
        parts.extend(first_text(item) for item in ensure_list(flow.get("inputs")))
        parts.extend(first_text(item) for item in ensure_list(flow.get("quality_checks")))
        parts.extend(first_text(item) for item in ensure_list(flow.get("failure_modes")))
        parts.extend(first_text(item) for item in ensure_list(flow.get("anti_patterns")))
        for step in ensure_list(flow.get("steps")):
            if not isinstance(step, dict):
                continue
            parts.extend(
                [
                    first_text(step.get("name")),
                    first_text(step.get("instruction")),
                    first_text(step.get("why_this_step")),
                    first_text(step.get("input_required")),
                    first_text(step.get("output_format")),
                    first_text(step.get("completion_check")),
                    first_text(step.get("if_stuck")),
                ]
            )
        return normalize_text(" ".join(part for part in parts if part))

    def _flow_summary(self, flow: dict[str, Any]) -> dict[str, Any]:
        source_entry = flow.get("source_entry") if isinstance(flow.get("source_entry"), dict) else {}
        return {
            "flow_id": flow.get("flow_id"),
            "entry_id": flow.get("entry_id"),
            "entry_title": flow.get("entry_title"),
            "category": flow.get("category"),
            "subcategory": flow.get("subcategory"),
            "kind": flow.get("kind"),
            "namespace": flow_namespace(flow),
            "purpose": flow.get("purpose"),
            "step_count": len(ensure_list(flow.get("steps"))),
            "source_entry": source_entry,
        }

    def _format_reasoning_flow(self, flow: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in flow.items() if not key.startswith("_")}

    def list_reasoning_flows_public(
        self,
        category: str | None = None,
        kind: str | None = None,
        namespace: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        safe_limit = max(1, min(int(limit or 100), 500))
        category_norm = normalize_text(category)
        kind_norm = normalize_text(kind)
        namespace_value = normalize_flow_namespace(namespace) if namespace else ""
        matches = []
        for flow in sorted(self.reasoning_flows, key=lambda item: first_text(item.get("entry_title"))):
            if category_norm and normalize_text(flow.get("category")) != category_norm:
                continue
            if kind_norm and normalize_text(flow.get("kind")) != kind_norm:
                continue
            if namespace_value and flow_namespace(flow) != namespace_value:
                continue
            matches.append(flow)
        return {
            "total_flows": len(self.reasoning_flows),
            "returned": min(len(matches), safe_limit),
            "filters": {"category": category, "kind": kind, "namespace": namespace_value or namespace},
            "flows": [self._flow_summary(flow) for flow in matches[:safe_limit]],
        }

    def _resolve_reasoning_flow(self, entry_id_or_flow_id: str) -> dict[str, Any] | None:
        raw = str(entry_id_or_flow_id or "").strip()
        if not raw:
            return None
        if raw in self.flows_by_id:
            return self.flows_by_id[raw]
        if raw in self.flows_by_entry_id:
            return self.flows_by_entry_id[raw]

        key = normalize_text(raw)
        for flow_id in self.flow_lookup.get(key, []):
            flow = self.flows_by_id.get(flow_id)
            if flow:
                return flow

        for concept in self.resolve(raw, limit=5):
            flow = self.flows_by_entry_id.get(concept.get("concept_id"))
            if flow:
                return flow
        return None

    def get_reasoning_flow_public(self, entry_id_or_flow_id: str) -> dict[str, Any]:
        flow = self._resolve_reasoning_flow(entry_id_or_flow_id)
        if flow:
            return {
                "found": True,
                **self._format_reasoning_flow(flow),
            }
        return {
            "found": False,
            "query": entry_id_or_flow_id,
            "candidates": self.search_reasoning_flows_public(entry_id_or_flow_id, limit=5)["results"],
        }

    def search_reasoning_flows_public(
        self,
        query: str,
        limit: int = 10,
        namespace: str | None = None,
    ) -> dict[str, Any]:
        safe_limit = max(1, min(int(limit or 10), 50))
        namespace_value = normalize_flow_namespace(namespace) if namespace else ""
        q_norm = normalize_text(query)
        q_tokens = set(tokenize(query))
        scored: list[tuple[float, dict[str, Any]]] = []
        for flow in self.reasoning_flows:
            if namespace_value and flow_namespace(flow) != namespace_value:
                continue
            flow_id = first_text(flow.get("flow_id"))
            flow_text = self.flow_search_text.get(flow_id) or self._flow_text(flow)
            title_norm = normalize_text(flow.get("entry_title"))
            entry_norm = normalize_text(flow.get("entry_id"))
            score = 0.0
            if q_norm and q_norm == title_norm:
                score += 100
            if q_norm and q_norm == entry_norm:
                score += 90
            if q_norm and q_norm in self.flow_lookup:
                score += 50
            if q_tokens:
                flow_tokens = set(flow_text.split())
                score += len(q_tokens & flow_tokens) * 5
            if q_norm and q_norm in flow_text:
                score += 10
            if score > 0:
                scored.append((score, flow))
        scored.sort(key=lambda item: (-item[0], first_text(item[1].get("entry_title"))))
        return {
            "query": query,
            "total_flows": len(self.reasoning_flows),
            "filters": {"namespace": namespace_value or namespace},
            "results": [
                {
                    **self._flow_summary(flow),
                    "score": round(score, 2),
                }
                for score, flow in scored[:safe_limit]
            ],
        }

    def lookup_exact_candidates(self, query: str) -> list[dict[str, Any]]:
        q_norm = normalize_text(query)
        if not q_norm:
            return []
        ids = []
        ids.extend(self.by_norm.get(q_norm, []))
        ids.extend(self.alias_to_ids.get(q_norm, []))
        seen: set[str] = set()
        results: list[dict[str, Any]] = []
        for concept_id in ids:
            if concept_id in seen:
                continue
            seen.add(concept_id)
            row = self.by_id.get(concept_id)
            if row:
                results.append(row)
        return results

    def rank_candidates(
        self,
        query: str,
        rows: list[dict[str, Any]],
        *,
        category: str | None = None,
        kinds: set[str] | None = None,
    ) -> list[dict[str, Any]]:
        q_norm = normalize_text(query)
        q_tokens = set(tokenize(query))
        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            score = 0.0
            title_norm = normalize_text(row.get("title"))
            slug_norm = normalize_text(row.get("slug"))
            entry_norm = normalize_text(row.get("concept_id"))
            if q_norm and q_norm == title_norm:
                score += 100
            if q_norm and q_norm == slug_norm:
                score += 95
            if q_norm and q_norm == entry_norm:
                score += 90
            row_aliases = [normalize_text(alias) for alias in row.get("aliases", [])]
            if q_norm and q_norm in row_aliases:
                score += 85
            if q_tokens:
                title_tokens = set(tokenize(row.get("title")))
                summary_tokens = set(tokenize(row.get("summary")))
                definition_tokens = set(tokenize(row.get("definition")))
                score += len(q_tokens & title_tokens) * 8
                score += len(q_tokens & summary_tokens) * 4
                score += len(q_tokens & definition_tokens) * 2
            if category and row.get("category") == category:
                score += 10
            if kinds and row.get("kind") in kinds:
                score += 5
            confidence = row.get("confidence")
            if confidence is not None:
                try:
                    score += float(confidence) * 4
                except (TypeError, ValueError):
                    pass
            scored.append((score, row))
        scored.sort(key=lambda item: (-item[0], item[1].get("title", "")))
        return [row for _, row in scored]

    def resolve(
        self,
        query: str,
        *,
        category: str | None = None,
        categories: set[str] | None = None,
        kinds: set[str] | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        exact = self.lookup_exact_candidates(query)
        if exact:
            filtered = [
                row
                for row in exact
                if (category is None or row.get("category") == category)
                and (not categories or row.get("category") in categories)
                and (not kinds or row.get("kind") in kinds)
            ]
            if filtered:
                return self.rank_candidates(query, filtered, category=category, kinds=kinds)[:limit]

        q_norm = normalize_text(query)
        if q_norm in self.alias_to_ids or q_norm in self.by_norm:
            ids = list(dict.fromkeys(self.alias_to_ids.get(q_norm, []) + self.by_norm.get(q_norm, [])))
            rows = [self.by_id[concept_id] for concept_id in ids if concept_id in self.by_id]
        else:
            rows = self._fts_search(query, limit=limit * 5)

        filtered = [
            row
            for row in rows
            if (category is None or row.get("category") == category)
            and (not categories or row.get("category") in categories)
            and (not kinds or row.get("kind") in kinds)
        ]
        if not filtered:
            return []
        return self.rank_candidates(query, filtered, category=category, kinds=kinds)[:limit]

    def _fts_search(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        tokens = tokenize(query)
        if not tokens:
            return []
        fts_query = " ".join(tokens[:8])
        try:
            rows = self.connection.execute(
                """
                SELECT c.*, bm25(concept_fts) AS rank
                FROM concept_fts
                JOIN concepts c ON c.rowid = concept_fts.rowid
                WHERE concept_fts MATCH ?
                ORDER BY rank ASC
                LIMIT ?
                """,
                (fts_query, limit),
            ).fetchall()
            return [parse_concept_row(row) for row in rows]
        except sqlite3.OperationalError:
            like = "%" + "%".join(tokens[:5]) + "%"
            rows = self.connection.execute(
                """
                SELECT *
                FROM concepts
                WHERE lower(title) LIKE lower(?)
                   OR lower(summary) LIKE lower(?)
                   OR lower(definition) LIKE lower(?)
                   OR lower(search_text) LIKE lower(?)
                LIMIT ?
                """,
                (like, like, like, like, limit),
            ).fetchall()
            return [parse_concept_row(row) for row in rows]

    def best_match(
        self,
        query: str,
        *,
        category: str | None = None,
        categories: set[str] | None = None,
        kinds: set[str] | None = None,
    ) -> dict[str, Any] | None:
        matches = self.resolve(query, category=category, categories=categories, kinds=kinds, limit=5)
        return matches[0] if matches else None

    def lookup_bias(self, name: str) -> dict[str, Any] | None:
        return self.best_match(name, categories={"biases"})

    def lookup_framework(self, thinking_lens: str) -> dict[str, Any] | None:
        return self.best_match(
            thinking_lens,
            categories={"reasoning-frameworks", "thinking-lenses", "methodology-checks", "other"},
            kinds={"framework", "pattern", "methodology", "technique", "helper"},
        )

    def search(self, query: str, *, kind: str | None = None, category: str | None = None, limit: int = 10) -> list[dict[str, Any]]:
        kinds = {kind} if kind else None
        categories = {category} if category else None
        matches = self.resolve(query, categories=categories, kinds=kinds, limit=limit * 2)
        if matches:
            return matches[:limit]
        rows = self._fts_search(query, limit=limit * 2)
        filtered = [
            row
            for row in rows
            if (kind is None or row.get("kind") == kind)
            and (category is None or row.get("category") == category)
        ]
        return self.rank_candidates(query, filtered, category=category, kinds=kinds)[:limit]

    def _format_public_row(self, row: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": row["concept_id"],
            "entry_id": row.get("entry_id"),
            "name": row.get("title"),
            "title": row.get("title"),
            "category": row.get("category"),
            "subcategory": row.get("subcategory"),
            "kind": row.get("kind"),
            "definition": row.get("definition"),
            "summary": row.get("summary"),
            "example": row.get("example"),
            "examples": row.get("examples"),
            "impact": row.get("impact"),
            "mitigation": row.get("mitigation"),
            "confidence_weight": confidence_weight(row.get("confidence_weight") or row.get("confidence")),
            "three_cs_lens": row.get("three_cs_lens") or "Critical",
            "related": row.get("related"),
            "aliases": row.get("aliases"),
            "source": {
                "path": row.get("source_path"),
                "normalized_path": row.get("normalized_path"),
                "source_type": row.get("source_type"),
                "source_collection": row.get("source_collection"),
            },
        }

    def _format_full_public_row(self, row: dict[str, Any]) -> dict[str, Any]:
        provenance = row.get("provenance") or {}
        source = {
            "path": row.get("source_path"),
            "normalized_path": row.get("normalized_path"),
            "source_type": provenance.get("source_type") if isinstance(provenance, dict) else None,
            "source_collection": provenance.get("source_collection") if isinstance(provenance, dict) else None,
            "source_slug": provenance.get("source_slug") if isinstance(provenance, dict) else None,
            "source_title": provenance.get("source_title") if isinstance(provenance, dict) else None,
        }
        return {
            "id": row["concept_id"],
            "entry_id": row.get("entry_id"),
            "slug": row.get("slug"),
            "title": row.get("title"),
            "category": row.get("category"),
            "subcategory": row.get("subcategory"),
            "kind": row.get("kind"),
            "public_schema": row.get("public_schema"),
            "summary": row.get("summary"),
            "definition": row.get("definition"),
            "example": row.get("example"),
            "examples": row.get("examples_json"),
            "impact": row.get("impact"),
            "mitigation": row.get("mitigation"),
            "confidence": row.get("confidence"),
            "confidence_weight": confidence_weight(row.get("confidence_weight") or row.get("confidence")),
            "three_cs_lens": row.get("three_cs_lens") or "Critical",
            "aliases": row.get("aliases"),
            "related": row.get("related"),
            "when_to_use": row.get("when_to_use"),
            "failure_modes": row.get("failure_modes"),
            "signals": row.get("signals"),
            "anti_patterns": row.get("anti_patterns"),
            "quality_flags": row.get("quality_flags"),
            "provenance": provenance,
            "source": source,
        }

    def list_categories_public(self) -> dict[str, Any]:
        categories: dict[str, dict[str, Any]] = {}
        for row in sorted(
            self.concepts,
            key=lambda item: (
                item.get("category") or "",
                item.get("subcategory") or "",
                item.get("kind") or "",
                item.get("title") or "",
            ),
        ):
            category = row.get("category") or "uncategorized"
            subcategory = row.get("subcategory") or ""
            kind = row.get("kind") or ""
            public_schema = row.get("public_schema") or ""
            bucket = categories.setdefault(
                category,
                {
                    "category": category,
                    "count": 0,
                    "subcategories": {},
                    "kinds": {},
                    "public_schemas": {},
                    "entry_ids": [],
                },
            )
            bucket["count"] += 1
            bucket["subcategories"][subcategory] = bucket["subcategories"].get(subcategory, 0) + 1
            bucket["kinds"][kind] = bucket["kinds"].get(kind, 0) + 1
            bucket["public_schemas"][public_schema] = bucket["public_schemas"].get(public_schema, 0) + 1
            bucket["entry_ids"].append(row["concept_id"])

        category_list = []
        for category in sorted(categories):
            bucket = categories[category]
            bucket["subcategories"] = dict(sorted(bucket["subcategories"].items()))
            bucket["kinds"] = dict(sorted(bucket["kinds"].items()))
            bucket["public_schemas"] = dict(sorted(bucket["public_schemas"].items()))
            category_list.append(bucket)

        facet_counts: list[dict[str, Any]] = []
        for category in category_list:
            for subcategory, count in category["subcategories"].items():
                facet_counts.append(
                    {
                        "category": category["category"],
                        "subcategory": subcategory,
                        "count": count,
                    }
                )

        return {
            "metadata": self.metadata,
            "total_entries": len(self.concepts),
            "categories": category_list,
            "category_subcategory_counts": facet_counts,
        }

    def get_entry_public(self, entry_id_or_slug: str) -> dict[str, Any]:
        matches = self.resolve(entry_id_or_slug, limit=5)
        if not matches:
            return {
                "found": False,
                "query": entry_id_or_slug,
                "candidates": self.search_public(entry_id_or_slug, limit=5)["results"],
            }
        return {
            "found": True,
            **self._format_full_public_row(matches[0]),
        }

    def lookup_bias_public(self, name: str) -> dict[str, Any]:
        row = self.lookup_bias(name)
        if not row:
            return {"found": False, "query": name, "candidates": self.search(name, category="biases", limit=5)}
        related = []
        for related_id in parse_json_field(row.get("related_json"), []):
            related_row = self.by_id.get(str(related_id))
            if related_row and related_row.get("category") == "biases":
                related.append({"id": related_row["concept_id"], "name": related_row["title"]})
        return {
            "found": True,
            **self._format_public_row(row),
            "related_biases": related,
            "confidence_weight": confidence_weight(row.get("confidence_weight") or row.get("confidence")),
        }

    def lookup_framework_public(self, thinking_lens: str) -> dict[str, Any]:
        row = self.lookup_framework(thinking_lens)
        if not row:
            return {
                "found": False,
                "query": thinking_lens,
                "candidates": [
                    self._format_public_row(candidate)
                    for candidate in self.search(thinking_lens, kind="framework", limit=5)
                ],
            }
        description_parts = [part for part in [row.get("summary"), row.get("definition")] if part]
        when_to_use = parse_json_field(row.get("when_to_use_json"), [])
        example = row.get("example") or (when_to_use[0] if when_to_use else "")
        description = trim_sentences(" ".join(description_parts) or row.get("title", ""), 3)
        if when_to_use:
            description = trim_sentences(f"{description} Use it when {when_to_use[0]}.", 3)
        return {
            "found": True,
            "id": row["concept_id"],
            "name": row.get("title"),
            "type": row.get("kind"),
            "category": row.get("category"),
            "subcategory": row.get("subcategory"),
            "description": description,
            "example": short_phrase(example, 40),
            "three_cs_lens": row.get("three_cs_lens") or "Critical",
            "aliases": row.get("aliases"),
            "source": {
                "path": row.get("source_path"),
                "normalized_path": row.get("normalized_path"),
                "source_type": row.get("source_type"),
                "source_collection": row.get("source_collection"),
            },
        }

    def search_public(self, query: str, *, kind: str | None = None, category: str | None = None, limit: int = 10) -> dict[str, Any]:
        rows = [self._format_public_row(row) for row in self.search(query, kind=kind, category=category, limit=limit)]
        return {
            "query": query,
            "filters": {"kind": kind, "category": category, "limit": limit},
            "results": rows,
        }

    def find_bias_hits(self, text: str) -> list[dict[str, Any]]:
        lowered = text.lower()
        hits: list[dict[str, Any]] = []
        seen: set[str] = set()

        for row in self.bias_rows:
            aliases = [row.get("title", "")] + parse_json_field(row.get("aliases_json"), [])
            matched_trigger = None
            exact = False
            for alias in aliases:
                alias_norm = normalize_text(alias)
                if alias_norm and alias_norm in normalize_text(text):
                    matched_trigger = alias
                    exact = True
                    break
            if not matched_trigger:
                for trigger_bias, triggers in BIAS_TRIGGER_RULES:
                    if normalize_text(trigger_bias) != normalize_text(row.get("title")) and normalize_text(trigger_bias) not in normalize_text(row.get("title")):
                        continue
                    for trigger in triggers:
                        if trigger in lowered:
                            matched_trigger = trigger
                            break
                    if matched_trigger:
                        break
            if not matched_trigger:
                continue

            key = row["concept_id"]
            if key in seen:
                continue
            seen.add(key)
            sentence = next((sentence for sentence in split_sentences(text) if matched_trigger.lower() in sentence.lower()), text)
            evidence = sentence_with_trigger(sentence, matched_trigger)
            evidence = short_phrase(evidence, 12)
            confidence = "high" if exact else "medium"
            if row.get("confidence") is not None and float(row["confidence"]) < 0.7:
                confidence = "low" if not exact else confidence
            hits.append(
                {
                    "bias_id": row["concept_id"],
                    "claim_passage": short_phrase(sentence, 20),
                    "bias_name": row.get("title"),
                    "evidence": evidence,
                    "why_it_qualifies": row.get("definition") or row.get("summary"),
                    "impact_on_reader": row.get("impact") or row.get("definition") or row.get("summary"),
                    "confidence": confidence,
                    "three_cs_lens": row.get("three_cs_lens") or "Critical",
                }
            )
        return hits

    def _concept_terms(self, row: dict[str, Any]) -> set[str]:
        return set(
            tokenize(
                text_blob(
                    row.get("title"),
                    row.get("summary"),
                    row.get("definition"),
                    row.get("impact"),
                    row.get("mitigation"),
                    row.get("aliases"),
                    row.get("when_to_use"),
                    row.get("signals"),
                    row.get("anti_patterns"),
                )
            )
        )

    def _best_sentence_for_terms(self, text: str, terms: set[str]) -> tuple[str, list[str]]:
        sentences = split_sentences(text)
        if not sentences:
            return short_phrase(text, 12), []
        text_tokens = set(tokenize(text))
        shared_terms = sorted(text_tokens & terms)
        if not shared_terms:
            return short_phrase(sentences[0], 12), []
        best_sentence = sentences[0]
        best_score = -1
        for sentence in sentences:
            sentence_tokens = set(tokenize(sentence))
            score = sum(3 for term in shared_terms if term in sentence_tokens)
            if score > best_score:
                best_score = score
                best_sentence = sentence
        return best_sentence, shared_terms[:4]

    def _research_methodology_bias_rows(self) -> list[dict[str, Any]]:
        priority_names = {normalize_text(name) for name in RESEARCH_METHODOLOGY_BIAS_NAMES}
        rows = [
            row
            for row in self.bias_rows
            if normalize_text(row.get("title")) in priority_names
            or normalize_text(row.get("subcategory")) == "methodology"
            or any("domain:research" in normalize_text(tag) or "class:methodology" in normalize_text(tag) for tag in parse_json_field(row.get("tags_json"), []))
        ]
        rows.sort(
            key=lambda row: (
                RESEARCH_METHODOLOGY_BIAS_NAMES.index(row.get("title"))
                if row.get("title") in RESEARCH_METHODOLOGY_BIAS_NAMES
                else 999,
                row.get("title") or "",
            )
        )
        return rows

    def find_research_methodology_bias_hits(self, text: str, *, limit: int = 7, exclude: Iterable[str] | None = None) -> list[dict[str, Any]]:
        lowered = text.lower()
        normalized = normalize_text(text)
        excluded = {normalize_text(value) for value in (exclude or []) if normalize_text(value)}
        hits: list[dict[str, Any]] = []
        seen: set[str] = set()
        text_tokens = set(tokenize(text))
        sentences = split_sentences(text)

        for row in self._research_methodology_bias_rows():
            concept_id = row["concept_id"]
            title = first_text(row.get("title"))
            title_norm = normalize_text(title)
            if concept_id in seen or normalize_text(concept_id) in excluded or title_norm in excluded:
                continue
            aliases = [title, *parse_json_field(row.get("aliases_json"), [])]
            signals = parse_json_field(row.get("signals_json"), [])
            cue_terms = [first_text(item) for item in [*aliases, *signals] if first_text(item)]
            for cue_key, cues in RESEARCH_METHODOLOGY_CUE_RULES.items():
                if cue_key in title_norm:
                    cue_terms.extend(cues)
            matched_cues: list[str] = []
            for cue in cue_terms:
                cue_norm = normalize_text(cue)
                if not cue_norm:
                    continue
                if cue.lower() in lowered or cue_norm in normalized:
                    matched_cues.append(cue)
            terms = self._concept_terms(row)
            shared_terms = sorted(text_tokens & terms)
            if not matched_cues and len(shared_terms) < 3:
                continue
            sentence, sentence_terms = self._best_sentence_for_terms(text, terms)
            if matched_cues:
                sentence = next(
                    (
                        candidate
                        for candidate in sentences
                        if any(cue.lower() in candidate.lower() for cue in matched_cues)
                    ),
                    sentence,
                )
            confidence = "high" if matched_cues and normalize_text(matched_cues[0]) in {title_norm, *[normalize_text(alias) for alias in aliases]} else "medium"
            if not matched_cues:
                confidence = "low"
            hits.append(
                {
                    "bias_id": concept_id,
                    "claim_passage": short_phrase(sentence, 20),
                    "bias_name": title,
                    "evidence": short_phrase(sentence_with_trigger(sentence, matched_cues[0]) if matched_cues else sentence, 12),
                    "why_it_qualifies": trim_sentences(
                        f"{row.get('definition') or row.get('summary') or title} "
                        f"Research-methodology cues: {', '.join((matched_cues or sentence_terms or shared_terms)[:4])}.",
                        2,
                    ),
                    "impact_on_reader": row.get("impact") or row.get("definition") or row.get("summary"),
                    "confidence": confidence,
                    "three_cs_lens": row.get("three_cs_lens") or "Critical",
                    "retrieval_profile": "research_methodology",
                }
            )
            seen.add(concept_id)
            if len(hits) >= limit:
                break
        return hits

    def find_bias_candidates(self, text: str, *, limit: int = 3, exclude: Iterable[str] | None = None) -> list[dict[str, Any]]:
        candidates = self.search(text, category="biases", limit=max(5, limit * 3))
        excluded = {normalize_text(value) for value in (exclude or []) if normalize_text(value)}
        hits: list[dict[str, Any]] = []
        seen: set[str] = set()
        text_tokens = set(tokenize(text))
        for row in candidates:
            concept_id = row["concept_id"]
            if concept_id in seen or normalize_text(concept_id) in excluded:
                continue
            terms = self._concept_terms(row)
            shared_terms = sorted(text_tokens & terms)
            if not shared_terms:
                continue
            sentence, sentence_terms = self._best_sentence_for_terms(text, terms)
            confidence = "low"
            if len(shared_terms) >= 4 or normalize_text(row.get("title")) in normalize_text(text):
                confidence = "medium"
            if row.get("confidence") is not None:
                try:
                    if float(row["confidence"]) < 0.7:
                        confidence = "low"
                except (TypeError, ValueError):
                    pass
            hits.append(
                {
                    "bias_id": concept_id,
                    "claim_passage": short_phrase(sentence, 20),
                    "bias_name": row.get("title"),
                    "evidence": short_phrase(sentence, 12),
                    "why_it_qualifies": trim_sentences(
                        f"{row.get('definition') or row.get('summary') or row.get('title') or ''} "
                        f"The text shares cues with this concept: {', '.join(sentence_terms or shared_terms[:3])}.",
                        2,
                    ),
                    "impact_on_reader": row.get("impact") or row.get("definition") or row.get("summary"),
                    "confidence": confidence,
                    "three_cs_lens": row.get("three_cs_lens") or "Critical",
                }
            )
            seen.add(concept_id)
            if len(hits) >= limit:
                break

        if len(hits) < limit:
            lowered = text.lower()
            for row in self.bias_rows:
                concept_id = row["concept_id"]
                if concept_id in seen or normalize_text(concept_id) in excluded:
                    continue
                title_norm = normalize_text(row.get("title"))
                fallback_cues: list[str] = []
                for cue_key, cues in BIAS_FALLBACK_RULES:
                    cue_norm = normalize_text(cue_key)
                    if cue_norm and cue_norm in title_norm:
                        fallback_cues.extend(cues)
                if not fallback_cues:
                    continue
                matched_cues = [cue for cue in fallback_cues if cue in lowered]
                if not matched_cues:
                    continue
                sentence = next((sentence for sentence in split_sentences(text) if any(cue in sentence.lower() for cue in matched_cues)), split_sentences(text)[0] if split_sentences(text) else text)
                confidence = "medium" if len(matched_cues) >= 2 else "low"
                hits.append(
                    {
                        "bias_id": concept_id,
                        "claim_passage": short_phrase(sentence, 20),
                        "bias_name": row.get("title"),
                        "evidence": short_phrase(sentence_with_trigger(sentence, matched_cues[0]), 12),
                        "why_it_qualifies": trim_sentences(
                            f"{row.get('definition') or row.get('summary') or row.get('title') or ''} "
                            f"Fallback cues in the text: {', '.join(matched_cues[:3])}.",
                            2,
                        ),
                        "impact_on_reader": row.get("impact") or row.get("definition") or row.get("summary"),
                        "confidence": confidence,
                        "three_cs_lens": row.get("three_cs_lens") or "Critical",
                    }
                )
                seen.add(concept_id)
                if len(hits) >= limit:
                    break
        return hits

    def find_persuasive_bias_hits(
        self,
        text: str,
        *,
        text_type: str,
        limit: int = 7,
        exclude: Iterable[str] | None = None,
    ) -> list[dict[str, Any]]:
        if text_type not in PERSUASIVE_TEXT_TYPES and text_type != "ai_generated":
            return []
        lowered = text.lower()
        excluded = {normalize_text(value) for value in (exclude or []) if normalize_text(value)}
        hits: list[dict[str, Any]] = []
        seen: set[str] = set()
        sentences = split_sentences(text)

        for cue_bundle in PERSUASIVE_BIAS_CUES:
            matched_cues = [cue for cue in cue_bundle["cues"] if cue in lowered]
            if not matched_cues:
                continue
            row = self.lookup_bias(str(cue_bundle["bias"]))
            if not row:
                continue
            concept_id = row["concept_id"]
            if concept_id in seen or normalize_text(concept_id) in excluded or normalize_text(row.get("title")) in excluded:
                continue
            sentence = next(
                (
                    sentence
                    for sentence in sentences
                    if any(cue in sentence.lower() for cue in matched_cues)
                ),
                sentences[0] if sentences else text,
            )
            hits.append(
                {
                    "bias_id": concept_id,
                    "claim_passage": short_phrase(sentence, 20),
                    "bias_name": row.get("title"),
                    "evidence": short_phrase(sentence_with_trigger(sentence, matched_cues[0]), 12),
                    "why_it_qualifies": trim_sentences(
                        f"{row.get('definition') or row.get('summary') or row.get('title') or ''} "
                        f"{cue_bundle['reason']} Persuasive-text cues: {', '.join(matched_cues[:3])}.",
                        2,
                    ),
                    "impact_on_reader": row.get("impact") or row.get("definition") or row.get("summary"),
                    "confidence": cue_bundle["confidence"],
                    "three_cs_lens": row.get("three_cs_lens") or "Critical",
                }
            )
            seen.add(concept_id)
            if len(hits) >= limit:
                break
        return hits

    def review_placeholder_bias(self, text: str) -> dict[str, Any]:
        sentences = split_sentences(text)
        sentence = sentences[0] if sentences else text
        return {
            "bias_id": "ct:bias-review-needed",
            "claim_passage": short_phrase(sentence, 20),
            "bias_name": "No direct sourced bias match",
            "evidence": short_phrase(sentence, 12),
            "why_it_qualifies": "The excerpt is substantive enough for review, but no knowledge-base bias entry matched strongly enough to label it.",
            "impact_on_reader": "Treat this as a review placeholder and continue with assumptions, probing questions, and alternative frames.",
            "confidence": "low",
            "three_cs_lens": "Critical",
        }

    def methodology_check(self, text: str) -> dict[str, Any] | None:
        if not is_study_report(text):
            return None
        lowered = text.lower()
        return {
            "sampling": self._methodology_note(
                lowered,
                ["sample", "participants", "cohort", "population", "survey", "sampling"],
                "Sampling is not fully stated in the excerpt.",
                "The excerpt names a sample or participant pool.",
            ),
            "measures_endpoints": self._methodology_note(
                lowered,
                ["endpoint", "outcome", "measure", "metric", "questionnaire", "scale"],
                "Measures or endpoints are not fully stated in the excerpt.",
                "The excerpt identifies what was measured or counted.",
            ),
            "design_stats": self._methodology_note(
                lowered,
                ["randomized", "controlled", "trial", "regression", "p-value", "confidence interval", "effect size", "experimental"],
                "The design or statistics are not fully stated in the excerpt.",
                "The excerpt signals a design or statistical approach.",
            ),
            "dose_context": self._methodology_note(
                lowered,
                ["dose", "context", "setting", "duration", "exposure", "dose-response", "context"],
                "Dose or context is not fully stated in the excerpt.",
                "The excerpt names a dose, setting, or context.",
            ),
            "safe_vs_beneficial": self._methodology_note(
                lowered,
                ["safe", "beneficial", "risk", "adverse", "harm", "benefit"],
                "Safety and benefit are not clearly separated in the excerpt.",
                "The excerpt distinguishes safety from benefit.",
            ),
        }

    def _methodology_note(self, lowered: str, terms: list[str], missing_note: str, positive_note: str) -> dict[str, str]:
        if any(term in lowered for term in terms):
            return {"assessment": positive_note, "status": "observed"}
        return {"assessment": missing_note, "status": "not stated"}


def format_assumptions(text: str, sensitivity: str) -> list[dict[str, Any]]:
    assumptions = [
        {
            "assumption": "The excerpt is complete enough to support a judgment.",
            "status": "testable",
        },
        {
            "assumption": "The evidence shown is representative rather than cherry-picked.",
            "status": "testable",
        },
        {
            "assumption": "The conclusion matches the strength of the evidence.",
            "status": "testable",
        },
        {
            "assumption": "Value judgments are not being presented as facts.",
            "status": "not testable",
        },
    ]
    if sensitivity == "high":
        assumptions.insert(
            0,
            {
                "assumption": "The text can be interpreted without assuming facts that are not in view.",
                "status": "testable",
            },
        )
    return assumptions


def bias_summary(row: dict[str, Any]) -> str:
    impact = row.get("impact") or row.get("definition") or row.get("summary") or ""
    mitigation = row.get("mitigation") or ""
    if mitigation:
        return trim_sentences(f"{impact} Counter with {mitigation}.", 2)
    return trim_sentences(impact, 2)


def frame_context_flags(text: str, domain: str, text_type: str | None = None, domain_hint: str | None = None) -> dict[str, bool]:
    context_text = normalize_text(" ".join([text, domain, text_type or "", domain_hint or ""]))
    return {
        "technology": any(term in context_text for term in ["ai", "algorithm", "model", "digital", "platform", "automation", "data", "technology"]),
        "governance": any(term in context_text for term in ["governance", "accountability", "policy", "regulation", "oversight", "decision rights", "framework"]),
        "systems": any(term in context_text for term in ["system", "process", "workflow", "organization", "feedback", "incentive", "complex", "pipeline"]),
        "structural": any(term in context_text for term in ["community", "stakeholder", "equity", "power", "access", "harm", "identity", "representation", "nonprofit", "sector"]),
        "cultural": any(
            term in context_text
            for term in [
                "indigenous",
                "kinship",
                "reciprocity",
                "stewardship",
                "all my relations",
                "relational",
                "decolon",
                "colonial",
                "maori",
                "yol u",
                "two eyed seeing",
                "ganma",
                "kaitiakitanga",
                "protocol",
                "non human",
                "land",
                "country",
                "ancestr",
            ]
        ),
    }


def lookup_alternative_frame(repo: Repository, query: str) -> dict[str, Any] | None:
    q_norm = normalize_text(query)
    search_matches = repo.search(query, limit=8)
    if "argument" in q_norm and "map" in q_norm:
        for candidate in search_matches:
            if "argument mapping" in normalize_text(candidate.get("title")):
                return candidate
    for candidate in search_matches:
        title_norm = normalize_text(candidate.get("title"))
        if q_norm and (q_norm == title_norm or q_norm in title_norm):
            return candidate
    row = repo.lookup_framework(query)
    if row:
        return row
    allowed_categories = {"reasoning-frameworks", "thinking-lenses", "methodology-checks", "other"}
    for candidate in search_matches:
        if candidate.get("category") in allowed_categories:
            return candidate
    return None


def choose_alternative_frames(
    repo: Repository,
    text: str,
    domain: str,
    bias_hits: list[dict[str, Any]],
    *,
    text_type: str | None = None,
    domain_hint: str | None = None,
) -> list[dict[str, Any]]:
    queries = list(FALLBACK_FRAME_QUERIES.get(domain, FALLBACK_FRAME_QUERIES["default"]))
    flags = frame_context_flags(text, domain, text_type=text_type, domain_hint=domain_hint)
    if flags["technology"] or flags["governance"] or text_type == "policy":
        queries = TECH_GOVERNANCE_FRAME_QUERIES + queries
    elif flags["systems"]:
        queries = SYSTEMS_FRAME_QUERIES + queries
    if flags["structural"] or text_type in {"advocacy", "policy"}:
        queries = STRUCTURAL_FRAME_QUERIES + queries
    if flags["cultural"] or any(
        any(term in normalize_text(hit.get("title") or hit.get("id") or "") for term in ("anthropocentric", "dehumanization", "ingroup", "authority"))
        for hit in bias_hits
    ):
        queries = [
            "cross-cultural anti-flattening",
            "all my relations",
            "reciprocity stewardship",
            "kaitiakitanga guardianship",
            "two-eyed seeing",
            "ganma knowledge confluence",
        ] + queries
    if bias_hits:
        queries.insert(0, "argument map")
    frames: list[dict[str, Any]] = []
    seen: set[str] = set()
    for query in join_unique(queries):
        row = lookup_alternative_frame(repo, query)
        if not row:
            continue
        key = row["concept_id"]
        if key in seen:
            continue
        seen.add(key)
        description = trim_sentences(
            f"{row.get('title')}: {row.get('summary') or row.get('definition') or ''}",
            2,
        )
        example = row.get("example") or ""
        if example:
            description = trim_sentences(f"{description} Example: {example}.", 3)
        frames.append(
            {
                "id": row["concept_id"],
                "name": row.get("title"),
                "frame": short_phrase(description, 40),
                "three_cs_lens": row.get("three_cs_lens") or "Critical",
            }
        )
        if len(frames) >= 2:
            break
    return frames


def probing_questions(domain: str, bias_hits: list[dict[str, Any]], sensitivity: str) -> list[str]:
    if domain == "research study/report":
        questions = [
            "What sample or comparison group is missing from view?",
            "Which endpoint matters most, and who decided that?",
            "What alternative explanation fits the same results?",
        ]
    elif domain == "news article":
        questions = [
            "What source is doing the real evidentiary work here?",
            "What context would weaken the strongest reading of this claim?",
            "What other explanation could fit the same facts?",
        ]
    elif domain == "email":
        questions = [
            "What is the sender actually asking for?",
            "What assumptions are baked into the request?",
            "What response would be safest if the context is incomplete?",
        ]
    elif domain == "social media post":
        questions = [
            "What was cut away before the post reached you?",
            "What would you need to verify before resharing?",
            "What is the strongest alternative interpretation?",
        ]
    elif domain == "speech excerpt":
        questions = [
            "What is the claim behind the rhetoric?",
            "What audience pressure may be shaping the framing?",
            "What evidence would you want before agreeing?",
        ]
    else:
        questions = [
            "What context is missing from the excerpt?",
            "What would the strongest counter-view say?",
            "What evidence would change your mind?",
        ]
    if sensitivity == "high":
        questions = [question.replace("you", "the reader") for question in questions]
    return questions[:3]


def follow_up_questions(domain: str, sensitivity: str) -> list[str]:
    questions = list(FOLLOW_UP_BY_DOMAIN.get(domain, FOLLOW_UP_BY_DOMAIN["default"]))
    if sensitivity == "high":
        return [question.replace("you", "the reader") for question in questions[:3]]
    return questions[:3]


def choose_fallacy(repo: Repository, claim: str) -> dict[str, Any]:
    lowered = claim.lower()
    chosen_query = "unsupported certainty"
    if any(marker in lowered for marker in ["either", "or ", "only two", "one of two", "no other option"]):
        chosen_query = "false dilemma"
    elif any(marker in lowered for marker in ["because", "caused", "causes", "therefore", "led to", "after ", "since "]):
        chosen_query = "causal overreach"
    elif any(marker in lowered for marker in ["definitely", "certainly", "always", "never", "obviously", "absolutely"]):
        chosen_query = "unsupported certainty"
    elif any(marker in lowered for marker in ["they are", "he is", "she is", "stupid", "lazy", "incompetent"]):
        chosen_query = "ad hominem"
    elif any(marker in lowered for marker in ["everyone", "most people", "popular", "trending", "all of us"]):
        chosen_query = "bandwagon"

    row = repo.lookup_framework(chosen_query)
    if not row:
        row = repo.lookup_bias(chosen_query)
    if not row:
        row = repo.best_match(chosen_query, categories={"fallacies"}) or repo.fallacy_rows[:1]
    if isinstance(row, list):
        row = row[0] if row else None
    if not row:
        return {"name": chosen_query, "definition": "A named reasoning risk could not be resolved from the catalog.", "confidence": "low"}
    return {
        "id": row["concept_id"],
        "name": row.get("title"),
        "definition": row.get("definition") or row.get("summary"),
        "why_it_fits": trim_sentences(
            f"{row.get('definition') or row.get('summary') or ''} The claim wording suggests this risk.",
            2,
        ),
        "confidence": "high" if chosen_query in normalize_text(row.get("title")) else "medium",
    }


def build_steelman(claim: str, domain: str, fallacy: dict[str, Any]) -> str:
    opener = "A charitable opposing view is that"
    if domain == "research study/report":
        body = "the finding may still be useful, but the design, sample, or endpoints need clearer scrutiny before the conclusion is treated as settled."
    elif domain == "news article":
        body = "the reported claim may reflect a real pattern, but the excerpt may not yet show enough context, sourcing, or comparison to justify the strongest conclusion."
    elif domain == "email":
        body = "the sender may have a legitimate need, but the request may be missing context, constraints, or alternatives that would change the response."
    elif domain == "social media post":
        body = "the post may be pointing to a real concern, but the phrasing may be compressing nuance and over-carrying the conclusion."
    elif domain == "speech excerpt":
        body = "the speaker may be emphasizing a genuine concern, but the rhetoric may be moving faster than the evidence and the boundaries of the claim."
    else:
        body = "the claim may capture a real concern, but the argument still needs clearer scope, evidence, and alternative explanations."
    if fallacy.get("name"):
        body += f" The strongest version should avoid {fallacy['name'].lower()}."
    return trim_sentences(f"{opener} {body}", 3)


def clean_claim_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def claim_scope_warning(claim: str, raw_claim: str | None = None) -> str | None:
    word_count = len(claim.split())
    sentence_count = len(re.findall(r"[.!?]+(?:\s+|$)", claim))
    if "\n" in str(raw_claim or "") or word_count > 60:
        return "This looks like a paragraph. The card focuses on the most visible claim; rerun with one sentence for a sharper stress test."
    if sentence_count > 1 or ";" in claim:
        return "This may contain more than one claim. Treat this card as a first pass and rerun on the single highest-stakes sentence if needed."
    return None


def fallacy_steelman_risk(fallacy: dict[str, Any]) -> str:
    name = normalize_text(fallacy.get("name"))
    if name in FALLACY_STEELMAN_RISKS:
        return FALLACY_STEELMAN_RISKS[name]
    for key, risk in FALLACY_STEELMAN_RISKS.items():
        if key in name:
            return risk
    return "The same pattern may be reasonable when the claim is bounded, the evidence is visible, and uncertainty is stated plainly."


def claim_stress_questions(fallacy: dict[str, Any], domain: str, audience: str | None = None) -> list[str]:
    name = normalize_text(fallacy.get("name"))
    if "false dilemma" in name:
        lead = "What third option, hybrid, or constraint is being hidden?"
    elif "causal overreach" in name:
        lead = "What comparison or mechanism would separate causation from timing?"
    elif "bandwagon" in name:
        lead = "What evidence would still matter if popularity were ignored?"
    elif "ad hominem" in name:
        lead = "Is the person's credibility actually relevant to this claim?"
    elif "unsupported certainty" in name:
        lead = "What level of confidence would the visible evidence actually justify?"
    else:
        lead = "What assumption does the claim need in order to work?"

    questions = [
        lead,
        "What would make the strongest version of this claim narrower or fairer?",
        "What evidence would most directly weaken or strengthen it?",
    ]
    if clean_claim_text(audience):
        questions.append("What would this audience need before acting on the claim?")
    if domain == "research study/report":
        questions.append("What sample, measure, or comparison would make the inference more reliable?")
    return questions[:3]


def claim_next_actions(fallacy: dict[str, Any]) -> list[dict[str, str]]:
    name = first_text(fallacy.get("name")) or "reasoning risk"
    return [
        {
            "id": "tighten_claim",
            "label": "Tighten the claim",
            "prompt": "Rewrite the claim with narrower scope, visible evidence, and a clearer confidence level.",
        },
        {
            "id": "test_counterclaim",
            "label": "Test the counterclaim",
            "prompt": "State the strongest counterclaim and the evidence that would decide between the two readings.",
        },
        {
            "id": "inspect_risk",
            "label": f"Inspect {name}",
            "prompt": f"Explain why {name} may fit here and when that same pattern would be valid reasoning.",
        },
    ]


def claim_stress_markdown_card(
    claim: str,
    steelman: str,
    fallacy_risk: dict[str, Any],
    when_not_a_fallacy: str,
    probing: list[str],
    next_actions: list[dict[str, str]],
    scope_warning: str | None = None,
) -> str:
    lines = [
        "## Claim Stress-Test",
        "",
        f"**Claim:** {claim}",
    ]
    if scope_warning:
        lines.extend(["", f"**Scope note:** {scope_warning}"])
    lines.extend(
        [
            "",
            "### Steelman",
            steelman,
            "",
            "### Fallacy Risk",
            f"{fallacy_risk.get('risk_label')}: {fallacy_risk.get('why_it_fits') or fallacy_risk.get('definition')}",
            "",
            "### When This May Not Be A Fallacy",
            when_not_a_fallacy,
            "",
            "### Probing Questions",
        ]
    )
    lines.extend(f"- {question}" for question in probing)
    lines.extend(["", "### Next Actions"])
    lines.extend(f"- **{action['label']}:** {action['prompt']}" for action in next_actions)
    return "\n".join(lines)


def claim_challenge_core(
    repo: Repository,
    claim: str,
    context: str | None = None,
    audience: str | None = None,
) -> dict[str, Any]:
    clean_claim = clean_claim_text(claim)
    context_text = clean_claim_text(context)
    domain_input = " ".join(part for part in [clean_claim, context_text] if part)
    domain, domain_signals = detect_domain(domain_input or clean_claim)
    base_fallacy = choose_fallacy(repo, clean_claim)
    steelman = build_steelman(clean_claim, domain, base_fallacy)
    when_not_a_fallacy = fallacy_steelman_risk(base_fallacy)
    probing = claim_stress_questions(base_fallacy, domain, audience)
    next_actions = claim_next_actions(base_fallacy)
    fallacy_risk = {
        **base_fallacy,
        "risk_label": f"{first_text(base_fallacy.get('name')) or 'Reasoning'} risk",
        "assessment": "risk_not_verdict",
        "caveat": "Treat this as a reasoning risk to inspect, not a final verdict on the claim.",
    }
    scope_warning = claim_scope_warning(clean_claim, raw_claim=claim)
    markdown_card = claim_stress_markdown_card(
        clean_claim,
        steelman,
        fallacy_risk,
        when_not_a_fallacy,
        probing,
        next_actions,
        scope_warning=scope_warning,
    )
    return {
        "claim": clean_claim,
        "context": context_text or None,
        "audience": clean_claim_text(audience) or None,
        "domain": domain,
        "domain_signals": domain_signals,
        "steelman": steelman,
        "fallacy_risk": fallacy_risk,
        "legacy_fallacy_risk": base_fallacy,
        "when_not_a_fallacy": when_not_a_fallacy,
        "probing_questions": probing,
        "legacy_probing_questions": [
            "What would the strongest opposing view say?",
            "What evidence would make this claim weaker or stronger?",
        ],
        "next_actions": next_actions,
        "scope_warning": scope_warning,
        "markdown_card": markdown_card,
    }


def challenge_claim_payload(repo: Repository, claim: str) -> dict[str, Any]:
    challenge = claim_challenge_core(repo, claim)
    return {
        "claim": challenge["claim"],
        "steelman": challenge["steelman"],
        "fallacy_risk": challenge["legacy_fallacy_risk"],
        "probing_questions": challenge["legacy_probing_questions"],
    }


def claim_stress_test_payload(
    repo: Repository,
    claim: str,
    context: str | None = None,
    audience: str | None = None,
) -> dict[str, Any]:
    clean_claim = clean_claim_text(claim)
    host_ai_directive = (
        "Render stress_test_card as an interactive card when the host UI supports it. "
        "Treat fallacy_risk as a risk, not a verdict. Offer next_actions as buttons or quick replies."
    )
    if not clean_claim:
        return {
            "status": "blocked",
            "claim": "",
            "domain": "unknown",
            "stress_test_card": {
                "title": "Claim Stress-Test",
                "state": "needs_claim",
                "message": "Paste one clear claim to stress-test.",
            },
            "steelman": "",
            "fallacy_risk": None,
            "when_not_a_fallacy": "",
            "probing_questions": [],
            "next_actions": [
                {
                    "id": "provide_claim",
                    "label": "Paste one claim",
                    "prompt": "Provide one sentence that makes a claim, recommendation, prediction, or causal assertion.",
                }
            ],
            "markdown_card": "## Claim Stress-Test\n\nPaste one clear claim to stress-test.",
            "host_ai_directive": host_ai_directive,
            "input_guidance": "Provide one sentence that makes a claim, recommendation, prediction, or causal assertion.",
        }

    challenge = claim_challenge_core(repo, claim, context=context, audience=audience)
    follow_up_activity = follow_up_activity_for_context(
        challenge["domain"],
        [first_text(challenge["fallacy_risk"].get("name"))],
        text_type="single_claim",
        key_tension=challenge["claim"],
        recommended_next_step="Stress-test the support and narrow the claim if needed.",
        subject_hint=challenge["claim"],
        depth="quick",
    )
    stress_test_card = {
        "title": "Claim Stress-Test",
        "state": "ready",
        "claim": challenge["claim"],
        "domain": challenge["domain"],
        "badges": [
            {"label": "Risk, not verdict", "tone": "caution"},
            {"label": f"{challenge['fallacy_risk'].get('confidence', 'medium')} confidence", "tone": "neutral"},
        ],
        "sections": [
            {"id": "steelman", "title": "Steelman", "body": challenge["steelman"]},
            {"id": "fallacy_risk", "title": "Fallacy Risk", "body": challenge["fallacy_risk"]},
            {"id": "when_not_a_fallacy", "title": "When This May Not Be A Fallacy", "body": challenge["when_not_a_fallacy"]},
            {"id": "probing_questions", "title": "Probing Questions", "body": challenge["probing_questions"]},
        ],
        "actions": challenge["next_actions"],
        "follow_up_activity": {
            "try_this_next": follow_up_activity.get("try_this_next"),
            "source_note": follow_up_activity.get("source_note"),
            "fit_check": follow_up_activity.get("fit_check"),
        },
    }
    if challenge["scope_warning"]:
        stress_test_card["scope_warning"] = challenge["scope_warning"]

    return {
        "status": "card_ready",
        "claim": challenge["claim"],
        "domain": challenge["domain"],
        "plain_language_read": "This claim may be useful, but it needs its support, scope, and strongest countercase checked before you rely on it.",
        "before_using_this_text": "Before using this text, ask what evidence would make the claim narrower, stronger, or not ready to use.",
        "stress_test_card": stress_test_card,
        "steelman": challenge["steelman"],
        "fallacy_risk": challenge["fallacy_risk"],
        "when_not_a_fallacy": challenge["when_not_a_fallacy"],
        "probing_questions": challenge["probing_questions"],
        "next_actions": challenge["next_actions"],
        "follow_up_activity": {
            "try_this_next": follow_up_activity.get("try_this_next"),
            "source_note": follow_up_activity.get("source_note"),
            "fit_check": follow_up_activity.get("fit_check"),
        },
        "markdown_card": challenge["markdown_card"],
        "host_ai_directive": host_ai_directive,
        "scope_warning": challenge["scope_warning"],
        "domain_signals": challenge["domain_signals"],
    }


OVERVIEW_TOPICS = {
    "overview",
    "quick_start",
    "audits",
    "claim_stress_test",
    "fact_checking",
    "human_loop",
    "reports",
    "app_ui",
    "knowledge_base",
    "saved_patterns",
    "comparable_tools",
    "mcp_composition",
}

OVERVIEW_TOPIC_ALIASES = {
    "": "overview",
    "start": "overview",
    "intro": "overview",
    "introduction": "overview",
    "quickstart": "quick_start",
    "quick-start": "quick_start",
    "audit": "audits",
    "bias_audit": "audits",
    "claim": "claim_stress_test",
    "claim_stress": "claim_stress_test",
    "claim-stress-test": "claim_stress_test",
    "stress_test": "claim_stress_test",
    "factcheck": "fact_checking",
    "fact_check": "fact_checking",
    "fact-check": "fact_checking",
    "fact_checking": "fact_checking",
    "human loop": "human_loop",
    "human-in-the-loop": "human_loop",
    "pdf": "reports",
    "report": "reports",
    "viewer": "app_ui",
    "artifact_viewer": "app_ui",
    "app_ui": "app_ui",
    "mcp_app": "app_ui",
    "ui": "app_ui",
    "kb": "knowledge_base",
    "patterns": "saved_patterns",
    "saved": "saved_patterns",
    "comparable": "comparable_tools",
    "comparable_tools": "comparable_tools",
    "benchmarks": "comparable_tools",
    "mcp_composition": "mcp_composition",
    "mcp-composition": "mcp_composition",
    "mcp_orchestration": "mcp_composition",
    "orchestration": "mcp_composition",
    "capability_registry": "mcp_composition",
}

CONCEPT_CATEGORY_ALIASES = {
    "": "all",
    "all": "all",
    "bias": "biases",
    "biases": "biases",
    "fallacy": "fallacies",
    "fallacies": "fallacies",
    "thinking_lens": "thinking_lenses",
    "thinking_lenses": "thinking_lenses",
    "thinking-lenses": "thinking_lenses",
    "lens": "thinking_lenses",
    "lenses": "thinking_lenses",
    "reasoning_framework": "reasoning_frameworks",
    "reasoning_frameworks": "reasoning_frameworks",
    "reasoning-frameworks": "reasoning_frameworks",
    "framework": "reasoning_frameworks",
    "frameworks": "reasoning_frameworks",
    "methodology_check": "methodology_checks",
    "methodology_checks": "methodology_checks",
    "methodology-checks": "methodology_checks",
    "methodology": "methodology_checks",
    "patterns": "patterns",
    "pattern": "patterns",
}

CONCEPT_CATEGORY_TO_DB = {
    "biases": ["biases"],
    "fallacies": ["fallacies"],
    "thinking_lenses": ["thinking-lenses"],
    "reasoning_frameworks": ["reasoning-frameworks"],
    "methodology_checks": ["methodology-checks"],
    "patterns": ["reasoning-frameworks", "thinking-lenses", "methodology-checks"],
    "all": ["biases", "fallacies", "thinking-lenses", "reasoning-frameworks", "methodology-checks"],
}

CONCEPT_CATEGORY_LABELS = {
    "biases": "Biases",
    "fallacies": "Fallacies",
    "thinking_lenses": "Thinking lenses",
    "reasoning_frameworks": "Reasoning frameworks",
    "methodology_checks": "Methodology checks",
    "patterns": "Patterns",
    "all": "All examples",
}

CURATED_CONCEPT_QUERIES = {
    "biases": ["confirmation bias", "framing effect", "selection bias", "algorithmic bias"],
    "fallacies": ["false dilemma", "causal overreach", "unsupported certainty", "hasty generalization"],
    "thinking_lenses": ["two-eyed seeing", "public narrative", "all my relations", "reciprocity stewardship"],
    "reasoning_frameworks": ["argument mapping", "ladder of inference", "first principles", "analogical reasoning"],
    "methodology_checks": ["replicability", "accessibility reality check", "construct validity", "external validity"],
    "patterns": ["argument mapping", "two-eyed seeing", "replicability", "source quality check"],
}


def normalize_overview_topic(value: str | None) -> str:
    topic = normalize_text(value).replace(" ", "_")
    topic = OVERVIEW_TOPIC_ALIASES.get(topic, topic)
    return topic if topic in OVERVIEW_TOPICS else "overview"


def normalize_concept_category(value: str | None) -> str | None:
    category = normalize_text(value).replace(" ", "_")
    return CONCEPT_CATEGORY_ALIASES.get(category)


def overview_core_workflows() -> list[dict[str, Any]]:
    return [
        {
            "id": "first_session_start",
            "title": "First-session start",
            "what_it_does": "Gives new users an intent-first first-five-minute path, clear routing rules, starter prompts, and the beta calibration feedback lane.",
            "best_tool": "get_started",
            "starter_prompt": "I am new to Critical Compass. Help me clarify my goal, intended audience, and whether I need a quick, full, or advanced audit.",
        },
        {
            "id": "source_preflight",
            "title": "PDF source preflight",
            "what_it_does": "Extracts audit-ready text from local PDFs, uses OCR when needed, and prevents audits from running on sparse or scanned source noise.",
            "best_tool": "prepare_audit_source",
            "starter_prompt": "Prepare this local PDF for audit, then use the extracted text.",
        },
        {
            "id": "quick_scan",
            "title": "Quick scan",
            "what_it_does": "Returns only CIS, top 2 biases, key tension, one action, text type, and guidance to run audit_text next.",
            "best_tool": "quick_scan",
            "starter_prompt": "Quick-scan this text before I decide whether it needs a full audit.",
        },
        {
            "id": "quick_bias_audit",
            "title": "Quick bias audit",
            "what_it_does": "Interrogates text for assumptions, bias patterns, evidence gaps, argument structure, check-worthy claims, alternative frames, intended-audience fit, framing openness, stakeholder fit, persuasion risk, and a Critical Integrity Snapshot.",
            "best_tool": "audit_text",
            "starter_prompt": "Here is a draft. Ask my goal and intended audience, then run a full Critical Compass audit.",
        },
        {
            "id": "agent_persona_discovery",
            "title": "Agent persona discovery",
            "what_it_does": "Shows advanced-audit persona archetypes, custom-agent schema, safe examples, and guardrails before stakeholder-sensitive or audience-fit agent mode.",
            "best_tool": "list_agent_personas",
            "starter_prompt": "Show me which advanced-audit personas fit this policy memo.",
        },
        {
            "id": "advanced_multi_agent_audit",
            "title": "Advanced staged audit",
            "what_it_does": "Builds a multi-perspective scaffold with analyst personas, independent analyses, tension mapping, dissent ledger, debate, and synthesis for high-stakes, stakeholder-sensitive, or audience-fit review.",
            "best_tool": "advanced_audit",
            "starter_prompt": "Run a thorough advanced audit on this advocacy draft and tell me whether it works for the audience I want to reach.",
        },
        {
            "id": "claim_stress_test",
            "title": "Claim Stress-Test",
            "what_it_does": "Turns one claim into a compact card with a steelman, fallacy risk, when the pattern may be valid, probing questions, and next actions.",
            "best_tool": "claim_stress_test",
            "starter_prompt": "Stress-test this claim: 'This update caused retention to drop.'",
        },
        {
            "id": "optional_factcheck_lookup",
            "title": "Fact-check research scaffold",
            "what_it_does": "Builds scaffold-first verification guidance for factual check-worthy claims and can run explicit local ClaimReview or consent-gated publisher retrieval when requested.",
            "best_tool": "factcheck_lookup",
            "starter_prompt": "Create a guided verification scaffold for the high-priority factual claims.",
        },
        {
            "id": "audit_result_compare",
            "title": "Compare saved audits",
            "what_it_does": "Diffs two saved final audit results with CIS, dimension, bias, workflow, and comparability warnings.",
            "best_tool": "compare_audit_results",
            "starter_prompt": "Compare these two saved audit result IDs and tell me what changed.",
        },
        {
            "id": "report_output",
            "title": "PDF report",
            "what_it_does": "Turns completed audit data into a stakeholder-ready PDF, Markdown contract, manifest, preview images, and local artifact viewer after the host compiles report_readiness_contract fields.",
            "best_tool": "generate_audit_report",
            "starter_prompt": "Generate a reader-facing PDF report and local artifact viewer from this completed audit.",
        },
        {
            "id": "artifact_viewer",
            "title": "Read-only artifact viewer",
            "what_it_does": "Opens a completed report manifest as a local HTML viewer for the PDF, Markdown, argument map, evidence plan, dissent ledger, reasoning traps, and trust notes.",
            "best_tool": "generate_audit_artifact_viewer",
            "starter_prompt": "Create a local viewer from this generated report manifest.",
        },
        {
            "id": "kb_exploration",
            "title": "Knowledge-base exploration",
            "what_it_does": "Browses biases, fallacies, reasoning frameworks, thinking lenses, methodology checks, and reasoning flows.",
            "best_tool": "list_concept_examples",
            "starter_prompt": "Show me examples of reasoning lenses I can use for a policy memo.",
        },
        {
            "id": "mcp_composition_policy",
            "title": "MCP composition policy",
            "what_it_does": "Surfaces the local capability registry, study-library lessons, and adopt/adapt/orchestrate/scaffold/reject rules without calling external MCPs.",
            "best_tool": "critical_compass_overview",
            "starter_prompt": "Show the MCP composition registry and study-library lessons, then explain whether this candidate should be merged, orchestrated, scaffolded, or rejected.",
        },
    ]


def overview_case_studies() -> list[dict[str, Any]]:
    return [
        {
            "title": "Audit a research excerpt",
            "user_goal": "Check whether a study summary overclaims from limited evidence.",
            "tool_sequence": ["audit_text", "advanced_audit", "synthesize_audit_verdict"],
            "example_prompt": "Audit this study excerpt as research and focus on replication readiness.",
        },
        {
            "title": "Check audience fit for advocacy copy",
            "user_goal": "Decide whether a public-facing draft works for the audience the writer wants to reach without hiding missing voices, stakeholder fit problems, or persuasion risk.",
            "tool_sequence": ["audit_text", "advanced_audit", "synthesize_audit_verdict"],
            "example_prompt": "This is advocacy copy. Ask my goal and intended audience, then audit whether the framing is open, persuasive, and effective for the audience I want to reach.",
        },
        {
            "title": "Stress-test one claim",
            "user_goal": "Pressure-test a sentence before sharing it, publishing it, or acting on it.",
            "tool_sequence": ["claim_stress_test"],
            "example_prompt": "Stress-test this claim: 'Everyone is switching to this tool, so it must be right.'",
        },
        {
            "title": "Scaffold factual verification",
            "user_goal": "Prepare a responsible research path for factual claims already marked worth verifying.",
            "tool_sequence": ["audit_text", "factcheck_lookup"],
            "example_prompt": "Extract check-worthy claims, then create a guided research scaffold with epistemic framing before browsing.",
        },
        {
            "title": "Generate a PDF report",
            "user_goal": "Turn a completed audit into a polished artifact for readers or stakeholders.",
            "tool_sequence": ["prepare_audit_source", "audit_text", "generate_audit_report", "generate_audit_artifact_viewer"],
            "example_prompt": "Prepare this PDF source, audit the extracted text, generate a report, and open the artifact viewer.",
        },
        {
            "title": "Teach the audit-to-report flow",
            "user_goal": "Demo the shipped local workflow without adding external retrieval or placeholder report sections.",
            "tool_sequence": ["prepare_audit_source", "audit_text", "advanced_audit", "synthesize_audit_verdict", "generate_audit_report", "generate_audit_artifact_viewer"],
            "example_prompt": "Run the audit-to-report-to-viewer demo and show me the PDF, Markdown, manifest, and viewer paths.",
        },
        {
            "title": "Browse reasoning lenses",
            "user_goal": "Find a thinking pattern before starting analysis.",
            "tool_sequence": ["list_concept_examples", "get_framework", "list_reasoning_flows"],
            "example_prompt": "Show me thinking lenses for reframing a community-policy argument.",
        },
        {
            "title": "Classify an MCP candidate",
            "user_goal": "Decide whether a thinking-related MCP belongs inside Critical Compass, outside it, or only in a prompt scaffold.",
            "tool_sequence": ["critical_compass_overview"],
            "example_prompt": "Use the MCP capability registry and study-library lessons to classify this candidate as merge, wrap, orchestrate, scaffold-only, or reject.",
        },
        {
            "title": "Track recurring patterns",
            "user_goal": "Save repeated bias or framework observations across audits.",
            "tool_sequence": ["save_bias_pattern", "save_entity_pattern", "get_pattern_summary"],
            "example_prompt": "Save this recurring framing-effect pattern and summarize my pattern history.",
        },
    ]


def overview_tool_map() -> list[dict[str, str]]:
    return [
        {"tool": "get_started", "use_when": "A new user needs first-session onboarding, install/start guidance, or a first audit path."},
        {"tool": "critical_compass_overview", "use_when": "The user or host AI needs a friendly map of what the MCP can do."},
        {"tool": "prepare_audit_source", "use_when": "The user provides a local PDF or source file that needs deterministic extraction before auditing."},
        {"tool": "list_concept_examples", "use_when": "The user wants examples of biases, fallacies, patterns, lenses, or methodology checks."},
        {"tool": "quick_scan", "use_when": "The user wants a lightweight gut-check before committing to a full audit."},
        {"tool": "audit_text", "use_when": "The user has text and wants the normal full Critical Compass audit, including audience effectiveness, framing openness, stakeholder fit, missing voices, or persuasion risk."},
        {"tool": "list_agent_personas", "use_when": "The user wants to choose or customize advanced-audit analyst personas before agent mode."},
        {"tool": "advanced_audit", "use_when": "The user needs staged, multi-perspective, reasoning-flow-backed analysis for high-stakes, stakeholder-sensitive, or audience-fit / persuasion-effectiveness review."},
        {"tool": "claim_stress_test", "use_when": "The user has one claim and wants a fast pressure-test card."},
        {"tool": "factcheck_lookup", "use_when": "The user asks how to verify factual check-worthy claims; default mode returns a scaffold, while retrieval providers are explicit/experimental."},
        {"tool": "lookup_bias", "use_when": "The host AI needs one verified bias definition before citing it."},
        {"tool": "get_framework", "use_when": "The user or host AI wants a reasoning framework or thinking lens."},
        {"tool": "search_knowledge_base", "use_when": "The exact concept name is unknown and search is needed."},
        {"tool": "compare_audit_results", "use_when": "The user wants to compare two saved final audit results without overstating CIS deltas."},
        {"tool": "generate_audit_report", "use_when": "A completed audit should become a PDF report."},
        {"tool": "generate_audit_artifact_viewer", "use_when": "A completed report manifest should become a local read-only HTML viewer."},
        {"tool": "critical_compass_overview", "use_when": "A host AI needs MCP composition policy, the capability registry summary, study-library lessons, or safe orchestration guidance."},
    ]


def overview_topic_filter(items: list[dict[str, Any]], topic: str) -> list[dict[str, Any]]:
    if topic in {"overview", "quick_start"}:
        return items
    topic_tools = {
        "audits": {"quick_scan", "audit_text", "advanced_audit", "synthesize_audit_verdict", "list_agent_personas", "compare_audit_results"},
        "claim_stress_test": {"claim_stress_test", "challenge_claim"},
        "fact_checking": {"factcheck_lookup", "audit_text"},
        "human_loop": {"audit_text", "advanced_audit", "synthesize_audit_verdict", "generate_audit_report"},
        "reports": {"prepare_audit_source", "generate_audit_report", "generate_audit_artifact_viewer", "audit_text"},
        "app_ui": {"generate_audit_artifact_viewer", "generate_audit_report"},
        "knowledge_base": {"list_concept_examples", "list_categories", "get_entry", "search_knowledge_base", "list_reasoning_flows", "get_framework"},
        "saved_patterns": {"save_bias_pattern", "save_entity_pattern", "get_pattern_summary", "list_audit_results", "compare_audit_results"},
        "mcp_composition": {"critical_compass_overview"},
    }
    allowed = topic_tools.get(topic, set())
    return [
        item
        for item in items
        if item.get("best_tool") in allowed
        or any(tool in allowed for tool in ensure_list(item.get("tool_sequence")))
        or item.get("tool") in allowed
    ] or items


def overview_markdown(title: str, user_overview: str, workflows: list[dict[str, Any]], case_studies: list[dict[str, Any]], starter_prompts: list[str]) -> str:
    lines = [f"## {title}", "", user_overview, "", "### Core Workflows"]
    lines.extend(f"- **{item['title']}**: {item['what_it_does']} Use `{item['best_tool']}`." for item in workflows)
    lines.extend(["", "### Case Studies"])
    lines.extend(f"- **{item['title']}**: {item['example_prompt']}" for item in case_studies)
    lines.extend(["", "### Starter Prompts"])
    lines.extend(f"- {prompt}" for prompt in starter_prompts)
    return "\n".join(lines)


def load_json_resource(path: Path, fallback: dict[str, Any]) -> dict[str, Any]:
    try:
        if not path.exists():
            return fallback
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else fallback
    except (OSError, json.JSONDecodeError):
        return fallback


def load_comparable_tools_resource() -> dict[str, Any]:
    data = load_json_resource(
        COMPARABLE_TOOLS_RESOURCE_PATH,
        {
            "schema_version": "v1",
            "resource_id": "critical_compass.comparable_tools.v1",
            "records": [],
            "guardrails": ["Do not add automatic external retrieval to core audits."],
        },
    )
    records = [item for item in ensure_list(data.get("records")) if isinstance(item, dict)]
    classifications: dict[str, int] = defaultdict(int)
    for record in records:
        classifications[first_text(record.get("classification")) or "unclassified"] += 1
    evaluations = load_json_resource(
        COMPARABLE_TOOLS_EVALUATIONS_PATH,
        {"schema_version": "v1", "resource_id": "critical_compass.comparable_tools.evaluations.v1", "cases": []},
    )
    evaluation_cases = [item for item in ensure_list(evaluations.get("cases")) if isinstance(item, dict)]
    return {
        "resource_id": first_text(data.get("resource_id")) or "critical_compass.comparable_tools.v1",
        "schema_version": first_text(data.get("schema_version")) or "v1",
        "path": str(COMPARABLE_TOOLS_RESOURCE_PATH),
        "record_count": len(records),
        "classification_counts": dict(sorted(classifications.items())),
        "guardrails": ensure_list(data.get("guardrails")),
        "records": records,
        "evaluation_cases_path": str(COMPARABLE_TOOLS_EVALUATIONS_PATH),
        "evaluation_cases": evaluation_cases,
        "planning_reference": "docs/planning/adopt-adapt-reject-matrix.md",
        "rule": "Use as local design guidance only; do not call external tools automatically from core audits.",
    }


def comparable_tools_positioning_card() -> dict[str, Any]:
    resource = load_comparable_tools_resource()
    records = {first_text(item.get("id")): item for item in ensure_list(resource.get("records")) if isinstance(item, dict)}

    def names(*ids: str) -> list[str]:
        return [first_text(records.get(item_id, {}).get("name")) for item_id in ids if first_text(records.get(item_id, {}).get("name"))]

    return {
        "title": "How Critical Compass differs from adjacent tools",
        "summary": "Critical Compass is a local-first pressure-test and teaching scaffold for text integrity. Adjacent tools inspire useful patterns, but they do not replace its trust/revise/verify/reframe decision contract.",
        "comparisons": [
            {
                "group": "Argument mapping tools",
                "examples": names("kialo_edu", "rationale", "argdown"),
                "positioning": "They make argument structure visible; Critical Compass uses compact argument maps inside an audit that also checks evidence, framing, missing voices, and use-readiness.",
            },
            {
                "group": "Research evidence products",
                "examples": names("research_evidence_tools"),
                "positioning": "They help discover papers and citation context; Critical Compass first names what evidence is needed and keeps live retrieval explicit and opt-in.",
            },
            {
                "group": "Fact-checking and check-worthiness tools",
                "examples": names("fact_check_tools_mcp", "factrank", "openfactcheck"),
                "positioning": "They support factual verification; Critical Compass preserves the boundary that check-worthy means worth verifying, not false.",
            },
            {
                "group": "Generic reasoning MCPs",
                "examples": names("think_mcp", "mcp_thinking", "verifiable_thinking_mcp"),
                "positioning": "They add reasoning pauses or modes; Critical Compass ties reasoning checks to user-facing audit outputs, CIS, reports, and teaching follow-up.",
            },
        ],
        "boundary": "Positioning only: no marketplace browsing, no automatic web search, and no external tool dependency is added to core audits.",
        "source": {
            "resource_id": resource.get("resource_id"),
            "record_count": resource.get("record_count"),
            "rule": resource.get("rule"),
        },
    }


def load_mcp_capability_registry_resource() -> dict[str, Any]:
    registry = load_mcp_capability_registry(MCP_CAPABILITY_REGISTRY_PATH)
    registry["path"] = str(MCP_CAPABILITY_REGISTRY_PATH)
    summary = summarize_mcp_capability_registry(registry)
    validation = validate_mcp_capability_registry(registry)
    records = [item for item in ensure_list(registry.get("capabilities")) if isinstance(item, dict)]
    return {
        **summary,
        "schema_path": str(MCP_CAPABILITY_SCHEMA_PATH),
        "validation": validation,
        "records": records,
        "planning_references": [
            "docs/planning/mcp-composition-strategy.md",
            "docs/planning/mcp-capability-registry.md",
            "docs/planning/mcp-integration-decision-matrix.md",
            "docs/specs/mcp_orchestration_contract.md",
        ],
        "rule": "Registry entries are planning and orchestration evidence. They are not proof that an external MCP is installed, trusted, or safe to call.",
    }


def load_mcp_study_lessons_resource() -> dict[str, Any]:
    registry = load_mcp_study_lessons(MCP_STUDY_LESSONS_PATH)
    registry["path"] = str(MCP_STUDY_LESSONS_PATH)
    summary = summarize_mcp_study_lessons(registry)
    validation = validate_mcp_study_lessons(registry)
    lessons = [item for item in ensure_list(registry.get("lessons")) if isinstance(item, dict)]
    return {
        **summary,
        "schema_path": str(MCP_STUDY_LESSONS_SCHEMA_PATH),
        "validation": validation,
        "records": lessons,
        "planning_references": [
            "docs/planning/mcp-study-library-soft-learner.md",
            "docs/specs/mcp_study_lessons_schema.md",
            "support/resources/scaffolds/v1/mcp-study-learner-runbook.md",
        ],
        "provenance_label": "study_library_pattern",
        "rule": "Study-library lessons are original Critical Compass summaries. They are not installed live dependencies, direct merges, or permission to call external MCPs.",
    }


def load_scaffold_resource_manifest() -> dict[str, Any]:
    data = load_json_resource(
        SCAFFOLD_RESOURCE_MANIFEST_PATH,
        {
            "schema_version": "v1",
            "resource_id": "critical_compass.scaffolds.v1",
            "resource_version": "v1.0.0",
            "resources": [],
            "guardrails": [],
        },
    )
    resources: list[dict[str, Any]] = []
    root_path = SCAFFOLD_RESOURCE_MANIFEST_PATH.parent
    for item in ensure_list(data.get("resources")):
        if not isinstance(item, dict):
            continue
        resource = dict(item)
        relative_path = first_text(resource.get("path"))
        if relative_path:
            resource["absolute_path"] = str((root_path / relative_path).resolve())
        resources.append(resource)
    return {
        "resource_id": first_text(data.get("resource_id")) or "critical_compass.scaffolds.v1",
        "schema_version": first_text(data.get("schema_version")) or "v1",
        "resource_version": first_text(data.get("resource_version")) or "v1.0.0",
        "manifest_path": str(SCAFFOLD_RESOURCE_MANIFEST_PATH),
        "root_path": str(root_path),
        "purpose": first_text(data.get("purpose")),
        "guardrails": ensure_list(data.get("guardrails")),
        "resources": resources,
    }


def critical_compass_overview_payload(topic: str | None = None, audience: str | None = "both") -> dict[str, Any]:
    resolved_topic = normalize_overview_topic(topic)
    title = "Critical Compass Overview" if resolved_topic == "overview" else f"Critical Compass: {CONCEPT_CATEGORY_LABELS.get(resolved_topic, resolved_topic.replace('_', ' ').title())}"
    topic_overviews = {
        "overview": "Critical Compass helps people and mission-driven organizations pressure-test text before they use it, so weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads. Every audit-facing output should also teach the user how to think with the text through a Plain-Language Read, a Before Using This Text caution, and a bounded follow-up activity when useful.",
        "quick_start": "Start with the user job, not the tool name: what is this text trying to do, who is it for, and should the review be quick, full, or advanced? Use `get_started` when the user is new or vague, default to `audit_text` for a normal full audit, escalate to `advanced_audit` only for high-stakes or explicitly requested panel review, use `prepare_audit_source` for local PDFs, and use `claim_stress_test` for a single assertion. Preserve the beta.8 teaching contract: plain read, exact before-use opener, and a small activity idea when it helps.",
        "audits": "Audit tools help users decide what to trust, revise, verify, or reframe before use. They surface assumptions, bias patterns, methodology gaps, argument maps, check-worthy claims, missing voices, overly narrow perspectives, alternative frames, probing questions, stakeholder fit, persuasion risk, whether the framing stays open to the intended audience, the Plain-Language Read, the Critical Integrity Snapshot, and a local File-O-Fun-derived follow-up activity layer.",
        "claim_stress_test": "Claim Stress-Test is the fastest lane: one claim in, steelman, fallacy risk, validity caveat, probing questions, and next actions out.",
        "fact_checking": "Fact-check lookup is scaffold-first for factual check-worthy claims. It returns epistemic framing, safe queries, source classes, evidence trail, and plurality review templates by default; local ClaimReview and direct publisher harvest are explicit modes, while external search/API providers remain optional and experimental.",
        "human_loop": "Human Loop uses mode consent plus three bounded blocks: onboarding before the audit, raw judgment before findings are revealed, and reflection after a three-bullet preview before final output. Onboarding can capture goal, intended audience, relationship to the text, and desired output before the audit runs. Silent mode requires user confirmation or an explicit noninteractive smoke-test override. Hosts should use native question UI first and ask only the current block, never the full Human Loop questionnaire at once. User input shapes configuration, focus, commentary, learning notes, and presentation, but not frozen findings unless verified evidence triggers rerun.",
        "reports": "Report tools turn completed audits into PDFs, Markdown contracts, manifests, page images, and local artifact viewers after the host AI compiles the report_readiness_contract fields and canonical audit_data payload.",
        "app_ui": "The local artifact viewer opens completed audit reports, argument maps, evidence plans, dissent, reasoning traps, and trust notes in a read-only HTML interface. It reads generated report manifests; it does not create new findings or run retrieval.",
        "knowledge_base": "Knowledge-base tools let users and host AIs browse, search, and cite biases, fallacies, frameworks, thinking lenses, methodology checks, and reasoning flows.",
        "saved_patterns": "Writable pattern tools let users save recurring bias/framework observations, browse saved audit results, compare final audits, and review longitudinal Critical Integrity Snapshot patterns.",
        "comparable_tools": "Comparable-tools notes are a design-facing resource: they classify outside inspirations as adopt, adapt/rebuild locally, optional integration, or reject without turning Critical Compass into a marketplace.",
        "mcp_composition": "MCP composition is an internal policy, registry, and soft-learning layer. It classifies outside MCPs as merge, wrap, orchestrate, scaffold-only, or reject; records original lessons from the local MCP study library; exposes the Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, and surface sync checklist; and prevents unreviewed external MCPs from displacing Critical Compass synthesis.",
    }
    workflows = overview_topic_filter(overview_core_workflows(), resolved_topic)
    case_studies = overview_topic_filter(overview_case_studies(), resolved_topic)
    tool_map = overview_topic_filter(overview_tool_map(), resolved_topic)
    starter_prompts = [item["starter_prompt"] for item in workflows[:4]]
    if resolved_topic in {"overview", "quick_start"}:
        starter_prompts = [
            "I have text but I am not sure which lane I need. Ask my goal, intended audience, and whether I want a quick, full, or advanced audit, then route me.",
            "Does this advocacy draft work for the audience I want to reach?",
            "Give this text a full Critical Compass audit for assumptions, missing voices, framing openness, stakeholder fit, and persuasion risk.",
            "Audit this text and include one solo and one group activity I could use to keep improving it.",
            "This is high-stakes. After clarifying goal, audience, and depth, ask whether I want a normal audit or an advanced panel review.",
        ]
    elif resolved_topic == "human_loop":
        starter_prompts = [
            "Run a guided audit with onboarding, judgment, and reflection prompts before the final output.",
            "Capture my raw read before showing findings, then compare it with the audit without changing frozen findings.",
            "Show me the three-bullet preview, ask reflection questions, then generate the PDF report.",
        ]
    elif resolved_topic == "reports":
        starter_prompts = [
            "Prepare this local PDF for audit, audit the extracted text, generate a report, and open the viewer.",
            "Create a reader-facing PDF report, Markdown contract, manifest, preview image, and local viewer from completed findings.",
            "Before generating the PDF, show the argument map, check-worthy factual claims, missing report fields, and viewer handoff path.",
        ]
    elif resolved_topic == "fact_checking":
        starter_prompts = [
            "Extract check-worthy factual claims, then call factcheck_lookup in guided_research mode before browsing.",
            "Search the configured local ClaimReview index for these factual claims before considering any external lookup.",
            "Use the fact-check scaffold to gather primary, secondary, regional, and affected-community evidence.",
            "Attach only real evidence rows or retrieved trusted matches to reports; never ship scaffold placeholders as fact-check results.",
        ]
    elif resolved_topic == "app_ui":
        starter_prompts = [
            "Open the generated audit report manifest in a local artifact viewer.",
            "Show the argument map, evidence plan, dissent ledger, and trust preflight in one read-only page.",
            "Create a viewer for this completed report without changing the audit findings.",
        ]
    elif resolved_topic == "comparable_tools":
        starter_prompts = [
            "Show the local adopt/adapt/reject lessons from adjacent tools before proposing a Critical Compass change.",
            "Use the comparable-tools notes to improve this workflow without adding automatic web retrieval.",
            "Classify this proposed integration as adopt, adapt/rebuild locally, optional integration, or reject.",
        ]
    elif resolved_topic == "mcp_composition":
        starter_prompts = [
            "Use the MCP capability registry to classify this candidate as merged internal, wrapped internal, orchestrated external, prompt scaffold only, or rejected.",
            "Use the MCP study lessons to learn from downloaded repos without merging, importing, installing, or calling them.",
            "Use the Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, and surface sync checklist before changing public MCP behavior.",
            "Show the trust, license, maintenance, epistemic-fit, plurality-fit, and fallback questions before using this external MCP.",
            "Plan a route that prefers native Critical Compass capabilities and labels any external MCP influence clearly.",
        ]

    host_ai_routing = {
        "audience": normalize_text(audience) or "both",
        "topic": resolved_topic,
        "routing_rule": "Use this overview to choose the next MCP tool. If the user has text but no lane, first clarify goal, intended audience, and whether they want quick, full, or advanced review; do not treat onboarding text as completed analysis.",
        "agentic_opt_in_rule": {
            "requires_explicit_opt_in": True,
            "safe_phrases": ["advanced panel review", "agentic panel review", "multi-perspective panel", "run the agent audit"],
            "insufficient_phrases_alone": ["agent", "agency", "city council", "panel", "committee", "stakeholders"],
            "normal_default": "Use audit_text for a normal full audit when panel-review intent is not explicit.",
        },
        "next_tool_candidates": [item["tool"] for item in tool_map[:6] if item.get("tool")] + [item["best_tool"] for item in workflows[:3] if item.get("best_tool")],
    }
    scaffold_topics = {"overview", "quick_start", "reports", "audits", "human_loop", "app_ui", "comparable_tools", "fact_checking", "mcp_composition"}
    workflow_resources = load_scaffold_resource_manifest() if resolved_topic in scaffold_topics else None
    return {
        "status": "overview_ready",
        "title": title,
        "topic": resolved_topic,
        "user_overview": topic_overviews[resolved_topic],
        "core_workflows": workflows,
        "case_studies": case_studies,
        "starter_prompts": starter_prompts,
        "tool_map": tool_map,
        "host_ai_routing": host_ai_routing,
        "report_readiness_contract": report_readiness_contract("full", stage="overview_reports", include_advanced=True) if resolved_topic == "reports" else None,
        "workflow_resources": workflow_resources,
        "teaching_alignment_contract": {
            "plain_language_read": "Every audit-facing output should include a 1-2 sentence nontechnical read of what the text is doing and the biggest trust/use issue.",
            "before_using_this_text": "Every audit-facing output should include a sentence starting exactly with 'Before using this text,'.",
            "follow_up_activity": "Quick/chat outputs use at most one compact try_this_next idea; full/advanced reports include one solo and one group activity from the local activity pack.",
            "activity_fit_check": "Follow-up activities include a non-persistent fit check asking whether to use, swap, or skip the activity next time.",
            "source_boundary": "File-O-Fun and Knowledge Atlas inform the local pack at build time only; no live Atlas lookup is part of core audits.",
        },
        "teaching_activity_pack": teaching_activity_pack_summary() if resolved_topic in {"overview", "quick_start", "audits", "reports"} else None,
        "comparable_tools_positioning_card": comparable_tools_positioning_card() if resolved_topic in {"overview", "comparable_tools"} else None,
        "comparable_tools_resource": load_comparable_tools_resource() if resolved_topic == "comparable_tools" else None,
        "mcp_capability_registry": load_mcp_capability_registry_resource() if resolved_topic in {"overview", "comparable_tools", "mcp_composition"} else None,
        "mcp_study_lessons_resource": load_mcp_study_lessons_resource() if resolved_topic in {"overview", "comparable_tools", "mcp_composition"} else None,
        "next_steps": [
            "If the user has text but no lane, clarify goal, intended audience, and whether the review should be quick, full, or advanced.",
            "Default to audit_text for a normal full audit; use advanced_audit for thorough, multi-perspective, stakeholder-sensitive, or high-stakes review.",
            "Use `list_concept_examples` if the user wants to browse ideas before auditing.",
            "Suggest adjacent lenses such as JTBD only after the core Critical Compass audit if they clearly add value.",
        ],
        "markdown": overview_markdown(title, topic_overviews[resolved_topic], workflows, case_studies, starter_prompts),
    }


def concept_related_tools(category: str) -> list[str]:
    if category == "biases":
        return ["lookup_bias", "audit_text", "search_knowledge_base"]
    if category == "fallacies":
        return ["claim_stress_test", "challenge_claim", "search_knowledge_base"]
    if category in {"thinking_lenses", "reasoning_frameworks", "patterns"}:
        return ["get_framework", "get_pattern", "list_reasoning_flows"]
    if category == "methodology_checks":
        return ["audit_text", "advanced_audit", "search_knowledge_base"]
    return ["search_knowledge_base", "get_entry", "list_categories"]


def concept_example_card(row: dict[str, Any], category: str) -> dict[str, Any]:
    title = first_text(row.get("title") or row.get("name")) or "Untitled concept"
    summary = trim_sentences(first_text(row.get("summary") or row.get("definition")) or "A Critical Compass knowledge-base concept.", 2)
    return {
        "id": first_text(row.get("id") or row.get("concept_id") or row.get("entry_id") or row.get("slug")),
        "title": title,
        "category": category,
        "plain_language_summary": summary,
        "example_use": f"Use {title} when you want to inspect how this pattern may shape reasoning, evidence, or framing.",
        "try_it_prompt": f"Show me how {title} might appear in this text, and what would reduce the risk.",
        "related_tools": concept_related_tools(category),
    }


def concept_rows_for_category(repo: Repository, category: str, query: str | None, limit: int) -> list[dict[str, Any]]:
    categories = CONCEPT_CATEGORY_TO_DB.get(category, CONCEPT_CATEGORY_TO_DB["all"])
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    if clean_claim_text(query):
        for db_category in categories:
            for row in repo.search(query or "", category=db_category, limit=max(1, limit)):
                row_id = first_text(row.get("concept_id") or row.get("entry_id") or row.get("title"))
                if row_id and row_id not in seen:
                    rows.append(row)
                    seen.add(row_id)
                if len(rows) >= limit:
                    return rows
        return rows

    curated = CURATED_CONCEPT_QUERIES.get(category)
    if category == "all":
        curated = [query for group in CURATED_CONCEPT_QUERIES.values() for query in group[:2]]
    for item in curated or []:
        for db_category in categories:
            row = repo.best_match(item, categories={db_category})
            row_id = first_text((row or {}).get("concept_id") or (row or {}).get("entry_id") or (row or {}).get("title"))
            if row and row_id and row_id not in seen:
                rows.append(row)
                seen.add(row_id)
                break
        if len(rows) >= limit:
            return rows
    for row in repo.concepts:
        if row.get("category") not in categories:
            continue
        row_id = first_text(row.get("concept_id") or row.get("entry_id") or row.get("title"))
        if row_id and row_id not in seen:
            rows.append(row)
            seen.add(row_id)
        if len(rows) >= limit:
            break
    return rows


def concept_examples_markdown(title: str, examples: list[dict[str, Any]], starter_prompts: list[str]) -> str:
    lines = [f"## {title}", "", "### Examples"]
    lines.extend(f"- **{item['title']}**: {item['plain_language_summary']}" for item in examples)
    lines.extend(["", "### Try Next"])
    lines.extend(f"- {prompt}" for prompt in starter_prompts)
    return "\n".join(lines)


def list_concept_examples_payload(
    repo: Repository,
    category: str | None = None,
    query: str | None = None,
    limit: int = 8,
) -> dict[str, Any]:
    safe_limit = max(1, min(int(limit or 8), 25))
    resolved_category = normalize_concept_category(category)
    available = list(CONCEPT_CATEGORY_TO_DB)
    if resolved_category is None:
        examples = [
            {
                "id": key,
                "title": label,
                "category": key,
                "plain_language_summary": f"Browse examples from {label.lower()}.",
                "example_use": f"Use category='{key}' to see teachable examples.",
                "try_it_prompt": f"List examples from {label.lower()}.",
                "related_tools": concept_related_tools(key),
            }
            for key, label in CONCEPT_CATEGORY_LABELS.items()
            if key != "all"
        ][:safe_limit]
        return {
            "status": "blocked",
            "category": category,
            "available_categories": available,
            "examples": examples,
            "suggested_tools": ["list_concept_examples", "list_categories", "search_knowledge_base"],
            "starter_prompts": ["Show me examples of biases.", "Show me reasoning patterns for a policy memo."],
            "markdown": concept_examples_markdown("Choose a Valid Concept Category", examples, ["Use one of the available category names."]),
        }

    rows = concept_rows_for_category(repo, resolved_category, query, safe_limit)
    status = "examples_ready"
    if clean_claim_text(query) and not rows:
        rows = concept_rows_for_category(repo, resolved_category, None, safe_limit)
        status = "no_exact_match"
    examples = [concept_example_card(row, resolved_category) for row in rows[:safe_limit]]
    title = f"{CONCEPT_CATEGORY_LABELS[resolved_category]} Examples"
    starter_prompts = [
        f"Show me how to use {examples[0]['title']} on my text." if examples else "Show me an example concept.",
        f"Search the knowledge base for {clean_claim_text(query) or CONCEPT_CATEGORY_LABELS[resolved_category].lower()}.",
        "Which tool should I use next?",
    ]
    return {
        "status": status,
        "category": resolved_category,
        "query": clean_claim_text(query) or None,
        "available_categories": available,
        "examples": examples,
        "suggested_tools": concept_related_tools(resolved_category) + ["get_entry", "search_knowledge_base"],
        "starter_prompts": starter_prompts,
        "markdown": concept_examples_markdown(title, examples, starter_prompts),
    }


ADVANCED_AUDIT_BUCKETS = {
    "evidence_argument": {
        "role": "Evidence / argument",
        "persona": "Argument Mapper",
        "rationale": "It tests claims, premises, objections, warrants, and inference jumps.",
    },
    "systems_causal": {
        "role": "Systems / causal",
        "persona": "Systems Thinker",
        "rationale": "It maps conditions, feedback loops, interdependence, and domain fit.",
    },
    "uncertainty_methodology": {
        "role": "Uncertainty / methodology",
        "persona": "Red-Team Auditor",
        "rationale": "It checks confidence, evidence quality, risks, and failure modes.",
    },
    "structural_relational": {
        "role": "Structural / relational / ethical",
        "persona": "Relational Ethicist",
        "rationale": "It surfaces power, stakeholders, access, harms, and affected communities.",
    },
    "creative_reframing": {
        "role": "Creative / reframing",
        "persona": "Possibility Scout",
        "rationale": "It expands options, alternative frames, analogies, and generative possibilities.",
    },
    "communication_task": {
        "role": "Communication / task execution",
        "persona": "Execution Editor",
        "rationale": "It turns the input into a concrete artifact, plan, or next action.",
    },
}


def advanced_mode(value: str | None) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (value or "").strip().lower()).strip("_")


def advanced_subject_summary(subject: str) -> str:
    summary = trim_sentences(subject, 2)
    return summary if len(summary) <= 280 else f"{summary[:277].rstrip()}..."


def advanced_query(subject: str, domain_hint: str | None, domain: str, domain_signals: list[str]) -> str:
    lowered = subject.lower()
    cues: list[str] = []
    if any(marker in lowered for marker in ["should", "must", "because", "therefore", "claim", "argue", "recommend"]):
        cues.extend(["argument", "claim", "evidence", "inference"])
    if any(marker in lowered for marker in ["system", "process", "workflow", "organization", "team", "incentive", "feedback", "recurring"]):
        cues.extend(["systems", "complexity", "conditions", "feedback"])
    if any(marker in lowered for marker in ["risk", "fail", "failure", "uncertain", "confidence", "forecast", "study", "measure", "metric"]):
        cues.extend(["risk", "uncertainty", "calibration", "preflight"])
    if any(marker in lowered for marker in ["customer", "community", "stakeholder", "harm", "access", "identity", "power", "equity"]):
        cues.extend(["stakeholder", "harm", "power", "structural"])
    if any(marker in lowered for marker in ["governance", "policy", "oversight", "accountability", "ai", "algorithm", "digital divide", "framework"]):
        cues.extend(["governance", "accountability", "systems", "stakeholder", "evidence"])
    if any(marker in lowered for marker in ["write", "draft", "email", "memo", "resume", "post", "copy", "brief"]):
        cues.extend(["communication", "draft", "task"])
    return " ".join([subject, domain_hint or "", domain, *domain_signals, *cues])


def advanced_has_deliverable_intent(subject: str, domain_hint: str | None = None) -> bool:
    text = normalize_text(f"{domain_hint or ''} {subject}")
    if not text:
        return False

    deliverable_phrases = [
        "write",
        "draft",
        "rewrite",
        "edit",
        "polish",
        "prepare",
        "compose",
        "format",
        "turn this into",
        "convert this into",
        "make a brief",
        "create a brief",
        "produce a",
        "generate a",
    ]
    artifact_terms = [
        "email",
        "resume",
        "cover letter",
        "prd",
        "brief",
        "memo",
        "letter",
        "announcement",
        "press release",
        "social media post",
        "microcopy",
        "metadata",
        "questionnaire",
        "survey",
        "interview questions",
        "usability test",
        "task scenarios",
        "developer ready brief",
        "user stories",
        "acceptance criteria",
        "bdd",
    ]
    if any(phrase in text for phrase in deliverable_phrases):
        return True
    return any(term in text for term in artifact_terms) and any(
        verb in text for verb in ["need", "create", "make", "build", "prepare", "send", "publish"]
    )


def advanced_is_research_subject(subject: str, context: dict[str, Any] | None = None) -> bool:
    context = context or {}
    subject_norm = normalize_text(subject)
    return (
        first_text(context.get("text_type")) == "research"
        or first_text(context.get("domain")) == "research study/report"
        or any(
            term in subject_norm
            for term in [
                "study",
                "research",
                "paper",
                "experiment",
                "sample",
                "participant",
                "methodology",
                "p value",
                "confidence interval",
                "effect size",
                "replication",
                "preregistration",
                "pre registered",
                "hypothesis",
            ]
        )
    )


def advanced_artifact_match_score(flow: dict[str, Any], subject: str) -> float:
    subject_norm = normalize_text(subject)
    title_norm = normalize_text(flow.get("entry_title"))
    artifact_pairs = [
        ("email", "email"),
        ("dm", "dm outreach"),
        ("outreach", "dm outreach"),
        ("resume", "resume"),
        ("cover letter", "cover letter"),
        ("prd", "prd"),
        ("product requirements", "prd"),
        ("memo", "memo"),
        ("letter", "letter formal personal"),
        ("announcement", "announcement"),
        ("press release", "press release"),
        ("social media", "social media"),
        ("microcopy", "microcopy"),
        ("metadata", "metadata seo"),
        ("seo", "metadata seo"),
        ("questionnaire", "questionnaire"),
        ("survey", "survey"),
        ("interview questions", "interviews plan questions"),
        ("usability test", "usability test"),
        ("task scenarios", "task scenarios"),
        ("health", "health symptom clinician"),
        ("symptom", "health symptom clinician"),
        ("backlog", "backlog prioritize"),
        ("travel", "travel door to door"),
        ("brief", "brief"),
        ("user stories", "user stories acceptance criteria"),
        ("acceptance criteria", "user stories acceptance criteria"),
        ("bdd", "bdd given when then"),
    ]
    score = 0.0
    for subject_term, title_terms in artifact_pairs:
        if subject_term in subject_norm and any(term in title_norm for term in title_terms.split()):
            score += 38.0
            break
    if "informational interview" in subject_norm and "informational interview" in title_norm:
        score += 30.0
    return score


def advanced_flow_bucket(flow: dict[str, Any]) -> str:
    text = normalize_text(
        " ".join(
            first_text(part)
            for part in [
                flow.get("entry_title"),
                flow.get("category"),
                flow.get("subcategory"),
                flow.get("kind"),
                flow.get("purpose"),
                flow.get("output_contract"),
            ]
        )
    )
    title = normalize_text(flow.get("entry_title"))
    category = normalize_text(flow.get("category"))
    subcategory = normalize_text(flow.get("subcategory"))

    if flow_namespace(flow) == FLOW_NAMESPACE_APPLIED_REASONING:
        return "communication_task"

    if any(term in title for term in ["intersectionality", "conscientization", "collective impact", "public narrative", "ikigai"]):
        return "structural_relational"
    if any(term in title for term in ["cynefin", "dependent origination", "kanban", "systems", "targeting matrix", "pipeline"]):
        return "systems_causal"
    if category == "methodology checks" or any(term in title for term in ["pre mortem", "risk", "audit", "screener", "survey", "usability", "replication", "preregistration", "methodology"]):
        return "uncertainty_methodology"
    if category == "reasoning frameworks" or subcategory in {"argumentation", "inference", "uncertainty"} or any(term in title for term in ["ladder of inference", "tetralemma", "catuskoti", "bdd", "par", "rap", "star"]):
        return "evidence_argument"
    if any(term in title for term in ["role storming", "wishing", "synesthetic", "story spine", "clown", "contact improv", "playback theatre"]):
        return "creative_reframing"
    if any(term in text for term in ["draft", "write", "memo", "email", "resume", "brief"]):
        return "communication_task"
    return "evidence_argument"


def advanced_context_flags(subject: str, context: dict[str, Any]) -> dict[str, bool]:
    flags = frame_context_flags(
        subject,
        first_text(context.get("domain")),
        text_type=first_text(context.get("text_type")),
        domain_hint=first_text(context.get("domain_hint")),
    )
    subject_norm = normalize_text(subject)
    flags.update(
        {
            "evidence": any(term in subject_norm for term in ["should", "must", "because", "therefore", "claim", "argue", "recommend", "compare", "framework"]),
            "risk": any(term in subject_norm for term in ["risk", "fail", "failure", "uncertain", "confidence", "forecast", "measure", "metric", "harm"]),
            "research": advanced_is_research_subject(subject, context) or context.get("retrieval_profile") == "research_methodology",
            "product_prioritization": any(term in subject_norm for term in ["product", "feature", "roadmap", "backlog", "prioritize", "reach", "impact", "effort", "resource allocation"]),
            "career": any(term in subject_norm for term in ["job", "career", "resume", "cover letter", "interview", "offer", "application", "hiring"]),
            "deliverable": bool(context.get("include_applied_reasoning")),
        }
    )
    return flags


def advanced_flow_mismatch_warning(flow: dict[str, Any], subject: str, context: dict[str, Any]) -> str:
    title = normalize_text(flow.get("entry_title"))
    flags = advanced_context_flags(subject, context)
    if flow_namespace(flow) == FLOW_NAMESPACE_APPLIED_REASONING and not flags["deliverable"]:
        return "Applied artifact flow; use only when the user is asking to produce a deliverable."
    if flags["research"] and any(
        term in title
        for term in [
            "job search",
            "star stories",
            "pipeline kanban",
            "resume",
            "cover letter",
            "interviewing offer",
            "okr",
            "rice",
            "backlog",
            "competitive analysis",
            "roadmap",
            "pomodoro",
            "2 minute",
            "two minute",
            "feature advantage benefit",
            "par problem",
            "rap result",
            "informational interview",
            "value proposition",
            "woop",
            "wish outcome obstacle",
            "targeting matrix",
            "role industry",
            "company size",
        ]
    ):
        return "Research-audit context; career, product, and execution frameworks are weak fit unless the subject is explicitly about that domain."
    if any(term in title for term in ["pipeline kanban", "job search", "resume", "cover letter", "interviewing offer"]):
        if not flags["career"]:
            return "Career/job-search flow; weak fit for this subject unless the text is about hiring or career work."
    if "rice" in title and not flags["product_prioritization"]:
        return "Product prioritization flow; weak fit unless the text is about ranking product work, roadmap choices, or resource allocation."
    if "backlog" in title and not flags["product_prioritization"]:
        return "Backlog prioritization flow; weak fit unless the text asks for product or task prioritization."
    return ""


def advanced_flow_fit_metadata(score: float, flow: dict[str, Any], subject: str, context: dict[str, Any]) -> dict[str, Any]:
    flags = advanced_context_flags(subject, context)
    title = normalize_text(flow.get("entry_title"))
    bucket_key = advanced_flow_bucket(flow)
    bucket = ADVANCED_AUDIT_BUCKETS[bucket_key]
    mismatch = advanced_flow_mismatch_warning(flow, subject, context)

    title_strong_fit = (
        ("argument" in title and flags["evidence"])
        or ("rap" in title and (flags["evidence"] or flags["governance"] or flags["technology"]))
        or ("ladder of inference" in title and flags["evidence"])
        or ("intersectionality" in title and (flags["structural"] or flags["governance"]))
        or ("conscientization" in title and (flags["structural"] or flags["governance"]))
        or ("stakeholder" in title and (flags["structural"] or flags["governance"]))
        or ("cynefin" in title and (flags["systems"] or flags["governance"] or flags["technology"]))
        or ("systems thinking" in title and (flags["systems"] or flags["governance"]))
        or ("complex adaptive" in title and (flags["systems"] or flags["governance"]))
        or ("pre mortem" in title and (flags["risk"] or flags["governance"] or flags["technology"]))
        or ("red team" in title and (flags["risk"] or flags["governance"] or flags["technology"]))
        or (any(term in title for term in ["replication", "preregistration", "methodology", "sampling", "evidence"]) and flags["research"])
    )
    bucket_fit = (
        (bucket_key == "evidence_argument" and flags["evidence"])
        or (bucket_key == "systems_causal" and (flags["systems"] or flags["governance"] or flags["technology"]))
        or (bucket_key == "uncertainty_methodology" and (flags["risk"] or flags["governance"] or flags["technology"] or flags["research"]))
        or (bucket_key == "structural_relational" and (flags["structural"] or flags["governance"]))
        or (bucket_key == "creative_reframing" and not flags["risk"] and not flags["research"])
        or (bucket_key == "communication_task" and flags["deliverable"])
    )

    if flags["research"] and bucket_key == "creative_reframing":
        mismatch = mismatch or "Creative reframing flow; weak fit for research-methodology audit unless explicitly requested."
        relevance = "low"
    elif mismatch:
        relevance = "low"
    elif title_strong_fit or (bucket_fit and score >= 85):
        relevance = "high"
    elif bucket_fit or score >= 55:
        relevance = "medium"
    else:
        relevance = "low"

    if mismatch:
        fit_rationale = mismatch
    elif relevance == "high":
        fit_rationale = f"{first_text(flow.get('entry_title'))} directly matches the text's {bucket['role'].lower()} demands."
    elif relevance == "medium":
        fit_rationale = f"{first_text(flow.get('entry_title'))} may help with {bucket['role'].lower()}, but the host AI should verify fit before attaching it."
    else:
        fit_rationale = f"{first_text(flow.get('entry_title'))} has weak direct fit; prefer a persona-only agent unless the text gives stronger cues."

    return {
        "domain_relevance": relevance,
        "fit_rationale": fit_rationale,
        "mismatch_warning": mismatch or None,
        "epistemic_role": bucket["role"],
        "bucket": bucket_key,
    }


def advanced_score_flow(
    repo: Repository,
    flow: dict[str, Any],
    query: str,
    domain: str,
    subject: str,
    seeded_score: float = 0.0,
    retrieval_profile: str | None = None,
) -> float:
    flow_id = first_text(flow.get("flow_id"))
    flow_text = repo.flow_search_text.get(flow_id) or repo._flow_text(flow)
    query_tokens = set(tokenize(query))
    score = seeded_score
    if query_tokens:
        score += len(query_tokens & set(flow_text.split())) * 4

    bucket = advanced_flow_bucket(flow)
    lowered = subject.lower()
    if any(marker in lowered for marker in ["should", "must", "because", "therefore", "claim", "recommend"]) and bucket == "evidence_argument":
        score += 18
    if any(marker in lowered for marker in ["system", "process", "workflow", "team", "organization", "feedback", "incentive"]) and bucket == "systems_causal":
        score += 18
    if any(marker in lowered for marker in ["risk", "fail", "failure", "uncertain", "metric", "measure", "study"]) and bucket == "uncertainty_methodology":
        score += 18
    if any(marker in lowered for marker in ["customer", "community", "stakeholder", "harm", "access", "identity", "power"]) and bucket == "structural_relational":
        score += 18
    if any(marker in lowered for marker in ["write", "draft", "email", "memo", "resume", "post", "brief"]) and bucket == "communication_task":
        score += 18
    if flow_namespace(flow) == FLOW_NAMESPACE_APPLIED_REASONING:
        if advanced_has_deliverable_intent(subject):
            score += advanced_artifact_match_score(flow, subject)
            if not advanced_artifact_match_score(flow, subject):
                score -= 8
        else:
            score -= 50

    subject_norm = normalize_text(subject)
    title_norm = normalize_text(flow.get("entry_title"))
    research_context = advanced_is_research_subject(subject, {"domain": domain}) or normalize_retrieval_profile(retrieval_profile) == "research_methodology"
    if research_context:
        if bucket in {"evidence_argument", "uncertainty_methodology"}:
            score += 16
        if any(term in title_norm for term in ["replication", "preregistration", "methodology", "sampling", "generalizability", "self report", "demand effects", "evidence", "falsif", "bayesian", "toulmin", "validity"]):
            score += 36
        if any(term in title_norm for term in ["replication readiness", "sampling generalizability", "self report demand"]):
            score += 30
        if any(term in title_norm for term in ["job search", "star stories", "pipeline kanban", "resume", "cover letter", "interviewing offer", "okr", "rice", "backlog", "roadmap", "competitive analysis", "pomodoro", "2 minute", "two minute", "feature advantage benefit", "par problem", "rap result", "informational interview", "value proposition", "woop", "wish outcome obstacle", "targeting matrix", "role industry", "company size"]):
            score -= 140
    if any(term in subject_norm for term in ["governance", "policy", "accountability", "ai", "algorithm", "digital divide", "framework"]):
        if bucket in {"evidence_argument", "systems_causal", "uncertainty_methodology", "structural_relational"}:
            score += 10
        if any(term in title_norm for term in ["pipeline kanban", "job search", "resume", "cover letter"]):
            score -= 45
        if "rice" in title_norm and not any(term in subject_norm for term in ["product", "feature", "roadmap", "backlog", "prioritize"]):
            score -= 35

    if domain in {"research study/report", "news article"} and bucket in {"evidence_argument", "uncertainty_methodology"}:
        score += 8
    if domain in {"email", "social media post"} and bucket == "communication_task":
        score += 8
    if flow.get("category") in {"reasoning-frameworks", "thinking-lenses", "methodology-checks", "heuristics"}:
        score += 3
    return score


def advanced_ranked_flows(
    repo: Repository,
    subject: str,
    domain_hint: str | None,
    sensitivity: str | None,
    text_type: str | None = None,
    retrieval_profile: str | None = None,
    limit: int = 12,
) -> tuple[list[tuple[float, dict[str, Any]]], dict[str, Any]]:
    sensitivity_level, sensitivity_signals = detect_sensitivity(subject, sensitivity)
    domain_source = f"{domain_hint or ''}\n{subject}".strip()
    domain, domain_signals = detect_domain(domain_source)
    resolved_text_type, text_type_source = resolve_text_type(subject, domain, text_type)
    resolved_retrieval_profile = resolve_retrieval_profile(
        subject,
        text_type=resolved_text_type,
        domain=domain,
        retrieval_profile=retrieval_profile,
    )
    query = advanced_query(subject, domain_hint, domain, domain_signals)
    if resolved_retrieval_profile == "research_methodology":
        query = f"{query} research methodology replication validity sampling generalizability construct validity external validity demand characteristics statistical power"
    include_applied_reasoning = advanced_has_deliverable_intent(subject, domain_hint)
    search_namespace = None if include_applied_reasoning else FLOW_NAMESPACE_EPISTEMIC_CORE
    seed_results = repo.search_reasoning_flows_public(query, limit=50, namespace=search_namespace).get("results", [])
    seed_scores = {
        result.get("flow_id"): max(0.0, 60.0 - index * 2.0 + float(result.get("score") or 0))
        for index, result in enumerate(seed_results)
    }
    ranked = [
        (
            advanced_score_flow(
                repo,
                flow,
                query,
                domain,
                subject,
                seed_scores.get(flow.get("flow_id"), 0.0),
                retrieval_profile=resolved_retrieval_profile,
            ),
            flow,
        )
        for flow in repo.reasoning_flows
        if include_applied_reasoning or flow_namespace(flow) == FLOW_NAMESPACE_EPISTEMIC_CORE
    ]
    ranked = [(score, flow) for score, flow in ranked if score > 0]
    ranked.sort(key=lambda item: (-item[0], first_text(item[1].get("entry_title"))))
    context = {
        "subject_summary": advanced_subject_summary(subject),
        "domain": domain,
        "domain_signals": domain_signals,
        "sensitivity": sensitivity_level,
        "sensitivity_signals": sensitivity_signals,
        "text_type": resolved_text_type,
        "text_type_source": text_type_source,
        "query": query,
        "domain_hint": domain_hint,
        "include_applied_reasoning": include_applied_reasoning,
        "default_namespace": None if include_applied_reasoning else FLOW_NAMESPACE_EPISTEMIC_CORE,
        "retrieval_profile": resolved_retrieval_profile,
    }
    return ranked[: max(limit, 1)], context


def advanced_select_diverse(ranked: list[tuple[float, dict[str, Any]]], count: int = 4) -> list[tuple[float, dict[str, Any]]]:
    chosen: list[tuple[float, dict[str, Any]]] = []
    used_buckets: set[str] = set()
    used_subcategories: set[tuple[str, str]] = set()

    for score, flow in ranked:
        bucket = advanced_flow_bucket(flow)
        subkey = (first_text(flow.get("category")), first_text(flow.get("subcategory")))
        if bucket in used_buckets or subkey in used_subcategories:
            continue
        chosen.append((score, flow))
        used_buckets.add(bucket)
        used_subcategories.add(subkey)
        if len(chosen) >= count:
            return chosen

    for score, flow in ranked:
        if any(existing.get("flow_id") == flow.get("flow_id") for _, existing in chosen):
            continue
        chosen.append((score, flow))
        if len(chosen) >= count:
            return chosen
    return chosen


def advanced_candidate_payload(
    flow: dict[str, Any],
    rank: int,
    rationale: str,
    *,
    score: float | None = None,
    context: dict[str, Any] | None = None,
    subject: str | None = None,
) -> dict[str, Any]:
    payload = {
        "rank": rank,
        "flow_id": flow.get("flow_id"),
        "entry_id": flow.get("entry_id"),
        "title": flow.get("entry_title"),
        "category": flow.get("category"),
        "subcategory": flow.get("subcategory"),
        "kind": flow.get("kind"),
        "namespace": flow_namespace(flow),
        "rationale": rationale,
    }
    if score is not None:
        payload["score"] = round(score, 2)
    if context is not None and subject is not None:
        payload.update(advanced_flow_fit_metadata(float(score or 0), flow, subject, context))
    return payload


def advanced_rationale(flow: dict[str, Any], context: dict[str, Any]) -> str:
    bucket = ADVANCED_AUDIT_BUCKETS[advanced_flow_bucket(flow)]
    domain = context.get("domain") or "the input"
    return f"{bucket['rationale']} This fits {domain} because {first_text(flow.get('entry_title'))} has an executable flow for that kind of analysis."


def advanced_candidate_model_pool(
    ranked: list[tuple[float, dict[str, Any]]],
    context: dict[str, Any],
    subject: str,
    limit: int = 8,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    pool: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    used_flow_ids: set[str] = set()
    desired_buckets = [
        "evidence_argument",
        "systems_causal",
        "uncertainty_methodology",
        "structural_relational",
        "creative_reframing",
    ]
    if advanced_is_research_subject(subject, context):
        desired_buckets = [
            "uncertainty_methodology",
            "evidence_argument",
            "structural_relational",
            "systems_causal",
        ]
    if context.get("include_applied_reasoning"):
        desired_buckets.append("communication_task")

    def add_candidate(score: float, flow: dict[str, Any]) -> bool:
        flow_id = first_text(flow.get("flow_id"))
        if flow_id in used_flow_ids:
            return False
        if len(pool) >= limit:
            return False
        meta = advanced_flow_fit_metadata(score, flow, subject, context)
        if meta["domain_relevance"] == "low":
            if len(rejected) < 5:
                rejected.append(
                    advanced_candidate_payload(
                        flow,
                        len(rejected) + 1,
                        advanced_rationale(flow, context),
                        score=score,
                        context=context,
                        subject=subject,
                    )
                )
            return False
        used_flow_ids.add(flow_id)
        pool.append(
            advanced_candidate_payload(
                flow,
                len(pool) + 1,
                advanced_rationale(flow, context),
                score=score,
                context=context,
                subject=subject,
            )
        )
        return len(pool) >= limit

    def collect_rejections() -> None:
        for score, flow in ranked:
            if len(rejected) >= 5:
                return
            flow_id = first_text(flow.get("flow_id"))
            if flow_id in used_flow_ids:
                continue
            meta = advanced_flow_fit_metadata(score, flow, subject, context)
            if meta["domain_relevance"] != "low":
                continue
            if any(existing.get("flow_id") == flow_id for existing in rejected):
                continue
            rejected.append(
                advanced_candidate_payload(
                    flow,
                    len(rejected) + 1,
                    advanced_rationale(flow, context),
                    score=score,
                    context=context,
                    subject=subject,
                )
            )

    if advanced_is_research_subject(subject, context):
        for score, flow in ranked:
            title = normalize_text(flow.get("entry_title"))
            if not any(term in title for term in ["replication", "sampling", "generalizability", "self report", "demand effects", "methodology"]):
                continue
            add_candidate(score, flow)
            if len(pool) >= min(limit, 3):
                break

    for bucket in desired_buckets:
        for score, flow in ranked:
            if advanced_flow_bucket(flow) != bucket:
                continue
            before = len(pool)
            complete = add_candidate(score, flow)
            if complete:
                return pool, rejected
            if len(pool) > before:
                break

    for bucket in desired_buckets:
        for score, flow in ranked:
            if advanced_flow_bucket(flow) != bucket:
                continue
            before = len(pool)
            complete = add_candidate(score, flow)
            if complete:
                break
            if len(pool) > before:
                break
        if len(pool) >= limit:
            break

    for score, flow in ranked:
        if add_candidate(score, flow):
            break
    collect_rejections()
    return pool, rejected


def advanced_persona_profile(bucket_key: str) -> dict[str, str]:
    return {
        "evidence_argument": {
            "prioritizes": "Surfacing every claim, premise, warrant, objection, and inference jump before accepting the conclusion.",
            "characteristic_skepticism": "What has to be true for this claim to work, and which premise is doing the most unsupported work?",
            "argues_by": "Reconstructing the argument, testing the strongest premise, and challenging settled-sounding conclusions.",
            "tends_to_miss": "May underweight relational, emotional, or community evidence when it is not phrased as a formal premise.",
        },
        "systems_causal": {
            "prioritizes": "Conditions, feedback loops, second-order effects, incentives, handoffs, and domain mismatch.",
            "characteristic_skepticism": "What conditions produce this pattern, and what changes if the system boundary is drawn differently?",
            "argues_by": "Mapping interacting causes and showing where a single-cause story is too neat.",
            "tends_to_miss": "May understate immediate moral stakes while mapping the larger system.",
        },
        "uncertainty_methodology": {
            "prioritizes": "Evidence quality, confidence, failure modes, base rates, missing comparisons, and stop criteria.",
            "characteristic_skepticism": "What would make this conclusion false, weaker, or unsafe to act on?",
            "argues_by": "Stress-testing the evidence threshold and naming what remains unknown.",
            "tends_to_miss": "May make action feel slower than necessary when a values-based decision is also required.",
        },
        "structural_relational": {
            "prioritizes": "Power, access, excluded stakeholders, community voice, harm distribution, and relational accountability.",
            "characteristic_skepticism": "Who is spoken for, who benefits from this framing, and whose evidence is missing?",
            "argues_by": "Reading the text for erased actors, asymmetric burdens, and structural blind spots.",
            "tends_to_miss": "May underweight operational constraints or narrow decision deadlines.",
        },
        "creative_reframing": {
            "prioritizes": "Alternative frames, generative options, metaphor shifts, neglected possibilities, and non-obvious interventions.",
            "characteristic_skepticism": "What frame is making the current answer seem inevitable?",
            "argues_by": "Offering a different frame and testing whether it reveals a better question.",
            "tends_to_miss": "May diffuse focus if the text needs a direct evidentiary verdict.",
        },
        "communication_task": {
            "prioritizes": "Audience model, desired action, risk of misread, clarity of ask, and evidence-safe artifact production.",
            "characteristic_skepticism": "What judgment is this artifact smuggling under polished language?",
            "argues_by": "Separating the artifact's intent, evidence, risks, and final wording.",
            "tends_to_miss": "May over-focus on output usefulness when the deeper issue is whether the claim should be accepted.",
        },
    }.get(
        bucket_key,
        {
            "prioritizes": "Visible reasoning, evidence status, assumptions, and next action.",
            "characteristic_skepticism": "What conclusion is being reached before the evidence is ready?",
            "argues_by": "Turning the model into concrete checks and visible outputs.",
            "tends_to_miss": "May miss context not present in the subject text.",
        },
    )


def advanced_related_without_flow(repo: Repository, query: str, limit: int = 4) -> list[dict[str, Any]]:
    related: list[dict[str, Any]] = []
    for row in repo.search(query, limit=limit * 3):
        if row.get("concept_id") in repo.flows_by_entry_id:
            continue
        related.append(
            {
                "entry_id": row.get("concept_id"),
                "title": row.get("title"),
                "reason": "Matched the knowledge base, but no reasoning flow is available for MVP execution.",
            }
        )
        if len(related) >= limit:
            break
    return related


def advanced_flow_execution(flow: dict[str, Any], subject: str, context: dict[str, Any]) -> dict[str, Any]:
    steps = []
    for step in ensure_list(flow.get("steps")):
        if not isinstance(step, dict):
            continue
        steps.append(
            {
                "step_id": first_text(step.get("step_id")),
                "step_name": first_text(step.get("name")),
                "instruction": first_text(step.get("instruction")),
                "why_this_step": first_text(step.get("why_this_step")),
                "input_required": first_text(step.get("input_required")),
                "output_format": first_text(step.get("output_format")),
                "completion_check": first_text(step.get("completion_check")),
                "if_stuck": first_text(step.get("if_stuck")),
            }
        )
    title = first_text(flow.get("entry_title"))
    return {
        "flow_id": flow.get("flow_id"),
        "entry_id": flow.get("entry_id"),
        "entry_title": title,
        "namespace": flow_namespace(flow),
        "status": "scaffold_ready",
        "execution_required": True,
        "host_ai_directive": (
            f"The MCP selected {title} and returned its protocol. The analysis has NOT been performed. "
            "You are now responsible for executing every step against the subject text. Do not render this scaffold as the answer."
        ),
        "subject_summary": context.get("subject_summary"),
        "output_contract": flow.get("output_contract"),
        "steps_to_execute": steps,
        "quality_checks": ensure_list(flow.get("quality_checks")),
        "failure_modes": ensure_list(flow.get("failure_modes")),
        "anti_patterns": ensure_list(flow.get("anti_patterns")),
    }


def advanced_missing_voice_needed(subject: str, context: dict[str, Any]) -> bool:
    flags = advanced_context_flags(subject, context)
    return any(
        [
            flags["governance"],
            flags["structural"],
            first_text(context.get("text_type")) in {"advocacy", "policy"},
        ]
    )


def advanced_suggested_persona_archetypes(subject: str, context: dict[str, Any]) -> list[dict[str, Any]]:
    role_order = [
        ("evidence_argument", "The Skeptic"),
        ("systems_causal", "The Systems Mapper"),
        ("uncertainty_methodology", "The Evidence Steward"),
        ("structural_relational", "The Missing Voice" if advanced_missing_voice_needed(subject, context) else "The Relational Ethicist"),
        ("creative_reframing", "The Reframer"),
    ]
    archetypes: list[dict[str, Any]] = []
    for bucket_key, archetype in role_order:
        bucket = ADVANCED_AUDIT_BUCKETS[bucket_key]
        profile = advanced_persona_profile(bucket_key)
        archetypes.append(
            {
                "epistemic_role": bucket["role"],
                "suggested_name": archetype,
                "default_persona": bucket["persona"],
                "reasoning_philosophy": profile["prioritizes"],
                "decision_making_voice": profile["argues_by"],
                "characteristic_skepticism": profile["characteristic_skepticism"],
                "characteristic_blind_spot": profile["tends_to_miss"],
                "must_ground_in_text": "Quote or paraphrase a specific phrase, claim, omission, or structural move from the subject text.",
            }
        )
    return archetypes


def normalize_host_capability_profile(value: dict[str, Any] | None) -> dict[str, Any]:
    profile = value if isinstance(value, dict) else {}
    host_family = normalize_text(first_text(profile.get("host_family"))).replace("-", "_").replace(" ", "_") or "unknown"
    if host_family in {"claude", "claude_desktop_app"}:
        host_family = "claude_desktop"
    if host_family in {"claude_code_cli", "claude_cowork"}:
        host_family = "claude_code"
    if host_family in {"chat", "generic"}:
        host_family = "generic_chat"
    return {
        "host_family": host_family,
        "native_question_ui": bool(profile.get("native_question_ui", host_family in {"claude_desktop", "claude_code", "codex"})),
        "native_subagents": bool(profile.get("native_subagents", False)),
        "explicit_subagent_spawn": bool(profile.get("explicit_subagent_spawn", False)),
        "can_write_progress_log": bool(profile.get("can_write_progress_log", False)),
        "can_call_external_tools": bool(profile.get("can_call_external_tools", False)),
        "can_execute_stage_scaffolds": bool(profile.get("can_execute_stage_scaffolds", True)),
    }


def agent_execution_adapter(host_capability_profile: dict[str, Any] | None = None) -> dict[str, Any]:
    profile = normalize_host_capability_profile(host_capability_profile)
    if not profile["can_execute_stage_scaffolds"]:
        selected = "scaffold_only"
    elif profile["host_family"] == "claude_code" and profile["native_subagents"]:
        selected = "claude_native_subagents"
    elif profile["host_family"] == "codex" and profile["explicit_subagent_spawn"]:
        selected = "codex_explicit_subagents"
    else:
        selected = "sequential_labeled_fallback"
    fallback = selected in {"sequential_labeled_fallback", "scaffold_only"}
    disclosure = (
        "Native subagents are unavailable here, so I will run the analyst panel sequentially in this chat with labeled sections."
        if selected == "sequential_labeled_fallback"
        else "This host can inspect the panel scaffold, but it has not declared that it can execute the staged panel workflow."
        if selected == "scaffold_only"
        else ""
    )
    return {
        "selected_adapter": selected,
        "host_capability_profile": profile,
        "fallback_disclosure_required": fallback,
        "fallback_disclosure_text": disclosure,
        "role_label_format": "## [AGENT_NAME]",
        "output_shape_matches_native": True,
        "user_message": (
            "I can still run the panel review, but it will be simulated in one thread."
            if selected == "sequential_labeled_fallback"
            else "I can show the panel contract, but this host needs a separate executor to run it."
            if selected == "scaffold_only"
            else "This host declared support for real subagent execution; preserve the same stage artifacts and dissent ledger."
        ),
        "sandbox_rule": "Panel approval does not bypass host sandbox, tool approval, external-call, or MCP trust policy.",
    }


def agentic_role_contracts() -> list[dict[str, Any]]:
    base_required = [
        "agent_id",
        "top_finding",
        "bias_findings",
        "challenged_claim",
        "cis_dimension_evidence",
        "blind_spot_underweighted",
    ]
    return [
        {
            "role_id": "agent_1",
            "role_type": "evidence_argument",
            "display_name": "Evidence and Argument Reviewer",
            "purpose": "Reconstruct claims, warrants, objections, evidence gaps, and inference jumps before accepting the conclusion.",
            "inputs": ["subject_text", "text_type", "candidate_model_pool"],
            "allowed_tools": ["lookup_bias", "search_knowledge_base", "challenge_claim", "get_framework", "get_pattern", "get_reasoning_flow"],
            "forbidden_tools": ["generate_audit_report", "save_blind_spot_reminder", "factcheck_lookup", "publisher_harvest", "local_claimreview"],
            "expected_artifact_schema": {"required": base_required},
            "stop_condition": "Stop after one independent analysis artifact is complete.",
            "max_turns": 3,
            "max_tool_calls": 5,
            "permission_profile": "read_only",
            "handoff_target": "tension_map",
            "asks_user_directly": False,
        },
        {
            "role_id": "agent_2",
            "role_type": "systems_context",
            "display_name": "Systems and Context Reviewer",
            "purpose": "Check whether the text accounts for incentives, implementation context, second-order effects, and organizational constraints.",
            "inputs": ["subject_text", "text_type", "candidate_model_pool"],
            "allowed_tools": ["lookup_bias", "search_knowledge_base", "get_framework", "get_pattern", "get_reasoning_flow"],
            "forbidden_tools": ["generate_audit_report", "save_blind_spot_reminder", "factcheck_lookup", "publisher_harvest", "local_claimreview"],
            "expected_artifact_schema": {"required": base_required},
            "stop_condition": "Stop after one independent analysis artifact is complete.",
            "max_turns": 3,
            "max_tool_calls": 5,
            "permission_profile": "read_only",
            "handoff_target": "tension_map",
            "asks_user_directly": False,
        },
        {
            "role_id": "agent_3",
            "role_type": "uncertainty_methods",
            "display_name": "Uncertainty and Methods Reviewer",
            "purpose": "Stress-test confidence, comparability, evidence conventions, research-method fit, and what evidence would change the audit.",
            "inputs": ["subject_text", "text_type", "candidate_model_pool"],
            "allowed_tools": ["lookup_bias", "search_knowledge_base", "challenge_claim", "get_framework", "get_pattern", "get_reasoning_flow"],
            "forbidden_tools": ["generate_audit_report", "save_blind_spot_reminder", "factcheck_lookup", "publisher_harvest", "local_claimreview"],
            "expected_artifact_schema": {"required": base_required},
            "stop_condition": "Stop after one independent analysis artifact is complete.",
            "max_turns": 3,
            "max_tool_calls": 5,
            "permission_profile": "read_only",
            "handoff_target": "tension_map",
            "asks_user_directly": False,
        },
        {
            "role_id": "agent_4",
            "role_type": "missing_voice_power",
            "display_name": "Missing Voice and Power Reviewer",
            "purpose": "Surface absent stakeholders, positionality and power risks, over-narrow framing, and voices with standing that the text may underweight.",
            "inputs": ["subject_text", "text_type", "candidate_model_pool"],
            "allowed_tools": ["lookup_bias", "search_knowledge_base", "get_framework", "get_pattern"],
            "forbidden_tools": ["generate_audit_report", "save_blind_spot_reminder", "factcheck_lookup", "publisher_harvest", "local_claimreview"],
            "expected_artifact_schema": {"required": base_required},
            "stop_condition": "Stop after one independent analysis artifact is complete.",
            "max_turns": 3,
            "max_tool_calls": 4,
            "permission_profile": "read_only",
            "handoff_target": "tension_map",
            "asks_user_directly": False,
        },
    ]


def agentic_artifact_budget(depth: str | None = None) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    return {
        "artifact_only_handoff": True,
        "do_not_pass_full_transcript": True,
        "max_words_per_independent_analysis": 320 if depth_value == "deep" else 220,
        "max_tensions": 5,
        "max_debate_turns": 3,
        "carry_forward_keys": ["agent_roster", "analyses", "tensions", "debate", "critical_integrity_snapshot"],
        "audit_only_keys": ["raw_tool_outputs", "scratch_notes", "discarded_frameworks", "full_transcript"],
    }


def agentic_revision_state(agentic_state: dict[str, Any] | None = None) -> dict[str, Any]:
    state = agentic_state if isinstance(agentic_state, dict) else {}
    try:
        pass_count = max(0, int(state.get("revision_pass_count", 0)))
    except (TypeError, ValueError):
        pass_count = 0
    return {
        "revision_requested": bool(state.get("revision_requested", False)),
        "revision_pass_count": pass_count,
        "max_revision_passes": 1,
        "revision_trigger": state.get("revision_trigger"),
        "stop_condition_reached": pass_count >= 1,
        "policy": "After one high-impact revision pass, finalize with caveats or withhold the aggregate as profile_only.",
        "triggers": ["FRAME_COLLAPSE", "NEEDS_EVIDENCE could change label, confidence, comparability, or profile-only state"],
    }


def agentic_progress_state(
    *,
    agentic_state: dict[str, Any] | None = None,
    current_stage: str = "plan_review",
    next_tool: str | None = None,
    agentic_run_id: str | None = None,
    artifact_refs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    state = agentic_state if isinstance(agentic_state, dict) else {}
    completed = state.get("completed_stage_ids")
    completed_ids = [first_text(item) for item in completed if first_text(item)] if isinstance(completed, list) else []
    run_id = first_text(state.get("agentic_run_id")) or first_text(agentic_run_id) or f"agentic-{uuid4()}"
    return {
        "agentic_run_id": run_id,
        "current_stage": current_stage if current_stage in AGENTIC_PROGRESS_STAGES else "plan_review",
        "completed_stage_ids": completed_ids,
        "next_tool": next_tool or "advanced_audit",
        "required_inputs": ["subject", "agentic_state"] if current_stage == "plan_review" else [],
        "artifact_refs": artifact_refs or {},
        "resume_allowed": True,
        "stop_reason": "awaiting_host_stage_execution" if current_stage != "plan_review" else "awaiting_agentic_plan_approval",
    }


def agentic_plan_hash(plan_core: dict[str, Any]) -> str:
    encoded = json.dumps(plan_core, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def agentic_plan_core(
    *,
    subject: str,
    context: dict[str, Any],
    depth: str,
    host_capability_profile: dict[str, Any] | None,
) -> dict[str, Any]:
    roles = agentic_role_contracts()
    adapter = agent_execution_adapter(host_capability_profile)
    stage_plan = advanced_stage_plan(depth)
    return {
        "subject_summary": context.get("subject_summary") or advanced_subject_summary(subject),
        "text_type": context.get("text_type"),
        "depth": depth,
        "role_contracts": roles,
        "stage_plan": stage_plan,
        "selected_adapter": adapter["selected_adapter"],
        "tool_allowlists": {role["role_id"]: role["allowed_tools"] for role in roles},
        "artifact_budget": agentic_artifact_budget(depth),
        "revision_budget": {"max_revision_passes": 1},
    }


def agentic_plan_review_payload(
    *,
    subject: str,
    context: dict[str, Any],
    depth: str,
    host_capability_profile: dict[str, Any] | None,
    agentic_state: dict[str, Any] | None,
    audit_snapshot: dict[str, Any],
) -> dict[str, Any]:
    roles = agentic_role_contracts()
    adapter = agent_execution_adapter(host_capability_profile)
    stage_plan = advanced_stage_plan(depth)
    progress = agentic_progress_state(agentic_state=agentic_state, current_stage="plan_review")
    plan_core = agentic_plan_core(subject=subject, context=context, depth=depth, host_capability_profile=host_capability_profile)
    plan_hash = agentic_plan_hash(plan_core)
    return {
        "tool": "advanced_audit",
        "mode": "agent",
        "status": "agentic_plan_review_required",
        "execution_required": False,
        "agentic_stage": "stage_agentic_plan_review",
        "agentic_run_id": progress["agentic_run_id"],
        "agentic_plan_hash": plan_hash,
        "agentic_approval_required": True,
        "agentic_mode_requires_explicit_opt_in": True,
        "subject_text": subject,
        "subject_summary": context.get("subject_summary"),
        "text_type": context.get("text_type"),
        "text_type_source": context.get("text_type_source"),
        "retrieval_profile": context.get("retrieval_profile"),
        "depth": depth,
        "plain_user_summary": (
            "I can run this as a deeper panel review. Four analytical perspectives read the same text separately, "
            "compare disagreements, then produce one final verdict with dissent preserved."
        ),
        "questions_for_user": [
            {
                "id": "agentic_plan_approval",
                "plain_question": "Do you want to run this deeper panel review?",
                "choices": ["Yes, run the panel", "No, use a normal audit"],
                "state_update_on_yes": {"agentic_state.plan_approved": True, "agentic_state.approved_plan_hash": plan_hash},
                "state_update_on_no": {"agentic_state.plan_declined": True},
            }
        ],
        "agent_execution_adapter": adapter,
        "role_contracts": roles,
        "stage_plan": stage_plan,
        "artifact_budget": agentic_artifact_budget(depth),
        "agentic_progress_state": progress,
        "agentic_revision_state": agentic_revision_state(agentic_state),
        "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
        "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
        "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
        "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
        "human_loop": audit_snapshot.get("human_loop"),
        "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
        "fallback_route_if_declined": {"tool": "audit_text", "mode": "normal_audit"},
        "plan_core": plan_core,
    }


def agentic_plan_declined_payload(subject: str, context: dict[str, Any], audit_snapshot: dict[str, Any], depth: str) -> dict[str, Any]:
    return {
        "tool": "advanced_audit",
        "mode": "agent",
        "status": "agentic_plan_declined_route_to_normal_audit",
        "execution_required": False,
        "required_next_tool": "audit_text",
        "required_mode": "normal",
        "required_depth": depth,
        "subject_text": subject,
        "subject_summary": context.get("subject_summary"),
        "plain_user_summary": "Panel review was declined. Use a normal Critical Compass audit instead.",
        "next_call": {"tool": "audit_text", "arguments": {"text": subject, "text_type": context.get("text_type")}},
        "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
        "human_loop": audit_snapshot.get("human_loop"),
        "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
    }


def agentic_plan_hash_mismatch_payload(expected_hash: str, supplied_hash: str | None) -> dict[str, Any]:
    return {
        "tool": "advanced_audit",
        "mode": "agent",
        "status": "agentic_plan_hash_mismatch",
        "execution_required": False,
        "agentic_approval_required": True,
        "expected_plan_hash": expected_hash,
        "supplied_plan_hash": supplied_hash,
        "recovery_action": "Re-run advanced_audit(mode='agent') to show the current plan review, then pass back the returned agentic_plan_hash after user approval.",
    }


def advanced_agent_design_protocol(subject: str, context: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": "agent_design_required_before_analysis",
        "required_agent_count": 4,
        "directive": (
            "Before analyzing, define four distinct analyst personas. Use the suggested archetypes and candidate_model_pool as inputs, "
            "but make the final persona/framework pairing yourself based on the subject text."
        ),
        "persona_requirements": [
            "Give each agent a name and epistemic archetype.",
            "State the agent's reasoning philosophy for this text type.",
            "Assign one primary and one secondary reasoning style; agents may shift styles when the text demands it.",
            "Give each agent 2 to 3 tool affinities that fit its style.",
            "State the agent's decision-making voice: evidence, pattern, absence, harm, constraints, or possibility.",
            "State one characteristic blind spot before analysis begins.",
            "Assign each agent one or two CIS dimensions to watch, using the exact public dimension names.",
            "If this is a governance, policy, advocacy, community, equity, stakeholder, or harm text, include a Missing Voice or Absent Stakeholder persona.",
        ],
        "cis_dimensions_to_assign": [label for _, label in SNAPSHOT_DIMENSIONS],
        "role_contracts": agentic_role_contracts(),
        "role_contract_rule": "Dynamic persona names are allowed, but each persona must map to exactly one stable role_contract.role_id before analysis.",
        "suggested_persona_archetypes": advanced_suggested_persona_archetypes(subject, context),
        "output_contract": "Define each persona in 4 to 6 sentences, as though introducing debaters before a panel.",
    }


def advanced_framework_attachment_rules() -> dict[str, Any]:
    return {
        "directive": "Use candidate_model_pool as an optional verified model library, not as mandatory agent assignments.",
        "attach_when": [
            "Attach a framework when domain_relevance is high.",
            "Attach a medium-relevance framework only if its fit_rationale clearly matches the text's actual claims, stakes, or structure.",
            "Prefer no framework over an irrelevant framework.",
        ],
        "do_not_attach_when": [
            "Do not attach low-relevance frameworks.",
            "Do not attach applied/task flows unless the user asks to produce an artifact.",
            "Do not attach career, product-prioritization, or job-search models to governance or policy analysis unless the subject explicitly uses that domain.",
        ],
        "persona_only_fallback": {
            "framework_attachment": None,
            "instruction": "If no framework cleanly fits an agent, keep the persona and set framework_attachment to null with a one-sentence reason.",
        },
        "required_attachment_fields": [
            "agent_name",
            "epistemic_archetype",
            "framework_attachment",
            "attachment_rationale",
            "rejected_framework_if_any",
        ],
    }


def advanced_agent_instruction() -> dict[str, Any]:
    return {
        "status": "model_pool_ready_awaiting_host_ai_persona_design",
        "directive": (
            "The MCP has retrieved and scored candidate reasoning models. The analysis has NOT been performed. "
            "You are now the reasoning engine. Do not render this scaffold; execute it sequentially. "
            "First define the analyst agents, then attach only frameworks that genuinely fit the subject text."
        ),
    }


def advanced_agent_execution_protocol(synthesis_audience: str = "both", depth: str | None = None) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    audience_guidance = {
        "reader": "Write the verdict for a reader deciding how much to trust the text.",
        "author": "Write the verdict for the author improving the document or argument.",
        "both": "Write one trust verdict for the reader and one concrete mitigation for the author.",
    }.get(synthesis_audience, "Write one trust verdict for the reader and one concrete mitigation for the author.")
    stages = [
        {
            "stage": "mode_detection",
            "stage_tool": "lookup_bias",
            "purpose": "Silently probe whether MCP-Enhanced Mode is available before citing KB-backed findings.",
            "required_call": {"tool": "lookup_bias", "arguments": {"name": "confirmation bias"}},
            "output": "Set mode header internally; do not render detection chatter.",
        },
        {
            "stage": "agent_definition",
            "stage_tool": "define_audit_agents",
            "purpose": "Define four distinct analyst agents before any analysis begins.",
            "output": "Four panel-style persona cards with reasoning styles, tool affinities, blind spots, and optional framework attachments.",
        },
        {
            "stage": "independent_analysis",
            "stage_tool": "run_independent_audit_analysis",
            "purpose": "Run one first-person, text-grounded analysis per agent.",
            "required_calls": [
                "lookup_bias or search_knowledge_base",
                "challenge_claim",
                "get_framework or get_pattern",
                "list_reasoning_flows and get_reasoning_flow when an executable flow fits",
            ],
            "output": "Four analysis entries with KB IDs, Three Cs labels, claim challenges with steelman risk, alternative frames, room questions, and CIS dimension evidence.",
        },
        {
            "stage": "tension_map",
            "stage_tool": "map_audit_tensions",
            "purpose": "Identify live disagreements before debate.",
            "output": "3 to 5 tensions labeled RESOLVABLE, UNRESOLVABLE, NEEDS_EVIDENCE, or FRAME_COLLAPSE, including whether the tension could change the Critical Integrity Snapshot.",
        },
        {
            "stage": "debate",
            "stage_tool": "run_audit_debate",
            "purpose": "Stage one grounded three-turn exchange from the sharpest resolvable tension.",
            "output": "Three turns that preserve each agent's reasoning style and reference subject-text language.",
        },
        {
            "stage": "synthesis",
            "stage_tool": "synthesize_audit_verdict",
            "purpose": "Commit to one verdict and produce next steps.",
            "required_call": {"tool": "suggest_next_steps", "arguments": {"domain": "text_type", "biases_found": "JSON array of bias names or IDs"}},
            "synthesis_audience": synthesis_audience,
            "audience_guidance": audience_guidance,
            "output": "Quick-Scan revision notes, Critical Integrity Snapshot confirmation/revision/withholding, verdict, counterargument, mitigation, and next steps.",
        },
    ]
    if depth_value == "deep":
        stages.append(
            {
                "stage": "mitigation_rewrite",
                "stage_tool": "propose_mitigation_rewrite",
                "purpose": "Add Step 6b: rewrite the most problematic sentence to mitigate the primary bias without changing the author's core intent.",
                "output": "One original sentence, one revised sentence, and one sentence explaining the bias reduction.",
            }
        )
    return {
        "status": "split_stage_protocol",
        "mode": "host_ai_executes",
        "depth": depth_value,
        "instruction": "Call the stage scaffold tools in order, complete each step fully before advancing, and pass the completed typed output into the next stage. Do not render scaffolds as output.",
        "stages": stages,
    }


def advanced_agent_output_format(depth: str | None = None) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    full_analysis = [
        "Step 2 - Agent definitions with Agent Roster",
        "Step 3 - Independent analyses",
        "Step 4 - Tension map",
        "Step 5 - Debate exchange",
        "Step 6 - Verdict paragraph, Agent Contribution Matrix, Dissent Ledger, and Next Steps",
    ]
    if depth_value == "deep":
        full_analysis.append("Step 6b - Mitigation rewrite")
    return {
        "quick_scan_card": {
            "max_words": 150,
            "source": "Start from prepopulated_quick_scan_card and revise only if the full analysis materially changes the top bias, primary tension, or next action.",
            "fields": [
                "Mode",
                "Text type",
                "Sensitivity level",
                "Top 3 biases identified: [KB ID if available] [name] - [one-line justification] [Three Cs label]",
                "Critical Integrity Snapshot: label or profile-only state, points only when scored, confidence, comparability, context lens, five dimensions, and a Before Using This Text sentence starting exactly with 'Before using this text,'",
                "Plain-Language Read",
                "Follow-Up Activity: one compact idea in quick mode, or solo/group activities in full report-ready output",
                "Primary tension",
                "Verdict",
                "Recommended action",
                "Dissent ledger: each agent's top finding, strongest disagreement, confidence, and what would change its mind",
                "reasoning_styles_used",
            ],
        },
        "full_analysis": full_analysis,
        "quick_depth_behavior": "For depth=quick, render only the Quick-Scan Card scaffold and do not run full multi-agent stages.",
    }


def advanced_agent_quality_gates(depth: str | None = None) -> list[str]:
    depth_value = normalize_audit_depth(depth)
    gates = [
        "Each Step 1 persona has a named blind spot, not just a strength.",
        "Each persona has one primary and one secondary reasoning style from the allowed list.",
        "The mode check records MCP-Enhanced Mode or Reference Mode before KB-backed findings are cited.",
        "Each independent analysis is first person, references the specific text, and names what the persona may underweight.",
        "Every cited bias has a KB ID when MCP-Enhanced Mode is available.",
        "Each bias finding has a Three Cs label: Critical, Compassionate, or Creative.",
        "At least one settled claim per agent is challenged with challenge_claim in MCP-Enhanced Mode.",
        "Every fallacy risk includes Steelman Risk: when the pattern is not a fallacy.",
        "At least one alternative lens is retrieved with get_framework or get_pattern in MCP-Enhanced Mode.",
        "get_reasoning_flow is used where an agent style matches an available executable flow.",
        "The tension map names agents by name and labels each tension RESOLVABLE, UNRESOLVABLE, NEEDS_EVIDENCE, or FRAME_COLLAPSE.",
        "The debate references actual text language in at least two of three turns.",
        "New biases or fallacy risks surfaced mid-debate trigger an inline MCP call.",
        "The final render preserves agent names through an Agent Roster and Agent Contribution Matrix.",
        "The final render preserves dissent through a Dissent Ledger; do not hide disagreement behind consensus wording.",
        "Check-worthy factual claims are separated from interpretive, causal, normative, and policy claims; check-worthy never means false.",
        "The synthesis calls suggest_next_steps with biases_found as a JSON array of bias names or IDs in MCP-Enhanced Mode.",
        "The synthesis commits to a single verdict with no `it depends` ending.",
        "The Critical Integrity Snapshot is computed after audit findings and appears after top bias findings.",
        "The snapshot uses no letter grades, percentages, or bare 1-5 scales.",
        "Snapshot confidence and comparability are separate from points.",
        "The snapshot withholds label and points in profile_only mode when aggregate scoring is not defensible.",
        "Every snapshot dimension traces to concrete findings.",
        "The snapshot uses Bias Transparency and Framing & Audience Openness.",
        "The snapshot prompt starts exactly with `Before using this text,`.",
        "The final output includes Plain-Language Read and the right-sized Follow-Up Activity.",
        "The Quick-Scan Card lists reasoning styles used.",
        "The Quick-Scan Card appears above the full analysis.",
        "The output does not reveal hidden chain-of-thought; it provides concise visible reasoning and conclusions.",
    ]
    if depth_value == "deep":
        gates.append("Depth is deep, so Step 6b includes one sentence rewrite that mitigates the primary bias without changing the author's core intent.")
    return gates


def normalize_audit_resume_stage(value: str | None) -> str:
    stage = advanced_mode(value)
    aliases = {
        "agents": "agent_definition",
        "agent": "agent_definition",
        "agent_definitions": "agent_definition",
        "define_agents": "agent_definition",
        "analysis": "independent_analysis",
        "independent": "independent_analysis",
        "independent_analyses": "independent_analysis",
        "run_independent_analysis": "independent_analysis",
        "tensions": "tension_map",
        "map_tensions": "tension_map",
        "tension": "tension_map",
        "structured_debate": "debate",
        "run_debate": "debate",
        "verdict": "synthesis",
        "synthesize": "synthesis",
        "synthesize_verdict": "synthesis",
    }
    stage = aliases.get(stage, stage)
    return stage if stage in AUDIT_RESUME_STAGES else ""


def coerce_payload_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError:
            return {}
        return loaded if isinstance(loaded, dict) else {}
    return {}


def extract_stage_list(payload: dict[str, Any], keys: list[str]) -> list[dict[str, Any]]:
    candidates = [payload]
    for container_key in ["stage_output", "output", "result", "payload", "prior_stage_payload"]:
        nested = payload.get(container_key)
        if isinstance(nested, dict):
            candidates.append(nested)
    for candidate in candidates:
        for key in keys:
            value = candidate.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
            if isinstance(value, dict):
                nested_items = value.get("items") or value.get("agents") or value.get("analyses") or value.get("tensions")
                if isinstance(nested_items, list):
                    return [item for item in nested_items if isinstance(item, dict)]
    return []


def audit_input_warnings(**items: Any) -> list[str]:
    warnings: list[str] = []
    for name, value in items.items():
        if value in (None, "", [], {}):
            warnings.append(f"Missing or empty input: {name}. Return the scaffold, but tell the host AI to supply this before executing the stage.")
    return warnings


def advanced_overkill_warning(subject: str, depth: str, text_type: str | None) -> str | None:
    if depth == "quick":
        return None
    resolved_type = normalize_text_type(text_type)
    if is_vague_or_short(subject) or resolved_type in {"general", "narrative"} and word_count(subject) < 60:
        return "Full advanced_audit may be overkill for this short or conversational text; use audit_text or depth='quick' unless a multi-agent audit is needed."
    return None


def compact_quality_gates(gates: list[str], limit: int = 7) -> list[str]:
    return gates[:limit]


def stage_expected_output(output_schema: dict[str, Any]) -> str:
    keys = list(output_schema.keys())
    if not keys:
        return "completed stage payload"
    return ", ".join(keys[:4])


def visible_reasoning_contract() -> dict[str, str]:
    return {
        "rule": "Show concise warrant-level reasoning, not hidden chain-of-thought.",
        "format": "Use short visible links such as: claim -> warrant -> missing evidence -> implication.",
        "avoid": "Do not expose private deliberation, exhaustive scratchpad reasoning, or token-by-token internal analysis.",
    }


def stage_carry_forward_keys(stage: str) -> list[str]:
    return {
        "agent_definition": ["agent_roster", "agents"],
        "independent_analysis": ["agents", "analyses", "biases_found", "snapshot_dimension_evidence"],
        "tension_map": ["agents", "analyses", "tensions", "snapshot_changing_disputes"],
        "debate": ["agents", "analyses", "tensions", "debate"],
        "synthesis": ["final_card", "critical_integrity_snapshot", "verdict", "agent_contribution_matrix"],
        "mitigation_rewrite": ["mitigation_rewrite"],
    }.get(stage, ["completed_stage_payload"])


def stage_common_failure(stage: str) -> str:
    return {
        "agent_definition": "Do not analyze the text yet; name the panelists, styles, tool affinities, blind spots, and CIS dimensions they will watch.",
        "independent_analysis": "Do not collapse the agents into one voice; each analysis must be first person, text-grounded, and tied to CIS dimension evidence.",
        "tension_map": "Do not summarize findings; name live disagreements and whether they could change CIS label, confidence, comparability, or profile-only state.",
        "debate": "Do not simulate generic disagreement; use the selected tension and keep each agent's original reasoning style.",
        "synthesis": "Do not list possibilities; confirm, revise, or withhold the snapshot and commit to one verdict.",
        "mitigation_rewrite": "Do not rewrite the whole text; rewrite exactly one problematic sentence.",
    }.get(stage, "Do not render the scaffold as the final user-facing analysis.")


def stage_delta_from_previous(stage: str) -> str:
    return {
        "agent_definition": "This is the first substantive stage after mode detection; it creates the named agents used by every later step.",
        "independent_analysis": "Moves from persona design to four independent readings of the subject text.",
        "tension_map": "Moves from separate readings to a conflict inventory across agents.",
        "debate": "Moves from inventory to one direct exchange over the sharpest resolvable tension.",
        "synthesis": "Moves from debate to a final verdict and CIS decision.",
        "mitigation_rewrite": "Adds the deep-mode action step after the verdict.",
    }.get(stage, "Continue from the prior completed stage.")


def stage_handoff_payload(
    *,
    stage: str,
    title: str,
    required_inputs: list[str],
    required_calls: list[str],
    output_schema: dict[str, Any],
) -> dict[str, Any]:
    return {
        "stage": stage,
        "title": title,
        "inputs_needed": required_inputs,
        "host_output_required": stage_expected_output(output_schema),
        "required_tool_calls": required_calls,
        "carry_forward_keys": stage_carry_forward_keys(stage),
        "artifact_only_handoff": True,
        "do_not_pass_full_transcript": True,
        "stop_condition": "Stop after this stage's typed output is complete and saved/passed forward.",
        "common_failure_to_avoid": stage_common_failure(stage),
        "delta_from_previous_stage": stage_delta_from_previous(stage),
    }


def schema_key_paths(schema: Any, *, prefix: str = "", limit: int = 80) -> list[str]:
    paths: list[str] = []

    def visit(value: Any, path: str) -> None:
        if len(paths) >= limit:
            return
        if isinstance(value, dict):
            for key, nested in value.items():
                next_path = f"{path}.{key}" if path else str(key)
                paths.append(next_path)
                visit(nested, next_path)
                if len(paths) >= limit:
                    return
        elif isinstance(value, list) and value:
            visit(value[0], f"{path}[]" if path else "[]")

    visit(schema, prefix)
    return paths[:limit]


def audit_stage_scaffold(
    *,
    tool: str,
    stage: str,
    title: str,
    host_ai_directive: str,
    required_inputs: list[str],
    recommended_mcp_calls: list[dict[str, Any]],
    output_schema: dict[str, Any],
    quality_gates: list[str],
    scaffold_detail: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    detail = normalize_scaffold_detail(scaffold_detail)
    core_gates = compact_quality_gates(quality_gates)
    stage_labels = {
        "agent_definition": "Stage 2 - Agent Definition",
        "independent_analysis": "Stage 3 - Independent Analysis",
        "tension_map": "Stage 4 - Tension Map",
        "debate": "Stage 5 - Structured Debate",
        "synthesis": "Stage 6 - Synthesis and Verdict",
        "mitigation_rewrite": "Step 6b - Mitigation Rewrite",
    }
    required_calls = [
        first_text(call.get("tool"))
        for call in recommended_mcp_calls
        if call.get("tool") and "optional" not in first_text(call.get("when")).lower()
    ]
    handoff = stage_handoff_payload(
        stage=stage,
        title=title,
        required_inputs=required_inputs,
        required_calls=required_calls,
        output_schema=output_schema,
    )
    payload = {
        "tool": tool,
        "status": "scaffold_ready",
        "execution_required": True,
        "stage": stage,
        "stage_title": title,
        "scaffold_detail": detail,
        "stage_handoff": handoff,
        "stage_brief": {
            "you_are_now_in": stage_labels.get(stage, title),
            "inputs": required_inputs,
            "output": stage_expected_output(output_schema),
            "required_calls": required_calls,
            "stop_when_done": "Return this stage's typed output and pass it forward; do not continue into the next stage unless explicitly asked.",
        },
        "artifact_only_handoff": True,
        "do_not_pass_full_transcript": True,
        "artifact_budget": agentic_artifact_budget(),
        "agentic_progress_state": agentic_progress_state(current_stage=stage, next_tool=tool),
        "visible_reasoning_contract": visible_reasoning_contract(),
        "host_ai_directive": host_ai_directive,
        "required_inputs": required_inputs,
        "recommended_mcp_calls": recommended_mcp_calls,
        "output_schema": output_schema,
        "quality_gates": quality_gates if detail == "full" else core_gates,
        "quality_gates_core": core_gates,
        "quality_gate_details": quality_gates,
    }
    if extra:
        payload.update(extra)
    if detail == "handoff":
        handoff_payload = {
            "tool": tool,
            "status": "scaffold_ready",
            "execution_required": True,
            "stage": stage,
            "stage_title": title,
            "scaffold_detail": detail,
            "stage_handoff": handoff,
            "artifact_only_handoff": True,
            "do_not_pass_full_transcript": True,
            "artifact_budget": agentic_artifact_budget(),
            "agentic_progress_state": agentic_progress_state(current_stage=stage, next_tool=tool),
            "visible_reasoning_contract": visible_reasoning_contract(),
            "host_ai_directive": host_ai_directive,
            "required_inputs": required_inputs,
            "recommended_mcp_calls": recommended_mcp_calls,
            "output_schema_keys": list(output_schema.keys()),
            "required_output_fields": schema_key_paths(output_schema, limit=120),
            "quality_gates": core_gates[:4],
        }
        if extra:
            handoff_payload.update(extra)
        return handoff_payload
    return payload


def advanced_tool_inventory_check(repo: Repository) -> dict[str, Any]:
    try:
        probe = repo.lookup_bias_public("confirmation bias")
    except Exception as exc:  # pragma: no cover - defensive boundary for MCP clients
        probe = {"found": False, "error": str(exc)}
    found = bool(probe.get("found"))
    return {
        "stage": "tool_inventory_check",
        "status": "mcp_enhanced_available" if found else "reference_mode_needed",
        "server_probe_found": found,
        "probe_call": {"tool": "lookup_bias", "arguments": {"name": "confirmation bias"}},
        "on_success": "Set mode header to MCP-Enhanced Mode and use Critical Compass MCP tools throughout the audit.",
        "on_failure": "Set mode header to Reference Mode and use the embedded Critical Compass references as fallback.",
        "rendering_rule": "Do not expose raw MCP JSON; render concise KB IDs, definitions, and tool-derived findings only.",
    }


def advanced_input_parameters(
    subject: str,
    context: dict[str, Any],
    *,
    depth: str,
    resume_from: str | None = None,
) -> dict[str, Any]:
    return {
        "subject_text": subject,
        "text_type": context.get("text_type"),
        "sensitivity": context.get("sensitivity"),
        "depth": depth,
        "snapshot_mode": context.get("snapshot_mode"),
        "scaffold_detail": context.get("scaffold_detail"),
        "retrieval_profile": context.get("retrieval_profile"),
        "resume_from": resume_from,
    }


def advanced_quick_scan_scaffold(
    subject: str,
    context: dict[str, Any],
    audit_snapshot: dict[str, Any],
    *,
    resume_from: str | None = None,
) -> dict[str, Any]:
    return {
        "tool": "advanced_audit",
        "mode": "agent",
        "status": "scaffold_ready",
        "execution_required": True,
        "depth": "quick",
        "subject_text": subject,
        "subject_summary": context.get("subject_summary"),
        "input_parameters": advanced_input_parameters(subject, context, depth="quick", resume_from=resume_from),
        "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
        "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
        "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
        "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
        "human_loop": audit_snapshot.get("human_loop"),
        "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
        "report_readiness_contract": report_readiness_contract("overview", stage="advanced_audit_quick", include_advanced=False),
        "host_ai_directive": (
            "Depth is quick. Render only the Quick-Scan Card and Critical Integrity Snapshot from the prepopulated audit_text payload. "
            "Do not run agent definitions, independent analyses, tension mapping, debate, or synthesis unless the user asks for more depth."
        ),
        "output_format": {
            "quick_scan_card": {
                "max_words": 150,
                "fields": [
                    "Mode",
                    "Text type",
                    "Sensitivity",
                    "Top 3 biases",
                    "Critical Integrity Snapshot: label or profile-only state, points only when scored, score_confidence, comparability, context_lens, dimension profile",
                    "Primary tension",
                    "Verdict (one sentence)",
                    "Recommended action",
                    "Plain-Language Read",
                    "Before Using This Text, starting exactly with 'Before using this text,'",
                    "One compact try_this_next activity idea when useful",
                    "reasoning_styles_used: Quick Scan",
                ],
            }
        },
        "quality_gates": [
            "Quick-Scan Card appears first.",
            "Critical Integrity Snapshot appears after top bias findings and does not use letter grades or percentages.",
            "The quick output includes Plain-Language Read and Before Using This Text.",
            "Any follow-up activity stays compact and does not become a full workshop plan.",
            "No full multi-agent stage scaffold is rendered or executed in quick depth.",
            "Raw MCP JSON is not exposed.",
        ],
    }


def define_audit_agents_payload(
    repo: Repository,
    subject: str,
    text_type: str | None = None,
    domain_hint: str | None = None,
    sensitivity: str | None = None,
    synthesis_audience: str | None = None,
    candidate_model_pool: list[dict[str, Any]] | None = None,
    depth: str | None = None,
    scaffold_detail: str | None = None,
    retrieval_profile: str | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    ranked, context = advanced_ranked_flows(repo, subject, domain_hint, sensitivity, text_type=text_type, retrieval_profile=retrieval_profile, limit=500)
    context["synthesis_audience"] = normalize_synthesis_audience(synthesis_audience)
    if candidate_model_pool is None:
        pool_limit = 8
        candidate_model_pool, low_relevance_examples = advanced_candidate_model_pool(ranked, context, subject, limit=pool_limit)
    else:
        low_relevance_examples = []
    return audit_stage_scaffold(
        tool="define_audit_agents",
        stage="agent_definition",
        title="Define analyst agents",
        host_ai_directive=(
            "Define four distinct analyst personas before analyzing the subject. Write them as panelists, not generic roles. "
            "Use candidate_model_pool as optional verified source material, attach a framework only when it clearly fits, "
            "and use framework_attachment: null when the persona is stronger than any available model."
        ),
        required_inputs=["subject", "text_type", "candidate_model_pool"],
        recommended_mcp_calls=[
            {
                "tool": "get_reasoning_flow",
                "when": "Optional: call only if a candidate framework needs full flow detail before attachment.",
                "arguments": {"entry_id_or_flow_id": "<candidate flow_id or entry_id>"},
            }
        ],
        output_schema={
            "agent_roster": [
                {
                    "agent_id": "agent_1",
                    "role_contract_id": "agent_1",
                    "name": "string",
                    "epistemic_archetype": "string",
                    "primary_reasoning_style": AUDIT_REASONING_STYLES,
                    "secondary_reasoning_style": AUDIT_REASONING_STYLES,
                    "tool_affinity": ["2-3 preferred tools"],
                    "characteristic_blind_spot": "string",
                    "assigned_cis_dimensions_to_watch": [label for _, label in SNAPSHOT_DIMENSIONS],
                }
            ],
            "agents": [
                {
                    "agent_id": "agent_1",
                    "role_contract_id": "agent_1",
                    "name": "string",
                    "epistemic_archetype": "string",
                    "reasoning_philosophy": "4-6 sentence persona introduction tuned to the text type",
                    "primary_reasoning_style": AUDIT_REASONING_STYLES,
                    "secondary_reasoning_style": AUDIT_REASONING_STYLES,
                    "reasoning_style_note": "Agents are not locked to one style; they may shift styles when the text demands it.",
                    "tool_affinity": ["2-3 preferred tools, e.g. lookup_bias, challenge_claim, get_framework, get_reasoning_flow"],
                    "decision_making_voice": "evidence | pattern | absence | harm | constraints | possibility",
                    "characteristic_blind_spot": "string",
                    "assigned_cis_dimensions_to_watch": [label for _, label in SNAPSHOT_DIMENSIONS],
                    "framework_attachment": "candidate flow object or null",
                    "attachment_rationale": "string",
                }
            ]
        },
        quality_gates=[
            "Exactly four agents are defined.",
            "Each agent maps to exactly one role_contract_id from role_contracts before analysis begins.",
            "Each agent definition is 4 to 6 sentences and reads like a panelist introduction.",
            "Each agent has a primary and secondary reasoning style from the allowed list.",
            "Each agent has 2 to 3 tool affinities.",
            "Each agent has a characteristic blind spot.",
            "Return agent_roster before independent analyses; it must include each agent's assigned CIS dimensions to watch.",
            "For governance, policy, advocacy, community, equity, stakeholder, or harm text, one agent is Missing Voice or Absent Stakeholder.",
            "No low-relevance framework is attached.",
            "Persona-only agents use framework_attachment: null with a one-sentence reason.",
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "subject_summary": context.get("subject_summary"),
            "depth": depth_value,
            "input_parameters": advanced_input_parameters(subject, context, depth=depth_value),
            "text_type": context.get("text_type"),
            "text_type_source": context.get("text_type_source"),
            "synthesis_audience": context.get("synthesis_audience"),
            "allowed_reasoning_styles": AUDIT_REASONING_STYLES,
            "three_cs_labels": AUDIT_THREE_CS,
            "tool_affinity_examples": [
                {"agent_style": "Socratic", "tools": ["challenge_claim", "get_reasoning_flow"]},
                {"agent_style": "Systems Thinking", "tools": ["get_framework('systems thinking')", "search_knowledge_base"]},
                {"agent_style": "Missing Voice", "tools": ["get_framework('cross-cultural')", "lookup_bias"]},
                {"agent_style": "Structuralist", "tools": ["lookup_bias", "audit_text", "get_entry"]},
            ],
            "candidate_model_pool": candidate_model_pool,
            "low_relevance_model_examples": low_relevance_examples,
            "retrieval_profile": context.get("retrieval_profile"),
            "role_contracts": agentic_role_contracts(),
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(depth_value),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="agent_definition", next_tool="define_audit_agents"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
            "research_methodology_hits": research_methodology_profile_hits(repo, subject) if context.get("retrieval_profile") == "research_methodology" else None,
            "agent_design_protocol": advanced_agent_design_protocol(subject, context),
            "framework_attachment_rules": advanced_framework_attachment_rules(),
            "input_warnings": audit_input_warnings(subject=subject),
        },
    )


def run_independent_audit_analysis_payload(
    subject: str,
    agents: list[dict[str, Any]],
    text_type: str | None = None,
    sensitivity: str | None = None,
    depth: str | None = None,
    scaffold_detail: str | None = None,
    retrieval_profile: str | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    resolved_profile = resolve_retrieval_profile(subject, text_type=text_type, retrieval_profile=retrieval_profile)
    return audit_stage_scaffold(
        tool="run_independent_audit_analysis",
        stage="independent_analysis",
        title="Run independent agent analyses",
        host_ai_directive=(
            "For each agent, write in first person from that agent's epistemic position. Do not describe what the agent would do; be the agent doing it. "
            "Execute opening reaction, reasoning chain, bias identification, claim challenge, alternative frame, and closing question in order. "
            "Use the recommended MCP calls while executing the stage and render only concise visible reasoning, not hidden chain-of-thought."
        ),
        required_inputs=["subject", "agents"],
        recommended_mcp_calls=[
            {
                "tool": "lookup_bias",
                "when": "Call before citing any bias in MCP-Enhanced Mode to verify definition, KB ID, and confidence_weight.",
                "arguments": {"name": "<bias name>"},
            },
            {
                "tool": "search_knowledge_base",
                "when": "Call when the bias name is uncertain but the pattern is visible.",
                "arguments": {"query": "<description of the observed reasoning risk>", "category": "biases", "limit": 5, "retrieval_profile": resolved_profile},
            },
            {
                "tool": "challenge_claim",
                "when": "Call at least once per agent for an exact sentence the text treats as settled.",
                "arguments": {"claim": "<exact sentence from subject text>"},
            },
            {
                "tool": "get_framework",
                "when": "Call for an alternative frame that fits the agent's reasoning style.",
                "arguments": {"thinking_lens": "<lens name>"},
            },
            {
                "tool": "get_pattern",
                "when": "Use as a compatibility alias when get_framework is not the natural tool name.",
                "arguments": {"thinking_lens": "<lens name>"},
            },
            {
                "tool": "list_reasoning_flows",
                "when": "Optional: browse available executable flows when an agent's reasoning style may match a flow.",
                "arguments": {"namespace": "epistemic_core", "limit": 100},
            },
            {
                "tool": "get_reasoning_flow",
                "when": "Optional: load and execute an available flow when it clearly fits the agent's style and the subject.",
                "arguments": {"entry_id_or_flow_id": "<flow ID or slug>"},
            },
        ],
        output_schema={
            "mode_header": "MCP-Enhanced Mode or Reference Mode",
            "analyses": [
                {
                    "agent_id": "agent_1",
                    "agent_name": "string",
                    "sharpest_reaction": "one sentence grounded in the subject text",
                    "reasoning_style_used": "primary or secondary reasoning style",
                    "opening_reaction": "one sentence, no hedging",
                    "reasoning_chain": {
                        "style": "Chain of Thought | Tree of Thought | Socratic | Systems Thinking | Steelman-first | Missing Voice",
                        "visible_reasoning": "Show concise visible reasoning from a specific claim or structural feature.",
                    },
                    "bias_findings": [
                        {
                            "bias_name": "string",
                            "kb_id": "string|null",
                            "confidence_weight": "low|medium|high|null",
                            "three_cs_lens": AUDIT_THREE_CS,
                            "text_evidence": "quote or tight paraphrase",
                            "why_it_matters": "string",
                        }
                    ],
                    "challenged_claim": {
                        "claim": "string",
                        "steelman": "string",
                        "fallacy_risk": {"name": "string", "kb_id": "string|null"},
                        "steelman_risk": "When this pattern is NOT a fallacy.",
                        "probing_questions": ["string"],
                    },
                    "alternative_frame": {"lens_name": "string", "kb_id": "string|null", "application_to_text": "40 words or fewer", "three_cs_lens": "Creative"},
                    "reasoning_flow_used": {"flow_id": "string|null", "why_used_or_skipped": "string"},
                    "critical_integrity_snapshot_evidence": {
                        "dimension": "Grounding & Scope Fit | Assumptions & Context | Bias Transparency | Framing & Audience Openness | Positionality & Power",
                        "could_change_snapshot": "true|false",
                        "evidence": "quote or tight paraphrase from the subject text",
                    },
                    "snapshot_dimension_evidence": [
                        {
                            "dimension": "Grounding & Scope Fit | Assumptions & Context | Bias Transparency | Framing & Audience Openness | Positionality & Power",
                            "evidence": "quote or tight paraphrase from the subject text",
                            "likely_effect": "raises_score | lowers_score | changes_confidence | changes_comparability | supports_profile_only | none",
                        }
                    ],
                    "blind_spot_underweighted": "string",
                    "room_question": "string",
                }
            ],
        },
        quality_gates=[
            "There is one analysis per defined agent.",
            "Each analysis follows the order: opening reaction, reasoning chain, bias identification, claim challenge, alternative frame, closing question.",
            "Each analysis is first person and references actual subject-text language.",
            "Each analysis is 5 to 8 sentences unless the host AI needs a compact schema rendering.",
            "Each analysis names at least one bias or structural assumption.",
            "lookup_bias is called before citing any bias in MCP-Enhanced Mode; search_knowledge_base is used first when uncertain.",
            "Each bias finding has one Three Cs label: Critical, Compassionate, or Creative.",
            "Each agent challenges one exact settled sentence using challenge_claim in MCP-Enhanced Mode.",
            "Every fallacy risk includes Steelman Risk: when the pattern is not a fallacy.",
            "get_framework or get_pattern is called for at least one lens per agent in MCP-Enhanced Mode.",
            "list_reasoning_flows and get_reasoning_flow are used when an agent style clearly matches an available executable flow.",
            "Each agent surfaces at least one finding that maps to a Critical Integrity Snapshot dimension.",
            "Each agent closes by naming what the persona may be underweighting and one question for the room.",
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "text_type": normalize_text_type(text_type) or text_type or "general",
            "sensitivity": sensitivity or "auto",
            "depth": depth_value,
            "retrieval_profile": resolved_profile,
            "research_methodology_priority": (
                "For research-methodology profile, check demand characteristics, sampling/WEIRD bias, social desirability, construct/external validity, p-hacking/HARKing, and replication readiness before generic cognitive biases."
                if resolved_profile == "research_methodology"
                else None
            ),
            "agents": agents,
            "role_contracts": agentic_role_contracts(),
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(depth_value),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="independent_analysis", next_tool="run_independent_audit_analysis"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
            "execution_sequence": [
                "Opening reaction",
                "Reasoning chain",
                "Bias identification",
                "Claim challenge",
                "Alternative frame",
                "Closing question",
            ],
            "reasoning_style_examples": {
                "Chain of Thought": "The author claims X. For that to hold, Y must be true. Y requires Z. Z is not established because...",
                "Tree of Thought": "If X is true, A follows. If X is false, B follows. The text forecloses B by...",
                "Socratic": "The text assumes readers will not ask X. That question matters because...",
                "Systems Thinking": "This claim is downstream of X. The real intervention point is...",
                "Steelman-first": "The strongest version of this claim is X. It still fails or narrows at Y.",
                "Missing Voice": "The absent stakeholder is X. If they were in the room, they would challenge Y.",
            },
            "tool_inventory_check": {
                "required_before_execution": True,
                "probe_call": {"tool": "lookup_bias", "arguments": {"name": "confirmation bias"}},
            },
            "input_warnings": audit_input_warnings(subject=subject, agents=agents),
        },
    )


def map_audit_tensions_payload(
    analyses: list[dict[str, Any]],
    subject: str | None = None,
    scaffold_detail: str | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return audit_stage_scaffold(
        tool="map_audit_tensions",
        stage="tension_map",
        title="Map live disagreements",
        host_ai_directive=(
            "Review the completed independent analyses before debate. Do not summarize them. Identify contradictions, frame collapses, "
            "and evidence gaps that would change the verdict."
        ),
        required_inputs=["analyses"],
        recommended_mcp_calls=[
            {
                "tool": "lookup_bias",
                "when": "Optional: call if two agents use the same bias term differently or a definition conflict affects the tension.",
                "arguments": {"name": "<bias name>"},
            }
        ],
        output_schema={
            "tensions": [
                {
                    "tension_id": "tension_1",
                    "agent_a": "string",
                    "agent_b": "string",
                    "label": ["RESOLVABLE", "UNRESOLVABLE", "NEEDS_EVIDENCE", "FRAME_COLLAPSE"],
                    "label_aliases": {"NEEDS EVIDENCE": "NEEDS_EVIDENCE"},
                    "exact_disagreement": "one sentence",
                    "text_anchor": "quote or tight paraphrase from subject text or analyses",
                    "why_it_matters": "string",
                    "evidence_needed": "string|null",
                    "snapshot_effect": "none | could_change_label | could_trigger_profile_only | could_change_confidence | could_change_comparability",
                    "snapshot_impact": {
                        "could_change_label": "true|false",
                        "could_trigger_profile_only": "true|false",
                        "could_change_confidence": "true|false",
                        "could_change_comparability": "true|false",
                        "reason": "one sentence naming which CIS dimension or context-lens signal is affected",
                    },
                }
            ]
        },
        quality_gates=[
            "Return 3 to 5 tensions unless fewer than three genuine tensions exist.",
            "Each tension names two agents by name, not only by role.",
            "Each tension has one of the allowed labels; normalize NEEDS EVIDENCE to NEEDS_EVIDENCE.",
            "FRAME_COLLAPSE is used when one agent's finding invalidates another agent's framing.",
            "Flag any tension that could change the Critical Integrity Snapshot label, confidence, comparability, or profile-only state.",
            "Do not stage debate in this stage.",
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "analyses": analyses,
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="tension_map", next_tool="map_audit_tensions"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
            "input_warnings": audit_input_warnings(analyses=analyses),
        },
    )


def run_audit_debate_payload(
    subject: str,
    agents: list[dict[str, Any]],
    analyses: list[dict[str, Any]],
    tensions: list[dict[str, Any]],
    scaffold_detail: str | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return audit_stage_scaffold(
        tool="run_audit_debate",
        stage="debate",
        title="Stage the structured debate",
        host_ai_directive=(
            "Select the sharpest RESOLVABLE tension and stage a direct three-turn exchange. Let the agents clash when the text warrants it; "
            "do not simulate politeness or generic methodological positioning. Each agent must argue from its Step 2 reasoning style."
        ),
        required_inputs=["subject", "agents", "analyses", "tensions"],
        recommended_mcp_calls=[
            {
                "tool": "challenge_claim",
                "when": "Call if the debate surfaces a new claim that neither agent challenged in independent analysis.",
                "arguments": {"claim": "<specific debated claim from subject text>"},
            },
            {
                "tool": "lookup_bias",
                "when": "Call if a new bias or fallacy risk emerges during the exchange.",
                "arguments": {"name": "<bias or fallacy name>"},
            },
        ],
        output_schema={
            "selected_tension": {
                "tension_id": "string",
                "why_selected": "string",
                "label": "RESOLVABLE",
            },
            "debate_exchange": [
                {"speaker": "Agent X", "turn": 1, "content": "Direct challenge referencing the subject text."},
                {"speaker": "Agent Y", "turn": 2, "content": "Defense or concession grounded in the subject text and the agent's reasoning style."},
                {"speaker": "Agent X", "turn": 3, "content": "Final volley: update position or hold with clearer stakes."},
            ],
            "fallback_if_no_resolvable_tension": "Agents converge on [X]; unresolved tension is [Y].",
        },
        quality_gates=[
            "Use exactly one selected tension unless no resolvable tension exists.",
            "The exchange has three turns.",
            "At least two of the three turns quote or tightly reference actual subject-text language.",
            "Each agent argues from its Step 2 reasoning style and decision-making voice.",
            "New biases or fallacy risks surfaced mid-debate trigger lookup_bias or challenge_claim inline.",
            "The debate does not introduce claims unsupported by the subject text or prior analyses.",
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "agents": agents,
            "analyses": analyses,
            "tensions": tensions,
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="debate", next_tool="run_audit_debate"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
            "input_warnings": audit_input_warnings(subject=subject, agents=agents, analyses=analyses, tensions=tensions),
        },
    )


def synthesize_audit_verdict_payload(
    subject: str,
    agents: list[dict[str, Any]],
    analyses: list[dict[str, Any]],
    tensions: list[dict[str, Any]],
    debate: dict[str, Any],
    text_type: str | None = None,
    synthesis_audience: str | None = "both",
    biases_found: list[str] | None = None,
    depth: str | None = None,
    snapshot_mode: str | None = None,
    scaffold_detail: str | None = None,
    human_loop_mode: str | None = None,
    human_loop_state: dict[str, Any] | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    depth_value = normalize_audit_depth(depth)
    snapshot_mode_value = normalize_snapshot_mode(snapshot_mode)
    audience = normalize_synthesis_audience(synthesis_audience)
    resolved_text_type = normalize_text_type(text_type) or text_type or "general"
    source_completeness, _, _ = human_loop_source_completeness(subject, is_vague_or_short(subject))
    preview_before_reflection = human_loop_reflection_preview(subject)
    synthesis_human_loop_stage = (
        "mode_consent"
        if human_loop_mode_consent_required(human_loop_mode, human_loop_state_input(human_loop_state))
        else "reflection"
    )
    human_loop = build_human_loop(
        stage=synthesis_human_loop_stage,
        human_loop_mode=human_loop_mode,
        human_loop_state=human_loop_state,
        text_type=resolved_text_type,
        text_type_source="explicit" if normalize_text_type(text_type) else "inferred",
        domain=resolved_text_type,
        sensitivity="high" if text_has_any(subject.lower(), ["health", "medical", "policy", "election", "identity"]) else "low",
        depth=depth_value,
        snapshot_mode=snapshot_mode_value,
        retrieval_profile=resolve_retrieval_profile(subject, text_type=resolved_text_type),
        source_completeness=source_completeness,
        silent_parse=human_loop_silent_parse(subject),
        preview_before_reflection=preview_before_reflection,
    )
    audience_guidance = {
        "reader": "Evaluate whether and how much the reader should trust the text.",
        "author": "State the most concrete improvement the author should make.",
        "both": "Give one trust verdict for the reader and one author-facing mitigation.",
    }[audience]
    output_schema: dict[str, Any] = {
        "quick_scan_card_revision": {
            "revise_prepopulated_card": "true|false",
            "reason": "string",
            "final_card": {
                "mode": "MCP-Enhanced Mode or Reference Mode",
                "text_type": "string",
                "sensitivity": "string",
                "top_3_biases": ["[KB ID] name - one-line justification [Three Cs label]"],
                "critical_integrity_snapshot": {
                    "decision": "confirm_prepopulated | revise | withhold_aggregate",
                    "display_state": "scored | profile_only",
                    "label": "Exemplary Integrity | Strong Integrity | Moderate Integrity | Limited Integrity | Needs Scrutiny | null",
                    "points": "integer|null; never render as percentage",
                    "score_confidence": "very_low | low | medium | high | very_high",
                    "comparability": "strong | qualified | limited | not_comparable",
                    "display_policy": {
                        "points_prominence": "primary | secondary | suppressed",
                        "profile_first": "true|false",
                        "comparability_warning": "string|null",
                        "rendering_rule": "string",
                    },
                    "snapshot_mode": snapshot_mode_value,
                    "context_lens": {
                        "evidence_convention": "citation_based | experiential_testimony | institutional_reporting | communal_consensus | hybrid | unclear",
                        "purpose": "inform | persuade | mobilize | document | narrate | mixed",
                        "voice": "first_person | collective | institutional | mixed | unclear",
                    },
                    "dimensions": [
                        {
                            "name": "Grounding & Scope Fit | Assumptions & Context | Bias Transparency | Framing & Audience Openness | Positionality & Power",
                            "points": "0-20",
                            "trace": ["concrete prior-stage finding references"],
                        }
                    ],
                    "before_using_this_text": "Must start exactly with: Before using this text,",
                    "withheld_reason": "string|null",
                },
                "cis_revision_trace": [
                    {
                        "from": "prepopulated snapshot label/confidence/profile state",
                        "to": "final snapshot label/confidence/profile state",
                        "reason": "traceable reason from analyses, tensions, or debate",
                    }
                ],
                "agent_roster": [
                    {
                        "agent_name": "string",
                        "epistemic_archetype": "string",
                        "primary_reasoning_style": "string",
                        "secondary_reasoning_style": "string",
                        "characteristic_blind_spot": "string",
                    }
                ],
                "agent_contribution_matrix": [
                    {
                        "agent_name": "string",
                        "strongest_contribution": "string",
                        "challenged_claim_or_bias": "string",
                        "cis_dimension_affected": "Grounding & Scope Fit | Assumptions & Context | Bias Transparency | Framing & Audience Openness | Positionality & Power",
                        "blind_spot": "string",
                        "changed_final_verdict": "true|false",
                    }
                ],
                "primary_tension": "string",
                "verdict": "string",
                "recommended_action": "string",
                "reasoning_styles_used": ["string"],
            },
        },
        "reflection": {
            "preview_before_reflection": {
                "likely_strongest_point": "string",
                "likely_weakest_point": "string",
                "biggest_missing_piece": "string",
                "render_rule": "Show these three bullets before asking reflection prompts; do not show an integrity score here.",
            },
            "reflection_prompts_collected_before_final_output": "true|false",
            "selected_option_bank": "decision_report | learning_coaching",
        },
        "post_audit_reflection": {
            "findings_frozen_before_reflection": "true",
            "human_auditor_commentary": {
                "include_in_report": "true|false",
                "user_role": "author | reviewer | reader | decision_maker | skeptic | unknown",
                "commentary_text": "Human reflection, disagreement, context note, or report note.",
                "collected_after_stage": "findings_frozen",
                "collected_at": "ISO timestamp",
                "ai_response_to_commentary": "Brief response that preserves the frozen findings unless new evidence triggers rerun.",
                "commentary_bucket": "commentary",
            },
            "divergence_map": {
                "items": [
                    {
                        "topic": "string",
                        "type": "interpretive | evidentiary | scope/framing",
                        "ai_audit_position": "string",
                        "human_auditor_position": "string",
                        "resolution": "Keep finding | mark stale and rerun | label as interpretive disagreement",
                    }
                ],
                "render_rule": "Render only when there is real disagreement, rerun history, or deep mode asks for it.",
            },
            "learning_notes": ["Optional short explainer tied to a flagged reasoning pattern."],
            "provenance_footer": {
                "ai_findings_finalized_at": "ISO timestamp",
                "human_commentary_added_at": "ISO timestamp|null",
                "audit_version": "integer",
                "findings_rerun": "true|false",
                "payload_hash": "filled by generate_audit_report after rendering",
            },
        },
        "synthesis": {
            "primary_bias_or_structural_problem": {"name": "string", "kb_id": "string required in MCP-Enhanced Mode", "three_cs_lens": AUDIT_THREE_CS},
            "single_verdict": "4-6 sentence paragraph",
            "most_influential_agent": "string",
            "strongest_counterargument": "string",
            "dissent_ledger": [
                {
                    "agent_name": "string",
                    "top_finding": "one sentence",
                    "strongest_disagreement": "one sentence",
                    "confidence": "low | medium | high",
                    "what_would_change_mind": "one sentence naming evidence or perspective",
                    "provenance": {"stage": "synthesis", "source": "agents|analyses|tensions|debate"},
                }
            ],
            "reasoning_traps": [
                {
                    "label": "advisory risk label",
                    "risk": "what could go wrong in reasoning",
                    "next_check": "concrete non-scolding check",
                }
            ],
            "mitigation": "string",
            "next_steps_for_deeper_thinking": ["numbered steps from suggest_next_steps, 25 words or fewer each"],
            "follow_up_activity": "Use one compact try_this_next idea for quick/chat output; for full/advanced reports, include one solo and one group activity from the local teaching pack.",
            "replication_readiness": "Required for research/study text; otherwise null or not_applicable.",
            "synthesis_audience": audience,
        },
        "report_ready_materials": {
            "purpose": "Canonical content package for generate_audit_report. Fill this before calling the PDF tool.",
            "audit_data": report_payload_template(include_advanced=True),
            "markdown_checkpoint": report_markdown_checkpoint_template(include_advanced=True),
            "pre_call_checklist": [
                "plain_language_read is present and written for a non-expert",
                "before_using_this_text starts exactly with 'Before using this text,'",
                "follow_up_activity includes try_this_next; full/advanced reports include solo_activity and group_activity",
                "all five dimensions have points/max_points, rationale, trace, and improvement_prompt",
                "biases uses the canonical key biases, not top_biases",
                "key_tension is a single sentence, not only a tensions array",
                "recommended_next_step is one concrete action",
                "assumptions, alternative_frames, probing_questions, follow_up_questions, and next_steps are populated",
                "argument_map and checkworthy_claims are passed through when the audit produced them",
                "dissent_ledger preserves agent disagreement instead of flattening it into consensus",
                "advanced_audit.agents[].top_finding is populated for each agent",
            ],
        },
    }
    if depth_value == "deep":
        output_schema["mitigation_rewrite"] = {
            "original_sentence": "Most problematic sentence from subject text.",
            "rewritten_sentence": "Bias-mitigating rewrite that preserves the author's core intent.",
            "why_this_reduces_bias": "one sentence",
        }
    return audit_stage_scaffold(
        tool="synthesize_audit_verdict",
        stage="synthesis",
        title="Synthesize verdict and next steps",
        host_ai_directive=(
            "Synthesize the prior stages into one verdict. Do not relist every finding. Commit to the primary bias or structural problem, "
            "acknowledge the strongest counterargument, and give one concrete mitigation. In deep mode, add Step 6b with one sentence rewrite. "
            "Before final PDF, Markdown, chat, save, or report output, clear any pending mode_consent or reflection prompt using native question UI when available. "
            "Show preview_before_reflection before reflection prompts, ask only the current questions_for_user block, and never ask the full Human Loop questionnaire at once. "
            "If a PDF report was requested, compile report_ready_materials with canonical field names and a Markdown checkpoint before calling generate_audit_report."
        ),
        required_inputs=["subject", "agents", "analyses", "tensions", "debate"],
        recommended_mcp_calls=[
            {
                "tool": "suggest_next_steps",
                "when": "Call after extracting the surfaced biases. biases_found must be a JSON array of bias names or IDs.",
                "arguments": {"domain": text_type or "general", "biases_found": biases_found or ["<bias name or ID>"]},
            },
            {
                "tool": "generate_audit_report",
                "when": "Optional: call after synthesis only if report output was requested and all report-critical sections are compiled. The MCP blocks incomplete full reports before Markdown/PDF rendering unless allow_placeholders=true is explicitly requested.",
                "arguments": {
                    "audit_data": "<report_ready_materials.audit_data using canonical keys only>",
                    "report_audience": synthesis_audience or "general",
                    "report_depth": depth_value,
                    "allow_placeholders": False,
                },
            }
        ],
        output_schema=output_schema,
        quality_gates=[
            "The synthesis commits to one verdict and does not end with `it depends`.",
            "The primary bias or structural problem includes a KB ID in MCP-Enhanced Mode.",
            "The audience guidance is honored.",
            "The strongest counterargument is stated before the mitigation.",
            "suggest_next_steps is called in MCP-Enhanced Mode with biases_found as a JSON array of bias names or IDs.",
            "Next Steps for Deeper Thinking are numbered and 25 words or fewer each.",
            "Every fallacy risk used in the verdict has a Steelman Risk from the prior analyses.",
            "The synthesis includes a dissent ledger: each agent states top finding, strongest disagreement, confidence, and what would change its mind.",
            "Reasoning trap checks, if present, are framed as advisory risks and next checks, not claims that the text is false.",
            "The Critical Integrity Snapshot is confirmed, revised, or withheld with traceable reasons.",
            "No letter grade, percentage, or bare 1-5 scale appears in the snapshot.",
            "Snapshot confidence and comparability remain separate from points.",
            "If aggregate scoring is not defensible, the snapshot uses profile_only and suppresses label and points.",
            "Every snapshot dimension traces to concrete findings.",
            "The final output includes an agent_roster and agent_contribution_matrix naming each agent's contribution, blind spot, affected CIS dimension, and whether they changed the verdict.",
            "Post-audit human reflection is collected only after findings are frozen.",
            "Human commentary is labeled and never silently merged into AI findings.",
            "New verified evidence marks affected sections stale and triggers rerun/version increment before findings change.",
            "The snapshot uses Bias Transparency, not raw bias count, and Framing & Audience Openness, not Framing Fairness.",
            "The snapshot prompt starts exactly with `Before using this text,`.",
            "Every audit-facing final output includes Plain-Language Read and a Before Using This Text sentence starting exactly with `Before using this text,`.",
            "Full/advanced report-ready output includes one solo and one group follow-up activity from the local teaching pack.",
            "The Quick-Scan Card appears before the full analysis in final rendering.",
            "If report output was requested, report_ready_materials is completed with canonical keys before generate_audit_report is called.",
            "For full report output, a Markdown checkpoint is written and checked before calling generate_audit_report unless the caller explicitly requested a noninteractive smoke test.",
            "Raw MCP JSON is not exposed in the final answer.",
            *(
                ["Depth is deep, so Step 6b includes one mitigation rewrite for the most problematic sentence."]
                if depth_value == "deep"
                else []
            ),
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "text_type": resolved_text_type,
            "depth": depth_value,
            "synthesis_audience": audience,
            "audience_guidance": audience_guidance,
            "biases_found": biases_found or [],
            "preview_before_reflection": preview_before_reflection,
            "human_loop": human_loop,
            "human_loop_host_action": human_loop_host_action(human_loop),
            "snapshot_mode": snapshot_mode_value,
            "snapshot_revision_rules": [
                "Confirm the prepopulated Critical Integrity Snapshot if full analysis supports it.",
                "Revise the snapshot only with traceable reasons from agent analyses, tensions, or debate.",
                "Withhold the aggregate and return profile_only when confidence, context, or comparability is too weak.",
            ],
            "optional_report_generation": {
                "report_generation_is_optional": True,
                "call_after_synthesis_only": "generate_audit_report",
                "report_tool_contract": "Pass report_ready_materials.audit_data only, after all report sections are compiled with canonical field names. The MCP owns alias-aware normalization, strict readiness gating, deterministic Markdown, Jinja templates, WeasyPrint rendering, PyMuPDF QA, preview PNGs, manifest writing, local artifact viewer generation, and report metadata. Full reports require CIS, five dimensions, plain-language read, before-use text, key tension, recommended next step, bias rows, assumptions, alternative frames, at least three questions, at least three next steps, and agent top findings when advanced_audit is present. If qa_status='blocked', show missing_report_fields and what_to_resubmit, then ask for re-submission; do not present a PDF. Use allow_placeholders=true only for an explicitly requested draft placeholder report. If qa_status passes, present report_path, markdown_path, manifest_path, and viewer_path together.",
                "report_readiness_contract": report_readiness_contract(depth_value, stage="synthesize_audit_verdict", include_advanced=True),
                "canonical_payload_template": report_payload_template(include_advanced=True),
                "markdown_checkpoint_template": report_markdown_checkpoint_template(include_advanced=True),
                "after_report_generation": {
                    "tool": "save_audit_result",
                    "result_payload_additions": {
                        "report_id": "[generate_audit_report.report_id]",
                        "report_path": "[generate_audit_report.report_path]",
                        "template_version": "[generate_audit_report.template_version]",
                        "render_version": "[generate_audit_report.render_version]",
                        "payload_schema_version": "[generate_audit_report.payload_schema_version]",
                        "payload_hash": "[generate_audit_report.payload_hash]",
                        "markdown_path": "[generate_audit_report.markdown_path]",
                        "markdown_hash": "[generate_audit_report.markdown_hash]",
                        "manifest_path": "[generate_audit_report.manifest_path]",
                        "viewer_path": "[generate_audit_report.viewer_path]",
                        "ui_version": "[generate_audit_report.artifact_viewer.ui_version]",
                        "preflight_status": "[generate_audit_report.preflight_status]",
                        "schema_warnings": "[generate_audit_report.schema_warnings]",
                    },
                },
            },
            "report_readiness_contract": report_readiness_contract(depth_value, stage="synthesize_audit_verdict", include_advanced=True),
            "agents": agents,
            "analyses": analyses,
            "tensions": tensions,
            "debate": debate,
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(depth_value),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="synthesis", next_tool="synthesize_audit_verdict"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
            "input_warnings": audit_input_warnings(subject=subject, agents=agents, analyses=analyses, tensions=tensions, debate=debate),
        },
    )


def propose_mitigation_rewrite_payload(
    subject: str,
    verdict: dict[str, Any] | None = None,
    primary_bias: str | None = None,
    depth: str | None = "deep",
    scaffold_detail: str | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return audit_stage_scaffold(
        tool="propose_mitigation_rewrite",
        stage="mitigation_rewrite",
        title="Rewrite one problematic sentence",
        host_ai_directive=(
            "Use this only after synthesis in deep mode. Select the single most problematic sentence from the subject text, "
            "rewrite it to reduce the primary bias or structural problem, and preserve the author's core intent."
        ),
        required_inputs=["subject", "verdict_or_primary_bias"],
        recommended_mcp_calls=[
            {
                "tool": "lookup_bias",
                "when": "Call if the primary bias needs a final definition or KB ID before rewriting.",
                "arguments": {"name": primary_bias or "<primary bias name>"},
            }
        ],
        output_schema={
            "mitigation_rewrite": {
                "primary_bias_or_problem": primary_bias or "string",
                "original_sentence": "exact sentence from subject text",
                "rewritten_sentence": "bias-mitigating rewrite preserving core intent",
                "why_this_reduces_bias": "one sentence",
                "what_changed": ["scope", "certainty", "evidence", "voice", "positionality"],
            }
        },
        quality_gates=[
            "Rewrite exactly one sentence.",
            "Preserve the author's core intent.",
            "Reduce the named primary bias or structural problem.",
            "Do not add facts that were not in the subject text or prior analysis.",
            "Explain the mitigation in one sentence.",
        ],
        scaffold_detail=scaffold_detail,
        extra={
            "subject_text": subject,
            "depth": normalize_audit_depth(depth),
            "verdict": verdict or {},
            "primary_bias": primary_bias,
            "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
            "artifact_budget": agentic_artifact_budget(depth),
            "agentic_progress_state": agentic_progress_state(agentic_state=agentic_state, current_stage="mitigation_rewrite", next_tool="propose_mitigation_rewrite"),
            "agentic_revision_state": agentic_revision_state(agentic_state),
        },
    )


def advanced_stage_plan(depth: str | None = None) -> list[dict[str, Any]]:
    depth_value = normalize_audit_depth(depth)
    stages = [
        {
            "order": 1,
            "stage": "mode_detection",
            "stage_tool": "lookup_bias",
            "host_action": "Silently call lookup_bias('confirmation bias') and set MCP-Enhanced Mode or Reference Mode.",
            "passes_to_next": "mode_header",
        },
        {
            "order": 2,
            "stage": "agent_definition",
            "stage_tool": "define_audit_agents",
            "host_action": "Define four analyst personas and optional framework attachments.",
            "passes_to_next": "agents",
        },
        {
            "order": 3,
            "stage": "independent_analysis",
            "stage_tool": "run_independent_audit_analysis",
            "host_action": "Run one first-person analysis per agent, using MCP lookup tools while reasoning and surfacing CIS dimension evidence.",
            "passes_to_next": "analyses",
        },
        {
            "order": 4,
            "stage": "tension_map",
            "stage_tool": "map_audit_tensions",
            "host_action": "Map 3 to 5 live disagreements, evidence gaps, frame collapses, or snapshot-changing disputes.",
            "passes_to_next": "tensions",
        },
        {
            "order": 5,
            "stage": "debate",
            "stage_tool": "run_audit_debate",
            "host_action": "Stage one three-turn debate over the sharpest resolvable tension.",
            "passes_to_next": "debate",
        },
        {
            "order": 6,
            "stage": "synthesis",
            "stage_tool": "synthesize_audit_verdict",
            "host_action": "Commit to one verdict, confirm/revise/withhold the Critical Integrity Snapshot, revise the Quick-Scan Card if needed, and call suggest_next_steps.",
            "passes_to_next": "final rendered analysis",
        },
    ]
    if depth_value == "deep":
        stages.append(
            {
                "order": 7,
                "stage": "mitigation_rewrite",
                "stage_tool": "propose_mitigation_rewrite",
                "host_action": "Add Step 6b: rewrite the most problematic sentence to reduce the primary bias while preserving intent.",
                "passes_to_next": "final rendered analysis",
            }
        )
    return stages


def advanced_resume_contract() -> dict[str, Any]:
    return {
        "resume_from_values": sorted(AUDIT_RESUME_STAGES),
        "prior_stage_payload": "Pass the completed typed output from the prior stage or an object containing agents, analyses, tensions, debate, and biases_found as available.",
        "stateless_rule": "The MCP does not store stage state. The host AI must pass prior outputs back on resume.",
        "examples": [
            {"resume_from": "independent_analysis", "prior_stage_payload": {"agents": ["<completed agent cards>"]}},
            {"resume_from": "debate", "prior_stage_payload": {"agents": ["<agent cards>"], "analyses": ["<analysis entries>"], "tensions": ["<tension entries>"]}},
        ],
    }


def advanced_resume_stage_payload(
    repo: Repository,
    *,
    subject: str,
    resume_from: str,
    prior_stage_payload: dict[str, Any] | None,
    text_type: str | None,
    domain_hint: str | None,
    sensitivity: str | None,
    synthesis_audience: str | None,
    candidate_model_pool: list[dict[str, Any]] | None = None,
    depth: str | None = None,
    snapshot_mode: str | None = None,
    scaffold_detail: str | None = None,
    retrieval_profile: str | None = None,
    human_loop_mode: str | None = None,
    human_loop_state: dict[str, Any] | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    prior = coerce_payload_dict(prior_stage_payload)
    depth_value = normalize_audit_depth(depth)
    stage = normalize_audit_resume_stage(resume_from)
    if not stage:
        return {
            "tool": "advanced_audit",
            "status": "invalid_resume_stage",
            "resume_from": resume_from,
            "allowed_resume_from": sorted(AUDIT_RESUME_STAGES),
        }
    if stage == "agent_definition":
        payload = define_audit_agents_payload(
            repo,
            subject,
            text_type=text_type,
            domain_hint=domain_hint,
            sensitivity=sensitivity,
            synthesis_audience=synthesis_audience,
            candidate_model_pool=candidate_model_pool,
            depth=depth_value,
            scaffold_detail=scaffold_detail,
            retrieval_profile=retrieval_profile,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )
    elif stage == "independent_analysis":
        agents = extract_stage_list(prior, ["agents", "agent_definitions", "defined_agents"])
        payload = run_independent_audit_analysis_payload(
            subject,
            agents,
            text_type=text_type,
            sensitivity=sensitivity,
            depth=depth_value,
            scaffold_detail=scaffold_detail,
            retrieval_profile=retrieval_profile,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )
    elif stage == "tension_map":
        analyses = extract_stage_list(prior, ["analyses", "independent_analyses", "round_1_independent_analysis"])
        payload = map_audit_tensions_payload(analyses, subject=subject, scaffold_detail=scaffold_detail, host_capability_profile=host_capability_profile, agentic_state=agentic_state)
    elif stage == "debate":
        agents = extract_stage_list(prior, ["agents", "agent_definitions", "defined_agents"])
        analyses = extract_stage_list(prior, ["analyses", "independent_analyses", "round_1_independent_analysis"])
        tensions = extract_stage_list(prior, ["tensions", "tension_map"])
        payload = run_audit_debate_payload(subject, agents, analyses, tensions, scaffold_detail=scaffold_detail, host_capability_profile=host_capability_profile, agentic_state=agentic_state)
    else:
        agents = extract_stage_list(prior, ["agents", "agent_definitions", "defined_agents"])
        analyses = extract_stage_list(prior, ["analyses", "independent_analyses", "round_1_independent_analysis"])
        tensions = extract_stage_list(prior, ["tensions", "tension_map"])
        debate = coerce_payload_dict(prior.get("debate") or prior.get("debate_exchange") or prior.get("structured_debate"))
        biases = prior.get("biases_found") if isinstance(prior.get("biases_found"), list) else None
        payload = synthesize_audit_verdict_payload(
            subject,
            agents,
            analyses,
            tensions,
            debate,
            text_type=text_type,
            synthesis_audience=synthesis_audience,
            biases_found=biases,
            depth=depth_value,
            snapshot_mode=snapshot_mode,
            scaffold_detail=scaffold_detail,
            human_loop_mode=human_loop_mode,
            human_loop_state=human_loop_state,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )
    payload["resume_from"] = stage
    payload["depth"] = depth_value
    payload["resume_contract"] = advanced_resume_contract()
    payload.setdefault("report_readiness_contract", report_readiness_contract(depth_value, stage=f"advanced_audit_resume_{stage}", include_advanced=stage == "synthesis"))
    return payload


def advanced_selected_flow_scaffold(
    flow: dict[str, Any],
    subject: str,
    context: dict[str, Any],
    audit_snapshot: dict[str, Any] | None = None,
    score: float = 0.0,
) -> dict[str, Any]:
    return {
        "tool": "advanced_audit",
        "status": "scaffold_ready",
        "execution_required": True,
        "subject_text": subject,
        "subject_summary": context.get("subject_summary"),
        "text_type": context.get("text_type"),
        "text_type_source": context.get("text_type_source"),
        "synthesis_audience": context.get("synthesis_audience", "both"),
        "prepopulated_quick_scan_card": (audit_snapshot or {}).get("quick_scan_card"),
        "prepopulated_critical_integrity_snapshot": ((audit_snapshot or {}).get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
        "prepopulated_replication_readiness": (audit_snapshot or {}).get("replication_readiness"),
        "prepopulated_follow_up_activity": (audit_snapshot or {}).get("follow_up_activity"),
        "human_loop": (audit_snapshot or {}).get("human_loop"),
        "human_loop_host_action": human_loop_host_action((audit_snapshot or {}).get("human_loop")),
        "report_readiness_contract": report_readiness_contract(context.get("depth"), stage="advanced_audit_selected_flow", include_advanced=False),
        "selected_model": {
            "flow_id": flow.get("flow_id"),
            "entry_id": flow.get("entry_id"),
            "title": flow.get("entry_title"),
            "category": flow.get("category"),
            "subcategory": flow.get("subcategory"),
            "namespace": flow_namespace(flow),
            **advanced_flow_fit_metadata(score, flow, subject, context),
            "rationale": advanced_rationale(flow, context),
        },
        "host_ai_directive": (
            "The MCP selected and verified the reasoning protocol. The analysis has NOT been performed. "
            "Execute the flow against the subject text, fill each visible output, render the Quick-Scan Card first, "
            "and return the user's final analysis or artifact."
        ),
        "flow_scaffold": advanced_flow_execution(flow, subject, context),
        "limitations": ["MCP is the KB, selection, verification, and scaffold layer; the host AI is the reasoning and rendering layer."],
    }


def advanced_audit_payload(
    repo: Repository,
    subject: str,
    mode: str,
    selected_flow_id: str | None = None,
    domain_hint: str | None = None,
    sensitivity: str | None = None,
    text_type: str | None = None,
    synthesis_audience: str | None = None,
    max_candidate_models: int = 8,
    resume_from: str | None = None,
    prior_stage_payload: dict[str, Any] | None = None,
    depth: str | None = None,
    snapshot_mode: str | None = None,
    scaffold_detail: str | None = None,
    retrieval_profile: str | None = None,
    human_loop_mode: str | None = None,
    human_loop_state: dict[str, Any] | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    agentic_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    mode_name = advanced_mode(mode)
    depth_value = normalize_audit_depth(depth)
    snapshot_mode_value = normalize_snapshot_mode(snapshot_mode)
    scaffold_detail_value = normalize_scaffold_detail(scaffold_detail)
    if mode_name not in {"user_selected", "ai_selected", "agent"}:
        return {
            "tool": "advanced_audit",
            "mode": mode,
            "status": "invalid_mode",
            "allowed_modes": ["user_selected", "ai_selected", "agent"],
        }
    if not first_text(subject):
        return {
            "tool": "advanced_audit",
            "mode": mode_name,
            "status": "invalid_input",
            "message": "subject is required.",
        }
    if not repo.reasoning_flows:
        return {
            "tool": "advanced_audit",
            "mode": mode_name,
            "status": "no_viable_flow",
            "subject_summary": advanced_subject_summary(subject),
            "candidates": [],
            "related_without_flow": [],
            "limitations": ["No reasoning flow files are available for MVP execution."],
        }

    ranked, context = advanced_ranked_flows(repo, subject, domain_hint, sensitivity, text_type=text_type, retrieval_profile=retrieval_profile, limit=500)
    context["synthesis_audience"] = normalize_synthesis_audience(synthesis_audience)
    context["depth"] = depth_value
    context["snapshot_mode"] = snapshot_mode_value
    context["scaffold_detail"] = scaffold_detail_value
    overkill_warning = advanced_overkill_warning(subject, depth_value, context.get("text_type"))
    audit_snapshot = audit_text_payload(
        repo,
        subject,
        sensitivity=sensitivity,
        text_type=text_type,
        domain_hint=domain_hint,
        snapshot_mode=snapshot_mode_value,
        retrieval_profile=context.get("retrieval_profile"),
        depth=depth_value,
        human_loop_mode=human_loop_mode,
        human_loop_state=human_loop_state,
        defer_reflection=True,
    )
    if audit_snapshot.get("status") in {"human_loop_mode_consent_pending", "human_loop_onboarding_pending", "human_loop_judgment_pending"}:
        return {
            "tool": "advanced_audit",
            "mode": mode_name,
            "status": audit_snapshot.get("status"),
            "subject_summary": context["subject_summary"],
            "text_type": context.get("text_type"),
            "text_type_source": context.get("text_type_source"),
            "retrieval_profile": context.get("retrieval_profile"),
            "silent_parse": audit_snapshot.get("silent_parse"),
            "human_loop": audit_snapshot.get("human_loop"),
            "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
            "report_readiness_contract": report_readiness_contract(depth_value, stage=f"advanced_audit_{audit_snapshot.get('status')}", include_advanced=False),
            "limitations": ["Advanced audit scaffolding is withheld until the pending Human Loop gate is answered, skipped, or explicitly bypassed."],
        }
    if not ranked:
        return {
            "tool": "advanced_audit",
            "mode": mode_name,
            "status": "no_viable_flow",
            "subject_summary": context["subject_summary"],
            "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
            "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
            "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
            "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
            "human_loop": audit_snapshot.get("human_loop"),
            "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
            "report_readiness_contract": report_readiness_contract(depth_value, stage="advanced_audit_no_viable_flow", include_advanced=True),
            "candidates": [],
            "related_without_flow": advanced_related_without_flow(repo, context["query"]),
            "limitations": ["No flow-backed candidate matched the input."],
        }

    if mode_name == "agent" and depth_value == "quick" and not resume_from:
        return advanced_quick_scan_scaffold(subject, context, audit_snapshot, resume_from=resume_from)

    if resume_from:
        return {
            "tool": "advanced_audit",
            "mode": mode_name,
            **advanced_resume_stage_payload(
                repo,
                subject=subject,
                resume_from=resume_from,
                prior_stage_payload=prior_stage_payload,
                text_type=text_type,
                domain_hint=domain_hint,
                sensitivity=sensitivity,
                synthesis_audience=context.get("synthesis_audience"),
                depth=depth_value,
                snapshot_mode=snapshot_mode_value,
                scaffold_detail=scaffold_detail_value,
                retrieval_profile=context.get("retrieval_profile"),
                human_loop_mode=human_loop_mode,
                human_loop_state=human_loop_state,
                host_capability_profile=host_capability_profile,
                agentic_state=agentic_state,
            ),
        }

    if mode_name == "user_selected" and not selected_flow_id:
        candidates = advanced_select_diverse(ranked, count=4)
        return {
            "tool": "advanced_audit",
            "mode": "user_selected",
            "status": "selection_required",
            "subject_summary": context["subject_summary"],
            "text_type": context.get("text_type"),
            "text_type_source": context.get("text_type_source"),
            "synthesis_audience": context.get("synthesis_audience"),
            "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
            "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
            "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
            "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
            "human_loop": audit_snapshot.get("human_loop"),
            "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
            "report_readiness_contract": report_readiness_contract(depth_value, stage="advanced_audit_selection_required", include_advanced=False),
            "selection_prompt": "Choose one reasoning model to run.",
            "candidates": [
                advanced_candidate_payload(
                    flow,
                    index + 1,
                    advanced_rationale(flow, context),
                    score=score,
                    context=context,
                    subject=subject,
                )
                for index, (score, flow) in enumerate(candidates)
            ],
            "related_without_flow": advanced_related_without_flow(repo, context["query"]),
        }

    if mode_name == "user_selected":
        flow = repo._resolve_reasoning_flow(selected_flow_id or "")
        if not flow:
            return {
                "tool": "advanced_audit",
                "mode": "user_selected",
                "status": "no_viable_flow",
                "subject_summary": context["subject_summary"],
                "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
                "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
                "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
                "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
                "human_loop": audit_snapshot.get("human_loop"),
                "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
                "report_readiness_contract": report_readiness_contract(depth_value, stage="advanced_audit_selected_flow_missing", include_advanced=False),
                "message": "selected_flow_id did not resolve to an available reasoning flow.",
                "candidates": [
                    advanced_candidate_payload(
                        flow,
                        index + 1,
                        advanced_rationale(flow, context),
                        score=score,
                        context=context,
                        subject=subject,
                    )
                    for index, (score, flow) in enumerate(advanced_select_diverse(ranked, count=4))
                ],
            }
        score = next((candidate_score for candidate_score, candidate_flow in ranked if candidate_flow.get("flow_id") == flow.get("flow_id")), 0.0)
        payload = advanced_selected_flow_scaffold(flow, subject, context, audit_snapshot=audit_snapshot, score=score)
        payload["mode"] = "user_selected"
        return payload

    if mode_name == "ai_selected":
        score, flow = ranked[0]
        payload = advanced_selected_flow_scaffold(flow, subject, context, audit_snapshot=audit_snapshot, score=score)
        payload["mode"] = "ai_selected"
        return payload

    state = agentic_state if isinstance(agentic_state, dict) else {}
    if state.get("plan_declined"):
        return agentic_plan_declined_payload(subject, context, audit_snapshot, depth_value)
    plan_core = agentic_plan_core(subject=subject, context=context, depth=depth_value, host_capability_profile=host_capability_profile)
    expected_plan_hash = agentic_plan_hash(plan_core)
    approved_hash = first_text(state.get("approved_plan_hash"))
    if not state.get("plan_approved"):
        return agentic_plan_review_payload(
            subject=subject,
            context=context,
            depth=depth_value,
            host_capability_profile=host_capability_profile,
            agentic_state=state,
            audit_snapshot=audit_snapshot,
        )
    if approved_hash != expected_plan_hash:
        return agentic_plan_hash_mismatch_payload(expected_plan_hash, approved_hash)

    try:
        pool_limit = max(1, min(int(max_candidate_models or 8), 12))
    except (TypeError, ValueError):
        pool_limit = 8
    candidate_model_pool, low_relevance_examples = advanced_candidate_model_pool(
        ranked,
        context,
        subject,
        limit=pool_limit,
    )
    return {
        "tool": "advanced_audit",
        "mode": "agent",
        "status": "scaffold_ready",
        "execution_required": True,
        "depth": depth_value,
        "scaffold_detail": scaffold_detail_value,
        "subject_text": subject,
        "subject_summary": context.get("subject_summary"),
        "input_parameters": advanced_input_parameters(subject, context, depth=depth_value, resume_from=resume_from),
        "retrieval_profile": context.get("retrieval_profile"),
        "research_methodology_hits": research_methodology_profile_hits(repo, subject) if context.get("retrieval_profile") == "research_methodology" else None,
        "text_type": context.get("text_type"),
        "text_type_source": context.get("text_type_source"),
        "synthesis_audience": context.get("synthesis_audience"),
        "prepopulated_quick_scan_card": audit_snapshot.get("quick_scan_card"),
        "prepopulated_critical_integrity_snapshot": (audit_snapshot.get("quick_scan_card") or {}).get("critical_integrity_snapshot"),
        "prepopulated_replication_readiness": audit_snapshot.get("replication_readiness"),
        "prepopulated_follow_up_activity": audit_snapshot.get("follow_up_activity"),
        "human_loop": audit_snapshot.get("human_loop"),
        "human_loop_host_action": human_loop_host_action(audit_snapshot.get("human_loop")),
        "overkill_warning": overkill_warning,
        "candidate_model_pool": candidate_model_pool,
        "low_relevance_model_examples": low_relevance_examples,
        "tool_inventory_check": advanced_tool_inventory_check(repo),
        "stage_plan": advanced_stage_plan(depth_value),
        "resume_contract": advanced_resume_contract(),
        "report_readiness_contract": report_readiness_contract(depth_value, stage="advanced_audit_agent", include_advanced=True),
        "agent_execution_adapter": agent_execution_adapter(host_capability_profile),
        "role_contracts": agentic_role_contracts(),
        "artifact_budget": agentic_artifact_budget(depth_value),
        "agentic_progress_state": agentic_progress_state(agentic_state=state, current_stage="agent_definition", next_tool="define_audit_agents"),
        "agentic_revision_state": agentic_revision_state(state),
        "agentic_plan_hash": expected_plan_hash,
        "agentic_approval_required": False,
        "agent_design_protocol": advanced_agent_design_protocol(subject, context),
        "framework_attachment_rules": advanced_framework_attachment_rules(),
        "agent_instruction": advanced_agent_instruction(),
        "execution_protocol": advanced_agent_execution_protocol(context.get("synthesis_audience", "both"), depth=depth_value),
        "output_format": advanced_agent_output_format(depth=depth_value),
        "quality_gates": advanced_agent_quality_gates(depth=depth_value) if scaffold_detail_value == "full" else compact_quality_gates(advanced_agent_quality_gates(depth=depth_value), 8),
        "quality_gate_details": advanced_agent_quality_gates(depth=depth_value),
        "limitations": ["MCP retrieved models and persona-design rules only. The host AI must define the agents, attach only fitting frameworks, and perform all substantive analysis."],
    }


def methodology_lookup(repo: Repository, text: str) -> dict[str, Any] | None:
    return repo.methodology_check(text)


def ai_data_audit_language(text: str) -> dict[str, Any]:
    lowered = text.lower()
    risks: list[dict[str, Any]] = []
    for rule in AI_DATA_RISK_CUES:
        matched = [cue for cue in rule["cues"] if cue in lowered]
        if not matched:
            continue
        risks.append(
            {
                "risk": rule["risk"],
                "label": rule["label"],
                "visible_cue": matched[0],
                "why_it_matters": rule["why"],
                "next_check": rule["next_check"],
            }
        )
    if not risks:
        risks.append(
            {
                "risk": "source_coverage_gap",
                "label": "Source-coverage risk",
                "visible_cue": "ai_generated_text_type",
                "why_it_matters": "AI-mediated text can sound complete even when source coverage is unknown.",
                "next_check": "Ask which sources were used, which claims were not checked, and what evidence would change the summary.",
            }
        )
    return {
        "applies": True,
        "mode": "ai_data_audit_language",
        "risks": risks[:4],
        "no_retrieval_caution": "No retrieval was performed; these are visible risk cues and verification prompts, not fact-check results.",
        "host_rule": "Name AI/data risks as visible risks in the text, not as claims about hidden model internals.",
    }


def kb_no_result_recovery(query: str, *, kind: str | None = None, category: str | None = None) -> dict[str, Any]:
    normalized = normalize_text(query)
    matched_patterns: list[dict[str, Any]] = []
    for pattern in KB_NO_RESULT_RECOVERY_PATTERNS:
        if any(cue in normalized for cue in pattern["cues"]):
            matched_patterns.append(pattern)
    if not matched_patterns:
        matched_patterns = [
            {
                "topic": "general recovery",
                "try_narrower_queries": ["argument map", "source quality check", "framing effect", "confirmation bias"],
                "category_filters": ["biases", "thinking-lenses", "reasoning-frameworks", "methodology-checks"],
                "adjacent_concepts": ["assumptions", "alternative frames", "evidence gaps"],
            }
        ]
    narrower: list[str] = []
    filters: list[str] = []
    adjacent: list[str] = []
    topics: list[str] = []
    for pattern in matched_patterns:
        topics.append(pattern["topic"])
        narrower.extend(pattern.get("try_narrower_queries", []))
        filters.extend(pattern.get("category_filters", []))
        adjacent.extend(pattern.get("adjacent_concepts", []))
    return {
        "triggered": True,
        "reason": "No KB results matched this exact query and filter set.",
        "query": query,
        "original_filters": {"kind": kind, "category": category},
        "possible_topic_matches": join_unique(topics),
        "try_narrower_queries": join_unique(narrower)[:8],
        "try_category_filters": join_unique(filters),
        "adjacent_concepts": join_unique(adjacent)[:8],
        "host_rule": "No result means no result for this query, not proof that the concept is absent. Try narrower terms or a category filter before giving up.",
    }


def mitigation_strategy_from_bias(row: dict[str, Any]) -> dict[str, str]:
    title = first_text(row.get("title") or row.get("bias_name"))
    haystack = normalize_text(
        text_blob(
            title,
            row.get("summary"),
            row.get("definition"),
            row.get("impact"),
            row.get("mitigation"),
            row.get("aliases"),
        )
    )
    for rule in MITIGATION_VERB_RULES:
        if any(keyword in haystack for keyword in rule["keywords"]):
            return {
                "action_verb": rule["verb"],
                "strategy": rule["strategy"],
                "why": rule["why"],
            }
    mitigation = first_text(row.get("mitigation"))
    if mitigation:
        return {
            "action_verb": "revise",
            "strategy": short_phrase(mitigation, 18),
            "why": "The KB mitigation gives a concrete way to reduce this risk.",
        }
    return {
        "action_verb": "test",
        "strategy": "Name what would change the conclusion before relying on it.",
        "why": "A falsification check keeps the next step grounded in evidence.",
    }


_TEACHING_ACTIVITY_PACK_CACHE: dict[str, Any] | None = None

FALLBACK_TEACHING_ACTIVITIES: list[dict[str, Any]] = [
    {
        "id": "claim-support-question",
        "title": "Claim-Support-Question",
        "roles": ["internal_scaffold", "solo_follow_up", "group_follow_up"],
        "thinking_focus": ["critical"],
        "match_keywords": ["evidence", "citation", "source", "article", "research", "verify", "provenance", "claim"],
        "use_when": "The user needs to separate a claim from the support offered for it.",
        "why_this_fits": "It turns a vague concern into one claim, one support check, and one unresolved question.",
        "steps": [
            "Pick one load-bearing claim.",
            "Name the exact support shown.",
            "Ask the one source question still unresolved.",
        ],
        "content_focus": "Use the claim doing the most work in the text.",
        "source_note": "Fallback local teaching activity.",
    },
    {
        "id": "micro-lab-protocol",
        "title": "Micro Lab Protocol",
        "roles": ["group_follow_up"],
        "thinking_focus": ["critical", "compassionate"],
        "match_keywords": ["feedback", "audience", "review", "stakeholder", "public", "draft"],
        "use_when": "The text needs structured feedback from people who can notice audience, evidence, or framing risks.",
        "why_this_fits": "It keeps feedback specific and bounded instead of turning into general opinion-sharing.",
        "steps": [
            "Give reviewers one passage and one feedback question.",
            "Collect what confused, concerned, or persuaded them.",
            "Turn the feedback into one revision and one verification task.",
        ],
        "content_focus": "Use the passage most likely to affect trust, inclusion, or action.",
        "source_note": "Fallback local teaching activity.",
        "safety_note": "Use real consultation where lived experience matters; do not ask participants to impersonate affected groups.",
    },
]


def load_teaching_activity_pack() -> dict[str, Any]:
    global _TEACHING_ACTIVITY_PACK_CACHE
    if _TEACHING_ACTIVITY_PACK_CACHE is not None:
        return _TEACHING_ACTIVITY_PACK_CACHE
    try:
        with TEACHING_ACTIVITY_PACK_PATH.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            raise ValueError("activity pack root must be an object")
        activities = ensure_list(data.get("activities"))
        if not activities:
            raise ValueError("activity pack has no activities")
        _TEACHING_ACTIVITY_PACK_CACHE = data
    except Exception as exc:  # pragma: no cover - defensive fallback for broken local pack
        _TEACHING_ACTIVITY_PACK_CACHE = {
            "resource_id": "critical_compass.file_o_fun_teaching_activity_pack.fallback",
            "source_note": "Local fallback teaching pack used because the beta.8 activity pack could not be loaded.",
            "guardrails": [
                "Use activities to support auditing, not replace audit findings.",
                "Do not imply live Atlas lookup or live retrieval occurred.",
            ],
            "activities": FALLBACK_TEACHING_ACTIVITIES,
        }
    return _TEACHING_ACTIVITY_PACK_CACHE


def teaching_activity_candidates() -> list[dict[str, Any]]:
    pack = load_teaching_activity_pack()
    return [activity for activity in ensure_list(pack.get("activities")) if isinstance(activity, dict)]


def teaching_activity_pack_summary() -> dict[str, Any]:
    pack = load_teaching_activity_pack()
    activities = teaching_activity_candidates()
    roles: dict[str, int] = defaultdict(int)
    titles: list[str] = []
    for activity in activities:
        title = first_text(activity.get("title"))
        if title:
            titles.append(title)
        for role in ensure_list(activity.get("roles")):
            role_name = normalize_text(first_text(role)).replace(" ", "_")
            if role_name:
                roles[role_name] += 1
    return {
        "resource_id": first_text(pack.get("resource_id")),
        "activity_count": len(activities),
        "role_counts": dict(sorted(roles.items())),
        "sample_titles": titles[:8],
        "selection_rules": ensure_list(pack.get("selection_rules"))[:5],
        "guardrails": ensure_list(pack.get("guardrails")),
        "source_note": "Curated local File-O-Fun / Knowledge Atlas activity snapshot; no live Atlas lookup is performed by core audits.",
    }


def _activity_by_id(activity_id: str) -> dict[str, Any] | None:
    target = normalize_text(activity_id)
    for activity in teaching_activity_candidates():
        if normalize_text(first_text(activity.get("id"))) == target:
            return activity
    return None


def _activity_matches(activity: dict[str, Any], haystack: str, *, role: str) -> bool:
    roles = {normalize_text(item) for item in ensure_list(activity.get("roles"))}
    if role not in roles:
        return False
    for keyword in ensure_list(activity.get("match_keywords")):
        keyword_norm = normalize_text(first_text(keyword))
        if keyword_norm and keyword_norm in haystack:
            return True
    return False


def _pack_preferred_activity_ids(haystack: str) -> list[str]:
    pack = load_teaching_activity_pack()
    preferred: list[str] = []
    for rule in ensure_list(pack.get("selection_rules")):
        if not isinstance(rule, dict):
            continue
        keywords = [normalize_text(first_text(keyword)) for keyword in ensure_list(rule.get("keywords"))]
        if any(keyword and keyword in haystack for keyword in keywords):
            preferred.extend([first_text(item) for item in ensure_list(rule.get("prefer"))])
    return [item for item in preferred if item]


def _select_teaching_activity(role: str, haystack: str, *, avoid_ids: set[str] | None = None) -> dict[str, Any]:
    avoid = {normalize_text(item) for item in (avoid_ids or set())}
    for activity_id in _pack_preferred_activity_ids(haystack):
        activity = _activity_by_id(activity_id)
        if activity and normalize_text(first_text(activity.get("id"))) not in avoid:
            roles = {normalize_text(item) for item in ensure_list(activity.get("roles"))}
            if role in roles:
                return activity
    for activity in teaching_activity_candidates():
        if normalize_text(first_text(activity.get("id"))) in avoid:
            continue
        if _activity_matches(activity, haystack, role=role):
            return activity
    for fallback_id in ("claim-support-question", "reverse-outline-repair", "micro-lab-protocol"):
        activity = _activity_by_id(fallback_id)
        if not activity or normalize_text(first_text(activity.get("id"))) in avoid:
            continue
        roles = {normalize_text(item) for item in ensure_list(activity.get("roles"))}
        if role in roles:
            return activity
    return FALLBACK_TEACHING_ACTIVITIES[0]


def _teaching_activity_card(activity: dict[str, Any], *, subject_hint: str | None = None) -> dict[str, Any]:
    title = first_text(activity.get("title")) or "Claim-Support-Question"
    content_focus = first_text(activity.get("content_focus")) or "Use the claim or paragraph doing the most work in the text."
    hint = short_phrase(subject_hint or "", 16)
    if hint:
        content_focus = f"{content_focus} Start with: {hint}."
    return {
        "title": title,
        "why_this_fits": first_text(activity.get("why_this_fits") or activity.get("use_when"))
        or "This activity helps turn the audit into a concrete thinking move.",
        "steps": [
            first_text(step)
            for step in ensure_list(activity.get("steps"))
            if first_text(step)
        ][:4]
        or [
            "Pick the claim doing the most work.",
            "Name the support and the uncertainty.",
            "Choose one revision or verification move.",
        ],
        "content_focus": content_focus,
        "thinking_focus": [first_text(item) for item in ensure_list(activity.get("thinking_focus")) if first_text(item)][:3]
        or ["critical"],
        "source_note": first_text(activity.get("source_note"))
        or "Curated from the local File-O-Fun teaching activity pack.",
        **({"safety_note": first_text(activity.get("safety_note"))} if first_text(activity.get("safety_note")) else {}),
    }


def follow_up_activity_for_context(
    domain: str,
    biases_found: list[str],
    *,
    text_type: str | None = None,
    key_tension: str | None = None,
    recommended_next_step: str | None = None,
    human_loop_state: dict[str, Any] | None = None,
    subject_hint: str | None = None,
    depth: str | None = None,
) -> dict[str, Any]:
    human_loop_hint = ""
    if isinstance(human_loop_state, dict):
        human_loop_hint = text_blob(human_loop_state.get("responses"), human_loop_state.get("configuration"))
    haystack = normalize_text(
        text_blob(domain, text_type, biases_found, key_tension, recommended_next_step, human_loop_hint, subject_hint, depth)
    )
    quick_activity = _select_teaching_activity("solo_follow_up", haystack)
    solo_activity = _select_teaching_activity("solo_follow_up", haystack)
    solo_id = first_text(solo_activity.get("id"))
    group_activity = _select_teaching_activity("group_follow_up", haystack, avoid_ids={solo_id})
    pack = load_teaching_activity_pack()
    source_note = (
        "Curated from the local File-O-Fun / Knowledge Atlas teaching activity pack; no live Atlas lookup was performed."
    )
    if first_text(pack.get("source_note")):
        source_note = "Curated from a local File-O-Fun / Knowledge Atlas activity snapshot; no live Atlas lookup was performed."
    return {
        "mode": "curated_file_o_fun_snapshot",
        "try_this_next": _teaching_activity_card(quick_activity, subject_hint=subject_hint or key_tension),
        "solo_activity": _teaching_activity_card(solo_activity, subject_hint=subject_hint or key_tension),
        "group_activity": _teaching_activity_card(group_activity, subject_hint=subject_hint or key_tension),
        "source_note": source_note,
        "fit_check": {
            "prompt": "Use this, swap it, or skip activities next time?",
            "reflection_question": "What made it useful or not useful?",
            "persistence": "non_persistent",
            "no_persistence_note": "No activity outcome is saved by Critical Compass in beta.8.1.",
        },
        "guardrails": [
            "These activities are follow-up scaffolds, not replacements for the audit findings.",
            "Check-worthy or activity-worthy means worth examining, not false.",
            "Do not invent lived experience; consult affected people or evidence when missing voices matter.",
        ],
    }


def practice_suggestions_for_context(domain: str, biases_found: list[str], *, text_type: str | None = None) -> list[dict[str, Any]]:
    follow_up = follow_up_activity_for_context(domain, biases_found, text_type=text_type)
    suggestions: list[dict[str, Any]] = []
    for key, surface in (("try_this_next", "quick_chat_optional_followup"), ("group_activity", "full_report_group_followup")):
        card = follow_up.get(key) if isinstance(follow_up, dict) else None
        if not isinstance(card, dict):
            continue
        suggestions.append(
            {
                "activity": first_text(card.get("title")),
                "use_when": first_text(card.get("why_this_fits")),
                "prompt": " ".join([first_text(step) for step in ensure_list(card.get("steps")) if first_text(step)]),
                "skill_focus": ", ".join([first_text(item) for item in ensure_list(card.get("thinking_focus")) if first_text(item)]),
                "surface": surface,
                "standalone_tool": False,
            }
        )
    return suggestions[:2]


def suggest_next_steps_payload(repo: Repository, domain: str, biases_found: list[str]) -> dict[str, Any]:
    strategies: list[dict[str, Any]] = []
    seen: set[str] = set()

    for bias_name in biases_found:
        bias_row = repo.lookup_bias(bias_name)
        if not bias_row:
            continue
        mitigation = mitigation_strategy_from_bias(bias_row)
        key = normalize_text(mitigation["strategy"])
        if key in seen:
            continue
        seen.add(key)
        strategies.append(
            {
                "strategy": mitigation["strategy"],
                "action_verb": mitigation["action_verb"],
                "source_bias": bias_row.get("title"),
                "source_bias_id": bias_row.get("concept_id"),
                "why": short_phrase(mitigation["why"], 24),
                "thinking_move": "Critical: test evidence or inference; Compassionate: keep people separate from ideas; Creative: try a stronger alternate frame.",
            }
        )
        if len(strategies) >= 3:
            break

    if len(strategies) < 3:
        fallback_moves = [
            {
                "strategy": "Gather one primary source and one affected-stakeholder perspective.",
                "action_verb": "gather",
                "why": "The audit needs both evidence and standing before the recommendation is used.",
            },
            {
                "strategy": "Revise the strongest claim so it matches the visible evidence.",
                "action_verb": "revise",
                "why": "A bounded claim is easier to defend and less likely to mislead.",
            },
            {
                "strategy": "Compare the preferred frame with the strongest serious alternative.",
                "action_verb": "compare",
                "why": "A competing frame can reveal hidden assumptions or missing voices.",
            },
        ]
        for move in fallback_moves:
            key = normalize_text(move["strategy"])
            if key in seen:
                continue
            seen.add(key)
            strategies.append(
                {
                    **move,
                    "source_bias": None,
                    "source_bias_id": None,
                    "thinking_move": "Critical: test evidence or inference; Compassionate: avoid moralizing; Creative: reframe the claim.",
                }
            )
            if len(strategies) >= 3:
                break

    return {
        "domain": domain,
        "biases_found": biases_found,
        "next_steps": strategies[:3],
        "practice_suggestions": practice_suggestions_for_context(domain, biases_found),
        "mitigation_style": "atlas_informed_action_verbs",
        "allowed_verbs": ["check", "compare", "ask", "gather", "disclose", "bound", "test", "revise"],
    }


def merge_bias_hits(*groups: list[dict[str, Any]], limit: int = 7) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    seen: set[str] = set()
    for group in groups:
        for hit in group:
            key = normalize_text(first_text(hit.get("bias_id")) or first_text(hit.get("bias_name")))
            if not key or key in seen:
                continue
            seen.add(key)
            merged.append(hit)
            if len(merged) >= limit:
                return merged
    return merged


def research_methodology_result_score(result: dict[str, Any], query: str) -> int:
    text = normalize_text(
        text_blob(
            result.get("id"),
            result.get("entry_id"),
            result.get("title"),
            result.get("name"),
            result.get("category"),
            result.get("subcategory"),
            result.get("kind"),
            result.get("summary"),
            result.get("definition"),
            result.get("aliases"),
        )
    )
    title = normalize_text(first_text(result.get("title") or result.get("name")))
    query_norm = normalize_text(query)
    score = 0
    if query_norm and query_norm == title:
        score += 120
    if any(normalize_text(name) == title for name in [*RESEARCH_METHODOLOGY_BIAS_NAMES, *RESEARCH_VALIDITY_CONCEPT_NAMES]):
        score += 80
    if "methodology" in text or "validity" in text or "replic" in text or "sampling" in text:
        score += 35
    if result.get("category") in {"biases", "methodology-checks", "reasoning-frameworks"}:
        score += 12
    if normalize_text(result.get("subcategory")) in {"methodology", "research_validity", "research-validity", "audit", "preflight"}:
        score += 20
    if any(term in text for term in ["job search", "resume", "cover letter", "interview", "okr", "kanban", "roadmap", "rice", "backlog"]):
        score -= 120
    return score


def rerank_for_research_methodology(results: list[dict[str, Any]], query: str) -> list[dict[str, Any]]:
    return sorted(
        results,
        key=lambda result: (-research_methodology_result_score(result, query), first_text(result.get("title") or result.get("name"))),
    )


def research_methodology_profile_hits(repo: Repository, query: str, *, limit: int = 8) -> dict[str, Any]:
    names = [*RESEARCH_METHODOLOGY_BIAS_NAMES, *RESEARCH_VALIDITY_CONCEPT_NAMES]
    matched: list[dict[str, Any]] = []
    seen: set[str] = set()
    query_norm = normalize_text(query)
    for name in names:
        if normalize_text(name) not in query_norm and name not in RESEARCH_VALIDITY_CONCEPT_NAMES:
            continue
        rows = repo.search_public(name, limit=3).get("results", [])
        for row in rows:
            key = first_text(row.get("id") or row.get("entry_id") or row.get("title"))
            if key and key not in seen:
                seen.add(key)
                matched.append(row)
                break
        if len(matched) >= limit:
            break
    if len(matched) < min(limit, 4):
        for name in names:
            rows = repo.search_public(name, limit=2).get("results", [])
            for row in rows:
                key = first_text(row.get("id") or row.get("entry_id") or row.get("title"))
                if key and key not in seen:
                    seen.add(key)
                    matched.append(row)
                    break
            if len(matched) >= limit:
                break
    return {
        "profile": "research_methodology",
        "priority_terms": names,
        "hits": rerank_for_research_methodology(matched, query)[:limit],
    }


def text_has_any(text: str, terms: Iterable[str]) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in terms)


def detect_snapshot_context_lens(text: str, domain: str, text_type: str, bias_hits: list[dict[str, Any]]) -> dict[str, Any]:
    lowered = text.lower()
    signals: list[str] = []
    evidence_candidates: list[str] = []
    if is_study_report(text) or text_has_any(
        lowered,
        [
            "study",
            "survey",
            "sample",
            "participants",
            "cohort",
            "methodology",
            "regression",
            "randomized",
            "peer reviewed",
            "doi",
            "p <",
            "confidence interval",
        ],
    ):
        evidence_candidates.append("citation_based")
        signals.append("research or methods language")
    if text_has_any(
        lowered,
        [
            "report",
            "policy",
            "program",
            "agency",
            "foundation",
            "grant",
            "governance",
            "framework",
            "compliance",
            "evaluation",
            "dashboard",
        ],
    ):
        evidence_candidates.append("institutional_reporting")
        signals.append("institutional or policy-report language")
    if text_has_any(
        lowered,
        [
            "i experienced",
            "i saw",
            "my story",
            "lived experience",
            "in my community",
            "we experienced",
            "we saw",
            "testimony",
            "testimonial",
            "as someone",
        ],
    ):
        evidence_candidates.append("experiential_testimony")
        signals.append("lived-experience or testimony language")
    if text_has_any(
        lowered,
        [
            "community consensus",
            "our elders",
            "our community",
            "we decided",
            "we know",
            "collective",
            "shared responsibility",
            "mutual aid",
            "neighbors told us",
            "community members told us",
        ],
    ):
        evidence_candidates.append("communal_consensus")
        signals.append("collective or community-accountability language")
    evidence_unique = join_unique(evidence_candidates)
    if len(evidence_unique) > 1:
        evidence_convention = "hybrid"
    elif evidence_unique:
        evidence_convention = evidence_unique[0]
    else:
        evidence_convention = "unclear"
        signals.append("no clear evidence convention")

    purpose_candidates: list[str] = []
    if text_type in {*RESEARCH_TEXT_TYPES, "journalism"} or domain in {"research study/report", "news article"}:
        purpose_candidates.append("inform")
    if text_type in PERSUASIVE_TEXT_TYPES or text_has_any(lowered, ["should", "must", "need to", "adopt", "support", "choose"]):
        purpose_candidates.append("persuade")
    if text_type == "legal":
        purpose_candidates.append("govern")
    if text_type == "ai_generated":
        purpose_candidates.append("draft")
    if text_has_any(lowered, ["join", "mobilize", "act now", "organize", "movement", "campaign", "cannot wait"]):
        purpose_candidates.append("mobilize")
    if text_has_any(lowered, ["document", "record", "minutes", "findings", "report", "evaluation"]):
        purpose_candidates.append("document")
    if text_type == "narrative" or text_has_any(lowered, ["story", "narrative", "memoir", "scene"]):
        purpose_candidates.append("narrate")
    purpose_unique = join_unique(purpose_candidates)
    purpose = purpose_unique[0] if len(purpose_unique) == 1 else "mixed" if purpose_unique else "mixed"
    if purpose_unique:
        signals.append(f"purpose cues: {', '.join(purpose_unique[:2])}")

    voice_candidates: list[str] = []
    if re.search(r"\b(i|me|my|mine)\b", lowered):
        voice_candidates.append("first_person")
    if re.search(r"\b(we|our|us|ours)\b", lowered) or text_has_any(lowered, ["community", "neighbors", "families", "residents"]):
        voice_candidates.append("collective")
    if text_has_any(lowered, ["the organization", "the agency", "the foundation", "the report", "leaders", "officials", "experts"]):
        voice_candidates.append("institutional")
    voice_unique = join_unique(voice_candidates)
    voice = voice_unique[0] if len(voice_unique) == 1 else "mixed" if voice_unique else "unclear"
    if voice_unique:
        signals.append(f"voice cues: {', '.join(voice_unique[:2])}")

    sensitive_dimensions = ["Grounding & Scope Fit"]
    if evidence_convention in {"experiential_testimony", "communal_consensus", "hybrid", "unclear"}:
        sensitive_dimensions.append("Framing & Audience Openness")
    if any("framing" in normalize_text(hit.get("bias_name")) for hit in bias_hits):
        sensitive_dimensions.append("Bias Transparency")
    return {
        "evidence_convention": evidence_convention,
        "purpose": purpose,
        "voice": voice,
        "signals": join_unique(signals)[:6],
        "scoring_note": "Grounding and framing are interpreted relative to the detected evidence convention.",
        "sensitive_dimensions": join_unique(sensitive_dimensions),
    }


def snapshot_label(points: int) -> str:
    if points >= 90:
        return "Exemplary Integrity"
    if points >= 75:
        return "Strong Integrity"
    if points >= 55:
        return "Moderate Integrity"
    if points >= 35:
        return "Limited Integrity"
    return "Needs Scrutiny"


def confidence_from_snapshot_inputs(
    text: str,
    context_lens: dict[str, Any],
    insufficient: bool,
    bias_hits: list[dict[str, Any]],
    methodology: dict[str, Any] | None,
) -> str:
    word_count = len(text.split())
    if insufficient or word_count < 8:
        return "very_low"
    if word_count < 25 or context_lens.get("evidence_convention") == "unclear":
        return "low"
    high_hits = sum(1 for hit in bias_hits if first_text(hit.get("confidence")).lower() == "high")
    if word_count >= 120 and (methodology or high_hits or context_lens.get("evidence_convention") in {"citation_based", "institutional_reporting", "hybrid"}):
        return "high"
    return "medium"


def snapshot_comparability(context_lens: dict[str, Any], confidence: str, insufficient: bool, noisy: bool) -> str:
    if insufficient or noisy or confidence == "very_low" or context_lens.get("evidence_convention") == "unclear":
        return "not_comparable"
    if context_lens.get("evidence_convention") in {"hybrid", "experiential_testimony", "communal_consensus"}:
        return "qualified"
    if confidence == "low":
        return "limited"
    return "strong"


def snapshot_display_policy(
    *,
    display_state: str,
    confidence: str,
    comparability: str,
    snapshot_mode: str,
) -> dict[str, Any]:
    if display_state == "profile_only" or comparability == "not_comparable" or confidence == "very_low":
        return {
            "points_prominence": "suppressed",
            "profile_first": True,
            "comparability_warning": "Aggregate points are withheld because the snapshot is not comparable enough to defend.",
            "rendering_rule": "Render the context lens, confidence, comparability, five dimensions, withheld reason, and Before Using This Text sentence starting exactly with 'Before using this text,'. Do not invent a label or points.",
        }
    if comparability == "limited":
        return {
            "points_prominence": "secondary" if snapshot_mode == "research" else "suppressed",
            "profile_first": True,
            "comparability_warning": "Compare this only with texts in a similar evidence frame; the dimension profile carries more meaning than the total.",
            "rendering_rule": "Lead with the label and dimension profile. Show points only as a secondary traceability signal in research mode.",
        }
    if comparability == "qualified":
        return {
            "points_prominence": "secondary",
            "profile_first": True,
            "comparability_warning": "Cross-frame comparisons are qualified; read the context lens before comparing totals.",
            "rendering_rule": "Render the descriptive label first, points second, then confidence, comparability, context lens, and dimension profile.",
        }
    return {
        "points_prominence": "secondary",
        "profile_first": False,
        "comparability_warning": None,
        "rendering_rule": "Render the descriptive label first and points only as a traceability signal; never render a school grade or percentage.",
    }


def noisy_or_translation_signals(text: str) -> list[str]:
    lowered = text.lower()
    signals: list[str] = []
    for term in ["machine translated", "translated from", "[translation", "ocr", "transcript unclear", "inaudible"]:
        if term in lowered:
            signals.append(term)
    if "�" in text:
        signals.append("replacement characters")
    if text.count("???") > 0:
        signals.append("unclear transcription markers")
    return signals


def bias_penalty(hit: dict[str, Any]) -> int:
    return {"high": 5, "medium": 3, "low": 1}.get(first_text(hit.get("confidence")).lower(), 1)


def trace_for_bias(bias_hits: list[dict[str, Any]], *needles: str) -> list[str]:
    traces: list[str] = []
    normalized_needles = [normalize_text(needle) for needle in needles if normalize_text(needle)]
    for index, hit in enumerate(bias_hits):
        haystack = normalize_text(" ".join([first_text(hit.get("bias_name")), first_text(hit.get("why_it_qualifies")), first_text(hit.get("evidence"))]))
        if any(needle in haystack for needle in normalized_needles):
            traces.append(f"bias_map[{index}]")
    return traces


def clamp_dimension(points: int) -> int:
    return max(0, min(20, points))


def dimension_payload(key: str, points: int, rationale: str, trace: list[str], improvement_prompt: str) -> dict[str, Any]:
    label = dict(SNAPSHOT_DIMENSIONS)[key]
    return {
        "key": key,
        "name": label,
        "points": clamp_dimension(points),
        "max_points": 20,
        "rationale": rationale,
        "trace": join_unique(trace),
        "improvement_prompt": improvement_prompt,
    }


def snapshot_key_term(text: str) -> str:
    lowered = text.lower()
    for term in ["capacity", "community voice", "accountability", "risk", "evidence", "equity", "framework", "impact", "safety", "care"]:
        if term in lowered:
            return term
    words = [word for word in tokenize(text) if word not in STOPWORDS and len(word) > 4]
    return words[0] if words else "the key claim"


def one_sentence(text: str, *, max_words: int = 24) -> str:
    cleaned = re.sub(r"\s+", " ", first_text(text)).strip()
    if not cleaned:
        return ""
    match = re.search(r"^(.+?[.!?])(?:\s|$)", cleaned)
    sentence = match.group(1).strip() if match else cleaned
    words = sentence.split()
    if len(words) > max_words:
        sentence = " ".join(words[:max_words]).rstrip(" ,;:") + "."
    if sentence[-1] not in ".!?":
        sentence += "."
    return sentence


def standardize_before_using_prompt(text: str) -> str:
    sentence = one_sentence(text, max_words=24)
    if not sentence:
        return "Before using this text, ask what evidence would change the reader's mind."
    lowered = sentence.lower()
    if lowered.startswith("before using this text,"):
        return sentence
    if lowered.startswith("ask "):
        sentence = sentence[0].lower() + sentence[1:]
        return one_sentence(f"Before using this text, {sentence}", max_words=24)
    return one_sentence(f"Before using this text, ask {sentence[0].lower() + sentence[1:]}", max_words=24)


def build_before_using_prompt(text: str, context_lens: dict[str, Any], bias_hits: list[dict[str, Any]]) -> str:
    key_term = snapshot_key_term(text)
    if any("framing" in normalize_text(hit.get("bias_name")) for hit in bias_hits):
        return standardize_before_using_prompt(
            f"Before using this text, ask whose framing sets the terms and what serious alternative it leaves out."
        )
    if context_lens.get("voice") == "institutional":
        return standardize_before_using_prompt(
            "Before using this text, ask who benefits, who is accountable, and whose lived stakes are missing."
        )
    if context_lens.get("evidence_convention") in {"experiential_testimony", "communal_consensus"}:
        return standardize_before_using_prompt(
            "Before using this text, ask what would look different from inside the community most affected."
        )
    if context_lens.get("evidence_convention") == "citation_based":
        return standardize_before_using_prompt(
            "Before using this text, ask whether the evidence supports the claim's scope."
        )
    return standardize_before_using_prompt(f"Before using this text, ask what evidence would change the reader's mind about {key_term}.")


def snapshot_plain_language(label: str | None, mode: str, *, display_state: str = "scored") -> str:
    if display_state == "profile_only" or not label:
        profile_reads = {
            "organizer": "Do not reduce this to a score; read the dimension profile and resolve the missing context first.",
            "research": "Do not compress this into a verdict; inspect the dimensions and resolve the missing methodological context first.",
        }
        return one_sentence(profile_reads["research" if mode == "research" else "organizer"])
    organizer = {
        "Exemplary Integrity": "Use this with confidence; it names its evidence, limits, and point of view.",
        "Strong Integrity": "Use this, but keep the visible gaps and assumptions attached.",
        "Moderate Integrity": "Use this as a starting point, not a final authority; verify the claims doing the most work.",
        "Limited Integrity": "Do not rely on this alone; key claims, assumptions, or missing voices need outside support.",
        "Needs Scrutiny": "Treat this as high-risk material; verify who benefits, what evidence is missing, and whose stakes are absent.",
    }
    research = {
        "Exemplary Integrity": "Use this as strong evidence; its claims, limits, and evidence frame are visible.",
        "Strong Integrity": "Use this as evidence, but keep its methods, sample, and assumptions visible.",
        "Moderate Integrity": "Use this as provisional evidence; verify the methods, sample, and strongest claim first.",
        "Limited Integrity": "Do not cite this alone; the methods, scope, or assumptions need independent support.",
        "Needs Scrutiny": "Treat this as weak evidence until the methods, data, and scope claims are independently checked.",
    }
    return one_sentence((research if mode == "research" else organizer).get(label, organizer["Needs Scrutiny"]))


def replication_dimension(name: str, points: int, rationale: str, trace: list[str]) -> dict[str, Any]:
    return {
        "name": name,
        "points": max(0, min(points, 20)),
        "max_points": 20,
        "rationale": rationale,
        "trace": trace,
    }


def build_replication_readiness(
    text: str,
    *,
    domain: str,
    text_type: str,
    methodology: dict[str, Any] | None,
    bias_hits: list[dict[str, Any]],
) -> dict[str, Any]:
    if text_type not in RESEARCH_TEXT_TYPES and domain != "research study/report" and not is_study_report(text):
        return {
            "applicable": False,
            "reason": "Replication readiness is only scored for research, study, or methodology-shaped text.",
        }
    lowered = text.lower()
    methodology = methodology or {}
    preregistered = text_has_any(lowered, ["preregistered", "pre-registered", "registered report", "protocol", "analysis plan"])
    replication_terms = text_has_any(lowered, ["replication", "replicate", "reproduced", "open data", "open materials", "code available"])
    high_methodology_bias = any(
        any(term in normalize_text(hit.get("bias_name")) for term in ["p hacking", "harking", "publication", "demand", "social desirability", "weird", "overgeneralization", "nonresponse", "attrition"])
        for hit in bias_hits
    )

    sampling_status = (methodology.get("sampling") or {}).get("status")
    measures_status = (methodology.get("measures_endpoints") or {}).get("status")
    design_status = (methodology.get("design_stats") or {}).get("status")
    context_status = (methodology.get("dose_context") or {}).get("status")

    dimensions = [
        replication_dimension(
            "Sample & Population Clarity",
            17 if sampling_status == "observed" else 8,
            "The text names the sample or participant pool." if sampling_status == "observed" else "The sample or participant pool is not explicit enough for stable replication judgment.",
            ["methodology_check.sampling"],
        ),
        replication_dimension(
            "Measures & Outcomes",
            17 if measures_status == "observed" else 8,
            "The measured outcomes or instruments are visible." if measures_status == "observed" else "The measured outcomes or instruments are not fully visible.",
            ["methodology_check.measures_endpoints"],
        ),
        replication_dimension(
            "Design & Analysis",
            17 if design_status == "observed" else 7,
            "The design or statistical approach is named." if design_status == "observed" else "The design or statistical approach is under-specified.",
            ["methodology_check.design_stats"],
        ),
        replication_dimension(
            "Context & Conditions",
            15 if context_status == "observed" else 7,
            "The setting, exposure, or context is at least partly stated." if context_status == "observed" else "The setting, exposure, or context is not clear enough.",
            ["methodology_check.dose_context"],
        ),
        replication_dimension(
            "Preregistration & Reproducibility",
            18 if preregistered and replication_terms else 12 if preregistered or replication_terms else 5,
            "The text signals preregistration and reproducibility materials." if preregistered and replication_terms else "The text has partial preregistration or reproducibility signals." if preregistered or replication_terms else "No preregistration, protocol, open data, or replication signal is visible.",
            ["subject_text"],
        ),
    ]
    points = sum(item["points"] for item in dimensions)
    if high_methodology_bias:
        points = max(0, points - 10)
    if points >= 85:
        label = "Replication-Ready"
    elif points >= 65:
        label = "Partly Replication-Ready"
    elif points >= 40:
        label = "Weak Replication Readiness"
    else:
        label = "Not Replication-Ready"
    return {
        "applicable": True,
        "label": label,
        "points": points,
        "max_points": 100,
        "score_confidence": "medium" if methodology else "low",
        "dimensions": dimensions,
        "methodology_bias_penalty_applied": high_methodology_bias,
        "before_relying_on_replication": "Ask whether an independent team could recreate the sample, measures, conditions, and analysis plan from what is visible here.",
    }


def build_critical_integrity_snapshot(
    text: str,
    *,
    domain: str,
    text_type: str,
    sensitivity: str,
    bias_hits: list[dict[str, Any]],
    assumptions: list[dict[str, Any]],
    methodology: dict[str, Any] | None,
    alternative_frames: list[dict[str, Any]],
    insufficient: bool,
    snapshot_mode: str | None = None,
) -> dict[str, Any]:
    mode = normalize_snapshot_mode(snapshot_mode)
    context_lens = detect_snapshot_context_lens(text, domain, text_type, bias_hits)
    noisy_signals = noisy_or_translation_signals(text)
    confidence = confidence_from_snapshot_inputs(text, context_lens, insufficient, bias_hits, methodology)
    comparability = snapshot_comparability(context_lens, confidence, insufficient, bool(noisy_signals))

    high_biases = [hit for hit in bias_hits if first_text(hit.get("confidence")).lower() == "high"]
    total_bias_penalty = sum(bias_penalty(hit) for hit in bias_hits)
    has_evidence = context_lens.get("evidence_convention") in {"citation_based", "experiential_testimony", "communal_consensus", "hybrid"}
    has_methodology = bool(methodology)
    has_limit_language = text_has_any(text, ["limitation", "may", "might", "could", "suggests", "preliminary", "we do not know", "uncertain"])
    has_standpoint = text_has_any(
        text,
        [
            "i write as",
            "we write as",
            "from our perspective",
            "from my perspective",
            "as organizers",
            "as researchers",
            "as community members",
            "our goal",
            "we believe",
            "we advocate",
            "funded by",
            "sponsored by",
        ],
    )
    has_alternatives = text_has_any(text, ["alternative", "another explanation", "critics", "however", "limitations", "on the other hand", "tradeoff"])
    has_power_cues = text_has_any(text, ["funded by", "sponsored by", "who benefits", "power", "community voice", "stakeholder", "lived experience", "accountability"])
    has_universalizing = text_has_any(text, ["everyone", "all communities", "only", "none of the other", "clearly", "obviously", "must", "cannot afford"])
    has_false_neutrality = text_has_any(text, ["research shows", "experts agree", "data proves", "it is clear", "evidence proves"])

    grounding = 16 if has_evidence else 10
    if has_methodology:
        grounding += 2
    if insufficient:
        grounding = 6
    grounding -= sum(bias_penalty(hit) for hit in bias_hits if any(term in normalize_text(hit.get("bias_name")) for term in ["overconfidence", "causal", "unsupported", "authority"]))
    grounding_rationale = "Claims have visible grounding for the detected evidence convention." if has_evidence else "The visible excerpt gives limited grounding for its claims."
    if has_methodology:
        grounding_rationale = "The text includes research or methodology cues, but claim scope still needs checking."
    if insufficient:
        grounding_rationale = "The text is too short or fragmentary for stable claim-support scoring."

    assumptions_points = 14
    if has_limit_language:
        assumptions_points += 3
    if has_universalizing:
        assumptions_points -= 4
    if insufficient:
        assumptions_points = 7
    assumptions_rationale = "Some context is visible, but at least one load-bearing assumption still needs naming."
    if has_limit_language:
        assumptions_rationale = "The text uses some limiting language, which helps readers see the claim boundaries."
    if has_universalizing:
        assumptions_rationale = "Universal or necessity language leaves assumptions doing structural work."

    bias_transparency = 18 - total_bias_penalty
    if has_standpoint:
        bias_transparency += 4
    if has_false_neutrality and bias_hits:
        bias_transparency -= 3
    if insufficient:
        bias_transparency = 8
    bias_rationale = "Bias signals are present; the key question is whether the text owns or hides its angle."
    if has_standpoint:
        bias_rationale = "The text gives some standpoint or purpose cues, reducing the risk of hidden neutrality."
    if has_false_neutrality and bias_hits:
        bias_rationale = "The text uses neutral-sounding authority language while bias cues are present."

    framing = 16
    framing -= sum(bias_penalty(hit) for hit in bias_hits if any(term in normalize_text(hit.get("bias_name")) for term in ["framing", "false consensus", "selection", "availability"]))
    if has_alternatives:
        framing += 4
    if text_type in {"advocacy", "sales", "product_copy", "social_media"}:
        framing -= 1
    if text_type == "legal":
        grounding -= 1
        assumptions_points -= 1
    if text_type == "ai_generated":
        bias_transparency -= 2
    if insufficient:
        framing = 7
    framing_rationale = "The text gives readers some room to compare frames." if has_alternatives else "The text does not make alternative interpretations very visible."

    positionality = 10
    if has_standpoint:
        positionality += 6
    if has_power_cues:
        positionality += 3
    if context_lens.get("voice") in {"first_person", "collective"}:
        positionality += 2
    if context_lens.get("voice") == "institutional" and not (has_standpoint or has_power_cues):
        positionality -= 3
    if text_type == "ai_generated":
        positionality -= 1
    if insufficient:
        positionality = 7
    positionality_rationale = "The speaker, incentives, and centered voices are only partly visible."
    if has_power_cues or has_standpoint:
        positionality_rationale = "The text gives readers some signal about standpoint, incentives, or whose stakes are centered."
    if context_lens.get("voice") == "institutional" and not (has_standpoint or has_power_cues):
        positionality_rationale = "The text speaks institutionally without clearly locating standpoint, funding, or affected voices."

    dimensions = [
        dimension_payload(
            "grounding_scope_fit",
            grounding,
            grounding_rationale,
            (["methodology_check"] if methodology else []) + trace_for_bias(bias_hits, "overconfidence", "causal", "unsupported", "authority") + ["context_lens"],
            "Name the evidence type and keep the claim scope inside that evidence.",
        ),
        dimension_payload(
            "assumptions_context",
            assumptions_points,
            assumptions_rationale,
            ["assumptions[2]"] + (["context_lens"] if context_lens.get("signals") else []),
            "State the assumption a skeptical reader would test first.",
        ),
        dimension_payload(
            "bias_transparency",
            bias_transparency,
            bias_rationale,
            [f"bias_map[{index}]" for index, _ in enumerate(bias_hits[:3])] or ["bias_map"],
            "Own the text's standpoint instead of presenting advocacy as neutral fact.",
        ),
        dimension_payload(
            "framing_audience_openness",
            framing,
            framing_rationale,
            trace_for_bias(bias_hits, "framing", "false consensus", "selection", "availability") + (["alternative_frames"] if alternative_frames else []),
            "Name the strongest alternative interpretation or missing comparison.",
        ),
        dimension_payload(
            "positionality_power",
            positionality,
            positionality_rationale,
            ["context_lens"] + (["assumptions[3]"] if len(assumptions) > 3 else []),
            "Name who is speaking, who benefits, and whose stakes are missing.",
        ),
    ]
    points = sum(int(item["points"]) for item in dimensions)
    spread = max(int(item["points"]) for item in dimensions) - min(int(item["points"]) for item in dimensions)
    profile_only_reasons: list[str] = []
    if insufficient:
        profile_only_reasons.append("Text is too short or fragmentary for stable aggregate scoring.")
    if context_lens.get("evidence_convention") == "unclear":
        profile_only_reasons.append("Evidence convention is unclear, so cross-text comparison would be misleading.")
    if confidence == "very_low":
        profile_only_reasons.append("Score confidence is very low.")
    if comparability == "not_comparable":
        profile_only_reasons.append("Comparability is not strong enough for an aggregate score.")
    if noisy_signals:
        profile_only_reasons.append(f"Noisy or translation signals detected: {', '.join(noisy_signals[:3])}.")
    if spread >= 17 and confidence in {"very_low", "low"}:
        profile_only_reasons.append("Dimension scores are too unstable to compress into one label.")

    display_state = "profile_only" if profile_only_reasons else "scored"
    label = snapshot_label(points) if display_state == "scored" else None
    display_policy = snapshot_display_policy(
        display_state=display_state,
        confidence=confidence,
        comparability=comparability,
        snapshot_mode=mode,
    )
    return {
        "name": "Critical Integrity Snapshot",
        "abbreviation": "CIS",
        "display_state": display_state,
        "label": label,
        "points": points if display_state == "scored" else None,
        "max_points": 100,
        "score_confidence": confidence,
        "comparability": comparability,
        "snapshot_mode": mode,
        "context_lens": context_lens,
        "display_policy": display_policy,
        "dimensions": dimensions,
        "plain_language_read": snapshot_plain_language(label, mode, display_state=display_state),
        "before_using_this_text": build_before_using_prompt(text, context_lens, bias_hits),
        "withheld_reason": " ".join(profile_only_reasons) if profile_only_reasons else None,
        "derived_after_bias_detection": True,
        "scoring_rules": {
            "labels": [
                {"range": "90-100", "label": "Exemplary Integrity"},
                {"range": "75-89", "label": "Strong Integrity"},
                {"range": "55-74", "label": "Moderate Integrity"},
                {"range": "35-54", "label": "Limited Integrity"},
                {"range": "0-34", "label": "Needs Scrutiny"},
            ],
            "note": "Points are criterion-referenced traceability signals, not school grades or percentages.",
        },
    }


def bias_confidence_rank(hit: dict[str, Any]) -> int:
    return {"high": 3, "medium": 2, "low": 1}.get(first_text(hit.get("confidence")).lower(), 0)


def build_quick_scan_card(
    text: str,
    *,
    domain: str,
    text_type: str,
    text_type_source: str,
    sensitivity: str,
    bias_hits: list[dict[str, Any]],
    insufficient: bool,
    critical_integrity_snapshot: dict[str, Any] | None = None,
    replication_readiness: dict[str, Any] | None = None,
) -> dict[str, Any]:
    top_biases = sorted(
        bias_hits,
        key=lambda hit: (-bias_confidence_rank(hit), first_text(hit.get("bias_name"))),
    )[:3]
    top_bias_payload = [
        {
            "bias_name": hit.get("bias_name"),
            "confidence": hit.get("confidence"),
            "justification": short_phrase(first_text(hit.get("evidence")) or first_text(hit.get("claim_passage")), 18),
        }
        for hit in top_biases
    ]
    if insufficient:
        key_tension = "The text is too thin to label bias confidently."
        next_step = "Ask for more context before applying a bias label."
    elif top_biases:
        key_tension = f"The text may be using {top_biases[0].get('bias_name')} while presenting its conclusion as more settled than the visible evidence supports."
        next_step = "Ask what evidence would weaken the main claim, then revise the framing to show alternatives fairly."
    else:
        key_tension = "No strong deterministic bias cue fired."
        next_step = "Use the probing questions before treating the claim as settled."
    card = {
        "text_type": text_type,
        "text_type_source": text_type_source,
        "domain": domain,
        "sensitivity": sensitivity,
        "top_biases": top_bias_payload,
    }
    if critical_integrity_snapshot:
        card["critical_integrity_snapshot"] = critical_integrity_snapshot
    if replication_readiness and replication_readiness.get("applicable"):
        card["replication_readiness"] = replication_readiness
    card.update(
        {
            "key_tension": key_tension,
            "recommended_next_step": next_step,
            "word_limit_hint": "Designed to render as a quick-scan card before the full audit.",
        }
    )
    return card


def build_audit_reasoning_artifacts(data: dict[str, Any], subject_text: str) -> dict[str, Any]:
    try:
        from audit_report.artifacts import normalize_reasoning_artifacts  # type: ignore
    except Exception:
        return {
            "argument_map": {},
            "checkworthy_claims": {
                "claims": [],
                "status": "not_available",
                "note": "Reasoning artifacts were not available in this host test environment.",
            },
        }
    return normalize_reasoning_artifacts(data, subject_text=subject_text)


def build_audit_trust_artifacts(data: dict[str, Any], subject_text: str) -> dict[str, Any]:
    try:
        from audit_report.trust import (  # type: ignore
            blind_spot_reminder_candidates,
            detect_reasoning_traps,
            human_loop_interruption_triggers,
            source_tool_trust_preflight,
        )
    except Exception:
        return {
            "reasoning_traps": [],
            "human_loop_interruption_triggers": [],
            "blind_spot_reminders": {
                "present": False,
                "requires_explicit_consent": True,
                "sensitive_profile_blocked": False,
                "reminders": [],
            },
            "source_tool_trust_preflight": {
                "status": "not_available",
                "warnings": [],
            },
        }
    trap_input = {
        "subject_text": subject_text,
    }
    trigger_input = {
        "subject_text": subject_text,
        "schema_warnings": data.get("schema_warnings"),
        "missing_report_fields": data.get("missing_report_fields"),
    }
    trap_report = detect_reasoning_traps(trap_input)
    trigger_report = human_loop_interruption_triggers(trigger_input)
    reminder_report = blind_spot_reminder_candidates(
        {
            "reasoning_traps": ensure_list(trap_report.get("traps"))[:5] if isinstance(trap_report, dict) else [],
            "human_loop_interruption_triggers": trigger_report,
        },
        text_type=normalize_text(data.get("text_type")),
    )
    source_input = data.get("source_preflight") or data.get("source_result") or data.get("source_tool_trust_preflight")
    source_preflight = (
        source_tool_trust_preflight(source_input)
        if source_input
        else {
            "status": "not_run",
            "warnings": [],
            "consent_boundaries": {
                "local_only": True,
                "external_retrieval_allowed": False,
                "notes": "No source preflight data was supplied; audit_text does not perform automatic source retrieval.",
            },
        }
    )
    return {
        "reasoning_traps": ensure_list(trap_report.get("traps"))[:5] if isinstance(trap_report, dict) else [],
        "human_loop_interruption_triggers": ensure_list(trigger_report.get("triggers"))[:5] if isinstance(trigger_report, dict) else [],
        "blind_spot_reminders": reminder_report,
        "source_tool_trust_preflight": source_preflight,
    }


def audit_text_payload(
    repo: Repository,
    text: str,
    sensitivity: str | None = None,
    text_type: str | None = None,
    domain_hint: str | None = None,
    snapshot_mode: str | None = None,
    retrieval_profile: str | None = None,
    depth: str | None = None,
    human_loop_mode: str | None = None,
    human_loop_state: dict[str, Any] | None = None,
    defer_reflection: bool = False,
) -> dict[str, Any]:
    sensitivity_level, sensitivity_signals = detect_sensitivity(text, sensitivity)
    domain_source = f"{domain_hint or ''}\n{text}".strip()
    domain, domain_signals = detect_domain(domain_source)
    resolved_text_type, text_type_source = resolve_text_type(text, domain, text_type)
    resolved_retrieval_profile = resolve_retrieval_profile(
        text,
        text_type=resolved_text_type,
        domain=domain,
        retrieval_profile=retrieval_profile,
    )
    state_depth = ""
    if isinstance(human_loop_state, dict):
        configuration = human_loop_state.get("configuration") if isinstance(human_loop_state.get("configuration"), dict) else {}
        depth_config = configuration.get("depth") if isinstance(configuration.get("depth"), dict) else {}
        state_depth = first_text(depth_config.get("value"))
    depth_value = normalize_audit_depth(state_depth or depth)
    initial_source_completeness, _, _ = human_loop_source_completeness(text, is_vague_or_short(text))
    incoming_human_loop_state = human_loop_state_input(human_loop_state)
    if human_loop_mode_consent_required(human_loop_mode, incoming_human_loop_state):
        consent_loop = build_human_loop(
            stage="mode_consent",
            human_loop_mode=human_loop_mode,
            human_loop_state=human_loop_state,
            text_type=resolved_text_type,
            text_type_source=text_type_source,
            domain=domain,
            sensitivity=sensitivity_level,
            depth=depth_value,
            snapshot_mode=normalize_snapshot_mode(snapshot_mode),
            retrieval_profile=resolved_retrieval_profile,
            source_completeness=initial_source_completeness,
        )
        consent_action = human_loop_host_action(consent_loop)
        return {
            "tool": "audit_text",
            "status": "human_loop_mode_consent_pending",
            "domain_identification": {
                "domain": domain,
                "sensitivity": sensitivity_level,
                "signals": join_unique(domain_signals + sensitivity_signals),
                "retrieval_profile": resolved_retrieval_profile,
            },
            "text_type": resolved_text_type,
            "text_type_source": text_type_source,
            "human_loop": consent_loop,
            "human_loop_host_action": consent_action,
            "report_readiness_contract": report_readiness_contract(depth_value, stage="audit_text_mode_consent", include_advanced=False),
            "quality_gate": {"human_loop_gate": False, "mode_consent_required": True, "core_audit_not_run": True},
        }
    onboarding_loop = build_human_loop(
        stage="onboarding",
        human_loop_mode=human_loop_mode,
        human_loop_state=human_loop_state,
        text_type=resolved_text_type,
        text_type_source=text_type_source,
        domain=domain,
        sensitivity=sensitivity_level,
        depth=depth_value,
        snapshot_mode=normalize_snapshot_mode(snapshot_mode),
        retrieval_profile=resolved_retrieval_profile,
        source_completeness=initial_source_completeness,
    )
    onboarding_action = human_loop_host_action(onboarding_loop)
    if onboarding_action.get("must_pause"):
        return {
            "tool": "audit_text",
            "status": "human_loop_onboarding_pending",
            "domain_identification": {
                "domain": domain,
                "sensitivity": sensitivity_level,
                "signals": join_unique(domain_signals + sensitivity_signals),
                "retrieval_profile": resolved_retrieval_profile,
            },
            "text_type": resolved_text_type,
            "text_type_source": text_type_source,
            "human_loop": onboarding_loop,
            "human_loop_host_action": onboarding_action,
            "report_readiness_contract": report_readiness_contract(depth_value, stage="audit_text_onboarding", include_advanced=False),
            "quality_gate": {"human_loop_gate": False, "core_audit_not_run": True},
        }

    silent_parse = human_loop_silent_parse(text)
    judgment_loop = build_human_loop(
        stage="judgment",
        human_loop_mode=human_loop_mode,
        human_loop_state=human_loop_state,
        text_type=resolved_text_type,
        text_type_source=text_type_source,
        domain=domain,
        sensitivity=sensitivity_level,
        depth=depth_value,
        snapshot_mode=normalize_snapshot_mode(snapshot_mode),
        retrieval_profile=resolved_retrieval_profile,
        source_completeness=initial_source_completeness,
        silent_parse=silent_parse,
    )
    judgment_action = human_loop_host_action(judgment_loop)
    if judgment_action.get("must_pause"):
        return {
            "tool": "audit_text",
            "status": "human_loop_judgment_pending",
            "domain_identification": {
                "domain": domain,
                "sensitivity": sensitivity_level,
                "signals": join_unique(domain_signals + sensitivity_signals),
                "retrieval_profile": resolved_retrieval_profile,
            },
            "text_type": resolved_text_type,
            "text_type_source": text_type_source,
            "silent_parse": silent_parse,
            "human_loop": judgment_loop,
            "human_loop_host_action": judgment_action,
            "report_readiness_contract": report_readiness_contract(depth_value, stage="audit_text_judgment", include_advanced=False),
            "quality_gate": {"human_loop_gate": False, "findings_not_revealed": True},
        }

    direct_bias_hits = repo.find_bias_hits(text)
    research_bias_hits = (
        repo.find_research_methodology_bias_hits(
            text,
            exclude=[hit.get("bias_id") or hit.get("bias_name") for hit in direct_bias_hits],
        )
        if resolved_retrieval_profile == "research_methodology"
        else []
    )
    persuasive_bias_hits = repo.find_persuasive_bias_hits(
        text,
        text_type=resolved_text_type,
        exclude=[hit.get("bias_id") or hit.get("bias_name") for hit in [*direct_bias_hits, *research_bias_hits]],
    )
    if resolved_retrieval_profile == "research_methodology":
        bias_hits = merge_bias_hits(research_bias_hits, direct_bias_hits, persuasive_bias_hits, limit=7)
    else:
        bias_hits = merge_bias_hits(direct_bias_hits, persuasive_bias_hits, limit=7)
    insufficient = is_vague_or_short(text) and not bias_hits and not is_study_report(text)
    source_completeness, _, _ = human_loop_source_completeness(text, insufficient)
    fallback_bias_hits: list[dict[str, Any]] = []
    bias_mode = "direct" if bias_hits else "none"

    assumptions = format_assumptions(text, sensitivity_level)
    methodology = methodology_lookup(repo, text)
    if insufficient:
        bias_hits = []
        methodology = methodology if methodology and domain == "research study/report" else None
        bias_mode = "insufficient"
    elif not bias_hits:
        fallback_bias_hits = repo.find_bias_candidates(text, limit=3)
        bias_hits = fallback_bias_hits or [repo.review_placeholder_bias(text)]
        bias_mode = "fallback_candidates" if fallback_bias_hits else "placeholder"
    elif research_bias_hits:
        bias_mode = "research_methodology_profile"
    elif persuasive_bias_hits:
        bias_mode = "direct_plus_persuasive_cues" if direct_bias_hits else "persuasive_cues"

    alternative_frames = choose_alternative_frames(
        repo,
        text,
        domain,
        bias_hits,
        text_type=resolved_text_type,
        domain_hint=domain_hint,
    )
    probing = probing_questions(domain, bias_hits, sensitivity_level)
    follow_up = follow_up_questions(domain, sensitivity_level)
    critical_integrity_snapshot = build_critical_integrity_snapshot(
        text,
        domain=domain,
        text_type=resolved_text_type,
        sensitivity=sensitivity_level,
        bias_hits=bias_hits,
        assumptions=assumptions,
        methodology=methodology,
        alternative_frames=alternative_frames,
        insufficient=insufficient,
        snapshot_mode=snapshot_mode,
    )
    replication_readiness = build_replication_readiness(
        text,
        domain=domain,
        text_type=resolved_text_type,
        methodology=methodology,
        bias_hits=bias_hits,
    )
    ai_data_language = ai_data_audit_language(text) if resolved_text_type == "ai_generated" else None
    bias_names = [
        first_text(hit.get("bias_name") or hit.get("title") or hit.get("name") or hit.get("bias_id"))
        for hit in bias_hits
        if isinstance(hit, dict)
    ]
    practice_suggestions = practice_suggestions_for_context(
        domain,
        bias_names,
        text_type=resolved_text_type,
    )

    evidence_note = (
        "Bias labels are conservative and come only from the local knowledge base. "
        "Evidence snippets are capped at 12 words. "
        f"Text type is {resolved_text_type} ({text_type_source}). "
        + ("High sensitivity detected; this response stays person-first and avoids speculation. " if sensitivity_level == "high" else "")
        + (
            "The excerpt is too thin to label bias confidently."
            if bias_mode == "insufficient"
            else "AI-generated text calibration emphasizes synthetic certainty, LLM-bias risk, polished-but-unsupported claims, and missing provenance."
            if resolved_text_type == "ai_generated"
            else "Legal-style text is reviewed for argument, evidence, power, and assumption risks only; this is not legal advice."
            if resolved_text_type == "legal"
            else "Persuasive-document calibration added deterministic structural/framing cues."
            if bias_mode in {"direct_plus_persuasive_cues", "persuasive_cues"}
            else "Research-methodology profile prioritized study design, validity, and replication cues before generic cognitive-bias labels."
            if bias_mode == "research_methodology_profile"
            else "No direct trigger fired, so the bias map uses KB-ranked fallback candidates."
            if bias_mode == "fallback_candidates"
            else "No direct trigger fired, so the bias map uses a review placeholder."
            if bias_mode == "placeholder"
            else "Bias labels are only applied where the text itself supports them."
        )
    )
    if resolved_text_type == "legal" and "not legal advice" not in evidence_note:
        evidence_note += " Legal-style text is reviewed for argument, evidence, power, and assumption risks only; this is not legal advice."
    if resolved_text_type == "ai_generated" and "AI-generated text calibration" not in evidence_note:
        evidence_note += " AI-generated text calibration emphasizes synthetic certainty, LLM-bias risk, polished-but-unsupported claims, and missing provenance."
    if ai_data_language:
        risk_labels = [first_text(item.get("label")) for item in ensure_list(ai_data_language.get("risks")) if isinstance(item, dict)]
        evidence_note += (
            " AI/data audit language names visible risks such as "
            + ", ".join(risk_labels[:3])
            + "; no retrieval was performed by audit_text."
        )

    quality_gate = {
        "relevance": True,
        "accuracy": True,
        "completeness": len(probing) == 3 and len(follow_up) == 3,
        "clarity": True,
        "coherence": True,
        "appropriateness": True,
        "no_summary": True,
    }
    if len(probing) != 3:
        probing = (probing + probing_questions(domain, [], sensitivity_level))[:3]
    if len(follow_up) != 3:
        follow_up = (follow_up + follow_up_questions(domain, sensitivity_level))[:3]

    preview_before_reflection = human_loop_reflection_preview(
        text,
        bias_hits=bias_hits,
        assumptions=assumptions,
        methodology=methodology,
        silent_parse=silent_parse,
    )
    human_loop = build_human_loop(
        stage="judgment" if defer_reflection else "reflection",
        human_loop_mode=human_loop_mode,
        human_loop_state=human_loop_state,
        text_type=resolved_text_type,
        text_type_source=text_type_source,
        domain=domain,
        sensitivity=sensitivity_level,
        depth=depth_value,
        snapshot_mode=normalize_snapshot_mode(snapshot_mode),
        retrieval_profile=resolved_retrieval_profile,
        source_completeness=source_completeness,
        silent_parse=silent_parse,
        preview_before_reflection=None if defer_reflection else preview_before_reflection,
    )
    human_loop_action = human_loop_host_action(human_loop)
    quick_scan_card = build_quick_scan_card(
        text,
        domain=domain,
        text_type=resolved_text_type,
        text_type_source=text_type_source,
        sensitivity=sensitivity_level,
        bias_hits=bias_hits,
        insufficient=insufficient,
        critical_integrity_snapshot=critical_integrity_snapshot,
        replication_readiness=replication_readiness,
    )
    follow_up_activity = follow_up_activity_for_context(
        domain,
        bias_names,
        text_type=resolved_text_type,
        key_tension=quick_scan_card.get("key_tension"),
        recommended_next_step=quick_scan_card.get("recommended_next_step"),
        human_loop_state=human_loop,
        subject_hint=short_phrase(text, 16),
        depth=depth_value,
    )
    practice_suggestions = practice_suggestions_for_context(domain, bias_names, text_type=resolved_text_type)
    quick_scan_card["follow_up_activity"] = {
        "try_this_next": follow_up_activity.get("try_this_next"),
        "source_note": follow_up_activity.get("source_note"),
    }
    artifact_context = {
        "subject_text": text,
        "text_type": resolved_text_type,
        "quick_scan_card": quick_scan_card,
        "critical_integrity_snapshot": critical_integrity_snapshot,
        "biases": bias_hits,
        "assumptions": assumptions,
        "alternative_frames": alternative_frames,
        "probing_questions": probing,
        "follow_up_questions": follow_up,
        "next_steps": [quick_scan_card.get("recommended_next_step")],
        "follow_up_activity": follow_up_activity,
    }
    reasoning_artifacts = build_audit_reasoning_artifacts(artifact_context, text)
    trust_artifacts = build_audit_trust_artifacts(
        {
            **artifact_context,
            "human_loop": human_loop,
            "human_loop_host_action": human_loop_action,
        },
        text,
    )

    return {
        "tool": "audit_text",
        "status": "audit_ready_reflection_pending" if human_loop_action.get("must_pause") else "audit_ready",
        "domain_identification": {
            "domain": domain,
            "sensitivity": sensitivity_level,
            "signals": join_unique(domain_signals + sensitivity_signals),
            "retrieval_profile": resolved_retrieval_profile,
        },
        "quick_scan_card": artifact_context["quick_scan_card"],
        "text_type": resolved_text_type,
        "text_type_source": text_type_source,
        "assumptions": assumptions,
        "bias_map": bias_hits,
        "argument_map": reasoning_artifacts.get("argument_map", {}),
        "checkworthy_claims": reasoning_artifacts.get("checkworthy_claims", {}),
        "reasoning_traps": trust_artifacts.get("reasoning_traps", []),
        "practice_suggestions": practice_suggestions,
        "follow_up_activity": follow_up_activity,
        "human_loop_interruption_triggers": trust_artifacts.get("human_loop_interruption_triggers", []),
        "blind_spot_reminders": trust_artifacts.get("blind_spot_reminders", {}),
        "source_tool_trust_preflight": trust_artifacts.get("source_tool_trust_preflight", {}),
        "retrieval_profile": resolved_retrieval_profile,
        "research_methodology_hits": research_methodology_profile_hits(repo, text) if resolved_retrieval_profile == "research_methodology" else None,
        "ai_data_audit_language": ai_data_language,
        "critical_integrity_snapshot": critical_integrity_snapshot,
        "replication_readiness": replication_readiness,
        "methodology_check": methodology,
        "alternative_frames": alternative_frames,
        "probing_questions": probing,
        "evidence_and_limits": evidence_note,
        "follow_up_questions": follow_up,
        "insufficient_evidence": insufficient,
        "silent_parse": silent_parse,
        "preview_before_reflection": preview_before_reflection,
        "human_loop": human_loop,
        "human_loop_host_action": human_loop_action,
        "report_readiness_contract": report_readiness_contract(depth_value, stage="audit_text", include_advanced=False),
        "quality_gate": quality_gate,
    }


def _scaffold_resource_by_id(resource_id: str) -> dict[str, Any] | None:
    manifest = load_scaffold_resource_manifest()
    for resource in ensure_list(manifest.get("resources")):
        if isinstance(resource, dict) and resource.get("id") == resource_id:
            return resource
    return None


def get_started_payload(topic: str | None = None, audience: str | None = "both") -> dict[str, Any]:
    overview = critical_compass_overview_payload(topic=topic or "quick_start", audience=audience)
    beta_resource = _scaffold_resource_by_id("beta_calibration_intake")
    mcpb_install_resource = _scaffold_resource_by_id("mcpb_install_diagnostics_prompt")
    return {
        "status": "get_started_ready",
        "tool": "get_started",
        "audience": normalize_text(audience) or "both",
        "topic": normalize_overview_topic(topic or "quick_start"),
        "routing_rule": {
            "use_get_started_when": [
                "Call get_started when the user is new to Critical Compass.",
                "The user asks what to do first, how to install/onboard, or how to run their first audit.",
                "The user has text but has not chosen an audit lane yet, or has not said what they want the text to do for which audience.",
                "The user says use Critical Compass without explicitly choosing normal audit, quick scan, claim stress-test, or advanced panel review.",
            ],
            "use_critical_compass_overview_when": [
                "Call critical_compass_overview when the user asks for capability lookup, topic-specific workflow details, report contracts, MCP composition, or tool inventory.",
                "The user is already using Critical Compass and needs to choose among known tools.",
            ],
        },
        "first_five_minutes": [
            {
                "minute": "0-1",
                "action": "If you already have text but no lane, clarify what you want the text to do, who it is for, and whether you need quick scan, normal full audit, or advanced panel review.",
                "best_tool": "get_started",
            },
            {
                "minute": "1-2",
                "action": "Use audit_text for the normal full audit, including assumptions, missing voices, framing openness, stakeholder fit, persuasion risk, the Plain-Language Read, and the Before Using This Text caution.",
                "best_tool": "audit_text",
            },
            {
                "minute": "2-3",
                "action": "Escalate to advanced_audit agent mode only after explicit opt-in such as advanced panel review, agentic panel review, multi-perspective panel, or run the agent audit.",
                "best_tool": "advanced_audit",
            },
            {
                "minute": "3-4",
                "action": "If the source is a PDF, run prepare_audit_source before any audit.",
                "best_tool": "prepare_audit_source",
            },
            {
                "minute": "4-5",
                "action": "For a full report, keep one solo and one group follow-up activity tied to the text; if factual claims need checking, use factcheck_lookup in guided_research mode before browsing.",
                "best_tool": "audit_text",
            },
        ],
        "starter_prompts": [
            "I have text but I am not sure which lane I need. Ask my goal, intended audience, and whether I want a quick, full, or advanced audit, then route me.",
            "Audit this text for hidden assumptions, missing voices, framing openness, stakeholder fit, persuasion risk, and whether it works for the audience I want to reach.",
            "Audit this text and include the plain-language read, the before-use caution, and one solo and one group follow-up activity.",
            "This is high-stakes. Ask whether I want a normal audit or an advanced panel review after clarifying my goal and intended audience.",
            "Prepare this local PDF for audit, then ask my goal and audience before auditing the extracted text.",
            "Show me which advanced-audit personas fit this text if I need a stakeholder-sensitive review.",
        ],
        "agentic_opt_in_rule": {
            "requires_explicit_opt_in": True,
            "safe_phrases": ["advanced panel review", "agentic panel review", "multi-perspective panel", "run the agent audit"],
            "insufficient_phrases_alone": ["agent", "agency", "city council", "panel", "committee", "stakeholders"],
            "default_when_unclear": "Ask one plain lane question or use audit_text for a normal full audit; do not expose agent scaffolds.",
        },
        "beta_feedback": {
            "message": "If an audit result felt wrong, confusing, too harsh, too soft, or culturally narrow, use the beta calibration intake resource.",
            "resource_id": "beta_calibration_intake",
            "resource": beta_resource,
        },
        "distribution_guidance": {
            "preferred_path": "MCPB / Claude Desktop Extension",
            "why": "Closest available non-technical install path: users install a .mcpb from GitHub Releases through Claude Desktop Settings > Extensions instead of editing JSON.",
            "builder_docs": "packaging/mcpb/README.md",
            "diagnostic_prompt_resource_id": "mcpb_install_diagnostics_prompt",
            "diagnostic_prompt_resource": mcpb_install_resource,
            "fallback_note": "Manual JSON config and zip installers are fallback paths, not the preferred release path.",
        },
        "teaching_alignment": {
            "plain_language_read": "Every audit-facing output should include a short, nontechnical read of what the text is doing and the biggest trust/use issue.",
            "before_using_this_text": "Every audit-facing output should include one sentence starting exactly with 'Before using this text,'.",
            "follow_up_activity": "Quick outputs use one compact activity idea; full/advanced reports use one solo and one group activity from the local File-O-Fun teaching activity pack.",
            "source_boundary": "File-O-Fun and Knowledge Atlas are build-time source material only, not runtime dependencies.",
        },
        "overview_reference": {
            "status": overview.get("status"),
            "topic": overview.get("topic"),
            "next_tool_candidates": overview.get("host_ai_routing", {}).get("next_tool_candidates", []),
            "markdown": overview.get("markdown"),
        },
        "next_step": "If the user already has text, clarify goal, intended audience, and desired depth, then choose audit_text unless the user explicitly opts into advanced panel review.",
    }


def quick_scan_payload(
    repo: Repository,
    text: str,
    sensitivity: str | None = None,
    text_type: str | None = None,
    snapshot_mode: str | None = None,
    retrieval_profile: str | None = None,
) -> dict[str, Any]:
    audit = audit_text_payload(
        repo,
        text,
        sensitivity=sensitivity,
        text_type=text_type,
        snapshot_mode=snapshot_mode,
        retrieval_profile=retrieval_profile,
        depth="quick",
        human_loop_mode="silent",
        human_loop_state={"explicit_noninteractive_override": True},
    )
    card = dict(audit.get("quick_scan_card") or {})
    top_biases = ensure_list(card.get("top_biases"))[:2]
    activity = audit.get("follow_up_activity") if isinstance(audit.get("follow_up_activity"), dict) else {}
    compact_activity = {
        "try_this_next": activity.get("try_this_next"),
        "source_note": activity.get("source_note"),
        "fit_check": activity.get("fit_check"),
    }
    return {
        "status": "quick_scan_ready",
        "tool": "quick_scan",
        "scope_note": "Quick scan is a low-activation entry point, not a replacement for audit_text.",
        "text_type": audit.get("text_type") or card.get("text_type"),
        "text_type_source": card.get("text_type_source"),
        "domain_identification": audit.get("domain_identification"),
        "critical_integrity_snapshot": audit.get("critical_integrity_snapshot"),
        "top_biases": top_biases,
        "key_tension": card.get("key_tension"),
        "recommended_next_step": card.get("recommended_next_step"),
        "follow_up_activity": compact_activity,
        "run_next": {
            "tool": "audit_text",
            "reason": "Use audit_text next for assumptions, argument map, check-worthy claims, report readiness, and the full bias/audience analysis.",
            "suggested_arguments": {
                "text": "<same text>",
                "text_type": audit.get("text_type") or card.get("text_type"),
                "snapshot_mode": normalize_snapshot_mode(snapshot_mode),
                "retrieval_profile": audit.get("retrieval_profile"),
            },
        },
    }


def list_agent_personas_payload(
    repo: Repository,
    subject: str | None = None,
    text_type: str | None = None,
    domain_hint: str | None = None,
    sensitivity: str | None = None,
    retrieval_profile: str | None = None,
) -> dict[str, Any]:
    subject_text = subject or "General Critical Compass audit subject."
    _, context = advanced_ranked_flows(
        repo,
        subject_text,
        domain_hint,
        sensitivity,
        text_type=text_type,
        retrieval_profile=retrieval_profile,
        limit=1,
    )
    archetypes = advanced_suggested_persona_archetypes(subject_text, context)
    custom_examples = [
        {
            "user_phrase": "policy analyst",
            "safe_persona_frame": "Policy analyst focused on evidence standards, implementation constraints, affected stakeholders, and decision trade-offs.",
            "recommended_bucket": "evidence_argument",
        },
        {
            "user_phrase": "community organizer",
            "safe_persona_frame": "Community organizer focused on missing voices, power, mobilization risk, accountability, and concrete next actions.",
            "recommended_bucket": "structural_relational",
        },
        {
            "user_phrase": "Indigenous knowledge holder",
            "safe_persona_frame": "Missing-voice and knowledge-tradition check that asks whether Indigenous, local, or community sources with standing are present; do not impersonate identity or claim lived authority.",
            "recommended_bucket": "structural_relational",
        },
        {
            "user_phrase": "grant reviewer / evidence steward",
            "safe_persona_frame": "Evidence steward focused on outcome metrics, denominators, comparison groups, reporting completeness, and whether the claim is ready for funder-facing use.",
            "recommended_bucket": "uncertainty_methodology",
        },
        {
            "user_phrase": "affected-community reviewer",
            "safe_persona_frame": "Affected-community standpoint focused on missing voices, burdens, repair, accessibility, and what people affected by the text would need to see; do not claim lived authority.",
            "recommended_bucket": "structural_relational",
        },
        {
            "user_phrase": "AI/data auditor",
            "safe_persona_frame": "AI/data auditor focused on provenance gaps, metric or benchmark bias, dataset shift, representation gaps, and visible claims of model or data readiness.",
            "recommended_bucket": "uncertainty_methodology",
        },
        {
            "user_phrase": "public accountability editor",
            "safe_persona_frame": "Public accountability editor focused on responsibility, repair, defensiveness, timing, and the concrete next action a public reader can trust.",
            "recommended_bucket": "communication_task",
        },
        {
            "user_phrase": "accessibility reviewer",
            "safe_persona_frame": "Accessibility reviewer focused on barriers, excluded users, plain-language access, accommodation assumptions, and service-delivery consequences; do not speak for disabled communities.",
            "recommended_bucket": "structural_relational",
        },
    ]
    return {
        "status": "agent_personas_ready",
        "tool": "list_agent_personas",
        "context": {
            "text_type": context.get("text_type"),
            "text_type_source": context.get("text_type_source"),
            "domain": context.get("domain"),
            "sensitivity": context.get("sensitivity"),
            "retrieval_profile": context.get("retrieval_profile"),
        },
        "default_agent_count": 4,
        "default_archetypes": archetypes,
        "custom_persona_schema": {
            "name": "<short persona name>",
            "epistemic_archetype": "<evidence_argument | systems_causal | uncertainty_methodology | structural_relational | creative_reframing | communication_task>",
            "reasoning_philosophy": "<what this persona prioritizes in this text>",
            "primary_reasoning_style": "<one of the public advanced-audit reasoning styles>",
            "secondary_reasoning_style": "<one of the public advanced-audit reasoning styles>",
            "tool_affinities": ["lookup_bias", "challenge_claim", "get_framework"],
            "decision_making_voice": "<evidence | pattern | absence | harm | constraints | possibility>",
            "characteristic_blind_spot": "<what this persona may underweight>",
            "cis_dimensions_to_watch": [label for _, label in SNAPSHOT_DIMENSIONS[:2]],
            "framework_attachment": None,
        },
        "supported_custom_examples": custom_examples,
        "atlas_persona_seed_guidance": {
            "source": "Atlas-informed Pressure-Test Readiness roadmap",
            "rule": "Use seeds as analytical standpoints for better questions; they are not identity roleplay or claims of lived authority.",
            "recommended_seeds": [
                "grant reviewer / evidence steward",
                "affected-community reviewer",
                "AI/data auditor",
                "public accountability editor",
                "accessibility reviewer",
            ],
        },
        "guardrails": [
            "Personas are analytical standpoints, not claims of lived identity.",
            "Use Indigenous, local, community, disability, racial, gender, or other lived-position requests as missing-voice and evidence-with-standing checks unless the user supplies real source material from that community.",
            "Do not impersonate protected identities or present the MCP/host as a member of a community.",
            "Attach frameworks only when they fit the subject; use framework_attachment=null when the persona is stronger than any available model.",
            "For governance, policy, advocacy, community, equity, stakeholder, or harm texts, include a Missing Voice or Absent Stakeholder persona.",
        ],
        "next_tool": {
            "tool": "define_audit_agents",
            "reason": "Use this after choosing personas; it returns the agent-definition scaffold for advanced_audit.",
        },
    }


def _result_cis_points(result: dict[str, Any]) -> int | None:
    value = result.get("cis_points")
    if isinstance(value, int):
        return value
    snapshot = result.get("critical_integrity_snapshot") if isinstance(result.get("critical_integrity_snapshot"), dict) else {}
    value = snapshot.get("points") if isinstance(snapshot, dict) else None
    return value if isinstance(value, int) else None


def _result_display_state(result: dict[str, Any]) -> str:
    return first_text(result.get("cis_display_state")) or first_text((result.get("critical_integrity_snapshot") or {}).get("display_state"))


def _result_snapshot_mode(result: dict[str, Any]) -> str:
    return first_text(result.get("snapshot_mode")) or first_text((result.get("critical_integrity_snapshot") or {}).get("snapshot_mode"))


def _result_has_advanced_audit(result: dict[str, Any]) -> bool:
    payload = result.get("result_payload") if isinstance(result.get("result_payload"), dict) else {}
    return bool(payload.get("advanced_audit") or payload.get("agents") or payload.get("analyses") or payload.get("debate"))


def compare_result_from_payload(payload: dict[str, Any], fallback_id: str) -> dict[str, Any]:
    if not isinstance(payload, dict) or not payload:
        return {"found": False, "result_id": fallback_id, "reason": "Inline result payload must be a non-empty object."}
    snapshot = {}
    for key in ("critical_integrity_snapshot", "cis_snapshot", "cis"):
        value = payload.get(key)
        if isinstance(value, dict):
            snapshot = dict(value)
            break
    if not snapshot:
        return {"found": False, "result_id": fallback_id, "reason": "Inline result payload must include critical_integrity_snapshot or cis."}
    context_lens = snapshot.get("context_lens") if isinstance(snapshot.get("context_lens"), dict) else {}
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    dimensions = [item for item in ensure_list(snapshot.get("dimensions") or payload.get("dimensions")) if isinstance(item, dict)]
    biases = [
        item
        for item in ensure_list(
            payload.get("biases_found")
            or payload.get("top_biases")
            or findings.get("biases")
            or findings.get("top_biases")
        )
        if isinstance(item, dict)
    ]
    subject_text = (
        first_text(payload.get("subject_text"))
        or first_text(payload.get("source_text"))
        or first_text(payload.get("text"))
        or first_text((payload.get("appendix") or {}).get("subject_text") if isinstance(payload.get("appendix"), dict) else "")
        or fallback_id
    )
    text_type = first_text(payload.get("text_type")) or first_text(meta.get("text_type"))
    return {
        "found": True,
        "result_id": first_text(payload.get("result_id")) or fallback_id,
        "text_id": first_text(payload.get("text_id")) or fallback_id,
        "text_type": text_type,
        "cis_display_state": first_text(snapshot.get("display_state")),
        "cis_label": first_text(snapshot.get("label")),
        "cis_points": snapshot.get("points") if isinstance(snapshot.get("points"), int) else None,
        "cis_max_points": snapshot.get("max_points") if isinstance(snapshot.get("max_points"), int) else None,
        "score_confidence": first_text(snapshot.get("score_confidence")),
        "comparability": first_text(snapshot.get("comparability")),
        "snapshot_mode": first_text(snapshot.get("snapshot_mode")),
        "evidence_convention": first_text(context_lens.get("evidence_convention")),
        "purpose": first_text(context_lens.get("purpose")),
        "voice": first_text(context_lens.get("voice")),
        "knowledge_tradition": first_text(snapshot.get("knowledge_tradition")) or first_text(context_lens.get("knowledge_tradition")),
        "subject_text": subject_text,
        "summary": first_text(payload.get("summary")),
        "context_lens": context_lens,
        "critical_integrity_snapshot": snapshot,
        "replication_readiness": payload.get("replication_readiness") if isinstance(payload.get("replication_readiness"), dict) else {},
        "biases_found": biases,
        "dimensions": dimensions,
        "verdict": payload.get("verdict") if isinstance(payload.get("verdict"), dict) else {},
        "result_payload": payload.get("result_payload") if isinstance(payload.get("result_payload"), dict) else payload,
        "input_source": "inline_payload",
    }


def _bias_key(item: dict[str, Any]) -> str:
    return normalize_text(first_text(item.get("bias_id") or item.get("id") or item.get("bias_name") or item.get("name")))


def framing_drift_check_scaffold(comparability: str) -> dict[str, Any]:
    return {
        "status": "scaffold_only",
        "use_when": "Use this as a host-AI prose check when two saved or already-audited inline results appear to be different drafts or revisions of related text.",
        "comparability_caution": "Describe framing movement; do not claim the draft improved unless compare_audit_results returns comparability='direct'.",
        "checks": [
            {
                "area": "Audience posture",
                "prompt": "Name whether the newer draft opens, narrows, moralizes, softens, or redirects the intended audience.",
            },
            {
                "area": "Claim strength",
                "prompt": "Name which claims became stronger, weaker, more qualified, or more sweeping.",
            },
            {
                "area": "Missing voices",
                "prompt": "Check whether affected stakeholders became more visible, stayed absent, or were flattened into generic language.",
            },
            {
                "area": "Persuasion risk",
                "prompt": "Check whether urgency, authority language, emotional appeal, or certainty increased beyond the evidence.",
            },
        ],
        "next_step": "If this scaffold repeatedly proves useful in smoke tests, promote it to a dedicated two-draft framing-drift workflow.",
        "current_comparability": comparability,
    }


def compare_audit_results_payload(
    state: StateStore,
    result_id_a: str | None = None,
    result_id_b: str | None = None,
    *,
    result_payload_a: dict[str, Any] | None = None,
    result_payload_b: dict[str, Any] | None = None,
) -> dict[str, Any]:
    has_any_id = bool(result_id_a or result_id_b)
    has_ids = bool(result_id_a and result_id_b)
    has_payloads = isinstance(result_payload_a, dict) or isinstance(result_payload_b, dict)
    if has_any_id and has_payloads:
        return {
            "status": "validation_error",
            "tool": "compare_audit_results",
            "comparability": "not_comparable",
            "warnings": ["Pass either two saved result IDs or two already-audited inline payloads, not a mixed ID/payload request."],
        }
    if has_payloads:
        if not isinstance(result_payload_a, dict) or not isinstance(result_payload_b, dict):
            return {
                "status": "validation_error",
                "tool": "compare_audit_results",
                "comparability": "not_comparable",
                "warnings": ["Inline comparison requires both result_payload_a and result_payload_b."],
            }
        a = compare_result_from_payload(result_payload_a, "inline:a")
        b = compare_result_from_payload(result_payload_b, "inline:b")
    else:
        a = state.get_audit_result(result_id_a or "")
        b = state.get_audit_result(result_id_b or "")
    if not a.get("found") or not b.get("found"):
        return {
            "status": "not_comparable",
            "tool": "compare_audit_results",
            "comparability": "not_comparable",
            "result_id_a": result_id_a,
            "result_id_b": result_id_b,
            "missing_results": [
                result_id for result_id, result in [(result_id_a, a), (result_id_b, b)] if not result.get("found")
            ],
            "warnings": ["One or both audit results could not be loaded or parsed as already-audited payloads."],
        }

    a_points = _result_cis_points(a)
    b_points = _result_cis_points(b)
    a_display = _result_display_state(a)
    b_display = _result_display_state(b)
    a_dimensions = {first_text(item.get("name") or item.get("dimension_name")): item for item in ensure_list(a.get("dimensions")) if isinstance(item, dict)}
    b_dimensions = {first_text(item.get("name") or item.get("dimension_name")): item for item in ensure_list(b.get("dimensions")) if isinstance(item, dict)}
    usable = bool(a.get("critical_integrity_snapshot") and b.get("critical_integrity_snapshot") and (a_dimensions or b_dimensions or a_points is not None or b_points is not None))
    a_text_hash = sha256_text(re.sub(r"\s+", " ", first_text(a.get("subject_text"))))
    b_text_hash = sha256_text(re.sub(r"\s+", " ", first_text(b.get("subject_text"))))
    same_text = a.get("text_id") == b.get("text_id") or a_text_hash == b_text_hash
    same_text_type = first_text(a.get("text_type")) == first_text(b.get("text_type"))
    same_snapshot_mode = _result_snapshot_mode(a) == _result_snapshot_mode(b)
    same_evidence = first_text(a.get("evidence_convention")) == first_text(b.get("evidence_convention"))
    same_purpose = first_text(a.get("purpose")) == first_text(b.get("purpose"))
    same_knowledge = first_text(a.get("knowledge_tradition")) == first_text(b.get("knowledge_tradition"))
    both_scored = a_display == "scored" and b_display == "scored" and isinstance(a_points, int) and isinstance(b_points, int)
    a_advanced = _result_has_advanced_audit(a)
    b_advanced = _result_has_advanced_audit(b)

    warnings: list[str] = []
    if not same_text_type:
        warnings.append("Text types differ; treat score and bias deltas as weak comparison signals.")
    if a_advanced != b_advanced:
        warnings.append("One result includes advanced-audit material and the other does not.")
    if a_display == "profile_only" or b_display == "profile_only":
        warnings.append("At least one result is profile-only, so aggregate score deltas should not be used.")
    context_fields = {
        "evidence_convention": same_evidence,
        "purpose": same_purpose,
        "voice": first_text(a.get("voice")) == first_text(b.get("voice")),
        "knowledge_tradition": same_knowledge,
        "snapshot_mode": same_snapshot_mode,
    }
    changed_context = [field for field, same in context_fields.items() if not same]
    if changed_context:
        warnings.append(f"Context lens fields differ: {', '.join(changed_context)}.")

    if not usable:
        comparability = "not_comparable"
    elif same_text and same_text_type and same_snapshot_mode and both_scored and same_evidence:
        comparability = "direct"
    elif same_text_type and both_scored and (same_evidence or same_purpose) and a_display != "profile_only" and b_display != "profile_only":
        comparability = "qualified"
    else:
        comparability = "weak"
    if comparability != "direct":
        warnings.append("This comparison is descriptive, not proof that one draft improved.")

    dimension_names = sorted(set(a_dimensions) | set(b_dimensions))
    dimension_deltas = []
    for name in dimension_names:
        left = a_dimensions.get(name) or {}
        right = b_dimensions.get(name) or {}
        left_points = left.get("points") if isinstance(left.get("points"), int) else None
        right_points = right.get("points") if isinstance(right.get("points"), int) else None
        dimension_deltas.append(
            {
                "dimension": name,
                "a_points": left_points,
                "b_points": right_points,
                "delta": right_points - left_points if isinstance(left_points, int) and isinstance(right_points, int) else None,
                "a_rationale": left.get("rationale"),
                "b_rationale": right.get("rationale"),
            }
        )

    a_biases = {_bias_key(item): item for item in ensure_list(a.get("biases_found")) if isinstance(item, dict) and _bias_key(item)}
    b_biases = {_bias_key(item): item for item in ensure_list(b.get("biases_found")) if isinstance(item, dict) and _bias_key(item)}
    shared_keys = sorted(set(a_biases) & set(b_biases))
    added_keys = sorted(set(b_biases) - set(a_biases))
    removed_keys = sorted(set(a_biases) - set(b_biases))

    return {
        "status": "comparison_ready" if comparability != "not_comparable" else "not_comparable",
        "tool": "compare_audit_results",
        "comparability": comparability,
        "result_a": {
            "result_id": a.get("result_id"),
            "text_id": a.get("text_id"),
            "text_type": a.get("text_type"),
            "cis_label": a.get("cis_label"),
            "cis_points": a_points,
            "display_state": a_display,
            "snapshot_mode": _result_snapshot_mode(a),
            "advanced_audit_present": a_advanced,
        },
        "result_b": {
            "result_id": b.get("result_id"),
            "text_id": b.get("text_id"),
            "text_type": b.get("text_type"),
            "cis_label": b.get("cis_label"),
            "cis_points": b_points,
            "display_state": b_display,
            "snapshot_mode": _result_snapshot_mode(b),
            "advanced_audit_present": b_advanced,
        },
        "cis_delta": {
            "a_label": a.get("cis_label"),
            "b_label": b.get("cis_label"),
            "label_changed": a.get("cis_label") != b.get("cis_label"),
            "a_points": a_points,
            "b_points": b_points,
            "delta": b_points - a_points if isinstance(a_points, int) and isinstance(b_points, int) else None,
            "display_state_changed": a_display != b_display,
        },
        "dimension_deltas": dimension_deltas,
        "bias_diff": {
            "shared": [a_biases[key] for key in shared_keys],
            "added_in_b": [b_biases[key] for key in added_keys],
            "removed_from_a": [a_biases[key] for key in removed_keys],
        },
        "workflow_differences": {
            "input_source_a": a.get("input_source") or "saved_result",
            "input_source_b": b.get("input_source") or "saved_result",
            "same_saved_text": same_text,
            "same_text_type": same_text_type,
            "same_snapshot_mode": same_snapshot_mode,
            "same_evidence_convention": same_evidence,
            "same_purpose": same_purpose,
            "same_knowledge_tradition": same_knowledge,
            "advanced_audit_present_a": a_advanced,
            "advanced_audit_present_b": b_advanced,
        },
        "framing_drift_check": framing_drift_check_scaffold(comparability),
        "warnings": join_unique(warnings),
    }


def kb_addition_category(entry_type: str | None, category: str | None) -> tuple[str, str]:
    entry = normalize_entity_type(entry_type)
    if category:
        return category, entry if entry != "kb_entry" else "framework"
    if entry == "bias":
        return "biases", "bias"
    if entry == "fallacy":
        return "fallacies", "fallacy"
    if entry == "reasoning_flow":
        return "methodology-checks", "methodology"
    if entry in {"thinking_lens", "framework"}:
        return "thinking-lenses", "framework"
    return "other", entry if entry != "kb_entry" else "framework"


def canonical_duplicate_candidates(repo: Repository, title: str, aliases: list[str] | None, category: str | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    probes = [title, *(aliases or [])]
    exact: list[dict[str, Any]] = []
    near: list[dict[str, Any]] = []
    seen_exact: set[str] = set()
    seen_near: set[str] = set()
    for probe in probes:
        probe_norm = normalize_text(probe)
        if not probe_norm:
            continue
        rows = repo.resolve(probe, category=category, limit=5)
        if not rows and category:
            rows = repo.resolve(probe, limit=5)
        for row in rows:
            row_values = [row.get("concept_id"), row.get("entry_id"), row.get("slug"), row.get("title"), *ensure_list(row.get("aliases"))]
            is_exact = any(normalize_text(first_text(value)) == probe_norm for value in row_values)
            item = {
                "source_scope": "canonical",
                "id": row.get("concept_id"),
                "title": row.get("title"),
                "category": row.get("category"),
                "kind": row.get("kind"),
                "suggested_action": "Use this existing KB entry or add the new label as an alias in a user overlay note.",
            }
            if is_exact and row.get("concept_id") not in seen_exact:
                exact.append(item)
                seen_exact.add(row.get("concept_id"))
            elif row.get("concept_id") not in seen_near:
                near.append(item)
                seen_near.add(row.get("concept_id"))
    return exact, near[:5]


def build_kb_addition_payload(
    *,
    entry_type: str | None,
    category: str | None,
    kind: str | None,
    title: str,
    definition: str,
    summary: str | None = None,
    aliases: list[str] | None = None,
    tags: list[str] | None = None,
    related_entry_ids: list[str] | None = None,
    signals: list[str] | None = None,
    examples: list[str] | None = None,
    notes: str | None = None,
    rhetorical_tradition: str | None = None,
    subcategory: str | None = None,
) -> dict[str, Any]:
    resolved_category, resolved_kind = kb_addition_category(entry_type, category)
    if kind:
        resolved_kind = kind
    return {
        "title": title,
        "kind": resolved_kind,
        "category": resolved_category,
        "subcategory": subcategory or "user-addition",
        "summary": summary or short_phrase(definition, 24),
        "definition": definition,
        "help": notes,
        "aliases": aliases or [],
        "tags": tags or [],
        "related_entry_ids": related_entry_ids or [],
        "signals": signals or [],
        "examples": examples or [],
        "notes": notes,
        "rhetorical_tradition": normalize_rhetorical_tradition(rhetorical_tradition),
        "confidence_weight": "medium",
        "three_cs_lens": "Critical",
    }


def with_source_scope(payload: dict[str, Any], scope: str) -> dict[str, Any]:
    if not payload.get("found", True):
        return payload
    payload = dict(payload)
    payload.setdefault("source_scope", scope)
    payload.setdefault("editable", scope == "user_overlay")
    return payload


def build_server(repo: Repository, state: StateStore) -> FastMCP:
    server = FastMCP(
        name="critical-compass",
        instructions=(
            "Critical Compass MCP: local-only deterministic critical-thinking retrieval. "
            "The canonical KB is read-only; audit state and user-added KB overlays are writable."
        ),
        log_level="ERROR",
    )

    @server.tool(description="Explain what Critical Compass can do, with user-facing workflows, case studies, starter prompts, and host-AI routing guidance. Use this as the onboarding/start-here tool before choosing a specific audit, claim, report, knowledge-base, or saved-pattern workflow. If the user has text but no lane, use this or get_started to clarify goal, intended audience, and desired depth before analysis.", annotations=READ_ONLY, structured_output=True)
    def critical_compass_overview(
        topic: str | None = None,
        audience: str | None = "both",
    ) -> dict[str, Any]:
        return critical_compass_overview_payload(topic=topic, audience=audience)

    @server.tool(description="First-session onboarding for Critical Compass. Call get_started for new users, installation/onboarding, 'what do I do first?', or first audit setup. If the user has text but has not chosen a lane, first clarify goal, intended audience, and whether they want quick, full, or advanced review. Use critical_compass_overview instead for capability lookup, topic-specific workflows, report contracts, MCP composition, and existing users choosing among tools.", annotations=READ_ONLY, structured_output=True)
    def get_started(
        topic: str | None = None,
        audience: str | None = "both",
    ) -> dict[str, Any]:
        return get_started_payload(topic=topic, audience=audience)

    @server.tool(description="List user-friendly examples of Critical Compass concepts: biases, fallacies, thinking lenses, reasoning frameworks, methodology checks, or broader patterns. Use query for KB-backed matches; otherwise returns curated starter examples and next-tool suggestions.", annotations=READ_ONLY, structured_output=True)
    def list_concept_examples(
        category: str | None = None,
        query: str | None = None,
        limit: int = 8,
    ) -> dict[str, Any]:
        return list_concept_examples_payload(repo, category=category, query=query, limit=limit)

    @server.tool(description=f"Audit text for bias, assumptions, alternative frames, intended-audience fit, framing openness, stakeholder fit, persuasion risk, and a Critical Integrity Snapshot. text_type may be {TEXT_TYPE_OPTIONS}, or other/general. snapshot_mode may be organizer or research. retrieval_profile may be auto, general, or research_methodology. human_loop_mode may be guided, minimal, or silent; silent requires user-confirmed consent in human_loop_state or an explicit noninteractive smoke-test override. human_loop_state carries bounded-decision-rights state across turns. User-facing audits default to guided. The host must use Claude Desktop/Codex native question UI first when human_loop_host_action.must_pause=true, ask only the current questions_for_user block, and never ask the full Human Loop questionnaire at once. Guided mode asks onboarding before the core audit, judgment before revealing findings, and reflection after preview_before_reflection before final output. Unauthorized silent requests return mode_consent first and do not run the audit. Returns report_readiness_contract with the canonical PDF payload template, completed example, and Markdown checkpoint template.", annotations=READ_ONLY, structured_output=True)
    def audit_text(
        text: str,
        sensitivity: str | None = None,
        text_type: str | None = None,
        snapshot_mode: str | None = None,
        retrieval_profile: str | None = None,
        human_loop_mode: str | None = None,
        human_loop_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return audit_text_payload(repo, text, sensitivity, text_type=text_type, snapshot_mode=snapshot_mode, retrieval_profile=retrieval_profile, human_loop_mode=human_loop_mode, human_loop_state=human_loop_state)

    @server.tool(description="Quick scan a text as a lightweight demo/entry point. Returns only the Critical Integrity Snapshot, top 2 biases, key tension, one recommended action, text type, and guidance to run audit_text next for the full audit. This is not a replacement for audit_text.", annotations=READ_ONLY, structured_output=True)
    def quick_scan(
        text: str,
        sensitivity: str | None = None,
        text_type: str | None = None,
        snapshot_mode: str | None = None,
        retrieval_profile: str | None = None,
    ) -> dict[str, Any]:
        return quick_scan_payload(
            repo,
            text,
            sensitivity=sensitivity,
            text_type=text_type,
            snapshot_mode=snapshot_mode,
            retrieval_profile=retrieval_profile,
        )

    @server.tool(description=f"Run a guided, reasoning-flow-backed audit in user-selected, ai-selected, or agent mode. Use this when the user needs a thorough, multi-perspective, stakeholder-sensitive, high-stakes, or audience-fit / persuasion-effectiveness review that should stay inside Critical Compass first. Agent mode requires explicit opt-in such as advanced panel review, agentic panel review, multi-perspective panel, or run the agent audit; generic words like agent, agency, city council, panel, committee, or stakeholders are not enough by themselves. text_type may be {TEXT_TYPE_OPTIONS}, or other/general. depth may be quick, standard, or deep; synthesis_audience may be reader, author, or both; snapshot_mode may be organizer or research; scaffold_detail may be compact, full, or handoff; retrieval_profile may be auto, general, or research_methodology. host_capability_profile declares whether the host has native subagents or must use sequential fallback. agentic_state carries plan approval, plan hash, progress, and revision state. human_loop_mode may be guided, minimal, or silent; silent requires user-confirmed consent in human_loop_state or an explicit noninteractive smoke-test override. human_loop_state carries bounded-decision-rights state across turns. If the user has text but no clear lane, clarify goal, intended audience, and desired depth before exposing scaffolds. If human_loop_host_action.must_pause=true, use Claude Desktop/Codex native question UI first, ask only the current questions_for_user block, and never ask the full Human Loop questionnaire at once. Onboarding and judgment gates must clear before advanced agent scaffolding is exposed; reflection is handled before final synthesis/report output. Adjacent frameworks such as JTBD are optional follow-on helpers after the core Critical Compass audit, not replacements for it. Returns report_readiness_contract so the host AI knows the exact generate_audit_report fields before analysis starts.", annotations=READ_ONLY, structured_output=True)
    def advanced_audit(
        subject: str,
        mode: str,
        selected_flow_id: str | None = None,
        domain_hint: str | None = None,
        sensitivity: str | None = None,
        text_type: str | None = None,
        synthesis_audience: str | None = None,
        max_candidate_models: int = 8,
        resume_from: str | None = None,
        prior_stage_payload: dict[str, Any] | None = None,
        depth: str | None = None,
        snapshot_mode: str | None = None,
        scaffold_detail: str | None = None,
        retrieval_profile: str | None = None,
        human_loop_mode: str | None = None,
        human_loop_state: dict[str, Any] | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return advanced_audit_payload(
            repo,
            subject,
            mode,
            selected_flow_id=selected_flow_id,
            domain_hint=domain_hint,
            sensitivity=sensitivity,
            text_type=text_type,
            synthesis_audience=synthesis_audience,
            max_candidate_models=max_candidate_models,
            resume_from=resume_from,
            prior_stage_payload=prior_stage_payload,
            depth=depth,
            snapshot_mode=snapshot_mode,
            scaffold_detail=scaffold_detail,
            retrieval_profile=retrieval_profile,
            human_loop_mode=human_loop_mode,
            human_loop_state=human_loop_state,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )

    @server.tool(description="List advanced-audit persona archetypes and custom-persona guidance. Use before define_audit_agents when users ask what analyst roles are available or want custom agents such as a policy analyst, community organizer, or missing-voice/knowledge-tradition reviewer.", annotations=READ_ONLY, structured_output=True)
    def list_agent_personas(
        subject: str | None = None,
        text_type: str | None = None,
        domain_hint: str | None = None,
        sensitivity: str | None = None,
        retrieval_profile: str | None = None,
    ) -> dict[str, Any]:
        return list_agent_personas_payload(
            repo,
            subject=subject,
            text_type=text_type,
            domain_hint=domain_hint,
            sensitivity=sensitivity,
            retrieval_profile=retrieval_profile,
        )

    @server.tool(description="Return the agent-definition scaffold for advanced_audit. This defines analyst personas; it does not perform analysis.", annotations=READ_ONLY, structured_output=True)
    def define_audit_agents(
        subject: str,
        text_type: str | None = None,
        domain_hint: str | None = None,
        sensitivity: str | None = None,
        synthesis_audience: str | None = None,
        candidate_model_pool: list[dict[str, Any]] | None = None,
        depth: str | None = None,
        scaffold_detail: str | None = None,
        retrieval_profile: str | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return define_audit_agents_payload(
            repo,
            subject,
            text_type=text_type,
            domain_hint=domain_hint,
            sensitivity=sensitivity,
            synthesis_audience=synthesis_audience,
            candidate_model_pool=candidate_model_pool,
            depth=depth,
            scaffold_detail=scaffold_detail,
            retrieval_profile=retrieval_profile,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )

    @server.tool(description="Return the independent-analysis scaffold for advanced_audit. The host AI executes it and should call lookup_bias, challenge_claim, and get_framework/get_pattern while reasoning. host_capability_profile and agentic_state carry the agent execution adapter, progress state, and compact artifact handoff contract.", annotations=READ_ONLY, structured_output=True)
    def run_independent_audit_analysis(
        subject: str,
        agents: list[dict[str, Any]],
        text_type: str | None = None,
        sensitivity: str | None = None,
        depth: str | None = None,
        scaffold_detail: str | None = None,
        retrieval_profile: str | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return run_independent_audit_analysis_payload(subject, agents, text_type=text_type, sensitivity=sensitivity, depth=depth, scaffold_detail=scaffold_detail, retrieval_profile=retrieval_profile, host_capability_profile=host_capability_profile, agentic_state=agentic_state)

    @server.tool(description="Return the tension-map scaffold for advanced_audit. The host AI maps disagreements from completed independent analyses while preserving compact artifact-only handoff.", annotations=READ_ONLY, structured_output=True)
    def map_audit_tensions(
        analyses: list[dict[str, Any]],
        subject: str | None = None,
        scaffold_detail: str | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return map_audit_tensions_payload(analyses, subject=subject, scaffold_detail=scaffold_detail, host_capability_profile=host_capability_profile, agentic_state=agentic_state)

    @server.tool(description="Return the structured-debate scaffold for advanced_audit. The host AI stages a three-turn debate from a selected tension and carries only compact artifacts forward.", annotations=READ_ONLY, structured_output=True)
    def run_audit_debate(
        subject: str,
        agents: list[dict[str, Any]],
        analyses: list[dict[str, Any]],
        tensions: list[dict[str, Any]],
        scaffold_detail: str | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return run_audit_debate_payload(subject, agents, analyses, tensions, scaffold_detail=scaffold_detail, host_capability_profile=host_capability_profile, agentic_state=agentic_state)

    @server.tool(description="Return the synthesis scaffold for advanced_audit. The host AI commits to one findings decision, confirms/revises/withholds the Critical Integrity Snapshot, calls suggest_next_steps with biases_found as a JSON array, compiles report_ready_materials with canonical generate_audit_report keys when PDF output was requested, then shows preview_before_reflection and collects reflection prompts before final output. human_loop_mode may be guided, minimal, or silent; silent requires user-confirmed consent in human_loop_state or an explicit noninteractive smoke-test override. If human_loop_host_action.must_pause=true, use Claude Desktop/Codex native question UI first, ask only the current questions_for_user block, and never ask the full Human Loop questionnaire at once. A pending mode_consent or reflection gate must clear before saving or generating a final report.", annotations=READ_ONLY, structured_output=True)
    def synthesize_audit_verdict(
        subject: str,
        agents: list[dict[str, Any]],
        analyses: list[dict[str, Any]],
        tensions: list[dict[str, Any]],
        debate: dict[str, Any],
        text_type: str | None = None,
        synthesis_audience: str | None = "both",
        biases_found: list[str] | None = None,
        depth: str | None = None,
        snapshot_mode: str | None = None,
        scaffold_detail: str | None = None,
        human_loop_mode: str | None = None,
        human_loop_state: dict[str, Any] | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return synthesize_audit_verdict_payload(
            subject,
            agents,
            analyses,
            tensions,
            debate,
            text_type=text_type,
            synthesis_audience=synthesis_audience,
            biases_found=biases_found,
            depth=depth,
            snapshot_mode=snapshot_mode,
            scaffold_detail=scaffold_detail,
            human_loop_mode=human_loop_mode,
            human_loop_state=human_loop_state,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )

    @server.tool(description="Return the deep-mode mitigation rewrite scaffold. The host AI rewrites one problematic sentence after synthesis.", annotations=READ_ONLY, structured_output=True)
    def propose_mitigation_rewrite(
        subject: str,
        verdict: dict[str, Any] | None = None,
        primary_bias: str | None = None,
        depth: str | None = "deep",
        scaffold_detail: str | None = None,
        host_capability_profile: dict[str, Any] | None = None,
        agentic_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return propose_mitigation_rewrite_payload(
            subject,
            verdict=verdict,
            primary_bias=primary_bias,
            depth=depth,
            scaffold_detail=scaffold_detail,
            host_capability_profile=host_capability_profile,
            agentic_state=agentic_state,
        )

    @server.tool(description=REPORT_TOOL_DESCRIPTION, annotations=WRITE_LOCAL, structured_output=True)
    def generate_audit_report(
        audit_data: dict[str, Any],
        report_audience: str | None = None,
        report_depth: str | None = None,
        report_mode: str | None = None,
        include_raw_text: bool = False,
        report_title: str | None = None,
        output_path: str | None = None,
        allow_placeholders: bool = False,
        return_markdown: bool = True,
    ) -> dict[str, Any]:
        return generate_audit_report_file(
            audit_data,
            report_audience=report_audience,
            report_depth=report_depth,
            report_mode=report_mode,
            include_raw_text=include_raw_text,
            report_title=report_title,
            output_path=output_path,
            allow_placeholders=allow_placeholders,
            return_markdown=return_markdown,
        )

    @server.tool(description=SOURCE_PREFLIGHT_DESCRIPTION, annotations=WRITE_LOCAL, structured_output=True)
    def prepare_audit_source(
        source_path: str,
        ocr_mode: str | None = "auto",
        output_dir: str | None = None,
        include_page_images: bool = True,
    ) -> dict[str, Any]:
        return prepare_audit_source_file(
            source_path=source_path,
            ocr_mode=ocr_mode,
            output_dir=output_dir,
            include_page_images=include_page_images,
        )

    @server.tool(description=ARTIFACT_VIEWER_DESCRIPTION, annotations=WRITE_LOCAL, structured_output=True)
    def generate_audit_artifact_viewer(
        manifest_path: str,
        output_path: str | None = None,
    ) -> dict[str, Any]:
        return generate_audit_artifact_viewer_file(
            manifest_path=manifest_path,
            output_path=output_path,
        )

    @server.tool(description=FACTCHECK_LOOKUP_DESCRIPTION, annotations=EXTERNAL_LOOKUP, structured_output=True)
    def factcheck_lookup(
        claims: list[dict[str, Any]],
        provider: str | None = "guided_research",
        language_code: str | None = "en",
        publisher_sites: list[str] | None = None,
        max_age_days: int | None = None,
        allow_external_calls: bool = False,
        allow_sensitive_claims: bool = False,
    ) -> dict[str, Any]:
        return factcheck_lookup_file(
            claims=claims,
            provider=provider,
            language_code=language_code,
            publisher_sites=publisher_sites,
            max_age_days=max_age_days,
            allow_external_calls=allow_external_calls,
            allow_sensitive_claims=allow_sensitive_claims,
        )

    @server.tool(description="Save resumable audit progress, notes, and prior-stage payload into the local Critical Compass state store.", annotations=WRITE_LOCAL, structured_output=True)
    def save_audit_progress(
        subject_text: str | None = None,
        audit_id: str | None = None,
        text_id: str | None = None,
        text_type: str | None = None,
        stage: str | None = None,
        resume_from: str | None = None,
        progress_payload: dict[str, Any] | None = None,
        cis_revision_event: dict[str, Any] | None = None,
        notes: str | None = None,
        next_action: str | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        try:
            return state.save_audit_progress(
                subject_text=subject_text,
                audit_id=audit_id,
                text_id=text_id,
                text_type=text_type,
                stage=stage,
                resume_from=resume_from,
                progress_payload=progress_payload,
                cis_revision_event=cis_revision_event,
                notes=notes,
                next_action=next_action,
                status=status,
            )
        except ValueError as exc:
            return {"saved": False, "error": str(exc)}

    @server.tool(description="Load resumable audit progress and the prior-stage payload for a saved audit.", annotations=READ_ONLY, structured_output=True)
    def get_audit_progress(audit_id: str) -> dict[str, Any]:
        return state.get_audit_progress(audit_id)

    @server.tool(description="Return the chronological Critical Integrity Snapshot revision timeline for a saved audit.", annotations=READ_ONLY, structured_output=True)
    def get_cis_revision_timeline(audit_id: str) -> dict[str, Any]:
        return state.get_cis_revision_timeline(audit_id)

    @server.tool(description="List saved audit progress sessions by status or text_type.", annotations=READ_ONLY, structured_output=True)
    def list_audit_progress(status: str | None = None, text_type: str | None = None, limit: int = 20) -> dict[str, Any]:
        return state.list_audit_progress(status=status, text_type=text_type, limit=limit)

    @server.tool(description="Save a completed audit result, including CIS score columns, dimensions, context lens, biases, verdict, replication readiness, and optional non-persistent activity outcome feedback stored inside result_payload.", annotations=WRITE_LOCAL, structured_output=True)
    def save_audit_result(
        subject_text: str | None = None,
        text_id: str | None = None,
        audit_id: str | None = None,
        text_type: str | None = None,
        critical_integrity_snapshot: dict[str, Any] | None = None,
        biases_found: list[Any] | None = None,
        verdict: dict[str, Any] | None = None,
        replication_readiness: dict[str, Any] | None = None,
        result_payload: dict[str, Any] | None = None,
        activity_outcome: dict[str, Any] | None = None,
        timestamp: str | None = None,
        knowledge_tradition: str | None = None,
    ) -> dict[str, Any]:
        try:
            return state.save_audit_result(
                subject_text=subject_text,
                text_id=text_id,
                audit_id=audit_id,
                text_type=text_type,
                critical_integrity_snapshot=critical_integrity_snapshot,
                biases_found=biases_found,
                verdict=verdict,
                replication_readiness=replication_readiness,
                result_payload=result_payload,
                activity_outcome=activity_outcome,
                timestamp=timestamp,
                knowledge_tradition=knowledge_tradition,
            )
        except ValueError as exc:
            return {"saved": False, "error": str(exc)}

    @server.tool(description="Load one saved audit result by result_id.", annotations=READ_ONLY, structured_output=True)
    def get_audit_result(result_id: str) -> dict[str, Any]:
        return state.get_audit_result(result_id)

    @server.tool(description="Compare two saved audit results or two already-audited inline result payloads. Returns descriptive CIS, dimension, bias, workflow, and context-lens deltas with comparability warnings; score changes are not treated as improvement proof unless comparability is direct. This tool does not audit raw text, run retrieval, or auto-save temporary results.", annotations=READ_ONLY, structured_output=True)
    def compare_audit_results(
        result_id_a: str | None = None,
        result_id_b: str | None = None,
        result_payload_a: dict[str, Any] | None = None,
        result_payload_b: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return compare_audit_results_payload(
            state,
            result_id_a,
            result_id_b,
            result_payload_a=result_payload_a,
            result_payload_b=result_payload_b,
        )

    @server.tool(description="List saved audit results with filters for text type, date, bias, CIS label/score, and low dimension scores.", annotations=READ_ONLY, structured_output=True)
    def list_audit_results(
        text_type: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        bias: str | None = None,
        cis_label: str | None = None,
        cis_score: int | None = None,
        cis_score_min: int | None = None,
        cis_score_max: int | None = None,
        cis_score_below: int | None = None,
        dimension_name: str | None = None,
        dimension_score_below: int | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        return state.list_audit_results(
            text_type=text_type,
            date_from=date_from,
            date_to=date_to,
            bias=bias,
            cis_label=cis_label,
            cis_score=cis_score,
            cis_score_min=cis_score_min,
            cis_score_max=cis_score_max,
            cis_score_below=cis_score_below,
            dimension_name=dimension_name,
            dimension_score_below=dimension_score_below,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
        )

    @server.tool(description="Track a recurring bias pattern for longitudinal self-knowledge.", annotations=WRITE_LOCAL, structured_output=True)
    def save_bias_pattern(
        bias_id: str,
        text_type: str | None = None,
        frequency: int = 1,
        context_note: str | None = None,
        audit_id: str | None = None,
    ) -> dict[str, Any]:
        resolved = state.lookup_kb_addition(bias_id, category="biases") or repo.lookup_bias_public(bias_id)
        entity_id = resolved.get("id") if resolved.get("found", True) else bias_id
        return state.save_entity_pattern(
            entity_type="bias",
            entity_id=entity_id or bias_id,
            text_type=text_type,
            frequency=frequency,
            context_note=context_note,
            audit_id=audit_id,
        )

    @server.tool(description="Track a recurring KB entity pattern across biases, thinking lenses, reasoning flows, frameworks, fallacies, reasoning traps, disagreement patterns, and consent-confirmed non-sensitive blind-spot reminders. For blind spots, prefer save_blind_spot_reminder so explicit consent and sensitive-profile safeguards are enforced.", annotations=WRITE_LOCAL, structured_output=True)
    def save_entity_pattern(
        entity_type: str,
        entity_id: str,
        text_type: str | None = None,
        frequency: int = 1,
        context_note: str | None = None,
        audit_id: str | None = None,
    ) -> dict[str, Any]:
        return state.save_entity_pattern(
            entity_type=entity_type,
            entity_id=entity_id,
            text_type=text_type,
            frequency=frequency,
            context_note=context_note,
            audit_id=audit_id,
        )

    @server.tool(description="Save a consent-confirmed, non-sensitive blind-spot reminder into existing pattern storage. Requires consent_confirmed=true, blocks sensitive personal profiling, and stores entity_type=blind_spot_reminder.", annotations=WRITE_LOCAL, structured_output=True)
    def save_blind_spot_reminder(
        reminder_id: str,
        text_type: str | None = None,
        frequency: int = 1,
        context_note: str | None = None,
        audit_id: str | None = None,
        consent_confirmed: bool = False,
    ) -> dict[str, Any]:
        return state.save_blind_spot_reminder(
            reminder_id=reminder_id,
            text_type=text_type,
            frequency=frequency,
            context_note=context_note,
            audit_id=audit_id,
            consent_confirmed=consent_confirmed,
        )

    @server.tool(description="Summarize recurring saved bias/framework/flow patterns by entity type and text_type.", annotations=READ_ONLY, structured_output=True)
    def get_pattern_summary(entity_type: str | None = None, text_type: str | None = None, limit: int = 20) -> dict[str, Any]:
        return state.get_pattern_summary(entity_type=entity_type, text_type=text_type, limit=limit)

    @server.tool(description="Save a user-added KB entry as a draft by default; active overlay exposure requires confirm_active=true and no duplicate match.", annotations=WRITE_LOCAL, structured_output=True)
    def save_kb_addition(
        title: str,
        definition: str,
        entry_type: str | None = None,
        category: str | None = None,
        kind: str | None = None,
        subcategory: str | None = None,
        summary: str | None = None,
        aliases: list[str] | None = None,
        tags: list[str] | None = None,
        related_entry_ids: list[str] | None = None,
        signals: list[str] | None = None,
        examples: list[str] | None = None,
        notes: str | None = None,
        rhetorical_tradition: str | None = None,
        status: str | None = None,
        confirm_active: bool = False,
        allow_duplicate: bool = False,
    ) -> dict[str, Any]:
        resolved_category, _ = kb_addition_category(entry_type, category)
        exact_duplicates, near_matches = canonical_duplicate_candidates(repo, title, aliases or [], category=resolved_category)
        overlay_duplicates = state.find_kb_addition_duplicates(title, aliases or [])
        duplicate_candidates = exact_duplicates + overlay_duplicates
        if duplicate_candidates and not allow_duplicate:
            return {
                "saved": False,
                "status": "duplicate_detected",
                "duplicate_candidates": duplicate_candidates,
                "near_matches": near_matches,
                "suggested_action": "Use the existing entry, or save a distinct draft with allow_duplicate=true only after confirming this is not an alias.",
            }
        payload = build_kb_addition_payload(
            entry_type=entry_type,
            category=category,
            kind=kind,
            subcategory=subcategory,
            title=title,
            definition=definition,
            summary=summary,
            aliases=aliases,
            tags=tags,
            related_entry_ids=related_entry_ids,
            signals=signals,
            examples=examples,
            notes=notes,
            rhetorical_tradition=rhetorical_tradition,
        )
        result = state.save_kb_addition(
            payload=payload,
            duplicate_candidates=duplicate_candidates,
            status=status,
            confirm_active=confirm_active,
        )
        result["near_matches"] = near_matches
        return result

    @server.tool(description="List user-added KB overlay entries, including draft and inactive records.", annotations=READ_ONLY, structured_output=True)
    def list_kb_additions(status: str | None = None, category: str | None = None, limit: int = 50) -> dict[str, Any]:
        return state.list_kb_additions(status=status, category=category, limit=limit)

    @server.tool(description="Load a user-added KB overlay entry by addition_id or entry_id.", annotations=READ_ONLY, structured_output=True)
    def get_kb_addition(addition_id_or_entry_id: str) -> dict[str, Any]:
        return state.get_kb_addition(addition_id_or_entry_id)

    @server.tool(description="Update a user-added KB overlay entry. Activating an entry requires status='active' and confirm_active=true.", annotations=WRITE_LOCAL, structured_output=True)
    def update_kb_addition(
        addition_id_or_entry_id: str,
        updates: dict[str, Any] | None = None,
        status: str | None = None,
        confirm_active: bool = False,
    ) -> dict[str, Any]:
        return state.update_kb_addition(
            addition_id_or_entry_id,
            updates=updates,
            status=status,
            confirm_active=confirm_active,
        )

    @server.tool(description="Soft-delete a user-added KB overlay entry. Canonical KB entries cannot be deleted by this tool.", annotations=WRITE_LOCAL, structured_output=True)
    def soft_delete_kb_addition(addition_id_or_entry_id: str, reason: str | None = None) -> dict[str, Any]:
        return state.soft_delete_kb_addition(addition_id_or_entry_id, reason=reason)

    @server.tool(description="Resolve one verified bias entry from the knowledge base.", annotations=READ_ONLY, structured_output=True)
    def lookup_bias(name: str) -> dict[str, Any]:
        overlay = state.lookup_kb_addition(name, category="biases")
        if overlay:
            return {"found": True, **overlay}
        return with_source_scope(repo.lookup_bias_public(name), "canonical")

    @server.tool(description="Challenge a single claim with a steelman, named fallacy risk, and probing questions.", annotations=READ_ONLY, structured_output=True)
    def challenge_claim(claim: str) -> dict[str, Any]:
        return challenge_claim_payload(repo, claim)

    @server.tool(description="Return a compact host-renderable Claim Stress-Test card for one claim. Use this for fast user-facing claim interrogation; use challenge_claim inside advanced_audit scaffolds. The MCP owns the structured card data and Markdown fallback; the host AI owns interactive UI rendering. context and audience are optional framing hints.", annotations=READ_ONLY, structured_output=True)
    def claim_stress_test(
        claim: str,
        context: str | None = None,
        audience: str | None = None,
    ) -> dict[str, Any]:
        return claim_stress_test_payload(repo, claim, context=context, audience=audience)

    @server.tool(description="Look up a reasoning framework or thinking lens.", annotations=READ_ONLY, structured_output=True)
    def get_framework(thinking_lens: str) -> dict[str, Any]:
        overlay = state.lookup_kb_addition(
            thinking_lens,
            categories={"reasoning-frameworks", "thinking-lenses", "methodology-checks", "other"},
        )
        if overlay:
            return {"found": True, **overlay}
        return with_source_scope(repo.lookup_framework_public(thinking_lens), "canonical")

    @server.tool(description="Compatibility alias for get_framework.", annotations=READ_ONLY, structured_output=True)
    def get_pattern(thinking_lens: str) -> dict[str, Any]:
        overlay = state.lookup_kb_addition(
            thinking_lens,
            categories={"reasoning-frameworks", "thinking-lenses", "methodology-checks", "other"},
        )
        if overlay:
            return {"found": True, **overlay}
        return with_source_scope(repo.lookup_framework_public(thinking_lens), "canonical")

    @server.tool(description="List Critical Compass categories, counts, and entry IDs for full inventory.", annotations=READ_ONLY, structured_output=True)
    def list_categories() -> dict[str, Any]:
        return repo.list_categories_public()

    @server.tool(description="Resolve a full Critical Compass entry by id, entry id, slug, exact title, or alias.", annotations=READ_ONLY, structured_output=True)
    def get_entry(entry_id_or_slug: str) -> dict[str, Any]:
        overlay = state.lookup_kb_addition(entry_id_or_slug)
        if overlay:
            return {"found": True, **overlay}
        return with_source_scope(repo.get_entry_public(entry_id_or_slug), "canonical")

    @server.tool(description="List available executable reasoning flows for Critical Compass entries.", annotations=READ_ONLY, structured_output=True)
    def list_reasoning_flows(
        category: str | None = None,
        kind: str | None = None,
        namespace: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return repo.list_reasoning_flows_public(category=category, kind=kind, namespace=namespace, limit=limit)

    @server.tool(description="Resolve an executable reasoning flow by flow id, entry id, slug, title, or source entry alias.", annotations=READ_ONLY, structured_output=True)
    def get_reasoning_flow(entry_id_or_flow_id: str) -> dict[str, Any]:
        return repo.get_reasoning_flow_public(entry_id_or_flow_id)

    @server.tool(description="Search executable reasoning flows by title, purpose, steps, or output contract.", annotations=READ_ONLY, structured_output=True)
    def search_reasoning_flows(query: str, limit: int = 10, namespace: str | None = None) -> dict[str, Any]:
        return repo.search_reasoning_flows_public(query, limit=limit, namespace=namespace)

    @server.tool(description="Suggest next critical-thinking steps based on the domain and surfaced biases. biases_found must be a JSON array of bias names or IDs.", annotations=READ_ONLY, structured_output=True)
    def suggest_next_steps(domain: str, biases_found: list[str]) -> dict[str, Any]:
        return suggest_next_steps_payload(repo, domain, biases_found)

    @server.tool(description="Search the knowledge base for manual exploration and debugging. retrieval_profile may be auto, general, or research_methodology.", annotations=READ_ONLY, structured_output=True)
    def search_knowledge_base(
        query: str,
        kind: str | None = None,
        category: str | None = None,
        limit: int = 10,
        retrieval_profile: str | None = None,
    ) -> dict[str, Any]:
        safe_limit = max(1, min(limit, 25))
        resolved_profile = resolve_retrieval_profile(query, text_type="research" if normalize_retrieval_profile(retrieval_profile) == "research_methodology" else None, retrieval_profile=retrieval_profile)
        overlay_results = state.search_kb_additions(query, kind=kind, category=category, limit=safe_limit)
        canonical = repo.search_public(query, kind=kind, category=category, limit=safe_limit)
        canonical_results = [with_source_scope(result, "canonical") for result in canonical.get("results", [])]
        merged = overlay_results + canonical_results
        if resolved_profile == "research_methodology":
            methodology = research_methodology_profile_hits(repo, query, limit=safe_limit)
            existing = {first_text(result.get("id") or result.get("entry_id") or result.get("title")) for result in merged}
            for result in methodology["hits"]:
                key = first_text(result.get("id") or result.get("entry_id") or result.get("title"))
                if key and key not in existing:
                    merged.append(with_source_scope(result, "canonical"))
                    existing.add(key)
            merged = rerank_for_research_methodology(merged, query)
        merged = merged[:safe_limit]
        no_result_recovery = (
            kb_no_result_recovery(query, kind=kind, category=category)
            if not merged
            else None
        )
        return {
            "query": query,
            "filters": {"kind": kind, "category": category, "limit": safe_limit, "retrieval_profile": resolved_profile},
            "results": merged,
            "overlay_count": len(overlay_results),
            "canonical_count": len(canonical_results),
            "research_methodology_hits": research_methodology_profile_hits(repo, query, limit=min(safe_limit, 8)) if resolved_profile == "research_methodology" else None,
            "no_result_recovery": no_result_recovery,
        }

    return server


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Critical Compass MCP server.")
    parser.add_argument("--db-path", default=str(DEFAULT_DB_PATH), help="Path to critical-compass.sqlite")
    parser.add_argument("--state-db-path", default=str(DEFAULT_STATE_DB_PATH), help="Path to writable critical-compass-state.sqlite")
    parser.add_argument("--user-additions-pack-path", default=str(USER_ADDITIONS_PACK_PATH), help="Path to additive user KB pack JSON")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    db_path = Path(args.db_path).expanduser().resolve()
    try:
        repo = Repository(db_path)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2)
    state_path = Path(args.state_db_path).expanduser().resolve()
    additions_pack_path = Path(args.user_additions_pack_path).expanduser().resolve()
    state = StateStore(state_path, additions_pack_path)
    try:
        server = build_server(repo, state)
        server.run(transport="stdio")
    finally:
        state.close()


if __name__ == "__main__":
    main()
