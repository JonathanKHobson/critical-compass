# External MCP Orchestration Contract v1.0.0

Use this contract only for MCPs classified as `orchestrated_external`.

## Pre-Call Gate

- Confirm the registry entry is not `rejected`.
- Confirm the user explicitly asked for or accepted external orchestration.
- Confirm the MCP has license, dependency, transport, and data-exposure review notes.
- Send only the minimum necessary data.
- Keep Critical Compass responsible for final synthesis and plurality framing.

## Output Provenance

Every orchestrated result must say whether it came from:

- internal Critical Compass module
- external MCP orchestration
- prompt scaffold only
- host browsing
- experimental provider path

## Fallback

If the external MCP is unavailable, unsafe, unreviewed, or not explicitly allowed, return the registry fallback:

- native Critical Compass module when available
- approved local helper
- prompt scaffold
- structured not-available result

Never silently substitute live external behavior for scaffold-only guidance.
