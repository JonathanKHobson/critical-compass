# Host-AI Quickstart / Current State Context v1.0.0

Use this before changing Critical Compass behavior, calling multiple tools, or explaining the MCP to a user.

## Product Promise

Critical Compass helps people and mission-driven organizations pressure-test text before they use it, so weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads.

Lead with this plain-language purpose. Treat MCP composition, provider adapters, registries, and study-library lessons as support infrastructure, not the product story.

## Current Shipped State

Critical Compass is a host-AI-powered critical-thinking coach with local-first defaults. It supports:

- first-session onboarding through `get_started`
- intent-first routing when users have text but no chosen lane yet
- MCPB/Desktop Extension install and diagnostic guidance through the `mcpb_install_diagnostics_prompt` scaffold
- local PDF/source preparation through `prepare_audit_source`
- lightweight gut-checks through `quick_scan`
- structured audits through `audit_text`, including audience-fit, framing openness, stakeholder fit, missing voices, and persuasion-risk review
- advanced-audit persona discovery through `list_agent_personas`
- staged advanced-audit scaffolding through `advanced_audit` for thorough, multi-perspective, stakeholder-sensitive, or high-stakes review
- claim pressure-testing through `claim_stress_test`
- scaffold-first factual verification through `factcheck_lookup`
- saved audit browsing and comparison through `list_audit_results`, `get_pattern_summary`, and `compare_audit_results`
- stakeholder-ready report generation through `generate_audit_report`
- local read-only report viewers through `generate_audit_artifact_viewer`
- MCP composition policy and study-library lessons through `critical_compass_overview(topic="mcp_composition")`

Expanded `text_type` support includes `social_media`, `academic_abstract`, `product_copy`, `legal`, and `ai_generated`.

The current Pressure-Test Readiness implementation track adds an Atlas-informed scenario and guidance kit through `pressure-test-readiness-kit.md`. Use it to evaluate advocacy copy, public statements, grant impact claims, article review, AI-generated summaries, and research-adjacent summaries against the trust/revise/verify/reframe decision contract.

## Non-Negotiable Rules

- Do not add automatic web retrieval to core audits.
- Do not equate check-worthy with false.
- Do not call fact-check retrieval providers unless the user explicitly authorizes that mode.
- Do not describe study-library lessons as live MCP orchestration.
- Do not merge, import, install, or call downloaded MCP repos from the study library.
- Do not generate placeholder final reports unless the user explicitly authorizes placeholders.
- Do not treat `quick_scan` as a full audit.
- Do not treat saved-audit score deltas as improvement proof unless `compare_audit_results` returns `comparability="direct"`.
- Do not treat Knowledge Atlas as a runtime dependency; Atlas-informed material in this repo is build-time evidence distilled into local Critical Compass resources.

## Freshness Checks

When behavior seems stale:

1. Call `get_started()`.
2. Call `critical_compass_overview(topic="overview")`.
3. Call `critical_compass_overview(topic="reports")`.
4. Call `critical_compass_overview(topic="mcp_composition")`.
5. Confirm workflow resources include tool inventory, server instructions, fact-check scaffolds, report/viewer runbooks, and MCP study-learning resources.
6. For install questions, confirm workflow resources include `mcpb_install_diagnostics_prompt`.
7. If an attached host MCP still returns old behavior, restart or rebind the MCP session before deeper QA.

## Default Host Path

Start with the user job: pressure-test this before use. Then choose the narrowest workflow:

- text present, no lane chosen: ask goal + intended audience + quick/full/advanced depth, then route to `audit_text` or `advanced_audit`
- one local PDF: `prepare_audit_source` before audit tools
- new user or first audit: `get_started`
- lightweight gut-check: `quick_scan`, then `audit_text` if warranted
- one text needing the normal full analysis or audience-fit read: `audit_text`
- advanced personas: `list_agent_personas`, then `define_audit_agents` or `advanced_audit`
- high-stakes, multi-perspective, stakeholder-sensitive, or persuasion-effectiveness review: `advanced_audit`
- one claim: `claim_stress_test`
- factual claims worth checking: `factcheck_lookup(provider="guided_research")`
- two saved results: `compare_audit_results`
- completed audit data: `generate_audit_report`
- completed report manifest: `generate_audit_artifact_viewer`
- external MCP idea: `critical_compass_overview(topic="mcp_composition")`

When improving or evaluating output usefulness, use `pressure-test-readiness-kit.md` and the local `support/evals/atlas_pressure_test_scenarios.json` fixture before proposing new tools.

Audience effectiveness is not a mismatch lane. If the question is really about framing openness, stakeholder fit, missing voices, persuasion quality, or whether a draft works for its intended reader, stay inside Critical Compass first. Offer JTBD or other adjacent frameworks only after the core audit if they clearly add value.

## What This Resource Is Not

This is not an audit result, a retrieval result, or permission to call external MCPs. It is the current-state context for host AIs and maintainers.
