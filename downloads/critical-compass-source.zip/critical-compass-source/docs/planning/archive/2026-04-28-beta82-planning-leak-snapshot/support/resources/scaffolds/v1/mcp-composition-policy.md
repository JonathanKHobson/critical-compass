# MCP Composition Policy v1.0.0

Use this when a host AI or maintainer wants to decide what to do with an outside MCP or learn from downloaded MCP repos without making them dependencies.

## Decision Modes

- `merged_internal`: adapt the pattern or compatible code into Critical Compass because it is core, safe, licensed, and maintainable.
- `wrapped_internal`: keep the capability repo-owned and local, but expose it with native Critical Compass semantics.
- `orchestrated_external`: coordinate a separate MCP only after trust review, explicit availability, consent, and provenance labeling.
- `prompt_scaffold_only`: keep the useful behavior as a prompt, checklist, or workflow contract.
- `rejected`: do not use because it conflicts with scope, trust, license, maintenance, or epistemic goals.

## Required Questions

1. What Critical Compass problem does this solve?
2. Is the useful value code, architecture, interface, prompt pattern, data, or evaluation design?
3. What existing Critical Compass behavior would it displace?
4. Is the license compatible with local use?
5. What data would leave the user's machine?
6. What happens if the MCP is unavailable?
7. Does the MCP strengthen or weaken plurality, uncertainty, and provenance?

## Current Rule

Do not merge or call outside MCPs by default. Use the local capability registry first, prefer native Critical Compass capabilities, and label every external influence.

## Study-Library Soft Learning

The local study library can inform design through `support/registry/mcp_study_lessons.json`. These records are original Critical Compass summaries of patterns, not copied source text and not live tools.

Allowed uses:

- learn repo-organization, schema, prompt, fixture, and trust-review patterns
- classify a pattern as adopt, adapt, document-only, defer, or reject
- rewrite useful guidance in Critical Compass language

Disallowed uses:

- copy third-party code or long prompt text
- import, install, execute, or call studied repos
- describe a lesson as retrieval, verification, or orchestration
