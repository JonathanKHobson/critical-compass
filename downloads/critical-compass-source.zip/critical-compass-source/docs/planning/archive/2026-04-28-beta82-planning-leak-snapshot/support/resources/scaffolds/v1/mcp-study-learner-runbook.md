# MCP Study Learner Runbook v1.0.0

Use this when a host AI or maintainer wants to learn from downloaded MCP repos without turning them into dependencies.

## Default Path

1. Call `critical_compass_overview(topic="mcp_composition")`.
2. Read the `mcp_study_lessons_resource` summary.
3. Treat records as `study_library_pattern` evidence, not live capabilities.
4. Decide whether the lesson should be adopted, adapted, documented, deferred, or rejected.
5. If implementation is justified, rewrite the behavior in Critical Compass language and add tests.

## Allowed Learning

- Repo organization patterns.
- Tool-description patterns.
- Host-AI prompt/scaffold patterns.
- Schema and fixture organization.
- Release checklist ideas.
- Security and trust-preflight ideas.
- Negative examples that clarify what not to ship.

## Disallowed Learning

- Copying third-party code.
- Copying long prompt text.
- Importing or executing downloaded repos.
- Installing MCPs as part of this runbook.
- Calling external MCPs during audits.
- Treating a study-library lesson as retrieval, verification, or orchestration.

## Labels To Preserve

- `study_library_pattern`: a design lesson from a local repo.
- `prompt_scaffold_only`: useful as host guidance, not runtime integration.
- `document_only`: planning evidence only.
- `rejected`: not available for route planning.

## Good Host Phrases

- "This is a study-library pattern, not a live dependency."
- "The useful part is the interface pattern, not the code."
- "No external MCP is being called."
- "This should stay scaffold-only until a trust and license review says otherwise."

## Bad Host Phrases

- "Critical Compass now uses this MCP."
- "The study-library repo verified this claim."
- "No match means the claim is false."
- "This external MCP can be called because it appears in the registry."

## Scanner

Use `python3 scripts/scan_mcp_study_library.py` to produce candidate evidence. The scanner emits JSON to stdout by default and only inspects docs, prompts, schemas, examples, and golden fixtures. It does not import, run, install, or call studied repos.
