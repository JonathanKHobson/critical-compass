# Support Registries

- Total aliases: 2150
- Collisions: 50

Generated alias registry for canonical lookup, exact-match aliases, and near-synonym access.

Additional local registries:

- `comparable_tools.json`: adjacent-tool lessons for adopt/adapt/integrate/reject decisions.
- `mcp_capabilities.json`: MCP composition registry for merge/wrap/orchestrate/scaffold/reject decisions.
- `mcp_capability_registry.schema.json`: machine-readable schema summary for the MCP capability registry.
- `mcp_study_lessons.json`: soft-learning registry of original Critical Compass lessons from downloaded MCP repos.
- `mcp_study_lessons.schema.json`: machine-readable schema summary for the MCP study lessons registry.
- `trusted_factcheck_publishers.json`: approved publisher/source metadata for explicit fact-check retrieval modes.

Registry entries are evidence and policy, not permission to call external tools automatically.
