# Surface Sync Checklist v1.0.0

Use this checklist whenever a public MCP tool, tool description, workflow resource, report contract, or planning status changes.

## Required Surface Checks

- README describes the current shipped behavior.
- `docs/public/why-critical-compass.md` explains who the tool is for, why local-first matters, why the KB is useful but not final authority, and what the tool does not do.
- `get_started`, `quick_scan`, `list_agent_personas`, and `compare_audit_results` are visible in server descriptions, docs, and tests when shipped.
- `critical_compass_overview` mentions the workflow and routes hosts correctly.
- `tool-inventory.md` lists when to use the relevant tool or resource.
- `server-instructions.md` includes any new non-negotiable host rule.
- `manifest.json` includes any new scaffold resource with an accurate purpose.
- Pressure-Test Readiness changes include or reference scenario-backed checks before adding tools.
- Tests assert the new public surface is discoverable.
- Validators fail loudly if a required public-surface term disappears.

## MCP Study-Library Roadmap Checks

For MSL work, confirm these terms remain visible:

- `Host-AI Quickstart / Current State Context`
- `Client-specific one-line hints`
- `Tool trigger matrix`
- `Surface sync checklist`
- `Ship next`
- `study_library_pattern`
- `prompt_scaffold_only`

## Fact-Check Surface Checks

- Default `factcheck_lookup` behavior remains `guided_research`.
- Scaffold-only output leads with "No retrieval was performed" and is not described as retrieval.
- External lookup remains opt-in and provider-specific.
- Check-worthy still means worth verifying, not false.

## Compare And Persona Checks

- `compare_audit_results` exposes `direct`, `qualified`, `weak`, and `not_comparable` statuses.
- Score deltas are described as proof of improvement only when comparability is `direct`.
- Persona guidance supports custom roles while avoiding protected-identity impersonation.

## Report Surface Checks

- `generate_audit_report` still requires completed report-critical fields unless placeholders are explicitly authorized.
- `generate_audit_artifact_viewer` remains read-only and manifest-based.
- Report output paths are presented together: PDF, Markdown, manifest, and viewer.

## Validation Command

Run:

```bash
python3 scripts/validate_mcp_surface_sync.py
```

This validator checks the high-risk public surfaces: README, overview code, tool inventory, server instructions, scaffold manifest, resource files, planning docs, and tests.
