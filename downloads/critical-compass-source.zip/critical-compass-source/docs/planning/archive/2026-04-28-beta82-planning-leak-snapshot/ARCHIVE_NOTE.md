# Beta 8.2 Planning-Leak Cleanup Snapshot

Created before the approved cleanup that removes external-MCP orchestration and internal planning language from runtime-visible, packaged-scaffold-visible, and public-facing Critical Compass surfaces.

This archive preserves the pre-cleanup files for dev review. Cleanup should keep orientation scaffolding useful while removing unsupported third-party MCP names, orchestration plans, registry classifications, study-library language, and future-state noise from product-facing guidance.
