# Why Critical Compass

Critical Compass helps people pressure-test text before they use it, so weak evidence, hidden assumptions, bias, false certainty, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads.

Use it when a draft, claim, report, policy memo, grant narrative, research summary, product copy, social post, or public statement needs one more honest pass before it is published, taught, funded, shared, or acted on.

The core question is simple: should I trust, revise, verify, or reframe this before I use it?

## How It Differs From Adjacent Tools

Critical Compass borrows useful patterns from adjacent tools without becoming them.

- Kialo, Rationale, and Argdown inspire compact argument maps, but Critical Compass keeps those maps inside a broader audit of evidence, framing, missing voices, and readiness to use.
- Elicit, Scite, and Consensus inspire better evidence-needed prompts, but Critical Compass does not run live research retrieval by default.
- Fact-check and check-worthiness tools inspire verification planning, but Critical Compass preserves the boundary that check-worthy means worth verifying, not false.
- Generic reasoning MCPs inspire reasoning pauses, but Critical Compass ties those pauses to user-facing audit outputs, reports, and teaching follow-up activities.

The point is not to replace research, debate, or fact-checking tools. The point is to give a local-first pressure test that helps a human decide the next responsible move.

## Who It Is For

Critical Compass is for people and teams whose words can shape decisions:

- nonprofit and mission-driven organizations
- researchers, educators, writers, editors, and consultants
- policy, civic, advocacy, and community-facing teams
- product and communications teams reviewing persuasive copy
- individuals who want a structured second read before sharing a claim

It is built for users who want plain-language critical thinking, not a black-box score.

## What Problem It Solves

Most text problems are not obvious factual errors. They are quieter:

- a claim outruns its evidence
- a draft hides its assumptions
- a report sounds neutral while carrying a standpoint
- an argument leaves out affected voices
- polished language makes weak support feel stronger than it is
- Western, institutional, or dominant-culture framing is treated as the default
- AI-generated text sounds more certain than its provenance allows

Critical Compass surfaces these risks early, while revision is still possible.

## Why Local-First Matters

Critical Compass is local-first because many audit inputs are sensitive, unfinished, or context-heavy.

The default audit path uses the local knowledge base and local state. It does not automatically browse the web, send full documents to external fact-check providers, or treat outside tools as part of the core verdict. External lookup remains explicit and opt-in.

That design keeps the audit focused on the visible text, preserves provenance, and makes it easier to explain what evidence was and was not used.

## Why Trust The Knowledge Base

The knowledge base is not presented as universal authority. It is a structured library of biases, fallacies, reasoning frameworks, methodology checks, thinking lenses, and audit scaffolds.

Critical Compass uses it conservatively:

- bias labels require textual support
- check-worthy means worth verifying, not false
- Critical Integrity Snapshot points are traceability signals, not school grades
- context lenses describe evidence convention, purpose, and voice, not the author's identity
- dissent and uncertainty are preserved instead of flattened into false consensus

The goal is not to make the tool final. The goal is to make the next human judgment better.

## What This Does Not Do

Critical Compass does not verify truth by default. It can identify factual claims worth checking and produce a guided verification plan, but real verification requires evidence gathering or an explicit opt-in fact-check lookup.

Critical Compass does not replace human judgment. It gives a structured read, named risks, and revision questions so a person can decide what to trust, revise, verify, or reframe.

Critical Compass does not guarantee that non-Western, Indigenous, local, or affected-community perspectives are correctly represented. It can flag missing perspectives and ask whether sources with standing are present, but it cannot speak for communities it has not heard from.

Critical Compass does not prevent biased outputs. It surfaces possible bias, overclaiming, missing context, and framing risk so users can review and revise before use; in plain terms, it surfaces risks for review.

This is trust calibration, not a legal disclaimer: the tool is strongest when users treat it as a disciplined pressure test, not an authority badge.

## First Five Minutes

Start with one concrete input:

- `get_started` for first-session onboarding
- `quick_scan` for a lightweight gut-check
- `audit_text` for the full direct audit
- `prepare_audit_source` before auditing local PDFs
- `claim_stress_test` for one claim
- `factcheck_lookup(provider="guided_research")` for a scaffold-first verification plan
- `list_agent_personas` before advanced-audit agent mode
- `compare_audit_results` when two saved results need a careful diff

If an audit feels wrong, confusing, too harsh, too soft, or culturally narrow, use the beta calibration intake resource so the release can improve from real user friction instead of guessing.
