# Beta.8.2 Planning-Fragment Inventory

Status: flag-only inventory; no cleanup approved yet.

Purpose: identify dev/planning/composition language that is visible from product-facing, host-visible, packaged, or public Critical Compass surfaces. This file is an approval checkpoint, not a deletion list.

## Rules

- Do not delete or rewrite flagged material until cleanup is explicitly approved.
- Before any approved cleanup, copy affected files to `docs/planning/archive/<date>-beta82-planning-leak-snapshot/`.
- Planning and ADR material may remain in planning areas, but runtime MCP guidance and packaged user-facing scaffolds should not expose internal planning language.
- Product-facing guidance should describe shipped local Critical Compass capabilities, not third-party MCP candidates, external orchestration, or implementation history.

## Flagged Inventory

| Classification | Surface | Flagged Material | Why It Is Flagged | Proposed Later Action |
| --- | --- | --- | --- | --- |
| runtime-visible | `server.py` / `critical_compass_overview` | `mcp_composition` topic aliases and topic payloads | Exposes internal MCP composition planning as a user/host workflow. | Remove from runtime overview topics or make dev-only. |
| runtime-visible | `server.py` / overview core workflows | `mcp_composition_policy` workflow card | Tells host AIs to surface capability registry and study-library lessons. | Remove from product workflow list. |
| runtime-visible | `server.py` / overview case studies | `Classify an MCP candidate` case study | Makes third-party MCP planning look like a shipped Critical Compass use case. | Move to planning docs only. |
| runtime-visible | `server.py` / overview tool map | `critical_compass_overview` entry for MCP composition policy and safe orchestration guidance | Keeps external orchestration language inside runtime routing. | Replace with product-facing capability lookup language. |
| runtime-visible | `server.py` / comparable-tools topic | Returned `mcp_capability_registry` and `mcp_study_lessons_resource` | Exposes local registry records, classifications, and planning evidence to Claude-visible output. | Return positioning-only summary or null resources. |
| runtime-visible | `server.py` / starter prompts | Prompts using `merged internal`, `wrapped internal`, `orchestrated external`, `prompt scaffold only`, and `rejected` | Internal implementation taxonomy appears as user-facing action language. | Remove from runtime prompts. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/tool-trigger-matrix.md` | MCP composition resources row and `orchestrated_external` / `prompt_scaffold_only` / `rejected` labels | Host-visible scaffold treats integration planning as a normal routing lane. | Move to planning-only or replace with “future planning notes.” |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/client-host-hints.md` | External MCP merge/wrap/orchestrate/reject guidance | Product prompt hints expose internal strategy and unsupported external orchestration. | Remove from host-facing hints. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/server-instructions.md` | Instructions to call `critical_compass_overview(topic="mcp_composition")` | Runtime server instructions tell hosts to enter planning mode. | Remove from runtime instructions. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/host-ai-quickstart-current-state.md` | MCP composition and study-library current-state guidance | Host onboarding mentions internal planning infrastructure. | Keep only product workflow current state. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/tool-inventory.md` | Registry paths, internal helpers, external MCP labels | Packaged inventory names internal registries and external orchestration conditions. | Move details to planning docs or a dev-only inventory. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/mcp-composition-policy.md` | Merge/wrap/orchestrate/scaffold/reject policy | Entire file is planning/developer policy, not product guidance. | Archive or exclude from packaged scaffolds after approval. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/external-mcp-orchestration-contract.md` | Contract for MCPs classified as `orchestrated_external` | Conflicts with current decision to avoid external MCP orchestration. | Archive or exclude from packaged scaffolds after approval. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/mcp-study-learner-runbook.md` | Study-library learner workflow | Dev learning workflow appears in packaged scaffold layer. | Move to planning docs only. |
| packaged-scaffold-visible | `support/resources/scaffolds/v1/manifest.json` | Manifest entries for composition policy, external orchestration, and study learner resources | Makes planning resources discoverable through scaffold manifest. | Remove entries after approved archival. |
| public-doc-visible | `README.md` | MCP composition, study-library, capability registry, and `orchestrated_external` sections | Public product docs foreground internal architecture and future/external integration thinking. | Rewrite to focus on shipped local product capabilities. |
| public-doc-visible | `docs/public/why-critical-compass.md` | Named adjacent tools and unsupported integrations | Public positioning can imply unsupported availability or dependency. | Keep generic positioning only unless a capability ships locally. |
| archive-candidate | `support/registry/mcp_capabilities.json` and schema | Candidate MCP classifications and local source paths | Registry is useful dev evidence but should not be runtime-visible. | Move or exclude from packaged runtime resources after approval. |
| archive-candidate | `support/registry/mcp_study_lessons.json` and schema | Study-library lesson records and local paths | Planning evidence, not product guidance or runtime capability. | Move or exclude from packaged runtime resources after approval. |
| dev-only-ok | `docs/planning/*mcp*`, `docs/specs/mcp_orchestration_contract.md`, `docs/adr/ADR-0004*`, `docs/adr/ADR-0005*`, `docs/adr/ADR-0006*` | Historical planning and architecture decisions | Fine to keep as dev-facing evidence when not surfaced through runtime MCP outputs. | Leave in planning/ADR unless later pruning is requested. |

## Suggested Approval Gate

Cleanup should start only after this inventory is approved. The cleanup pass should:

1. Archive affected runtime/scaffold/public files before edits.
2. Remove the `mcp_composition` topic from user/host-visible routing.
3. Stop returning capability registry and study lesson resources from `critical_compass_overview`.
4. Remove external orchestration scaffold resources from packaged manifests.
5. Replace named third-party MCP/tool references with generic “adjacent tool inspiration” language where public positioning still needs it.
6. Add the hard static leak test that fails if runtime-visible surfaces contain the blocked terms.
