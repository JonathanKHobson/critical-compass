# Scoring Stability And Course Mode Backlog

Date: 2026-05-20

## Purpose

Course users need Critical Compass outputs that are comparable enough to discuss together. The goal is not perfect determinism; this is an LLM-driven MCP and variance will remain. The goal is to reduce avoidable ambiguity, explain score limits honestly, and give instructors a stable classroom path.

## What Shipped In This Slice

- Add score interpretation language to CIS report outputs.
- Frame CIS points as an approximate diagnostic signal, not a grade, truth verdict, or deterministic evaluation.
- Tell readers to treat findings, severity, dimension profile, and Before Using This Text guidance as primary.
- Warn that reruns can move by 5-10+ points when prompt wording, model/version, audit depth, or panel mode changes.
- Reinforce that movement across bands matters more than small point changes.
- Add `classroom_standard_audit_prompt` as a scaffold resource for Week 2 course use.
- Route course/classroom users through standard `audit_text`, not advanced panel review, in `get_started` and overview guidance.
- Add a clean Week 2 handoff in `docs/course-use/week2-critical-compass-bias-audit.md`.
- Strengthen `compare_audit_results` copy so raw score deltas are treated as diagnostic signals, not proof of improvement.

## Product Read

The friend's feedback is a course-reliability issue more than a scoring-math issue. Students need shared structure, stable section order, and consistent comparison language. Advanced panel review is useful for deep critique, but it is a poor default for a classroom assignment because it naturally changes the finding set and therefore the score rationale.

Opinionated, advocacy, governance, or value-based pieces will amplify variance because legitimate evaluation depends on audience, evidence convention, standpoint, and intended use. That should be explained, not hidden.

## Prioritization

| ID | Idea | Impact | Effort | Priority | Notes |
|---|---|---:|---:|---|---|
| CCS-001 | Score interpretation language in chat/report outputs | High | Low | P0 | Shipped locally in this slice. |
| CCS-002 | Student prompt for course audits | High | Low | P0 | Shipped as `classroom_standard_audit_prompt`. |
| CCS-003 | Classroom mode guidance: no advanced panel by default | High | Low | P0 | Shipped in `get_started`, overview routing, and scaffold docs. |
| CCS-004 | Version/upgrade note for older installs | Medium | Low | P0 | Shipped in course guidance and handoff docs. |
| CCS-005 | Stable section-order contract for course reports | High | Medium | P1 | Likely a `course` or `classroom` report profile using existing report renderer sections. |
| CCS-006 | Rerun comparison workflow using existing `compare_audit_results` | Medium | Medium | P1 | Copy strengthened; deeper draft-comparison workflow remains future work. |
| CCS-007 | Score rationale trace block | Medium | Medium | P1 | Add compact explanation tying aggregate points to dimension deltas and top findings. |
| CCS-008 | Repeated-run score calibration eval | Medium | High | P2 | Use only after prompt/report framing changes land; otherwise it becomes a tuning rabbit hole. |
| CCS-009 | New public `course_mode` tool | Medium | High | P2 | Do not add a tool until prompt/template guidance proves the shape. |

## Student Prompt

Use this in the Week 2 assignment:

```text
Please run a standard Critical Compass audit on the text below.

Use this fixed frame:
- Audience: [who this is for]
- Intended use: [what this writing is meant to do]
- Text type: [memo / pitch / email / report section / social post / proposal / other]
- Audit depth: standard
- Output purpose: classroom bias-audit reflection

Do not run an advanced panel review, multi-agent review, or web research. Do not rewrite the text unless I ask afterward.

Use this exact output structure:
1. Critical Integrity Snapshot
2. Plain-Language Read
3. Before Using This Text
4. Top 3-5 findings
   - finding name
   - severity: high / medium / low
   - specific evidence from the text
   - why it matters for the stated audience and intended use
5. Key tension
6. Recommended next revision
7. Two peer-discussion questions

Here is the text to audit:

[paste text]
```

## Instructor Guidance

Keep this note outside the student prompt:

> Critical Compass is AI-assisted, so outputs may differ across models and runs. For class discussion, compare the top findings, severity, and revision decisions more than exact point scores.

Recommended Week 2 assignment changes:

- Replace the broad standard-audit prompt with the student prompt above.
- Tell students to use the same text if they rerun the audit. If they revise it, label the next draft `Version 2` and compare findings rather than just the score.
- Keep advanced audit and advanced panel review out of the core assignment; offer them only as an optional extension for deeper critique.
- Use `MCPB extension` language for Claude Desktop and separate Claude Desktop setup from ChatGPT or prompt-only skill-file setup.
- Replace any overpromising de-westernization debrief with: Did the audit surface any perspective, power, cultural, or missing-voice issue that shifted how you see the text?
- Recommend updating older installs before the course so students receive the newer score framing and course routing guidance.

## Next Action

Validate the student prompt with one sample Week 2 text in Claude and ChatGPT, then decide whether a future classroom output profile is warranted.

## Do Not Touch Yet

- Do not retune the scoring model broadly.
- Do not add a new public tool before the prompt/template path is validated.
- Do not run release packaging or public-site publishing in this stability slice.
