# Benchmark Coverage And Omissions Ledger

Last reviewed: 2026-04-15.

This ledger reconciles the benchmark-informed improvement plan against the current repository state. It exists to prevent idea drift: every benchmark idea is either implemented, partially implemented with a next slice, deferred as optional, or rejected for core scope.

Validation update: the 36 Questions OCR/report smoke passed on 2026-04-15 with Apple Vision OCR, no PDF QA issues, and golden screenshots for the new report artifact sections. Later on 2026-04-15, the next implementation slice added check-worthy evidence-plan fields, expanded reasoning traps, consent-gated blind-spot reminder storage, a local read-only artifact viewer, checklist-only visual artifact coverage, a six-case beta calibration harness, real-case calibration intake guidance, and a live MCP freshness QA runbook. The fact-check lane is now implemented as scaffold-first `factcheck_lookup` with mocked no-network validation, opt-in local ClaimReview retrieval, consent-gated direct publisher harvest, and explicit/experimental provider-backed retrieval outside core audit execution.

## Status Legend

- **Implemented**: code, docs, and validation coverage exist for the core promise.
- **Partial**: the core shape exists, but a named benchmark detail is still missing.
- **Planned**: feasible and in scope, but not implemented yet.
- **Deferred**: feasible only as later opt-in work.
- **Rejected**: conflicts with Critical Compass scope or local-first guardrails.

## Coverage Matrix

| Benchmark idea | Current status | Evidence in repo | Decision | Outstanding planning |
|---|---|---|---|---|
| Argument map output inspired by Kialo, Rationale, and Argdown | Implemented | `audit_report/artifacts.py`, report Markdown/PDF sections, renderer tests | Adapt/rebuild locally | Add more golden fixtures after real advanced-audit smoke tests. |
| `.argdown` export | Implemented | Argument map includes Markdown and `.argdown` strings | Adapt/rebuild locally | Keep as text export; no public Argdown renderer tool yet. |
| Check-worthy claim extraction inspired by FactRank | Implemented | `checkworthy_claims` separates factual, interpretive, causal, normative, and policy claims; only factual claims receive priority; each claim now carries `suggested_queries`, `likely_source_types`, `support_contrast_status`, and `uncertainty_note` | Adapt/rebuild locally | Maintain no-network and report fixture coverage. |
| "Check-worthy does not mean false" language | Implemented | Artifact helpers, Markdown, PDF copy, tests | Adopt concept directly, rebuild locally | Continue regression coverage. |
| Optional factuality or fact-check lane inspired by Fact Check Tools MCP, OpenFactCheck, Elicit, Scite, and Consensus | Implemented as scaffold-first lane; rejected for core default retrieval | Evidence Needed Next table, query/source-plan fields, `factcheck_lookup`, epistemic framing, local ClaimReview indexing, direct publisher harvest, trusted publisher allowlist, privacy guard, cache for retrieval modes, mocked provider tests, and External Fact Checks report/viewer sections exist | Scaffold-first default; local retrieval opt-in; external integration explicit | Maintain no-network tests, allowlist review, and consent-gated host instructions. |
| Advanced-audit dissent preservation inspired by ThoughtProof | Implemented | Dissent ledger helper, report rendering, synthesis scaffold, persistence fixtures, recurring disagreement-pattern storage, and compression guidance exist | Adapt/rebuild locally | Maintain provenance and avoid false consensus. |
| Reasoning trap detectors inspired by Verifiable Thinking MCP | Implemented | Current traps cover comfortable answer, single source, binary frame, missing voice, causation leap, scope leap, base-rate neglect, missing denominator, anecdotal evidence, authority laundering, and circular framing, with false-positive calibration and severity ordering | Adapt/rebuild locally | Maintain fixture coverage as new traps are added. |
| Human-loop interruption triggers inspired by Ethics Check MCP | Implemented / Calibration harness active | Trigger helper, judgment prompt choices, guided/minimal/silent handling, blind-spot reminder candidates, and beta calibration cases exist | Adapt/rebuild locally | Broaden false-pause measurement when larger real-user fixtures exist. |
| Saved blind-spot reminders | Implemented | `save_blind_spot_reminder` stores consent-confirmed, non-sensitive reminders through existing pattern storage; scaffold resources include consent and retrieval examples | Adapt/rebuild locally | Keep sensitive profiling blocked. |
| Scaffold registry and canonical examples inspired by Claude Prompts MCP | Implemented | Versioned scaffold resources, report readiness contract, canonical templates, tool inventory, demo runbook, live QA runbook, calibration intake, and tests exist | Adapt/rebuild locally | Keep resources versioned as contracts evolve. |
| Host-AI onboarding and correct tool usage | Implemented | Server descriptions, overview resources, `server-instructions.md`, and live QA runbook include report/viewer workflow rules | Adapt/rebuild locally | Keep instructions concise and model-agnostic. |
| PDF report readiness and upgraded artifacts | Implemented | Strict readiness gate, Markdown contract, Evidence Needed Next, Argument Map, Dissent Ledger, Reasoning Trap sections, `.argdown` sidecar, trust summaries, artifact viewer, checklist-only visual artifact coverage, and golden artifact validation | Adapt/rebuild locally | Maintain visual fixtures as report sections evolve. |
| Tool/source trust preflight inspired by MCP Guard and MCP Shield | Implemented | Trust helper, persisted source preflight output, trust summaries, red-team fixtures, and `prepare_audit_source` behavior exist | Adapt/rebuild locally first | Keep external-tool trust checks before optional integrations. |
| Comparable tools knowledge layer | Implemented | Machine-readable local registry and evaluation cases are surfaced through `critical_compass_overview(topic="comparable_tools")` | Adapt/rebuild locally | Maintain as curated notes, not a marketplace. |
| Idea Reality MCP-style proposal reality check | Deferred | Captured in adopt/adapt/reject matrix only | Optional external integration | Plan as proposal-only mode; never part of default text audits. |
| Named thinking modes from MCP Thinking / think-mcp | Partial | Reasoning flows and audit scaffolds already provide local lenses | Adapt only where output-specific | Avoid generic "thinking mode marketplace"; add named lens presets only when tied to audit artifacts. |
| Broad MCP marketplace discovery | Rejected for core audits | ADR/local-first guardrails | Reject | No core implementation. Keep curated notes only. |
| MCP App UI for argument maps and inline review | Implemented locally for read-only v1 | `generate_audit_artifact_viewer` writes a local static HTML viewer from report manifests | Adapt/rebuild locally | Comparison and annotation views remain deferred until real usage justifies them. |

## Active Local-First Slices Now Completed

### 1. Evidence Plan Fields For Check-Worthy Claims

Status: implemented in the MCP output/report path on 2026-04-15.

Problem solved: `checkworthy_claims` now tells users what evidence is needed and carries suggested local verification queries, likely source types, support/contrast status, and uncertainty notes without triggering web retrieval.

Scope:
- Add optional fields to each claim: `suggested_queries`, `likely_source_types`, `support_contrast_status`, and `uncertainty_note`.
- Keep these as local planning fields. Do not run web search by default.
- Render them in the Evidence Needed Next table only when present.

Completed acceptance:
- Report rendering tests cover these fields in Evidence Needed Next.
- A no-network regression proves suggested queries are planning fields only.
- Research/policy support and contrast status examples are represented in scaffold resources and tests.

### 2. Expanded Reasoning Trap Taxonomy

Status: implemented and calibrated in the detector layer on 2026-04-15.

Problem solved: the trap detector now covers missing denominator, base-rate neglect, authority laundering, circular framing, and anecdotal evidence in addition to the first trap set.

Scope:
- Add these traps as advisory risk labels with `next_check`.
- Keep labels conservative and non-scolding.
- Add false-positive fixtures before enabling new traps broadly in reports.

Completed acceptance:
- False-positive fixtures cover words like "or" and other short signals.
- Reports receive a capped, severity-ordered trap subset when many traps fire.
- Each trap remains advisory and non-blocking.

### 3. Saved Blind-Spot Reminders

Status: implemented as consent-gated storage on 2026-04-15; host-facing consent examples are published.

Problem solved: recurring blind-spot reminders can now be saved through existing pattern storage only when the user explicitly consents, and sensitive personal profiling is blocked.

Scope:
- Use existing pattern storage to save recurring blind-spot patterns explicitly chosen by the user or inferred from repeated audit artifacts.
- Avoid sensitive personal profiling.
- Surface reminders as optional reflection context, not as a verdict.

Completed acceptance:
- Consent question examples are in versioned scaffold resources.
- Retrieval wording is bounded and non-profiling.
- Silent mode remains governed by explicit user/tool flow rather than automatic reminder surfacing.

### 4. Versioned Scaffold Resource Files

Status: implemented as versioned local resources on 2026-04-15.

Problem solved: canonical examples no longer live only inside tool contracts; host AIs can inspect a browsable local registry.

Scope:
- Add versioned local example files for audit payload, report payload, advanced synthesis, argument map, check-worthy claims, and self-audit mode.
- Expose them through existing overview/report-readiness surfaces before adding any new public tool.

Acceptance criteria:
- Host AIs can discover canonical examples without reverse-engineering `server.py`.
- Examples use canonical field names first; aliases are documented as compatibility fallbacks.
- Report generation instructions clearly say "compile fields before PDF."

### 5. Comparable Tools Local Records

Status: implemented as local registry records on 2026-04-15.

Problem solved: comparable-tools decisions now exist as local machine-readable records and overview-facing evaluation cases.

Scope:
- Add a curated local resource file containing tool name, category, classification, local mergeability, useful takeaway, and rejection/defer notes.
- Keep it design-facing, not a marketplace.

Acceptance criteria:
- `critical_compass_overview(topic="comparable_tools")` can point to a stable local record.
- Every outside inspiration remains classified as adopt, adapt/rebuild, optional integration, or reject.

### 6. Proposal Reality-Check Mode

Problem: Idea Reality MCP inspired a useful mechanic for startup/app proposals, but it is outside default text-audit scope.

Scope:
- Later optional mode for proposal texts only.
- Use local comparable examples and user-provided context first.
- External scans stay opt-in and consent-gated.

Acceptance criteria:
- Core audits never call external scans automatically.
- Proposal mode returns duplication-risk questions, comparable-example prompts, and pivot questions, not a market verdict.

## Out Of Scope For Current Core

- Automatic web fact-checking inside `audit_text` or `advanced_audit`.
- Broad MCP marketplace browsing as a core Critical Compass feature.
- A visual MCP App UI before backend contracts and report artifacts are stable.
- Sensitive personal profiling for blind-spot reminders.
