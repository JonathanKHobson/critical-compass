# Implementation Status And Idea-Drift Review - 2026-04-15

This review reconciles the current repo state against the benchmark-informed Critical Compass improvement plan. It is intentionally narrow: keep Critical Compass one focused audit system, prefer local rebuilds, and do not add automatic web retrieval to core audits.

## Completed Since The Last Planning Pass

- Check-worthy claims now include local evidence-plan fields: `suggested_queries`, `likely_source_types`, `support_contrast_status`, and `uncertainty_note`.
- Reasoning traps now include base-rate neglect, missing denominator, anecdotal evidence, authority laundering, and circular framing, alongside the first detector set.
- Blind-spot reminders now save through existing pattern storage only when the user explicitly consents, and sensitive personal profiling is blocked.
- Comparable-tools decisions now live in machine-readable local records surfaced through overview/resources.
- Versioned scaffold resources now publish canonical report payloads, Markdown checkpoints, argument maps, check-worthy claims, server instructions, structured elicitation examples, blind-spot consent examples, and dissent guidance.
- Source/tool trust preflight now persists beside prepared sources and appears as compact trust summaries in report metadata/save payloads.
- Reports now write deterministic `.argdown` sidecars when argument maps are present.
- Reports now write a local read-only artifact viewer from the report manifest, surfacing the PDF/Markdown links, argument map, evidence plan, dissent ledger, reasoning traps, questions, and trust preflight.
- `factcheck_lookup` now provides scaffold-first verification orchestration for factual `checkworthy_claims`, with epistemic framing by default plus opt-in local ClaimReview retrieval, consent-gated direct publisher harvest, experimental provider infrastructure, trusted publisher allowlist, privacy guard, cache, no-network fixtures, and optional External Fact Checks report/viewer rendering when real matches are supplied.
- MCP composition now has a machine-readable capability registry, internal route-planning helpers, ADRs, policy docs, and scaffold resources. The local MCP study library is represented as evidence, not as a runtime dependency.
- MCP study-library lessons now feed an actionable implementation roadmap ordered by verdict: `Ship next`, `Use for local ClaimReview phase`, `Good next phase`, `Defer until examples prove need`, `Later / high effort`, and `Reject / scaffold-only`.
- Overview, scaffold resources, and AI-facing runbooks now explicitly surface source prep, report generation, manifests, local artifact viewers, calibration intake, and live MCP freshness QA.
- Targeted regression tests cover the new check-worthy fields, expanded trap labels, false positives, consent-gated blind-spot storage, trust red-team fixtures, scaffold resources, golden artifact manifests, checklist-only handout images, the artifact viewer, and beta calibration cases.

## Current Outstanding Items

All active local-first implementation items from the benchmark-informed roadmap are complete. The active planning risk is now infrastructure drift: the project can keep building meta-tooling instead of proving usefulness to public users and nonprofit teams.

1. Automatic live external fact-check/research integrations are rejected for core audits; `factcheck_lookup` is implemented as a scaffold-first tool for factual check-worthy claims, with retrieval only available through explicit local, publisher-harvest, or experimental provider modes.
2. Comparison and annotation views for the artifact viewer remain deferred until users need multi-report review.
3. Broader human-loop false-pause measurement should continue as consented real-user fixture data accumulates.
4. Third-party MCP orchestration remains deferred until a candidate has registry approval, trust review, explicit fallback, and a concrete user need.

## Mission Alignment Review

The mission charter is now authoritative: Critical Compass helps people and mission-driven organizations pressure-test text before they use it. The next phase is **Pressure-Test Readiness**, not more infrastructure.

Planning docs should now prioritize realistic public/nonprofit examples that show whether outputs are understandable, useful, and action-guiding. Every active roadmap item should help users decide what to trust, revise, verify, or reframe before sharing, teaching, funding, reporting, publishing, or acting.

Current non-active areas:

- Local ClaimReview expansion stays deferred until real examples show guided fact-check scaffolding is insufficient.
- External MCP trust preflight stays policy-only until a concrete pressure-test workflow needs external orchestration.
- Factuality evals and runtime MCP guard/proxy work stay later/high effort until output-quality failures justify them.
- Generic think tools and provider/payment consensus MCPs remain rejected or scaffold-only.

## MCP Study Library Implementation Roadmap

The `Ship next` items are complete. They reduce host-AI misuse and stale public-surface drift without adding runtime dependencies:

1. Done - `MSL-01`: Host-AI Quickstart / Current State Context resource.
2. Done - `MSL-02`: Client-specific one-line hints for Claude, Codex, and Cursor-style hosts.
3. Done - `MSL-03`: Tool trigger matrix with call-when, do-not-call-when, ask-first, and output-label guidance.
4. Done - `MSL-04`: Surface sync checklist plus lightweight validator for README, overview, tool inventory, scaffold manifest, and tests.

Later verdicts remain non-active:

- `Use for local ClaimReview phase`: adapter boundary checklist and golden-fixture requirement.
- `Good next phase`: external MCP trust preflight checklist.
- `Defer until examples prove need`: confidence/revision metadata and manifest/resource linter.
- `Later / high effort`: factuality eval subsystem and runtime MCP guard/proxy layer.
- `Reject / scaffold-only`: generic think tool and provider/payment consensus MCPs.

## Previous Ideas Fully Represented

- Argument map output, Markdown export, and `.argdown` export are represented and implemented.
- Check-worthy claims are represented and implemented without equating check-worthy with false.
- Advanced-audit dissent preservation is represented and implemented for the local-first path.
- Human-loop interruption triggers are represented and implemented, with broader false-pause measurement deferred.
- Report artifacts and readiness gates are represented and implemented, including golden artifact validation.
- Tool/source trust preflight is represented and implemented for local source preparation and report metadata.
- Host-AI workflow instructions are represented and implemented through server descriptions and versioned resources.
- Optional MCP App UI is represented and implemented as a local read-only artifact viewer; comparison and annotations remain deferred.

## Potential Omissions Or Idea Drift

### Proposal Reality-Check Mode

Source idea: idea-reality-mcp inspired comparable examples, duplication risk, and pivot questions for proposals.

Status: represented only as deferred prose. This is feasible but not part of default text audits.

Plan: keep as a later optional proposal-audit mode. It should use local comparable examples and user-provided context first. Any external scan must be explicit, consent-gated, and separate from `audit_text` or `advanced_audit`.

Decision: optional external integration later.

### Factuality Lane For Research And Policy Audits

Source idea: OpenFactCheck, Elicit, Scite, Consensus, and Fact-Check Tools MCP inspired a factuality lane and support/contrast evidence planning.

Status: implemented locally through `checkworthy_claims`, Evidence Needed Next, report rendering, and artifact viewer surfacing. A separate explicit `factcheck_lookup` tool now returns guided-research scaffolding by default; local ClaimReview search is opt-in when indexed, and published fact-check retrieval is only available through explicit publisher-harvest or experimental provider modes after user authorization.

Plan: keep local evidence planning and guided-research scaffolding as the default. Use provider-backed `factcheck_lookup` modes only when a user explicitly asks for external lookup of factual claims and accepts the privacy/provider caveats.

Decision: adapt/rebuild locally now; optional external integration implemented separately; reject automatic external calls for core audits.

### Named Audit Lens Presets

Source idea: MCP Thinking / think-mcp inspired named reasoning modes.

Status: represented through existing reasoning flows and advanced-audit agents. No separate "thinking modes" marketplace is needed.

Plan: only add named lens presets when they produce concrete audit artifacts or clearer agent scaffolds.

Decision: adapt selectively; reject generic mode marketplace.

### MCP Composition And Orchestration

Source idea: thinking-related MCP study library, FactRank, OpenFactCheck, Fact-Check Tools MCP, ethics-check-mcp, mcp-shield, mcp-guard, sequential-thinking, crash-mcp, and related packages.

Status: represented and implemented as policy, registry, ADRs, resources, and internal route-planning helpers. No public orchestration tool was added and no third-party MCP repos were merged.

Plan: keep the registry current only when product decisions depend on it. External MCP orchestration requires trust, license, maintenance, data-exposure, fallback, and provenance review.

Decision: implement composition spine now; defer live orchestration until a specific user need displaces current work.

### Saved Blind-Spot Retrieval At Audit Start

Source idea: Ethics Check MCP inspired learned blind spots.

Status: saving is implemented with consent; retrieval and surfacing examples are published as versioned scaffold resources.

Plan: keep retrieval opt-in and non-profiling. Silent mode should not surface reminders unless the user explicitly requests saved-pattern context.

Decision: adapt/rebuild locally.

## Next Planning Actions

1. Keep artifact viewer comparison and annotations deferred until users need multi-report review.
2. Keep proposal reality-check mode and broader external research integrations outside core audits unless a separate opt-in product request displaces current roadmap work.
3. Treat future comparable-tools and MCP capability registry updates as maintenance work, not core audit expansion.
4. Treat attached MCP staleness as a client refresh/rebind issue and run the live QA checklist before trusting report smoke results.
