# File Ownership And Parallel Work Rules

## Ownership Model

- Product/orchestrator owns master docs, roadmap, ADRs, global tickets, and final prioritization.
- UX/UI owns report artifacts, workflow clarity, host-AI instructions, and optional UI exploration.
- UX research owns comparable tools, user value hypotheses, argument map, check-worthy claims, and evaluation framing.
- Trust/security owns dissent ledger, source/tool trust, consent boundaries, prompt injection, tool poisoning, and sensitive elicitation risks.

## Parallel Work Rules

- No two roles edit the same destination file at the same time.
- Specialists may draft staging notes, but only the assigned owner writes final destination files.
- Preserve disagreements in the relevant risks or dissent section instead of flattening them.
- Any feature implementation requires a ticket and phase assignment before code changes.
- Existing `server.py`, `audit_report/`, persistence files, and schema files are implementation surfaces and must not be edited during Phase 1 planning.

## Current Planning Ownership

| Destination | Owner |
|---|---|
| `docs/planning/master-prd.md` | Product/orchestrator |
| `docs/planning/master-roadmap.md` | Product/orchestrator |
| `docs/planning/adopt-adapt-reject-matrix.md` | Product/orchestrator |
| `docs/planning/mergeability-matrix.md` | Product/orchestrator |
| `docs/planning/file-ownership-and-parallel-work-rules.md` | Product/orchestrator |
| `docs/agents/agent-charter.md` | Product/orchestrator |
| `docs/evals/evaluation-strategy.md` | Product/orchestrator with UX research review |
| `docs/adr/*` | Product/orchestrator with trust review |
| `docs/planning/ideas/*argument*` | UX research |
| `docs/planning/ideas/*checkworthy*` | UX research |
| `docs/planning/ideas/*report*` | UX/UI |
| `docs/planning/ideas/*trust*` | Trust/security |

## Merge Criteria

- Planning docs must state scope, dependencies, risks, acceptance criteria, and smallest shippable slice.
- Every outside inspiration must have adopt/adapt/integrate/reject classification.
- Any future public API change must cite the relevant idea PRD and ADR.
