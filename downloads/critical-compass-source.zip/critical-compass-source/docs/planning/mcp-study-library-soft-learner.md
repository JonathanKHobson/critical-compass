# MCP Study Library Soft Learner

Status: active
Date: 2026-04-15

## Decision

Critical Compass may learn from the local MCP study library at `/Volumes/Kyle SSD II/ExternalApplications/mcp-study-library`, but the study library is not a runtime dependency and is not permission to merge, install, import, or call external MCPs.

The shipped artifact is a soft-learning registry: original Critical Compass summaries of patterns worth adopting, adapting, documenting, deferring, or rejecting.

## What This Adds

- `support/registry/mcp_study_lessons.json`: machine-readable lesson records.
- `support/registry/mcp_study_lessons.schema.json`: allowed fields and enum values.
- `scripts/scan_mcp_study_library.py`: read-only scanner that emits candidate evidence from docs, prompts, schemas, examples, and golden fixtures.
- `critical_compass_overview(topic="mcp_composition")`: exposes the study-lessons summary alongside the capability registry.

## What This Does Not Add

- No new public MCP tool.
- No runtime dependency on downloaded MCP repos.
- No third-party code or long prompt text copied into Critical Compass.
- No live external MCP calls.
- No marketplace or plugin installation workflow.

## Adaptation Rules

Use `adopt_pattern` when a lesson strengthens an existing Critical Compass surface without adding external dependency.

Use `adapt_language` when the idea is useful but must be rewritten in Critical Compass terms.

Use `document_only` when the source is useful background but should not affect runtime behavior.

Use `reject` when the lesson is mainly a boundary, caution, or anti-pattern.

## Current Lesson Themes

- Host-facing project context and client hints can improve discoverability.
- Trigger matrices are useful when they prevent over-calling tools.
- Structured confidence, uncertainty, revision, and branching concepts are useful only inside bounded audit artifacts.
- Security scanners and proxy MCPs inform trust preflight, but are not current runtime dependencies.
- Factuality frameworks belong in a future evaluation lane, not the main audit loop.
- Generic thinking tools are a scope-expansion risk unless embedded in concrete workflows.

## Review Rule

Before any lesson becomes code, ask what it displaces. If it displaces Critical Compass synthesis, plurality review, report readiness, or consent boundaries, reject or keep it scaffold-only.

## MCP Study Library Implementation Roadmap

This roadmap turned the study-library lessons into implementation tickets ordered by verdict. The first `Ship next` slice is complete. Study-library learning is now support infrastructure; it is no longer the active roadmap center unless a lesson directly improves a public/nonprofit pressure-test workflow.

### Impact vs Effort Matrix

| Verdict | Item | Impact | Effort | Implementation Decision |
|---|---|---:|---:|---|
| `Completed ship-next` | Host-AI Quickstart / Current State Context resource | High | Low | Implemented as scaffold resource and manifest entry. |
| `Completed ship-next` | Client-specific one-line hints for Claude, Codex, Cursor-style hosts | High | Low | Implemented as host hints without client-specific runtime behavior. |
| `Completed ship-next` | Tool trigger matrix | High | Medium | Implemented as call-when/do-not-call/ask-first/output-label resource. |
| `Completed ship-next` | Surface sync checklist plus lightweight validator | High | Medium | Implemented as scaffold resource and `validate_mcp_surface_sync.py`. |
| `Use for local ClaimReview phase` | Adapter boundary checklist and golden-fixture requirement | High | Medium | Apply when extending local ClaimReview and direct publisher harvest. |
| `Good next phase` | External MCP trust preflight checklist | High | Medium | Convert mcp-shield/mcp-guard lessons into a trust checklist before any live external orchestration. |
| `Defer until examples prove need` | Confidence, uncertainty, revision, and branch metadata | Medium | Medium | Add only if real advanced-audit examples show stage artifacts need it. |
| `Defer until examples prove need` | Manifest/resource linter | Medium | Low | Keep behind the surface-sync validator until scaffold churn creates recurring misses. |
| `Later / high effort` | Factuality eval subsystem inspired by OpenFactCheck | Medium | High | Keep as future eval architecture, separate from core audits. |
| `Later / high effort` | Runtime MCP guard/proxy layer | Medium | High | Revisit only after trust policy hardens and a real external MCP route exists. |
| `Reject / scaffold-only` | Generic think/scratchpad public tool | Low | Low | Reject as public surface; keep thinking pauses inside concrete workflows. |
| `Reject / scaffold-only` | Provider/payment consensus MCPs | Low-Medium | High | Keep as scaffold-only unless a transparent local or user-provided provider path is approved. |

### Completed Ship-Next Tickets

1. Done - `MSL-01`: Add Host-AI Quickstart / Current State Context resource and expose it through the scaffold manifest.
2. Done - `MSL-02`: Add client-specific one-line hints for Claude, Codex, and Cursor-style hosts, written in Critical Compass language.
3. Done - `MSL-03`: Add the tool trigger matrix for `critical_compass_overview`, `prepare_audit_source`, `audit_text`, `advanced_audit`, `factcheck_lookup`, report tools, Human Loop, persistence, and MCP composition.
4. Done - `MSL-04`: Add the surface sync checklist and lightweight validator so public docs, overview, tool inventory, scaffold manifest, and tests fail loudly when the shipped surface drifts.

### Current Active Phase

Pressure-Test Readiness is now the active phase. It asks whether Critical Compass helps public users and nonprofit teams decide what to trust, revise, verify, or reframe before use. Study-library lessons should be pulled forward only when they directly improve that pressure-test outcome.

### Later Tickets By Verdict

- `MSL-05` / local ClaimReview phase: require adapter boundaries and golden fixtures before adding or changing retrieval adapters; resume only if real pressure-test examples show fact-check scaffolding is insufficient.
- `MSL-06` / good next phase: add external MCP trust preflight checklist; keep it non-runtime until a candidate route is approved and the pressure-test value is concrete.
- `MSL-07` / deferred: evaluate confidence, uncertainty, revision, and branch metadata only against real advanced-audit misses.
- `MSL-08` / deferred: promote manifest/resource linter only if the lightweight validator does not catch recurring scaffold drift.
- `MSL-09` / later: design factuality eval subsystem separately from user-facing audits.
- `MSL-10` / later: revisit runtime guard/proxy only after a reviewed external MCP route exists.
- `MSL-11` / rejected: do not add a generic public think tool.
- `MSL-12` / scaffold-only: keep provider/payment consensus MCPs out of runtime paths.
