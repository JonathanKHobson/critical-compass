# Critical Compass Mission, Audience, And Purpose Charter

Status: active
Date: 2026-04-15

## Mission Sentence

Critical Compass helps people and mission-driven organizations pressure-test text before they use it, so weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads.

## Audience Hierarchy

1. General public users and nonprofit teams who need plain-language help reviewing text before sharing, teaching, funding, reporting, publishing, or acting.
2. Host AIs such as Claude, Codex, and other MCP clients that need stable routing, scaffolds, and guardrails for helping those users.
3. Maintainers and integrators who need schemas, registries, validators, and composition policy without mistaking infrastructure for the product center.

## Core User Job

The core job is: "Pressure-test this before I use it."

Users bring drafts, claims, articles, reports, advocacy copy, grant language, public statements, research-adjacent text, or decision materials. Critical Compass should help them see what is strong enough to use, what needs revision, and what should be verified or reframed first.

## Nonprofit Use Cases

- Find weak evidence, overstated claims, or unsupported impact language before publication or submission.
- Surface assumptions, missing stakeholder voices, bias patterns, fallacy risks, and framing gaps in advocacy, education, fundraising, and public communication.
- Identify factual claims worth verifying without treating "worth checking" as "false."
- Flag overly Western, institutionally narrow, or missing knowledge-community perspectives when those limits could affect interpretation or harm.
- Turn audit findings into practical next questions, revision prompts, and report artifacts a team can actually use.

## Product Pillars

- Plain-language pressure testing before use.
- Evidence humility: distinguish support, uncertainty, no-match states, and verification needs.
- Framing and power awareness: show whose perspectives, institutions, and knowledge traditions are present or missing.
- Human-in-the-loop reflection: make user judgment visible without letting opinion silently rewrite evidence.
- Local-first, consent-aware operation: prefer local source preparation and explicit opt-in for retrieval, persistence, or external tools.
- Host-AI reliability: give agents stable contracts so they route correctly and do not overclaim what a scaffold or provider result proves.

## Non-Goals

- Critical Compass is not an omniscient fact-checker or truth oracle.
- Critical Compass is not a marketplace of thinking MCPs.
- Critical Compass is not a generic "think tool" detached from concrete text, claims, reports, or decisions.
- Critical Compass does not add automatic web retrieval to core audits.
- Critical Compass does not treat external providers, downloaded MCP repos, or scaffold-only prompts as replacements for its synthesis, plurality review, or report-readiness judgment.

## Decision Filter For Future Work

Every roadmap item should pass this filter:

1. Does it help a person or nonprofit pressure-test text before use?
2. Does it make evidence, uncertainty, assumptions, framing, and missing voices clearer?
3. Does it reduce overclaiming, false certainty, or harmful communication?
4. Can the value be explained in plain public language?
5. Does it preserve Critical Compass judgment instead of outsourcing it to providers, external MCPs, or opaque retrieval?

If the answer is no, the item is infrastructure, deferred, or rejected.

## Roadmap Implications

- Keep `audit_text`, `advanced_audit`, `claim_stress_test`, `factcheck_lookup`, reports, and Human Loop centered on the pressure-test-before-use promise.
- Treat MCP composition, study-library learning, provider adapters, and local retrieval as support infrastructure, not the product story.
- Keep fact-checking scaffold-first by default and frame it as responsible verification guidance, not a truth oracle.
- Move overly Western perspective and missing knowledge-community checks into core public explanation, not only advanced docs.
- Do not add new MCP orchestration, provider APIs, or runtime external integrations until they clearly improve the public/nonprofit pressure-test use case.

## What Not To Build Next

- Do not build another external MCP orchestration layer until a concrete user-facing pressure-test workflow needs it.
- Do not expand provider-backed fact checking until the local and scaffold-first user value is clear in real examples.
- Do not add generic reasoning tools unless they produce a concrete audit, claim card, report, or revision decision.
- Do not let technical registry work displace public-facing clarity, nonprofit usefulness, or finished report/audit quality.

## Alignment Test Scenarios

- A nonprofit pastes advocacy copy and asks whether it is safe to publish.
- A public user pastes an article and asks what claims, assumptions, and framing gaps they should notice.
- A grant writer pastes impact claims and asks where evidence is weak or overstated.
- A host AI explains Critical Compass without mentioning MCP composition first.
- A roadmap item is proposed and must justify how it improves pressure-testing before use.
