# Fact-Check State Of The World

Status date: 2026-04-15

## Current Shipped State

Critical Compass fact-checking is **scaffold-first**.

`factcheck_lookup` defaults to `guided_research`. It does not perform retrieval, does not require API keys, and does not imply that a local index exists. It returns:

- normalized claim records
- epistemic framing
- suggested queries
- recommended source classes
- evidence trail template
- plurality review template
- structured cautions and warnings

This is designed for host AIs such as Claude or Codex that already have browsing or research tools.

## Current Opt-In Retrieval

The retrieval layer is now available only when explicitly selected:

- `local_claimreview` searches a configured local ClaimReview index and sends no claim text externally.
- `publisher_harvest` harvests ClaimReview JSON-LD from approved publisher sites and requires `allow_external_calls=true`.
- the publisher registry carries region, language, source-class, governance, and coverage notes.

This is not the default. Populate the local index with `scripts/build_claimreview_index.py` before expecting local matches.

## Later Optional Phase

Provider-backed retrieval stays optional and experimental:

- `publisher_site_search`
- `google_fact_check_tools`
- `brave_search`
- future source credibility or search providers

These providers require explicit selection and explicit user authorization. They are not the main value proposition.

## Product Rule

Critical Compass is the orchestrator of claim selection, epistemic framing, verification scaffolding, evidence trails, and plurality-aware synthesis. It is not a provider-key-dependent fact-check wrapper.
