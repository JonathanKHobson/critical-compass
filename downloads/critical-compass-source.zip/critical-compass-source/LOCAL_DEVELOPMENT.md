# Critical Compass

Critical Compass helps people and mission-driven organizations pressure-test text before they use it, so weak evidence, hidden assumptions, bias, fallacies, false claims, missing voices, and overly narrow Western framing are easier to see before harm or overclaiming spreads.

The public purpose is human: a plain-language critical-thinking coach for people reviewing drafts, claims, articles, reports, advocacy copy, grant language, public statements, or research-adjacent text before publishing, sharing, teaching, funding, reporting, or acting. The implementation is host-AI/MCP-powered, but the product center is the audit and the decision it helps a person make.

Use Critical Compass when the core question is: **"Should I trust or revise this before I use it?"**

The mission, audience, and decision filter for future work live in `docs/planning/mission-audience-purpose-charter.md`.

The public release narrative lives in `docs/public/why-critical-compass.md`. It explains who the tool is for, why local-first matters, why the KB is useful but not final authority, and what Critical Compass does not do: it does not verify truth by default, replace human judgment, guarantee non-Western perspectives are correctly represented, or prevent biased outputs; it surfaces risks for review.

Public positioning explains how Critical Compass differs from argument-mapping apps, research-evidence products, fact-check databases, and generic reasoning assistants without implying those tools are bundled, required, or called by default.

## Corpus Snapshot

This corpus snapshot contains 421 source files and 793 normalized entries, organized for AI-first critical-thinking retrieval.

## Layout

```text
CriticalThinking/
  scripts/
  incoming/
    raw/
      source-critical-thinker-biases-data/
      source-glossary-js/
      source-exports/
      database/
        glossary/
        patterns/
        tasks/
  normalized/
    biases/
      cognitive/
      ai/
      cultural/
    reasoning-frameworks/
      inference/
      argumentation/
      uncertainty/
    thinking-lenses/
      systems/
      reflective/
      dialectical/
      design/
      creative/
    fallacies/
      formal/
      informal/
    heuristics/
      judgment/
      decision/
    methodology-checks/
      audit/
      preflight/
      red-team/
      calibration/
    other/
      legacy/
      transcripts/
      paradoxes/
      prompting/
      decision-cases/
      social-dynamics/
      ai-governance/
      adjacent/
  indexes/
    graph/
    reverse/
  support/
    library/
    taxonomy/
    registry/
    schema/
```

## Notes

- Canonical root: `/Volumes/KyleSSD/CriticalThinking`.
- `scripts/build-critical-thinking-corpus.mjs` is the standalone generator and source of truth.
- `incoming/raw` preserves the local source bundle for rebuilds.
- `normalized` holds the canonical machine-readable records.
- `indexes` holds source manifests, retrieval indexes, graphs, and review reports.
- `support` holds schema, taxonomy, registry, and usage references.

## Critical Integrity Snapshot

The MCP `audit_text` tool returns a `critical_integrity_snapshot` inside the Quick-Scan Card and at top level. CIS is a criterion-referenced snapshot, not a grade.

- User-facing name: Critical Integrity Snapshot.
- Internal shorthand: CIS.
- Default `snapshot_mode`: `organizer`.
- Optional `snapshot_mode`: `research`.
- Labels: Exemplary Integrity, Strong Integrity, Moderate Integrity, Limited Integrity, Needs Scrutiny.
- Points are shown as points only, never as percentages or A-F grades.
- Confidence and comparability are separate from points.
- `profile_only` suppresses label and points when the aggregate would be misleading.
- `display_policy` tells host AIs whether points should be secondary or suppressed, whether the profile should be shown first, and what comparability warning to render.

The five equal dimensions are:

- Grounding & Scope Fit
- Assumptions & Context
- Bias Transparency
- Framing & Audience Openness
- Positionality & Power

The context lens detects evidence convention, purpose, and voice from textual signals. It does not infer the author's cultural identity.

Every scored or profile-only CIS now emits two standardized reader lines: `plain_language_read` is a single concise verdict sentence, and `before_using_this_text` is a single action question that starts with “Before using this text,”. These fields are required in report-ready payloads and are rendered in both audit outputs and PDF reports.

## Argument Maps And Check-Worthy Claims

`audit_text` now returns compact reasoning artifacts alongside CIS:

- `argument_map` names the central claim, claim type, supporting reasons, objections, assumptions, missing voices, evidence gaps, next questions, and includes Markdown plus `.argdown` export strings.
- `checkworthy_claims` separates factual, interpretive, causal, normative, and policy claims. Only factual claims receive `high`, `medium`, or `low` verification priority; all other claim types use `not_ranked`.
- Every check-worthy claim carries the notice that check-worthy means worth verifying, not false.

These artifacts are local-first and do not trigger web search or fact retrieval. They identify what is worth checking next; they do not decide whether a claim is true.

## Scaffold-First Fact-Check Lane

`factcheck_lookup` is a verification-planning tool for factual claims that already came from `checkworthy_claims`. The shipped default is `provider="guided_research"`: no API key, no live retrieval, and no local index implied. It leads with “No retrieval was performed,” then returns a user-facing summary, epistemic framing, suggested queries, recommended source classes, an evidence trail template, a plurality review template, and opt-in retrieval paths for host AIs that already have browsing tools.

The current stack is:

- Layer 0: claim selection through `checkworthy_claims`.
- Layer 1: epistemic framing before verification, including domain sensitivity, consensus age, Western-bias risk, and knowledge communities with standing.
- Layer 2: verification scaffold for responsible host-AI browsing.
- Layer 3: opt-in retrieval through a configured local ClaimReview index, direct approved-publisher ClaimReview harvest, and optional later provider-backed retrieval.
- Layer 4: synthesis with epistemic provenance.

`provider="auto"` is deprecated and now returns guided-research scaffolding with a visible warning. `provider="local_claimreview"` searches a local ClaimReview index when configured and sends no claim text externally. `provider="publisher_harvest"` directly harvests ClaimReview markup from approved publisher sites and requires `allow_external_calls=true`. Provider-backed search remains optional and experimental: `publisher_site_search`, `google_fact_check_tools`, and `brave_search` require an explicit provider name plus `allow_external_calls=true`. Google/Brave key setup is not part of the main path.

Advanced provider notes remain in `docs/specs/factcheck_lookup_contract.md`. The trusted publisher allowlist lives at `support/registry/trusted_factcheck_publishers.json`; build a local index with `python3 scripts/build_claimreview_index.py <claimreview-source.json> --output support/registry/local_claimreview_index.json`.

Example input:

```json
{
  "claims": [
    {
      "claim_id": "claim-1",
      "text": "The city reduced bus fares by 25 percent in 2024.",
      "claim_type": "factual",
      "is_factual": true,
      "verification_priority": "high"
    }
  ],
  "provider": "guided_research",
  "publisher_sites": ["factcheck.org", "politifact.com"],
  "max_age_days": 3650,
  "allow_external_calls": false
}
```

Scaffold responses include `lookup_performed=false`. Provider-backed responses, when explicitly requested and authorized, may return `match_found`, `multiple_matches`, `conflicting_reviews`, `no_trusted_match`, `sensitive_blocked`, or `provider_error`. A no-match state is a coverage limit, not a truth verdict.

Calibration fixtures live at `support/cis-calibration-fixtures.json` and cover institutional reporting, nonprofit advocacy, lived-experience testimony, community voice, research methodology, and short insufficient text.

## Research Audit Coverage

The MCP includes a research-methodology profile for empirical and policy-research audits. `retrieval_profile` accepts `auto`, `general`, or `research_methodology`; `auto` selects methodology-first retrieval when `text_type="research"`, `text_type="academic_abstract"`, or study-method cues are visible.

`text_type` accepts `general`, `advocacy`, `policy`, `sales`, `research`, `journalism`, `narrative`, `social_media`, `academic_abstract`, `product_copy`, `legal`, `ai_generated`, and `other/general`. `academic_abstract` routes through research-methodology checks. `product_copy` and `social_media` use persuasive/framing cues. `legal` is reviewed for argument, evidence, assumptions, and power without implying legal advice. `ai_generated` emphasizes LLM-bias risk, synthetic certainty, polished-but-unsupported claims, and missing provenance.

The research profile adds KB-backed lookups for WEIRD bias, demand characteristics, social desirability bias, overgeneralization, publication bias, p-hacking, HARKing, sampling/selection bias, nonresponse bias, attrition bias, construct validity, external validity, ecological validity, measurement validity, internal validity, replicability, preregistration, and statistical power.

`audit_text` returns a `replication_readiness` companion signal for research/study-shaped text. This is separate from the Critical Integrity Snapshot and asks whether another team could reproduce or stress-test the claim from the visible sample, measures, design, context, and reproducibility details.

`advanced_audit(text_type="research")` now prioritizes research-methodology reasoning flows and demotes career, product, and execution frameworks unless the subject explicitly asks for those domains. Use `scaffold_detail="handoff"` when a host agent needs the smallest useful stage contract; it returns `stage_handoff` plus compact required output fields instead of long schemas.

## Lens Cards, Retrieval Budgets, And Fairness-To-Text

Critical Compass exposes compact `lens_card` metadata on KB-backed biases, fallacies, frameworks, thinking lenses, and methodology checks. A lens card gives short/standard/full summaries, use cases, do-not-use guidance, misuse warnings, related IDs, token budgets, quality flags, and source confidence without loading the full corpus into the host context.

Audit modes use bounded retrieval:

- `quick`: up to 3 short lens cards
- `standard`: up to 5 standard lens cards
- `advanced`: up to 8 standard lens cards with selection reasons
- report/preflight: compact host-facing summaries only

`audit_text`, `quick_scan`, `search_knowledge_base`, `get_framework`, and advanced scaffolds expose `selected_lens_ids`, `retrieval_budget`, and selection reasons where relevant. Host AIs should cite KB IDs when using named lenses; labels without lookup must be marked `host_inference`.

Audits also include a host-facing `fairness_to_text` stage. It records the strongest charitable reading, genre/context constraints, expected non-findings, and downgraded critique where the text does not justify a firm label. In beta.10 this is QA metadata and should not create a new default PDF page.

The current AIGlossary cross-check confirms the beta.10 baseline `bias` and `llm-bias` rows from `/Volumes/KyleSSD/Websites/AIGlossary/glossary/js/biases.data.js` have matching MCP bias entries by ID or title. Newer draft gap-fill rows in that external glossary are reported as deferred coverage, not silently treated as shipped Critical Compass corpus.

Run `scripts/validate_research_audit_coverage.py` after changing the bias library, reasoning flows, or advanced-audit scaffolds. It checks the research-methodology bias lookups, AIGlossary bias coverage, research candidate-flow ranking, CIS scaffold fields, and replication-readiness output.

## Claim Stress-Test

`claim_stress_test(claim, context=None, audience=None)` returns a compact host-renderable card for one claim. Use it for fast daily claim interrogation: steelman, fallacy risk, when the same pattern may be valid reasoning, probing questions, next actions, and a Markdown fallback.

`challenge_claim` remains the compatibility tool for `advanced_audit` scaffolds and agent workflows. It keeps the legacy steelman / fallacy risk / probing-question shape, while sharing the same deterministic KB-backed fallacy selection as `claim_stress_test`.

The MCP owns the structured card data. Claude, Codex, or another host AI owns interactive rendering, such as buttons, expandable card sections, or quick replies from `next_actions`. Fallacy labels are conservative risks, not verdicts.

## Onboarding And Discovery

`get_started(topic=None, audience="both")` is the first-session tool for new users, installation/onboarding, "what do I do first?", and first audit setup. It gives a first-five-minute path, starter prompts, the `get_started` vs `critical_compass_overview` routing rule, and a beta calibration intake path for audits that felt wrong, confusing, too harsh, too soft, or culturally narrow.

`critical_compass_overview(topic=None, audience="both")` remains the capability and workflow lookup tool for existing users and host AIs. It explains core workflows, practical case studies, starter prompts, tool routing, workflow resources, report contracts, output requirements, and current Critical Compass capabilities. Topics include `overview`, `quick_start`, `audits`, `claim_stress_test`, `fact_checking`, `human_loop`, `reports`, `app_ui`, `knowledge_base`, and `saved_patterns`.

`quick_scan(text, ...)` is the low-activation entry point. It returns only CIS, top 2 biases, key tension, one action, text type, and guidance to run `audit_text` next. It is not a replacement for `audit_text`.

`list_agent_personas(subject=None, text_type=None, ...)` surfaces advanced-audit persona archetypes, custom persona schema, pressure-test persona seeds, safe examples, and guardrails before agent mode. Custom roles such as policy analyst, community organizer, grant reviewer / evidence steward, AI/data auditor, affected-community reviewer, or Indigenous knowledge-holder review are treated as analytical perspectives and missing-voice/evidence-with-standing checks, not identity impersonation.

For Indigenous health equity, tribal/First Nations, public-health measurement, data sovereignty, food sovereignty, or community-evaluation text, host AIs should retrieve KB-backed lenses before naming OCAP, CARE Principles, Indigenous data sovereignty, data erasure, relational accountability, or community authority. If no lookup was performed, the label should be marked as host inference rather than KB-grounded.

`suggest_next_steps(domain, biases_found)` returns concrete mitigation actions and optional `practice_suggestions` for lightweight teaching follow-up. Practice suggestions stay inside existing outputs; there is no standalone Practice Activity Tool unless later gate criteria are met.

## Agentic Panel Review

`advanced_audit(mode="agent")` is the staged panel-review path. It is explicit opt-in only: safe user phrases include `advanced panel review`, `agentic panel review`, `multi-perspective panel`, and `run the agent audit`. Do not trigger agent mode from generic words like `agent`, `agency`, `city council`, `panel`, `committee`, or `stakeholders` without review-mode intent.

Standard and deep agent mode now starts with `status="agentic_plan_review_required"`. The payload includes `agentic_plan_hash`, `agent_execution_adapter`, four schema-first `role_contracts`, `stage_plan`, `artifact_budget`, `agentic_progress_state`, and one approval question. To proceed, the host passes `agentic_state.plan_approved=true` and `agentic_state.approved_plan_hash` equal to the returned hash. If the user declines, route to `audit_text`.

`host_capability_profile` tells the MCP whether the host can run real subagents or should use a sequential fallback. Claude Code uses `claude_native_subagents` only when `native_subagents=true`; Codex uses `codex_explicit_subagents` only when `explicit_subagent_spawn=true`; generic chat and Claude Desktop default to `sequential_labeled_fallback`; hosts that cannot execute stage scaffolds use `scaffold_only`. Sequential fallback must disclose that the panel is simulated in one thread.

Agentic stages carry artifacts, not full transcripts. Stage payloads include `artifact_only_handoff=true`, `do_not_pass_full_transcript=true`, compact carry-forward keys, and a one-pass revision budget for snapshot-changing `FRAME_COLLAPSE` or `NEEDS_EVIDENCE` tensions.

## MCPB Desktop Extension Distribution

The preferred non-technical distribution path is MCPB/Desktop Extension: build a `.mcpb` bundle, attach it to a GitHub Release, and let users install it through Claude Desktop Settings > Extensions. This is the closest available path to one-click install, has no hosting cost, and avoids asking normal users to edit Claude Desktop JSON by hand.

The MCPB packaging files live in `packaging/mcpb/critical-compass/`. Build the staged bundle with:

```bash
python3 scripts/build_mcpb_bundle.py
```

Pack the release artifact with the official MCPB CLI through `npx`:

```bash
python3 scripts/build_mcpb_bundle.py --pack
```

The script stages `dist/mcpb/critical-compass/` and writes `dist/mcpb/critical-compass-0.1.0.mcpb` when packing succeeds. It includes the read-only canonical database, support resources, core modules, and MCPB launcher, but excludes tests, reports, raw source folders, AppleDouble sidecars, and the writable state database.

Installed MCPB users write state, report artifacts, and fact-check cache files to their own app-data directory through `mcpb_launcher.py`; the extension bundle stays read-only. The install/diagnostic prompt for Claude, Claude Code, or Codex lives at `packaging/mcpb/INSTALLER_DIAGNOSTIC_PROMPT.md` and is also exposed as the scaffold resource `mcpb_install_diagnostics_prompt`.

### Windows Config Safety Note

The May 2026 Windows field test showed that the Critical Compass plugin could start cleanly while the manual install path damaged Claude's existing workspace config. The failure mode was install-layer drift, not MCP runtime failure: a config writer shrank `claude_desktop_config.json`, removed unrelated `mcpServers` entries, and wrote a UTF-8 byte-order mark. On Windows PowerShell 5.x, `Set-Content -Encoding UTF8` can add the `EF BB BF` BOM that Claude Desktop may reject.

Manual config install is therefore a technical fallback only. Any helper or AI-assisted path must back up the config, read existing keys, merge only `mcpServers.critical-compass`, write UTF-8 without BOM, and print before/after server names so existing MCPs are visibly preserved. Use a no-BOM writer such as Python `json.dump(..., encoding="utf-8", newline="\n")` or .NET `System.Text.UTF8Encoding($false)`.

## Host Scaffolds And Current-State Guidance

Critical Compass ships a compact scaffold layer for host AIs and maintainers. The goal is to make the current product easier to use: which tool to call, what to ask first, when to pause for the human loop, what fields are needed before report generation, and how to keep the teaching contract visible in every audit-facing output.

The scaffold resources live in `support/resources/scaffolds/v1/` and include the Host-AI Quickstart / Current State Context, client-specific host hints, tool trigger matrix, tool inventory, surface sync checklist, report-ready payload example, and report/viewer runbooks. These are current-state usage guides, not future-roadmap promises.

`list_concept_examples(category=None, query=None, limit=8)` returns friendly concept cards for biases, fallacies, thinking lenses, reasoning frameworks, methodology checks, and broader patterns. Use it when a user wants examples before choosing an audit path. The deeper inventory tools remain `list_categories`, `get_entry`, `search_knowledge_base`, and `list_reasoning_flows`.

## Human Loop Three-Block Flow

`audit_text`, `advanced_audit`, and `synthesize_audit_verdict` support a bounded-decision-rights `human_loop` contract. `human_loop_mode` accepts `guided`, `minimal`, or `silent`; `human_loop_state` carries prompt answers, skips, commentary, evidence additions, stale sections, and rerun markers across turns without a database migration. Guided is the default user-facing mode. Silent mode requires explicit user confirmation in `human_loop_state` or an explicit noninteractive smoke-test override; otherwise the MCP stops at a one-question `mode_consent` gate before any audit, silent parse, findings reveal, scaffold exposure, or report generation.

Guided mode now uses three fixed blocks:

- `onboarding` happens before the core audit and asks why the user is running the audit, the intended audience, their relationship to the text, and the desired output.
- `judgment` happens after a silent parse but before findings, scores, or bias labels are revealed. It asks for the user's raw read, suspected issues, and pressure-test target.
- `reflection` happens after a three-bullet `preview_before_reflection` and before final PDF, Markdown, chat, save, or report output. It asks what stood out, what shaped that view, and what the final output should help the user do next.

Guided mode exposes four onboarding prompts plus three judgment prompts and three reflection prompts. Minimal mode compresses to one prompt per block; silent mode asks none. Prompt payloads include `selection_mode`, `max_selections`, `allow_free_text`, `free_text_prompt`, `skill_tags`, `why_i_am_asking`, `what_this_can_change`, and `what_this_cannot_change` so Claude/Codex can render multiple-choice or multi-select question cards plus one short optional note field.

The MCP exposes only the current stage's askable prompts. `mode_consent` returns exactly one question; `onboarding` returns no more than four in guided mode; `judgment` and `reflection` return no more than three. `human_loop_host_action` is a host interaction contract, not a style preference: when `PAUSE_REQUIRED=true` or `must_pause=true`, hosts must render the current `questions_for_user` block through native conversational UI before continuing. In Claude, use `Ask_User_Input_V0` / the `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` question types. `plain_text_questions_valid=false` means ordinary chat questions violate the contract when the widget is available. Compact inline fallback is allowed only when native widget UI is unavailable, and it must still follow the current-block-only rule.

Critical Compass cannot force Claude API `tool_choice` from inside the MCP. Instead, pause responses expose `required_interaction_surface`, `claude_widget_tool_name`, `allowed_question_types`, `widget_compliance_check`, `tool_compliance_signal`, `repair_instruction`, and a compact `runtime_policy_card` so hosts can route, validate, and repair widget use outside the model.

Human input is separated into configuration, evidence, commentary, and quarantined opinion buckets. Configuration can shape routing and report framing. Verified evidence can mark findings stale and trigger rerun/version increment. Commentary is labeled human perspective and does not change frozen AI findings unless promoted to evidence and rerun.

The middle judgment block is deliberately not a fallacy quiz. It uses plain-language options mapped to internal skill tags such as evidence attention, assumption spotting, perspective-taking, confidence calibration, and openness to revision. Those learning signals stay session-local for now; this release does not add persistent reasoning profiles, gamification, migrations, or dashboards.

Every prompt includes skip semantics. Skipped prompts are recorded and the audit continues. Silent mode suppresses prompts but still returns assumption disclosure. PDF reports can include Human Auditor Commentary, a conditional Human-AI Divergence Map, Learning Notes, and a Provenance Footer.

Host AIs must treat `human_loop_host_action.must_pause=true` as an interaction gate. Mode consent must clear before honoring silent mode. Onboarding must clear before the core audit, judgment must clear before findings are shown, and reflection must clear before final output or report generation. The only intended exception is an explicitly noninteractive smoke test; in that case, disclose that prompts were skipped and preserve the pending prompt IDs in the test result. `generate_audit_report` returns a schema warning if audit data still carries pending human-loop prompts.

## Writable State And User Additions

The canonical KB remains read-only. The MCP opens `db/critical-compass.sqlite` in read-only mode and stores user state separately in `db/critical-compass-state.sqlite`.

Writable tools support:

- `save_audit_progress`, `get_audit_progress`, and `list_audit_progress` for resumable audit checkpoints.
- `save_audit_progress` can include `cis_revision_event`; `get_cis_revision_timeline` returns score/confidence/comparability changes across a saved audit.
- `save_audit_result`, `get_audit_result`, and `list_audit_results` for longitudinal CIS tracking. Results store CIS label/points, confidence, comparability, context lens, knowledge/rhetorical tradition, dimension scores, biases, verdict, replication readiness, and optional activity-outcome feedback inside `result_payload`.
- `list_audit_results` can filter by `cis_score`, `cis_score_min`, `cis_score_max`, `cis_score_below`, `dimension_name`, and `dimension_score_below`, so queries like “advocacy texts sorted by CIS score” and “texts below 12 on Framing & Audience Openness” are supported.
- `compare_audit_results(result_id_a, result_id_b)` diffs two saved final audit results and returns descriptive CIS, dimension, bias, workflow, and context-lens deltas. It can also compare two already-audited inline payloads with `result_payload_a` and `result_payload_b`; it does not audit raw text, run retrieval, or auto-save temporary results. It uses `direct`, `qualified`, `weak`, and `not_comparable` statuses so users do not mistake a score delta for proof of improvement.
- `save_bias_pattern`, `save_entity_pattern`, and `get_pattern_summary` for recurring bias/framework/flow patterns across audits.
- `save_kb_addition`, `update_kb_addition`, and `soft_delete_kb_addition` for user-added KB overlays.

User-added KB entries are draft-first. `save_kb_addition(status="active")` only exposes an entry to lookup/search when `confirm_active=true` and no duplicate canonical or user-overlay entry is detected. Additions include `rhetorical_tradition` (`western_academic`, `testimonial`, `indigenous_oral`, `ubuntu`, `confucian`, `liberation_pedagogy`, or `other`). Active additions are available immediately through overlay lookup/search and are mirrored to `support/library/user-additions.pack.json`; canonical KB files are never deleted or directly changed.

Run `scripts/validate_writable_state.py` after changing persistence, overlay lookup, or write-tool behavior. It uses a temporary state DB and verifies resumable progress, CIS result filters, pattern tracking, duplicate detection, draft-first activation, overlay lookup, and soft delete.

## Audit Report PDFs

`generate_audit_report` creates stakeholder-ready PDFs from completed `audit_text`, saved audit result, or advanced-audit synthesis-shaped data. The MCP owns normalization, schema validation, Jinja templates, WeasyPrint rendering, PyMuPDF QA, preview PNG generation, and report metadata. The host AI passes data only.

Use `prepare_audit_source` before auditing local PDFs. It extracts embedded text with PyMuPDF, detects sparse/scanned PDFs, rasterizes pages, and uses Apple Vision OCR on macOS when OCR is needed. If text remains too sparse or OCR dependencies are unavailable, the tool returns `blocked` or `needs_ocr_dependency` instead of letting the host audit a copyright notice or near-empty text.

V1 supports:

- `report_depth`: `full`, `overview`, `readiness_card`, or `checklist_only` (`quick` maps to `overview`; `standard` and `deep` map to `full`; `readiness` maps to `readiness_card`).
- `report_mode`: `reader` or `self`.
- `report_audience`: `organizer`, `academic`, `executive`, or `general`.
- US Letter, English left-to-right output.
- Local-only assets and optional raw-text appendix sidecar when the audited text is too long for inline appendix rendering.

First-share default: if the user asks for a report or stakeholder summary but does not explicitly request the full PDF, prefer `report_depth="readiness_card"` after validation. The readiness-card artifact is the safer compact default because it excludes appendices, debug metadata, internal KB notes, activity reflection pages, and advanced placeholder null states while preserving the CIS, before-use guidance, Audit Summary, and one next activity.

Before calling the tool, host AIs should assemble report-ready `audit_data`: Critical Integrity Snapshot, five dimensions, plain-language read, before-use text, key tension, recommended next step, bias rows, dimension improvement prompts, assumptions, alternative frames, questions, next steps, `follow_up_activity.try_this_next`, full-report `follow_up_activity.solo_activity` and `follow_up_activity.group_activity`, and agent top findings when `advanced_audit` is present. The tool accepts the canonical normalized payload plus common authoring aliases. Use `critical_integrity_snapshot.plain_language_read` for the cover verdict, or aliases `plain_language`, `executive_summary`, or `summary`. Dimension rows accept `points` or `score`, `max_points` or `max`, and prompts as `improvement_prompt`, `action`, `strengthen_prompt`, `improvement`, `next_step`, or `prompt`. Bias rows can be passed as `biases`, `top_biases`, `bias_map`, `quick_scan_card.top_biases`, or `findings.biases`; bias names can use `name`, `bias_name`, `title`, `bias_id`, or `id`. Key tension accepts `key_tension`, `quick_scan_card.key_tension`, `findings.key_tension`, or the first usable `tensions[]` item. Agent findings accept `top_finding`, `finding`, `key_finding`, `primary_finding`, `contribution`, `key_contribution`, `insight`, `summary`, or a matching `analyses[].primary_finding`. For complex or advanced reports, call `validate_report_payload` first; it runs the same checks without writing a PDF. If report generation blocks, use the returned preflight card; do not hand-build a separate PDF unless the user explicitly requests a manual placeholder.

`audit_text`, `advanced_audit`, and `synthesize_audit_verdict` return a `report_readiness_contract` so the host AI sees the report contract before it generates the PDF payload. The contract includes:

- the canonical `audit_data` template to use with `validate_report_payload` and `generate_audit_report`;
- a completed example payload using the canonical keys;
- a Markdown checkpoint template for the content that should exist before a full PDF call;
- the accepted alias list for compatibility;
- pre-call and post-call rules that stop automatic regeneration loops.

When a user asks for a PDF report, the host AI should treat this as an audit-to-PDF workflow contract: fill `report_ready_payload`, run `validate_report_payload`, then call `generate_audit_report` once after validation passes. Prefer canonical keys such as `biases`, `key_tension`, `points`, `max_points`, `improvement_prompt`, and `advanced_audit.agents[].top_finding`; aliases are for old payload compatibility, not the preferred authoring format.

Report-ready payloads may also include `argument_map`, `checkworthy_claims`, `external_fact_checks`, `advanced_audit.dissent_ledger`, and `reasoning_traps`. Full reports render these as an Argument Map, Evidence Needed Next table, External Fact Checks section, Where the Analysts Disagreed, and Reasoning Trap Checks when present. External Fact Checks appears only when real trusted matches exist; no placeholder section is rendered on no-match.

`generate_audit_report` now has a strict readiness gate. Full reports require substantive Tier 1 and Tier 2 content; empty arrays, blank strings, fallback strings, and numeric-only next steps such as `"1"`, `"2"`, `"3"` are blocked before Markdown or PDF rendering. When readiness fails, the tool returns `qa_status="blocked"`, `preflight_status="blocked_missing_fields"`, `compiled_sections`, `missing_report_fields`, `what_to_resubmit`, `accepted_aliases`, and no PDF path. Pass `allow_placeholders=true` only when the caller explicitly wants a draft placeholder PDF; those renders return `passed_with_cosmetic_issues` and must not be presented as final.

Successful report generation writes a deterministic Markdown contract next to the PDF before WeasyPrint runs. The result includes `markdown_path`, `markdown_hash`, and `markdown_validation` in addition to the PDF path, page images, preview image, template/render versions, and payload hash.

Successful report generation also writes a local read-only HTML artifact viewer and returns `manifest_path`, `viewer_path`, and `artifact_viewer` metadata. The viewer is generated from the report manifest, opens locally in a browser, and surfaces the decision layer, artifact links, argument map, Evidence Needed Next, analyst disagreements, reasoning traps, questions, and source/tool trust preflight. It does not create findings, run retrieval, edit report data, or replace the PDF/Markdown artifacts as the source of truth. Use `generate_audit_artifact_viewer(manifest_path)` to regenerate the viewer from an existing report manifest.

If report-critical fields are missing or warnings appear, host AIs should tell the caller exactly what is missing and ask whether to re-submit the missing data before requesting a final PDF.

Install report dependencies in the MCP runtime before using the PDF renderer:

```bash
python3 -m pip install -r requirements-report.txt
```

The bundled report requirements pin Apple Vision PyObjC to the Python 3.9-compatible 11.x line used by the local MCP runtime. PyObjC 12.x advertises Python 3.9 support but is yanked upstream and can fail to build locally, so keep the 11.x pin unless the runtime Python is upgraded and revalidated.

Run `scripts/validate_audit_report_renderer.py` after changing report normalization, templates, styles, renderer code, or QA behavior. It renders ready golden fixtures, alias-regression fixture, table-overlap fixture, checklist-only variant, self-mode variant, placeholder override fixture, and long-content cap fixture; it also confirms incomplete reports are blocked with no PDF/Markdown. The script checks PDF text, deterministic Markdown, page images, preview image generation, wrap-safe bias-table layout, and QA status.

Run `scripts/validate_audit_source_preflight.py /path/to/source.pdf` after changing source ingestion or OCR behavior. It verifies local PDF extraction, sparse-text handling, OCR fallback when needed, text artifact writing, and page-image generation.

Run `scripts/validate_factcheck_lookup.py` after changing the fact-check lane. It checks scaffold-first default behavior, deprecated `auto` warnings, opt-in provider gating, publisher conflicts, sensitive-claim blocking, non-factual skips, and provider-error handling without requiring a live API key.

Run `python3 scripts/validate_mcp_surface_sync.py` after changing public MCP surfaces. It checks README, `critical_compass_overview`, tool inventory, server instructions, scaffold manifest, the new Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, surface sync checklist, roadmap docs, and tests.

Public website changes are part of the release surface. Do not patch only the live GitHub Pages checkout or only the generated share kit. Keep these in sync in the same slice:

- `scripts/build_shareable_release.py` as the source generator;
- `dist/share/github-pages/index.html`;
- `dist/share/manual-share/START_HERE.html`;
- the live GitHub Pages `index.html`.

The current landing shell must keep separate `About` and `FAQ` tabs, beta.10 links/checksums, and the advanced-report prompt path: `report_ready_payload` -> `validate_report_payload` -> `generate_audit_report`. `About & FAQ` is a stale combined-tab regression and should fail review.

For website-only corrections after release artifacts already exist, run:

```bash
python3 scripts/build_shareable_release.py --pages-only
python3 -m pytest tests/test_shareable_release.py::test_shareable_release_landing_pages_explain_install_choices -q
python3 scripts/validate_mcp_surface_sync.py
```

Then sync the live GitHub Pages checkout and verify the canonical public URL. The full release builder is still required when the downloadable artifacts themselves change.

Run `scripts/run_beta_audit_calibration.py` after changing reasoning traps, human-loop interruption triggers, or generated audit text scanned by those detectors. It runs six local beta cases, logs expected trap/trigger misses, and records report-readiness fields that would need host-AI completion before a polished PDF.

The calibration script also accepts real user-provided case files with `--cases /path/to/cases.json --output-dir /path/to/output`. Do not fabricate real beta cases; use `support/resources/scaffolds/v1/beta-calibration-intake.md` to collect consented excerpts and expected trap/trigger behavior. Use `scripts/live_mcp_codex_qa.py` after report smoke tests to confirm the repo-local overview, scaffold resources, report contract, and smoke manifest all expose the current source-to-report-to-viewer flow. If the attached Codex or Claude MCP overview is stale, restart/rebind the MCP session before deeper QA.
