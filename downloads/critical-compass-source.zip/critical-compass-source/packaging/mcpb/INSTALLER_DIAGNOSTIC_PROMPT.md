# Critical Compass MCPB Installer / Diagnostic Prompt

Paste this into Claude, Claude Code, Codex, or another capable coding assistant when you want help installing or diagnosing Critical Compass.

```text
You are helping me install or diagnose the Critical Compass MCPB/Desktop Extension in Claude Desktop.

Goal:
- Get Critical Compass installed and visible as an MCP server/tool set.
- Do not delete or overwrite any existing Claude Desktop MCP configuration.
- Preserve unrelated MCP servers and settings.
- Prefer MCPB/Desktop Extension installation over manual JSON editing.
- Treat manual config editing as a technical fallback only for users who have installed MCPs this way before.

Context:
- The package file should be named like critical-compass-0.1.0.mcpb.
- Critical Compass is a local MCP server for pressure-testing text before use.
- It should expose tools such as get_started, critical_compass_overview, quick_scan, audit_text, claim_stress_test, factcheck_lookup, and generate_audit_report.
- factcheck_lookup is scaffold-first by default; it does not require Google, Brave, API keys, or live retrieval.

Steps:
1. Confirm Claude Desktop supports Extensions or MCPB/Desktop Extensions.
2. Help me install the .mcpb through Claude Desktop Settings > Extensions.
3. Restart Claude Desktop if needed.
4. Check whether Critical Compass appears in the available MCP tools.
5. Run a small smoke prompt:
   "Call get_started for Critical Compass and tell me the first five-minute path."
6. If it fails, diagnose in this order:
   - Is the .mcpb file present and not still zipped inside another archive?
   - Is Claude Desktop updated enough to show Settings > Extensions?
   - Did UV dependency setup fail on first launch?
   - Are there Claude Desktop MCP logs showing a process launch error?
   - Are writable files being redirected to user app data rather than the extension folder?
   - Is any failure specific to PDF rendering or OCR rather than the core audit tools?
   - If manual config editing is being considered, did you back up the file, read existing `mcpServers`, and confirm the user is comfortable with this technical fallback?

Safety rules:
- Do not add Google/Brave/provider keys unless I explicitly ask.
- Do not claim factcheck_lookup performed retrieval unless lookup_performed=true.
- Do not treat "no match" as true or false.
- Do not change unrelated servers while diagnosing this install.
- If manual config inspection is needed, read the current config first and preserve all existing entries.
- If manual config writing is needed, merge only the `critical-compass` entry into `mcpServers`; do not rewrite or shrink the whole config.
- On Windows PowerShell 5.x, do not write Claude config with `Set-Content -Encoding UTF8`; it can add a UTF-8 BOM. Use a no-BOM writer and verify the file does not start with `EF BB BF`.
- After any config write, print the before/after MCP server names and confirm all pre-existing servers are still present.

Expected result:
- Critical Compass is installed.
- get_started and critical_compass_overview work.
- Any pre-existing MCP servers still appear after restart.
- If a feature is unavailable, explain whether it is an install issue, dependency issue, renderer/OCR limitation, or normal scaffold-first behavior.
```
