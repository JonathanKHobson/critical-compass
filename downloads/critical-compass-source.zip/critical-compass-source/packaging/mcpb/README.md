# Critical Compass MCPB Distribution

MCPB is the preferred distribution path for non-technical Critical Compass users. It gives the closest available experience to one-click installation in Claude Desktop while keeping hosting costs at zero when the `.mcpb` file is attached to a GitHub Release.

## Current Decision

- Primary path: MCPB / Desktop Extension.
- Distribution host: GitHub Releases.
- Runtime model: `server.type="uv"` so Claude Desktop can manage Python and dependencies from `pyproject.toml`.
- Public promise: install Critical Compass, then pressure-test text before use.
- Not in this slice: remote hosting, provider/API setup, or third-party MCP dependencies.

## Build

From the repo root:

```bash
python3 scripts/build_mcpb_bundle.py
```

This stages the bundle at:

```text
dist/mcpb/critical-compass/
```

To pack a `.mcpb` file with the official CLI:

```bash
python3 scripts/build_mcpb_bundle.py --pack
```

The packed artifact is written as:

```text
dist/mcpb/critical-compass-0.1.0.mcpb
```

The build script never copies the writable state database. It includes the canonical read-only knowledge database and redirects user state, report artifacts, and fact-check cache data through `mcpb_launcher.py`.

## Release Checklist

1. Run the full smoke tests from the repo root:

   ```bash
   python3 -m pytest -q
   python3 scripts/validate_factcheck_lookup.py
   python3 scripts/validate_research_audit_coverage.py
   python3 scripts/validate_writable_state.py
   ```

2. Stage and pack the MCPB:

   ```bash
   python3 scripts/build_mcpb_bundle.py --pack
   ```

3. Validate the manifest if the CLI is available:

   ```bash
   npx -y @anthropic-ai/mcpb validate dist/mcpb/critical-compass
   ```

4. Attach `dist/mcpb/critical-compass-0.1.0.mcpb` to a GitHub Release.

5. Give users the release asset plus `INSTALLER_DIAGNOSTIC_PROMPT.md` for AI-assisted install help.
6. Before publishing, verify the public install guide screenshots still match the current Claude UI and that the checksum table matches `downloads/checksums.txt`.

## Known Failure Points

- Claude Desktop must support MCPB/Desktop Extensions. If the Extensions UI is absent, users may need to update Claude Desktop.
- If the expected UI is absent, users should stop and use the diagnostic prompt. Do not tell non-technical users to hand-edit Claude config as the next step.
- Windows PowerShell 5.x `Set-Content -Encoding UTF8` can write a UTF-8 BOM. Any technical fallback that writes `claude_desktop_config.json` must write no-BOM UTF-8 and preserve existing `mcpServers` entries.
- First launch may take time while UV resolves Python dependencies.
- PDF report rendering depends on WeasyPrint and platform font/rendering support. Core audit and scaffold tools should still work if PDF rendering is unavailable, and the report tool exposes renderer dependency status.
- Complex reports should be dry-run with `validate_report_payload` before `generate_audit_report`.
- OCR stays local. `prepare_audit_source` prefers Apple Vision OCR on macOS when available, then falls back to local Tesseract OCR through `pytesseract`/`Pillow` when the `tesseract` binary is installed on Windows, Linux, or macOS. If no OCR provider is available, scanned PDFs return `needs_ocr_dependency` with install guidance rather than silently auditing sparse text.

## User Install Experience

1. Download `critical-compass-0.1.0.mcpb` from GitHub Releases.
2. Open Claude Desktop.
3. Go to Settings > Extensions.
4. Install the `.mcpb` file.
5. Start a new chat and ask: “Use Critical Compass to pressure-test this before I use it.”

Manual config install is a technical fallback only. If used, back up the current config, merge only `mcpServers.critical-compass`, restart Claude, run `get_started`, and confirm any pre-existing MCP servers still appear.
