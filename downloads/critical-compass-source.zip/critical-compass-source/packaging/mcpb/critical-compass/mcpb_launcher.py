#!/usr/bin/env python3
"""Launcher used by the Critical Compass MCPB package.

The bundle contains read-only code and canonical data. Writable state, report
artifacts, and caches are redirected to a per-user app-data directory.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _user_data_dir() -> Path:
    override = os.getenv("CRITICAL_COMPASS_USER_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = Path(os.getenv("APPDATA", str(Path.home() / "AppData" / "Roaming")))
        return base / "CriticalCompass"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "CriticalCompass"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "critical-compass"


def main() -> None:
    bundle_root = Path(__file__).resolve().parent
    user_data = _user_data_dir()
    reports_dir = user_data / "reports"
    cache_dir = user_data / "factcheck-cache"
    state_db = user_data / "critical-compass-state.sqlite"
    additions_pack = user_data / "user-additions.pack.json"
    canonical_db = bundle_root / "db" / "critical-compass.sqlite"

    for path in (user_data, reports_dir, cache_dir, additions_pack.parent):
        path.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    os.environ.setdefault("CRITICAL_COMPASS_REPORTS_DIR", str(reports_dir))
    os.environ.setdefault("CRITICAL_COMPASS_FACTCHECK_CACHE_DIR", str(cache_dir))
    os.environ.setdefault("CRITICAL_COMPASS_FACTCHECK_ENV_PATH", str(user_data / "factcheck.env"))

    if str(bundle_root) not in sys.path:
        sys.path.insert(0, str(bundle_root))

    sys.argv = [
        str(bundle_root / "server.py"),
        "--db-path",
        str(canonical_db),
        "--state-db-path",
        str(state_db),
        "--user-additions-pack-path",
        str(additions_pack),
    ]

    from server import main as server_main  # pylint: disable=import-outside-toplevel

    server_main()


if __name__ == "__main__":
    main()

