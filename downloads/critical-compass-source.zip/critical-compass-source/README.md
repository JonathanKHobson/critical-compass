# Critical Compass

Critical Compass is a local-first critical-thinking MCP that helps people pressure-test high-stakes text before they trust it, publish it, teach from it, fund it, cite it, or act on it.

Use Critical Compass when the question is: **Should I trust this text, revise it, verify it, or slow down before using it?**

It is built for nonprofits, advocacy teams, educators, public communicators, researchers, and AI-assisted reviewers who need a structured way to catch weak evidence, hidden assumptions, bias, fallacies, overclaiming, missing voices, and framing problems.

## What The MCP Does

Critical Compass gives a host AI a structured audit layer. The host AI owns the conversation and final judgment; Critical Compass owns the local reasoning frameworks, lens retrieval, audit contracts, scoring snapshots, report payload validation, and artifact generation.

It does not replace human judgment, certify truth, or guarantee that every cultural or epistemic risk has been found. It surfaces risks and next questions so people can decide what to verify, revise, or withhold.

## Tool Overview

Orientation and routing:

- `get_started`: first-session guidance and next-step selection.
- `critical_compass_overview`: capability lookup, workflow routing, output expectations, and report contracts.
- Host-facing scaffold anchors: use the Host-AI Quickstart / Current State Context, client-specific one-line hints, tool trigger matrix, surface sync checklist, output requirements, and tool inventory before changing or explaining the MCP surface.
- Mission anchor: Critical Compass helps people and mission-driven organizations pressure-test text before use so weak evidence and overly narrow Western framing are easier to catch.

Core audit and reasoning:

- `quick_scan`: fast Critical Integrity Snapshot, top risks, key tension, and next action.
- `audit_text`: full structured audit with evidence limits, assumptions, bias rows, reasoning artifacts, and report-ready fields.
- `advanced_audit`: multi-perspective audit scaffolding when the host/user needs a deeper panel-style review.
- Related public tools include `list_agent_personas` for advanced-role setup and `compare_audit_results` for saved-result review.
- Supported text-type lanes include `social_media`, `academic_abstract`, `product_copy`, legal/policy/research variants, and `ai_generated` text.

Verification and report support:

- `factcheck_lookup`: scaffold-first verification planning for factual claims.
- `validate_report_payload`: dry-run report readiness validation.
- `generate_audit_report`: Markdown/PDF-style report artifact generation when the payload is ready.

First-share default: when a user needs a quick stakeholder-facing artifact, prefer a compact `report_depth="readiness_card"` report before a full PDF. Keep debug metadata, internal notes, and report-preflight diagnostics out of reader-facing output unless the user explicitly asks for troubleshooting detail.

Human-loop contract: when `PAUSE_REQUIRED=true`, Claude hosts should use `Ask_User_Input_V0` / the `ask_user_input widget` with `single-select`, `multi-select`, or `rank-priority` questions. The contract fields `plain_text_questions_valid`, `widget_compliance_check`, `tool_compliance_signal`, and `repair_instruction` are host-facing guardrails, not reader-facing report copy.

Knowledge and maintenance surfaces:

- Lens, bias, fallacy, framework, and corpus lookup tools provide local retrieval support for host reasoning.
- Calibration, eval, and renderer scripts support release validation and regression checks.

## What To Download

- Claude Desktop Extension / MCPB: easiest local MCP install for Claude Desktop.
- Claude Code or Cowork Plugin: bundled MCP plus supporting agent/skill assets.
- Skill or Skill ZIP: lightweight prompt-only help when the MCP is unavailable.
- Source ZIP: inspect, audit, or rebuild from source.

If you are new to MCPs, start with the MCPB when using Claude Desktop and the plugin zip when using Claude Code/Cowork-style workflows.

If the expected Claude install UI is missing, stop and use the diagnostic prompt on the public page. Manual config edits are a technical fallback only: back up the config, merge only `critical-compass`, write UTF-8 without a BOM, and verify existing MCP servers remain present.

## Dependencies And Optional Capabilities

- Python runtime and MCP host support are required for local MCP use.
- OCR is optional but important when auditing image-based PDFs or scanned documents. `prepare_audit_source` uses embedded PDF text first, Apple Vision OCR on macOS when available, then local Tesseract OCR through `pytesseract`/`Pillow` when the `tesseract` binary is installed on Windows, Linux, or macOS. If no local OCR provider is available, scanned PDFs return dependency guidance instead of being audited as near-empty text.
- Web search is not required by default. Fact-checking begins as a guided research scaffold unless the host/user explicitly performs retrieval.

## Files And Folders

- `server.py` and MCP modules: tool implementation and contracts.
- `support/`: schemas, registry records, reasoning lenses, and local knowledge support.
- `normalized/` and `indexes/`: generated corpus records and retrieval indexes.
- `audit_report/`: report renderer assets and templates.
- `packaging/`: MCPB/plugin/shareable packaging inputs.
- `scripts/`: corpus builds, validators, release checks, and smoke tests.
- `docs/`: planning, specs, public product notes, and implementation tickets.
- `docs/public/why-critical-compass.md`: public explanation of what the tool does and does not do.
- `docs/planning/mission-audience-purpose-charter.md`: mission and audience guardrail for future changes.
- `scripts/validate_mcp_surface_sync.py`: release-surface parity check for README, scaffolds, public pages, and tests.
- `LOCAL_DEVELOPMENT.md`: local maintainer notes that may include machine-specific paths and should not be treated as public install instructions.

## Privacy And Safety Boundary

Critical Compass is local-first. It should not send user text to external services by default. Any host-side browsing, cloud OCR, or external verification is separate from the MCP and should be explicitly chosen by the user or host environment.

Public packages should not include local state, private reports, caches, machine paths, or personal files.

## Compass Suite

Critical Compass is one member of the Compass Suite. Other Compasses focus on prompt work, UX heuristic review, research grounding, TTRPG assistance, and job-application packet preparation.

Compass Suite home: https://jonathankhobson.github.io/compass-suite/

## Versioning

The public package base version is `0.1.0`. Beta tags and release pages identify the public release iteration. Package builders should keep release assets, checksums, Pages files, and source zips aligned before publishing.

## About The Author

Jonathan Kyle Hobson is a UX researcher, product strategist, and AI tool builder with 10+ years of experience across design, storytelling, and emerging technology. He holds a master's degree in User Experience from Arizona State University.

LinkedIn: https://www.linkedin.com/in/jonathankylehobson/

Kyle created Critical Compass to give nonprofits, advocacy teams, educators, and public communicators a practical way to pressure-test high-stakes writing before it shapes decisions.

## License And Attribution

Created by Jonathan Kyle Hobson.

- Code license: AGPL-3.0-only. See `LICENSE`.
- Documentation, prompts, skills, rubrics, checklists, examples, and public methodology text: CC BY-SA 4.0. See `LICENSE-DOCS-CC-BY-SA-4.0.md`.
- Compass names, logos, author photo, and personal brand: reserved for attribution/reference use. See `BRAND-AND-ATTRIBUTION.md`.
- Redistribution notices: see `NOTICE` and `THIRD_PARTY_NOTICES.md`.

Modified versions are not official releases unless explicitly published by Jonathan Kyle Hobson.
