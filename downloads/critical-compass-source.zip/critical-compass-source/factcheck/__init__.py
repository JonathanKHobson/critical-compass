"""Scaffold-first fact-check orchestration lane for Critical Compass."""

from .tool import factcheck_lookup

__all__ = ["factcheck_lookup"]
