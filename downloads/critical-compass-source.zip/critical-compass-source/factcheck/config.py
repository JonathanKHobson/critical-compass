from __future__ import annotations

import os
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LOCAL_ENV = PROJECT_ROOT / "config" / "factcheck.env"
DEFAULT_USER_ENV = Path.home() / ".critical-compass" / "factcheck.env"


def env_file_candidates() -> list[Path]:
    paths: list[Path] = []
    override = os.getenv("CRITICAL_COMPASS_FACTCHECK_ENV_PATH")
    if override:
        paths.append(Path(override).expanduser().resolve())
    paths.extend([DEFAULT_LOCAL_ENV, DEFAULT_USER_ENV])
    seen: set[str] = set()
    unique: list[Path] = []
    for path in paths:
        key = str(path)
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique


def parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            values[key] = value
    return values


def config_value(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value:
        return value
    for path in env_file_candidates():
        values = parse_env_file(path)
        if values.get(name):
            return values[name]
    return default


def config_status() -> dict[str, Any]:
    key_source = ""
    if os.getenv("GOOGLE_FACT_CHECK_API_KEY"):
        key_source = "environment"
    else:
        for path in env_file_candidates():
            values = parse_env_file(path)
            if values.get("GOOGLE_FACT_CHECK_API_KEY"):
                key_source = str(path)
                break
    return {
        "google_api_key_available": bool(config_value("GOOGLE_FACT_CHECK_API_KEY")),
        "google_api_key_source": key_source,
        "brave_api_key_available": bool(config_value("BRAVE_SEARCH_API_KEY")),
        "env_file_candidates": [str(path) for path in env_file_candidates()],
        "effective_provider": config_value("CRITICAL_COMPASS_FACTCHECK_PROVIDER", "guided_research"),
        "cache_enabled": config_value("CRITICAL_COMPASS_FACTCHECK_CACHE_ENABLED", "true"),
        "cache_dir": config_value("CRITICAL_COMPASS_FACTCHECK_CACHE_DIR", str(PROJECT_ROOT / "reports" / "factcheck-cache")),
        "default_max_age_days": config_value("CRITICAL_COMPASS_FACTCHECK_DEFAULT_MAX_AGE_DAYS", "3650"),
        "claimreview_index_path": config_value(
            "CRITICAL_COMPASS_CLAIMREVIEW_INDEX_PATH",
            str(PROJECT_ROOT / "support" / "registry" / "local_claimreview_index.json"),
        ),
    }
