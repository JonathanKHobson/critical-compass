from __future__ import annotations

from typing import Any

from .allowlist import resolve_publisher_sites
from .cache import cache_enabled, cache_key, read_cache, write_cache
from .config import config_status, config_value
from .local_index import LocalClaimReviewIndexProvider
from .privacy import sensitivity_reasons
from .providers import (
    BraveSearchProvider,
    FactCheckProvider,
    GoogleFactCheckToolsProvider,
    KeylessPublisherSearchProvider,
    PublisherClaimReviewHarvesterProvider,
    ProviderError,
    ProviderOptions,
    normalize_google_response,
    normalized_text,
)
from .scaffold import (
    NOT_FALSE_NOTICE,
    build_guided_research_response,
    caution,
    caution_text,
)


DEFAULT_PROVIDER = "guided_research"
AUTO_PROVIDER = "auto"
LOCAL_PROVIDER = "local_claimreview"
HARVEST_PROVIDER = "publisher_harvest"
GOOGLE_PROVIDER = "google_fact_check_tools"
BRAVE_PROVIDER = "brave_search"
KEYLESS_PROVIDER = "publisher_site_search"
VALID_PRIORITIES = {"high", "medium", "low"}
RETRIEVED_NOTICE = "Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts."


def _claim_id(item: dict[str, Any], index: int) -> str:
    return str(item.get("claim_id") or item.get("id") or item.get("claimId") or f"claim-{index + 1}")


def _claim_text(item: dict[str, Any]) -> str:
    return " ".join(str(item.get("text") or item.get("claim") or item.get("statement") or "").split()).strip()


def _is_factual(item: dict[str, Any]) -> bool:
    claim_type = str(item.get("claim_type") or item.get("type") or "").strip().lower()
    return bool(item.get("is_factual")) or claim_type == "factual"


def _priority(item: dict[str, Any]) -> str:
    value = str(item.get("verification_priority") or item.get("priority") or "").strip().lower()
    return value if value in {*VALID_PRIORITIES, "not_ranked"} else value


def _empty_result(claim_id: str, status: str, summary: str, cautions: list[Any] | None = None, notes: list[str] | None = None) -> dict[str, Any]:
    return {
        "claim_id": claim_id,
        "status": status,
        "summary": summary,
        "matches": [],
        "cautions": cautions or [],
        "provider_notes": notes or [],
    }


def _ratings_conflict(matches: list[dict[str, Any]]) -> bool:
    ratings = {
        normalized_text(match.get("review", {}).get("textual_rating"))
        for match in matches
        if normalized_text(match.get("review", {}).get("textual_rating"))
    }
    publishers = {
        normalized_text(match.get("review", {}).get("publisher_site"))
        for match in matches
        if normalized_text(match.get("review", {}).get("publisher_site"))
    }
    return len(matches) > 1 and len(publishers) > 1 and len(ratings) > 1


def _result_from_matches(claim_id: str, matches: list[dict[str, Any]], provider_notes: list[str]) -> dict[str, Any]:
    cautions: list[dict[str, str]] = [
        caution("checkworthy_not_false", "info", RETRIEVED_NOTICE, claim_id, "Treat retrieved reviews as evidence artifacts, not a Critical Compass truth verdict.")
    ]
    for match in matches:
        match_caution = match.pop("caution", "")
        if match_caution:
            cautions.append(
                caution("related_claim_match", "caution", str(match_caution), claim_id, "Do not describe related-but-not-identical matches as confirmations.")
            )
    if not matches:
        cautions.append(
            caution(
                "no_match_is_not_disproof",
                "info",
                "No trusted match is not evidence that the claim is true or false.",
                claim_id,
                "Report no-match states as coverage limits.",
            )
        )
        return _empty_result(
            claim_id,
            "no_trusted_match",
            "No trusted external fact check was found for this factual claim.",
            cautions=cautions,
            notes=provider_notes,
        )
    if _ratings_conflict(matches):
        status = "conflicting_reviews"
        summary = "Trusted publishers returned materially different textual ratings. Preserve the disagreement."
        cautions.append(
            caution(
                "conflicting_reviews_preserved",
                "caution",
                "Conflicting publisher assessments are not collapsed into one truth score.",
                claim_id,
                "Quote ratings verbatim and preserve disagreement.",
            )
        )
    elif len(matches) > 1:
        status = "multiple_matches"
        summary = "Multiple trusted fact-check reviews were retrieved for this claim or closely related claims."
    else:
        status = "match_found"
        summary = "One trusted fact-check review was retrieved for this claim or a closely related claim."
    return {
        "claim_id": claim_id,
        "status": status,
        "summary": summary,
        "matches": matches,
        "cautions": cautions,
        "provider_notes": provider_notes,
    }


def _provider(provider: str | None, provider_client: FactCheckProvider | None = None) -> FactCheckProvider:
    if provider_client is not None:
        return provider_client
    requested = (provider or DEFAULT_PROVIDER).strip().lower()
    if requested in {DEFAULT_PROVIDER, AUTO_PROVIDER}:
        raise ProviderError("guided_research_only", f"Provider {requested} does not perform live retrieval in this MVP.")
    if requested == LOCAL_PROVIDER:
        return LocalClaimReviewIndexProvider()
    if requested == HARVEST_PROVIDER:
        return PublisherClaimReviewHarvesterProvider()
    if requested == GOOGLE_PROVIDER:
        return GoogleFactCheckToolsProvider()
    if requested == BRAVE_PROVIDER:
        return BraveSearchProvider()
    if requested in {KEYLESS_PROVIDER, "keyless_publisher_search", "approved_publisher_search"}:
        return KeylessPublisherSearchProvider()
    raise ProviderError("unsupported_provider", f"Unsupported fact-check provider: {provider}.")


def _default_max_age_days() -> int:
    try:
        return max(1, int(config_value("CRITICAL_COMPASS_FACTCHECK_DEFAULT_MAX_AGE_DAYS", "3650")))
    except ValueError:
        return 3650


def _lookup_claim(
    *,
    claim_id: str,
    claim_text: str,
    provider_name: str,
    provider_client: FactCheckProvider,
    language_code: str,
    approved_sites: list[str],
    max_age_days: int,
    cache_allowed: bool,
) -> tuple[dict[str, Any], dict[str, int]]:
    cache_stats = {"hits": 0, "writes": 0}
    key = cache_key(
        {
            "claim": normalized_text(claim_text),
            "language_code": language_code,
            "provider": provider_name,
            "publisher_sites": sorted(approved_sites),
            "max_age_days": max_age_days,
        }
    )
    if cache_allowed:
        cached = read_cache(key)
        if cached:
            cache_stats["hits"] += 1
            return cached, cache_stats
    payloads: list[dict[str, Any]] = []
    notes: list[str] = []
    try:
        for site in approved_sites:
            options = ProviderOptions(language_code=language_code, publisher_site=site, max_age_days=max_age_days)
            payloads.append(provider_client.search(claim_text, options))
    except ProviderError as exc:
        return _empty_result(claim_id, "provider_error", exc.message, notes=[exc.code]), cache_stats
    matches, normalize_notes = normalize_google_response(
        payloads,
        query_claim=claim_text,
        approved_sites=approved_sites,
        max_age_days=max_age_days,
    )
    notes.extend(normalize_notes)
    result = _result_from_matches(claim_id, matches, notes)
    if cache_allowed:
        write_cache(key, result)
        cache_stats["writes"] += 1
    return result, cache_stats


def factcheck_lookup(
    claims: list[dict[str, Any]],
    provider: str | None = DEFAULT_PROVIDER,
    language_code: str | None = "en",
    publisher_sites: list[str] | None = None,
    max_age_days: int | None = None,
    allow_external_calls: bool = False,
    allow_sensitive_claims: bool = False,
    *,
    provider_client: FactCheckProvider | None = None,
) -> dict[str, Any]:
    requested_provider = (provider or DEFAULT_PROVIDER).strip().lower()
    language = (language_code or "en").strip() or "en"
    freshness_days = max_age_days if isinstance(max_age_days, int) and max_age_days > 0 else _default_max_age_days()
    safe_config = config_status()
    cache_stats = {"enabled": cache_enabled(), "hits": 0, "writes": 0, "bypassed_sensitive": 0}
    if not isinstance(claims, list):
        return {
            "status": "blocked",
            "mode": requested_provider,
            "provider": requested_provider,
            "lookup_performed": False,
            "results": [],
            "provider_notes": ["claims must be a list of claim objects."],
            "cache": cache_stats,
        }

    if requested_provider in {"", DEFAULT_PROVIDER, AUTO_PROVIDER}:
        auto_deprecated = requested_provider == AUTO_PROVIDER
        notes = [
            "No retrieval was performed. Scaffold-first mode is the shipped default.",
            "Use the guided response to see what is ready to verify, which sources to check, and how to preserve evidence limits.",
            "Opt-in retrieval paths: local_claimreview for a configured offline index; publisher_harvest with allow_external_calls=true; or an explicit provider such as publisher_site_search, google_fact_check_tools, or brave_search with allow_external_calls=true.",
        ]
        if auto_deprecated:
            notes.append("DEPRECATED: provider='auto' no longer selects Google, Brave, or publisher search. It returns guided_research scaffolding.")
        return build_guided_research_response(
            claims,
            language_code=language,
            provider_requested=requested_provider or DEFAULT_PROVIDER,
            auto_deprecated=auto_deprecated,
            provider_notes=notes,
            cache=cache_stats,
        )

    publisher_scope = resolve_publisher_sites(publisher_sites)
    approved_sites = publisher_scope["approved_sites"]
    is_local_lookup = requested_provider == LOCAL_PROVIDER
    results: list[dict[str, Any]] = []
    provider_notes: list[str] = [RETRIEVED_NOTICE]
    if is_local_lookup:
        provider_notes.extend(
            [
                "Local ClaimReview retrieval is opt-in and offline.",
                "No claim text is sent externally in local_claimreview mode.",
            ]
        )
    else:
        provider_notes.extend(
            [
                "factcheck_lookup provider-backed retrieval is optional and experimental.",
                "Only normalized factual claim text, language code, publisher filter, and freshness window are sent externally.",
            ]
        )
    if publisher_scope["rejected_sites"]:
        provider_notes.append(f"Unapproved publisher sites ignored: {', '.join(publisher_scope['rejected_sites'])}.")
    if not approved_sites:
        return {
            "status": "blocked",
            "mode": "local_retrieval" if is_local_lookup else "provider_retrieval",
            "provider": requested_provider,
            "lookup_performed": False,
            "results": [
                _empty_result(_claim_id(item, index), "provider_error", "No approved trusted publisher sites were available.")
                for index, item in enumerate(claims)
                if isinstance(item, dict)
            ],
            "provider_notes": provider_notes,
            "trusted_publishers": publisher_scope,
            "cache": cache_stats,
        }
    if not allow_external_calls and not is_local_lookup:
        return {
            "status": "blocked",
            "mode": "provider_retrieval",
            "provider": requested_provider,
            "lookup_performed": False,
            "results": [
                _empty_result(
                    _claim_id(item, index),
                    "provider_error",
                    "External fact-check lookup was not run because allow_external_calls=false.",
                    cautions=[
                        caution(
                            "retrieval_not_performed",
                            "caution",
                            "External fact-check lookup was not run because allow_external_calls=false.",
                            _claim_id(item, index),
                            "Ask the user before sending factual claims to an external provider.",
                        )
                    ],
                )
                for index, item in enumerate(claims)
                if isinstance(item, dict)
            ],
            "provider_notes": provider_notes,
            "trusted_publishers": publisher_scope,
            "cache": cache_stats,
        }
    try:
        client = _provider(requested_provider, provider_client)
        provider_name = client.provider_name
    except ProviderError as exc:
        return {
            "status": "blocked",
            "mode": "local_retrieval" if is_local_lookup else "provider_retrieval",
            "provider": requested_provider,
            "lookup_performed": False,
            "results": [
                _empty_result(_claim_id(item, index), "provider_error", exc.message, notes=[exc.code])
                for index, item in enumerate(claims)
                if isinstance(item, dict)
            ],
            "provider_notes": provider_notes,
            "trusted_publishers": publisher_scope,
            "cache": cache_stats,
            "provider_config": safe_config,
        }
    for index, item in enumerate(claims):
        if not isinstance(item, dict):
            continue
        cid = _claim_id(item, index)
        text = _claim_text(item)
        if not text:
            results.append(_empty_result(cid, "provider_error", "Claim text is missing."))
            continue
        if not _is_factual(item) or _priority(item) == "not_ranked":
            results.append(
                _empty_result(
                    cid,
                    "no_trusted_match",
                    "No external lookup was run because the claim was not a ranked factual claim.",
                    cautions=[
                        caution(
                            "checkworthy_not_false",
                            "info",
                            "Only ranked factual claims from checkworthy_claims should be sent to provider-backed retrieval.",
                            cid,
                            "Use the scaffold for interpretive, policy, worldview, or non-ranked claims.",
                        )
                    ],
                )
            )
            continue
        reasons = sensitivity_reasons(text)
        claim_language = str(item.get("language_code") or language).strip() or language
        cache_allowed = True
        if reasons and not allow_sensitive_claims:
            results.append(
                _empty_result(
                    cid,
                    "sensitive_blocked",
                    "Privacy guard blocked this claim before any external lookup.",
                    cautions=[
                        caution(
                            "private_or_sensitive_claim",
                            "high",
                            "; ".join(reasons),
                            cid,
                            "Do not send identifying details externally without explicit user authorization.",
                        )
                    ],
                )
            )
            continue
        if reasons and allow_sensitive_claims:
            cache_allowed = False
            cache_stats["bypassed_sensitive"] += 1
        result, stats = _lookup_claim(
            claim_id=cid,
            claim_text=text,
            provider_name=provider_name,
            provider_client=client,
            language_code=claim_language,
            approved_sites=approved_sites,
            max_age_days=freshness_days,
            cache_allowed=cache_allowed,
        )
        if reasons and allow_sensitive_claims:
            result.setdefault("cautions", []).append(
                caution(
                    "private_or_sensitive_claim",
                    "high",
                    "Sensitive override was used; this result was not cached.",
                    cid,
                    "Handle the result as sensitive and avoid broad redistribution.",
                )
            )
            result.setdefault("provider_notes", []).extend(reasons)
        cache_stats["hits"] += stats["hits"]
        cache_stats["writes"] += stats["writes"]
        results.append(result)
    return {
        "status": "completed",
        "mode": "local_retrieval" if provider_name == LOCAL_PROVIDER else "provider_retrieval",
        "provider": provider_name,
        "lookup_performed": True,
        "language_code": language,
        "max_age_days": freshness_days,
        "results": results,
        "trusted_publishers": publisher_scope,
        "provider_notes": provider_notes,
        "cache": cache_stats,
        "privacy": {
            "minimum_data_sent": []
            if provider_name == LOCAL_PROVIDER
            else ["normalized claim text", "language code", "publisher site filter", "freshness window"],
            "full_documents_sent": False,
            "audit_context_sent": False,
            "sensitive_claims_allowed": bool(allow_sensitive_claims),
        },
        "provider_config": safe_config,
    }
