from __future__ import annotations

import re
from typing import Any

from .privacy import sensitivity_reasons
from .providers import normalized_text


NOT_FALSE_NOTICE = "Check-worthy means worth verifying, not false."


def caution(
    code: str,
    severity: str,
    message: str,
    applies_to_claim_id: str = "",
    recommended_action: str = "",
) -> dict[str, str]:
    return {
        "code": code,
        "severity": severity,
        "message": message,
        "applies_to_claim_id": applies_to_claim_id,
        "recommended_action": recommended_action,
    }


def caution_text(item: Any) -> str:
    if isinstance(item, dict):
        return str(item.get("message") or item.get("code") or "").strip()
    return str(item or "").strip()


def claim_id(item: dict[str, Any], index: int) -> str:
    return str(item.get("claim_id") or item.get("id") or item.get("claimId") or f"claim-{index + 1}")


def claim_text(item: dict[str, Any]) -> str:
    return " ".join(str(item.get("text") or item.get("claim") or item.get("statement") or "").split()).strip()


def is_factual(item: dict[str, Any]) -> bool:
    claim_type = str(item.get("claim_type") or item.get("type") or "").strip().lower()
    return bool(item.get("is_factual")) or claim_type in {"factual", "empirical", "statistical", "historical"}


def priority(item: dict[str, Any]) -> str:
    value = str(item.get("verification_priority") or item.get("priority") or "").strip().lower()
    return value if value in {"high", "medium", "low", "not_ranked"} else value


def claim_kind(item: dict[str, Any]) -> str:
    raw = str(item.get("claim_kind") or item.get("claim_type") or item.get("type") or "").strip().lower()
    if raw in {"empirical", "statistical", "historical", "causal", "interpretive", "policy", "worldview"}:
        return raw
    text = claim_text(item).lower()
    if re.search(r"\b\d+(?:\.\d+)?\s*(%|percent|million|billion|trillion|people|dollars|usd)\b", text):
        return "statistical"
    if re.search(r"\b(19|20)\d{2}\b|\bborn\b|\bdied\b|\bfounded\b|\bpassed\b|\bsigned\b", text):
        return "historical"
    if any(token in text for token in ["causes", "caused", "leads to", "because of", "results in"]):
        return "causal"
    if raw in {"normative", "value", "opinion"}:
        return "interpretive"
    return "empirical" if is_factual(item) else "interpretive"


def domain_for(text: str) -> str:
    lower = text.lower()
    if any(token in lower for token in ["prairie dog", "animal communication", "whale song", "elephant", "dolphin", "birdsong"]):
        return "animal_communication"
    if any(token in lower for token in ["traditional medicine", "indigenous medicine", "ayurveda", "herbal", "plant medicine"]):
        return "traditional_medicine"
    if any(token in lower for token in ["indigenous ecology", "traditional ecological", "land management", "biodiversity", "controlled burn", "fire stewardship"]):
        return "ecological_knowledge"
    if any(token in lower for token in ["mental health", "trauma", "kinship", "collective healing"]):
        return "mental_health_and_social_knowledge"
    if any(token in lower for token in ["vaccine", "disease", "medicine", "public health", "clinical", "clinic", "patient", "patients"]):
        return "public_health"
    if any(token in lower for token in ["gdp", "inflation", "unemployment", "population", "budget", "tax", "fare", "fares"]):
        return "public_statistics"
    if any(token in lower for token in ["climate", "carbon", "emissions", "warming"]):
        return "climate_and_environment"
    if any(token in lower for token in ["election", "congress", "parliament", "policy", "law", "regulation"]):
        return "politics_and_policy"
    return "general_empirical"


def framing_for_claim(item: dict[str, Any], index: int) -> dict[str, Any]:
    cid = claim_id(item, index)
    text = claim_text(item)
    domain = domain_for(text)
    kind = claim_kind(item)
    high_domains = {"animal_communication", "traditional_medicine", "ecological_knowledge", "mental_health_and_social_knowledge"}
    medium_domains = {"public_health", "climate_and_environment", "politics_and_policy"}
    if domain in high_domains:
        sensitivity = "high"
        western_bias = "documented"
        consensus_age = "emerging_or_contested"
    elif domain in medium_domains or kind in {"policy", "worldview", "interpretive", "causal"}:
        sensitivity = "medium"
        western_bias = "possible"
        consensus_age = "unknown"
    else:
        sensitivity = "low"
        western_bias = "none_known"
        consensus_age = "settled_longstanding" if kind == "historical" else "unknown"
    lower = text.lower()
    if any(token in lower for token in ["new study", "recent research", "emerging", "contested", "debated"]):
        consensus_age = "emerging_or_contested"
    communities = {
        "animal_communication": ["ethologists", "long-term field observers", "Indigenous/local ecological knowledge holders"],
        "traditional_medicine": ["clinical researchers", "traditional medicine practitioners", "affected communities", "local knowledge holders"],
        "ecological_knowledge": ["ecologists", "Indigenous land stewards", "local environmental monitors", "affected communities"],
        "mental_health_and_social_knowledge": ["clinicians", "community care practitioners", "affected communities", "cultural knowledge holders"],
        "public_health": ["public health agencies", "clinical researchers", "affected patients or communities"],
        "public_statistics": ["official statistical agencies", "primary datasets", "independent data journalists"],
        "climate_and_environment": ["climate scientists", "regional monitoring bodies", "affected communities"],
        "politics_and_policy": ["official records", "nonpartisan fact-checkers", "affected communities"],
        "general_empirical": ["primary sources", "domain experts", "reputable secondary sources"],
    }.get(domain, ["primary sources", "domain experts"])
    source_emphasis = {
        "high": ["domain experts", "local or affected-community sources", "non-English/regional sources where relevant", "primary evidence"],
        "medium": ["primary evidence", "independent expert sources", "regional or affected-community context"],
        "low": ["primary/official sources", "reputable secondary sources", "existing fact checks"],
    }[sensitivity]
    return {
        "claim_id": cid,
        "domain": domain,
        "claim_kind": kind,
        "domain_sensitivity": sensitivity,
        "known_western_bias_history": western_bias,
        "consensus_age": consensus_age,
        "knowledge_communities_with_standing": communities,
        "recommended_source_emphasis": source_emphasis,
        "framing_notes": [
            "Use epistemic framing before choosing sources and queries.",
            "Treat missing perspectives as a coverage limit, not as proof that those perspectives do not exist.",
        ],
    }


def source_classes_for(framing: dict[str, Any]) -> list[dict[str, str]]:
    classes = [
        {"source_class": "existing_fact_check", "use_when": "Look for prior ClaimReview or publisher fact-checks before reinventing the search."},
        {"source_class": "primary_or_official_source", "use_when": "Use when the claim depends on dates, numbers, records, laws, or direct statements."},
        {"source_class": "reputable_secondary_source", "use_when": "Use for synthesis, context, and independent reporting."},
    ]
    if framing.get("domain_sensitivity") in {"medium", "high"}:
        classes.extend(
            [
                {"source_class": "regional_or_local_source", "use_when": "Use when geography, language, or local context may change framing."},
                {"source_class": "affected_community_source", "use_when": "Use when lived stakes, harm, or standing are central to the claim."},
            ]
        )
    if framing.get("known_western_bias_history") == "documented":
        classes.append(
            {
                "source_class": "knowledge_tradition_with_standing",
                "use_when": "Use when Indigenous, local, or non-Western knowledge systems have documented standing in the domain.",
            }
        )
    return classes


def suggested_queries_for(item: dict[str, Any], index: int, framing: dict[str, Any]) -> dict[str, Any]:
    cid = claim_id(item, index)
    text = claim_text(item)
    sensitive = bool(sensitivity_reasons(text))
    if sensitive:
        base = "[privacy-sensitive claim redacted]"
        queries = [
            {"purpose": "privacy_safe_method", "query": "how to verify a privacy-sensitive factual claim without exposing private details"},
        ]
    else:
        base = text
        queries = [
            {"purpose": "existing_fact_checks", "query": f'"{base}" fact check'},
            {"purpose": "primary_sources", "query": f'"{base}" official source OR primary data'},
            {"purpose": "independent_context", "query": f'"{base}" evidence context'},
        ]
        if framing.get("domain_sensitivity") in {"medium", "high"}:
            queries.append({"purpose": "regional_or_affected_perspectives", "query": f'"{base}" local community perspective OR regional source'})
    return {"claim_id": cid, "queries": queries}


def build_guided_research_response(
    claims: list[dict[str, Any]],
    *,
    language_code: str,
    provider_requested: str,
    auto_deprecated: bool = False,
    status: str = "scaffold_ready",
    extra_cautions: list[dict[str, str]] | None = None,
    provider_notes: list[str] | None = None,
    cache: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_claims: list[dict[str, Any]] = []
    framing: list[dict[str, Any]] = []
    suggested_queries: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    cautions: list[dict[str, str]] = [
        caution("retrieval_not_performed", "info", "No retrieval was performed. This response is a guided research scaffold, not verification results.", recommended_action="Use local_claimreview, publisher_harvest, or an explicit provider with allow_external_calls=true only if the user authorizes verification."),
        caution("checkworthy_not_false", "info", NOT_FALSE_NOTICE, recommended_action="Describe claims as worth checking, not as false."),
        caution("no_match_is_not_disproof", "info", "A missing fact-check match is not evidence that a claim is true or false.", recommended_action="Report no-match states as coverage limits."),
    ]
    warnings: list[dict[str, str]] = []
    if auto_deprecated:
        item = caution(
            "provider_auto_deprecated",
            "high",
            "provider='auto' is deprecated and now returns guided_research scaffolding; it no longer selects live providers.",
            recommended_action="Use provider='guided_research' for scaffold mode, or explicitly name an experimental retrieval provider.",
        )
        cautions.append(item)
        warnings.append(item)
    for index, item in enumerate(claims):
        if not isinstance(item, dict):
            continue
        cid = claim_id(item, index)
        text = claim_text(item)
        redacted = bool(sensitivity_reasons(text))
        claim_framing = framing_for_claim(item, index)
        framing.append(claim_framing)
        normalized_claims.append(
            {
                "claim_id": cid,
                "text": "[privacy-sensitive claim redacted]" if redacted else text,
                "claim_kind": claim_framing["claim_kind"],
                "is_factual": is_factual(item),
                "verification_priority": priority(item) or "not_ranked",
                "language_code": str(item.get("language_code") or language_code or "en"),
            }
        )
        suggested_queries.append(suggested_queries_for(item, index, claim_framing))
        claim_cautions: list[dict[str, str]] = []
        if redacted:
            claim_cautions.append(
                caution(
                    "private_or_sensitive_claim",
                    "high",
                    "This claim appears private or sensitive; do not send identifying details to external tools.",
                    cid,
                    "Ask for explicit consent and use privacy-safe verification methods.",
                )
            )
        if claim_framing["domain_sensitivity"] == "high":
            claim_cautions.append(
                caution(
                    "domain_sensitivity_high",
                    "high",
                    "This domain has documented risk of narrow Western or institutional framing.",
                    cid,
                    "Include local, Indigenous, affected-community, or non-Western sources with standing where relevant.",
                )
            )
        if claim_framing["consensus_age"] in {"recent_less_than_5_years", "emerging_or_contested"}:
            claim_cautions.append(
                caution(
                    "recent_or_contested_consensus",
                    "caution",
                    "The consensus may be recent, emerging, or contested.",
                    cid,
                    "Check publication dates and whether expert disagreement is about truth, framing, or scope.",
                )
            )
        if claim_framing["domain_sensitivity"] in {"medium", "high"}:
            claim_cautions.extend(
                [
                    caution(
                        "non_western_coverage_not_found",
                        "caution",
                        "Non-Western or non-English coverage has not been checked yet.",
                        cid,
                        "Look for regional, local-language, or knowledge-tradition sources before synthesizing.",
                    ),
                    caution(
                        "affected_community_not_represented",
                        "caution",
                        "Affected-community representation has not been established.",
                        cid,
                        "Check whether directly affected communities are present in the evidence base.",
                    ),
                ]
            )
        if not is_factual(item) or priority(item) == "not_ranked":
            claim_cautions.append(
                caution(
                    "checkworthy_not_false",
                    "info",
                    "This claim is not a ranked factual claim for external verification.",
                    cid,
                    "Treat it as interpretive or framing material unless the audit author supplies a factual version.",
                )
            )
        cautions.extend(claim_cautions)
        results.append(
            {
                "claim_id": cid,
                "status": "scaffold_only",
                "summary": "No retrieval was performed. This claim is ready for guided verification planning, not yet verified.",
                "matches": [],
                "cautions": claim_cautions,
                "provider_notes": ["Use host browsing, local_claimreview, publisher_harvest, or an explicit provider with allow_external_calls=true to fill the evidence trail after user authorization."],
            }
        )
    if extra_cautions:
        cautions.extend(extra_cautions)
        warnings.extend(extra_cautions)
    return {
        "status": status,
        "mode": "guided_research",
        "provider": "guided_research",
        "provider_requested": provider_requested,
        "lookup_performed": False,
        "language_code": language_code,
        "user_facing_summary": {
            "headline": "No retrieval was performed.",
            "what_this_is": "A verification plan for factual claims that are worth checking, not proof that any claim is true or false.",
            "ready_to_verify_now": [
                {
                    "claim_id": item["claim_id"],
                    "claim": item["text"],
                    "verification_priority": item["verification_priority"],
                    "next_action": "Use the suggested queries, source classes, and evidence trail template to gather real evidence.",
                }
                for item in normalized_claims
            ],
            "opt_in_retrieval_paths": [
                "provider='local_claimreview' searches a configured offline ClaimReview index without external calls.",
                "provider='publisher_harvest' with allow_external_calls=true directly harvests approved publisher ClaimReview markup.",
                "provider='publisher_site_search', 'google_fact_check_tools', or 'brave_search' requires an explicit provider name plus allow_external_calls=true.",
            ],
        },
        "results": results,
        "normalized_claims": normalized_claims,
        "epistemic_framing": framing,
        "suggested_queries": suggested_queries,
        "recommended_source_classes": [
            {
                "claim_id": item["claim_id"],
                "source_classes": source_classes_for(item),
            }
            for item in framing
        ],
        "evidence_trail_template": [
            {
                "claim_id": item["claim_id"],
                "claim": item["text"],
                "evidence_rows": [],
                "required_fields": ["source_title", "source_url", "source_class", "publisher_or_author", "date", "what_it_supports", "limits"],
                "note": "Fill only after real retrieval or host browsing. Do not fabricate evidence rows.",
            }
            for item in normalized_claims
        ],
        "epistemic_plurality_review_template": [
            {
                "claim_id": item["claim_id"],
                "claim_type": item["claim_kind"],
                "regions_represented": [],
                "languages_represented": [],
                "knowledge_systems_present": [],
                "missing_perspectives": [],
                "dominant_bloc_risk": "unknown",
                "framing_gap": "unknown",
                "warnings": [],
                "notes": ["Complete after evidence is gathered; distinguish truth disputes from framing disputes."],
            }
            for item in framing
        ],
        "cautions": cautions,
        "warnings": warnings,
        "provider_notes": provider_notes
        or [
            "Scaffold-first mode is the shipped default.",
            "Local ClaimReview and direct publisher harvest are opt-in retrieval modes.",
            "External providers are optional and must be explicitly named.",
        ],
        "cache": cache or {"enabled": False, "hits": 0, "writes": 0, "bypassed_sensitive": 0},
        "privacy": {
            "minimum_data_sent": [],
            "full_documents_sent": False,
            "audit_context_sent": False,
            "sensitive_claims_allowed": False,
        },
    }
