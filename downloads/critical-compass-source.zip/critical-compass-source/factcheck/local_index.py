from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .allowlist import load_allowlist, normalize_domain
from .config import config_value
from .providers import ProviderOptions, match_confidence, normalized_text, token_overlap, within_max_age


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INDEX_PATH = PROJECT_ROOT / "support" / "registry" / "local_claimreview_index.json"


def configured_index_path() -> Path:
    override = config_value("CRITICAL_COMPASS_CLAIMREVIEW_INDEX_PATH")
    if override:
        return Path(override).expanduser().resolve()
    return DEFAULT_INDEX_PATH


def _publisher_metadata(site: str, allowlist: dict[str, Any] | None = None) -> dict[str, Any]:
    source = allowlist or load_allowlist()
    row = source.get("by_site", {}).get(normalize_domain(site), {})
    return {
        "source_name": row.get("name") or row.get("source_name") or normalize_domain(site),
        "publisher_site": normalize_domain(row.get("site") or site),
        "source_class": row.get("source_class") or "fact_check_structured",
        "regions": row.get("regions") or ([row.get("region")] if row.get("region") else []),
        "country": row.get("country"),
        "languages": row.get("languages") or [],
        "governance": row.get("governance") or row.get("ownership") or "",
        "coverage_notes": row.get("coverage_notes") or row.get("review_notes") or "",
    }


def _rating_text(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("alternateName", "name", "ratingValue"):
            if value.get(key) is not None:
                return str(value[key])
    return str(value or "").strip()


def _claimreview_record(review: dict[str, Any], *, fallback_url: str = "", allowlist: dict[str, Any] | None = None) -> dict[str, Any] | None:
    publisher = review.get("author") if isinstance(review.get("author"), dict) else {}
    item_reviewed = review.get("itemReviewed") if isinstance(review.get("itemReviewed"), dict) else {}
    publisher_site = normalize_domain(publisher.get("url") or publisher.get("site") or fallback_url)
    claim_text = str(review.get("claimReviewed") or item_reviewed.get("claimReviewed") or review.get("name") or "").strip()
    if not claim_text or not publisher_site:
        return None
    claimant = item_reviewed.get("author")
    if isinstance(claimant, dict):
        claimant = claimant.get("name")
    return {
        "claim_text": claim_text,
        "normalized_claim_text": normalized_text(claim_text),
        "claimant": claimant if isinstance(claimant, str) else None,
        "claim_date": item_reviewed.get("datePublished") or item_reviewed.get("dateCreated"),
        "review": {
            "publisher_name": publisher.get("name") or publisher_site,
            "publisher_site": publisher_site,
            "url": review.get("url") or fallback_url,
            "title": review.get("headline") or review.get("name"),
            "review_date": review.get("datePublished") or review.get("dateModified"),
            "textual_rating": _rating_text(review.get("reviewRating")),
            "language_code": review.get("inLanguage"),
        },
        "source_metadata": _publisher_metadata(publisher_site, allowlist),
    }


def _google_claim_records(claim: dict[str, Any], *, allowlist: dict[str, Any] | None = None) -> Iterable[dict[str, Any]]:
    text = str(claim.get("text") or claim.get("claim_text") or claim.get("claimReviewed") or "").strip()
    if not text:
        return
    reviews = claim.get("claimReview") or claim.get("claimReviews") or []
    if not isinstance(reviews, list):
        return
    for review in reviews:
        if not isinstance(review, dict):
            continue
        publisher = review.get("publisher") if isinstance(review.get("publisher"), dict) else {}
        site = normalize_domain(publisher.get("site") or publisher.get("url") or review.get("url"))
        if not site:
            continue
        yield {
            "claim_text": text,
            "normalized_claim_text": normalized_text(text),
            "claimant": claim.get("claimant"),
            "claim_date": claim.get("claimDate") or claim.get("claim_date"),
            "review": {
                "publisher_name": publisher.get("name") or site,
                "publisher_site": site,
                "url": review.get("url") or "",
                "title": review.get("title") or review.get("headline"),
                "review_date": review.get("reviewDate") or review.get("datePublished"),
                "textual_rating": review.get("textualRating") or _rating_text(review.get("reviewRating")),
                "language_code": review.get("languageCode") or review.get("inLanguage"),
            },
            "source_metadata": _publisher_metadata(site, allowlist),
        }


def _flat_record(row: dict[str, Any], *, allowlist: dict[str, Any] | None = None) -> dict[str, Any] | None:
    claim_text = str(row.get("claim_text") or row.get("claim") or row.get("text") or row.get("claimReviewed") or "").strip()
    site = normalize_domain(row.get("publisher_site") or row.get("site") or row.get("domain") or row.get("publisher_url") or row.get("url"))
    if not claim_text or not site:
        return None
    return {
        "claim_text": claim_text,
        "normalized_claim_text": normalized_text(claim_text),
        "claimant": row.get("claimant"),
        "claim_date": row.get("claim_date") or row.get("claimDate"),
        "review": {
            "publisher_name": row.get("publisher_name") or row.get("publisher") or site,
            "publisher_site": site,
            "url": row.get("url") or row.get("review_url") or "",
            "title": row.get("title") or row.get("review_title"),
            "review_date": row.get("review_date") or row.get("reviewDate") or row.get("datePublished"),
            "textual_rating": row.get("textual_rating") or row.get("textualRating") or row.get("rating"),
            "language_code": row.get("language_code") or row.get("languageCode") or row.get("lang"),
        },
        "source_metadata": _publisher_metadata(site, allowlist),
    }


def _walk_json(value: Any, *, allowlist: dict[str, Any]) -> Iterable[dict[str, Any]]:
    if isinstance(value, list):
        for item in value:
            yield from _walk_json(item, allowlist=allowlist)
        return
    if not isinstance(value, dict):
        return
    if isinstance(value.get("records"), list):
        for item in value["records"]:
            if isinstance(item, dict):
                record = _flat_record(item, allowlist=allowlist)
                if record:
                    yield record
        return
    if isinstance(value.get("claims"), list):
        for claim in value["claims"]:
            if isinstance(claim, dict):
                yield from _google_claim_records(claim, allowlist=allowlist)
        return
    type_value = value.get("@type")
    types = type_value if isinstance(type_value, list) else [type_value]
    if any(str(item).lower() == "claimreview" for item in types) or value.get("claimReviewed"):
        record = _claimreview_record(value, fallback_url=str(value.get("url") or ""), allowlist=allowlist)
        if record:
            yield record
    for key in ("@graph", "graph", "items"):
        if key in value:
            yield from _walk_json(value[key], allowlist=allowlist)


def _load_source_records(source_path: Path, *, allowlist: dict[str, Any]) -> list[dict[str, Any]]:
    suffix = source_path.suffix.lower()
    if suffix == ".csv":
        with source_path.open(newline="", encoding="utf-8") as handle:
            return [record for row in csv.DictReader(handle) if (record := _flat_record(row, allowlist=allowlist))]
    if suffix == ".jsonl":
        records: list[dict[str, Any]] = []
        for line in source_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            records.extend(_walk_json(json.loads(line), allowlist=allowlist))
        return records
    data = json.loads(source_path.read_text(encoding="utf-8"))
    return list(_walk_json(data, allowlist=allowlist))


def build_claimreview_index(source_path: str | Path, output_path: str | Path | None = None) -> dict[str, Any]:
    source = Path(source_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve() if output_path else configured_index_path()
    allowlist = load_allowlist()
    approved = set(allowlist.get("active_sites", []))
    records = [
        record
        for record in _load_source_records(source, allowlist=allowlist)
        if record.get("review", {}).get("publisher_site") in approved
    ]
    seen: set[tuple[str, str, str]] = set()
    deduped: list[dict[str, Any]] = []
    for record in records:
        review = record.get("review", {})
        key = (
            str(record.get("normalized_claim_text") or ""),
            str(review.get("publisher_site") or ""),
            str(review.get("url") or ""),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(record)
    index = {
        "schema_version": "claimreview_index.v1",
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "source_path": str(source),
        "record_count": len(deduped),
        "records": deduped,
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(index, indent=2, sort_keys=True), encoding="utf-8")
    return index | {"index_path": str(destination)}


def load_claimreview_index(path: str | Path | None = None) -> dict[str, Any]:
    source = Path(path).expanduser().resolve() if path else configured_index_path()
    if not source.exists():
        return {
            "schema_version": "claimreview_index.v1",
            "path": str(source),
            "record_count": 0,
            "records": [],
            "provider_notes": [f"Local ClaimReview index not found at {source}."],
        }
    data = json.loads(source.read_text(encoding="utf-8"))
    records = data.get("records") if isinstance(data.get("records"), list) else []
    return {
        "schema_version": data.get("schema_version", "claimreview_index.v1"),
        "path": str(source),
        "record_count": len(records),
        "records": records,
        "provider_notes": data.get("provider_notes") or [],
    }


def _record_to_google_claim(record: dict[str, Any]) -> dict[str, Any]:
    review = record.get("review") if isinstance(record.get("review"), dict) else {}
    return {
        "text": record.get("claim_text"),
        "claimant": record.get("claimant"),
        "claimDate": record.get("claim_date"),
        "claimReview": [
            {
                "publisher": {
                    "name": review.get("publisher_name"),
                    "site": review.get("publisher_site"),
                },
                "url": review.get("url"),
                "title": review.get("title"),
                "reviewDate": review.get("review_date"),
                "textualRating": review.get("textual_rating"),
                "languageCode": review.get("language_code"),
                "source_metadata": record.get("source_metadata") or {},
            }
        ],
    }


def search_claimreview_index(
    claim_text: str,
    *,
    publisher_site: str,
    language_code: str,
    max_age_days: int,
    page_size: int = 10,
    index_path: str | Path | None = None,
) -> dict[str, Any]:
    index = load_claimreview_index(index_path)
    site = normalize_domain(publisher_site)
    claims: list[dict[str, Any]] = []
    scored: list[tuple[float, dict[str, Any]]] = []
    for record in index.get("records", []):
        if not isinstance(record, dict):
            continue
        review = record.get("review") if isinstance(record.get("review"), dict) else {}
        if normalize_domain(review.get("publisher_site")) != site:
            continue
        review_language = str(review.get("language_code") or "").lower()
        if review_language and language_code and not review_language.startswith(language_code[:2].lower()):
            continue
        if not within_max_age(review.get("review_date") or record.get("claim_date"), max_age_days):
            continue
        record_text = str(record.get("claim_text") or "")
        overlap = token_overlap(claim_text, record_text)
        exactish = normalized_text(claim_text) in normalized_text(record_text) or normalized_text(record_text) in normalized_text(claim_text)
        if not exactish and overlap < 0.2:
            continue
        scored.append((match_confidence(claim_text, record_text), record))
    for _score, record in sorted(scored, key=lambda item: item[0], reverse=True)[:page_size]:
        claims.append(_record_to_google_claim(record))
    notes = list(index.get("provider_notes") or [])
    notes.append(f"Local ClaimReview index searched at {index.get('path')}; records={index.get('record_count', 0)}.")
    return {"claims": claims, "provider_notes": notes}


class LocalClaimReviewIndexProvider:
    provider_name = "local_claimreview"

    def __init__(self, index_path: str | Path | None = None):
        self.index_path = Path(index_path).expanduser().resolve() if index_path else configured_index_path()

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        return search_claimreview_index(
            claim_text,
            publisher_site=options.publisher_site,
            language_code=options.language_code,
            max_age_days=options.max_age_days,
            page_size=options.page_size,
            index_path=self.index_path,
        )
