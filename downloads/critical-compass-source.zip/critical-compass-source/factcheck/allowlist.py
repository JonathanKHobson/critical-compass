from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .config import config_value


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ALLOWLIST_PATH = PROJECT_ROOT / "support" / "registry" / "trusted_factcheck_publishers.json"


def normalize_domain(value: Any) -> str:
    text = str(value or "").strip().lower()
    if not text:
        return ""
    if "://" not in text:
        text = "https://" + text
    parsed = urlparse(text)
    domain = parsed.netloc or parsed.path
    domain = domain.split("@")[-1].split(":")[0].strip(".")
    if domain.startswith("www."):
        domain = domain[4:]
    return domain


def allowlist_path() -> Path:
    override = config_value("CRITICAL_COMPASS_FACTCHECK_ALLOWLIST_PATH")
    if override:
        return Path(override).expanduser().resolve()
    return DEFAULT_ALLOWLIST_PATH


def load_allowlist(path: str | Path | None = None) -> dict[str, Any]:
    source = Path(path).expanduser().resolve() if path else allowlist_path()
    data = json.loads(source.read_text(encoding="utf-8"))
    publishers = []
    by_site: dict[str, dict[str, Any]] = {}
    for item in data.get("publishers", []):
        if not isinstance(item, dict):
            continue
        site = normalize_domain(item.get("site") or item.get("domain"))
        if not site:
            continue
        row = dict(item)
        row["site"] = site
        row.setdefault("domain", site)
        row.setdefault("status", "active")
        publishers.append(row)
        if row.get("status") == "active":
            by_site[site] = row
    return {
        "schema_version": data.get("schema_version", "v1"),
        "path": str(source),
        "publishers": publishers,
        "active_sites": sorted(by_site),
        "by_site": by_site,
        "policy": data.get("policy", ""),
    }


def resolve_publisher_sites(
    requested_sites: list[str] | None,
    *,
    allowlist: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source = allowlist or load_allowlist()
    by_site = source.get("by_site") if isinstance(source.get("by_site"), dict) else {}
    if requested_sites:
        requested = [normalize_domain(site) for site in requested_sites]
        requested = [site for site in requested if site]
    else:
        requested = sorted(by_site)
    approved = [site for site in requested if site in by_site]
    rejected = [site for site in requested if site and site not in by_site]
    return {
        "approved_sites": approved,
        "rejected_sites": rejected,
        "mode": "single_org" if len(approved) == 1 else "multi_source",
        "allowlist_path": source.get("path", ""),
        "allowlist_policy": source.get("policy", ""),
        "publishers": [by_site[site] for site in approved],
    }
