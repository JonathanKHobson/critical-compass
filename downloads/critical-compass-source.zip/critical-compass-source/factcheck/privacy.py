from __future__ import annotations

import re
from typing import Any


EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b", re.IGNORECASE)
PHONE_RE = re.compile(r"(?:\+?1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]?\d{4}")
SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
CREDIT_RE = re.compile(r"\b(?:\d[ -]*?){13,16}\b")
TOKEN_RE = re.compile(r"\b(?:api[_-]?key|password|token|secret|credential|account number|routing number)\b", re.IGNORECASE)
PRIVATE_CONTEXT_RE = re.compile(
    r"\b(my|our|this student's|this employee's|patient|client|tenant|minor|child|family|spouse|partner)\b",
    re.IGNORECASE,
)
SENSITIVE_TOPIC_RE = re.compile(
    r"\b(diagnosed|medical|therapy|bankrupt|debt|salary|fired|termination|lawsuit|arrested|accused|divorce|custody|grades?|discipline|disability|immigration)\b",
    re.IGNORECASE,
)
NAMED_PRIVATE_ALLEGATION_RE = re.compile(
    r"\b[A-Z][a-z]+ [A-Z][a-z]+\b.{0,80}\b(accused|stole|fired|diagnosed|bankrupt|divorced|arrested|sued|cheated|harassed)\b"
)


def sensitivity_reasons(claim_text: Any) -> list[str]:
    text = str(claim_text or "")
    reasons: list[str] = []
    if EMAIL_RE.search(text):
        reasons.append("contains_private_contact_email")
    if PHONE_RE.search(text):
        reasons.append("contains_private_contact_phone")
    if SSN_RE.search(text) or CREDIT_RE.search(text):
        reasons.append("contains_financial_or_identity_number")
    if TOKEN_RE.search(text):
        reasons.append("contains_account_or_credential_language")
    if PRIVATE_CONTEXT_RE.search(text) and SENSITIVE_TOPIC_RE.search(text):
        reasons.append("contains_private_context_sensitive_topic")
    if NAMED_PRIVATE_ALLEGATION_RE.search(text):
        reasons.append("contains_named_private_allegation")
    return reasons


def is_sensitive_claim(claim_text: Any) -> bool:
    return bool(sensitivity_reasons(claim_text))
