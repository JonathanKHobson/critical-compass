from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

from .config import config_value


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CACHE_DIR = PROJECT_ROOT / "reports" / "factcheck-cache"


def cache_enabled() -> bool:
    return config_value("CRITICAL_COMPASS_FACTCHECK_CACHE_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}


def cache_dir() -> Path:
    override = config_value("CRITICAL_COMPASS_FACTCHECK_CACHE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return DEFAULT_CACHE_DIR


def cache_ttl_seconds() -> int:
    try:
        return max(0, int(config_value("CRITICAL_COMPASS_FACTCHECK_CACHE_TTL_SECONDS", "86400")))
    except ValueError:
        return 86400


def cache_key(parts: dict[str, Any]) -> str:
    material = json.dumps(parts, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def read_cache(key: str) -> dict[str, Any] | None:
    if not cache_enabled():
        return None
    path = cache_dir() / f"{key}.json"
    if not path.exists():
        return None
    ttl = cache_ttl_seconds()
    if ttl and time.time() - path.stat().st_mtime > ttl:
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def write_cache(key: str, value: dict[str, Any]) -> str:
    if not cache_enabled():
        return ""
    directory = cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{key}.json"
    path.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    return str(path.resolve())
