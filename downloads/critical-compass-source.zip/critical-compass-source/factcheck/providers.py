from __future__ import annotations

import json
import os
import re
from html import unescape
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus, urlencode, urljoin, urlparse
from urllib.request import Request, urlopen

from .allowlist import load_allowlist, normalize_domain
from .config import config_value


GOOGLE_ENDPOINT = "https://factchecktools.googleapis.com/v1alpha1/claims:search"
BRAVE_SEARCH_ENDPOINT = "https://api.search.brave.com/res/v1/web/search"


class ProviderError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class ProviderOptions:
    language_code: str
    publisher_site: str
    max_age_days: int
    page_size: int = 10


class FactCheckProvider(Protocol):
    provider_name: str

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        ...


class GoogleFactCheckToolsProvider:
    provider_name = "google_fact_check_tools"

    def __init__(self, api_key: str | None = None, timeout_seconds: int = 15):
        self.api_key = api_key or config_value("GOOGLE_FACT_CHECK_API_KEY", "")
        self.timeout_seconds = timeout_seconds

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        if not self.api_key:
            raise ProviderError("missing_api_key", "GOOGLE_FACT_CHECK_API_KEY is required for live fact-check lookups.")
        params = {
            "query": claim_text,
            "languageCode": options.language_code,
            "reviewPublisherSiteFilter": options.publisher_site,
            "maxAgeDays": str(options.max_age_days),
            "pageSize": str(options.page_size),
            "key": self.api_key,
        }
        url = GOOGLE_ENDPOINT + "?" + urlencode(params)
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "CriticalCompass/1.0"})
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:  # nosec B310 - explicit opt-in provider call.
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            code = "rate_limited" if exc.code == 429 else f"http_{exc.code}"
            raise ProviderError(code, f"Google Fact Check Tools returned HTTP {exc.code}.") from exc
        except URLError as exc:
            raise ProviderError("network_error", f"Provider network error: {exc.reason}") from exc
        except json.JSONDecodeError as exc:
            raise ProviderError("malformed_response", "Provider returned malformed JSON.") from exc


class BraveSearchProvider:
    """Search approved publisher pages through Brave, then parse ClaimReview markup."""

    provider_name = "brave_search"

    def __init__(self, api_key: str | None = None, timeout_seconds: int = 15):
        self.api_key = api_key or config_value("BRAVE_SEARCH_API_KEY", "")
        self.timeout_seconds = timeout_seconds

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        if not self.api_key:
            raise ProviderError("missing_api_key", "BRAVE_SEARCH_API_KEY is required for Brave Search fact-check lookups.")
        params = {
            "q": f"{claim_text} site:{options.publisher_site}",
            "count": str(options.page_size),
            "country": "us",
            "search_lang": (options.language_code or "en")[:2],
            "safesearch": "strict",
            "spellcheck": "1",
        }
        url = BRAVE_SEARCH_ENDPOINT + "?" + urlencode(params)
        request = Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "CriticalCompass/1.0",
                "X-Subscription-Token": self.api_key,
            },
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:  # nosec B310 - explicit opt-in provider call.
                payload = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            code = "rate_limited" if exc.code == 429 else f"http_{exc.code}"
            raise ProviderError(code, f"Brave Search returned HTTP {exc.code}.") from exc
        except URLError as exc:
            raise ProviderError("network_error", f"Provider network error: {exc.reason}") from exc
        except json.JSONDecodeError as exc:
            raise ProviderError("malformed_response", "Provider returned malformed JSON.") from exc

        results = payload.get("web", {}).get("results", [])
        if not isinstance(results, list):
            return {"claims": []}
        claims: list[dict[str, Any]] = []
        approved = normalize_domain(options.publisher_site)
        seen: set[str] = set()
        for item in results:
            if not isinstance(item, dict):
                continue
            link = str(item.get("url") or "").split("#")[0]
            parsed = urlparse(link)
            domain = normalize_domain(parsed.netloc)
            if parsed.scheme not in {"http", "https"} or (domain != approved and not domain.endswith("." + approved)):
                continue
            if _skip_publisher_url(link):
                continue
            if link in seen:
                continue
            seen.add(link)
            try:
                page_html = _fetch_text(link, self.timeout_seconds)
            except (HTTPError, URLError, TimeoutError, OSError):
                page_html = ""
            title = _html_title(page_html) or str(item.get("title") or "").strip()
            claim_reviews: list[dict[str, Any]] = []
            for block in _jsonld_blocks(page_html):
                claim_reviews.extend(_walk_jsonld(block))
            if claim_reviews:
                for review in claim_reviews[:2]:
                    claims.append(_claimreview_to_google_claim(review, url=link, publisher_site=options.publisher_site, fallback_title=title))
            elif title:
                claims.append(
                    {
                        "text": title,
                        "claimant": None,
                        "claimDate": None,
                        "claimReview": [
                            {
                                "publisher": {"name": options.publisher_site, "site": options.publisher_site},
                                "url": link,
                                "title": title,
                                "reviewDate": None,
                                "textualRating": None,
                                "languageCode": options.language_code,
                            }
                        ],
                    }
                )
            if len(claims) >= options.page_size:
                break
        return {"claims": claims}


def _fetch_text(url: str, timeout_seconds: int) -> str:
    request = Request(
        url,
        headers={
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "User-Agent": "CriticalCompass/1.0 (+local opt-in fact-check lookup)",
        },
    )
    with urlopen(request, timeout=timeout_seconds) as response:  # nosec B310 - explicit opt-in provider call.
        content_type = response.headers.get_content_charset() or "utf-8"
        return response.read(1_500_000).decode(content_type, "replace")


def _source_metadata(site: str) -> dict[str, Any]:
    try:
        row = load_allowlist().get("by_site", {}).get(normalize_domain(site), {})
    except (OSError, json.JSONDecodeError):
        row = {}
    return {
        "source_name": row.get("name") or row.get("source_name") or normalize_domain(site),
        "publisher_site": normalize_domain(row.get("site") or site),
        "source_class": row.get("source_class") or "fact_check_publisher_direct",
        "regions": row.get("regions") or ([row.get("region")] if row.get("region") else []),
        "country": row.get("country"),
        "languages": row.get("languages") or [],
        "governance": row.get("governance") or row.get("ownership") or "",
        "coverage_notes": row.get("coverage_notes") or row.get("review_notes") or "",
    }


def _publisher_search_url(site: str, query: str) -> str:
    q = quote_plus(query)
    try:
        row = load_allowlist().get("by_site", {}).get(normalize_domain(site), {})
    except (OSError, json.JSONDecodeError):
        row = {}
    if row.get("search_url_template"):
        return str(row["search_url_template"]).format(query=q)
    templates = {
        "factcheck.org": "https://www.factcheck.org/search/?q={query}",
        "politifact.com": "https://www.politifact.com/search/?q={query}",
        "snopes.com": "https://www.snopes.com/search/?q={query}",
        "reuters.com": "https://www.reuters.com/site-search/?query={query}",
        "apnews.com": "https://apnews.com/search?q={query}",
        "fullfact.org": "https://fullfact.org/search/?q={query}",
        "leadstories.com": "https://leadstories.com/cgi-bin/mt/mt-search.cgi?search={query}",
        "afp.com": "https://factcheck.afp.com/search?search={query}",
    }
    return templates.get(site, f"https://{site}/search/?q={{query}}").format(query=q)


def _candidate_links(search_html: str, base_url: str, publisher_site: str, limit: int) -> list[str]:
    links: list[str] = []
    seen: set[str] = set()
    approved = normalize_domain(publisher_site)
    for match in re.finditer(r"""href=["']([^"']+)["']""", search_html, re.IGNORECASE):
        href = unescape(match.group(1))
        url = urljoin(base_url, href).split("#")[0]
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            continue
        domain = normalize_domain(parsed.netloc)
        if domain != approved and not domain.endswith("." + approved):
            continue
        if _skip_publisher_url(url):
            continue
        if url not in seen:
            seen.add(url)
            links.append(url)
        if len(links) >= limit:
            break
    return links


def _skip_publisher_url(url: str) -> bool:
    return any(
        skip in url.lower()
        for skip in ["/tag/", "/author/", "/category/", "/about", "/privacy", "/contact", "/search", "/rss", "/feed", "/social/"]
    )


def _jsonld_blocks(html: str) -> list[Any]:
    blocks: list[Any] = []
    for match in re.finditer(
        r"""<script[^>]+type=["']application/ld\+json["'][^>]*>(.*?)</script>""",
        html,
        re.IGNORECASE | re.DOTALL,
    ):
        raw = unescape(match.group(1)).strip()
        if not raw:
            continue
        try:
            blocks.append(json.loads(raw))
        except json.JSONDecodeError:
            continue
    return blocks


def _walk_jsonld(value: Any) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if isinstance(value, dict):
        type_value = value.get("@type")
        types = type_value if isinstance(type_value, list) else [type_value]
        if any(str(item).lower() == "claimreview" for item in types):
            found.append(value)
        for item in value.values():
            found.extend(_walk_jsonld(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(_walk_jsonld(item))
    return found


def _html_title(html: str) -> str:
    meta = re.search(r"""<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""", html, re.IGNORECASE)
    if meta:
        return unescape(meta.group(1)).strip()
    title = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    return re.sub(r"\s+", " ", unescape(title.group(1))).strip() if title else ""


def _rating_text(review_rating: Any) -> str | None:
    if isinstance(review_rating, dict):
        for key in ("alternateName", "name", "ratingValue"):
            if review_rating.get(key) is not None:
                return str(review_rating[key])
    if review_rating:
        return str(review_rating)
    return None


def _claimreview_to_google_claim(review: dict[str, Any], *, url: str, publisher_site: str, fallback_title: str) -> dict[str, Any]:
    publisher = review.get("author") if isinstance(review.get("author"), dict) else {}
    item_reviewed = review.get("itemReviewed") if isinstance(review.get("itemReviewed"), dict) else {}
    claim_text = review.get("claimReviewed") or item_reviewed.get("claimReviewed") or fallback_title
    return {
        "text": claim_text,
        "claimant": item_reviewed.get("author") if isinstance(item_reviewed.get("author"), str) else None,
        "claimDate": review.get("datePublished") or review.get("dateCreated"),
        "claimReview": [
            {
                "publisher": {"name": publisher.get("name") or publisher_site, "site": publisher_site},
                "url": url,
                "title": review.get("headline") or review.get("name") or fallback_title,
                "reviewDate": review.get("datePublished") or review.get("dateModified"),
                "textualRating": _rating_text(review.get("reviewRating")),
                "languageCode": review.get("inLanguage"),
                "source_metadata": _source_metadata(publisher_site),
            }
        ],
    }


class KeylessPublisherSearchProvider:
    provider_name = "publisher_site_search"

    def __init__(self, timeout_seconds: int = 12):
        self.timeout_seconds = timeout_seconds

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        search_url = _publisher_search_url(options.publisher_site, claim_text)
        try:
            search_html = _fetch_text(search_url, self.timeout_seconds)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise ProviderError("publisher_search_error", f"Publisher search failed for {options.publisher_site}: {exc}") from exc
        claims: list[dict[str, Any]] = []
        links = _candidate_links(search_html, search_url, options.publisher_site, options.page_size)
        for link in links[: options.page_size]:
            try:
                page_html = _fetch_text(link, self.timeout_seconds)
            except (HTTPError, URLError, TimeoutError, OSError):
                continue
            title = _html_title(page_html)
            claim_reviews: list[dict[str, Any]] = []
            for block in _jsonld_blocks(page_html):
                claim_reviews.extend(_walk_jsonld(block))
            if claim_reviews:
                for review in claim_reviews[:2]:
                    claims.append(_claimreview_to_google_claim(review, url=link, publisher_site=options.publisher_site, fallback_title=title))
            elif title:
                claims.append(
                    {
                        "text": title,
                        "claimant": None,
                        "claimDate": None,
                        "claimReview": [
                            {
                                "publisher": {"name": options.publisher_site, "site": options.publisher_site},
                                "url": link,
                                "title": title,
                                "reviewDate": None,
                                "textualRating": None,
                                "languageCode": options.language_code,
                            }
                        ],
                    }
                )
            if len(claims) >= options.page_size:
                break
        return {"claims": claims}


class PublisherClaimReviewHarvesterProvider:
    """Harvest ClaimReview JSON-LD from approved publisher search pages."""

    provider_name = "publisher_harvest"

    def __init__(self, timeout_seconds: int = 12):
        self.timeout_seconds = timeout_seconds

    def search(self, claim_text: str, options: ProviderOptions) -> dict[str, Any]:
        search_url = _publisher_search_url(options.publisher_site, claim_text)
        try:
            search_html = _fetch_text(search_url, self.timeout_seconds)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise ProviderError("publisher_harvest_error", f"Publisher harvest failed for {options.publisher_site}: {exc}") from exc
        claims: list[dict[str, Any]] = []
        links = _candidate_links(search_html, search_url, options.publisher_site, options.page_size)
        for link in links[: options.page_size]:
            try:
                page_html = _fetch_text(link, self.timeout_seconds)
            except (HTTPError, URLError, TimeoutError, OSError):
                continue
            title = _html_title(page_html)
            claim_reviews: list[dict[str, Any]] = []
            for block in _jsonld_blocks(page_html):
                claim_reviews.extend(_walk_jsonld(block))
            for review in claim_reviews[:3]:
                claims.append(_claimreview_to_google_claim(review, url=link, publisher_site=options.publisher_site, fallback_title=title))
            if len(claims) >= options.page_size:
                break
        return {
            "claims": claims[: options.page_size],
            "provider_notes": [
                f"Publisher ClaimReview harvest searched {options.publisher_site}.",
                "Only ClaimReview JSON-LD or equivalent structured metadata was used; title-only search hits were ignored.",
            ],
        }


def parse_provider_date(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(text[:10], fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def within_max_age(value: Any, max_age_days: int) -> bool:
    if not max_age_days:
        return True
    parsed = parse_provider_date(value)
    if not parsed:
        return True
    now = datetime.now(timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return (now - parsed).days <= max_age_days


def normalized_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip().lower()


def token_overlap(a: str, b: str) -> float:
    left = {token for token in normalized_text(a).split() if len(token) > 2}
    right = {token for token in normalized_text(b).split() if len(token) > 2}
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def match_confidence(query_claim: str, matched_claim: str) -> float:
    if normalized_text(query_claim) == normalized_text(matched_claim):
        return 0.95
    if token_overlap(query_claim, matched_claim) >= 0.6:
        return 0.75
    return 0.45


def normalize_google_response(
    provider_payloads: list[dict[str, Any]],
    *,
    query_claim: str,
    approved_sites: list[str],
    max_age_days: int,
) -> tuple[list[dict[str, Any]], list[str]]:
    matches: list[dict[str, Any]] = []
    notes: list[str] = []
    approved = {normalize_domain(site) for site in approved_sites}
    for payload in provider_payloads:
        payload_notes = payload.get("provider_notes") if isinstance(payload, dict) else None
        if isinstance(payload_notes, list):
            notes.extend(str(item) for item in payload_notes if item)
        claims = payload.get("claims")
        if not isinstance(claims, list):
            if payload:
                notes.append("Provider response did not include a claims array.")
            continue
        for claim in claims:
            if not isinstance(claim, dict):
                continue
            reviews = claim.get("claimReview") or claim.get("claimReviews") or []
            if not isinstance(reviews, list):
                continue
            for review in reviews:
                if not isinstance(review, dict):
                    continue
                publisher = review.get("publisher") if isinstance(review.get("publisher"), dict) else {}
                site = normalize_domain(publisher.get("site") or publisher.get("url") or review.get("url"))
                if site not in approved:
                    continue
                review_date = review.get("reviewDate") or review.get("datePublished")
                if not within_max_age(review_date or claim.get("claimDate"), max_age_days):
                    notes.append(f"Excluded an outdated review from {site}.")
                    continue
                matched_text = str(claim.get("text") or "").strip()
                confidence = match_confidence(query_claim, matched_text)
                match = {
                    "matched_claim_text": matched_text,
                    "claimant": claim.get("claimant"),
                    "claim_date": claim.get("claimDate"),
                    "review": {
                        "publisher_name": publisher.get("name") or site,
                        "publisher_site": site,
                        "url": review.get("url") or "",
                        "title": review.get("title"),
                        "review_date": review_date,
                        "textual_rating": review.get("textualRating"),
                        "language_code": review.get("languageCode"),
                        "source_metadata": review.get("source_metadata") if isinstance(review.get("source_metadata"), dict) else {},
                    },
                    "match_confidence": confidence,
                }
                if confidence < 0.75:
                    match["caution"] = "Related-but-not-identical claim; do not describe this as confirmation."
                matches.append(match)
    return matches, notes
