from __future__ import annotations

import re
from typing import Any


TIER_1_TOOLS = (
    "get_started",
    "quick_scan",
    "audit_text",
    "claim_stress_test",
    "prepare_audit_source",
    "generate_audit_report",
)

TIER_2_TOOLS = (
    "critical_compass_overview",
    "advanced_audit",
    "factcheck_lookup",
    "validate_report_payload",
    "generate_audit_artifact_viewer",
    "list_agent_personas",
    "define_audit_agents",
    "run_independent_audit_analysis",
    "map_audit_tensions",
    "run_audit_debate",
    "synthesize_audit_verdict",
    "propose_mitigation_rewrite",
    "list_concept_examples",
    "lookup_bias",
    "get_framework",
    "search_knowledge_base",
    "list_categories",
    "get_entry",
    "list_reasoning_flows",
    "get_reasoning_flow",
    "search_reasoning_flows",
    "save_audit_progress",
    "get_audit_progress",
    "list_audit_progress",
    "get_cis_revision_timeline",
    "save_audit_result",
    "get_audit_result",
    "list_audit_results",
    "compare_audit_results",
)

TIER_3_TOOLS = (
    "get_pattern",
    "suggest_next_steps",
    "challenge_claim",
    "save_bias_pattern",
    "save_entity_pattern",
    "save_blind_spot_reminder",
    "get_pattern_summary",
    "save_kb_addition",
    "list_kb_additions",
    "get_kb_addition",
    "update_kb_addition",
    "soft_delete_kb_addition",
)

TOOL_TIER_REGISTRY: dict[str, int] = {
    **{name: 1 for name in TIER_1_TOOLS},
    **{name: 2 for name in TIER_2_TOOLS},
    **{name: 3 for name in TIER_3_TOOLS},
}

TIER_LABELS = {
    1: "Tier 1",
    2: "Tier 2",
    3: "Tier 3",
}

TIER_GUIDANCE = {
    1: "Start here for first-use, quick audits, full audits, claim cards, PDF/source intake, and report generation.",
    2: "Use after the lane is known for workflow support, validation, advanced audit stages, KB lookup, fact-check scaffolds, saved results, and comparisons.",
    3: "Use only for compatibility, persistence overlays, legacy helpers, or user-added KB maintenance.",
}

START_HERE_TOOLS = TIER_1_TOOLS
_TIER_PREFIX_RE = re.compile(r"^\[Tier [123]\]\s*")


def tier_for_tool(tool_name: str) -> int:
    return TOOL_TIER_REGISTRY.get(tool_name, 3)


def tier_label(tool_name: str) -> str:
    return TIER_LABELS[tier_for_tool(tool_name)]


def tier_prefix(tool_name: str) -> str:
    return f"[{tier_label(tool_name)}]"


def strip_tier_prefix(description: str) -> str:
    return _TIER_PREFIX_RE.sub("", description or "").strip()


def tiered_description(tool_name: str, description: str) -> str:
    cleaned = strip_tier_prefix(description)
    return f"{tier_prefix(tool_name)} {cleaned}" if cleaned else tier_prefix(tool_name)


def tool_tiers_payload() -> dict[str, Any]:
    return {
        "tier_1": {"label": "Tier 1", "tools": list(TIER_1_TOOLS), "guidance": TIER_GUIDANCE[1]},
        "tier_2": {"label": "Tier 2", "tools": list(TIER_2_TOOLS), "guidance": TIER_GUIDANCE[2]},
        "tier_3": {"label": "Tier 3", "tools": list(TIER_3_TOOLS), "guidance": TIER_GUIDANCE[3]},
    }


def annotate_tool_record(item: dict[str, Any], *, tool_key: str = "tool") -> dict[str, Any]:
    tool_name = str(item.get(tool_key) or item.get("best_tool") or "")
    tier = tier_for_tool(tool_name)
    return {
        **item,
        "tier": tier,
        "tier_label": TIER_LABELS[tier],
        "tier_guidance": TIER_GUIDANCE[tier],
    }


def annotate_tool_records(items: list[dict[str, Any]], *, tool_key: str = "tool") -> list[dict[str, Any]]:
    return [annotate_tool_record(item, tool_key=tool_key) for item in items]


def apply_tool_tiers_to_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    tools = manifest.get("tools")
    if not isinstance(tools, list):
        return manifest
    for item in tools:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        item["description"] = tiered_description(name, str(item.get("description") or ""))
    return manifest
