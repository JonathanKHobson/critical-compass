PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
  document_id TEXT PRIMARY KEY,
  source_path TEXT NOT NULL UNIQUE,
  source_type TEXT,
  source_collection TEXT,
  source_slug TEXT,
  source_title TEXT,
  content_hash TEXT,
  provenance_json TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS concepts (
  rowid INTEGER PRIMARY KEY AUTOINCREMENT,
  concept_id TEXT NOT NULL UNIQUE,
  entry_id TEXT,
  slug TEXT,
  title TEXT NOT NULL,
  kind TEXT NOT NULL,
  category TEXT NOT NULL,
  subcategory TEXT,
  public_schema TEXT NOT NULL,
  summary TEXT,
  definition TEXT,
  example TEXT,
  examples_json TEXT,
  impact TEXT,
  mitigation TEXT,
  confidence REAL,
  confidence_weight TEXT,
  three_cs_lens TEXT,
  aliases_json TEXT,
  related_json TEXT,
  when_to_use_json TEXT,
  failure_modes_json TEXT,
  signals_json TEXT,
  anti_patterns_json TEXT,
  quality_flags_json TEXT,
  provenance_json TEXT,
  source_document_id TEXT,
  source_path TEXT,
  normalized_path TEXT,
  render_format TEXT,
  content_text TEXT,
  search_text TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_document_id) REFERENCES documents (document_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS aliases (
  alias_norm TEXT NOT NULL,
  alias TEXT NOT NULL,
  concept_id TEXT NOT NULL,
  alias_kind TEXT NOT NULL DEFAULT 'source',
  source TEXT,
  PRIMARY KEY (alias_norm, concept_id),
  FOREIGN KEY (concept_id) REFERENCES concepts (concept_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS relations (
  relation_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_concept_id TEXT NOT NULL,
  relation_type TEXT NOT NULL,
  target_concept_id TEXT,
  target_ref TEXT,
  confidence REAL,
  metadata_json TEXT,
  FOREIGN KEY (source_concept_id) REFERENCES concepts (concept_id) ON DELETE CASCADE,
  FOREIGN KEY (target_concept_id) REFERENCES concepts (concept_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS concept_facets (
  facet_type TEXT NOT NULL,
  facet_value TEXT NOT NULL,
  concept_id TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'tags',
  PRIMARY KEY (facet_type, facet_value, concept_id),
  FOREIGN KEY (concept_id) REFERENCES concepts (concept_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_concepts_category_kind ON concepts (category, kind);
CREATE INDEX IF NOT EXISTS idx_concepts_title ON concepts (title);
CREATE INDEX IF NOT EXISTS idx_concepts_public_schema ON concepts (public_schema);
CREATE INDEX IF NOT EXISTS idx_aliases_norm ON aliases (alias_norm);
CREATE INDEX IF NOT EXISTS idx_relations_source ON relations (source_concept_id, relation_type);
CREATE INDEX IF NOT EXISTS idx_relations_target ON relations (target_concept_id, relation_type);
CREATE INDEX IF NOT EXISTS idx_facets_lookup ON concept_facets (facet_type, facet_value);

CREATE VIRTUAL TABLE IF NOT EXISTS concept_fts USING fts5(
  concept_id UNINDEXED,
  title,
  aliases,
  summary,
  definition,
  example,
  impact,
  mitigation,
  content_text,
  tokenize = 'unicode61 remove_diacritics 2'
);

CREATE VIEW IF NOT EXISTS bias_entries AS
SELECT
  concept_id,
  entry_id,
  slug,
  title,
  kind,
  category,
  subcategory,
  summary,
  definition,
  example,
  examples_json,
  impact,
  mitigation,
  confidence,
  confidence_weight,
  three_cs_lens,
  aliases_json,
  related_json,
  when_to_use_json,
  failure_modes_json,
  signals_json,
  anti_patterns_json,
  quality_flags_json,
  provenance_json,
  source_path,
  normalized_path,
  public_schema
FROM concepts
WHERE category = 'biases';

CREATE VIEW IF NOT EXISTS framework_entries AS
SELECT
  concept_id,
  entry_id,
  slug,
  title,
  kind,
  category,
  subcategory,
  summary,
  definition,
  example,
  examples_json,
  impact,
  mitigation,
  confidence,
  confidence_weight,
  three_cs_lens,
  aliases_json,
  related_json,
  when_to_use_json,
  failure_modes_json,
  signals_json,
  anti_patterns_json,
  quality_flags_json,
  provenance_json,
  source_path,
  normalized_path,
  public_schema
FROM concepts
WHERE category IN ('reasoning-frameworks', 'thinking-lenses', 'methodology-checks')
   OR public_schema = 'framework';

CREATE VIEW IF NOT EXISTS fallacy_entries AS
SELECT
  concept_id,
  entry_id,
  slug,
  title,
  kind,
  category,
  subcategory,
  summary,
  definition,
  example,
  examples_json,
  impact,
  mitigation,
  confidence,
  confidence_weight,
  three_cs_lens,
  aliases_json,
  related_json,
  when_to_use_json,
  failure_modes_json,
  signals_json,
  anti_patterns_json,
  quality_flags_json,
  provenance_json,
  source_path,
  normalized_path,
  public_schema
FROM concepts
WHERE category = 'fallacies';
