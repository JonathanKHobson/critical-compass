from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "packaging" / "mcpb" / "critical-compass" / "manifest.json"
PYPROJECT_PATH = ROOT / "packaging" / "mcpb" / "critical-compass" / "pyproject.toml"
LAUNCHER_PATH = ROOT / "packaging" / "mcpb" / "critical-compass" / "mcpb_launcher.py"
BUILD_SCRIPT = ROOT / "scripts" / "build_mcpb_bundle.py"
SCAFFOLD_MANIFEST = ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json"


def test_mcpb_manifest_uses_uv_runtime_and_no_provider_keys() -> None:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

    assert manifest["manifest_version"] == "0.4"
    assert manifest["name"] == "critical-compass"
    assert manifest["server"]["type"] == "uv"
    assert manifest["server"]["entry_point"] == "mcpb_launcher.py"
    assert manifest["server"]["mcp_config"]["command"] == "uv"
    assert manifest["server"]["mcp_config"]["args"] == ["run", "--directory", "${__dirname}", "mcpb_launcher.py"]
    assert "google" not in json.dumps(manifest).casefold()
    assert "brave" not in json.dumps(manifest).casefold()
    tool_names = {tool["name"] for tool in manifest["tools"]}
    assert "factcheck_lookup" in tool_names
    assert "validate_report_payload" in tool_names


def test_mcpb_manifest_tool_descriptions_are_tiered() -> None:
    from tool_tiers import START_HERE_TOOLS, TOOL_TIER_REGISTRY, tier_prefix

    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    seen = {tool["name"] for tool in manifest["tools"]}

    assert set(START_HERE_TOOLS) <= seen
    assert seen <= set(TOOL_TIER_REGISTRY)
    tier_1 = {tool["name"] for tool in manifest["tools"] if tool["description"].startswith("[Tier 1]")}
    assert tier_1 == set(START_HERE_TOOLS)
    for tool in manifest["tools"]:
        description = tool["description"]
        assert re.match(r"^\[Tier [123]\] ", description), tool["name"]
        assert description.startswith(tier_prefix(tool["name"]))
        assert len(re.findall(r"\[Tier [123]\]", description)) == 1


def test_mcpb_pyproject_declares_runtime_dependencies_and_platform_markers() -> None:
    text = PYPROJECT_PATH.read_text(encoding="utf-8")

    for dependency in ["mcp>=1.0.0", "jinja2>=3.1", "weasyprint>=62", "pymupdf>=1.26", "pytesseract>=0.3.13", "Pillow>=10"]:
        assert dependency in text
    assert "sys_platform == 'darwin'" in text
    assert "pyobjc-framework-Vision" in text


def test_mcpb_launcher_redirects_writable_paths_to_user_data() -> None:
    text = LAUNCHER_PATH.read_text(encoding="utf-8")

    assert "CRITICAL_COMPASS_REPORTS_DIR" in text
    assert "CRITICAL_COMPASS_FACTCHECK_CACHE_DIR" in text
    assert "--state-db-path" in text
    assert "--user-additions-pack-path" in text
    assert "db\" / \"critical-compass.sqlite" in text
    assert "critical-compass-state.sqlite" not in (ROOT / "packaging" / "mcpb" / "critical-compass" / "manifest.json").read_text(encoding="utf-8")


def test_mcpb_build_script_stages_clean_bundle(tmp_path: Path) -> None:
    result = subprocess.run(
        [sys.executable, str(BUILD_SCRIPT), "--output-dir", str(tmp_path)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    stage = tmp_path / "critical-compass"
    assert (stage / "manifest.json").exists()
    assert (stage / "pyproject.toml").exists()
    assert (stage / "mcpb_launcher.py").exists()
    assert (stage / "server.py").exists()
    assert (stage / "tool_tiers.py").exists()
    assert (stage / "db" / "critical-compass.sqlite").exists()
    assert not (stage / "db" / "critical-compass-state.sqlite").exists()
    assert not (stage / "tests").exists()
    assert not (stage / "reports").exists()
    assert not (stage / "incoming").exists()
    assert not (stage / "audit_report" / "fixtures").exists()
    assert not (stage / "support" / "registry" / "mcp_capabilities.json").exists()
    assert not (stage / "support" / "registry" / "mcp_capability_registry.schema.json").exists()
    assert not (stage / "support" / "registry" / "mcp_study_lessons.json").exists()
    assert not (stage / "support" / "registry" / "mcp_study_lessons.schema.json").exists()
    assert not (stage / "support" / "registry" / "comparable_tools.json").exists()
    assert not (stage / "support" / "registry" / "comparable_tools.md").exists()
    assert not (stage / "support" / "registry" / "comparable_tools_evaluations.json").exists()
    assert not any(path.name.startswith("._") or path.name.startswith(".__") for path in stage.rglob("*"))


def test_mcpb_diagnostic_prompt_is_exposed_as_scaffold_resource() -> None:
    manifest = json.loads(SCAFFOLD_MANIFEST.read_text(encoding="utf-8"))
    resources = {item["id"]: item for item in manifest["resources"]}
    resource = resources["mcpb_install_diagnostics_prompt"]

    assert resource["path"] == "mcpb-install-diagnostics-prompt.md"
    assert (SCAFFOLD_MANIFEST.parent / resource["path"]).exists()
    text = (SCAFFOLD_MANIFEST.parent / resource["path"]).read_text(encoding="utf-8")
    assert "Settings > Extensions" in text
    assert "Do not add Google/Brave/provider keys" in text


def test_report_output_env_override_keeps_bundle_read_only() -> None:
    tool_text = (ROOT / "audit_report" / "tool.py").read_text(encoding="utf-8")
    source_text = (ROOT / "audit_report" / "source.py").read_text(encoding="utf-8")

    assert "CRITICAL_COMPASS_REPORTS_DIR" in tool_text
    assert "CRITICAL_COMPASS_REPORTS_DIR" in source_text
    assert "os.getenv" in tool_text
    assert "os.getenv" in source_text
