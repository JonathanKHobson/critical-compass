from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"

SAMPLE_TEXT = (
    "The city council should adopt this policy because the pilot suggests better family stability. "
    "The memo does not compare similar cities, and affected families are not directly quoted."
)


def install_fake_mcp_modules() -> None:
    if "audit_report" not in sys.modules:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        audit_report_module.generate_audit_artifact_viewer = lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None}
        audit_report_module.generate_audit_report = lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None}
        audit_report_module.prepare_audit_source = lambda *_args, **_kwargs: {"status": "not_run", "text": ""}
        audit_report_module.validate_report_payload = lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False}
        sys.modules["audit_report"] = audit_report_module

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        advanced_audit_payload,
        critical_compass_overview_payload,
        get_started_payload,
        run_independent_audit_analysis_payload,
    )

    return Repository, advanced_audit_payload, critical_compass_overview_payload, get_started_payload, run_independent_audit_analysis_payload


def run_agentic(**kwargs):
    Repository, advanced_audit_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        return advanced_audit_payload(
            repo,
            SAMPLE_TEXT,
            mode="agent",
            text_type="policy",
            human_loop_mode="silent",
            human_loop_state={"silent_mode_confirmed_by_user": True},
            **kwargs,
        )
    finally:
        repo.close()


def test_generic_use_critical_compass_routes_without_agent_scaffold() -> None:
    *_, get_started_payload, _stage_payload = load_server_symbols()
    result = get_started_payload()
    joined = " ".join(
        result["routing_rule"]["use_get_started_when"]
        + result["starter_prompts"]
        + [result["next_step"], result["agentic_opt_in_rule"]["default_when_unclear"]]
    )

    assert "advanced panel review" in joined
    assert "do not expose agent scaffolds" in joined
    assert "use Critical Compass" in joined


def test_city_council_alone_does_not_trigger_agent_mode_in_routing_contract() -> None:
    *_, overview_payload, _get_started, _stage_payload = load_server_symbols()
    result = overview_payload(topic="quick_start")

    opt_in = result["host_ai_routing"]["agentic_opt_in_rule"]
    assert opt_in["requires_explicit_opt_in"] is True
    assert "city council" in opt_in["insufficient_phrases_alone"]
    assert opt_in["normal_default"].startswith("Use audit_text")


def test_explicit_agent_mode_reaches_plan_review_before_scaffolds() -> None:
    result = run_agentic()

    assert result["status"] == "agentic_plan_review_required"
    assert result["PAUSE_REQUIRED"] is True
    assert result["runtime_policy_card"]["stage"] == "agentic_plan_approval"
    assert result["runtime_policy_card"]["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert result["execution_required"] is False
    assert result["agentic_approval_required"] is True
    assert result["questions_for_user"][0]["id"] == "agentic_plan_approval"
    assert result["questions_for_user"][0]["widget_question_type"] == "single-select"
    assert result["questions_for_user"][0]["ask_user_input_schema_hint"]["tool_name"] == "Ask_User_Input_V0"
    assert result["human_loop_host_action"]["required_interaction_surface"] == "native_host_question_ui"
    assert result["human_loop_host_action"]["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert "ask_user_input widget" in result["human_loop_host_action"]["claude_widget_tool_aliases"]
    assert set(result["human_loop_host_action"]["allowed_question_types"]) == {"single-select", "multi-select", "rank-priority"}
    assert result["human_loop_host_action"]["plain_text_questions_valid"] is False
    assert result["human_loop_host_action"]["tool_compliance_signal"]["current_stage"] == "agentic_plan_approval"
    assert "violates the Critical Compass interaction contract" in result["human_loop_host_action"]["repair_instruction"]
    assert "candidate_model_pool" not in result
    assert len(result["role_contracts"]) == 4
    assert result["agent_execution_adapter"]["selected_adapter"] == "sequential_labeled_fallback"


def test_agentic_plan_approval_widget_contract_snapshot_is_not_prose_only() -> None:
    result = run_agentic()
    action = result["human_loop_host_action"]

    assert result["PAUSE_REQUIRED"] is True
    assert result["runtime_policy_card"]["rule"].startswith("If PAUSE_REQUIRED=true")
    assert action["required_interaction_surface"] == "native_host_question_ui"
    assert action["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert action["allowed_question_types"] == ["single-select", "multi-select", "rank-priority"]
    assert action["plain_text_questions_valid"] is False
    assert "plain-text chat" in action["widget_compliance_check"]["invalid_behavior"]
    assert action["tool_compliance_signal"]["expected_widget_use"] is True
    assert action["tool_compliance_signal"]["current_stage"] == "agentic_plan_approval"
    assert "Do not ask the question in ordinary chat" in action["repair_instruction"]


def test_human_loop_still_blocks_agentic_plan_review() -> None:
    Repository, advanced_audit_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = advanced_audit_payload(repo, SAMPLE_TEXT, mode="agent", text_type="policy", human_loop_mode="guided")
    finally:
        repo.close()

    assert result["status"] == "human_loop_onboarding_pending"
    assert "agentic_plan_hash" not in result
    assert result["human_loop_host_action"]["must_pause"] is True
    assert result["runtime_policy_card"]["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert result["human_loop_host_action"]["plain_text_questions_valid"] is False


def test_agentic_plan_hash_mismatch_fails_closed() -> None:
    result = run_agentic(agentic_state={"plan_approved": True, "approved_plan_hash": "wrong"})

    assert result["status"] == "agentic_plan_hash_mismatch"
    assert result["execution_required"] is False
    assert "Re-run advanced_audit" in result["recovery_action"]


def test_approved_plan_exposes_scaffold_with_contracts_and_budget() -> None:
    review = run_agentic()
    approved = run_agentic(
        agentic_state={
            "plan_approved": True,
            "approved_plan_hash": review["agentic_plan_hash"],
            "agentic_run_id": review["agentic_run_id"],
        }
    )

    assert approved["status"] == "scaffold_ready"
    assert approved["execution_required"] is True
    assert approved["agentic_approval_required"] is False
    assert approved["agentic_plan_hash"] == review["agentic_plan_hash"]
    for key in ["role_contracts", "agent_execution_adapter", "agentic_progress_state", "artifact_budget", "agentic_revision_state"]:
        assert key in approved
    assert approved["artifact_budget"]["artifact_only_handoff"] is True
    assert approved["artifact_budget"]["do_not_pass_full_transcript"] is True
    assert approved["agentic_revision_state"]["max_revision_passes"] == 1


def test_role_contracts_are_read_only_and_do_not_ask_user_directly() -> None:
    result = run_agentic()

    role_types = {role["role_type"] for role in result["role_contracts"]}
    assert role_types == {"evidence_argument", "systems_context", "uncertainty_methods", "missing_voice_power"}
    for role in result["role_contracts"]:
        assert role["asks_user_directly"] is False
        assert role["permission_profile"] == "read_only"
        assert role["allowed_tools"]
        assert role["forbidden_tools"]
        assert role["expected_artifact_schema"]["required"]
        assert role["stop_condition"]


def test_declining_agentic_plan_routes_to_normal_audit() -> None:
    result = run_agentic(agentic_state={"plan_declined": True})

    assert result["status"] == "agentic_plan_declined_route_to_normal_audit"
    assert result["required_next_tool"] == "audit_text"
    assert result["next_call"]["tool"] == "audit_text"
    assert result["execution_required"] is False


def test_host_adapter_selection_is_capability_declared() -> None:
    generic = run_agentic(host_capability_profile={"host_family": "generic_chat"})
    claude_code = run_agentic(host_capability_profile={"host_family": "claude_code", "native_subagents": True})
    codex = run_agentic(host_capability_profile={"host_family": "codex", "explicit_subagent_spawn": True})
    scaffold_only = run_agentic(host_capability_profile={"host_family": "unknown", "can_execute_stage_scaffolds": False})

    assert generic["agent_execution_adapter"]["selected_adapter"] == "sequential_labeled_fallback"
    assert generic["agent_execution_adapter"]["fallback_disclosure_required"] is True
    assert "sequentially" in generic["agent_execution_adapter"]["fallback_disclosure_text"]
    assert claude_code["agent_execution_adapter"]["selected_adapter"] == "claude_native_subagents"
    assert codex["agent_execution_adapter"]["selected_adapter"] == "codex_explicit_subagents"
    assert scaffold_only["agent_execution_adapter"]["selected_adapter"] == "scaffold_only"


def test_stage_payloads_include_artifact_only_handoff_and_progress_state() -> None:
    *_, run_stage = load_server_symbols()
    result = run_stage(
        SAMPLE_TEXT,
        [{"agent_id": "agent_1", "role_contract_id": "agent_1", "name": "Evidence Reviewer"}],
        text_type="policy",
        scaffold_detail="handoff",
        agentic_state={"completed_stage_ids": ["plan_review", "agent_definition"]},
    )

    assert result["scaffold_detail"] == "handoff"
    assert result["artifact_only_handoff"] is True
    assert result["do_not_pass_full_transcript"] is True
    assert result["stage_handoff"]["artifact_only_handoff"] is True
    assert result["agentic_progress_state"]["current_stage"] == "independent_analysis"
    assert "agent_definition" in result["agentic_progress_state"]["completed_stage_ids"]
