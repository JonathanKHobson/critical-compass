from __future__ import annotations

import json
import subprocess
import sys
import types
from pathlib import Path

from mcp_composition import (
    load_mcp_study_lessons,
    summarize_mcp_study_lessons,
    validate_mcp_study_lessons,
)


ROOT = Path(__file__).resolve().parents[1]
LESSONS_PATH = ROOT / "support" / "registry" / "mcp_study_lessons.json"
SCHEMA_PATH = ROOT / "support" / "registry" / "mcp_study_lessons.schema.json"
SCANNER_PATH = ROOT / "scripts" / "scan_mcp_study_library.py"
ROADMAP_VALIDATOR_PATH = ROOT / "scripts" / "validate_mcp_study_roadmap.py"
SURFACE_SYNC_VALIDATOR_PATH = ROOT / "scripts" / "validate_mcp_surface_sync.py"


def lessons_by_id(registry: dict) -> dict[str, dict]:
    return {item["lesson_id"]: item for item in registry["lessons"]}


def load_overview_payload():
    audit_report_module = sys.modules.get("audit_report")
    if audit_report_module is None:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        sys.modules["audit_report"] = audit_report_module
    audit_report_module.generate_audit_artifact_viewer = getattr(
        audit_report_module,
        "generate_audit_artifact_viewer",
        lambda *_args, **_kwargs: {"status": "not_run"},
    )
    audit_report_module.generate_audit_report = getattr(
        audit_report_module,
        "generate_audit_report",
        lambda *_args, **_kwargs: {"qa_status": "not_run"},
    )
    audit_report_module.prepare_audit_source = getattr(
        audit_report_module,
        "prepare_audit_source",
        lambda *_args, **_kwargs: {"status": "not_run", "text": ""},
    )
    audit_report_module.validate_report_payload = getattr(
        audit_report_module,
        "validate_report_payload",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False},
    )

    if "mcp.server.fastmcp" not in sys.modules:
        mcp = types.ModuleType("mcp")
        server_module = types.ModuleType("mcp.server")
        fastmcp_module = types.ModuleType("mcp.server.fastmcp")
        types_module = types.ModuleType("mcp.types")

        class FakeFastMCP:
            def __init__(self, *_args, **_kwargs):
                pass

            def tool(self, *_args, **_kwargs):
                def decorator(func):
                    return func

                return decorator

        class FakeToolAnnotations:
            def __init__(self, **kwargs):
                self.kwargs = kwargs

        fastmcp_module.FastMCP = FakeFastMCP
        types_module.ToolAnnotations = FakeToolAnnotations
        sys.modules["mcp"] = mcp
        sys.modules["mcp.server"] = server_module
        sys.modules["mcp.server.fastmcp"] = fastmcp_module
        sys.modules["mcp.types"] = types_module

    from server import critical_compass_overview_payload  # pylint: disable=import-error,import-outside-toplevel

    return critical_compass_overview_payload


def test_mcp_study_lessons_registry_validates_and_carries_local_evidence() -> None:
    registry = load_mcp_study_lessons(LESSONS_PATH)
    validation = validate_mcp_study_lessons(registry)
    records = lessons_by_id(registry)

    assert validation["valid"], validation["errors"]
    assert validation["record_count"] >= 14
    assert SCHEMA_PATH.exists()
    assert registry["study_library_reference"] == "external-corpus://mcp-study-library"
    assert records["idea_reality_project_context"]["source_repo_path"].endswith("mcp-study-library/repos/idea-reality-mcp")
    assert records["claude_prompts_manifest_and_hooks"]["copy_policy"] == "summarize_only"
    assert records["openfactcheck_eval_contracts"]["license_caution"].startswith("AGPL")
    assert all(item["runtime_dependency"] is False for item in registry["lessons"])


def test_mcp_study_lessons_summary_counts_patterns_without_runtime_claims() -> None:
    registry = load_mcp_study_lessons(LESSONS_PATH)
    summary = summarize_mcp_study_lessons(registry)

    assert summary["record_count"] >= 14
    assert summary["lesson_type_counts"]["scaffold_resource"] >= 3
    assert summary["adaptation_mode_counts"]["document_only"] >= 3
    assert summary["copy_policy_counts"]["original_rewrite_required"] >= 3
    assert summary["status_counts"]["accepted"] >= 8
    assert "study-library lessons" in summary["rule"].lower()
    assert "server_instructions" in summary["accepted_implementation_targets"]


def test_invalid_study_lessons_report_missing_fields_bad_enums_and_runtime_dependency() -> None:
    invalid = {
        "lessons": [
            {
                "lesson_id": "bad",
                "lesson_type": "merge_it_all",
                "adaptation_mode": "clone_repo",
                "copy_policy": "copy_paste",
                "status": "installed",
                "runtime_dependency": True,
                "source_files": [],
                "implementation_target": [],
            }
        ]
    }

    validation = validate_mcp_study_lessons(invalid)

    assert not validation["valid"]
    assert any("missing required fields" in error for error in validation["errors"])
    assert any("unsupported lesson_type" in error for error in validation["errors"])
    assert any("unsupported adaptation_mode" in error for error in validation["errors"])
    assert any("unsupported copy_policy" in error for error in validation["errors"])
    assert any("runtime_dependency=false" in error for error in validation["errors"])


def test_license_cautioned_lessons_require_safe_copy_policy() -> None:
    registry = {
        "lessons": [
            {
                "lesson_id": "unsafe_agpl",
                "source_mcp_id": "agpl_source",
                "source_repo_path": "/tmp/agpl-source",
                "source_files": ["README.md"],
                "lesson_type": "scaffold_resource",
                "pattern_summary": "AGPL source with unsafe copy policy.",
                "critical_compass_application": "Should be blocked.",
                "adaptation_mode": "document_only",
                "copy_policy": "no_code_copy",
                "license_caution": "AGPL-3.0; no direct code or prompt copying.",
                "runtime_dependency": False,
                "implementation_target": ["docs"],
                "status": "accepted",
                "notes": "Fixture.",
            }
        ]
    }

    validation = validate_mcp_study_lessons(registry)

    assert not validation["valid"]
    assert any("must use summarize_only or original_rewrite_required" in error for error in validation["errors"])


def test_scanner_reports_candidate_docs_and_ignores_runtime_files(tmp_path: Path) -> None:
    study_library = tmp_path / "mcp-study-library"
    repo = study_library / "repos" / "sample-mcp"
    (repo / "docs").mkdir(parents=True)
    (repo / "src").mkdir()
    (repo / "tests").mkdir()
    (repo / "README.md").write_text("# Sample", encoding="utf-8")
    (repo / "CLAUDE.md").write_text("Host hint", encoding="utf-8")
    (repo / "docs" / "system-prompts.md").write_text("Prompt guidance", encoding="utf-8")
    (repo / "src" / "schema.ts").write_text("export const schema = {}", encoding="utf-8")
    (repo / "src" / "index.ts").write_text("console.log('runtime')", encoding="utf-8")
    (repo / "tests" / "golden_cases.json").write_text("[]", encoding="utf-8")

    completed = subprocess.run(
        [sys.executable, str(SCANNER_PATH), "--study-library", str(study_library), "--limit-per-repo", "20"],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    files = {item["path"] for item in payload["repositories"][0]["candidate_files"]}

    assert payload["resource_id"] == "critical_compass.mcp_study_library_scan.v1"
    assert payload["repository_count"] == 1
    assert "README.md" in files
    assert "CLAUDE.md" in files
    assert "docs/system-prompts.md" in files
    assert "src/schema.ts" in files
    assert "tests/golden_cases.json" in files
    assert "src/index.ts" not in files
    assert "Do not import" in " ".join(payload["guardrails"])


def test_overview_does_not_expose_study_lessons_as_runtime_guidance() -> None:
    critical_compass_overview_payload = load_overview_payload()

    result = critical_compass_overview_payload(topic="mcp_composition")
    joined = " ".join(str(item) for item in result["tool_map"] + result["starter_prompts"] + result["case_studies"])

    assert result["topic"] == "overview"
    assert "mcp_study_lessons_resource" not in result
    assert "mcp_capability_registry" not in result
    assert "study-library lessons" not in joined.lower()
    assert "mcp_composition" not in joined


def test_ship_next_resources_are_manifested_and_exist() -> None:
    manifest = json.loads((ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json").read_text(encoding="utf-8"))
    resources = {item["id"]: item for item in manifest["resources"]}
    expected = {
        "host_ai_quickstart_current_state": "host-ai-quickstart-current-state.md",
        "client_host_hints": "client-host-hints.md",
        "tool_trigger_matrix": "tool-trigger-matrix.md",
        "surface_sync_checklist": "surface-sync-checklist.md",
    }

    for resource_id, path in expected.items():
        assert resource_id in resources
        assert resources[resource_id]["path"] == path
        assert (ROOT / "support" / "resources" / "scaffolds" / "v1" / path).exists()


def test_mcp_study_roadmap_surfaces_verdict_order_and_ship_next_items() -> None:
    files = [
        ROOT / "docs" / "planning" / "master-roadmap.md",
        ROOT / "docs" / "planning" / "mcp-study-library-soft-learner.md",
        ROOT / "docs" / "planning" / "mcp-composition-strategy.md",
        ROOT / "docs" / "planning" / "mcp-integration-decision-matrix.md",
        ROOT / "docs" / "planning" / "implementation-status-and-idea-drift-review-2026-04-15.md",
        ROOT / "docs" / "tickets" / "top-10-prioritized-tickets.md",
    ]
    joined = "\n".join(path.read_text(encoding="utf-8") for path in files)

    assert "MCP Study Library Implementation Roadmap" in joined
    assert "Completed ship-next" in joined
    assert "Host-AI Quickstart / Current State Context" in joined
    assert "Client-specific one-line hints" in joined
    assert "Tool trigger matrix" in joined
    assert "Surface sync checklist" in joined
    assert "Use for local ClaimReview phase" in joined
    assert "Good next phase" in joined
    assert "Defer until examples prove need" in joined
    assert "Later / high effort" in joined
    assert "Reject / scaffold-only" in joined
    assert "Pressure-Test Readiness" in joined
    assert "mission-audience-purpose-charter.md" in joined
    assert "trust, revise, verify, or reframe" in joined
    assert "public users and nonprofit" in joined

    tickets = (ROOT / "docs" / "tickets" / "top-10-prioritized-tickets.md").read_text(encoding="utf-8")
    assert tickets.index("PTR-01") < tickets.index("PTR-02") < tickets.index("PTR-03") < tickets.index("PTR-04")
    assert "[Done / MSL-01]" in tickets
    assert "[Done / MSL-04]" in tickets
    assert tickets.index("PTR-04") < tickets.index("MSL-01")


def test_mcp_study_roadmap_validator_passes() -> None:
    completed = subprocess.run(
        [sys.executable, str(ROADMAP_VALIDATOR_PATH)],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "mcp study roadmap and pressure-test readiness validation passed" in completed.stdout


def test_mcp_surface_sync_validator_passes() -> None:
    completed = subprocess.run(
        [sys.executable, str(SURFACE_SYNC_VALIDATOR_PATH)],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "mcp surface sync validation passed" in completed.stdout
