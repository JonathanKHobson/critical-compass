from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_state_store():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import StateStore  # pylint: disable=import-error,import-outside-toplevel

    return StateStore


def test_blind_spot_reminder_requires_consent_and_uses_pattern_storage(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        without_consent = state.save_blind_spot_reminder(
            reminder_id="comfortable-answer-risk",
            text_type="policy",
            context_note="Ask what would make the easy answer harder to defend.",
        )
        assert without_consent["saved"] is False
        assert without_consent["requires_explicit_consent"] is True

        saved = state.save_blind_spot_reminder(
            reminder_id="comfortable-answer-risk",
            text_type="policy",
            context_note="Ask what would make the easy answer harder to defend.",
            consent_confirmed=True,
        )

        assert saved["saved"] is True
        assert saved["entity_type"] == "blind_spot_reminder"
        assert saved["entity_id"] == "ct:blind-spot:comfortable-answer-risk"

        summary = state.get_pattern_summary(entity_type="blind_spot", text_type="policy")
        assert summary["count"] == 1
        assert summary["patterns"][0]["entity_type"] == "blind_spot_reminder"
        assert "Consent-confirmed blind-spot reminder" in summary["patterns"][0]["last_context_note"]
    finally:
        state.close()


def test_blind_spot_reminder_blocks_sensitive_personal_profiling(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        result = state.save_blind_spot_reminder(
            reminder_id="religion-profile",
            context_note="Track the user's religion as a recurring blind spot.",
            consent_confirmed=True,
        )

        assert result["saved"] is False
        assert result["sensitive_profile_blocked"] is True
    finally:
        state.close()


def test_reasoning_trap_patterns_use_existing_entity_storage(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        saved = state.save_entity_pattern(
            entity_type="reasoning_risk",
            entity_id="ct:reasoning-trap:base-rate-neglect",
            text_type="research",
            context_note="Base-rate neglect appeared in an audit and should be tracked as a recurring trap shape.",
        )
        assert saved["saved"] is True
        assert saved["pattern"]["entity_type"] == "reasoning_trap"

        summary = state.get_pattern_summary(entity_type="reasoning_trap", text_type="research")
        assert summary["count"] == 1
        assert summary["patterns"][0]["entity_id"] == "ct:reasoning-trap:base-rate-neglect"
    finally:
        state.close()


def test_save_audit_result_preserves_dissent_ledger_in_payload(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        result = state.save_audit_result(
            subject_text="A short advanced audit source.",
            text_type="research",
            critical_integrity_snapshot={
                "display_state": "scored",
                "label": "Moderate Integrity",
                "points": 70,
                "max_points": 100,
                "dimensions": [],
            },
            result_payload={
                "advanced_audit": {
                    "dissent_ledger": [
                        {
                            "agent_name": "Methodologist",
                            "top_finding": "Scope claims need tighter bounds.",
                            "strongest_disagreement": "Power analysis should weigh missing voices more heavily.",
                            "confidence": "medium",
                            "what_would_change_mind": "Direct affected-stakeholder review.",
                            "provenance": "advanced_audit.synthesis",
                        }
                    ]
                }
            },
        )
        loaded = state.get_audit_result(result["result_id"])
        ledger = loaded["result_payload"]["advanced_audit"]["dissent_ledger"]

        assert loaded["found"] is True
        assert ledger[0]["agent_name"] == "Methodologist"
        assert ledger[0]["strongest_disagreement"].startswith("Power analysis")
        assert ledger[0]["what_would_change_mind"] == "Direct affected-stakeholder review."
    finally:
        state.close()


def test_save_audit_result_stores_activity_outcome_in_result_payload(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        result = state.save_audit_result(
            subject_text="A short audit source with a follow-up activity.",
            text_type="advocacy",
            critical_integrity_snapshot={
                "display_state": "scored",
                "label": "Moderate Integrity",
                "points": 72,
                "max_points": 100,
                "dimensions": [],
            },
            result_payload={"report_id": "report-123"},
            activity_outcome={
                "activity_title": "Reverse Outline Repair",
                "choice": "swap it",
                "usefulness": "medium",
                "notes": "The structure activity fit, but the group option would work better.",
            },
        )
        loaded = state.get_audit_result(result["result_id"])
        outcome = loaded["activity_outcome"]

        assert result["activity_outcome_saved"] is True
        assert loaded["result_payload"]["report_id"] == "report-123"
        assert loaded["result_payload"]["activity_outcome"] == outcome
        assert outcome["activity_title"] == "Reverse Outline Repair"
        assert outcome["choice"] == "swap"
        assert outcome["persistence"] == "saved_with_audit_result_only"
    finally:
        state.close()


def test_disagreement_patterns_use_existing_entity_storage(tmp_path: Path) -> None:
    StateStore = load_state_store()
    state = StateStore(tmp_path / "state.sqlite")
    try:
        saved = state.save_entity_pattern(
            entity_type="dissent_pattern",
            entity_id="ct:disagreement:evidence-vs-power-weighting",
            text_type="research",
            context_note="Agents repeatedly diverged on evidence strength versus power-analysis weighting.",
        )
        assert saved["saved"] is True
        assert saved["pattern"]["entity_type"] == "disagreement_pattern"

        summary = state.get_pattern_summary(entity_type="disagreement", text_type="research")
        assert summary["count"] == 1
        assert summary["patterns"][0]["entity_id"] == "ct:disagreement:evidence-vs-power-weighting"
    finally:
        state.close()
