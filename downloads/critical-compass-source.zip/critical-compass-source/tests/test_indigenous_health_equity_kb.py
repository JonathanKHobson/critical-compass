from __future__ import annotations

import json
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"
PACK_PATH = ROOT / "support" / "library" / "indigenous-health-equity.pack.json"


def install_fake_mcp_modules() -> None:
    audit_report_module = sys.modules.get("audit_report")
    if audit_report_module is None:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        sys.modules["audit_report"] = audit_report_module
    audit_report_module.generate_audit_artifact_viewer = getattr(
        audit_report_module,
        "generate_audit_artifact_viewer",
        lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None},
    )
    audit_report_module.generate_audit_report = getattr(
        audit_report_module,
        "generate_audit_report",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None},
    )
    audit_report_module.prepare_audit_source = getattr(
        audit_report_module,
        "prepare_audit_source",
        lambda *_args, **_kwargs: {"status": "not_run", "text": ""},
    )
    audit_report_module.validate_report_payload = getattr(
        audit_report_module,
        "validate_report_payload",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False},
    )

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        define_audit_agents_payload,
        run_independent_audit_analysis_payload,
    )

    return Repository, define_audit_agents_payload, run_independent_audit_analysis_payload


def test_indigenous_health_equity_pack_is_curated_and_quality_flagged() -> None:
    records = json.loads(PACK_PATH.read_text(encoding="utf-8"))

    assert 8 <= len(records) <= 12
    assert {record["entry_id"] for record in records} >= {
        "ct:thinking-lenses:systems:ocap-first-nations-data-governance",
        "ct:thinking-lenses:systems:care-indigenous-data-governance",
        "ct:thinking-lenses:systems:indigenous-data-sovereignty",
        "ct:methodology-checks:audit:data-erasure-misclassification-risk",
    }
    assert all("._" not in json.dumps(record, ensure_ascii=False) for record in records)
    assert all(".DS_Store" not in json.dumps(record, ensure_ascii=False) for record in records)

    data_erasure = next(record for record in records if record["entry_id"].endswith("data-erasure-misclassification-risk"))
    assert data_erasure["status"] == "source_limited"
    assert any(flag["code"] == "source-reconstructed" for flag in data_erasure["quality_flags"])


def test_indigenous_health_equity_entries_are_lookupable_from_db() -> None:
    Repository, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        expected = {
            "OCAP": "ct:thinking-lenses:systems:ocap-first-nations-data-governance",
            "CARE Principles": "ct:thinking-lenses:systems:care-indigenous-data-governance",
            "Indigenous data sovereignty": "ct:thinking-lenses:systems:indigenous-data-sovereignty",
            "data erasure": "ct:methodology-checks:audit:data-erasure-misclassification-risk",
            "Indigenous food sovereignty": "ct:thinking-lenses:systems:indigenous-food-sovereignty-health-equity",
            "relational accountability": "ct:thinking-lenses:systems:relational-accountability-community-research",
        }
        for query, entry_id in expected.items():
            result = repo.lookup_framework_public(query)
            assert result["found"] is True, query
            assert result["id"] == entry_id
    finally:
        repo.close()


def test_advanced_scaffolds_surface_indigenous_kb_grounding_contract() -> None:
    Repository, define_payload, run_stage_payload = load_server_symbols()
    repo = Repository(DB_PATH)
    subject = (
        "The tribal public health dashboard uses AI/AN data to measure food sovereignty, "
        "urban Indigenous health equity, and community-defined recovery indicators."
    )
    try:
        definition = define_payload(repo, subject, text_type="research", retrieval_profile="research_methodology")
    finally:
        repo.close()

    guidance = definition["indigenous_health_equity_kb_guidance"]
    assert guidance["active"] is True
    assert "OCAP" in guidance["required_lookup_terms_when_named"]
    assert "CARE Principles" in guidance["required_lookup_terms_when_named"]
    assert "data-sovereignty or measurement-accountability lens" in " ".join(definition["quality_gate_details"])

    stage = run_stage_payload(
        subject,
        [{"agent_id": "agent_1", "role_contract_id": "agent_1", "name": "Measurement Reviewer"}],
        text_type="research",
        retrieval_profile="research_methodology",
    )
    calls = " ".join(str(call) for call in stage["recommended_mcp_calls"])
    gates = " ".join(stage["quality_gate_details"])
    assert stage["indigenous_health_equity_kb_guidance"]["active"] is True
    assert "Indigenous data sovereignty" in calls
    assert "OCAP" in calls
    assert "host_inference" in gates
