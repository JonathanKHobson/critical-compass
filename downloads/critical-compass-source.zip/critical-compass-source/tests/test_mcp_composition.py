from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from mcp_composition import (
    load_mcp_capability_registry,
    plan_capability_route,
    summarize_mcp_capability_registry,
    validate_mcp_capability_registry,
)


ROOT = Path(__file__).resolve().parents[1]
REGISTRY_PATH = ROOT / "support" / "registry" / "mcp_capabilities.json"
SCHEMA_PATH = ROOT / "support" / "registry" / "mcp_capability_registry.schema.json"


def registry_by_id(registry: dict) -> dict[str, dict]:
    return {item["mcp_id"]: item for item in registry["capabilities"]}


def test_mcp_capability_registry_validates_and_carries_study_library_evidence() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    validation = validate_mcp_capability_registry(registry)
    records = registry_by_id(registry)

    assert validation["valid"], validation["errors"]
    assert validation["record_count"] >= 12
    assert SCHEMA_PATH.exists()
    assert registry["study_library_reference"] == "external-corpus://mcp-study-library"
    assert records["factrank"]["local_source_path"].endswith("mcp-study-library/repos/FactRank")
    assert records["openfactcheck"]["licensing_notes"].startswith("AGPL")
    assert records["fact_check_tools_mcp"]["local_inventory_status"] == "unavailable"


def test_registry_summary_counts_modes_and_statuses() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    summary = summarize_mcp_capability_registry(registry)

    assert summary["record_count"] >= 12
    assert summary["integration_mode_counts"]["merged_internal"] >= 3
    assert summary["integration_mode_counts"]["wrapped_internal"] >= 2
    assert summary["integration_mode_counts"]["prompt_scaffold_only"] >= 4
    assert summary["integration_mode_counts"]["rejected"] >= 1
    assert summary["source_type_counts"]["repo"] >= 6


def test_invalid_registry_reports_missing_fields_and_bad_modes() -> None:
    invalid = {
        "capabilities": [
            {
                "mcp_id": "bad",
                "name": "Bad MCP",
                "integration_mode": "merge_everything",
                "current_status": "ship_it",
                "capabilities": [],
            }
        ]
    }

    validation = validate_mcp_capability_registry(invalid)

    assert not validation["valid"]
    assert any("missing required fields" in error for error in validation["errors"])
    assert any("unsupported integration_mode" in error for error in validation["errors"])
    assert any("unsupported current_status" in error for error in validation["errors"])


def test_orchestration_prefers_internal_capability_over_external() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    route = plan_capability_route(registry, capability_ids=["factrank"], allow_external_mcp=True)

    assert route["status"] == "route_ready"
    assert route["routes"][0]["selected_path"] == "internal"
    assert route["routes"][0]["decision"] == "use_internal"
    assert route["routes"][0]["provenance_label"] == "internal Critical Compass module"


def test_rejected_mcp_is_never_selected() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    route = plan_capability_route(registry, capability_ids=["fact_check_tools_mcp"], allow_external_mcp=True)

    assert route["routes"][0]["selected_path"] == "not_available"
    assert route["routes"][0]["decision"] == "rejected"
    assert route["routes"][0]["provenance_label"] == "rejected_candidate"


def test_scaffold_only_candidate_is_not_mislabeled_as_retrieval() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    route = plan_capability_route(registry, capability_ids=["openfactcheck"], allow_external_mcp=True)

    assert route["routes"][0]["selected_path"] == "prompt_scaffold_only"
    assert route["routes"][0]["decision"] == "use_scaffold"
    assert "retrieval" not in route["routes"][0]["provenance_label"].lower()


def test_external_candidate_falls_back_when_unavailable_or_sensitive() -> None:
    registry = load_mcp_capability_registry(REGISTRY_PATH)
    records = registry_by_id(registry)
    records["idea_reality_mcp"]["current_status"] = "experimental"

    unavailable = plan_capability_route(registry, capability_ids=["idea_reality_mcp"], allow_external_mcp=False)
    sensitive = plan_capability_route(registry, capability_ids=["idea_reality_mcp"], allow_external_mcp=True, sensitivity="sensitive")

    assert unavailable["routes"][0]["decision"] == "fallback"
    assert unavailable["routes"][0]["selected_path"] == "proposal_reality_check_scaffold"
    assert sensitive["routes"][0]["decision"] == "fallback"
    assert sensitive["routes"][0]["selected_path"] == "proposal_reality_check_scaffold"


def test_external_candidate_can_route_only_when_explicitly_allowed() -> None:
    registry = deepcopy(load_mcp_capability_registry(REGISTRY_PATH))
    records = registry_by_id(registry)
    records["idea_reality_mcp"]["current_status"] = "experimental"

    route = plan_capability_route(registry, capability_ids=["idea_reality_mcp"], allow_external_mcp=True)

    assert route["routes"][0]["selected_path"] == "external_mcp"
    assert route["routes"][0]["decision"] == "orchestrate_external"
    assert route["routes"][0]["requires_user_consent"] is True
    assert route["routes"][0]["provenance_label"] == "external MCP orchestration"
