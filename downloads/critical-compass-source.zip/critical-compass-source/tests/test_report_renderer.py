from __future__ import annotations

import json
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_fixture(name: str) -> dict:
    return json.loads((ROOT / "audit_report" / "fixtures" / f"{name}.json").read_text(encoding="utf-8"))


def test_normalize_fixture_payloads() -> None:
    from audit_report.models import validate_payload
    from audit_report.normalize import normalize_audit_data, normalize_options

    for name in [
        "minimal",
        "max_content",
        "profile_only",
        "advanced_full",
        "alias_regression",
        "missing_fields",
        "table_overlap",
        "complete_report_ready",
        "failed_v2_incomplete_report",
        "placeholder_override",
        "long_sentence_caps",
        "claude_schema_trust_regression",
        "advanced_consensus_report",
    ]:
        data = load_fixture(name)
        options = normalize_options(data)
        payload = normalize_audit_data(data, options)
        validate_payload(payload)
        assert payload["meta"]["schema_version"] == "v1"
        assert len(payload["cis"]["dimensions"]) == 5
        assert len(payload["findings"]["biases"]) <= 5


def test_checklist_only_requires_questions() -> None:
    from audit_report.models import validate_payload
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("minimal")
    options = normalize_options(data, report_depth="checklist_only")
    payload = normalize_audit_data(data, options)
    validate_payload(payload)
    assert payload["meta"]["report_depth"] == "checklist_only"


def test_checklist_only_handout_generates_visual_golden_artifact(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    output = tmp_path / "questions-handout.pdf"
    result = generate_audit_report(
        load_fixture("complete_report_ready"),
        report_depth="checklist_only",
        output_path=str(output),
    )

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert result["tier_1_page_range"] == "1-1"
    assert result["tier_2_page_range"] is None
    assert Path(result["preview_image_path"]).exists()
    assert len(result["page_image_paths"]) == result["page_count"] == 1
    assert Path(result["viewer_path"]).exists()

    doc = fitz.open(output)
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Questions To Bring To This Text" in text
    assert "What comparison group supports the attendance claim?" in text


def test_readiness_card_depth_generates_compact_report(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    result = generate_audit_report(
        load_fixture("complete_report_ready"),
        report_depth="readiness_card",
        output_path=str(tmp_path / "readiness-card.pdf"),
    )

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert result["compiled_sections"]["follow_up_activity"] is True
    assert result["compiled_sections"]["assumptions"] is True
    assert result["pressure_test_readiness_card"]["decision_action"] in {"Trust", "Revise", "Verify", "Reframe"}
    assert result["follow_up_activity"]["try_this_next"]["title"]

    markdown = Path(result["markdown_path"]).read_text(encoding="utf-8")
    assert "## Plain-Language Read" in markdown
    assert "## Before Using This Text" in markdown
    assert "## Audit Summary" in markdown
    assert "## Follow-Up Activity" in markdown
    assert "Try This Next" in markdown
    assert "## Quick-Scan Findings" not in markdown
    assert "## Dimension Deep-Dive" not in markdown
    assert "## Argument Map" not in markdown
    assert "## Evidence Needed Next" not in markdown
    assert "## Where the Analysts" not in markdown
    assert "## Reasoning Trap Checks" not in markdown
    assert "Activity Reflection" not in markdown
    assert "KB grounding:" not in markdown
    assert "host_inference" not in markdown
    assert "Solo Activity" not in markdown
    assert "Group Activity" not in markdown

    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Plain-Language Read" in text
    assert "Before Using This Text" in text
    assert "Audit Summary" in text
    assert "TRY" in text
    assert "Claim-Support-Question" in text
    for forbidden in [
        "Argument Map",
        "Evidence Needed Next",
        "Where the Analysts",
        "Reasoning Trap Checks",
        "Activity Reflection",
        "KB grounding:",
        "host_inference",
        "No explicit disagreement",
    ]:
        assert forbidden not in text


def test_readiness_card_depth_blocks_without_next_move(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["quick_scan_card"]["recommended_next_step"] = ""

    result = generate_audit_report(
        data,
        report_depth="readiness_card",
        output_path=str(tmp_path / "readiness-card-blocked.pdf"),
    )

    assert result["qa_status"] == "blocked"
    assert result["report_preflight_card"]["status"] == "needs_resubmission"
    assert any(item["field"] == "pressure_test_readiness_card" for item in result["missing_report_fields"])


def test_external_fact_checks_render_only_when_real_matches_exist(tmp_path: Path) -> None:
    import fitz

    from audit_report.markdown import render_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["external_fact_checks"] = {
        "results": [
            {
                "claim_id": "claim-1",
                "status": "conflicting_reviews",
                "summary": "Trusted publishers reviewed closely related claims and disagreed.",
                "matches": [
                    {
                        "matched_claim_text": "The pilot reduced absences by 18 percent.",
                        "claimant": "Example district",
                        "claim_date": "2025-01-01",
                        "review": {
                            "publisher_name": "FactCheck.org",
                            "publisher_site": "factcheck.org",
                            "url": "https://factcheck.org/example",
                            "title": "Attendance pilot review",
                            "review_date": "2025-02-01",
                            "textual_rating": "Mostly True",
                            "language_code": "en",
                        },
                        "match_confidence": 0.75,
                    },
                    {
                        "matched_claim_text": "The pilot reduced absences by 18 percent.",
                        "claimant": "Example district",
                        "claim_date": "2025-01-01",
                        "review": {
                            "publisher_name": "PolitiFact",
                            "publisher_site": "politifact.com",
                            "url": "https://politifact.com/example",
                            "title": "Attendance pilot review",
                            "review_date": "2025-02-03",
                            "textual_rating": "False",
                            "language_code": "en",
                        },
                        "match_confidence": 0.75,
                    },
                ],
                "cautions": ["Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts."],
            }
        ]
    }

    payload = normalize_audit_data(data, normalize_options(data))
    markdown = render_markdown(payload)
    assert "## External Fact Checks" in markdown
    assert 'Publisher rating: "Mostly True"' in markdown
    assert 'Publisher rating: "False"' in markdown

    result = generate_audit_report(data, output_path=str(tmp_path / "external-fact-checks.pdf"))
    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert result["external_fact_checks"]["present"] is True
    assert "external_fact_checks" in result["artifact_viewer"]["sections"]

    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "External Fact Checks" in text
    assert "Mostly True" in text
    assert "False" in text


def test_external_fact_checks_no_placeholder_when_no_matches() -> None:
    from audit_report.markdown import render_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options
    from factcheck.tool import factcheck_lookup

    data = load_fixture("complete_report_ready")
    data["external_fact_checks"] = {"results": [{"claim_id": "claim-1", "status": "no_trusted_match", "matches": []}]}
    payload = normalize_audit_data(data, normalize_options(data))
    markdown = render_markdown(payload)
    assert payload["external_fact_checks"]["present"] is False
    assert "## External Fact Checks" not in markdown
    assert "No trusted external fact check found" not in markdown

    data["external_fact_checks"] = factcheck_lookup(
        [
            {
                "claim_id": "claim-1",
                "text": "The pilot reduced absences by 18 percent.",
                "claim_type": "factual",
                "is_factual": True,
                "verification_priority": "high",
            }
        ]
    )
    payload = normalize_audit_data(data, normalize_options(data))
    markdown = render_markdown(payload)
    assert payload["external_fact_checks"]["present"] is False
    assert "## External Fact Checks" not in markdown


def test_external_fact_check_alias_normalizes() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("complete_report_ready")
    data["factcheck_results"] = {
        "results": [
            {
                "claim_id": "claim-2",
                "status": "match_found",
                "matches": [
                    {
                        "matched_claim_text": "A reviewed factual claim.",
                        "review": {
                            "publisher_name": "Snopes",
                            "publisher_site": "snopes.com",
                            "url": "https://snopes.com/example",
                            "textual_rating": "True",
                        },
                        "match_confidence": 0.95,
                    }
                ],
            }
        ]
    }
    payload = normalize_audit_data(data, normalize_options(data))
    assert payload["external_fact_checks"]["present"] is True
    assert payload["external_fact_checks"]["results"][0]["claim_id"] == "claim-2"
    assert any(alias["field"] == "external_fact_checks" for alias in payload["diagnostics"]["aliases_used"])


def test_beta8_normalization_enforces_before_use_prefix_and_activity_fallback() -> None:
    from audit_report.markdown import render_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("complete_report_ready")
    data["critical_integrity_snapshot"]["before_using_this_text"] = "Before sharing your draft, verify the denominator."

    payload = normalize_audit_data(data, normalize_options(data))
    markdown = render_markdown(payload)

    assert payload["cis"]["before_using_this_text"].startswith("Before using this text,")
    assert payload["follow_up_activity"]["try_this_next"]["title"]
    assert payload["follow_up_activity"]["solo_activity"]["title"]
    assert payload["follow_up_activity"]["group_activity"]["title"]
    assert payload["follow_up_activity"]["fit_check"]["persistence"] == "non_persistent"
    assert payload["pressure_test_readiness_card"]["decision_action"] in {"Trust", "Revise", "Verify", "Reframe"}
    assert "## Follow-Up Activity" in markdown
    assert "## Audit Summary" in markdown
    assert "Solo Activity" in markdown
    assert "Group Activity" in markdown
    assert "After trying this activity, note what helped and what you would change." not in markdown


def test_beta8_full_report_renders_follow_up_activity(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    result = generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(tmp_path / "beta8-follow-up.pdf"),
    )

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert result["compiled_sections"]["follow_up_activity"] is True
    assert result["report_preflight_card"]["status"] == "ready"
    assert result["pressure_test_readiness_card"]["decision_action"] in {"Trust", "Revise", "Verify", "Reframe"}
    assert result["follow_up_activity"]["solo_activity"]["title"]
    assert result["follow_up_activity"]["group_activity"]["title"]
    assert "follow_up_activity" in result["artifact_viewer"]["sections"]
    assert "pressure_test_readiness_card" in result["artifact_viewer"]["sections"]

    markdown = Path(result["markdown_path"]).read_text(encoding="utf-8")
    assert "## Plain-Language Read" in markdown
    assert "## Before Using This Text" in markdown
    assert "Before using this text," not in markdown
    assert "## Audit Summary" in markdown
    assert "## Follow-Up Activity" in markdown
    assert "Activity reflection" not in markdown

    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Plain-Language Read" in text
    assert "Before Using This Text" in text
    assert "Audit Summary" in text
    assert "Follow-Up Activity" in text
    assert "SOLO" in text
    assert "GROUP" in text
    assert "Activity Reflection" not in text


def test_renderer_dependency_status_uses_python_module_when_cli_missing(monkeypatch) -> None:
    from audit_report import render

    monkeypatch.setattr(render.shutil, "which", lambda name: "")
    monkeypatch.setattr(render, "_weasyprint_module_available", lambda: (True, "module ok"))

    resolution = render.resolve_weasyprint_command()
    status = render.renderer_dependency_status()

    assert resolution["source"] == "python_module"
    assert "-m weasyprint" in resolution["command_display"]
    assert status["weasyprint_binary"]
    assert status["weasyprint_resolution_source"] == "python_module"


def test_validate_report_payload_dry_run_shares_schema_hash_and_writes_no_files(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report, validate_report_payload

    output = tmp_path / "dry-run.pdf"
    dry_run = validate_report_payload(load_fixture("complete_report_ready"), output_path=str(output))

    assert dry_run["qa_status"] == "preflight_passed"
    assert dry_run["writes_files"] is False
    assert dry_run["intended_report_path"] == str(output.resolve())
    assert dry_run["report_schema_hash"]
    assert not output.exists()

    rendered = generate_audit_report(load_fixture("complete_report_ready"), output_path=str(output))
    assert rendered["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert rendered["report_schema_hash"] == dry_run["report_schema_hash"]
    assert output.exists()


def test_generate_report_preflight_check_writes_no_files(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report

    output = tmp_path / "preflight.pdf"
    result = generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(output),
        preflight_check=True,
    )

    assert result["qa_status"] == "preflight_passed"
    assert result["preflight_check"] is True
    assert result["writes_files"] is False
    assert result["intended_report_path"] == str(output.resolve())
    assert result["markdown_path"] == ""
    assert not output.exists()


def test_validate_report_payload_schema_only_writes_no_files(tmp_path: Path) -> None:
    from audit_report.tool import validate_report_payload

    output = tmp_path / "schema-only.pdf"
    result = validate_report_payload({}, output_path=str(output), schema_only=True)

    assert result["status"] == "schema_only"
    assert result["writes_files"] is False
    assert result["report_schema_hash"]
    assert "cis_score" in result["accepted_aliases"]["cis.points"]
    assert "bias" in result["accepted_aliases"]["findings.biases[].name"]
    assert result["cis_bands"][0]["label"] == "Exemplary Integrity"
    required = set(result["required_field_checklist"])
    assert "critical_integrity_snapshot.dimensions[].rationale" in required
    assert "advanced_audit.dissent_ledger[].top_finding" in required
    assert "advanced_audit.dissent_ledger[].strongest_disagreement" in required
    assert "advanced_audit.dissent_ledger[].what_would_change_mind" in required
    assert result["consensus_null_state"]["required_companion_field"] == "consensus_note"
    assert not output.exists()


def test_report_contract_lists_dissent_and_dimension_rationale_requirements(tmp_path: Path) -> None:
    from audit_report.tool import validate_report_payload

    result = validate_report_payload({}, output_path=str(tmp_path / "schema.pdf"), schema_only=True)
    fields = "\n".join(result["required_field_checklist"])

    assert "critical_integrity_snapshot.dimensions[].rationale" in fields
    assert "advanced_audit.dissent_ledger[].top_finding" in fields
    assert "advanced_audit.dissent_ledger[].strongest_disagreement" in fields
    assert "advanced_audit.dissent_ledger[].what_would_change_mind" in fields
    assert result["consensus_null_state"]["rule"].startswith("Use this only when analysts genuinely agree")


def test_claude_natural_keys_normalize_and_low_score_never_trust() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("claude_schema_trust_regression")
    data["host_inference_heavy"] = True
    payload = normalize_audit_data(data, normalize_options(data))

    assert payload["cis"]["points"] == 36
    assert payload["cis"]["label"] == "Limited Integrity"
    assert payload["findings"]["biases"][0]["name"] == "Demand Characteristics"
    assert payload["pressure_test_readiness_card"]["decision_action"] != "Trust"
    fields = {item["field"] for item in payload["diagnostics"]["schema_warnings"]}
    assert "cis.label" in fields
    assert "findings.biases[].name" in fields
    assert any(item.get("suggested_value") for item in payload["diagnostics"]["schema_warnings"])


def test_low_cis_never_primary_action_trust() -> None:
    from audit_report.markdown import render_markdown, validate_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("claude_schema_trust_regression")
    data["host_inference_heavy"] = True
    payload = normalize_audit_data(data, normalize_options(data))
    assert payload["cis"]["points"] == 36
    assert payload["pressure_test_readiness_card"]["decision_action"] != "Trust"

    payload["pressure_test_readiness_card"]["decision_action"] = "Trust"
    markdown = render_markdown(payload)
    validation = validate_markdown(markdown, payload)

    assert validation["passed"] is False
    assert any(item["check"] == "markdown_primary_action_trust_contradiction" for item in validation["issues"])


def test_no_placeholder_strings_in_pdf_markdown_html(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    forbidden = [
        "No bias rows were supplied",
        "No explicit disagreement",
        "Name the evidence that would change this view",
        "Confidence: unknown",
        "KB grounding:",
        "Items without IDs",
        "File-O-Fun",
        "Knowledge Atlas",
        "host_inference",
        "needs_evidence",
        "not_ranked_for_truth",
    ]
    pdf_only_forbidden = ["Activity Reflection"]
    result = generate_audit_report(load_fixture("complete_report_ready"), output_path=str(tmp_path / "clean-render.pdf"))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    markdown = Path(result["markdown_path"]).read_text(encoding="utf-8")
    html = Path(result["viewer_path"]).read_text(encoding="utf-8")
    doc = fitz.open(result["report_path"])
    try:
        pdf_text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()

    for needle in forbidden:
        assert needle not in markdown
        assert needle not in pdf_text
        assert needle not in html
    for needle in pdf_only_forbidden:
        assert needle not in markdown
        assert needle not in pdf_text


def test_low_kb_grounding_blocks_advanced_report_without_override(tmp_path: Path) -> None:
    from audit_report.tool import validate_report_payload

    result = validate_report_payload(load_fixture("claude_schema_trust_regression"), output_path=str(tmp_path / "blocked.pdf"))

    assert result["qa_status"] == "blocked"
    assert result["normalization_diagnostics"]["kb_grounding_warning"]
    assert any(item["field"] == "kb_coverage_signal" for item in result["missing_report_fields"])


def test_consensus_dissent_null_state_renders_without_placeholders(tmp_path: Path) -> None:
    import fitz

    from audit_report.markdown import render_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.tool import generate_audit_report

    output = tmp_path / "consensus.pdf"
    data = load_fixture("advanced_consensus_report")
    payload = normalize_audit_data(data, normalize_options(data))
    markdown = render_markdown(payload)
    result = generate_audit_report(data, output_path=str(output))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert payload["advanced_audit"]["consensus_only"] is True
    assert "## Where the Analysts Reached Consensus" in markdown
    assert "## Where the Analysts Disagreed" not in markdown
    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Where the Analysts Reached Consensus" in text
    assert "Consensus note" in text
    assert "Strongest disagreement" not in text
    assert "No explicit disagreement" not in text
    assert "Name the evidence that would change this view" not in text
    assert "Confidence: unknown" not in text


def test_populated_dissent_renders_without_template_text(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["advanced_audit"] = {
        "present": True,
        "agents": [
            {
                "agent_name": "Methods reviewer",
                "top_finding": "The draft needs sharper evidence boundaries before it is shared.",
            }
        ],
        "dissent_ledger": [
            {
                "agent_name": "Methods reviewer",
                "top_finding": "The draft needs sharper evidence boundaries before it is shared.",
                "strongest_disagreement": "The text sounds more settled than the evidence can support.",
                "what_would_change_mind": "A revision that names the comparison evidence and counterexamples.",
                "confidence": "medium",
            }
        ],
    }

    result = generate_audit_report(data, output_path=str(tmp_path / "populated-dissent.pdf"))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Where the Analysts Disagreed" in text
    assert "The text sounds more settled than the evidence can support." in text
    assert "No explicit disagreement" not in text
    assert "Name the evidence that would change this view" not in text
    assert "Confidence: unknown" not in text


def test_absent_advanced_dissent_renders_without_placeholder_cards(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["advanced_audit"] = {
        "present": True,
        "agents": [
            {
                "agent_name": "Methods reviewer",
                "top_finding": "The draft needs sharper evidence boundaries before it is shared.",
            }
        ],
    }

    result = generate_audit_report(data, output_path=str(tmp_path / "no-dissent.pdf"))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    doc = fitz.open(result["report_path"])
    try:
        text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Analytical Lens Attribution" in text
    assert "Where the Analysts Disagreed" not in text
    assert "Where the Analysts Reached Consensus" not in text
    assert "No explicit disagreement" not in text
    assert "Name the evidence that would change this view" not in text


def test_render_pdf_falls_back_to_pymupdf_when_weasyprint_unavailable(monkeypatch, tmp_path: Path) -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.render import render_pdf
    from audit_report import render

    monkeypatch.setattr(
        render,
        "resolve_weasyprint_command",
        lambda explicit_binary=None: {
            "available": False,
            "source": "unavailable",
            "command": [],
            "command_display": "",
            "message": "test forced missing weasyprint",
        },
    )
    payload = normalize_audit_data(load_fixture("complete_report_ready"), normalize_options(load_fixture("complete_report_ready")))
    output = tmp_path / "fallback.pdf"

    render_pdf(payload, output)

    assert output.exists()
    assert payload["diagnostics"]["report_renderer"]["renderer"] == "pymupdf_fallback"
    assert "WeasyPrint did not render" in payload["diagnostics"]["report_renderer"]["message"]


def test_generate_report_renderer_failure_returns_preflight_card(monkeypatch, tmp_path: Path) -> None:
    from audit_report.models import ReportValidationError
    from audit_report import tool

    def fail_render(payload, output_path):  # noqa: ANN001
        raise ReportValidationError("WeasyPrint unavailable and PyMuPDF fallback unavailable.")

    monkeypatch.setattr(tool, "render_pdf", fail_render)

    result = tool.generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(tmp_path / "blocked-renderer.pdf"),
    )

    assert result["qa_status"] == "blocked"
    assert result["preflight_status"] == "pdf_render_failed"
    assert result["report_preflight_card"]["missing_fields"][0]["section"] == "Renderer"
    assert "renderer_status" in result["report_preflight_card"]
    assert result["report_path"] == ""
    assert result["viewer_path"] == ""
    assert Path(result["markdown_path"]).exists()
    assert result["markdown_hash"]
    assert Path(result["render_error_log_path"]).exists()
    assert "returned Markdown artifact" in result["report_preflight_card"]["top_fixes"][0]


def test_pdf_render_timeout_returns_markdown_path_and_error_log(monkeypatch, tmp_path: Path) -> None:
    from audit_report.models import ReportValidationError
    from audit_report import tool

    def fail_render(payload, output_path):  # noqa: ANN001
        raise ReportValidationError("PDF render timed out after 1 seconds.")

    monkeypatch.setattr(tool, "render_pdf", fail_render)

    result = tool.generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(tmp_path / "timeout-renderer.pdf"),
    )

    assert result["qa_status"] == "blocked"
    assert result["preflight_status"] == "pdf_render_failed"
    assert Path(result["markdown_path"]).exists()
    assert Path(result["render_error_log_path"]).read_text(encoding="utf-8").startswith("stage=pdf_render_failed")


def test_renderer_failure_preserves_markdown_path(monkeypatch, tmp_path: Path) -> None:
    from audit_report.models import ReportValidationError
    from audit_report import tool

    def fail_render(payload, output_path):  # noqa: ANN001
        raise ReportValidationError("Forced renderer failure for Markdown fallback test.")

    monkeypatch.setattr(tool, "render_pdf", fail_render)

    result = tool.generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(tmp_path / "renderer-failure.pdf"),
    )

    assert result["qa_status"] == "blocked"
    assert result["report_path"] == ""
    assert Path(result["markdown_path"]).exists()
    assert result["markdown_validation"]["passed"] is True


def test_pdf_qa_timeout_returns_markdown_path_and_error_log(monkeypatch, tmp_path: Path) -> None:
    from audit_report.models import ReportValidationError
    from audit_report import tool

    def fail_qa(report_path, payload, image_dir):  # noqa: ANN001
        raise ReportValidationError("PDF QA timed out after 1 seconds.")

    monkeypatch.setattr(tool, "qa_report_with_timeout", fail_qa)

    result = tool.generate_audit_report(
        load_fixture("complete_report_ready"),
        output_path=str(tmp_path / "qa-timeout.pdf"),
    )

    assert result["qa_status"] == "blocked"
    assert result["preflight_status"] == "pdf_qa_failed"
    assert result["report_path"] == ""
    assert result["viewer_path"] == ""
    assert Path(result["markdown_path"]).exists()
    assert result["markdown_hash"]
    assert Path(result["render_error_log_path"]).exists()


def test_follow_up_activity_aliases_normalize_to_canonical_full_cards() -> None:
    from audit_report.markdown import render_markdown, validate_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    data = load_fixture("complete_report_ready")
    data["follow_up_activity"] = {
        "try_next": {
            "title": "Claim-Support-Question",
            "why_this_fits": "This keeps the highest-stakes claim tied to visible support.",
            "content_focus": "Use the main impact claim and its evidence.",
        },
        "solo": {
            "title": "Reverse Outline Repair",
            "why_this_fits": "This helps one writer find structure gaps before sharing.",
            "steps": ["Mark the main claim.", "List each support point.", "Revise the weakest link."],
            "content_focus": "Use the paragraph with the broadest impact claim.",
            "thinking_focus": ["Critical", "Creative"],
            "source_note": "Curated from Critical Compass.",
        },
        "team_activity": {
            "title": "1-2-4-All Review",
            "why_this_fits": "This gives the group a fast way to surface missing voices.",
            "steps": ["Reflect alone first.", "Pair up and compare concerns.", "Choose one group revision."],
            "content_focus": "Use the passage naming community outcomes.",
            "thinking_focus": ["Compassionate", "Creative"],
            "source_note": "Curated from Critical Compass.",
        },
    }

    payload = normalize_audit_data(data, normalize_options(data))
    readiness = assess_report_readiness(payload)
    markdown = render_markdown(payload)
    validation = validate_markdown(markdown, payload)

    assert payload["follow_up_activity"]["solo_activity"]["title"] == "Reverse Outline Repair"
    assert payload["follow_up_activity"]["group_activity"]["title"] == "1-2-4-All Review"
    assert readiness["passed"] is True
    assert validation["passed"] is True


def test_thin_solo_activity_reports_exact_subfield() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    payload = normalize_audit_data(load_fixture("complete_report_ready"), normalize_options(load_fixture("complete_report_ready")))
    payload["follow_up_activity"]["solo_activity"]["steps"] = []

    readiness = assess_report_readiness(payload)
    fields = {item["field"] for item in readiness["missing_report_fields"]}

    assert readiness["passed"] is False
    assert "follow_up_activity.solo_activity.steps" in fields
    assert not any(field.startswith("follow_up_activity.solo.") for field in fields)


def test_markdown_validation_uses_canonical_activity_paths() -> None:
    from audit_report.markdown import render_markdown, validate_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options

    payload = normalize_audit_data(load_fixture("complete_report_ready"), normalize_options(load_fixture("complete_report_ready")))
    payload["follow_up_activity"]["solo_activity"]["title"] = "Unique Solo Canonical Title"
    markdown = render_markdown(payload).replace("Unique Solo Canonical Title", "")

    validation = validate_markdown(markdown, payload)
    fields = {item["field"] for item in validation["issues"]}

    assert "follow_up_activity.solo_activity.title" in fields
    assert not any(field.startswith("follow_up_activity.solo.") for field in fields)


def test_advanced_audit_aliases_normalize_without_dissent_field_churn() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    data = load_fixture("complete_report_ready")
    data["advanced_audit"] = {
        "present": True,
        "agents": [
            {
                "agent_name": "Methods reviewer",
                "primary_finding": "The evidence plan is useful, but the comparison group still needs proof.",
                "counterpoint": "The report is more actionable than the evidence currently warrants.",
                "confidence": "medium",
            }
        ],
        "dissent_ledger": [
            {
                "agent_name": "Methods reviewer",
                "key_finding": "The evidence plan is useful, but the comparison group still needs proof.",
                "counterpoint": "The report is more actionable than the evidence currently warrants.",
                "confidence": "medium",
                "what_would_change_your_mind": "A dataset showing baseline and follow-up attendance by group.",
            }
        ],
    }

    payload = normalize_audit_data(data, normalize_options(data))
    readiness = assess_report_readiness(payload)

    assert payload["advanced_audit"]["agents"][0]["top_finding"].startswith("The evidence plan")
    assert payload["advanced_audit"]["agents"][0]["strongest_disagreement"].startswith("The report is")
    assert payload["advanced_audit"]["dissent_ledger"][0]["strongest_disagreement"].startswith("The report is")
    assert readiness["passed"] is True


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def test_human_loop_prompt_contracts_and_silent_mode() -> None:
    install_fake_mcp_modules()
    sys.path.insert(0, str(ROOT))
    from server import build_human_loop  # pylint: disable=import-error,import-outside-toplevel

    guided = build_human_loop(
        stage="pre_audit",
        human_loop_mode="guided",
        human_loop_state=None,
        text_type="research",
        text_type_source="inferred",
        domain="research study/report",
        sensitivity="low",
        depth="standard",
        snapshot_mode="research",
        retrieval_profile="research_methodology",
        source_completeness="visible_text_only",
    )

    assert guided["state"]["audit_session_id"]
    assert guided["stage"] == "onboarding"
    assert guided["state"]["phase"] == "onboarding_pending"
    assert guided["pending_prompt_ids"] == [
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
    ]
    assert len(guided["prompts"]) == guided["question_budget"]["onboarding"]
    for prompt in guided["prompts"]:
        assert prompt["group_id"]
        assert prompt["batchable"] is True
        assert prompt["selection_mode"] in {"single", "multi"}
        assert prompt["max_selections"] >= 1
        assert "allow_free_text" in prompt
        assert prompt["why_i_am_asking"]
        assert prompt["what_this_can_change"]
        assert prompt["what_this_cannot_change"]
        assert prompt["on_skip"]["action"]

    silent = build_human_loop(
        stage="pre_audit",
        human_loop_mode="silent",
        human_loop_state=None,
        text_type="research",
        text_type_source="inferred",
        domain="research study/report",
        sensitivity="low",
        depth="standard",
        snapshot_mode="research",
        retrieval_profile="research_methodology",
        source_completeness="visible_text_only",
    )

    assert silent["prompts"] == []
    assert silent["pending_prompt_ids"] == []
    assert silent["assumption_disclosure"]
    assert any("silent" in item.lower() for item in silent["assumption_disclosure"])


def test_human_loop_verified_evidence_marks_rerun_and_commentary_does_not() -> None:
    install_fake_mcp_modules()
    sys.path.insert(0, str(ROOT))
    from server import build_human_loop  # pylint: disable=import-error,import-outside-toplevel

    commentary_state = {
        "audit_version": 1,
        "human_inputs": {
            "commentary": [{"bucket": "commentary", "content": "I disagree with finding two."}],
            "quarantined_opinions": [{"bucket": "quarantined_opinion", "content": "This feels biased."}],
        },
    }
    commentary = build_human_loop(
        stage="post_audit_reflection",
        human_loop_mode="guided",
        human_loop_state=commentary_state,
        text_type="advocacy",
        text_type_source="explicit",
        domain="advocacy",
        sensitivity="low",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="visible_text_only",
    )
    assert commentary["needs_rerun"] is False
    assert commentary["stale_sections"] == []

    evidence_state = {
        "audit_version": 1,
        "human_inputs": {
            "evidence": [
                {
                    "bucket": "evidence",
                    "evidence_class": "verified_evidence",
                    "content": "The full source paper was uploaded.",
                    "affects_sections": ["bias_map", "methodology_check"],
                    "requires_rerun": True,
                }
            ]
        },
    }
    evidence = build_human_loop(
        stage="pre_audit",
        human_loop_mode="minimal",
        human_loop_state=evidence_state,
        text_type="research",
        text_type_source="explicit",
        domain="research",
        sensitivity="low",
        depth="standard",
        snapshot_mode="research",
        retrieval_profile="research_methodology",
        source_completeness="visible_text_only",
    )
    assert evidence["needs_rerun"] is True
    assert evidence["state"]["phase"] == "evidence_rerun_required"
    assert evidence["state"]["rerun_marker"]["prior_audit_version"] == 1
    assert evidence["state"]["rerun_marker"]["next_audit_version"] == 2
    assert evidence["stale_sections"] == ["bias_map", "methodology_check"]


def test_human_commentary_report_sections_are_normalized() -> None:
    from audit_report.models import validate_payload
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("advanced_full")
    data["human_auditor_commentary"] = {
        "include_in_report": True,
        "user_role": "author",
        "commentary_text": "I agree with the evidence-gap concern, but this was a brainstorming draft.",
        "collected_after_stage": "findings_frozen",
        "collected_at": "2026-04-15T10:42:00Z",
        "ai_response_to_commentary": "The draft context changes report framing, but not the frozen evidence-gap finding.",
        "commentary_bucket": "commentary",
    }
    data["divergence_map"] = {
        "items": [
            {
                "topic": "Draft intent vs reader-facing evidence",
                "type": "scope/framing",
                "ai_audit_position": "The text makes claims without enough visible support.",
                "human_auditor_position": "The text was exploratory.",
                "resolution": "Keep the finding, but label the report as draft coaching.",
            }
        ]
    }
    data["learning_notes"] = ["Framing effect matters because wording can make one interpretation feel natural."]
    data["human_loop_state"] = {"audit_version": 2, "findings_frozen_at": "2026-04-15T10:38:00Z"}

    payload = normalize_audit_data(data, normalize_options(data))
    validate_payload(payload)

    assert payload["human_auditor_commentary"]["present"] is True
    assert payload["divergence_map"]["present"] is True
    assert payload["learning_notes"]
    assert payload["provenance_footer"]["present"] is True
    assert payload["provenance_footer"]["audit_version"] == 2


def test_human_commentary_report_sections_render() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.render import render_html

    data = load_fixture("advanced_full")
    data["human_auditor_commentary"] = {
        "include_in_report": True,
        "user_role": "reviewer",
        "commentary_text": "The finding is fair, but the source was a rough draft.",
        "collected_after_stage": "findings_frozen",
        "collected_at": "2026-04-15T10:42:00Z",
        "ai_response_to_commentary": "The draft context changes report framing, not the frozen finding.",
        "commentary_bucket": "commentary",
    }
    data["divergence_map"] = {
        "items": [
            {
                "topic": "Draft intent vs evidence",
                "type": "scope/framing",
                "ai_audit_position": "The text needs clearer support.",
                "human_auditor_position": "The text was exploratory.",
                "resolution": "Keep finding and label the report as draft coaching.",
            }
        ]
    }
    data["learning_notes"] = ["Framing effect can make one interpretation feel natural."]
    data["human_loop_state"] = {"audit_version": 2, "findings_frozen_at": "2026-04-15T10:38:00Z"}

    payload = normalize_audit_data(data, normalize_options(data))
    html = render_html(payload, "full_report.html")

    assert "Human Auditor Commentary" in html
    assert "Human-AI Divergence Map" in html
    assert "Draft intent vs evidence" in html
    assert "Framing effect can make one interpretation feel natural." in html


def test_human_commentary_can_be_omitted_from_report() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("advanced_full")
    data["human_auditor_commentary"] = {
        "include_in_report": False,
        "commentary_text": "Do not render this.",
    }

    payload = normalize_audit_data(data, normalize_options(data))

    assert payload["human_auditor_commentary"]["present"] is False


def test_alias_regression_hydrates_report_fields() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    payload = normalize_audit_data(load_fixture("alias_regression"), normalize_options(load_fixture("alias_regression")))
    assert payload["cis"]["plain_language_read"].startswith("The study is useful")
    assert [dimension["points"] for dimension in payload["cis"]["dimensions"]] == [18, 14, 14, 15, 13]
    assert "laboratory procedure" in payload["cis"]["dimensions"][0]["improvement_prompt"]
    assert payload["findings"]["biases"][0]["name"] == "Demand Characteristics"
    assert payload["findings"]["key_tension"].startswith("The procedure may create genuine closeness")
    assert payload["advanced_audit"]["agents"][0]["top_finding"].startswith("The strongest threat")
    assert not payload["diagnostics"]["schema_warnings"]


def test_reasoning_artifacts_normalize_into_report_payload() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = load_fixture("complete_report_ready")
    payload = normalize_audit_data(data, normalize_options(data))

    assert payload["argument_map"]["central_claim"]
    assert payload["argument_map"]["markdown"].startswith("# Argument Map")
    assert payload["argument_map"]["argdown"]
    assert payload["checkworthy_claims"]["claims"]
    assert all("not false" in item["not_false_notice"].lower() for item in payload["checkworthy_claims"]["claims"])
    assert all(
        item["verification_priority"] == "not_ranked"
        for item in payload["checkworthy_claims"]["claims"]
        if not item["is_factual"]
    )
    assert payload["reasoning_traps"]


def test_reasoning_artifact_sections_render_in_full_report_html() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.render import render_html

    data = load_fixture("complete_report_ready")
    payload = normalize_audit_data(data, normalize_options(data))
    html = render_html(payload, "full_report.html")

    assert "Argument Map" in html
    assert "Evidence Needed Next" in html
    assert "Check-worthy means worth verifying, not false" in html
    assert "Reasoning Trap Checks" in html


def test_missing_fields_emit_schema_warnings() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    payload = normalize_audit_data(load_fixture("missing_fields"), normalize_options(load_fixture("missing_fields")))
    fields = {item["field"] for item in payload["diagnostics"]["missing_report_fields"]}
    assert "cis.plain_language_read" in fields
    assert "cis.dimensions[].improvement_prompt" in fields
    assert "advanced_audit.agents[].top_finding" in fields


def test_readiness_blocks_incomplete_full_report() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    payload = normalize_audit_data(load_fixture("failed_v2_incomplete_report"), normalize_options(load_fixture("failed_v2_incomplete_report")))
    readiness = assess_report_readiness(payload)
    fields = {item["field"] for item in readiness["missing_report_fields"]}

    assert readiness["passed"] is False
    assert readiness["preflight_status"] == "blocked_missing_fields"
    assert readiness["report_preflight_card"]["status"] == "needs_resubmission"
    assert readiness["report_preflight_card"]["top_fixes"]
    assert "Please re-submit report-ready audit_data" in readiness["report_preflight_card"]["paste_ready_resubmit_prompt"]
    assert "cis.before_using_this_text" in fields
    assert "assumptions" in fields
    assert "alternative_frames" in fields
    assert "questions.probing_or_follow_up" in fields
    assert "next_steps" in fields
    assert all(item not in readiness["what_to_resubmit"] for item in ["1", "2", "3"])


def test_generate_blocks_incomplete_report_before_files(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report

    output = tmp_path / "failed.pdf"
    result = generate_audit_report(load_fixture("failed_v2_incomplete_report"), output_path=str(output))

    assert result["qa_status"] == "blocked"
    assert result["preflight_status"] == "blocked_missing_fields"
    assert result["report_preflight_card"]["status"] == "needs_resubmission"
    assert result["report_preflight_card"]["top_fixes"]
    assert result["report_path"] == ""
    assert result["markdown_path"] == ""
    assert not output.exists()


def test_placeholder_override_renders_as_draft(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report

    output = tmp_path / "placeholder.pdf"
    result = generate_audit_report(load_fixture("placeholder_override"), output_path=str(output), allow_placeholders=True)

    assert result["preflight_status"] == "placeholder_override"
    assert result["qa_status"] in {"passed_with_cosmetic_issues", "blocked"}
    if result["qa_status"] != "blocked":
        assert output.exists()
        assert Path(result["markdown_path"]).exists()


def test_markdown_contract_validates_complete_fixture(tmp_path: Path) -> None:
    from audit_report.markdown import validate_markdown, write_markdown_report
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    payload = normalize_audit_data(load_fixture("complete_report_ready"), normalize_options(load_fixture("complete_report_ready")))
    readiness = assess_report_readiness(payload)
    markdown = write_markdown_report(payload, tmp_path / "complete.pdf")
    validation = validate_markdown(markdown["markdown"], payload)

    assert readiness["passed"] is True
    assert Path(markdown["markdown_path"]).exists()
    assert markdown["markdown_hash"]
    assert validation["passed"] is True


def test_long_sentence_caps_emit_schema_warnings() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    payload = normalize_audit_data(load_fixture("long_sentence_caps"), normalize_options(load_fixture("long_sentence_caps")))
    fields = {item["field"] for item in payload["diagnostics"]["schema_warnings"]}

    assert "cis.plain_language_read" in fields
    assert "cis.before_using_this_text" in fields
    assert assess_report_readiness(payload)["passed"] is True


def test_table_overlap_fixture_hydrates_aliases() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    payload = normalize_audit_data(load_fixture("table_overlap"), normalize_options(load_fixture("table_overlap")))
    assert payload["cis"]["plain_language_read"].startswith("The text is generally reliable")
    assert len(payload["findings"]["biases"]) == 5
    assert payload["findings"]["biases"][0]["kb_id"] == "ct:methodology:overgeneralization"
    assert payload["findings"]["biases"][0]["name"] == "Overgeneralization"
    assert payload["findings"]["biases"][0]["passage"] == "creating closeness in an experimental context"


def test_generated_report_renders_checkworthy_evidence_plan_fields(tmp_path: Path) -> None:
    import fitz

    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["checkworthy_claims"] = {
        "claims": [
            {
                "claim": "Navigation support improved clinic attendance by 18 percent.",
                "claim_type": "factual",
                "verification_priority": "high",
                "why_check": "This is the highest-stakes impact claim in the report.",
                "evidence_needed": "Attendance dataset, baseline rate, and comparison group definition.",
                "source_anchor": "outcomes section",
                "confidence": "medium",
                "suggested_queries": [
                    "navigation support clinic attendance 18 percent comparison group",
                    "community health navigation attendance baseline dataset",
                ],
                "likely_source_types": [
                    "program evaluation dataset",
                    "methods appendix",
                    "clinic attendance records",
                ],
                "support_contrast_status": "needs_source",
                "uncertainty_note": "The audit has not verified this claim externally.",
            }
        ]
    }
    output = tmp_path / "evidence-plan.pdf"

    result = generate_audit_report(data, output_path=str(output))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert output.exists()
    assert Path(result["markdown_path"]).exists()
    assert Path(result["argdown_path"]).exists()
    assert result["page_image_paths"]
    assert Path(result["preview_image_path"]).exists()

    markdown = Path(result["markdown_path"]).read_text(encoding="utf-8")
    assert "Suggested Queries" in markdown
    assert "Likely Source Types" in markdown
    assert "Support/Contrast Status" in markdown
    assert "Uncertainty Note" in markdown

    doc = fitz.open(output)
    try:
        pdf_text = "\n".join(page.get_text("text") for page in doc)
    finally:
        doc.close()
    assert "Suggested queries" in pdf_text
    assert "LIKELY" in pdf_text
    assert "SOURCES" in pdf_text
    assert "Support/contrast" in pdf_text
    assert "Uncertainty" in pdf_text


def test_generated_report_writes_read_only_artifact_viewer(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report
    from audit_report.viewer import generate_audit_artifact_viewer

    output = tmp_path / "viewer-report.pdf"
    data = load_fixture("complete_report_ready")
    data["advanced_audit"] = {
        "present": True,
        "agents": [
            {
                "name": "Methods reviewer",
                "reasoning_style": "evidence review",
                "top_finding": "The evidence plan is useful, but the comparison group still needs proof.",
            }
        ],
        "dissent_ledger": [
            {
                "agent": "Methods reviewer",
                "top_finding": "The evidence plan is useful, but the comparison group still needs proof.",
                "strongest_disagreement": "The report is more actionable than the evidence currently warrants.",
                "confidence": "medium",
                "what_would_change_its_mind": "A dataset showing baseline and follow-up attendance by group.",
            }
        ],
    }
    result = generate_audit_report(data, output_path=str(output))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert Path(result["manifest_path"]).exists()
    assert Path(result["viewer_path"]).exists()
    assert result["artifact_viewer"]["status"] == "ready"
    assert "argument_map" in result["artifact_viewer"]["sections"]
    assert "checkworthy_claims" in result["artifact_viewer"]["sections"]
    assert result["save_audit_result_link"]["result_payload"]["viewer_path"] == result["viewer_path"]

    html = Path(result["viewer_path"]).read_text(encoding="utf-8")
    assert "Read-only Critical Compass artifact viewer" in html
    assert "Argument Map" in html
    assert "Evidence Needed Next" in html
    assert "Where the Analysts Disagreed" in html
    assert "No external lookup is run by this viewer" in html

    rerender = generate_audit_artifact_viewer(result["manifest_path"], output_path=str(tmp_path / "manual-viewer.html"))
    assert rerender["status"] == "ready"
    assert Path(rerender["viewer_path"]).exists()


def test_pdf_text_matcher_tolerates_line_break_hyphenation() -> None:
    from audit_report.qa import _text_contains

    extracted = "Use the procedure as a bounded research tool and foreground sample, setting, and follow-\nup limits before applying it elsewhere."
    expected = "Use the procedure as a bounded research tool and foreground sample, setting, and follow-up limits before applying it elsewhere."

    assert _text_contains(extracted, expected)


def test_prepare_audit_source_rejects_non_pdf(tmp_path: Path) -> None:
    from audit_report.source import prepare_audit_source

    source = tmp_path / "source.txt"
    source.write_text("Not a PDF", encoding="utf-8")
    result = prepare_audit_source(str(source), output_dir=str(tmp_path / "out"))
    assert result["status"] == "blocked"
    assert result["warnings"][0]["code"] == "unsupported_source"


def test_prepare_audit_source_persists_trust_preflight(tmp_path: Path) -> None:
    import fitz

    from audit_report.source import prepare_audit_source

    pdf_path = tmp_path / "source.pdf"
    doc = fitz.open()
    page = doc.new_page()
    for index in range(24):
        page.insert_text((72, 72 + index * 20), f"This local source line {index} has enough words for embedded text extraction and trust preflight checks.")
    doc.save(pdf_path)
    doc.close()

    result = prepare_audit_source(str(pdf_path), output_dir=str(tmp_path / "out"), include_page_images=False)

    assert result["status"] == "ready"
    assert result["trust_summary"]["status"] == "ready"
    assert result["source_tool_trust_preflight"]["consent_boundaries"]["external_retrieval_allowed"] is False
    assert Path(result["trust_preflight_path"]).exists()


def test_report_result_includes_trust_summary_and_metadata(tmp_path: Path) -> None:
    from audit_report.tool import generate_audit_report

    data = load_fixture("complete_report_ready")
    data["source_tool_trust_preflight"] = load_fixture("source_trust_safe")
    output = tmp_path / "trust-report.pdf"

    result = generate_audit_report(data, output_path=str(output))

    assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}
    assert result["trust_summary"]["status"] == "ready"
    assert result["trust_summary"]["external_retrieval_allowed"] is False
    assert result["source_tool_trust_preflight"]["status"] == "ready"
    assert result["save_audit_result_link"]["result_payload"]["trust_summary"]["status"] == "ready"
    markdown = Path(result["markdown_path"]).read_text(encoding="utf-8")
    assert "## Source And Tool Trust Preflight" in markdown
    assert "External Retrieval Allowed" in markdown
