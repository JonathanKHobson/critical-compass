from __future__ import annotations

import json
from pathlib import Path

import pytest

import factcheck.config as config_module
import factcheck.providers as providers_module
from factcheck.allowlist import load_allowlist
from factcheck.local_index import LocalClaimReviewIndexProvider, build_claimreview_index
from factcheck.providers import (
    BraveSearchProvider,
    GoogleFactCheckToolsProvider,
    KeylessPublisherSearchProvider,
    ProviderError,
    PublisherClaimReviewHarvesterProvider,
)
from factcheck.tool import factcheck_lookup, _provider


class FakeProvider:
    provider_name = "google_fact_check_tools"

    def __init__(self, responses: dict[str, dict] | None = None, error: ProviderError | None = None):
        self.responses = responses or {}
        self.error = error
        self.calls: list[tuple[str, str]] = []

    def search(self, claim_text, options):
        self.calls.append((claim_text, options.publisher_site))
        if self.error:
            raise self.error
        return self.responses.get(options.publisher_site, {"claims": []})


def google_payload(
    *,
    claim_text: str = "The city reduced bus fares by 25 percent in 2024.",
    publisher: str = "FactCheck.org",
    site: str = "factcheck.org",
    rating: str = "Mostly True",
    review_date: str = "2025-01-10",
    url: str = "https://factcheck.org/example",
) -> dict:
    return {
        "claims": [
            {
                "text": claim_text,
                "claimant": "Example claimant",
                "claimDate": "2024-12-01",
                "claimReview": [
                    {
                        "publisher": {"name": publisher, "site": site},
                        "url": url,
                        "title": "Review of the bus fare claim",
                        "reviewDate": review_date,
                        "textualRating": rating,
                        "languageCode": "en",
                    }
                ],
            }
        ]
    }


@pytest.fixture(autouse=True)
def isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("CRITICAL_COMPASS_FACTCHECK_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.setenv("CRITICAL_COMPASS_FACTCHECK_CACHE_ENABLED", "true")
    monkeypatch.setenv("CRITICAL_COMPASS_FACTCHECK_CACHE_TTL_SECONDS", "86400")


def factual_claim(text: str = "The city reduced bus fares by 25 percent in 2024.", **extra):
    data = {
        "claim_id": "c1",
        "text": text,
        "claim_type": "factual",
        "is_factual": True,
        "verification_priority": "high",
    }
    data.update(extra)
    return data


def caution_codes(result: dict) -> set[str]:
    return {item.get("code") for item in result.get("cautions", []) if isinstance(item, dict)}


def test_default_guided_research_scaffold_does_not_retrieve() -> None:
    result = factcheck_lookup([factual_claim("Prairie dogs communicate danger information through alarm calls.")])

    assert result["status"] == "scaffold_ready"
    assert result["mode"] == "guided_research"
    assert result["lookup_performed"] is False
    assert result["results"][0]["status"] == "scaffold_only"
    assert result["epistemic_framing"][0]["domain"] == "animal_communication"
    assert result["epistemic_framing"][0]["domain_sensitivity"] == "high"
    assert "domain_sensitivity_high" in caution_codes(result)
    assert result["evidence_trail_template"][0]["evidence_rows"] == []


def test_auto_provider_is_loudly_deprecated_to_guided_research() -> None:
    result = factcheck_lookup([factual_claim()], provider="auto")

    assert result["mode"] == "guided_research"
    assert result["lookup_performed"] is False
    assert "provider_auto_deprecated" in caution_codes(result)
    assert any(item.get("code") == "provider_auto_deprecated" for item in result["warnings"])
    assert any("DEPRECATED" in note for note in result["provider_notes"])


def test_epistemic_framing_distinguishes_sensitive_domains_from_simple_statistics() -> None:
    result = factcheck_lookup(
        [
            factual_claim("Traditional ecological knowledge improved controlled burn practices.", claim_id="ecology"),
            factual_claim("The city's GDP increased by 2 percent in 2024.", claim_id="gdp"),
        ]
    )
    framing = {item["claim_id"]: item for item in result["epistemic_framing"]}

    assert framing["ecology"]["domain_sensitivity"] == "high"
    assert framing["ecology"]["known_western_bias_history"] == "documented"
    assert framing["gdp"]["domain_sensitivity"] == "low"
    assert framing["gdp"]["known_western_bias_history"] == "none_known"


def test_sensitive_guided_research_queries_are_redacted() -> None:
    result = factcheck_lookup([factual_claim("John Smith was fired for stealing from his employer.")])
    query_text = " ".join(query["query"] for query in result["suggested_queries"][0]["queries"])

    assert "John Smith" not in query_text
    assert "privacy-sensitive" in query_text
    assert "private_or_sensitive_claim" in caution_codes(result)


def test_allow_external_calls_false_blocks_lookup() -> None:
    provider = FakeProvider({"factcheck.org": google_payload()})
    result = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org"], allow_external_calls=False, provider_client=provider)
    assert result["status"] == "blocked"
    assert result["results"][0]["status"] == "provider_error"
    assert provider.calls == []


def test_exact_match_from_single_approved_publisher() -> None:
    provider = FakeProvider({"factcheck.org": google_payload()})
    result = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org"], allow_external_calls=True, provider_client=provider)
    first = result["results"][0]
    assert result["trusted_publishers"]["mode"] == "single_org"
    assert first["status"] == "match_found"
    assert first["matches"][0]["match_confidence"] == 0.95
    assert first["matches"][0]["review"]["textual_rating"] == "Mostly True"


def test_paraphrased_claim_gets_near_match_confidence() -> None:
    provider = FakeProvider(
        {
            "factcheck.org": google_payload(
                claim_text="The city cut bus fares by 25 percent during 2024."
            )
        }
    )
    result = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org"], allow_external_calls=True, provider_client=provider)
    assert result["results"][0]["matches"][0]["match_confidence"] == 0.75


def test_multiple_trusted_matches_without_conflict() -> None:
    provider = FakeProvider(
        {
            "factcheck.org": google_payload(rating="Mostly True"),
            "politifact.com": google_payload(publisher="PolitiFact", site="politifact.com", rating="Mostly True", url="https://politifact.com/example"),
        }
    )
    result = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org", "politifact.com"], allow_external_calls=True, provider_client=provider)
    assert result["trusted_publishers"]["mode"] == "multi_source"
    assert result["results"][0]["status"] == "multiple_matches"
    assert len(result["results"][0]["matches"]) == 2


def test_conflicting_publisher_ratings_are_preserved() -> None:
    provider = FakeProvider(
        {
            "factcheck.org": google_payload(rating="Mostly True"),
            "politifact.com": google_payload(publisher="PolitiFact", site="politifact.com", rating="False", url="https://politifact.com/example"),
        }
    )
    result = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org", "politifact.com"], allow_external_calls=True, provider_client=provider)
    assert result["results"][0]["status"] == "conflicting_reviews"
    assert any("truth score" in item.get("message", "") for item in result["results"][0]["cautions"])


def test_no_match_and_outdated_review_are_explicit() -> None:
    no_match = factcheck_lookup([factual_claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org"], allow_external_calls=True, provider_client=FakeProvider({"factcheck.org": {"claims": []}}))
    assert no_match["results"][0]["status"] == "no_trusted_match"

    outdated = factcheck_lookup(
        [factual_claim()],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        max_age_days=1,
        allow_external_calls=True,
        provider_client=FakeProvider({"factcheck.org": google_payload(review_date="2000-01-01")}),
    )
    assert outdated["results"][0]["status"] == "no_trusted_match"
    assert any("outdated" in note for note in outdated["results"][0]["provider_notes"])


def test_local_claimreview_index_builds_and_searches_without_external_calls(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "claimreview-source.json"
    index_path = tmp_path / "claimreview-index.json"
    source.write_text(
        json.dumps(
            {
                "claims": [
                    {
                        "text": "The city reduced bus fares by 25 percent in 2024.",
                        "claimant": "Example claimant",
                        "claimDate": "2024-12-01",
                        "claimReview": [
                            {
                                "publisher": {"name": "FactCheck.org", "site": "factcheck.org"},
                                "url": "https://factcheck.org/local-fixture",
                                "title": "Local review of the bus fare claim",
                                "reviewDate": "2025-01-10",
                                "textualRating": "Mostly True",
                                "languageCode": "en",
                            }
                        ],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    built = build_claimreview_index(source, index_path)
    monkeypatch.setenv("CRITICAL_COMPASS_CLAIMREVIEW_INDEX_PATH", str(index_path))

    result = factcheck_lookup([factual_claim()], provider="local_claimreview", publisher_sites=["factcheck.org"])

    assert built["record_count"] == 1
    assert result["mode"] == "local_retrieval"
    assert result["lookup_performed"] is True
    assert result["privacy"]["minimum_data_sent"] == []
    assert result["results"][0]["status"] == "match_found"
    assert result["results"][0]["matches"][0]["review"]["url"] == "https://factcheck.org/local-fixture"


def test_publisher_harvest_parses_claimreview_markup_with_explicit_external_permission(monkeypatch: pytest.MonkeyPatch) -> None:
    search_html = '<html><body><a href="https://www.factcheck.org/review/example">review</a></body></html>'
    page_html = """
    <html><head><title>Review</title>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ClaimReview",
      "claimReviewed": "The city reduced bus fares by 25 percent in 2024.",
      "author": {"@type": "Organization", "name": "FactCheck.org", "url": "https://www.factcheck.org"},
      "url": "https://www.factcheck.org/review/example",
      "headline": "Review of the bus fare claim",
      "datePublished": "2025-01-10",
      "reviewRating": {"@type": "Rating", "alternateName": "Mostly True"}
    }
    </script></head><body></body></html>
    """

    def fake_fetch(url: str, _timeout: int) -> str:
        return search_html if "/search/" in url else page_html

    monkeypatch.setattr(providers_module, "_fetch_text", fake_fetch)
    blocked = factcheck_lookup([factual_claim()], provider="publisher_harvest", publisher_sites=["factcheck.org"])
    result = factcheck_lookup([factual_claim()], provider="publisher_harvest", publisher_sites=["factcheck.org"], allow_external_calls=True)

    assert blocked["status"] == "blocked"
    assert result["provider"] == "publisher_harvest"
    assert result["mode"] == "provider_retrieval"
    assert result["results"][0]["status"] == "match_found"
    assert result["results"][0]["matches"][0]["review"]["textual_rating"] == "Mostly True"
    assert result["results"][0]["matches"][0]["review"]["source_metadata"]["source_class"] == "fact_check_publisher_direct"


def test_trusted_publisher_registry_has_source_metadata() -> None:
    allowlist = load_allowlist()

    assert "africacheck.org" in allowlist["active_sites"]
    for publisher in allowlist["publishers"]:
        if publisher["status"] != "active":
            continue
        assert publisher.get("source_class")
        assert publisher.get("regions")
        assert publisher.get("languages")


def test_provider_error_and_malformed_response_are_graceful() -> None:
    provider_error = factcheck_lookup(
        [factual_claim()],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        allow_external_calls=True,
        provider_client=FakeProvider(error=ProviderError("rate_limited", "Provider rate limit.")),
    )
    assert provider_error["results"][0]["status"] == "provider_error"
    assert provider_error["results"][0]["provider_notes"] == ["rate_limited"]

    malformed = factcheck_lookup(
        [factual_claim()],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        allow_external_calls=True,
        provider_client=FakeProvider({"factcheck.org": {"unexpected": []}}),
    )
    assert malformed["results"][0]["status"] == "no_trusted_match"
    assert any("claims array" in note for note in malformed["results"][0]["provider_notes"])


def test_non_factual_and_sensitive_claims_are_not_sent() -> None:
    provider = FakeProvider({"factcheck.org": google_payload()})
    non_factual = factcheck_lookup(
        [{"claim_id": "n1", "text": "This policy is unfair.", "claim_type": "normative", "verification_priority": "not_ranked"}],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        allow_external_calls=True,
        provider_client=provider,
    )
    assert non_factual["results"][0]["status"] == "no_trusted_match"
    assert provider.calls == []

    sensitive = factcheck_lookup(
        [factual_claim("John Smith was fired for stealing from his employer.")],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        allow_external_calls=True,
        provider_client=provider,
    )
    assert sensitive["results"][0]["status"] == "sensitive_blocked"
    assert provider.calls == []


def test_sensitive_override_runs_without_cache() -> None:
    provider = FakeProvider({"factcheck.org": google_payload(claim_text="John Smith was fired for stealing from his employer.")})
    result = factcheck_lookup(
        [factual_claim("John Smith was fired for stealing from his employer.")],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org"],
        allow_external_calls=True,
        allow_sensitive_claims=True,
        provider_client=provider,
    )
    assert result["results"][0]["status"] == "match_found"
    assert result["cache"]["writes"] == 0
    assert result["cache"]["bypassed_sensitive"] == 1
    assert any("not cached" in item.get("message", "") for item in result["results"][0]["cautions"])


def test_unapproved_publishers_are_filtered_and_cache_hits() -> None:
    provider = FakeProvider({"factcheck.org": google_payload()})
    first = factcheck_lookup(
        [factual_claim()],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org", "unknown.example"],
        allow_external_calls=True,
        provider_client=provider,
    )
    second = factcheck_lookup(
        [factual_claim()],
        provider="google_fact_check_tools",
        publisher_sites=["factcheck.org", "unknown.example"],
        allow_external_calls=True,
        provider_client=provider,
    )
    assert first["trusted_publishers"]["approved_sites"] == ["factcheck.org"]
    assert first["trusted_publishers"]["rejected_sites"] == ["unknown.example"]
    assert second["cache"]["hits"] == 1
    assert provider.calls == [("The city reduced bus fares by 25 percent in 2024.", "factcheck.org")]


def test_explicit_provider_factory_supports_experimental_providers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GOOGLE_FACT_CHECK_API_KEY", raising=False)
    monkeypatch.delenv("BRAVE_SEARCH_API_KEY", raising=False)
    monkeypatch.setattr(config_module, "DEFAULT_LOCAL_ENV", tmp_path / "local.env")
    monkeypatch.setattr(config_module, "DEFAULT_USER_ENV", tmp_path / "user.env")
    monkeypatch.setenv("CRITICAL_COMPASS_FACTCHECK_ENV_PATH", str(tmp_path / "missing.env"))

    assert isinstance(_provider("publisher_site_search"), KeylessPublisherSearchProvider)
    assert isinstance(_provider("local_claimreview"), LocalClaimReviewIndexProvider)
    assert isinstance(_provider("publisher_harvest"), PublisherClaimReviewHarvesterProvider)
    assert isinstance(_provider("brave_search"), BraveSearchProvider)
    assert isinstance(_provider("google_fact_check_tools"), GoogleFactCheckToolsProvider)
    with pytest.raises(ProviderError):
        _provider("auto")


def test_explicit_keyless_provider_is_supported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GOOGLE_FACT_CHECK_API_KEY", raising=False)
    monkeypatch.delenv("BRAVE_SEARCH_API_KEY", raising=False)
    assert isinstance(_provider("publisher_site_search"), KeylessPublisherSearchProvider)
