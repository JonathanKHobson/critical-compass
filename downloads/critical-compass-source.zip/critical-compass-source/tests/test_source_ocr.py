from __future__ import annotations

from pathlib import Path


LONG_OCR_TEXT = " ".join(f"recognized source word {index}" for index in range(120))


def make_blank_pdf(path: Path) -> Path:
    import fitz

    doc = fitz.open()
    doc.new_page()
    doc.save(path)
    doc.close()
    return path


def test_prepare_audit_source_prefers_apple_vision_when_available(tmp_path, monkeypatch) -> None:
    from audit_report import source

    pdf_path = make_blank_pdf(tmp_path / "scan.pdf")
    monkeypatch.setattr(source, "_load_apple_vision", lambda: ("vision",))
    monkeypatch.setattr(source, "_load_tesseract", lambda: ("tesseract", "5.3", "/usr/bin/tesseract"))
    monkeypatch.setattr(source, "_ocr_page_images", lambda image_paths, provider, language_code=None: (LONG_OCR_TEXT, []))

    result = source.prepare_audit_source(str(pdf_path), output_dir=str(tmp_path / "out"))

    assert result["status"] == "ready"
    assert result["ocr_used"] is True
    assert result["ocr_provider"] == "apple_vision"
    assert result["available_ocr_providers"] == ["apple_vision", "tesseract"]
    assert result["extraction_method"] == "apple_vision_ocr"
    assert result["ocr_language"] == "eng"


def test_prepare_audit_source_falls_back_to_tesseract(tmp_path, monkeypatch) -> None:
    from audit_report import source

    pdf_path = make_blank_pdf(tmp_path / "scan.pdf")
    monkeypatch.setattr(source, "_load_apple_vision", lambda: None)
    monkeypatch.setattr(source, "_load_tesseract", lambda: ("tesseract", "5.3", "/usr/bin/tesseract"))
    monkeypatch.setattr(source, "_ocr_page_images", lambda image_paths, provider, language_code=None: (LONG_OCR_TEXT, []))

    result = source.prepare_audit_source(str(pdf_path), output_dir=str(tmp_path / "out"))

    assert result["status"] == "ready"
    assert result["ocr_provider"] == "tesseract"
    assert result["available_ocr_providers"] == ["tesseract"]
    assert result["extraction_method"] == "tesseract_ocr"
    assert "tesseract" in result["source_tool_trust_preflight"]["source_provenance"]["ocr_provider"]


def test_prepare_audit_source_blocks_when_no_ocr_provider_is_available(tmp_path, monkeypatch) -> None:
    from audit_report import source

    pdf_path = make_blank_pdf(tmp_path / "scan.pdf")
    monkeypatch.setattr(source, "_load_apple_vision", lambda: None)
    monkeypatch.setattr(source, "_load_tesseract", lambda: None)

    result = source.prepare_audit_source(str(pdf_path), output_dir=str(tmp_path / "out"))

    assert result["status"] == "needs_ocr_dependency"
    assert result["ocr_used"] is False
    assert result["available_ocr_providers"] == []
    assert "tesseract" in result["ocr_dependency_guidance"]["tesseract"]
    assert {warning["code"] for warning in result["warnings"]} == {"missing_ocr_provider"}


def test_prepare_audit_source_blocks_when_requested_provider_is_unavailable(tmp_path, monkeypatch) -> None:
    from audit_report import source

    pdf_path = make_blank_pdf(tmp_path / "scan.pdf")
    monkeypatch.setattr(source, "_load_apple_vision", lambda: None)
    monkeypatch.setattr(source, "_load_tesseract", lambda: ("tesseract", "5.3", "/usr/bin/tesseract"))

    result = source.prepare_audit_source(str(pdf_path), ocr_provider="apple_vision", output_dir=str(tmp_path / "out"))

    assert result["status"] == "needs_ocr_dependency"
    assert result["available_ocr_providers"] == ["tesseract"]
    assert result["warnings"][0]["code"] == "missing_apple_vision"


def test_prepare_audit_source_ocr_off_still_blocks_sparse_pdf(tmp_path, monkeypatch) -> None:
    from audit_report import source

    pdf_path = make_blank_pdf(tmp_path / "scan.pdf")
    monkeypatch.setattr(source, "_load_apple_vision", lambda: ("vision",))
    monkeypatch.setattr(source, "_load_tesseract", lambda: ("tesseract", "5.3", "/usr/bin/tesseract"))

    result = source.prepare_audit_source(str(pdf_path), ocr_mode="off", output_dir=str(tmp_path / "out"))

    assert result["status"] == "blocked"
    assert result["ocr_used"] is False
    assert result["available_ocr_providers"] == ["apple_vision", "tesseract"]
    assert result["warnings"][0]["code"] == "embedded_text_sparse"
