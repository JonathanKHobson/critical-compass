from __future__ import annotations

import json
from pathlib import Path

from scripts.run_beta_audit_calibration import run_calibration


def test_beta_audit_calibration_harness_passes_fixture_expectations(tmp_path: Path) -> None:
    result = run_calibration(output_dir=tmp_path)

    assert result["status"] == "passed"
    assert result["case_count"] == 10
    assert result["blocking_count"] == 0
    assert result["metrics"]["expected_non_finding_violations"] == 0
    assert result["metrics"]["lens_retrieval_hit_rate"] >= 0.75
    assert result["metrics"]["forbidden_lens_violations"] == 0
    assert result["metrics"]["irrelevant_lens_count"] == 0
    assert result["metrics"]["unexpected_trap_count"] == 0
    assert result["metrics"]["before_use_quality_pass_rate"] == 1.0
    assert "lens_precision_at_k" in result["metrics"]
    assert "report_readiness_blocker_count" in result["metrics"]
    assert result["metrics"]["cis_range_pass_rate"] == 1.0
    assert Path(result["json_path"]).exists()
    assert Path(result["markdown_path"]).exists()
    assert any("report_readiness_misses" in row for row in result["rows"])
    assert any(row["trap_ids"] for row in result["rows"])
    assert any(row["trigger_ids"] for row in result["rows"])
    assert any(row["expected_non_findings"] for row in result["rows"])
    assert any(row["selected_lens_ids"] for row in result["rows"])
    assert any(row["forbidden_lens_families"] for row in result["rows"])


def test_beta_audit_calibration_accepts_custom_cases_file(tmp_path: Path) -> None:
    cases_path = tmp_path / "custom-cases.json"
    cases_path.write_text(
        json.dumps(
            {
                "cases": [
                    {
                        "id": "custom_neutral_case",
                        "text_type": "general",
                        "text": "The meeting moved from Monday to Wednesday. The agenda and owner remain unchanged.",
                        "expected_traps": [],
                        "expected_triggers": [],
                        "expected_absent_traps": ["comfortable_answer_detection"],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    result = run_calibration(cases_path=cases_path, output_dir=tmp_path / "out")

    assert result["status"] == "passed"
    assert result["case_count"] == 1
    assert result["metrics"]["false_positive_rate"] == 0.0
    assert result["rows"][0]["id"] == "custom_neutral_case"
    assert Path(result["json_path"]).exists()
    assert Path(result["markdown_path"]).exists()


def test_lens_precision_penalizes_forbidden_lenses(tmp_path: Path) -> None:
    cases_path = tmp_path / "custom-forbidden-lens.json"
    cases_path.write_text(
        json.dumps(
            {
                "cases": [
                    {
                        "id": "custom_forbidden_lens",
                        "text_type": "policy",
                        "text": "The tribal public health dashboard uses AI/AN data and asks whether OCAP or CARE governance applies.",
                        "expected_traps": [],
                        "expected_triggers": [],
                        "forbidden_lens_ids": ["ct:thinking-lenses:systems:indigenous-data-sovereignty"],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    result = run_calibration(cases_path=cases_path, output_dir=tmp_path / "out-forbidden")

    assert result["status"] == "needs_review"
    assert result["metrics"]["forbidden_lens_violations"] >= 1
    assert result["rows"][0]["forbidden_lens_violations"] == ["ct:thinking-lenses:systems:indigenous-data-sovereignty"]


def test_eval_summary_reports_negative_metrics(tmp_path: Path) -> None:
    result = run_calibration(output_dir=tmp_path)

    for key in [
        "lens_precision_at_k",
        "irrelevant_lens_count",
        "forbidden_lens_violations",
        "unexpected_trap_count",
        "before_use_quality_pass_rate",
        "report_readiness_blocker_count",
    ]:
        assert key in result["metrics"]
