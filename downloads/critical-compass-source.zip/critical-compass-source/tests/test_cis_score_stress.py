from __future__ import annotations

from pathlib import Path

from scripts.run_cis_score_stress import run_score_stress


def test_cis_score_stress_harness_records_repeat_and_distribution(tmp_path: Path) -> None:
    result = run_score_stress(output_dir=tmp_path)

    assert result["status"] == "measured"
    assert result["repeat_runs"] == 5
    assert result["case_count"] == 4
    assert "score_spread" in result
    assert {row["expected_band"] for row in result["rows"]} == {"weak", "moderate", "strong", "exemplary"}
    assert all(row["audit_method"] for row in result["rows"])
    assert result["cis_monotonicity_pass"] is True
    assert result["pairwise_failures"] == []
    assert result["minimum_gap_failures"] == []
    assert Path(result["json_path"]).exists()
    assert Path(result["markdown_path"]).exists()


def test_cis_weak_moderate_strong_ordering(tmp_path: Path) -> None:
    result = run_score_stress(output_dir=tmp_path)
    by_band = {row["expected_band"]: row["points"] for row in result["rows"]}

    assert by_band["weak"] < by_band["moderate"] < by_band["strong"] < by_band["exemplary"]


def test_cis_minimum_spread_for_anchor_set(tmp_path: Path) -> None:
    result = run_score_stress(output_dir=tmp_path)

    assert result["score_spread"] >= result["minimum_score_gap"] * 3
