from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def install_fake_mcp_modules() -> None:
    audit_report_module = sys.modules.get("audit_report")
    if audit_report_module is None:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        sys.modules["audit_report"] = audit_report_module
    audit_report_module.generate_audit_artifact_viewer = getattr(
        audit_report_module,
        "generate_audit_artifact_viewer",
        lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None},
    )
    audit_report_module.generate_audit_report = getattr(
        audit_report_module,
        "generate_audit_report",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None},
    )
    audit_report_module.prepare_audit_source = getattr(
        audit_report_module,
        "prepare_audit_source",
        lambda *_args, **_kwargs: {"status": "not_run", "text": ""},
    )
    audit_report_module.validate_report_payload = getattr(
        audit_report_module,
        "validate_report_payload",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False},
    )

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        audit_text_payload,
        define_audit_agents_payload,
        quick_scan_payload,
        select_lens_cards_for_audit,
    )

    return Repository, audit_text_payload, define_audit_agents_payload, quick_scan_payload, select_lens_cards_for_audit


def test_framework_lookup_returns_lens_card_contract() -> None:
    Repository, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = repo.lookup_framework_public("Indigenous data sovereignty")
    finally:
        repo.close()

    assert result["found"] is True
    card = result["lens_card"]
    assert card["schema_version"] == "lens-card.v1"
    assert card["lens_id"] == "ct:thinking-lenses:systems:indigenous-data-sovereignty"
    assert card["short_summary"]
    assert card["standard_summary"]
    assert card["full_summary"]
    assert card["use_when"]
    assert "short" in card["token_budget"]
    assert result["selected_lens_ids"] == [card["lens_id"]]


def test_audit_text_and_quick_scan_respect_lens_budgets() -> None:
    Repository, audit_text, _, quick_scan, _ = load_server_symbols()
    repo = Repository(DB_PATH)
    text = "This policy memo claims the AI governance dashboard will improve equity for every community without naming affected stakeholders or data limits."
    try:
        standard = audit_text(
            repo,
            text,
            text_type="policy",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            depth="standard",
        )
        quick = quick_scan(repo, text, text_type="policy")
    finally:
        repo.close()

    assert standard["retrieval_budget"]["mode"] == "standard"
    assert len(standard["selected_lens_cards"]) <= 5
    assert all(card["detail"] == "standard" for card in standard["selected_lens_cards"])
    assert quick["retrieval_budget"]["mode"] == "quick"
    assert len(quick["selected_lens_cards"]) <= 3
    assert all(card["detail"] == "short" for card in quick["selected_lens_cards"])


def test_search_public_exposes_selected_lens_ids_and_budget() -> None:
    Repository, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = repo.search_public("construct validity", category="methodology-checks", limit=5)
    finally:
        repo.close()

    assert result["retrieval_budget"]["mode"] == "standard"
    assert "ct:methodology:validity:construct-validity" in result["selected_lens_ids"]
    assert any(item["lens_id"] == "ct:methodology:validity:construct-validity" for item in result["selection_reasons"])
    assert any(item["lens_card"]["lens_id"] == "ct:methodology:validity:construct-validity" for item in result["results"])


def test_advanced_define_scaffold_exposes_budgeted_lens_cards() -> None:
    Repository, _, define_agents, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    subject = (
        "The tribal public health dashboard uses AI/AN data to measure food sovereignty, "
        "urban Indigenous health equity, and community-defined recovery indicators."
    )
    try:
        result = define_agents(repo, subject, text_type="research", retrieval_profile="research_methodology")
    finally:
        repo.close()

    assert result["retrieval_budget"]["mode"] == "advanced"
    assert len(result["selected_lens_cards"]) <= 8
    assert "ct:thinking-lenses:systems:indigenous-data-sovereignty" in result["selected_lens_ids"]
    assert result["lens_selection_reasons"]
    assert "host_inference" in result["lens_card_guidance"]


def test_fairness_to_text_keeps_neutral_update_from_overcritique() -> None:
    Repository, audit_text, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = audit_text(
            repo,
            "The meeting moved from Monday to Wednesday. The agenda and owner remain unchanged.",
            text_type="general",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            depth="standard",
        )
    finally:
        repo.close()

    fairness = result["fairness_to_text"]
    labels = {item["label"] for item in fairness["expected_non_findings"]}
    assert fairness["runs_before_final_bias_or_framing_conclusions"] is True
    assert "missing_denominator_risk" in labels
    assert "false_dilemma" in labels
    assert result["quality_gate"]["fairness_to_text_checked"] is True


def test_neutral_operational_update_does_not_select_indigenous_or_community_lenses() -> None:
    Repository, audit_text, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = audit_text(
            repo,
            "The team moved the weekly review from Tuesday to Thursday. The agenda is unchanged, and the facilitator will send notes afterward.",
            text_type="general",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            depth="standard",
        )
    finally:
        repo.close()

    forbidden = {
        "ct:thinking-lenses:systems:care-indigenous-data-governance",
        "framework:community-led-development-cld",
        "framework:ethical-data-stewardship-data-trusts-community-irb",
    }
    assert not (set(result["selected_lens_ids"]) & forbidden)
    assert result["lens_context_signals"]["neutral_operational"] is True


def test_generic_product_copy_does_not_select_care_without_data_governance_signal() -> None:
    Repository, audit_text, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = audit_text(
            repo,
            "Our AI coach eliminates bias for every hiring team and guarantees fair decisions without changing the company's existing workflow.",
            text_type="product_copy",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            depth="standard",
        )
    finally:
        repo.close()

    assert "ct:thinking-lenses:systems:care-indigenous-data-governance" not in result["selected_lens_ids"]
    assert "ct:thinking-lenses:systems:indigenous-data-sovereignty" not in result["selected_lens_ids"]


def test_indigenous_public_health_measurement_selects_ids_and_renders_carefully() -> None:
    Repository, audit_text, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    text = (
        "The tribal public health dashboard uses AI/AN data to measure food sovereignty, "
        "community-defined recovery indicators, and urban Indigenous health equity. "
        "The proposal does not yet say who controls access, who can veto categories, or whether OCAP or CARE governance applies."
    )
    try:
        result = audit_text(
            repo,
            text,
            text_type="policy",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            depth="standard",
        )
    finally:
        repo.close()

    assert "ct:thinking-lenses:systems:indigenous-data-sovereignty" in result["selected_lens_ids"]
    ids_to_cards = {card["lens_id"]: card for card in result["selected_lens_cards"]}
    card = ids_to_cards["ct:thinking-lenses:systems:indigenous-data-sovereignty"]
    assert card["match_confidence"] == "high"
    assert "Indigenous/tribal" in card["selection_reason"]
    assert "who controls the data categories" in result["critical_integrity_snapshot"]["before_using_this_text"]


def test_before_using_does_not_end_with_fragmented_keyword() -> None:
    Repository, audit_text, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    cases = [
        ("general", "The team moved the weekly review from Tuesday to Thursday. The agenda is unchanged, and the facilitator will send notes afterward."),
        ("advocacy", "The answer is obvious: either we approve the proposal now or we abandon the community. There is no doubt this is the only responsible path."),
        ("sales", "After fifteen years advising nonprofit boards, I recommend this governance sequence as a practical starting point. It is not a universal model, and small organizations should adapt the staffing steps to their capacity."),
    ]
    try:
        outputs = [
            audit_text(
                repo,
                text,
                text_type=text_type,
                human_loop_mode="silent",
                human_loop_state={"noninteractive_smoke_test": True},
                depth="standard",
            )["critical_integrity_snapshot"]["before_using_this_text"]
            for text_type, text in cases
        ]
    finally:
        repo.close()

    bad_endings = ("about moved.", "about answer.", "about capacity.")
    assert all(item.startswith("Before using this text,") for item in outputs)
    assert not any(item.endswith(bad_endings) for item in outputs)
