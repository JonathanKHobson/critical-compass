from __future__ import annotations

from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
INVENTORY = ROOT / "docs" / "planning" / "ideas" / "beta82-surface-extensions" / "planning-fragment-inventory.md"
ARCHIVE = ROOT / "docs" / "planning" / "archive" / "2026-04-28-beta82-planning-leak-snapshot"

RUNTIME_VISIBLE_FILES = [
    ROOT / "server.py",
    ROOT / "README.md",
    ROOT / "docs" / "public" / "why-critical-compass.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "tool-trigger-matrix.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "client-host-hints.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "server-instructions.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "host-ai-quickstart-current-state.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "tool-inventory.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "surface-sync-checklist.md",
    ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json",
]

BLOCKED_RUNTIME_PATTERNS = [
    r"\bmcp_composition\b",
    r"\bMCP composition\b",
    r"\borchestrated_external\b",
    r"\bmerged_internal\b",
    r"\bwrapped_internal\b",
    r"\bprompt_scaffold_only\b",
    r"\bThoughtProof\b",
    r"\bmcp-shield\b",
    r"\bmcp-guard\b",
    r"\bstudy-library\b",
    r"\bstudy library\b",
    r"\bcapability registry\b",
    r"\bKialo\b",
    r"\bScite\b",
    r"\bexternal MCP\b",
    r"\bthird-party MCP\b",
    r"\bdownloaded MCP\b",
]


def test_beta82_planning_leak_inventory_records_approved_cleanup() -> None:
    text = INVENTORY.read_text(encoding="utf-8")

    assert "Status: approved cleanup in progress" in text
    assert "2026-04-28-beta82-planning-leak-snapshot" in text
    assert "archive affected runtime/scaffold/public files before edits" in text.lower()
    for classification in [
        "runtime-visible",
        "packaged-scaffold-visible",
        "public-doc-visible",
        "dev-only-ok",
        "archive-candidate",
    ]:
        assert classification in text


def test_beta82_inventory_flags_known_runtime_and_packaged_leaks() -> None:
    text = INVENTORY.read_text(encoding="utf-8")

    flagged_surfaces = [
        "server.py",
        "critical_compass_overview",
        "support/resources/scaffolds/v1/tool-trigger-matrix.md",
        "support/resources/scaffolds/v1/client-host-hints.md",
        "support/resources/scaffolds/v1/server-instructions.md",
        "support/resources/scaffolds/v1/tool-inventory.md",
        "support/registry/mcp_capabilities.json",
        "support/registry/mcp_study_lessons.json",
        "README.md",
        "docs/public/why-critical-compass.md",
    ]
    for surface in flagged_surfaces:
        assert surface in text

    for blocked_term in [
        "orchestrated external",
        "prompt scaffold only",
        "capability registry",
        "study-library",
        "external orchestration",
    ]:
        assert blocked_term in text.lower()


def test_beta82_runtime_visible_surfaces_do_not_expose_planning_leak_terms() -> None:
    for path in RUNTIME_VISIBLE_FILES:
        text = path.read_text(encoding="utf-8")
        for pattern in BLOCKED_RUNTIME_PATTERNS:
            assert re.search(pattern, text, flags=re.IGNORECASE) is None, f"{path} exposes {pattern}"


def test_beta82_removed_scaffold_files_were_archived_before_cleanup() -> None:
    for relative_path in [
        "support/resources/scaffolds/v1/mcp-composition-policy.md",
        "support/resources/scaffolds/v1/external-mcp-orchestration-contract.md",
        "support/resources/scaffolds/v1/mcp-study-learner-runbook.md",
    ]:
        assert not (ROOT / relative_path).exists()
        assert (ARCHIVE / relative_path).exists()


def test_beta82_does_not_add_activity_or_readiness_or_framing_tools() -> None:
    server_text = (ROOT / "server.py").read_text(encoding="utf-8")

    assert "@server.tool" not in "\n".join(
        line for line in server_text.splitlines() if "record_activity_outcome" in line
    )
    assert "def record_activity_outcome" not in server_text
    assert "def framing_drift_monitor" not in server_text
    assert "def pressure_test_readiness_score" not in server_text
