from __future__ import annotations

import json
from pathlib import Path

from critical_course_resources import classroom_standard_audit_prompt_resource


ROOT = Path(__file__).resolve().parents[1]
SCAFFOLD_MANIFEST = ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json"


def test_classroom_standard_audit_prompt_blocks_panel_and_research_without_variance_disclaimer() -> None:
    resource = classroom_standard_audit_prompt_resource()
    prompt = resource["student_prompt"]
    lower_prompt = prompt.lower()

    assert resource["resource_id"] == "classroom_standard_audit_prompt"
    assert resource["prompt_version"] == "classroom-standard-audit.v1"
    assert resource["recommended_tool"] == "audit_text"
    assert "Please run a standard Critical Compass audit" in prompt
    assert "Audience: [who this is for]" in prompt
    assert "Intended use: [what this writing is meant to do]" in prompt
    assert "Text type:" in prompt
    assert "Audit depth: standard" in prompt
    assert "Do not run an advanced panel review" in prompt
    assert "multi-agent review" in prompt
    assert "web research" in prompt
    assert "Do not rewrite the text" in prompt
    assert "Critical Integrity Snapshot" in prompt
    assert "Plain-Language Read" in prompt
    assert "Top 3-5 findings" in prompt
    assert "Two peer-discussion questions" in prompt
    assert "variance" not in lower_prompt
    assert "outputs may differ" not in lower_prompt
    assert "score may vary" not in lower_prompt
    assert resource["student_prompt_rules"]["student_prompt_should_include_variance_disclaimer"] is False


def test_classroom_standard_audit_instructor_note_sets_score_expectations() -> None:
    resource = classroom_standard_audit_prompt_resource()
    note = resource["instructor_note"]
    feedback = " ".join(resource["course_feedback"])

    assert "outputs may differ across models and runs" in note
    assert "compare the top findings, severity, and revision decisions" in note
    assert "MCPB extension" in feedback
    assert "Version 2" in feedback
    assert "advanced panel review out of the core assignment" in feedback
    assert "perspective, power, cultural, or missing-voice issue" in feedback


def test_classroom_standard_audit_prompt_is_exposed_as_scaffold_resource() -> None:
    manifest = json.loads(SCAFFOLD_MANIFEST.read_text(encoding="utf-8"))
    resources = {item["id"]: item for item in manifest["resources"]}
    resource = resources["classroom_standard_audit_prompt"]
    path = SCAFFOLD_MANIFEST.parent / resource["path"]

    assert resource["path"] == "classroom-standard-audit-prompt.md"
    assert resource["format"] == "markdown"
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert "Do not run an advanced panel review" in text
    assert "web research" in text
    assert "outputs may differ across models and runs" in text
