from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "critical_compass_config_guard.py"

sys.path.insert(0, str(ROOT / "scripts"))
from critical_compass_config_guard import (  # noqa: E402
    has_utf8_bom,
    health_check,
    merge_server_entry,
    remove_server_entry,
)


def _write_config(path: Path) -> None:
    path.write_text(
        json.dumps(
            {
                "localAgentModeTrustedFolders": ["C:/Users/Megan/Documents/Obsidian_MCP"],
                "keepAwakeEnabled": True,
                "mcpServers": {
                    "chatgpt-history": {"command": "uv", "args": ["run", "chatgpt-history"]},
                    "pinboard": {"command": "uv", "args": ["run", "pinboard"]},
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def test_merge_preserves_existing_mcp_servers_and_writes_no_bom(tmp_path: Path) -> None:
    config_path = tmp_path / "claude_desktop_config.json"
    _write_config(config_path)

    result = merge_server_entry(
        config_path,
        "critical-compass",
        {"command": "uv", "args": ["run", "mcpb_launcher.py"]},
    )

    data = json.loads(config_path.read_text(encoding="utf-8"))
    assert result["before_servers"] == ["chatgpt-history", "pinboard"]
    assert result["after_servers"] == ["chatgpt-history", "critical-compass", "pinboard"]
    assert data["localAgentModeTrustedFolders"] == ["C:/Users/Megan/Documents/Obsidian_MCP"]
    assert data["keepAwakeEnabled"] is True
    assert data["mcpServers"]["chatgpt-history"]["command"] == "uv"
    assert data["mcpServers"]["pinboard"]["command"] == "uv"
    assert data["mcpServers"]["critical-compass"]["command"] == "uv"
    assert result["backup_path"]
    assert Path(result["backup_path"]).exists()
    assert has_utf8_bom(config_path) is False


def test_remove_preserves_unrelated_mcp_servers(tmp_path: Path) -> None:
    config_path = tmp_path / "claude_desktop_config.json"
    _write_config(config_path)
    merge_server_entry(config_path, "critical-compass", {"command": "uv", "args": ["run", "mcpb_launcher.py"]})

    result = remove_server_entry(config_path, "critical-compass")

    data = json.loads(config_path.read_text(encoding="utf-8"))
    assert result["after_servers"] == ["chatgpt-history", "pinboard"]
    assert set(data["mcpServers"]) == {"chatgpt-history", "pinboard"}
    assert data["localAgentModeTrustedFolders"] == ["C:/Users/Megan/Documents/Obsidian_MCP"]
    assert has_utf8_bom(config_path) is False


def test_health_check_reports_bom_without_mutating(tmp_path: Path) -> None:
    config_path = tmp_path / "claude_desktop_config.json"
    config_path.write_bytes(b"\xef\xbb\xbf" + b'{"mcpServers":{"pinboard":{"command":"uv"}}}\n')

    result = health_check(config_path)

    assert result["utf8_bom"] is True
    assert result["json_valid"] is True
    assert result["server_names"] == ["pinboard"]
    assert config_path.read_bytes().startswith(b"\xef\xbb\xbf")


def test_cli_merge_prints_before_after_servers(tmp_path: Path) -> None:
    config_path = tmp_path / "claude_desktop_config.json"
    entry_path = tmp_path / "entry.json"
    _write_config(config_path)
    entry_path.write_text('{"command":"uv","args":["run","mcpb_launcher.py"]}\n', encoding="utf-8")

    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "merge",
            "--config",
            str(config_path),
            "--entry-json",
            str(entry_path),
        ],
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["before_servers"] == ["chatgpt-history", "pinboard"]
    assert payload["after_servers"] == ["chatgpt-history", "critical-compass", "pinboard"]
    assert payload["utf8_bom"] is False
