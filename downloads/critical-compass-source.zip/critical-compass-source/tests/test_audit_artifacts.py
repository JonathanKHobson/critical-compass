from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def test_authored_argument_map_and_checkworthy_claims_export() -> None:
    from audit_report.artifacts import normalize_reasoning_artifacts

    data = {
        "argument_map": {
            "plain_language_summary": "This proposal is too early because the evidence is still thin.",
            "central_claim": "The launch should wait until the pilot evidence is stronger.",
            "claim_type": "policy",
            "supporting_reasons": ["The pilot is still running.", "The failure modes are not fully reviewed."],
            "objections": ["Delaying may slow adoption."],
            "assumptions": ["The pilot is representative."],
            "missing_voices": ["Frontline staff"],
            "evidence_gaps": ["No comparison to alternative rollout timing."],
            "confidence": "medium",
            "next_questions": ["What evidence would justify a launch now?"],
        },
        "checkworthy_claims": {
            "claims": [
                {"claim": "The pilot ran for 6 weeks.", "claim_type": "factual", "source_anchor": "pilot section"},
                {"claim": "The launch should wait.", "claim_type": "policy", "source_anchor": "conclusion"},
                {"claim": "Retention improved after the update.", "claim_type": "causal", "source_anchor": "results"},
            ]
        },
    }

    artifacts = normalize_reasoning_artifacts(data, subject_text="The launch should wait until evidence improves.")
    argument_map = artifacts["argument_map"]
    checkworthy = artifacts["checkworthy_claims"]

    assert argument_map["status"] == "authored"
    assert argument_map["plain_language_summary"] == "This proposal is too early because the evidence is still thin."
    assert argument_map["central_claim"] == "The launch should wait until the pilot evidence is stronger."
    assert argument_map["claim_type"] == "policy"
    assert argument_map["supporting_reasons"] == [
        "The pilot is still running.",
        "The failure modes are not fully reviewed.",
    ]
    assert argument_map["markdown"].startswith("# Argument Map")
    assert "## Evidence gaps" in argument_map["markdown"]
    assert "The launch should wait until the pilot evidence is stronger." in argument_map["argdown"]
    assert "  + The pilot is still running." in argument_map["argdown"]
    assert "  - Delaying may slow adoption." in argument_map["argdown"]

    claims = checkworthy["claims"]
    assert checkworthy["status"] == "authored"
    assert claims[0]["claim"] == "The pilot ran for 6 weeks."
    assert claims[0]["is_factual"] is True
    assert claims[0]["verification_priority"] in {"high", "medium", "low"}
    assert claims[1]["verification_priority"] == "not_ranked"
    assert claims[2]["verification_priority"] == "not_ranked"
    assert all(claim["not_false_notice"] == "Check-worthy means worth verifying, not false." for claim in claims)
    assert all(claim["suggested_queries"] for claim in claims)
    assert all(claim["likely_source_types"] for claim in claims)
    assert all(claim["support_contrast_status"] for claim in claims)
    assert all(claim["uncertainty_note"] for claim in claims)
    assert "Check-worthy means worth verifying, not false." in checkworthy["markdown"]
    assert "| Priority | Claim | Type | Why check | Evidence needed |" in checkworthy["markdown"]
    assert "Evidence plan:" in checkworthy["markdown"]


def test_heuristic_fallback_builds_reasoning_artifacts_from_text() -> None:
    from audit_report.artifacts import normalize_reasoning_artifacts

    subject_text = (
        "The pilot reduced wait times by 20 percent. However, the sample is small. "
        "The board should wait for more evidence."
    )

    artifacts = normalize_reasoning_artifacts({}, subject_text=subject_text)
    argument_map = artifacts["argument_map"]
    checkworthy = artifacts["checkworthy_claims"]

    assert argument_map["status"] == "heuristic"
    assert argument_map["plain_language_summary"].startswith("The pilot reduced wait times")
    assert argument_map["central_claim"] == "The board should wait for more evidence."
    assert argument_map["claim_type"] == "normative"
    assert argument_map["supporting_reasons"]
    assert argument_map["markdown"].startswith("# Argument Map")
    assert argument_map["argdown"].startswith("(The board should wait for more evidence.)")

    claims = checkworthy["claims"]
    assert claims
    assert claims[0]["is_factual"] is True
    assert claims[0]["verification_priority"] in {"high", "medium", "low"}
    assert any(not claim["is_factual"] for claim in claims)
    assert all(claim["not_false_notice"] == "Check-worthy means worth verifying, not false." for claim in claims)
    assert all(claim["suggested_queries"] for claim in claims)
    assert all(claim["likely_source_types"] for claim in claims)
    assert all(claim["uncertainty_note"] for claim in claims)
    assert "The board should wait for more evidence." in checkworthy["markdown"]


def test_argument_map_handles_causal_heavy_source_text() -> None:
    from audit_report.artifacts import normalize_reasoning_artifacts

    artifacts = normalize_reasoning_artifacts(
        {},
        subject_text=(
            "Clinic attendance increased because navigators coordinated rides and reminders. "
            "The report says the timing suggests the support caused the improvement."
        ),
    )

    argument_map = artifacts["argument_map"]
    assert argument_map["claim_type"] == "causal"
    assert any(term in argument_map["central_claim"].lower() for term in ("because", "caused"))
    assert argument_map["argdown"].startswith("(")


def test_argument_map_handles_normative_heavy_source_text() -> None:
    from audit_report.artifacts import normalize_reasoning_artifacts

    artifacts = normalize_reasoning_artifacts(
        {},
        subject_text=(
            "The organization should slow the rollout until affected families review the plan. "
            "Leaders ought to privilege safety over speed."
        ),
    )

    argument_map = artifacts["argument_map"]
    checkworthy = artifacts["checkworthy_claims"]
    assert argument_map["claim_type"] == "normative"
    assert "should" in argument_map["central_claim"].lower()
    assert any(claim["claim_type"] == "normative" for claim in checkworthy["claims"])
    assert all(
        claim["verification_priority"] == "not_ranked"
        for claim in checkworthy["claims"]
        if claim["claim_type"] == "normative"
    )


def test_factual_only_ranking_keeps_non_factual_claims_unranked() -> None:
    from audit_report.artifacts import normalize_checkworthy_claims

    data = {
        "checkworthy_claims": {
            "claims": [
                {"claim": "The launch should wait.", "claim_type": "policy"},
                {"claim": "The pilot ran for 6 weeks.", "claim_type": "factual"},
                {"claim": "Retention improved by 12 percent.", "claim_type": "factual"},
                {"claim": "The update caused the drop.", "claim_type": "causal"},
            ]
        }
    }

    checkworthy = normalize_checkworthy_claims(data)
    claims = checkworthy["claims"]

    assert [claim["is_factual"] for claim in claims[:2]] == [True, True]
    assert all(claim["verification_priority"] in {"high", "medium", "low"} for claim in claims[:2])
    assert all(claim["verification_priority"] == "not_ranked" for claim in claims[2:])
    assert all(claim["suggested_queries"] for claim in claims)
    assert all(claim["likely_source_types"] for claim in claims)
    assert all(claim["support_contrast_status"] for claim in claims)
    assert all(claim["uncertainty_note"] for claim in claims)
    assert "Check-worthy means worth verifying, not false." in checkworthy["markdown"]


def test_checkworthy_evidence_plan_is_no_network(monkeypatch) -> None:
    import socket

    from audit_report.artifacts import normalize_checkworthy_claims

    def fail_network(*_args, **_kwargs):
        raise AssertionError("checkworthy evidence planning must not open network connections")

    monkeypatch.setattr(socket, "create_connection", fail_network)
    monkeypatch.setattr(socket, "socket", fail_network)

    data = {
        "checkworthy_claims": {
            "claims": [
                {
                    "claim": "The pilot reduced wait times by 20 percent.",
                    "claim_type": "factual",
                    "source_anchor": "results",
                }
            ]
        }
    }

    checkworthy = normalize_checkworthy_claims(data)
    claim = checkworthy["claims"][0]

    assert claim["suggested_queries"]
    assert claim["likely_source_types"]
    assert claim["support_contrast_status"] in {"needs_source", "needs_evidence"}
    assert "false" in claim["uncertainty_note"].lower()
