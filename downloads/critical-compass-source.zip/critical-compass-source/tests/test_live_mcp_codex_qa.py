from __future__ import annotations

import json
from pathlib import Path

from scripts import live_mcp_codex_qa


def test_live_mcp_codex_qa_passes_repo_local_surface_checks(tmp_path: Path, monkeypatch) -> None:
    viewer = tmp_path / "report-viewer.html"
    viewer.write_text("<html>viewer</html>", encoding="utf-8")
    manifest = tmp_path / "report.json"
    manifest.write_text(json.dumps({"report": {"viewer_path": str(viewer)}}), encoding="utf-8")
    monkeypatch.setattr(live_mcp_codex_qa, "SMOKE_MANIFEST", manifest)

    result = live_mcp_codex_qa.run_repo_local_checks()

    assert result["status"] == "passed"
    checks = {item["check"]: item["passed"] for item in result["checks"]}
    assert checks["overview_mentions_artifact_viewer"]
    assert checks["reports_topic_has_source_to_report_to_viewer_flow"]
    assert checks["app_ui_topic_routes_to_artifact_viewer"]
    assert checks["scaffold_manifest_has_surface_refresh_resources"]
    assert checks["report_contract_mentions_viewer_handoff"]
    assert checks["smoke_report_manifest_has_viewer_path"]
    assert result["attached_mcp_manual_checks"]
