from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


SAMPLE_TEXT = (
    "Either we adopt this policy immediately or the whole program will fail. "
    "The pilot survey found retention dropped after the update, but it did not compare similar programs. "
    "Supporters say the choice is obvious, while affected families are not quoted."
)


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        advanced_audit_payload,
        audit_text_payload,
        build_human_loop,
        human_loop_host_action,
        human_loop_silent_parse,
        synthesize_audit_verdict_payload,
    )

    return Repository, advanced_audit_payload, audit_text_payload, build_human_loop, human_loop_host_action, human_loop_silent_parse, synthesize_audit_verdict_payload


def run_audit(**kwargs):
    Repository, _, audit_text_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        return audit_text_payload(repo, SAMPLE_TEXT, text_type="policy", **kwargs)
    finally:
        repo.close()


def answered_state(*prompt_ids: str) -> dict:
    return {"answered_prompt_ids": list(prompt_ids)}


def assert_widget_contract(action: dict, *, stage: str, question_count: int) -> None:
    required_keys = {
        "required_interaction_surface",
        "claude_widget_tool_name",
        "allowed_question_types",
        "plain_text_questions_valid",
        "repair_instruction",
        "widget_compliance_check",
        "tool_compliance_signal",
        "runtime_policy_card",
        "questions_for_user",
    }
    assert required_keys <= set(action)
    assert action["required_interaction_surface"] == "native_host_question_ui"
    assert action["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert "ask_user_input widget" in action["claude_widget_tool_aliases"]
    assert set(action["allowed_question_types"]) == {"single-select", "multi-select", "rank-priority"}
    assert action["plain_text_questions_valid"] is False
    assert action["inline_fallback_allowed"] is True
    assert action["inline_fallback_condition"].startswith("Only when Ask_User_Input_V0")
    assert "violates the Critical Compass interaction contract" in action["repair_instruction"]
    assert "Ask_User_Input_V0" in action["widget_compliance_check"]["expected_behavior"]
    assert "plain-text" in action["widget_compliance_check"]["invalid_behavior"]
    assert action["widget_compliance_check"]["repair_instruction"] == action["repair_instruction"]
    assert action["tool_compliance_signal"]["non_persistent"] is True
    assert action["tool_compliance_signal"]["current_stage"] == stage
    assert action["tool_compliance_signal"]["question_count"] == question_count
    assert action["runtime_policy_card"]["PAUSE_REQUIRED"] == action["must_pause"]
    assert action["runtime_policy_card"]["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert action["runtime_policy_card"]["allowed_question_types"] == ["single-select", "multi-select", "rank-priority"]
    assert "ask questions" not in action["directive"].lower().replace("ask_user_input", "")


def assert_top_level_pause_contract(result: dict, *, stage: str, question_count: int) -> None:
    assert result["PAUSE_REQUIRED"] is True
    assert result["runtime_policy_card"]["PAUSE_REQUIRED"] is True
    assert result["runtime_policy_card"]["stage"] == stage
    assert result["runtime_policy_card"]["question_count"] == question_count
    assert result["runtime_policy_card"]["claude_widget_tool_name"] == "Ask_User_Input_V0"
    assert "native conversational UI" in result["runtime_policy_card"]["rule"]
    assert_widget_contract(result["human_loop_host_action"], stage=stage, question_count=question_count)


def test_audit_text_guided_onboarding_gate_hides_findings() -> None:
    result = run_audit()

    assert result["status"] == "human_loop_onboarding_pending"
    assert result["human_loop"]["stage"] == "onboarding"
    assert result["human_loop"]["pending_prompt_ids"] == [
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
    ]
    assert result["human_loop_host_action"]["must_pause"] is True
    assert_top_level_pause_contract(result, stage="onboarding", question_count=4)
    assert "quick_scan_card" not in result
    assert "bias_map" not in result


def test_skipped_onboarding_allows_judgment_gate() -> None:
    result = run_audit(
        human_loop_state={
            "skipped_prompt_ids": [
                "onboarding_goal_for_text",
                "onboarding_intended_audience",
                "onboarding_relationship_to_text",
                "onboarding_output_format",
            ]
        }
    )

    assert result["status"] == "human_loop_judgment_pending"
    assert result["human_loop"]["stage"] == "judgment"
    assert result["human_loop"]["state"]["skipped_prompt_defaults"]
    assert result["human_loop"]["pending_prompt_ids"] == [
        "judgment_current_read",
        "judgment_suspected_issues",
        "judgment_pressure_test_target",
    ]
    assert_top_level_pause_contract(result, stage="judgment", question_count=3)


def test_silent_mode_bypasses_gates_with_disclosure() -> None:
    result = run_audit(human_loop_mode="silent", human_loop_state={"silent_mode_confirmed_by_user": True})

    assert result["status"] == "audit_ready"
    assert result["human_loop"]["pending_prompt_ids"] == []
    assert result["human_loop_host_action"]["must_pause"] is False
    assert result["quick_scan_card"]
    assert any("silent" in item.lower() for item in result["human_loop"]["assumption_disclosure"])


def test_unauthorized_silent_mode_returns_mode_consent_gate() -> None:
    result = run_audit(human_loop_mode="silent")
    action = result["human_loop_host_action"]

    assert result["status"] == "human_loop_mode_consent_pending"
    assert result["human_loop"]["stage"] == "mode_consent"
    assert result["human_loop"]["pending_prompt_ids"] == ["human_loop_mode_consent"]
    assert action["must_pause"] is True
    assert action["preferred_interaction_surface"] == "native_host_question_ui"
    assert action["interaction_batch"]["stage"] == "mode_consent"
    assert action["interaction_batch"]["question_count"] == 1
    assert action["interaction_batch"]["max_questions_this_turn"] == 1
    assert len(action["questions_for_user"]) == 1
    assert_top_level_pause_contract(result, stage="mode_consent", question_count=1)
    assert "quick_scan_card" not in result
    assert "bias_map" not in result


def test_mode_consent_guided_selection_overrides_requested_silent() -> None:
    result = run_audit(
        human_loop_mode="silent",
        human_loop_state={
            "answered_prompt_ids": ["human_loop_mode_consent"],
            "mode_consent": {"selected_mode": "guided", "confirmed_by_user": True},
        },
    )

    assert result["status"] == "human_loop_onboarding_pending"
    assert result["human_loop"]["mode"] == "guided"
    assert result["human_loop"]["state"]["mode_consent"]["selected_mode"] == "guided"
    assert result["human_loop"]["pending_prompt_ids"] == [
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
    ]


def test_mode_consent_minimal_selection_uses_one_prompt_per_block() -> None:
    result = run_audit(
        human_loop_mode="silent",
        human_loop_state={
            "answered_prompt_ids": ["human_loop_mode_consent"],
            "mode_consent": {"selected_mode": "minimal", "confirmed_by_user": True},
        },
    )

    assert result["status"] == "human_loop_onboarding_pending"
    assert result["human_loop"]["mode"] == "minimal"
    assert result["human_loop"]["pending_prompt_ids"] == ["onboarding_goal_for_text"]
    assert result["human_loop"]["interaction_batch"]["question_count"] == 1


def test_onboarding_intended_audience_prompt_is_optional_with_unknown_fallback() -> None:
    _, _, _, build_human_loop, _, _, _ = load_server_symbols()
    loop = build_human_loop(
        stage="onboarding",
        human_loop_mode="guided",
        human_loop_state={},
        text_type="policy",
        text_type_source="explicit",
        domain="public policy",
        sensitivity="high",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="visible_text_only",
    )
    prompt = {item["id"]: item for item in loop["prompts"]}["onboarding_intended_audience"]

    assert prompt["question"] == "Who is the intended audience or target reader?"
    assert prompt["allow_free_text"] is True
    assert prompt["on_skip"]["action"] == "continue_with_unknown_audience"
    assert prompt["on_skip"]["value"] == "unknown"
    assert prompt["selection_mode"] == "multi"
    assert prompt["max_selections"] == 2


def test_noninteractive_smoke_test_override_runs_silent() -> None:
    result = run_audit(human_loop_mode="silent", human_loop_state={"noninteractive_smoke_test": True})

    assert result["status"] == "audit_ready"
    assert result["human_loop"]["mode"] == "silent"
    assert result["human_loop"]["state"]["human_loop_override"] is True
    assert result["human_loop_host_action"]["must_pause"] is False
    assert result["quick_scan_card"]


def test_explicit_override_bypasses_onboarding_and_judgment() -> None:
    result = run_audit(human_loop_state={"explicit_noninteractive_override": True})

    assert result["status"] == "audit_ready"
    assert result["human_loop"]["state"]["human_loop_override"] is True
    assert result["human_loop"]["pending_prompt_ids"] == []
    assert result["human_loop_host_action"]["must_pause"] is False


def test_judgment_gate_uses_dynamic_m3_options() -> None:
    result = run_audit(
        human_loop_state=answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
        )
    )

    prompts = {prompt["id"]: prompt for prompt in result["human_loop"]["prompts"]}
    target = prompts["judgment_pressure_test_target"]

    assert result["status"] == "human_loop_judgment_pending"
    assert target["dynamic_options"]["source"] == "silent_parse_top_claims"
    assert any(choice["value"].startswith("dynamic_claim_") for choice in target["choices"])
    assert target["allow_free_text"] is True


def test_silent_parse_fallback_m3_options_for_empty_text() -> None:
    _, _, _, build_human_loop, _, human_loop_silent_parse, _ = load_server_symbols()
    silent_parse = human_loop_silent_parse("")
    loop = build_human_loop(
        stage="judgment",
        human_loop_mode="guided",
        human_loop_state={},
        text_type="general",
        text_type_source="inferred",
        domain="general text",
        sensitivity="low",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="too_thin",
        silent_parse=silent_parse,
    )
    target = {prompt["id"]: prompt for prompt in loop["prompts"]}["judgment_pressure_test_target"]

    assert target["dynamic_options"]["source"] == "fallback"
    assert any(choice["value"] == "main_claim" for choice in target["choices"])


def test_answered_judgment_runs_audit_then_reflection_gate() -> None:
    state = answered_state(
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
        "judgment_current_read",
        "judgment_suspected_issues",
        "judgment_pressure_test_target",
    )
    result = run_audit(human_loop_state=state)

    assert result["status"] == "audit_ready_reflection_pending"
    assert result["quick_scan_card"]
    assert result["bias_map"]
    assert result["human_loop"]["stage"] == "reflection"
    assert result["human_loop"]["pending_prompt_ids"] == [
        "reflection_takeaway",
        "reflection_reason_anchor",
        "reflection_next_action",
    ]
    assert_top_level_pause_contract(result, stage="reflection", question_count=3)
    assert set(result["preview_before_reflection"]) == {
        "likely_strongest_point",
        "likely_weakest_point",
        "biggest_missing_piece",
    }


def test_judgment_responses_do_not_change_frozen_findings() -> None:
    ids = [
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
        "judgment_current_read",
        "judgment_suspected_issues",
        "judgment_pressure_test_target",
    ]
    base = run_audit(human_loop_state={"answered_prompt_ids": ids})
    with_judgment = run_audit(
        human_loop_state={
            "answered_prompt_ids": ids,
            "responses": {
                "judgment_suspected_issues": {
                    "selected_values": ["loaded_language", "missing_affected_perspective"]
                }
            },
            "human_inputs": {
                "quarantined_opinions": [
                    {
                        "prompt_id": "judgment_suspected_issues",
                        "selected_values": ["loaded_language"],
                        "content": "The wording feels loaded.",
                    }
                ]
            },
        }
    )

    assert with_judgment["critical_integrity_snapshot"] == base["critical_integrity_snapshot"]
    assert with_judgment["bias_map"] == base["bias_map"]
    assert "framing_awareness" in with_judgment["human_loop"]["state"]["learning_signals"]["skill_tags"]


def test_reflection_option_bank_switches_for_learning_mode() -> None:
    _, _, _, build_human_loop, _, _, _ = load_server_symbols()
    state = {
        "responses": {
            "onboarding_goal_for_text": {"selected_values": ["learn_from_it"]},
            "onboarding_output_format": {"selected_values": ["learning_coaching"]},
        }
    }

    loop = build_human_loop(
        stage="reflection",
        human_loop_mode="guided",
        human_loop_state=state,
        text_type="general",
        text_type_source="inferred",
        domain="general text",
        sensitivity="low",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="visible_text_only",
        preview_before_reflection={
            "likely_strongest_point": "The claim is bounded.",
            "likely_weakest_point": "Evidence is thin.",
            "biggest_missing_piece": "Comparison evidence.",
        },
    )
    first_prompt = loop["prompts"][0]

    assert first_prompt["dynamic_options"]["option_bank"] == "learning_coaching"
    assert any(choice["value"] == "evidence_checking_sharper" for choice in first_prompt["choices"])


def test_host_action_uses_native_ui_and_current_stage_batching() -> None:
    _, _, _, build_human_loop, human_loop_host_action, _, _ = load_server_symbols()
    loop = build_human_loop(
        stage="onboarding",
        human_loop_mode="guided",
        human_loop_state={},
        text_type="policy",
        text_type_source="explicit",
        domain="public policy",
        sensitivity="high",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="visible_text_only",
    )
    action = human_loop_host_action(loop)

    assert action["preferred_interaction_surface"] == "native_host_question_ui"
    assert_widget_contract(action, stage="onboarding", question_count=4)
    assert action["fallback_interaction_surface"] == "compact_inline_question_block"
    assert "required host interaction contract" in action["directive"]
    assert "Ask_User_Input_V0" in action["directive"]
    assert "ordinary chat" in action["directive"]
    assert "Do not ask the full Human Loop questionnaire at once" in action["directive"]
    assert action["interaction_batch"] == loop["interaction_batch"]
    assert action["interaction_batch"]["stage"] == "onboarding"
    assert action["interaction_batch"]["question_count"] == 4
    assert len(action["questions_for_user"]) == 4
    assert {question["id"] for question in action["questions_for_user"]} == set(loop["pending_prompt_ids"])
    question_types = {question["id"]: question["widget_question_type"] for question in action["questions_for_user"]}
    assert question_types["onboarding_goal_for_text"] == "multi-select"
    assert question_types["onboarding_relationship_to_text"] == "single-select"
    assert all(question["ask_user_input_schema_hint"]["tool_name"] == "Ask_User_Input_V0" for question in action["questions_for_user"])


def test_widget_repair_instruction_is_available_for_prose_question_violation() -> None:
    _, _, _, build_human_loop, human_loop_host_action, _, _ = load_server_symbols()
    loop = build_human_loop(
        stage="judgment",
        human_loop_mode="guided",
        human_loop_state=answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
        ),
        text_type="policy",
        text_type_source="explicit",
        domain="public policy",
        sensitivity="high",
        depth="standard",
        snapshot_mode="organizer",
        retrieval_profile="general",
        source_completeness="visible_text_only",
        silent_parse={"top_claims_or_sections": [{"snippet": "The program must change now."}]},
    )
    action = human_loop_host_action(loop)

    assert action["must_pause"] is True
    assert "asked a user-facing question in prose" in action["repair_instruction"]
    assert "Do not ask the question in ordinary chat" in action["repair_instruction"]
    assert action["widget_compliance_check"]["repair_instruction"] == action["repair_instruction"]


def test_human_loop_batches_never_expose_all_nine_questions() -> None:
    _, _, _, build_human_loop, human_loop_host_action, _, _ = load_server_symbols()
    states = {
        "onboarding": {},
        "judgment": answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
        ),
        "reflection": answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
            "judgment_current_read",
            "judgment_suspected_issues",
            "judgment_pressure_test_target",
        ),
    }

    for stage, state in states.items():
        loop = build_human_loop(
            stage=stage,
            human_loop_mode="guided",
            human_loop_state=state,
            text_type="policy",
            text_type_source="explicit",
            domain="public policy",
            sensitivity="high",
            depth="standard",
            snapshot_mode="organizer",
            retrieval_profile="general",
            source_completeness="visible_text_only",
            silent_parse={"top_claims_or_sections": [{"snippet": "The program must change now."}]},
            preview_before_reflection={
                "likely_strongest_point": "A concrete policy concern is named.",
                "likely_weakest_point": "Evidence is thin.",
                "biggest_missing_piece": "Comparable outcome data.",
            },
        )
        action = human_loop_host_action(loop)

        assert len(action["questions_for_user"]) <= action["interaction_batch"]["max_questions_this_turn"]
        assert action["interaction_batch"]["do_not_prefetch_future_questions"] is True
        assert action["interaction_batch"]["question_count"] == len(action["questions_for_user"])
        assert all(question["id"].split("_", 1)[0] == stage for question in action["questions_for_user"])


def test_pause_contract_snapshot_fields_for_all_guided_stages() -> None:
    _, _, _, build_human_loop, human_loop_host_action, _, _ = load_server_symbols()
    stage_states = {
        "onboarding": {},
        "judgment": answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
        ),
        "reflection": answered_state(
            "onboarding_goal_for_text",
            "onboarding_intended_audience",
            "onboarding_relationship_to_text",
            "onboarding_output_format",
            "judgment_current_read",
            "judgment_suspected_issues",
            "judgment_pressure_test_target",
        ),
    }

    for stage, state in stage_states.items():
        loop = build_human_loop(
            stage=stage,
            human_loop_mode="guided",
            human_loop_state=state,
            text_type="policy",
            text_type_source="explicit",
            domain="public policy",
            sensitivity="high",
            depth="standard",
            snapshot_mode="organizer",
            retrieval_profile="general",
            source_completeness="visible_text_only",
            silent_parse={"top_claims_or_sections": [{"snippet": "The program must change now."}]},
            preview_before_reflection={
                "likely_strongest_point": "A concrete policy concern is named.",
                "likely_weakest_point": "Evidence is thin.",
                "biggest_missing_piece": "Comparable outcome data.",
            },
        )
        action = human_loop_host_action(loop)

        assert_widget_contract(action, stage=stage, question_count=len(action["questions_for_user"]))
        assert action["runtime_policy_card"]["rule"].startswith("If PAUSE_REQUIRED=true")
        assert "plain-text chat" in action["widget_compliance_check"]["invalid_behavior"]
        assert action["tool_compliance_signal"]["expected_widget_use"] is True


def test_advanced_audit_advocacy_request_stays_inside_critical_compass_first() -> None:
    Repository, advanced_audit_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = advanced_audit_payload(
            repo,
            "We need this advocacy statement to persuade skeptical local leaders without flattening community concerns or hiding trade-offs.",
            mode="ai_selected",
            text_type="policy",
            human_loop_mode="guided",
        )
    finally:
        repo.close()

    assert result["tool"] == "advanced_audit"
    assert result["status"] == "human_loop_onboarding_pending"
    assert result["human_loop"]["pending_prompt_ids"] == [
        "onboarding_goal_for_text",
        "onboarding_intended_audience",
        "onboarding_relationship_to_text",
        "onboarding_output_format",
    ]
    assert_top_level_pause_contract(result, stage="onboarding", question_count=4)
    assert "not built for" not in str(result).lower()


def test_synthesis_silent_without_consent_stops_at_mode_consent() -> None:
    *_, synthesize_audit_verdict_payload = load_server_symbols()

    result = synthesize_audit_verdict_payload(
        SAMPLE_TEXT,
        [{"agent_id": "agent_1"}],
        [{"agent_id": "agent_1"}],
        [{"tension_id": "tension_1"}],
        {"debate_exchange": []},
        text_type="policy",
        human_loop_mode="silent",
    )

    assert result["human_loop"]["stage"] == "mode_consent"
    assert result["human_loop_host_action"]["must_pause"] is True
    assert result["human_loop_host_action"]["interaction_batch"]["question_count"] == 1
    assert_top_level_pause_contract(result, stage="mode_consent", question_count=1)


def test_synthesis_silent_mode_accepts_reported_flat_confirmation_state() -> None:
    *_, synthesize_audit_verdict_payload = load_server_symbols()

    result = synthesize_audit_verdict_payload(
        SAMPLE_TEXT,
        [{"agent_id": "agent_1"}],
        [{"agent_id": "agent_1"}],
        [{"tension_id": "tension_1"}],
        {"debate_exchange": []},
        text_type="policy",
        human_loop_mode="silent",
        human_loop_state={"mode_consent": "confirmed", "user_confirmed_silent": True},
    )

    assert result["PAUSE_REQUIRED"] is False
    assert result["human_loop"]["mode"] == "silent"
    assert result["human_loop"]["mode_consent"]["selected_mode"] == "silent"
    assert result["human_loop"]["mode_consent"]["confirmed_by_user"] is True
    assert result["human_loop_confirmation"] == "Silent mode confirmed. Running without check-ins."


def test_synthesis_silent_mode_returns_confirmation_when_accepted() -> None:
    *_, synthesize_audit_verdict_payload = load_server_symbols()

    result = synthesize_audit_verdict_payload(
        SAMPLE_TEXT,
        [{"agent_id": "agent_1"}],
        [{"agent_id": "agent_1"}],
        [{"tension_id": "tension_1"}],
        {"debate_exchange": []},
        text_type="policy",
        human_loop_mode="silent",
        human_loop_state={"silent_mode_confirmed_by_user": True},
    )

    assert result["PAUSE_REQUIRED"] is False
    assert result["human_loop_confirmation"] == "Silent mode confirmed. Running without check-ins."


def test_pending_reflection_warns_report_normalization() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = {
        "critical_integrity_snapshot": {
            "label": "Moderate Integrity",
            "points": 62,
            "plain_language_read": "The text has a useful claim but needs stronger evidence.",
            "before_using_this_text": "Before using this text, check the missing comparison evidence.",
            "dimensions": [
                {"name": "Grounding & Scope Fit", "points": 12, "max_points": 20, "rationale": "Thin support.", "improvement_prompt": "Add comparison evidence."},
                {"name": "Assumptions & Context", "points": 12, "max_points": 20, "rationale": "Context is partial.", "improvement_prompt": "Name assumptions."},
                {"name": "Bias Transparency", "points": 12, "max_points": 20, "rationale": "Some framing risk.", "improvement_prompt": "Label uncertainty."},
                {"name": "Framing & Audience Openness", "points": 13, "max_points": 20, "rationale": "One perspective missing.", "improvement_prompt": "Add affected voices."},
                {"name": "Positionality & Power", "points": 13, "max_points": 20, "rationale": "Stakeholder impact thin.", "improvement_prompt": "Name affected groups."},
            ],
        },
        "biases": [{"name": "Framing effect", "why_it_matters": "Loaded framing can narrow interpretation."}],
        "key_tension": "The claim is persuasive but under-supported.",
        "recommended_next_step": "Add comparison evidence before using the claim.",
        "assumptions": [{"assumption": "The pilot is representative.", "status": "testable"}],
        "alternative_frames": [{"frame": "Treat this as an early signal.", "why_it_matters": "It lowers certainty."}],
        "probing_questions": ["What comparison group exists?", "What changed besides the policy?", "Who is missing?"],
        "next_steps": ["Add comparison data.", "Quote affected stakeholders.", "State uncertainty."],
        "human_loop": {
            "mode": "guided",
            "pending_prompt_ids": ["reflection_takeaway"],
            "state": {"human_loop_mode": "guided", "pending_prompt_ids": ["reflection_takeaway"]},
        },
        "human_loop_host_action": {"must_pause": True},
    }
    payload = normalize_audit_data(data, normalize_options(data))
    fields = {warning["field"] for warning in payload["diagnostics"]["schema_warnings"]}

    assert "human_loop.pending_prompt_ids" in fields
