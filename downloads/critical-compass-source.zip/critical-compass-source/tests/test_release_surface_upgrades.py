from __future__ import annotations

import sys
import types
from pathlib import Path

from factcheck.tool import factcheck_lookup


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def install_fake_mcp_modules() -> None:
    audit_report_module = sys.modules.get("audit_report")
    if audit_report_module is None:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        sys.modules["audit_report"] = audit_report_module
    audit_report_module.generate_audit_artifact_viewer = getattr(
        audit_report_module,
        "generate_audit_artifact_viewer",
        lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None},
    )
    audit_report_module.generate_audit_report = getattr(
        audit_report_module,
        "generate_audit_report",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None},
    )
    audit_report_module.prepare_audit_source = getattr(
        audit_report_module,
        "prepare_audit_source",
        lambda *_args, **_kwargs: {"status": "not_run", "text": ""},
    )
    audit_report_module.validate_report_payload = getattr(
        audit_report_module,
        "validate_report_payload",
        lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False},
    )

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        StateStore,
        audit_text_payload,
        compare_audit_results_payload,
        get_started_payload,
        list_agent_personas_payload,
        normalize_text_type,
        quick_scan_payload,
    )

    return {
        "Repository": Repository,
        "StateStore": StateStore,
        "audit_text_payload": audit_text_payload,
        "compare_audit_results_payload": compare_audit_results_payload,
        "get_started_payload": get_started_payload,
        "list_agent_personas_payload": list_agent_personas_payload,
        "normalize_text_type": normalize_text_type,
        "quick_scan_payload": quick_scan_payload,
    }


def sample_snapshot(points: int = 70, *, display_state: str = "scored", text_type: str = "policy") -> dict:
    cis_points = points if display_state == "scored" else None
    return {
        "display_state": display_state,
        "label": "Moderate Integrity" if display_state == "scored" else None,
        "points": cis_points,
        "max_points": 100,
        "score_confidence": "medium",
        "comparability": "comparable" if display_state == "scored" else "not_comparable",
        "snapshot_mode": "organizer",
        "plain_language_read": "Use this as a pressure-tested draft, not a final authority.",
        "before_using_this_text": "Before using this text, check the evidence doing the most work.",
        "context_lens": {
            "evidence_convention": "institutional_reporting",
            "purpose": "persuade" if text_type in {"policy", "advocacy"} else "inform",
            "voice": "institutional",
            "knowledge_tradition": "western_academic",
        },
        "dimensions": [
            {"name": "Grounding & Scope Fit", "points": min(points, 20), "max_points": 20, "rationale": "Visible but bounded.", "trace": []},
            {"name": "Assumptions & Context", "points": 14, "max_points": 20, "rationale": "Some assumptions remain.", "trace": []},
        ],
    }


def test_new_public_tools_and_existing_state_tools_are_exposed() -> None:
    text = (ROOT / "server.py").read_text(encoding="utf-8")

    for tool_name in [
        "get_started",
        "quick_scan",
        "list_agent_personas",
        "compare_audit_results",
        "list_audit_results",
        "get_pattern_summary",
    ]:
        assert f"def {tool_name}(" in text
    assert "First-session onboarding" in text
    assert "Summarize recurring saved bias/framework/flow patterns" in text


def test_get_started_surfaces_routing_and_beta_calibration() -> None:
    symbols = load_server_symbols()
    result = symbols["get_started_payload"]()

    assert result["status"] == "get_started_ready"
    assert result["start_here_tools"] == ["get_started", "quick_scan", "audit_text", "claim_stress_test", "prepare_audit_source", "generate_audit_report"]
    assert result["tool_tiers"]["tier_1"]["tools"] == result["start_here_tools"]
    assert "smallest correct Tier 1 tool" in result["tool_routing_note"]
    assert "get_started" in " ".join(result["routing_rule"]["use_get_started_when"])
    assert "critical_compass_overview" in " ".join(result["routing_rule"]["use_critical_compass_overview_when"])
    assert result["beta_feedback"]["resource_id"] == "beta_calibration_intake"
    assert "wrong" in result["beta_feedback"]["message"]


def test_get_started_defaults_to_intent_first_routing() -> None:
    symbols = load_server_symbols()
    result = symbols["get_started_payload"]()
    joined = " ".join(
        result["routing_rule"]["use_get_started_when"]
        + result["starter_prompts"]
        + [item["action"] for item in result["first_five_minutes"]]
        + [result["next_step"]]
    )

    assert "goal" in joined.lower()
    assert "intended audience" in joined.lower()
    assert "quick, full, or advanced" in joined.lower()
    assert "audit_text" in joined
    assert "advanced_audit" in joined
    assert result["agentic_opt_in_rule"]["requires_explicit_opt_in"] is True
    assert "advanced panel review" in result["agentic_opt_in_rule"]["safe_phrases"]
    assert "city council" in result["agentic_opt_in_rule"]["insufficient_phrases_alone"]
    assert "do not expose agent scaffolds" in result["agentic_opt_in_rule"]["default_when_unclear"]


def test_quick_scan_is_compact_and_points_to_audit_text() -> None:
    symbols = load_server_symbols()
    repo = symbols["Repository"](DB_PATH)
    try:
        result = symbols["quick_scan_payload"](
            repo,
            "Our framework is the only model built for this sector and will solve the risk.",
            text_type="product_copy",
        )
    finally:
        repo.close()

    assert result["status"] == "quick_scan_ready"
    assert len(result["top_biases"]) <= 2
    assert result["run_next"]["tool"] == "audit_text"
    assert "not a replacement" in result["scope_note"]
    assert "report_readiness_contract" not in result
    assert "argument_map" not in result
    assert "bias_map" not in result


def test_new_text_types_normalize_and_route_to_expected_emphasis() -> None:
    symbols = load_server_symbols()
    normalize_text_type = symbols["normalize_text_type"]
    repo = symbols["Repository"](DB_PATH)
    try:
        assert normalize_text_type("tweet") == "social_media"
        assert normalize_text_type("paper abstract") == "academic_abstract"
        assert normalize_text_type("landing page copy") == "product_copy"
        assert normalize_text_type("terms of service") == "legal"
        assert normalize_text_type("llm generated") == "ai_generated"

        abstract = symbols["audit_text_payload"](
            repo,
            "Abstract: Methods: A randomized study of 42 participants measured empathy. Results: The intervention improved self-reported empathy.",
            text_type="academic_abstract",
            retrieval_profile="auto",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
        )
        product = symbols["audit_text_payload"](
            repo,
            "Only our platform guarantees adoption and no other framework is built for this sector.",
            text_type="product_copy",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
        )
        legal = symbols["audit_text_payload"](
            repo,
            "The parties shall comply with this agreement and waive liability where permitted by law.",
            text_type="legal",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
        )
        ai_generated = symbols["audit_text_payload"](
            repo,
            "This ChatGPT generated summary clearly proves the policy will always work.",
            text_type="ai_generated",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
        )
    finally:
        repo.close()

    assert abstract["retrieval_profile"] == "research_methodology"
    assert abstract["replication_readiness"]["applicable"] is True
    assert "Persuasive-document calibration" in product["evidence_and_limits"]
    assert "not legal advice" in legal["evidence_and_limits"]
    assert "AI-generated text calibration" in ai_generated["evidence_and_limits"]


def test_guided_factcheck_leads_with_no_retrieval_and_opt_in_paths() -> None:
    result = factcheck_lookup(
        [
            {
                "claim_id": "c1",
                "text": "The city reduced bus fares by 25 percent in 2024.",
                "claim_type": "factual",
                "is_factual": True,
                "verification_priority": "high",
            }
        ]
    )

    assert result["lookup_performed"] is False
    assert result["user_facing_summary"]["headline"] == "No retrieval was performed."
    assert any("allow_external_calls=true" in path for path in result["user_facing_summary"]["opt_in_retrieval_paths"])
    assert "No retrieval was performed" in result["results"][0]["summary"]


def test_list_agent_personas_supports_custom_roles_without_identity_impersonation() -> None:
    symbols = load_server_symbols()
    repo = symbols["Repository"](DB_PATH)
    try:
        result = symbols["list_agent_personas_payload"](
            repo,
            subject="A policy memo about community benefits and digital governance.",
            text_type="policy",
        )
    finally:
        repo.close()

    examples = " ".join(item["user_phrase"] for item in result["supported_custom_examples"])
    guardrails = " ".join(result["guardrails"])
    assert result["status"] == "agent_personas_ready"
    assert "policy analyst" in examples
    assert "community organizer" in examples
    assert "Indigenous knowledge holder" in examples
    assert "not claims of lived identity" in guardrails
    assert "Do not impersonate" in guardrails


def test_compare_audit_results_direct_weak_missing_and_advanced_warnings(tmp_path: Path) -> None:
    symbols = load_server_symbols()
    StateStore = symbols["StateStore"]
    compare = symbols["compare_audit_results_payload"]
    state = StateStore(tmp_path / "state.sqlite")
    try:
        subject = "The agency should revise intake rules because families need kinship continuity."
        first = state.save_audit_result(
            subject_text=subject,
            text_type="policy",
            critical_integrity_snapshot=sample_snapshot(68, text_type="policy"),
            biases_found=[{"bias_name": "Framing effect", "bias_id": "ct:biases:cognitive:framing-effect"}],
            result_payload={"advanced_audit": {"agents": [{"name": "Policy analyst"}]}},
        )
        second = state.save_audit_result(
            subject_text=subject,
            text_type="policy",
            critical_integrity_snapshot=sample_snapshot(74, text_type="policy"),
            biases_found=[{"bias_name": "Selection bias", "bias_id": "ct:biases:cognitive:selection-bias"}],
            result_payload={},
        )
        direct = compare(state, first["result_id"], second["result_id"])

        profile = state.save_audit_result(
            subject_text="Terms: the user shall waive all claims.",
            text_type="legal",
            critical_integrity_snapshot=sample_snapshot(50, display_state="profile_only", text_type="legal"),
            biases_found=[],
        )
        weak = compare(state, first["result_id"], profile["result_id"])
        missing = compare(state, first["result_id"], "result:missing")
    finally:
        state.close()

    assert direct["comparability"] == "direct"
    assert direct["cis_delta"]["delta"] == 6
    assert direct["framing_drift_check"]["status"] == "scaffold_only"
    assert "Audience posture" in {item["area"] for item in direct["framing_drift_check"]["checks"]}
    assert "Claim strength" in {item["area"] for item in direct["framing_drift_check"]["checks"]}
    assert "Missing voices" in {item["area"] for item in direct["framing_drift_check"]["checks"]}
    assert "Persuasion risk" in {item["area"] for item in direct["framing_drift_check"]["checks"]}
    assert "do not claim the draft improved" in direct["framing_drift_check"]["comparability_caution"]
    assert any("advanced-audit" in warning for warning in direct["warnings"])
    assert weak["comparability"] == "weak"
    assert any("Text types differ" in warning for warning in weak["warnings"])
    assert any("profile-only" in warning for warning in weak["warnings"])
    assert missing["comparability"] == "not_comparable"


def test_compare_audit_results_accepts_already_audited_inline_payloads(tmp_path: Path) -> None:
    symbols = load_server_symbols()
    StateStore = symbols["StateStore"]
    compare = symbols["compare_audit_results_payload"]
    state = StateStore(tmp_path / "state.sqlite")
    try:
        payload_a = {
            "result_id": "inline-audit-a",
            "subject_text": "Draft A says the policy will improve access because families asked for it.",
            "text_type": "policy",
            "critical_integrity_snapshot": sample_snapshot(66, text_type="policy"),
            "biases_found": [{"bias_name": "Framing effect", "bias_id": "ct:biases:cognitive:framing-effect"}],
        }
        payload_b = {
            "result_id": "inline-audit-b",
            "subject_text": "Draft B says the policy may improve access if families confirm the design fits their needs.",
            "text_type": "policy",
            "critical_integrity_snapshot": sample_snapshot(76, text_type="policy"),
            "biases_found": [{"bias_name": "Selection bias", "bias_id": "ct:biases:cognitive:selection-bias"}],
        }
        inline = compare(state, result_payload_a=payload_a, result_payload_b=payload_b)
        mixed = compare(state, "result:a", result_payload_b=payload_b)
    finally:
        state.close()

    assert inline["status"] == "comparison_ready"
    assert inline["cis_delta"]["delta"] == 10
    assert inline["workflow_differences"]["input_source_a"] == "inline_payload"
    assert inline["workflow_differences"]["input_source_b"] == "inline_payload"
    assert inline["framing_drift_check"]["status"] == "scaffold_only"
    assert inline["bias_diff"]["added_in_b"][0]["bias_name"] == "Selection bias"
    assert mixed["status"] == "validation_error"
    assert any("either two saved result IDs or two already-audited inline payloads" in warning for warning in mixed["warnings"])


def test_why_critical_compass_public_page_has_required_trust_calibration() -> None:
    text = (ROOT / "docs" / "public" / "why-critical-compass.md").read_text(encoding="utf-8")

    assert "does not verify truth" in text
    assert "does not replace human judgment" in text
    assert "does not guarantee that non-Western" in text
    assert "does not prevent biased outputs" in text
    assert "surfaces risks for review" in text
    assert "Argument-mapping apps" in text
    assert "Research-evidence products" in text
    assert "Generic reasoning assistants" in text
    assert "Kialo" not in text
    assert "Elicit" not in text
    assert "Scite" not in text
    assert "Consensus" not in text
    assert "check-worthy means worth verifying, not false" in text


def test_host_routing_resources_keep_audience_fit_inside_critical_compass() -> None:
    paths = [
        ROOT / "support" / "resources" / "scaffolds" / "v1" / "tool-trigger-matrix.md",
        ROOT / "support" / "resources" / "scaffolds" / "v1" / "client-host-hints.md",
        ROOT / "support" / "resources" / "scaffolds" / "v1" / "host-ai-quickstart-current-state.md",
    ]
    text = "\n".join(path.read_text(encoding="utf-8") for path in paths)

    assert "goal, intended audience" in text
    assert "quick, full, or advanced" in text
    assert "Audience effectiveness" in text


def test_release_guardrails_preserve_website_design_and_compact_report_default() -> None:
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    skill = (ROOT / "critical-compass" / "SKILL.md").read_text(encoding="utf-8")
    host_hints = (ROOT / "support" / "resources" / "scaffolds" / "v1" / "client-host-hints.md").read_text(encoding="utf-8")
    quickstart = (ROOT / "support" / "resources" / "scaffolds" / "v1" / "host-ai-quickstart-current-state.md").read_text(encoding="utf-8")
    text = "\n".join([host_hints, quickstart])

    assert "separate `About` and `FAQ` tabs" in agents
    assert "no combined `About & FAQ` tab" in agents
    assert "build_shareable_release.py --pages-only" in agents
    assert "package rebuild, public-site edit, or publish step" in agents
    assert 'report_depth="readiness_card"' in agents
    assert "First-share default" in readme
    assert "debug metadata" in readme
    assert "compact report default" in host_hints
    assert "first-share report" in quickstart
    assert "first-share report" in skill
    assert "JTBD" in text
    assert "not mismatch cases" in text or "not a mismatch lane" in text


def test_server_public_descriptions_frame_advanced_audit_for_audience_fit() -> None:
    text = (ROOT / "server.py").read_text(encoding="utf-8")

    assert "audience-fit / persuasion-effectiveness review" in text
    assert "Adjacent frameworks such as JTBD are optional follow-on helpers" in text
    assert "never ask the full Human Loop questionnaire at once" in text
