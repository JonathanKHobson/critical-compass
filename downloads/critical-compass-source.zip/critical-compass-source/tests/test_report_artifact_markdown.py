from __future__ import annotations

from pathlib import Path


def _base_payload(*, include_optional: bool) -> dict:
    payload = {
        "meta": {
            "schema_version": "v1",
            "report_title": "Critical Integrity Report",
            "date": "2026-04-15",
            "text_type": "research",
            "knowledge_tradition": "critical_compass",
            "report_audience": "general",
            "report_mode": "reader",
            "report_depth": "full",
        },
        "cis": {
            "display_state": "scored",
            "label": "Moderate Integrity",
            "points": 13,
            "max_points": 20,
            "plain_language_read": "The draft is clear, but some claims need stronger support before a reader should act on them.",
            "before_using_this_text": "Before using this text, check the missing context, the evidence behind the strongest claims, and who is not represented.",
            "dimensions": [
                {
                    "name": "Grounding",
                    "points": 14,
                    "max_points": 20,
                    "rationale": "The evidence is visible, but not yet complete.",
                    "improvement_prompt": "Name the key source before making the claim stronger.",
                    "trace": ["page 2"],
                },
                {
                    "name": "Assumptions",
                    "points": 12,
                    "max_points": 20,
                    "rationale": "Several assumptions stay implicit.",
                    "improvement_prompt": "State the assumption that must be true for the claim to hold.",
                },
                {
                    "name": "Bias Transparency",
                    "points": 13,
                    "max_points": 20,
                    "rationale": "The text is reflective, but not fully explicit about its bias risk.",
                    "improvement_prompt": "Say where the text could overreach.",
                },
                {
                    "name": "Audience Openness",
                    "points": 13,
                    "max_points": 20,
                    "rationale": "The audience is named, but alternative readers are missing.",
                    "improvement_prompt": "Describe who might read this differently.",
                },
                {
                    "name": "Positionality",
                    "points": 12,
                    "max_points": 20,
                    "rationale": "The perspective is visible but still somewhat thin.",
                    "improvement_prompt": "Add the standpoint that shaped the text.",
                },
            ],
        },
        "findings": {
            "biases": [
                {
                    "name": "Overgeneralization",
                    "kb_id": "ct:methodology:overgeneralization",
                    "passage": "creating closeness in an experimental context",
                    "why_it_matters": "The reader may think a small example applies more broadly than it does.",
                    "three_cs_lens": "Critical",
                }
            ],
            "key_tension": "The text wants to be generous, but it still needs clearer evidence boundaries.",
            "recommended_next_step": "Add one short paragraph naming the strongest limitation before sharing the draft.",
        },
        "assumptions": [
            {
                "assumption": "The reader already trusts the source.",
                "testable": "testable",
                "evidence_needed": "A note describing why the source should be trusted.",
            }
        ],
        "alternative_frames": [
            {
                "name": "Skeptical Reader",
                "kb_id": "ct:frame:skeptical-reader",
                "frame": "Read the draft as an invitation to test the claim rather than accept it.",
                "three_cs_lens": "Critical",
            }
        ],
        "questions": {
            "probing": ["What evidence would change the conclusion?"],
            "follow_up": ["Who is missing from the current version?"],
        },
        "next_steps": ["Write the missing limitation in one sentence.", "Name the most important source behind the claim."],
        "follow_up_activity": {
            "mode": "curated_file_o_fun_snapshot",
            "try_this_next": {
                "title": "Claim-Support-Question",
                "why_this_fits": "The text depends on a claim whose support should be separated from what remains unresolved.",
                "steps": [
                    "Pick the claim doing the most work.",
                    "Name the exact support the text gives.",
                    "Write one honest question that would need an answer before relying on it.",
                ],
                "content_focus": "Use the claim that carries the most decision weight.",
                "thinking_focus": ["critical"],
                "source_note": "Curated from Critical Compass.",
            },
            "solo_activity": {
                "title": "Claim-Support-Question",
                "why_this_fits": "The text depends on a claim whose support should be separated from what remains unresolved.",
                "steps": [
                    "Pick the claim doing the most work.",
                    "Name the exact support the text gives.",
                    "Write one honest question that would need an answer before relying on it.",
                ],
                "content_focus": "Use the claim that carries the most decision weight.",
                "thinking_focus": ["critical"],
                "source_note": "Curated from Critical Compass.",
            },
            "group_activity": {
                "title": "Micro Lab Protocol",
                "why_this_fits": "A structured review can test whether the text is clear, supported, and safe to use with the intended audience.",
                "steps": [
                    "Give reviewers one passage and one feedback question.",
                    "Collect what confused, concerned, or persuaded them.",
                    "Turn the feedback into one revision and one verification task.",
                ],
                "content_focus": "Use the passage most likely to affect trust, inclusion, or action.",
                "thinking_focus": ["critical", "compassionate"],
                "source_note": "Curated from Critical Compass.",
            },
            "source_note": "Curated from Critical Compass.",
            "fit_check": {
                "prompt": "After trying this activity, note what helped and what you would change.",
                "reflection_question": "What worked, what felt mismatched, and what should change before the next review?",
                "persistence": "non_persistent",
                "reader_note": "Use these notes to choose whether to keep, swap, or skip this activity next time.",
            },
        },
        "pressure_test_readiness_card": {
            "decision_action": "Revise",
            "rationale": "The draft is useful, but it needs clearer evidence boundaries before it carries a decision.",
            "cis_signal": "Moderate Integrity (13/20)",
            "evidence_strength_signal": "Evidence-needed plan is present; use it before treating the text as settled.",
            "missing_voice_risk": "A skeptical reader may still need more evidence before agreeing.",
            "before_use_caution": "Before using this text, check the missing context, the evidence behind the strongest claims, and who is not represented.",
            "next_move": "Add one short paragraph naming the strongest limitation before sharing the draft.",
            "source_note": "Derived from existing audit fields; no new score or live retrieval was added.",
        },
        "advanced_audit": {
            "present": True,
            "agents": [],
            "verdict_paragraph": "",
        },
        "appendix": {
            "include_raw_text": False,
        },
    }

    if include_optional:
        payload["argument_map"] = {
            "central_claim": "The draft argues that trust grows when evidence boundaries are named clearly.",
            "claim_type": "interpretive",
            "supporting_reasons": [
                "The draft already names one limitation.",
                "The language becomes sharper when it points to a source.",
            ],
            "objections": [
                "The draft could still overstate confidence.",
            ],
            "assumptions": [
                "The reader wants a cautious rather than promotional frame.",
            ],
            "missing_voices": [
                "A skeptical reader who wants more evidence before agreeing.",
            ],
            "evidence_gaps": [
                "No control condition is described.",
            ],
            "confidence": "medium",
            "next_questions": [
                "Which sentence most needs evidence?",
            ],
            "markdown": "# Argument Map\n\n- Central claim: Trust grows when evidence boundaries are named clearly.",
            "argdown": "(trust grows) -> (evidence boundaries are named clearly)",
            "status": "ready",
        }
        payload["checkworthy_claims"] = {
            "factual": [
                {
                    "claim": "The draft uses one experimental example.",
                    "verification_priority": "high",
                    "why_check": "This anchors the scope of the argument.",
                    "evidence_needed": "The source note or transcript.",
                    "suggested_queries": ["experimental example source note transcript"],
                    "likely_source_types": ["source note", "transcript"],
                    "support_contrast_status": "needs_source",
                    "uncertainty_note": "The report has not verified this externally.",
                    "source_anchor": "page 2",
                    "confidence": "high",
                }
            ],
            "interpretive": [
                {
                    "claim": "The draft feels warmer than the average critical memo.",
                    "why_it_matters": "Tone can change how the reader receives the evidence.",
                    "evidence_needed": "Reader feedback or tone analysis.",
                    "suggested_queries": ["reader feedback tone analysis"],
                    "likely_source_types": ["reader feedback", "tone analysis"],
                    "support_contrast_status": "interpretive_not_ranked",
                    "uncertainty_note": "This is interpretive and should not be ranked as true or false.",
                    "source_anchor": "review note",
                    "confidence": "medium",
                }
            ],
            "causal": [
                {
                    "claim": "Adding a limitation paragraph may reduce overconfidence.",
                    "why_it_matters": "The effect is plausible but not guaranteed.",
                    "evidence_needed": "A comparison of draft versions.",
                    "suggested_queries": ["limitation paragraph overconfidence comparison"],
                    "likely_source_types": ["draft comparison", "reader test"],
                    "support_contrast_status": "causal_needs_test",
                    "uncertainty_note": "The causal effect is plausible but unverified.",
                    "source_anchor": "editorial hypothesis",
                    "confidence": "low",
                }
            ],
            "normative": [
                {
                    "claim": "The report should privilege clarity over persuasion.",
                    "why_it_matters": "This is a value choice, not a factual claim.",
                    "evidence_needed": "Editorial agreement.",
                    "suggested_queries": ["clarity over persuasion editorial guidance"],
                    "likely_source_types": ["style guide", "editorial principles"],
                    "support_contrast_status": "normative_not_ranked",
                    "uncertainty_note": "This claim depends on shared values, not external verification.",
                    "source_anchor": "style guide",
                    "confidence": "medium",
                }
            ],
            "policy": [
                {
                    "claim": "Readers should ask for one missing source before approval.",
                    "why_it_matters": "This is a guidance rule, not a truth claim.",
                    "evidence_needed": "Team process agreement.",
                    "suggested_queries": ["approval workflow missing source requirement"],
                    "likely_source_types": ["team workflow", "approval policy"],
                    "support_contrast_status": "policy_not_ranked",
                    "uncertainty_note": "This should be checked against team process, not truth-ranked.",
                    "source_anchor": "workflow rule",
                    "confidence": "medium",
                }
            ],
        }
        payload["advanced_audit"]["dissent_ledger"] = [
            {
                "agent": "Harvey",
                "top_finding": "The report is readable, but the evidence boundary should be even sharper.",
                "strongest_disagreement": "The draft still reads a little too certain.",
                "confidence": "medium",
                "what_would_change_its_mind": "A version that shows the counterevidence alongside the main claim.",
                "provenance": "synthesis",
            }
        ]
        payload["reasoning_traps"] = [
            {
                "label": "Comfortable Answer Detection",
                "risk": "The draft may reward agreeable wording instead of hard evidence.",
                "next_check": "Ask what would make the claim fail.",
                "confidence": "medium",
                "provenance": "reflection",
            }
        ]

    return payload


def test_optional_report_artifacts_render_and_validate(tmp_path: Path) -> None:
    from audit_report.markdown import render_markdown, validate_markdown, write_markdown_report

    payload = _base_payload(include_optional=True)
    markdown = render_markdown(payload)
    validation = validate_markdown(markdown, payload)
    written = write_markdown_report(payload, tmp_path / "artifact.pdf")

    assert validation["passed"] is True
    assert validation["issues"] == []
    assert "## Argument Map" in markdown
    assert "### Markdown Export" in markdown
    assert "```markdown" in markdown
    assert "### Argdown Export" not in markdown
    assert "```argdown" not in markdown
    assert "## Evidence Needed Next" in markdown
    assert "Note: check-worthy means worth verifying, not that the claim is false." in markdown
    assert "## Where the Analysts Disagreed" in markdown
    assert "## Reasoning Trap Checks" in markdown
    assert "## Factual Claims To Verify" in markdown
    assert "## Interpretive Claims" in markdown
    assert "## Causal Claims" in markdown
    assert "## Normative Claims" in markdown
    assert "## Policy Claims" in markdown
    assert markdown.count("Verification Priority") == 1
    assert "Suggested Queries" in markdown
    assert "Likely Source Types" in markdown
    assert "Support/Contrast Status" in markdown
    assert "Uncertainty Note" in markdown
    assert "trust grows when evidence boundaries are named clearly" in markdown
    assert written["markdown_path"].endswith("artifact.md")
    assert Path(written["markdown_path"]).exists()
    assert written["markdown_hash"]


def test_optional_report_artifacts_are_not_required_when_absent() -> None:
    from audit_report.markdown import render_markdown, validate_markdown

    payload = _base_payload(include_optional=False)
    markdown = render_markdown(payload)
    validation = validate_markdown(markdown, payload)

    assert validation["passed"] is True
    assert validation["issues"] == []
    assert "## Argument Map" not in markdown
    assert "## Evidence Needed Next" not in markdown
    assert "## Where the Analysts Disagreed" not in markdown
    assert "## Reasoning Trap Checks" not in markdown
