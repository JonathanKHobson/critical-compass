from __future__ import annotations

import json
from pathlib import Path

from audit_report.trust import (
    blind_spot_reminder_candidates,
    detect_reasoning_traps,
    human_loop_interruption_triggers,
    normalize_dissent_ledger,
    source_tool_trust_preflight,
)


ROOT = Path(__file__).resolve().parents[1]


def load_fixture(name: str) -> dict:
    return json.loads((ROOT / "audit_report" / "fixtures" / f"{name}.json").read_text(encoding="utf-8"))


def test_normalize_dissent_ledger_preserves_explicit_and_fallback_entries() -> None:
    data = {
        "advanced_audit": {
            "dissent_ledger": [
                {
                    "agent_name": "Methodologist",
                    "top_finding": "The sample is too small for broad claims.",
                    "strongest_disagreement": "The conclusion outruns the sample.",
                    "confidence": "high",
                    "what_would_change_mind": "A larger comparison sample would reduce the concern.",
                    "provenance": {"source": "advanced_audit.dissent_ledger[0]", "stage": "ledger", "notes": "explicit entry"},
                }
            ],
            "agents": [
                {
                    "name": "Consensus Reviewer",
                    "top_finding": "The structure is solid.",
                    "strongest_disagreement": "The conclusion may be too tidy.",
                    "confidence": 0.62,
                    "what_would_change_mind": "Direct quotation from affected stakeholders would help.",
                }
            ],
        },
        "analyses": [
            {
                "agent_name": "Consensus Reviewer",
                "primary_finding": "The structure is solid.",
                "counterpoint": "The conclusion may be too tidy.",
                "confidence": 0.62,
            }
        ],
    }

    ledger = normalize_dissent_ledger(data)

    assert ledger["present"] is True
    assert len(ledger["entries"]) == 2

    explicit = ledger["entries"][0]
    assert explicit["agent_name"] == "Methodologist"
    assert explicit["top_finding"] == "The sample is too small for broad claims."
    assert explicit["strongest_disagreement"] == "The conclusion outruns the sample."
    assert explicit["confidence"] == "high"
    assert explicit["provenance"]["source"] == "advanced_audit.dissent_ledger[0]"

    fallback = ledger["entries"][1]
    assert fallback["agent_name"] == "Consensus Reviewer"
    assert fallback["top_finding"] == "The structure is solid."
    assert fallback["strongest_disagreement"] == "The conclusion may be too tidy."
    assert fallback["confidence"] == "medium"
    assert fallback["provenance"]["stage"] == "agent_fallback"


def test_detect_reasoning_traps_uses_risk_language() -> None:
    data = {
        "text": "It is obvious the pilot survey proves the policy works, and the affected families are not quoted.",
        "findings": {"recommended_next_step": "Clearly move ahead now."},
        "assumptions": [{"assumption": "The pilot is representative."}],
    }

    traps = detect_reasoning_traps(data)

    assert traps["present"] is True
    labels = {item["label"] for item in traps["traps"]}
    assert "Comfortable-answer risk" in labels
    assert "Missing-voice risk" in labels
    for item in traps["traps"]:
        assert "risk" in item["risk"].lower()
        assert "false" not in item["risk"].lower()
        assert "failure" not in item["risk"].lower()
        assert item["next_check"]


def test_detect_reasoning_traps_includes_expanded_risks() -> None:
    data = {
        "text": (
            "Experts say the rate increased by 40 percent, but no baseline is provided. "
            "One example from a case study is treated as typical. By definition, the policy works because it works."
        )
    }

    traps = detect_reasoning_traps(data)

    assert traps["present"] is True
    labels = {item["label"] for item in traps["traps"]}
    assert "Base-rate neglect risk" in labels
    assert "Missing-denominator risk" in labels
    assert "Anecdotal-evidence risk" in labels
    assert "Authority-laundering risk" in labels
    assert "Circular-framing risk" in labels


def test_reasoning_traps_avoid_short_token_false_positives() -> None:
    safe = detect_reasoning_traps(
        {
            "text": (
                "The ordinary report provides information for reform and proportionate support. "
                "It names context, limits, and next checks without forcing a binary choice."
            )
        }
    )
    safe_labels = {item["label"] for item in safe["traps"]}
    assert "Binary-frame risk" not in safe_labels

    real = detect_reasoning_traps({"text": "Either we approve the program or the whole effort fails."})
    real_labels = {item["label"] for item in real["traps"]}
    assert "Binary-frame risk" in real_labels


def test_reasoning_traps_prioritize_high_severity_when_many_fire() -> None:
    traps = detect_reasoning_traps(
        {
            "text": (
                "Clearly one study caused the rate to increase by 40 percent with no baseline. "
                "Experts say one example is typical, but no affected voices are quoted. "
                "Either we scale or fail; by definition it works because it works for everyone."
            )
        }
    )["traps"]

    assert len(traps) >= 6
    first_five = traps[:5]
    assert all(item["severity"] == "high" for item in first_five)
    assert {item["label"] for item in first_five} >= {
        "Single-source risk",
        "Missing-voice risk",
        "Causation-leap risk",
        "Missing-denominator risk",
        "Authority-laundering risk",
    }


def test_source_tool_trust_preflight_reports_warnings_without_web_assumptions() -> None:
    preflight = source_tool_trust_preflight(
        {
            "status": "ready",
            "source_path": "/tmp/source.pdf",
            "source_id": "abc123",
            "page_count": 3,
            "text": "A short note with a few words only.",
            "extraction_method": "embedded_text",
            "ocr_used": False,
            "text_char_count": 34,
            "text_word_count": 7,
            "warnings": [],
        }
    )

    assert preflight["status"] == "warn"
    assert preflight["source_provenance"]["source_path"] == str(Path("/tmp/source.pdf").expanduser().resolve())
    assert preflight["consent_boundaries"]["local_only"] is True
    assert preflight["consent_boundaries"]["external_retrieval_allowed"] is False
    assert preflight["ocr_extraction_confidence"]["level"] == "low"
    assert any(item["code"] == "low_extraction_confidence" for item in preflight["warnings"])
    assert preflight["external_tool_trust"]["mode"] == "local_only"
    assert preflight["external_tool_trust"]["status"] == "trusted"


def test_source_tool_trust_red_team_fixture_blocks_prompt_injection() -> None:
    preflight = source_tool_trust_preflight(load_fixture("source_trust_prompt_injection"))

    assert preflight["status"] == "blocked"
    assert preflight["prompt_injection_checks"]["present"] is True
    codes = {item["code"] for item in preflight["prompt_injection_checks"]["checks"]}
    assert {"instruction_override", "tool_poisoning", "secret_exfiltration"} <= codes
    assert preflight["consent_boundaries"]["external_retrieval_allowed"] is False


def test_source_tool_trust_safe_fixture_has_no_prompt_injection_flags() -> None:
    preflight = source_tool_trust_preflight(load_fixture("source_trust_safe"))

    assert preflight["status"] == "ready"
    assert preflight["prompt_injection_checks"]["present"] is False
    assert preflight["ocr_extraction_confidence"]["level"] == "high"


def test_human_loop_interruption_triggers_return_bounded_actionable_prompts() -> None:
    triggers = human_loop_interruption_triggers(
        {
            "text": "It is obvious the policy works, but the affected families are not quoted and the pilot survey is doing all the work.",
            "assumptions": [{"assumption": "The pilot is representative."}],
            "schema_warnings": [{"field": "cis.plain_language_read"}],
            "missing_report_fields": [{"field": "cis.before_using_this_text"}],
        }
    )

    assert triggers["present"] is True
    assert 1 <= len(triggers["triggers"]) <= 5
    for item in triggers["triggers"]:
        assert set(item) >= {"id", "question", "risk", "next_check", "signals", "severity"}
        assert item["question"]
        assert item["risk"].lower().startswith("risk")
        assert item["next_check"]
        assert item["signals"]

    ids = {item["id"] for item in triggers["triggers"]}
    assert "comfortable_answer_detection" in ids
    assert "harmed_stakeholders" in ids
    assert "missing_affected_perspectives" in ids
    assert "contested_assumptions" in ids
    assert "report_critical_missing_context" in ids


def test_blind_spot_reminder_candidates_require_consent_and_avoid_sensitive_profiling() -> None:
    reminders = blind_spot_reminder_candidates(
        {
            "reasoning_traps": [
                {
                    "id": "comfortable_answer_detection",
                    "label": "Comfortable-answer risk",
                    "risk": "Risk of treating the easy answer as settled.",
                    "next_check": "Ask what would make this harder to defend.",
                }
            ],
            "human_loop_interruption_triggers": {
                "triggers": [
                    {
                        "id": "missing_affected_perspectives",
                        "question": "Whose perspective is missing?",
                    }
                ]
            },
        },
        text_type="policy",
    )

    assert reminders["present"] is True
    assert reminders["requires_explicit_consent"] is True
    assert reminders["sensitive_profile_blocked"] is False
    assert all(item["entity_type"] == "blind_spot_reminder" for item in reminders["reminders"])
    assert all(item["consent_required"] is True for item in reminders["reminders"])

    blocked = blind_spot_reminder_candidates(
        {
            "reasoning_traps": [
                {
                    "id": "sensitive_profile",
                    "label": "Religion profile",
                    "risk": "Risk tied to a user's religion.",
                    "next_check": "Do not profile this.",
                }
            ]
        }
    )

    assert blocked["present"] is False
    assert blocked["sensitive_profile_blocked"] is True
