from __future__ import annotations

from pathlib import Path

from scripts.smoke_36_questions_report import validate_golden_manifest


def test_validate_golden_manifest_requires_sections_and_pngs(tmp_path: Path) -> None:
    sections = {}
    for slug, title in {
        "argument_map": "Argument Map",
        "evidence_needed_next": "Evidence Needed Next",
        "dissent_ledger": "Where the Analysts Disagreed",
        "reasoning_traps": "Reasoning Trap Checks",
    }.items():
        image = tmp_path / f"{slug}.png"
        image.write_bytes(b"png")
        sections[slug] = {"section": title, "page": 3, "image_path": str(image)}

    validation = validate_golden_manifest({"sections": sections})

    assert validation["passed"] is True
    assert validation["issues"] == []


def test_validate_golden_manifest_flags_missing_artifacts(tmp_path: Path) -> None:
    image = tmp_path / "argument_map.jpg"
    image.write_bytes(b"not png")
    validation = validate_golden_manifest(
        {
            "sections": {
                "argument_map": {
                    "section": "Argument Map",
                    "page": 0,
                    "image_path": str(image),
                }
            }
        }
    )

    assert validation["passed"] is False
    checks = {item["check"] for item in validation["issues"]}
    assert {"sections", "image_format", "page_number"} <= checks
