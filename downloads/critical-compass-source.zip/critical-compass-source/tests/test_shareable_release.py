from __future__ import annotations

import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD_SCRIPT = ROOT / "scripts" / "build_shareable_release.py"
SHARE_DIR = ROOT / "dist" / "share"
GITHUB_DIR = SHARE_DIR / "github-pages"
MANUAL_DIR = SHARE_DIR / "manual-share"
MCP_EXPLAINER_SITE_DIR = SHARE_DIR / "mcp-explainer-site"
GITHUB_ZIP = SHARE_DIR / "critical-compass-github-pages-kit.zip"
MANUAL_ZIP = SHARE_DIR / "critical-compass-manual-share.zip"
EXAMPLE_HTML = "critical-compass-example-report.html"
EXAMPLE_PDF = "critical-compass-example-report.pdf"
EXAMPLE_MD = "critical-compass-example-report.md"
EXAMPLE_SCREENSHOT = "critical-compass-claude-output-screenshot.png"
RAW_EXAMPLE_PDF = ROOT / "reports" / "audit-report-20260417-182829.pdf"
RAW_EXAMPLE_SCREENSHOTS = tuple(
    Path("/Users/jonathanhobson/Pictures/Screenshots") / f"{index}.png" for index in range(1, 5)
)
SOURCE_ZIP = "critical-compass-source.zip"
MCP_EXPLAINER_HTML = "what-is-an-mcp.html"
MCP_EXPLAINER_PUBLIC_URL = "https://jonathankhobson.github.io/what-is-an-mcp/"
MCP_INFOGRAPHIC_STEMS = ("full", "1", "2", "3", "4")
AUTHOR_IMAGE = "assets/jonathan-kyle-hobson.png"
INSTALL_SCREENSHOTS = {
    "plugin": 9,
    "mcpb": 5,
    "skill": 5,
}
SENSITIVE_EXAMPLE_TERMS = [
    "Sarah",
    "Nonprofit AI Policy Framework",
    "audit-report-20260417-182829",
    "Let AI support, not replace",
    "That's not a compliance problem",
    "Seven Failure Patterns",
    "Five Shifts",
    "AI has fundamentally changed how decisions get made",
]


def run_builder() -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(BUILD_SCRIPT)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def run_pages_builder() -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(BUILD_SCRIPT), "--pages-only"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def assert_no_sidecars_or_bytecode(paths: list[Path]) -> None:
    forbidden_suffixes = {".pyc", ".pyo"}
    forbidden_names = {".DS_Store", "__pycache__"}
    offenders: list[str] = []
    for base in paths:
        if base.is_dir():
            for path in base.rglob("*"):
                if (
                    path.name.startswith("._")
                    or path.name.startswith(".__")
                    or path.name in forbidden_names
                    or path.suffix in forbidden_suffixes
                ):
                    offenders.append(str(path.relative_to(base)))
        else:
            with zipfile.ZipFile(base) as zf:
                for name in zf.namelist():
                    parts = Path(name).parts
                    if (
                        any(part.startswith("._") or part.startswith(".__") for part in parts)
                        or any(part in forbidden_names for part in parts)
                        or Path(name).suffix in forbidden_suffixes
                    ):
                        offenders.append(f"{base.name}:{name}")
    assert offenders == []


def test_shareable_release_builder_creates_github_and_manual_kits() -> None:
    result = run_builder()

    assert result.returncode == 0, result.stderr
    for path in [
        GITHUB_DIR / "index.html",
        GITHUB_DIR / MCP_EXPLAINER_HTML,
        GITHUB_DIR / "downloads" / "critical-compass-plugin.zip",
        GITHUB_DIR / "downloads" / "critical-compass-0.1.0.mcpb",
        GITHUB_DIR / "downloads" / "critical-compass.skill",
        GITHUB_DIR / "downloads" / "skill.zip",
        GITHUB_DIR / "downloads" / SOURCE_ZIP,
        GITHUB_DIR / "downloads" / "checksums.txt",
        GITHUB_DIR / "release-notes.md",
        GITHUB_DIR / "github-release-body.md",
        GITHUB_DIR / "examples" / EXAMPLE_HTML,
        GITHUB_DIR / "examples" / EXAMPLE_PDF,
        GITHUB_DIR / "examples" / EXAMPLE_MD,
        GITHUB_DIR / "examples" / EXAMPLE_SCREENSHOT,
        GITHUB_ZIP,
        MANUAL_DIR / "START_HERE.html",
        MANUAL_DIR / MCP_EXPLAINER_HTML,
        MANUAL_DIR / "START_HERE.md",
        MANUAL_DIR / "examples" / EXAMPLE_HTML,
        MANUAL_DIR / "examples" / EXAMPLE_PDF,
        MANUAL_DIR / "examples" / EXAMPLE_MD,
        MANUAL_DIR / "examples" / EXAMPLE_SCREENSHOT,
        MANUAL_DIR / "downloads" / "critical-compass-plugin.zip",
        MANUAL_DIR / "downloads" / "critical-compass-0.1.0.mcpb",
        MANUAL_DIR / "downloads" / "critical-compass.skill",
        MANUAL_DIR / "downloads" / "skill.zip",
        MANUAL_DIR / "downloads" / SOURCE_ZIP,
        MANUAL_DIR / "downloads" / "checksums.txt",
        MANUAL_DIR / "mcpb-install-diagnostics-prompt.md",
        MCP_EXPLAINER_SITE_DIR / "index.html",
        MCP_EXPLAINER_SITE_DIR / ".nojekyll",
        MANUAL_ZIP,
    ]:
        assert path.exists(), f"missing {path}"
    for group, count in INSTALL_SCREENSHOTS.items():
        github_files = sorted((GITHUB_DIR / "install-guide" / group).glob("*.png"))
        manual_files = sorted((MANUAL_DIR / "install-guide" / group).glob("*.png"))
        assert len(github_files) == count
        assert len(manual_files) == count
    for path in [
        GITHUB_DIR / AUTHOR_IMAGE,
        MANUAL_DIR / AUTHOR_IMAGE,
    ]:
        assert path.exists(), f"missing author asset {path}"
    for image_stem in MCP_INFOGRAPHIC_STEMS:
        assert (MCP_EXPLAINER_SITE_DIR / "mcp-infographic" / f"{image_stem}.webp").exists()
        assert (MCP_EXPLAINER_SITE_DIR / "mcp-infographic" / f"{image_stem}.jpg").exists()


def test_shareable_release_landing_pages_explain_install_choices() -> None:
    result = run_pages_builder()
    assert result.returncode == 0, result.stderr

    github_html = (GITHUB_DIR / "index.html").read_text(encoding="utf-8")
    manual_html = (MANUAL_DIR / "START_HERE.html").read_text(encoding="utf-8")
    combined = github_html + manual_html

    for phrase in [
        "What is Critical Compass?",
        "pressure-test written work before it has to hold up under scrutiny",
        "critical-thinking toolbox for people who need written work to hold up under scrutiny",
        "Pick Your Path",
        "I want a fast first read",
        "I need the full audit",
        "I want questions and calibration",
        "I need a shareable deliverable",
        "I only want the prompt layer",
        "Your First Prompt",
        "Once Critical Compass is installed, copy one of these prompts into your AI to get started right away.",
        "AI-assisted install prompt",
        "You can install more than one.",
        "prompt-only version available too",
        "Using Codex? See the FAQ tab for technical-user guidance.",
        "Claude Cowork Plugin",
        "Claude Desktop Extension",
        "Skill / Prompt-Only Alternative",
        "Skill File or Skill Zip",
        "Download Plugin",
        "Download Extension",
        "Download Skill",
        "Download Skill Zip",
        "&rarr; How to install",
        "About",
        "Install Guide",
        "FAQ",
        "What Is Critical Compass?",
        "How It's Built",
        "What's Inside",
        "How I Use It",
        "validate_report_payload",
        "About the author",
        "Jonathan Kyle Hobson",
        "UX researcher, product strategist, and AI tool builder",
        "10+ years",
        "master's degree in User Experience from Arizona State University",
        "high-stakes writing deserves",
        "Connect on LinkedIn",
        "https://www.linkedin.com/in/jonathankylehobson/",
        "Frequently Asked Questions",
        "Does this work with Codex?",
        "Critical Compass can work with Codex because Codex can use local MCPs, skills, and plugins",
        "does not yet provide a one-click Codex install path",
        "What is an MCP connector or extension?",
        "Model Context Protocol",
        "Claude may call the local tool connection an MCP, connector, or extension",
        "Critical Compass's extension is the MCP connector",
        "Learn more about MCPs.",
        "What is the difference between the plugin, extension, and skill?",
        "Plugin zip:",
        "Extension file:",
        "Skill:",
        "It includes the MCP/extension, skill, and predefined agents.",
        "gives Claude tools and bundled resources so it can do more with fewer tokens",
        "prompt-only alternative Claude can read without the MCP",
        "Is Critical Compass safe to install?",
        "Downloading anything from the internet carries real risk",
        "runs locally on your machine",
        "requires no API key",
        "no third-party tool is zero risk",
        "Learn more about MCP risks.",
        "Do I need a GitHub account to download?",
        "Download source files",
        "Download Source Zip",
        SOURCE_ZIP,
        "Advanced: Verify Download",
        "AI-Assisted Install Prompt",
        "Copy install prompt",
        "Manual config install is a technical fallback for people who have installed MCPs this way before.",
        "Before Manual Config Edits",
        "If the Expected UI Is Missing",
        "Back Out Safely",
        "After Install, Verify",
        "writes UTF-8 without a BOM",
        "verifies that no existing MCPs disappeared",
        "Which operating system are you on?",
        "determine the current add/install method",
        "Use current docs or visible client UI when the install method is unclear.",
        "technical fallback only",
        "If I had other MCPs before install, confirm they are still present.",
        "Claude Desktop on macOS:",
        "%APPDATA%\\Claude\\claude_desktop_config.json",
        "~/.codex/config.toml",
        "%USERPROFILE%\\.codex\\config.toml",
        "Claude Code project MCP config: .mcp.json",
        "View Claude Artifact mirror",
        "https://claude.ai/public/artifacts/9e50e78b-3877-40c0-855b-07031eb15c95",
        "Example",
        "See what a finished Critical Compass audit can look like.",
        "Open HTML Example (new tab)",
        "Download PDF Example",
        "View Markdown Example (new tab)",
        "examples/critical-compass-example-report.html",
        "examples/critical-compass-example-report.pdf",
        "examples/critical-compass-claude-output-screenshot.png",
        "Stitched screenshot of a Claude conversation showing Critical Compass quick feedback output",
        "Claude Conversation Snapshot",
        "This is a direct screenshot from Jonathan's Claude conversation using Critical Compass",
        "Copy diagnostics prompt",
        "If installation fails, copy this prompt",
        "critical-compass-plugin.zip",
        "critical-compass-0.1.0.mcpb",
        "critical-compass.skill",
        "skill.zip",
        "Skill Audit",
        "Quick Audit with MCP",
        "Classroom Bias Audit",
        "Full Standard Audit with MCP",
        "Advanced Audit with Multi-Agent Support",
        "Coaching Mode (Skill Only)",
        "When to use:",
        "Copy prompt",
        "I have the Critical Compass skill installed.",
        "Before you begin the audit, ask me the following questions one at a time",
        "Critical Integrity Snapshot (plain-language read + five-dimension table)",
        "I have the Critical Compass MCP connector/extension active.",
        "Start by calling critical_compass_overview to orient yourself on the available",
        "After I answer, run audit_text on the content below. Return:",
        "Output purpose: classroom bias-audit reflection",
        "Do not run an advanced panel review, multi-agent review, or web research.",
        "Call critical_compass_overview first to confirm the right audit path and",
        "After I answer, run audit_text on the content below. Return the full audit:",
        "I want to run an advanced audit with multi-agent support and human-in-the-loop",
        "Step 2 - Define agents: Call define_audit_agents for this content.",
        "Step 3 - Independent analyses: Call run_independent_audit_analysis for each",
        "Step 4 - Map tensions: Call map_audit_tensions to surface where agents",
        "Step 5 - Structured debate: Call run_audit_debate on the highest-tension finding.",
        "Step 6 - Synthesize: Call synthesize_audit_verdict to produce a final verdict,",
        "Step 8 - Report: After human-in-the-loop is complete, use the",
        "validate_report_payload first",
        "If I want a browser-friendly version too, provide the generated viewer",
        "I want coaching mode - not an audit of someone else&#x27;s writing.",
        "After I answer, use the Critical Compass coaching rewrite mode. Give me:",
        "My goal with this writing:",
    ]:
        assert phrase in combined
    assert "<img" in github_html
    assert 'data-tab-target="about"' in github_html
    assert 'data-tab-target="install"' in github_html
    assert 'data-tab-target="example"' in github_html
    assert 'data-tab-target="faq"' in github_html
    assert 'data-tab-target="advanced"' in github_html
    assert "About &amp; FAQ" not in github_html
    assert "About &amp; FAQ" not in manual_html
    nav_order = [
        'id="tab-get-started"',
        'id="tab-about"',
        'id="tab-install"',
        'id="tab-example"',
        'id="tab-faq"',
        'id="tab-advanced"',
    ]
    assert [github_html.index(marker) for marker in nav_order] == sorted(github_html.index(marker) for marker in nav_order)
    assert 'href="#install-cowork"' in github_html
    assert 'href="#install-desktop"' in github_html
    assert 'href="#install-skill"' in github_html
    assert "Tested Claude Surfaces" in github_html
    assert "not claimed for Claude.ai in a web browser" in github_html
    assert "install paths have been verified for Claude Desktop, Claude Cowork, and Claude Code" not in combined
    assert "These install paths have been verified" not in combined
    assert "These screenshots show the tested UI. If your app does not show this path, stop and use the diagnostic prompt instead of improvising." in github_html
    assert "If you only see Skills and Connectors" in github_html
    assert "do not hand-edit config as a beginner workaround" in github_html
    assert "Do not improvise in Connectors unless that surface clearly accepts the exact file type you downloaded" in github_html
    assert f'href="{MCP_EXPLAINER_PUBLIC_URL}" target="_blank" rel="noopener"' in github_html
    assert f'href="{MCP_EXPLAINER_PUBLIC_URL}#mcp-risks" target="_blank" rel="noopener"' in github_html
    assert f'src="{AUTHOR_IMAGE}" alt="Jonathan Kyle Hobson"' in github_html
    assert f'src="{AUTHOR_IMAGE}" alt="Jonathan Kyle Hobson"' in manual_html
    assert github_html.index("About the author") < github_html.index("Frequently Asked Questions")
    assert github_html.index("Frequently Asked Questions") < github_html.index("What does Critical Compass actually do?")
    assert f'href="examples/{EXAMPLE_HTML}" target="_blank" rel="noopener"' in github_html
    assert f'href="examples/{EXAMPLE_MD}" target="_blank" rel="noopener"' in github_html
    assert f'src="examples/{EXAMPLE_SCREENSHOT}"' in github_html
    assert 'class="example-output-image"' in github_html
    assert github_html.index("<h2>Finished Audit Snapshot</h2>") < github_html.index(f'src="examples/{EXAMPLE_SCREENSHOT}"')
    assert github_html.index("<h2>Finished Audit Snapshot</h2>") < github_html.index("<h2>Claude Conversation Snapshot</h2>")
    assert github_html.index("<h2>Claude Conversation Snapshot</h2>") < github_html.index(f'src="examples/{EXAMPLE_SCREENSHOT}"')
    assert 'const installAnchorIds = new Set(["install-cowork", "install-desktop", "install-skill"])' in github_html
    assert 'href="#diagnostics-prompt"' in github_html
    assert 'const advancedAnchorIds = new Set(["ai-install-prompt", "diagnostics-prompt"])' in github_html
    assert 'history.replaceState(null, "", "#" + targetPanel.id)' in github_html
    assert "https://github.com/JonathanKHobson/critical-compass/releases/download/v" in github_html
    assert 'href="downloads/critical-compass-plugin.zip"' in manual_html
    assert "Use the quick audit prompt for a plain-language risk read" in github_html
    assert "Use the classroom bias-audit prompt so students supply the same audience" in github_html
    assert "Use the report-ready workflow after an audit payload has been validated" in github_html
    assert "Download <code>critical-compass-plugin.zip</code>." in github_html
    assert "Download <code>critical-compass-0.1.0.mcpb</code>." in github_html
    assert "Download <code>critical-compass.skill</code> or <code>skill.zip</code>." in github_html
    assert 'aria-label="Claude Cowork plugin install screenshots"' in github_html
    assert 'aria-label="Claude Desktop extension install screenshots"' in github_html
    assert 'aria-label="Critical Compass skill install screenshots"' in github_html
    for group, count in INSTALL_SCREENSHOTS.items():
        assert github_html.count(f'src="install-guide/{group}/') == count
        assert manual_html.count(f'src="install-guide/{group}/') == count
    assert f'href="https://github.com/JonathanKHobson/critical-compass/releases/download/v0.1.0-beta.11/{SOURCE_ZIP}" download' in github_html
    assert f'href="downloads/{SOURCE_ZIP}" download' in manual_html
    advanced_section = github_html[github_html.index('<section id="advanced"') :]
    before_advanced = github_html[: github_html.index('<section id="advanced"')]
    assert SOURCE_ZIP in advanced_section
    assert SOURCE_ZIP not in before_advanced
    intro_to_table = github_html[github_html.index("What is Critical Compass?") : github_html.index("Pick Your Path")]
    for label in ["Download Plugin", "Download Extension", "Download Skill", "Download Skill Zip"]:
        assert label in intro_to_table
    assert "github-release-body.md" not in combined
    assert "claude-artifact-builder-prompt.md" not in combined
    assert "Create a Claude Artifact version" not in combined
    assert "A Claude AI plugin" not in combined
    assert "Start Here: Pick Your Path" not in combined
    assert "Codex support is being confirmed" not in combined
    assert "Using Codex? See the FAQ tab for status." not in combined
    ai_prompt_section = github_html[
        github_html.index('id="ai-install-prompt"') : github_html.index('<div class="card">\n        <h2>Diagnostics Prompt</h2>')
    ].lower()
    for forbidden_prompt_phrase in [
        "assisted manual upload",
        "manual upload",
        "upload/import",
        "plugin upload flow",
        "skills upload flow",
    ]:
        assert forbidden_prompt_phrase not in ai_prompt_section
    assert "Download MCPB" not in combined
    assert "Use the MCPB" not in combined
    assert "Do I need to install all three files?" not in combined
    assert "Why does Claude show a warning during install?" not in combined
    assert "Install only one" not in combined
    assert "He built Critical Compass" not in combined
    assert "All internet-downloaded MCPs and plugins carry some risk" not in combined
    assert "Northern Arizona" not in combined
    assert "You only need one file" not in combined
    assert "fallback instructions" not in combined
    assert "offline fallback" not in combined.lower()
    assert "add-on" not in combined
    assert "reference file" not in combined.lower()
    assert "offline reference" not in combined.lower()
    assert "Advanced Audit with MCP" not in combined
    assert "Claude Code / Agentic Workflow" not in combined
    assert "Skill Mode Only" not in combined
    decision_table = github_html[github_html.index("<h2>Pick Your Path</h2>") : github_html.index("</table>", github_html.index("<h2>Pick Your Path</h2>"))]
    assert "Codex" not in decision_table
    assert "<h2>Checksums</h2>" not in combined
    get_started_section = github_html[github_html.index('<section id="get-started"') : github_html.index('<section id="example"')]
    assert get_started_section.index("<h2>Pick Your Path</h2>") < get_started_section.index("<h2>Your First Prompt</h2>")
    assert get_started_section.count("When to use:</strong>") == 6
    assert get_started_section.count("<textarea id=") == 6
    assert get_started_section.count(">Copy prompt</button>") == 6
    for marker in [
        'id="copy-skill-audit"',
        'id="copy-quick-audit-mcp"',
        'id="copy-full-standard-audit-mcp"',
        'id="copy-advanced-audit-multi-agent"',
        'id="copy-coaching-mode-skill"',
        'id="prompt-skill-audit"',
        'id="prompt-quick-audit-mcp"',
        'id="prompt-full-standard-audit-mcp"',
        'id="prompt-advanced-audit-multi-agent"',
        'id="prompt-coaching-mode-skill"',
    ]:
        assert marker in get_started_section
    prompt_order = [
        "<h2>Skill Audit</h2>",
        "<h2>Quick Audit with MCP</h2>",
        "<h2>Full Standard Audit with MCP</h2>",
        "<h2>Advanced Audit with Multi-Agent Support</h2>",
        "<h2>Coaching Mode (Skill Only)</h2>",
    ]
    assert [get_started_section.index(marker) for marker in prompt_order] == sorted(get_started_section.index(marker) for marker in prompt_order)
    for marker in [
        'wireCopyButton("copy-skill-audit", "prompt-skill-audit");',
        'wireCopyButton("copy-quick-audit-mcp", "prompt-quick-audit-mcp");',
        'wireCopyButton("copy-full-standard-audit-mcp", "prompt-full-standard-audit-mcp");',
        'wireCopyButton("copy-advanced-audit-multi-agent", "prompt-advanced-audit-multi-agent");',
        'wireCopyButton("copy-coaching-mode-skill", "prompt-coaching-mode-skill");',
    ]:
        assert marker in github_html


def test_shareable_release_source_zip_is_reviewable_and_clean() -> None:
    run_builder()

    source_zip = GITHUB_DIR / "downloads" / SOURCE_ZIP
    assert source_zip.exists()
    checksums = (GITHUB_DIR / "downloads" / "checksums.txt").read_text(encoding="utf-8")
    assert SOURCE_ZIP in checksums

    with zipfile.ZipFile(source_zip) as zf:
        names = zf.namelist()
        assert "critical-compass-source/scripts/build_shareable_release.py" in names
        assert "critical-compass-source/audit_report/models.py" in names
        assert "critical-compass-source/server.py" in names
        forbidden_parts = {
            "dist",
            "reports",
            "__pycache__",
            ".pytest_cache",
            ".mypy_cache",
            ".venv",
            "venv",
            "node_modules",
        }
        offenders: list[str] = []
        for name in names:
            parts = Path(name).parts
            if any(part in forbidden_parts for part in parts):
                offenders.append(name)
            if (
                any(part.startswith("._") or part.startswith(".__") for part in parts)
                or any(part.startswith(".env") for part in parts)
                or any(part == ".DS_Store" for part in parts)
                or Path(name).suffix in {".pyc", ".pyo"}
                or Path(name).name in {"critical-compass-state.sqlite", "state.sqlite", "state.sqlite3", "state.db"}
            ):
                offenders.append(name)
        assert offenders == []


def test_shareable_release_mcp_explainer_page() -> None:
    run_builder()

    github_redirect = (GITHUB_DIR / MCP_EXPLAINER_HTML).read_text(encoding="utf-8")
    manual_redirect = (MANUAL_DIR / MCP_EXPLAINER_HTML).read_text(encoding="utf-8")
    explainer_page = (MCP_EXPLAINER_SITE_DIR / "index.html").read_text(encoding="utf-8")

    for redirect in [github_redirect, manual_redirect]:
        assert f'<link rel="canonical" href="{MCP_EXPLAINER_PUBLIC_URL}">' in redirect
        assert f'url={MCP_EXPLAINER_PUBLIC_URL}' in redirect
        assert "Diving Deeper" not in redirect
        assert "mcp-infographic" not in redirect
    for phrase in [
        "What is an MCP?",
        "Model Context Protocol",
        "toolbox",
        "filing cabinet",
        "connector",
        "extension",
        "MCPs can be local or remote",
        "trusted sources",
        'href="#short-version">Keep scrolling &darr;</a>',
        'id="short-version"',
        'id="mcp-risks"',
        "Diving Deeper: What files might I see inside an MCP?",
        "Can an MCP be local or remote?",
        "Is an MCP the same as a plugin or skill?",
        "What should I check before installing one?",
        "Back to Compass Suite",
        "Return to Compass Suite",
        "How This Applies to the Compass Suite",
    ]:
        assert phrase in explainer_page
    for phrase in [
        ".json",
        ".yaml",
        ".yml",
        ".py",
        ".ts",
        ".js",
        ".md",
        ".csv",
        ".sql",
        ".sqlite",
        ".db",
        ".env",
    ]:
        assert phrase in explainer_page
    for image_stem in MCP_INFOGRAPHIC_STEMS:
        assert f'srcset="mcp-infographic/{image_stem}.webp"' in explainer_page
        assert f'src="mcp-infographic/{image_stem}.jpg"' in explainer_page
        assert (MCP_EXPLAINER_SITE_DIR / "mcp-infographic" / f"{image_stem}.webp").exists()
        assert (MCP_EXPLAINER_SITE_DIR / "mcp-infographic" / f"{image_stem}.jpg").exists()
    assert not list((MCP_EXPLAINER_SITE_DIR / "mcp-infographic").glob("*.png"))
    assert not (GITHUB_DIR / "mcp-infographic").exists()
    assert not (MANUAL_DIR / "mcp-infographic").exists()
    assert explainer_page.index("mcp-infographic/1.webp") < explainer_page.index("mcp-infographic/2.webp")
    assert explainer_page.index("mcp-infographic/2.webp") < explainer_page.index("mcp-infographic/3.webp")
    assert explainer_page.index("mcp-infographic/3.webp") < explainer_page.index("mcp-infographic/4.webp")
    assert explainer_page.index("mcp-infographic/4.webp") < explainer_page.index("mcp-infographic/full.webp")
    assert explainer_page.index("mcp-infographic/full.webp") < explainer_page.index('id="mcp-risks"')
    assert explainer_page.index('id="short-version"') < explainer_page.index("mcp-infographic/full.webp")
    assert "Full infographic explaining MCP" not in explainer_page[: explainer_page.index('id="short-version"')]
    assert 'fetchpriority="high"' not in explainer_page
    assert 'src="mcp-infographic/full.jpg" alt="Full infographic explaining MCP as giving AI the keys to the office" width="1600" height="893" loading="lazy" decoding="async"' in explainer_page
    assert 'loading="lazy"' in explainer_page
    assert 'decoding="async"' in explainer_page
    explainer_main = explainer_page[: explainer_page.index("<footer")]
    assert "https://jonathankhobson.github.io/critical-compass/" not in explainer_main
    total_webp_size = sum((MCP_EXPLAINER_SITE_DIR / "mcp-infographic" / f"{stem}.webp").stat().st_size for stem in MCP_INFOGRAPHIC_STEMS)
    assert total_webp_size < 700 * 1024
    assert "MCPs are locally installed tools" not in explainer_page
    assert "MCPs are always local" not in explainer_page


def test_shareable_release_examples_are_public_and_sanitized() -> None:
    run_builder()

    github_html = (GITHUB_DIR / "examples" / EXAMPLE_HTML).read_text(encoding="utf-8")
    github_md = (GITHUB_DIR / "examples" / EXAMPLE_MD).read_text(encoding="utf-8")
    manual_html = (MANUAL_DIR / "examples" / EXAMPLE_HTML).read_text(encoding="utf-8")
    manual_md = (MANUAL_DIR / "examples" / EXAMPLE_MD).read_text(encoding="utf-8")
    github_pdf = GITHUB_DIR / "examples" / EXAMPLE_PDF
    manual_pdf = MANUAL_DIR / "examples" / EXAMPLE_PDF
    github_screenshot = GITHUB_DIR / "examples" / EXAMPLE_SCREENSHOT
    manual_screenshot = MANUAL_DIR / "examples" / EXAMPLE_SCREENSHOT
    combined = github_html + github_md + manual_html + manual_md

    for phrase in [
        "Redacted Nonprofit Policy Draft - Critical Compass Example Audit",
        "This public example is redacted to protect unpublished source material.",
        "Back to Critical Compass download page",
        "Moderate Integrity",
        "71/100",
        "[redacted source excerpt]",
    ]:
        assert phrase in combined
    for term in SENSITIVE_EXAMPLE_TERMS:
        assert term.casefold() not in combined.casefold()
    assert 'id="public-example-note"' in github_html
    assert github_html.index('id="public-example-note"') < github_html.index("<main>")
    assert '<main>\n    <section class="callout" id="public-example-note">' not in github_html
    assert "file://" not in github_html
    assert "[redacted-local-path]" not in github_html
    assert "artifact-links" not in github_html
    assert "main > div { min-width: 0; }" in github_html
    assert "..." not in combined
    for broken_fragment in [
        "audiences need differe",
        "why basic data go",
        "set appropriate expecta",
        "gap that preven",
        "would stre",
        "diverse organizatio",
    ]:
        assert broken_fragment not in combined

    nav_match = re.search(r'<nav aria-label="Artifact sections">(.*?)</nav>', github_html)
    assert nav_match is not None
    for target_id in re.findall(r'href="#([^"]+)"', nav_match.group(1)):
        assert f'id="{target_id}"' in github_html
    for missing_nav in ['href="#external-fact-checks"', 'href="#dissent"', 'href="#trust"']:
        assert missing_nav not in github_html

    raw_pdf_bytes = RAW_EXAMPLE_PDF.read_bytes()
    assert github_pdf.read_bytes() == raw_pdf_bytes
    assert manual_pdf.read_bytes() == raw_pdf_bytes
    assert manual_screenshot.read_bytes() == github_screenshot.read_bytes()

    try:
        from PIL import Image  # pylint: disable=import-error,import-outside-toplevel
    except Exception:
        Image = None
    if Image:
        source_sizes: list[tuple[int, int]] = []
        for source in RAW_EXAMPLE_SCREENSHOTS:
            if not source.exists():
                return
            with Image.open(source) as source_image:
                source_sizes.append(source_image.size)
        with Image.open(github_screenshot) as image:
            assert image.width == max(width for width, _ in source_sizes)
            assert image.height == sum(height for _, height in source_sizes)


def test_shareable_release_artifact_prompt_is_removed() -> None:
    run_builder()

    assert not (GITHUB_DIR / "claude-artifact-builder-prompt.md").exists()
    assert not (MANUAL_DIR / "claude-artifact-builder-prompt.md").exists()


def test_shareable_release_screenshot_pipeline_preserves_authentic_capture() -> None:
    script = BUILD_SCRIPT.read_text(encoding="utf-8")
    screenshot_pipeline = script[
        script.index("def _build_example_output_screenshot") : script.index("def _build_mcp_infographic")
    ]

    for forbidden in [
        "ImageDraw",
        "ImageFont",
        "_draw_redacted_text",
        "_redact_example_screenshot",
        "Redacted example draft - Public screenshot",
    ]:
        assert forbidden not in script
    for forbidden in ["resized", ".resize(", "LANCZOS"]:
        assert forbidden not in screenshot_pipeline


def test_shareable_release_zips_are_clean_and_contain_expected_roots() -> None:
    run_builder()

    assert_no_sidecars_or_bytecode([GITHUB_DIR, MANUAL_DIR, MCP_EXPLAINER_SITE_DIR, GITHUB_ZIP, MANUAL_ZIP])
    with zipfile.ZipFile(GITHUB_ZIP) as zf:
        names = zf.namelist()
        assert "critical-compass-github-pages-kit/index.html" in names
        assert f"critical-compass-github-pages-kit/{MCP_EXPLAINER_HTML}" in names
        assert not any(name.startswith("critical-compass-github-pages-kit/mcp-infographic/") for name in names)
        assert f"critical-compass-github-pages-kit/{AUTHOR_IMAGE}" in names
        assert "critical-compass-github-pages-kit/install-guide/plugin/plugin-01-open-claude-code.png" in names
        assert "critical-compass-github-pages-kit/install-guide/mcpb/mcpb-01-download.png" in names
        assert "critical-compass-github-pages-kit/install-guide/skill/skill-01-open-skills.png" in names
        assert "critical-compass-github-pages-kit/claude-artifact-builder-prompt.md" not in names
        assert f"critical-compass-github-pages-kit/examples/{EXAMPLE_HTML}" in names
        assert f"critical-compass-github-pages-kit/examples/{EXAMPLE_PDF}" in names
        assert f"critical-compass-github-pages-kit/examples/{EXAMPLE_SCREENSHOT}" in names
        assert "critical-compass-github-pages-kit/downloads/critical-compass-plugin.zip" in names
        assert f"critical-compass-github-pages-kit/downloads/{SOURCE_ZIP}" in names
    with zipfile.ZipFile(MANUAL_ZIP) as zf:
        names = zf.namelist()
        assert "critical-compass-manual-share/START_HERE.html" in names
        assert f"critical-compass-manual-share/{MCP_EXPLAINER_HTML}" in names
        assert not any(name.startswith("critical-compass-manual-share/mcp-infographic/") for name in names)
        assert f"critical-compass-manual-share/{AUTHOR_IMAGE}" in names
        assert "critical-compass-manual-share/install-guide/plugin/plugin-01-open-claude-code.png" in names
        assert "critical-compass-manual-share/install-guide/mcpb/mcpb-01-download.png" in names
        assert "critical-compass-manual-share/install-guide/skill/skill-01-open-skills.png" in names
        assert "critical-compass-manual-share/claude-artifact-builder-prompt.md" not in names
        assert f"critical-compass-manual-share/examples/{EXAMPLE_HTML}" in names
        assert f"critical-compass-manual-share/examples/{EXAMPLE_PDF}" in names
        assert f"critical-compass-manual-share/examples/{EXAMPLE_SCREENSHOT}" in names
        assert "critical-compass-manual-share/downloads/critical-compass-plugin.zip" in names
        assert f"critical-compass-manual-share/downloads/{SOURCE_ZIP}" in names


def test_shareable_release_embedded_plugin_shape_and_agent_frontmatter() -> None:
    run_builder()

    plugin_zip = GITHUB_DIR / "downloads" / "critical-compass-plugin.zip"
    with zipfile.ZipFile(plugin_zip) as zf:
        names = zf.namelist()
        roots = sorted({name.split("/", 1)[0] for name in names if "/" in name})
        assert roots == ["critical-compass-plugin"]
        manifest = json.loads(zf.read("critical-compass-plugin/.claude-plugin/plugin.json"))
        assert manifest["name"] == "critical-compass"
        assert manifest["version"] == "0.1.0-beta.11"
        assert "critical-compass-plugin/skills/critical-compass/references/activity-layer.md" in names
        agent_names = [name for name in names if name.startswith("critical-compass-plugin/agents/") and name.endswith(".md")]
        assert len(agent_names) == 5
        for name in agent_names:
            text = zf.read(name).decode("utf-8")
            frontmatter = text.split("---", 2)[1]
            for required in ["name:", "description: >", "model:", "color:"]:
                assert required in frontmatter
            assert "<example>" not in frontmatter


def test_packaging_lessons_are_recorded_in_codex_skills() -> None:
    skill_paths = {
        "local_data": Path("/Users/jonathanhobson/.codex/skills/local-data-mcp-builder/SKILL.md"),
        "debugging": Path("/Users/jonathanhobson/.codex/skills/local-mcp-debugging/SKILL.md"),
        "critical": Path("/Users/jonathanhobson/.codex/skills/critical-compass/SKILL.md"),
    }
    missing = [name for name, path in skill_paths.items() if not path.exists()]
    if missing:
        raise AssertionError(f"missing local Codex skills: {missing}")

    local_data = skill_paths["local_data"].read_text(encoding="utf-8")
    debugging = skill_paths["debugging"].read_text(encoding="utf-8")
    critical = skill_paths["critical"].read_text(encoding="utf-8")

    assert "MCPB/plugin/shareable bundles" in local_data
    assert "single top-level folder" in debugging
    assert "strict YAML frontmatter" in debugging
    assert "AppleDouble sidecars" in debugging
    assert "dist/share/" in critical
