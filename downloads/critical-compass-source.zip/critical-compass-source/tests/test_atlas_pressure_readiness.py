from __future__ import annotations

import json
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"
SCENARIOS_PATH = ROOT / "support" / "evals" / "atlas_pressure_test_scenarios.json"
OUTPUT_AUDIT_PATH = ROOT / "support" / "evals" / "atlas_pressure_test_output_audit.json"
PRACTICE_GATE_PATH = ROOT / "support" / "evals" / "practice_activity_tool_gate.json"
GAP_FILL_PATH = ROOT / "support" / "library" / "atlas-curated-gap-fill.pack.json"


def install_fake_mcp_modules() -> None:
    if "audit_report" not in sys.modules:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]
        audit_report_module.generate_audit_artifact_viewer = lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None}
        audit_report_module.generate_audit_report = lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None}
        audit_report_module.prepare_audit_source = lambda *_args, **_kwargs: {"status": "not_run", "text": ""}
        audit_report_module.validate_report_payload = lambda *_args, **_kwargs: {"qa_status": "not_run", "writes_files": False}
        sys.modules["audit_report"] = audit_report_module

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        ai_data_audit_language,
        audit_text_payload,
        critical_compass_overview_payload,
        kb_no_result_recovery,
        list_agent_personas_payload,
        practice_suggestions_for_context,
        suggest_next_steps_payload,
    )

    return {
        "Repository": Repository,
        "ai_data_audit_language": ai_data_audit_language,
        "audit_text_payload": audit_text_payload,
        "critical_compass_overview_payload": critical_compass_overview_payload,
        "kb_no_result_recovery": kb_no_result_recovery,
        "list_agent_personas_payload": list_agent_personas_payload,
        "practice_suggestions_for_context": practice_suggestions_for_context,
        "suggest_next_steps_payload": suggest_next_steps_payload,
    }


def test_atlas_pressure_test_scenarios_cover_required_public_cases() -> None:
    data = json.loads(SCENARIOS_PATH.read_text(encoding="utf-8"))
    scenarios = data["scenarios"]
    ids = {item["id"] for item in scenarios}
    decisions = {item["expected_decision"] for item in scenarios}

    assert data["resource_id"] == "critical_compass.atlas_pressure_test_scenarios.v1"
    assert ids == {
        "advocacy_copy_missing_voice",
        "public_statement_accountability_gap",
        "grant_impact_claim_metric_bias",
        "article_review_source_gap",
        "ai_generated_summary_provenance_gap",
        "research_adjacent_summary_external_validity",
    }
    assert decisions <= {"Trust", "Revise", "Verify", "Reframe"}
    assert all(item["pass_fail_checks"] for item in scenarios)
    assert all("expected_surfaces" in item for item in scenarios)
    assert "No scenario requires a new MCP tool." in data["global_guardrails"]


def test_output_audit_fixture_covers_every_pressure_test_scenario() -> None:
    scenarios = json.loads(SCENARIOS_PATH.read_text(encoding="utf-8"))["scenarios"]
    audit = json.loads(OUTPUT_AUDIT_PATH.read_text(encoding="utf-8"))
    scenario_ids = {item["id"] for item in scenarios}
    audit_ids = {item["scenario_id"] for item in audit["scenario_audits"]}

    assert audit["resource_id"] == "critical_compass.atlas_pressure_test_output_audit.v1"
    assert audit_ids == scenario_ids
    assert any("worth verifying, not false" in check for check in audit["global_acceptance_checks"])
    assert all("decision_usefulness" in item for item in audit["scenario_audits"])


def test_pressure_test_readiness_kit_is_exposed_as_scaffold_resource() -> None:
    symbols = load_server_symbols()
    overview = symbols["critical_compass_overview_payload"](topic="quick_start")
    resources = overview["workflow_resources"]["resources"]
    by_id = {item["id"]: item for item in resources}

    assert "pressure_test_readiness_kit" in by_id
    assert by_id["pressure_test_readiness_kit"]["path"] == "pressure-test-readiness-kit.md"
    assert Path(by_id["pressure_test_readiness_kit"]["absolute_path"]).exists()


def test_curated_atlas_gap_fill_pack_is_conservative_and_lookup_ready() -> None:
    symbols = load_server_symbols()
    pack = json.loads(GAP_FILL_PATH.read_text(encoding="utf-8"))
    ids = {item["entry_id"] for item in pack}

    assert "ct:biases:ai-data:hallucination-confidence-risk" in ids
    assert "ct:biases:research-evidence:outcome-reporting-bias" in ids
    assert all(item["kind"] == "bias" for item in pack)
    assert all(item["category"] == "biases" for item in pack)
    assert not any("persona:" in " ".join(item.get("tags", [])) for item in pack)
    assert not any(item["collection"] == "framework" for item in pack)

    repo = symbols["Repository"](DB_PATH)
    try:
        assert repo.lookup_bias("Citation bias")["title"] == "Citation bias"
        assert repo.lookup_bias("Metric or benchmark bias")["title"] == "Metric or benchmark bias"
    finally:
        repo.close()


def test_ai_generated_audits_include_precise_ai_data_language_without_retrieval() -> None:
    symbols = load_server_symbols()
    repo = symbols["Repository"](DB_PATH)
    try:
        result = symbols["audit_text_payload"](
            repo,
            "This AI-generated summary clearly shows the policy reduced costs for all residents and proves immediate adoption is ready.",
            text_type="ai_generated",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
        )
    finally:
        repo.close()

    language = result["ai_data_audit_language"]
    risk_labels = " ".join(item["label"] for item in language["risks"])
    assert language["mode"] == "ai_data_audit_language"
    assert "No retrieval was performed" in language["no_retrieval_caution"]
    assert "Hallucination-confidence risk" in risk_labels
    assert "Provenance-gap risk" in risk_labels
    assert "practice_suggestions" in result
    assert "AI/data audit language" in result["evidence_and_limits"]


def test_kb_no_result_recovery_suggests_narrower_terms_and_filters() -> None:
    symbols = load_server_symbols()
    recovery = symbols["kb_no_result_recovery"]("memory and AI bias", category="biases")

    assert recovery["triggered"] is True
    assert "false memory" in recovery["try_narrower_queries"]
    assert "automation bias" in recovery["try_narrower_queries"]
    assert "biases" in recovery["try_category_filters"]
    assert "not proof that the concept is absent" in recovery["host_rule"]


def test_suggest_next_steps_uses_concrete_mitigation_verbs() -> None:
    symbols = load_server_symbols()
    repo = symbols["Repository"](DB_PATH)
    try:
        result = symbols["suggest_next_steps_payload"](
            repo,
            "advocacy",
            ["framing effect", "authority bias"],
        )
    finally:
        repo.close()

    verbs = {item["action_verb"] for item in result["next_steps"]}
    assert result["mitigation_style"] == "atlas_informed_action_verbs"
    assert verbs <= set(result["allowed_verbs"])
    assert {"ask", "compare"} & verbs
    assert all("thinking_move" in item for item in result["next_steps"])
    assert result["practice_suggestions"]
    assert all(item["standalone_tool"] is False for item in result["practice_suggestions"])


def test_persona_seeds_are_analytical_standpoints_not_identity_roleplay() -> None:
    symbols = load_server_symbols()
    repo = symbols["Repository"](DB_PATH)
    try:
        result = symbols["list_agent_personas_payload"](
            repo,
            subject="A grant impact claim says the program doubled outcomes for all residents.",
            text_type="product_copy",
            domain_hint="grant review",
        )
    finally:
        repo.close()

    examples = {item["user_phrase"]: item for item in result["supported_custom_examples"]}
    assert "grant reviewer / evidence steward" in examples
    assert "affected-community reviewer" in examples
    assert "AI/data auditor" in examples
    assert "accessibility reviewer" in examples
    assert "analytical standpoints" in result["persona_seed_guidance"]["rule"]
    assert any("Do not impersonate protected identities" in item for item in result["guardrails"])


def test_practice_activity_tool_gate_defers_new_tool_surface() -> None:
    gate = json.loads(PRACTICE_GATE_PATH.read_text(encoding="utf-8"))
    server_text = (ROOT / "server.py").read_text(encoding="utf-8")

    assert gate["resource_id"] == "critical_compass.practice_activity_tool_gate.v1"
    assert gate["decision"] == "defer_standalone_tool"
    assert "No new Now-phase MCP tool." in gate["explicit_non_goals"]
    assert "def practice_activity_tool" not in server_text
    assert "standalone Practice Activity Tool" in gate["summary"]
