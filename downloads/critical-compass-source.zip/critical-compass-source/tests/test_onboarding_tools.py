from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def install_fake_mcp_modules() -> None:
    if "audit_report" not in sys.modules:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]

        def fake_generate_audit_report(*_args, **_kwargs):
            return {"qa_status": "not_run", "report_path": None}

        def fake_prepare_audit_source(*_args, **_kwargs):
            return {"status": "not_run", "text": ""}

        def fake_generate_audit_artifact_viewer(*_args, **_kwargs):
            return {"status": "not_run", "viewer_path": None}

        def fake_validate_report_payload(*_args, **_kwargs):
            return {"qa_status": "not_run", "writes_files": False}

        audit_report_module.generate_audit_artifact_viewer = fake_generate_audit_artifact_viewer
        audit_report_module.generate_audit_report = fake_generate_audit_report
        audit_report_module.prepare_audit_source = fake_prepare_audit_source
        audit_report_module.validate_report_payload = fake_validate_report_payload
        sys.modules["audit_report"] = audit_report_module

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        Repository,
        audit_text_payload,
        claim_stress_test_payload,
        critical_compass_overview_payload,
        list_concept_examples_payload,
        quick_scan_payload,
        synthesize_audit_verdict_payload,
    )

    return Repository, critical_compass_overview_payload, list_concept_examples_payload, audit_text_payload, quick_scan_payload, claim_stress_test_payload, synthesize_audit_verdict_payload


def run_concept_examples(**kwargs):
    Repository, _, list_concept_examples_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        return list_concept_examples_payload(repo, **kwargs)
    finally:
        repo.close()


def test_overview_default_returns_workflows_and_routing() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload()
    joined = " ".join(str(item) for item in result["tool_map"] + result["core_workflows"] + result["case_studies"])

    assert result["status"] == "overview_ready"
    assert result["start_here_tools"] == ["get_started", "quick_scan", "audit_text", "claim_stress_test", "prepare_audit_source", "generate_audit_report"]
    assert result["tool_tiers"]["tier_1"]["tools"] == result["start_here_tools"]
    assert result["host_ai_routing"]["start_here_tools"] == result["start_here_tools"]
    assert "smallest correct tool" in result["host_ai_routing"]["routing_rule"]
    assert all("tier_label" in item for item in result["tool_map"])
    assert all("tier_label" in item for item in result["core_workflows"])
    assert result["core_workflows"]
    assert result["case_studies"]
    assert result["starter_prompts"]
    assert result["tool_map"]
    assert result["host_ai_routing"]["next_tool_candidates"]
    assert "Critical Compass" in result["markdown"]
    assert "prepare_audit_source" in joined
    assert "generate_audit_artifact_viewer" in joined


def test_overview_leads_with_public_pressure_test_mission() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload()
    overview = result["user_overview"]

    assert "pressure-test text before" in overview
    assert "mission-driven organizations" in overview
    assert "weak evidence" in overview
    assert "overly narrow Western framing" in overview
    assert "MCP composition" not in overview


def test_overview_quick_start_is_intent_first_and_supports_audience_fit() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="quick_start")
    joined = " ".join(result["starter_prompts"] + result["next_steps"])

    assert "goal" in joined.lower()
    assert "intended audience" in joined.lower()
    assert "quick, full, or advanced" in joined.lower()
    assert "audit_text" in joined
    assert "advanced_audit" in joined
    assert "JTBD" in joined


def test_overview_includes_advocacy_audience_fit_case_study() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload()
    joined = " ".join(str(item) for item in result["case_studies"] + result["core_workflows"] + result["tool_map"])

    assert "audience I want to reach" in joined
    assert "stakeholder fit" in joined
    assert "persuasion risk" in joined
    assert "audience-fit / persuasion-effectiveness review" in joined


def test_overview_claim_stress_topic_routes_to_claim_tool() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="claim_stress_test")
    tools = {item.get("tool") or item.get("best_tool") for item in result["tool_map"] + result["core_workflows"]}

    assert result["topic"] == "claim_stress_test"
    assert "claim_stress_test" in tools
    assert "claim_stress_test" in result["host_ai_routing"]["next_tool_candidates"]


def test_overview_reports_topic_routes_to_report_tools() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="reports")
    joined = " ".join(str(item) for item in result["tool_map"] + result["case_studies"] + result["starter_prompts"])

    assert result["topic"] == "reports"
    assert "prepare_audit_source" in joined
    assert "generate_audit_report" in joined
    assert "generate_audit_artifact_viewer" in joined
    assert 'report_depth="readiness_card"' in result["user_overview"]
    assert "first-share" in joined
    assert result["report_readiness_contract"]["canonical_audit_data_template"]["critical_integrity_snapshot"]
    assert "Plain-Language Read" in result["report_readiness_contract"]["markdown_checkpoint_template"]
    post_call = " ".join(result["report_readiness_contract"]["post_call_rules"])
    assert "viewer_path" in post_call
    assert "generate_audit_artifact_viewer" in post_call
    resources = result["workflow_resources"]
    assert resources["resource_id"] == "critical_compass.scaffolds.v1"
    resource_ids = {item["id"] for item in resources["resources"]}
    assert {
        "host_workflow_contract",
        "report_ready_payload",
        "markdown_checkpoint",
        "argument_map",
        "checkworthy_claims",
        "factcheck_lookup_examples",
        "factcheck_research_scaffold",
        "blind_spot_consent_examples",
        "server_instructions",
        "structured_elicitation_examples",
        "dissent_guidance",
        "tool_inventory",
        "demo_runbook",
        "live_qa_runbook",
        "beta_calibration_intake",
    } <= resource_ids
    assert "mcp_composition_policy" not in resource_ids
    assert "external_mcp_orchestration_contract" not in resource_ids
    assert "mcp_study_learner_runbook" not in resource_ids
    assert all(Path(item["absolute_path"]).exists() for item in resources["resources"])


def test_overview_unsupported_planning_topics_fall_back_without_registry_resources() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    for topic in ["comparable_tools", "mcp_composition", "mcp_orchestration", "capability_registry"]:
        result = critical_compass_overview_payload(topic=topic)
        joined = " ".join(str(result.get(key, "")) for key in ["user_overview", "starter_prompts", "tool_map", "case_studies"])

        assert result["topic"] == "overview"
        assert "mcp_capability_registry" not in result
        assert "mcp_study_lessons_resource" not in result
        assert "comparable_tools_resource" not in result
        assert "mcp_composition" not in joined
        assert "orchestrated external" not in joined.lower()
        assert "study-library" not in joined.lower()


def test_overview_app_ui_topic_routes_to_artifact_viewer() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="app_ui")
    joined = " ".join(str(item) for item in result["tool_map"] + result["case_studies"] + result["starter_prompts"])

    assert result["topic"] == "app_ui"
    assert "generate_audit_artifact_viewer" in joined
    assert "read-only" in result["user_overview"].lower()
    resources = result["workflow_resources"]
    resource_ids = {item["id"] for item in resources["resources"]}
    assert {"tool_inventory", "demo_runbook", "live_qa_runbook"} <= resource_ids


def test_overview_payload_does_not_surface_planning_resource_keys() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload()
    joined = " ".join(str(value) for value in result.values())

    assert "mcp_capability_registry" not in result
    assert "mcp_study_lessons_resource" not in result
    assert "comparable_tools_positioning_card" not in result
    assert "MCP composition" not in joined
    assert "capability registry" not in joined.lower()
    assert "study-library" not in joined.lower()


def test_beta8_overview_exposes_teaching_alignment_contract() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="audits")
    contract = result["teaching_alignment_contract"]
    pack = result["teaching_activity_pack"]

    assert "Plain-Language Read" in result["user_overview"]
    assert "Before using this text," in contract["before_using_this_text"]
    assert "non-persistent" in contract["activity_fit_check"]
    assert "no live lookup" in contract["source_boundary"]
    assert pack["activity_count"] >= 10
    assert pack["role_counts"]["solo_follow_up"] >= 1
    assert pack["role_counts"]["group_follow_up"] >= 1
    assert "Claim-Support-Question" in pack["sample_titles"]


def test_beta81_overview_keeps_public_positioning_generic() -> None:
    _, critical_compass_overview_payload, *_ = load_server_symbols()

    result = critical_compass_overview_payload(topic="overview")
    joined = " ".join(str(value) for value in result.values())

    assert "generic reasoning MCPs" not in joined
    assert "unsupported integrations" not in joined
    assert "automatic web search" not in joined


def test_beta8_audit_and_quick_scan_include_follow_up_activity() -> None:
    Repository, _, _, audit_text_payload, quick_scan_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    text = "Our pilot reduced missed appointments by 40 percent, proving the navigator program should be expanded statewide."
    try:
        audit = audit_text_payload(
            repo,
            text,
            text_type="research",
            human_loop_mode="silent",
            human_loop_state={"explicit_noninteractive_override": True},
        )
        quick = quick_scan_payload(repo, text, text_type="research")
    finally:
        repo.close()

    assert audit["critical_integrity_snapshot"]["plain_language_read"]
    assert audit["critical_integrity_snapshot"]["before_using_this_text"].startswith("Before using this text,")
    assert audit["follow_up_activity"]["solo_activity"]["title"]
    assert audit["follow_up_activity"]["group_activity"]["title"]
    assert audit["follow_up_activity"]["fit_check"]["persistence"] == "non_persistent"
    assert audit["follow_up_activity"]["source_note"] == "Curated from Critical Compass."
    assert set(quick["follow_up_activity"]) == {"try_this_next", "source_note", "fit_check"}
    assert quick["follow_up_activity"]["try_this_next"]["title"]
    assert quick["follow_up_activity"]["fit_check"]["prompt"] == "After trying this activity, note what helped and what you would change."


def test_synthesize_returns_report_ready_payload_and_pause_flag() -> None:
    *_, synthesize_audit_verdict_payload = load_server_symbols()

    result = synthesize_audit_verdict_payload(
        subject="Our practitioner guide is based on ten years of direct consulting experience with small nonprofits.",
        text_type="policy",
        human_loop_mode="silent",
        human_loop_state={"explicit_noninteractive_override": True},
        agents=[
            {
                "agent_name": "Evidence reviewer",
                "reasoning_style": "evidence and argument",
                "top_finding": "The guide needs clearer context anchors for its authority claim.",
            }
        ],
        analyses=[
            {
                "agent_name": "Evidence reviewer",
                "top_finding": "The guide needs clearer context anchors for its authority claim.",
                "strongest_disagreement": "The authority basis may be enough if the audience already trusts the practitioner.",
                "confidence": "medium",
            }
        ],
        tensions=[],
        debate={"synthesis": "Use the guide, but name the authority basis and limits."},
    )

    assert result["PAUSE_REQUIRED"] is False
    assert result["report_schema_hash"]
    assert result["report_ready_payload"]["completion_status"] == "draft_needs_host_fill"
    assert result["report_ready_payload"]["audit_data"]["advanced_audit"]["agents"][0]["top_finding"]
    assert "validate_report_payload" in str(result["recommended_mcp_calls"])


def test_beta8_claim_stress_test_includes_plain_read_before_use_and_compact_activity() -> None:
    Repository, _, _, _, _, claim_stress_test_payload, *_ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = claim_stress_test_payload(repo, "This supplement doubles focus because one founder said it worked.")
    finally:
        repo.close()

    assert result["plain_language_read"]
    assert result["before_using_this_text"].startswith("Before using this text,")
    assert set(result["follow_up_activity"]) == {"try_this_next", "source_note", "fit_check"}
    assert result["follow_up_activity"]["try_this_next"]["title"]
    assert result["follow_up_activity"]["fit_check"]["persistence"] == "non_persistent"


def test_concept_examples_biases_include_known_bias_card() -> None:
    result = run_concept_examples(category="biases")
    titles = {item["title"] for item in result["examples"]}

    assert result["status"] == "examples_ready"
    assert result["category"] == "biases"
    assert "Confirmation bias" in titles
    assert all("plain_language_summary" in item for item in result["examples"])


def test_concept_examples_thinking_lenses_include_lens_cards() -> None:
    result = run_concept_examples(category="thinking_lenses")
    joined_titles = " ".join(item["title"] for item in result["examples"])

    assert result["status"] == "examples_ready"
    assert result["category"] == "thinking_lenses"
    assert "Two-Eyed Seeing" in joined_titles or "Public Narrative" in joined_titles
    assert all("get_framework" in item["related_tools"] for item in result["examples"])


def test_concept_examples_patterns_resolve_to_pattern_families() -> None:
    result = run_concept_examples(category="patterns", limit=8)
    related_tools = {tool for item in result["examples"] for tool in item["related_tools"]}

    assert result["status"] == "examples_ready"
    assert result["category"] == "patterns"
    assert result["examples"]
    assert "list_reasoning_flows" in related_tools


def test_concept_examples_invalid_category_blocks() -> None:
    result = run_concept_examples(category="unknowns")

    assert result["status"] == "blocked"
    assert "biases" in result["available_categories"]
    assert result["examples"]
    assert "list_categories" in result["suggested_tools"]


def test_concept_examples_query_returns_kb_backed_matches() -> None:
    result = run_concept_examples(category="biases", query="confirmation bias")

    assert result["status"] == "examples_ready"
    assert result["query"] == "confirmation bias"
    assert any(item["title"] == "Confirmation bias" for item in result["examples"])
    assert "search_knowledge_base" in result["suggested_tools"]
