from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BROKEN_ENDING = re.compile(r"(\.\.\.|…|[-,;:]$|\b(?:and|or|but|because|why|that|to)$)", re.IGNORECASE)


def load_fixture(name: str) -> dict:
    return json.loads((ROOT / "audit_report" / "fixtures" / f"{name}.json").read_text(encoding="utf-8"))


def assert_complete_thought(value: str, max_chars: int | None = None) -> None:
    assert value
    if max_chars is not None:
        assert len(value) <= max_chars
    assert not BROKEN_ENDING.search(value), value
    assert "..." not in value
    assert "…" not in value


def long_prose_fixture() -> dict:
    data = load_fixture("long_sentence_caps")
    data["biases"] = [
        {
            "name": "Scope Compression",
            "passage": (
                "The source language includes a very specific long passage about community conditions "
                "and public trust that should not end halfway through a word"
            ),
            "why_it_matters": (
                "This explanation is intentionally long because it describes a risk across audiences, "
                "context, power, and evidence standards, and it keeps going past the cap so the old helper "
                "would slice it into a broken fragment instead of completing the thought."
            ),
        }
    ]
    data["next_steps"] = [
        (
            "Add one paragraph that names the affected communities, evidence standard, revision owner, "
            "and publication threshold, and then keeps adding extra detail that would previously be sliced "
            "off mid-thought."
        )
    ]
    data["argument_map"] = {
        "central_claim": (
            "The draft should narrow the publication claim, name the evidence standard, and identify "
            "whose knowledge is missing before it asks readers to trust the conclusion."
        ),
        "supporting_reasons": [
            (
                "The current support names several risks, audiences, and governance concerns, but it does "
                "not yet connect each recommendation to a concrete evidence source."
            )
        ],
    }
    data["checkworthy_claims"] = [
        {
            "claim": (
                "The program reduced missed appointments by 42 percent across all participating clinics "
                "during the pilot period."
            ),
            "evidence_needed": (
                "Clinic-level attendance data, baseline comparison periods, and a note about whether the "
                "reported percentage includes all participating sites."
            ),
            "why_check": (
                "A numeric improvement claim is persuasive, but it needs enough source detail to avoid "
                "overstating causal certainty."
            ),
        }
    ]
    return data


def test_cap_complete_prose_prefers_complete_sentences() -> None:
    from audit_report.models import cap_complete_prose

    text = (
        "The first sentence is complete and useful. "
        "The second sentence adds detail that should not be sliced into a broken fragment."
    )

    shortened = cap_complete_prose(text, 55)

    assert shortened == "The first sentence is complete and useful."
    assert_complete_thought(shortened, 55)


def test_cap_complete_prose_trims_one_long_sentence_to_clean_clause() -> None:
    from audit_report.models import cap_complete_prose

    text = (
        "Add one paragraph to name governance, compliance, and evidence standards before publication "
        "because the remaining draft adds too much detail for a table cell."
    )

    shortened = cap_complete_prose(text, 62)

    assert shortened.startswith("Add one paragraph")
    assert_complete_thought(shortened, 62)


def test_cap_complete_words_never_uses_ellipsis_or_dangling_endings() -> None:
    from audit_report.models import cap_complete_words

    text = "The source passage includes a long quoted area that should not trail into nothing"

    shortened = cap_complete_words(text, 8)

    assert shortened.startswith("The source passage")
    assert_complete_thought(shortened)


def test_report_normalization_shortens_user_facing_prose_as_complete_thoughts() -> None:
    from audit_report.normalize import normalize_audit_data, normalize_options

    data = long_prose_fixture()

    payload = normalize_audit_data(data, normalize_options(data))
    values = [
        payload["findings"]["biases"][0]["passage"],
        payload["findings"]["biases"][0]["why_it_matters"],
        payload["next_steps"][0],
        payload["argument_map"]["central_claim"],
        payload["argument_map"]["supporting_reasons"][0],
        payload["checkworthy_claims"]["claims"][0]["claim"],
        payload["checkworthy_claims"]["claims"][0]["evidence_needed"],
        payload["checkworthy_claims"]["claims"][0]["why_check"],
    ]

    for value in values:
        assert_complete_thought(value)

    warning_messages = " ".join(item["message"] for item in payload["diagnostics"]["schema_warnings"])
    assert "shortened before rendering" in warning_messages
    assert "trimmed before rendering" not in warning_messages


def test_html_and_markdown_reports_do_not_render_ellipsis_fragments() -> None:
    from audit_report.markdown import render_markdown
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.render import render_html

    data = long_prose_fixture()
    payload = normalize_audit_data(data, normalize_options(data))

    rendered = render_html(payload, "full_report.html") + render_markdown(payload)

    assert "..." not in rendered
    assert "…" not in rendered
    assert "trimmed before rendering" not in rendered
