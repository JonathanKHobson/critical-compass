from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_server_symbols():
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from server import Repository, challenge_claim_payload, claim_stress_test_payload  # pylint: disable=import-error,import-outside-toplevel

    return Repository, challenge_claim_payload, claim_stress_test_payload


def run_stress_test(claim: str, **kwargs):
    Repository, _, claim_stress_test_payload = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        return claim_stress_test_payload(repo, claim, **kwargs)
    finally:
        repo.close()


def test_claim_stress_test_false_dilemma_card() -> None:
    result = run_stress_test("Either we adopt this policy immediately or the whole program will fail.")

    assert result["status"] == "card_ready"
    assert result["fallacy_risk"]["name"] == "False dilemma"
    assert result["fallacy_risk"]["assessment"] == "risk_not_verdict"
    assert result["stress_test_card"]["state"] == "ready"
    assert result["stress_test_card"]["actions"] == result["next_actions"]
    assert result["when_not_a_fallacy"]


def test_claim_stress_test_causal_overreach() -> None:
    result = run_stress_test("The update caused retention to drop because signups fell after launch.")

    assert result["fallacy_risk"]["name"] == "Causal overreach"
    assert "causation" in result["probing_questions"][0].lower()


def test_claim_stress_test_blank_claim_blocks() -> None:
    result = run_stress_test("   ")

    assert result["status"] == "blocked"
    assert result["stress_test_card"]["state"] == "needs_claim"
    assert result["input_guidance"]
    assert result["fallacy_risk"] is None


def test_claim_stress_test_long_claim_gets_scope_warning() -> None:
    long_claim = " ".join(["This program will fail because the evidence is weak."] * 10)
    result = run_stress_test(long_claim)

    assert result["status"] == "card_ready"
    assert result["scope_warning"]
    assert result["stress_test_card"]["scope_warning"] == result["scope_warning"]


def test_claim_stress_test_markdown_card_sections() -> None:
    result = run_stress_test("Everyone is switching to this tool, so it must be the right choice.")
    markdown = result["markdown_card"]

    assert "## Claim Stress-Test" in markdown
    assert "### Steelman" in markdown
    assert "### Fallacy Risk" in markdown
    assert "### Probing Questions" in markdown
    assert "### Next Actions" in markdown


def test_challenge_claim_payload_keeps_legacy_shape() -> None:
    Repository, challenge_claim_payload, _ = load_server_symbols()
    repo = Repository(DB_PATH)
    try:
        result = challenge_claim_payload(repo, "Everyone is switching to this tool, so it must be the right choice.")
    finally:
        repo.close()

    assert set(result) == {"claim", "steelman", "fallacy_risk", "probing_questions"}
    assert result["fallacy_risk"]["name"] == "Bandwagon"
    assert result["probing_questions"] == [
        "What would the strongest opposing view say?",
        "What evidence would make this claim weaker or stronger?",
    ]
