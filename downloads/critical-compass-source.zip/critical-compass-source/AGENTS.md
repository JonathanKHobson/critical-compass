# Critical Compass Agent Rules

## Purpose

Critical Compass helps people pressure-test written work before they use it. Keep work centered on audit quality, human judgment, dissent, provenance, and report readiness.

## Tool Boundaries

- Start with native Critical Compass tools before suggesting external MCPs or browsing.
- Do not add automatic web retrieval to core audits.
- Treat `factcheck_lookup` results as evidence artifacts, not Critical Compass truth verdicts.
- If `human_loop_host_action.must_pause=true`, stop and ask only the current prompt block through native question UI when available.
- Generate reports only after report readiness fields are complete.

## Agentic Panel Mode

- Agentic panel review is explicit opt-in only. Safe phrases include `advanced panel review`, `agentic panel review`, `multi-perspective panel`, and `run the agent audit`.
- Do not trigger agentic mode from generic words like `agent`, `agency`, `city council`, `panel`, `committee`, or `stakeholders` alone.
- If native subagents are unavailable, disclose that the panel is simulated/sequential in one thread.
- Personas are analytical standpoints, not claims of lived identity.
- Use the four stable role contracts: evidence/argument, systems/context, uncertainty/methods, and missing voice/power.
- Preserve dissent through the tension map, debate, synthesis, dissent ledger, confidence, and comparability.

## Release Hygiene

- Keep generated reports, private reports, caches, `.env*`, AppleDouble sidecars, bytecode, and local state databases out of public share bundles.
- Validate server surface, research coverage, beta calibration, and tests before packaging a release.
- Treat the public landing page as a synchronized surface, not a throwaway generated artifact. If you change GitHub Pages, update `scripts/build_shareable_release.py`, rebuild `dist/share/github-pages/index.html` and `dist/share/manual-share/START_HERE.html`, and verify the live Pages copy after push.
- Preserve the current landing-page shell: separate `About` and `FAQ` tabs, no combined `About & FAQ` tab, beta.11 download links/checksums, and current report-generation wording (`report_ready_payload` then `validate_report_payload` before `generate_audit_report`).
- Do not overwrite the live site from a generated share kit unless the generator and local generated pages have already passed the shareable-release tests and surface-sync validator.
- For website-only corrections, use `python3 scripts/build_shareable_release.py --pages-only` to refresh `dist/share/github-pages`, `dist/share/manual-share`, and the share-kit zips from existing release artifacts before syncing the live Pages checkout.
- In stability or hardening slices, do not run a package rebuild, public-site edit, or publish step unless the user explicitly asks for that release action.
- For a first-share report or stakeholder summary where the user has not explicitly asked for the full PDF, prefer `generate_audit_report(report_depth="readiness_card")` after `validate_report_payload`; reserve full reports for explicit full-analysis requests.
