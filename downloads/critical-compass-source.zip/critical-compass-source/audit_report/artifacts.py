from __future__ import annotations

import re
from typing import Any

from .models import cap_chars, cap_complete_prose, cap_complete_words, clean_text, ensure_list


ARGUMENT_MAP_CLAIM_TYPES = {"factual", "interpretive", "causal", "normative", "policy"}
CHECKWORTHY_PRIORITIES = {"high", "medium", "low", "not_ranked"}
CHECKWORTHY_NOTICE = "Check-worthy means worth verifying, not false."

MAX_REASONS = 5
MAX_OBJECTIONS = 5
MAX_ASSUMPTIONS = 5
MAX_MISSING_VOICES = 5
MAX_GAPS = 5
MAX_QUESTIONS = 5
MAX_CHECKWORTHY_CLAIMS = 8
MAX_SUGGESTED_QUERIES = 3
MAX_LIKELY_SOURCE_TYPES = 4

PRIORITY_LABELS = {
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "not_ranked": "Not ranked",
}

SUPPORT_CONTRAST_LABELS = {
    "needs_evidence": "Needs supporting evidence",
    "needs_source": "Needs source support",
    "needs_support_and_contrast": "Needs support and contrast evidence",
    "not_ranked_for_truth": "Not ranked - claim type does not admit simple truth verification",
}


def first_present(mapping: dict[str, Any] | None, aliases: list[str]) -> Any:
    if not isinstance(mapping, dict):
        return None
    for alias in aliases:
        if alias in mapping:
            value = mapping.get(alias)
            if value not in (None, "", [], {}):
                return value
    return None


def first_present_nested(data: dict[str, Any] | None, candidate_paths: list[tuple[str, ...]]) -> Any:
    if not isinstance(data, dict):
        return None
    for path in candidate_paths:
        current: Any = data
        found = True
        for key in path:
            if not isinstance(current, dict) or key not in current:
                found = False
                break
            current = current[key]
        if found and current not in (None, "", [], {}):
            return current
    return None


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        text = clean_text(item)
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result


def _split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", clean_text(text))
    return [part for part in (clean_text(part) for part in parts) if part]


def _claim_type_from_text(text: str) -> str:
    lowered = clean_text(text).lower()
    if not lowered:
        return "factual"
    if re.search(r"\b(should|must|ought|need to|recommended|recommend|best to|important to)\b", lowered):
        return "normative"
    if re.search(r"\b(policy|rule|require|required|ban|allow|prohibit|guideline)\b", lowered):
        return "policy"
    if re.search(r"\b(because|caused|causes|lead to|leads to|results in|resulted in|due to|therefore|as a result)\b", lowered):
        return "causal"
    if re.search(r"\b(seems|appears|suggests|implies|indicates|likely|probably)\b", lowered):
        return "interpretive"
    return "factual"


def _normalize_claim_type(value: Any, fallback_text: str = "") -> str:
    claim_type = clean_text(value).lower().replace(" ", "_")
    if claim_type in ARGUMENT_MAP_CLAIM_TYPES:
        return claim_type
    return _claim_type_from_text(fallback_text)


def _claim_priority(text: str) -> str:
    lowered = clean_text(text).lower()
    score = 0
    if re.search(r"\b\d+\b", lowered) or re.search(r"\b(19|20)\d{2}\b", lowered):
        score += 2
    if re.search(r"\b(according to|study|studies|report|survey|data|evidence|measured|count|observed|found)\b", lowered):
        score += 1
    if re.search(r"\b(percent|percentage|ratio|rate|increase|decrease|drop|rise|fell|grew)\b", lowered):
        score += 1
    if score >= 3:
        return "high"
    if score >= 1:
        return "medium"
    return "low"


def _priority_rank(priority: str) -> int:
    return {"high": 0, "medium": 1, "low": 2, "not_ranked": 3}.get(priority, 3)


def _display_label(value: Any, labels: dict[str, str]) -> str:
    text = clean_text(value)
    return labels.get(text, text.replace("_", " ").title() if text else "")


def _cap_list(values: Any, limit: int, item_chars: int | None = None, *, prose: bool = False) -> list[str]:
    items = [clean_text(item) for item in ensure_list(values)]
    result: list[str] = []
    for item in items:
        if not item:
            continue
        if item_chars and prose:
            result.append(cap_complete_prose(item, item_chars))
        elif item_chars:
            result.append(cap_chars(item, item_chars))
        else:
            result.append(item)
        if len(result) >= limit:
            break
    return _dedupe(result)


def _table_cell(value: Any) -> str:
    return clean_text(value).replace("|", "\\|")


def _maybe_from_authored(data: dict[str, Any], aliases: list[str]) -> Any:
    value = first_present(data, aliases)
    if value not in (None, "", [], {}):
        return value
    return None


def _extract_argument_map_source(data: dict[str, Any]) -> dict[str, Any]:
    source = first_present_nested(data, [("argument_map",), ("argument",), ("argument_structure",)])
    return source if isinstance(source, dict) else {}


def _extract_checkworthy_source(data: dict[str, Any]) -> Any:
    source = first_present_nested(data, [("checkworthy_claims",), ("claims",), ("checkworthy",)])
    if isinstance(source, dict) or isinstance(source, list):
        return source
    return []


def _normalize_argument_map_from_authored(source: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    used_authored = False

    def field(aliases: list[str], fallback: str = "") -> str:
        nonlocal used_authored
        value = _maybe_from_authored(source, aliases)
        if value is not None:
            used_authored = True
            return cap_complete_prose(value, 360)
        return fallback

    plain_language_summary = field(
        ["plain_language_summary", "plain_language", "summary", "executive_summary"],
        "",
    )
    central_claim = field(["central_claim", "claim", "thesis", "core_claim"], "")
    claim_type = _normalize_claim_type(
        _maybe_from_authored(source, ["claim_type", "type"]),
        central_claim or plain_language_summary,
    )
    if _maybe_from_authored(source, ["claim_type", "type"]) is not None:
        used_authored = True

    supporting_reasons = _cap_list(
        _maybe_from_authored(source, ["supporting_reasons", "reasons", "supporting_points", "evidence", "supports"]),
        MAX_REASONS,
        180,
        prose=True,
    )
    objections = _cap_list(
        _maybe_from_authored(source, ["objections", "counterarguments", "counterpoints", "concerns"]),
        MAX_OBJECTIONS,
        180,
        prose=True,
    )
    assumptions = _cap_list(_maybe_from_authored(source, ["assumptions"]), MAX_ASSUMPTIONS, 180, prose=True)
    missing_voices = _cap_list(
        _maybe_from_authored(source, ["missing_voices", "missing_perspectives", "voices_missing"]),
        MAX_MISSING_VOICES,
        180,
        prose=True,
    )
    evidence_gaps = _cap_list(
        _maybe_from_authored(source, ["evidence_gaps", "gaps", "open_questions", "unknowns"]),
        MAX_GAPS,
        180,
        prose=True,
    )
    next_questions = _cap_list(
        _maybe_from_authored(source, ["next_questions", "questions", "follow_up_questions"]),
        MAX_QUESTIONS,
        180,
        prose=True,
    )
    confidence = clean_text(_maybe_from_authored(source, ["confidence"]) or "")
    if confidence not in {"low", "medium", "high"}:
        confidence = "medium" if any([supporting_reasons, objections, assumptions, evidence_gaps]) else "low"
    else:
        used_authored = True

    status = "authored" if used_authored else "mixed"
    return (
        {
            "plain_language_summary": plain_language_summary,
            "central_claim": central_claim,
            "claim_type": claim_type,
            "supporting_reasons": supporting_reasons,
            "objections": objections,
            "assumptions": assumptions,
            "missing_voices": missing_voices,
            "evidence_gaps": evidence_gaps,
            "confidence": confidence,
            "next_questions": next_questions,
            "status": status,
        },
        used_authored,
    )


def _infer_argument_map_from_text(subject_text: str) -> dict[str, Any]:
    sentences = _split_sentences(subject_text)
    summary = cap_complete_prose(" ".join(sentences[:2]), 360) if sentences else ""

    scored: list[tuple[int, int, str, str]] = []
    for index, sentence in enumerate(sentences):
        lowered = sentence.lower()
        score = 0
        if re.search(r"\b(should|must|ought|need to|recommended|recommend|policy|board|launch)\b", lowered):
            score += 4
        if re.search(r"\b(because|therefore|due to|as a result|caused|results in|leads to)\b", lowered):
            score += 3
        if re.search(r"\b(seems|appears|suggests|implies|likely|probably)\b", lowered):
            score += 2
        if re.search(r"\b\d+\b", lowered):
            score += 1
        scored.append((score, -index, sentence, lowered))
    scored.sort(reverse=True)
    central_claim = cap_complete_prose(scored[0][2], 360) if scored and scored[0][0] > 0 else cap_complete_prose(sentences[0], 360) if sentences else ""

    supporting_reasons = []
    objections = []
    assumptions = []
    missing_voices: list[str] = []
    evidence_gaps = []
    next_questions = []

    for sentence in sentences:
        lowered = sentence.lower()
        if sentence == central_claim:
            continue
        if re.search(r"\b(however|but|yet|still|although|though|on the other hand)\b", lowered):
            objections.append(cap_complete_prose(sentence, 180))
            continue
        if re.search(r"\b(because|since|therefore|as a result|evidence|shows|suggests|indicates|supports)\b", lowered):
            supporting_reasons.append(cap_complete_prose(sentence, 180))
            continue
        if re.search(r"\b(assume|assuming|assumption|presume|unless|if)\b", lowered):
            assumptions.append(cap_complete_prose(sentence, 180))
            continue
        if re.search(r"\b(unclear|missing|unknown|limited|not enough|insufficient|unanswered)\b", lowered):
            evidence_gaps.append(cap_complete_prose(sentence, 180))
            continue
        if re.search(r"\b(what|how|who|which|when|where|why)\b", lowered):
            next_questions.append(cap_complete_prose(sentence, 180))
            continue

    if not evidence_gaps and sentences:
        evidence_gaps.append("The text does not spell out what evidence would settle the claim.")

    if not next_questions and central_claim:
        next_questions.append("What would need to be true for this claim to hold up?")

    claim_type = _claim_type_from_text(central_claim or summary)
    if not supporting_reasons and central_claim and re.search(r"\bbecause\b", central_claim, flags=re.IGNORECASE):
        reason = re.split(r"\bbecause\b", central_claim, maxsplit=1, flags=re.IGNORECASE)[-1]
        if clean_text(reason):
            supporting_reasons.append(cap_complete_prose(f"Because {clean_text(reason)}", 180))
    if not supporting_reasons and len(sentences) > 1:
        supporting_reasons = [cap_complete_prose(sentence, 180) for sentence in sentences[1:3]]

    return {
        "plain_language_summary": summary,
        "central_claim": central_claim,
        "claim_type": claim_type,
        "supporting_reasons": _dedupe(supporting_reasons[:MAX_REASONS]),
        "objections": _dedupe(objections[:MAX_OBJECTIONS]),
        "assumptions": _dedupe(assumptions[:MAX_ASSUMPTIONS]),
        "missing_voices": _dedupe(missing_voices[:MAX_MISSING_VOICES]),
        "evidence_gaps": _dedupe(evidence_gaps[:MAX_GAPS]),
        "confidence": "medium" if central_claim else "low",
        "next_questions": _dedupe(next_questions[:MAX_QUESTIONS]),
        "status": "heuristic" if central_claim or summary else "mixed",
    }


def normalize_argument_map(data: dict[str, Any], subject_text: Any = "") -> dict[str, Any]:
    source = _extract_argument_map_source(data)
    authored, used_authored = _normalize_argument_map_from_authored(source)
    if used_authored:
        argument_map = authored
        fallback = None
        if not argument_map["plain_language_summary"] or not argument_map["central_claim"]:
            fallback = _infer_argument_map_from_text(clean_text(subject_text or data.get("subject_text") or data.get("text") or ""))
            for key in [
                "plain_language_summary",
                "central_claim",
                "claim_type",
                "supporting_reasons",
                "objections",
                "assumptions",
                "missing_voices",
                "evidence_gaps",
                "confidence",
                "next_questions",
            ]:
                if not argument_map.get(key):
                    argument_map[key] = fallback[key]
            if argument_map["status"] == "authored":
                argument_map["status"] = "mixed"
        text = clean_text(subject_text or data.get("subject_text") or data.get("text") or "")
        if not argument_map["plain_language_summary"] and text:
            fallback = fallback or _infer_argument_map_from_text(text)
            argument_map["plain_language_summary"] = fallback["plain_language_summary"]
        if not argument_map["central_claim"] and text:
            fallback = fallback or _infer_argument_map_from_text(text)
            argument_map["central_claim"] = fallback["central_claim"]
        if argument_map["status"] == "authored" and (not argument_map["plain_language_summary"] or not argument_map["central_claim"]):
            argument_map["status"] = "mixed"
        argument_map["markdown"] = argument_map_markdown(argument_map)
        argument_map["argdown"] = argument_map_argdown(argument_map)
        return argument_map
    argument_map = _infer_argument_map_from_text(clean_text(subject_text or data.get("subject_text") or data.get("text") or ""))
    argument_map["markdown"] = argument_map_markdown(argument_map)
    argument_map["argdown"] = argument_map_argdown(argument_map)
    return argument_map


def _normalize_checkworthy_entry(entry: dict[str, Any]) -> dict[str, Any]:
    claim_text = cap_complete_prose(
        first_present(entry, ["claim", "text", "statement", "sentence", "content"]) or "",
        260,
    )
    claim_type = _normalize_claim_type(first_present(entry, ["claim_type", "type"]), claim_text)
    is_factual = claim_type == "factual"
    source_anchor = cap_complete_prose(first_present(entry, ["source_anchor", "source_ref", "anchor", "where"]) or "", 140)
    evidence_needed = cap_complete_prose(first_present(entry, ["evidence_needed", "evidence", "what_to_check", "what_would_settle"]) or "", 220)
    why_check = cap_complete_prose(first_present(entry, ["why_check", "why_it_matters", "importance"]) or "", 220)
    suggested_queries = _cap_list(
        first_present(
            entry,
            ["suggested_queries", "queries", "search_queries", "fact_check_queries", "verification_queries"],
        ),
        MAX_SUGGESTED_QUERIES,
        140,
    )
    likely_source_types = _cap_list(
        first_present(
            entry,
            ["likely_source_types", "source_types", "sources_to_check", "evidence_source_types", "likely_sources"],
        ),
        MAX_LIKELY_SOURCE_TYPES,
        90,
    )
    support_contrast_status = cap_chars(
        first_present(entry, ["support_contrast_status", "support_status", "evidence_status", "support_contrast"]) or "",
        80,
    )
    uncertainty_note = cap_complete_prose(first_present(entry, ["uncertainty_note", "uncertainty", "caveat", "limitations"]) or "", 180)
    confidence = clean_text(first_present(entry, ["confidence"]) or "")
    if confidence not in {"low", "medium", "high"}:
        confidence = "medium" if is_factual else "low"
    priority = clean_text(first_present(entry, ["verification_priority", "priority"]) or "")
    if is_factual:
        priority = priority if priority in CHECKWORTHY_PRIORITIES else _claim_priority(claim_text)
    else:
        priority = "not_ranked"
    not_false_notice = clean_text(first_present(entry, ["not_false_notice"]) or CHECKWORTHY_NOTICE)
    if not not_false_notice:
        not_false_notice = CHECKWORTHY_NOTICE
    return {
        "claim": claim_text,
        "claim_type": claim_type,
        "is_factual": is_factual,
        "verification_priority": priority,
        "verification_priority_label": _display_label(priority, PRIORITY_LABELS),
        "why_check": why_check or _default_why_check(claim_type),
        "evidence_needed": evidence_needed or _default_evidence_needed(claim_type),
        "suggested_queries": suggested_queries or _default_suggested_queries(claim_text, claim_type),
        "likely_source_types": likely_source_types or _default_likely_source_types(claim_type),
        "support_contrast_status": support_contrast_status or _default_support_contrast_status(claim_type),
        "support_contrast_label": _display_label(support_contrast_status or _default_support_contrast_status(claim_type), SUPPORT_CONTRAST_LABELS),
        "uncertainty_note": uncertainty_note or _default_uncertainty_note(claim_type),
        "source_anchor": source_anchor,
        "confidence": confidence,
        "not_false_notice": not_false_notice,
    }


def _default_why_check(claim_type: str) -> str:
    if claim_type == "factual":
        return "It makes a concrete claim that can be checked."
    if claim_type == "causal":
        return "It links one thing to another and should be tested carefully."
    if claim_type == "normative":
        return "It recommends a value judgment that should be made explicit."
    if claim_type == "policy":
        return "It implies a rule or decision that should be reviewed."
    return "It shapes how the text should be read."


def _default_evidence_needed(claim_type: str) -> str:
    if claim_type == "factual":
        return "A source, quote, dataset, or document that confirms the claim."
    if claim_type == "causal":
        return "Evidence that separates correlation from causation."
    if claim_type == "normative":
        return "A stated value or criterion that justifies the judgment."
    if claim_type == "policy":
        return "The rule, memo, or decision basis behind the recommendation."
    return "Context showing why the interpretation is plausible."


def _default_suggested_queries(claim_text: str, claim_type: str) -> list[str]:
    claim = clean_text(claim_text)
    if claim:
        return [cap_chars(f'"{claim}"', 140)]
    if claim_type == "factual":
        return ["Find the primary source or dataset behind this claim."]
    if claim_type == "causal":
        return ["Find comparison evidence that tests the claimed cause."]
    if claim_type == "policy":
        return ["Find the policy text, implementation record, or decision memo."]
    if claim_type == "normative":
        return ["Find the stated criteria or stakeholder standard behind this judgment."]
    return ["Find source context that supports or complicates this interpretation."]


def _default_likely_source_types(claim_type: str) -> list[str]:
    if claim_type == "factual":
        return ["primary source", "official record", "dataset or direct quote"]
    if claim_type == "causal":
        return ["comparison study", "longitudinal evidence", "mechanism evidence"]
    if claim_type == "policy":
        return ["policy text", "implementation record", "stakeholder impact evidence"]
    if claim_type == "normative":
        return ["stated criteria", "stakeholder values", "decision standard"]
    return ["source excerpt", "contextual evidence", "alternative interpretation"]


def _default_support_contrast_status(claim_type: str) -> str:
    if claim_type == "factual":
        return "needs_evidence"
    if claim_type == "causal":
        return "needs_support_and_contrast"
    return "not_ranked_for_truth"


def _default_uncertainty_note(claim_type: str) -> str:
    if claim_type == "factual":
        return "Priority reflects verification usefulness, not a judgment that the claim is false."
    if claim_type == "causal":
        return "Causal language needs support and contrast evidence before it should guide action."
    return "This claim shapes interpretation or action; verify its basis without treating it as a truth verdict."


def _normalize_checkworthy_from_authored(source: Any) -> tuple[list[dict[str, Any]], bool]:
    entries: list[dict[str, Any]] = []
    used_authored = False

    if isinstance(source, dict):
        raw_entries = ensure_list(first_present(source, ["claims", "entries", "items", "checkworthy_claims"]))
    else:
        raw_entries = ensure_list(source)

    for raw in raw_entries:
        if not isinstance(raw, dict):
            raw = {"claim": raw}
        normalized = _normalize_checkworthy_entry(raw)
        if normalized["claim"]:
            entries.append(normalized)
            used_authored = True

    return entries, used_authored


def _heuristic_checkworthy_claims(subject_text: str, limit: int = MAX_CHECKWORTHY_CLAIMS) -> list[dict[str, Any]]:
    sentences = _split_sentences(subject_text)
    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for sentence in sentences:
        claim_text = cap_complete_prose(sentence, 260)
        if not claim_text or claim_text in seen or len(claim_text.split()) < 4:
            continue
        seen.add(claim_text)
        claim_type = _claim_type_from_text(claim_text)
        if claim_type == "factual":
            priority = _claim_priority(claim_text)
        else:
            priority = "not_ranked"
        entries.append(
            {
                "claim": claim_text,
                "claim_type": claim_type,
                "is_factual": claim_type == "factual",
                "verification_priority": priority,
                "why_check": _default_why_check(claim_type),
                "evidence_needed": _default_evidence_needed(claim_type),
                "suggested_queries": _default_suggested_queries(claim_text, claim_type),
                "likely_source_types": _default_likely_source_types(claim_type),
                "support_contrast_status": _default_support_contrast_status(claim_type),
                "uncertainty_note": _default_uncertainty_note(claim_type),
                "source_anchor": claim_text[:80],
                "confidence": "medium" if claim_type == "factual" else "low",
                "not_false_notice": CHECKWORTHY_NOTICE,
            }
        )
        if len(entries) >= limit:
            break

    factual = [entry for entry in entries if entry["is_factual"]]
    factual.sort(key=lambda entry: _priority_rank(entry["verification_priority"]))
    non_factual = [entry for entry in entries if not entry["is_factual"]]
    return factual + non_factual


def normalize_checkworthy_claims(data: dict[str, Any], subject_text: Any = "") -> dict[str, Any]:
    source = _extract_checkworthy_source(data)
    authored_entries, _used_authored = _normalize_checkworthy_from_authored(source)
    if authored_entries:
        factual = [entry for entry in authored_entries if entry["is_factual"]]
        factual.sort(key=lambda entry: _priority_rank(entry["verification_priority"]))
        non_factual = [entry for entry in authored_entries if not entry["is_factual"]]
        non_factual.sort(key=lambda entry: (entry["claim_type"], entry["claim"]))
        claims = factual + non_factual
        status = "authored"
    else:
        claims = _heuristic_checkworthy_claims(clean_text(subject_text or data.get("subject_text") or data.get("text") or ""))
        status = "heuristic" if claims else "mixed"

    for claim in claims:
        if claim["is_factual"]:
            claim["verification_priority"] = (
                claim["verification_priority"]
                if claim["verification_priority"] in CHECKWORTHY_PRIORITIES
                else _claim_priority(claim["claim"])
            )
        else:
            claim["verification_priority"] = "not_ranked"
        claim["not_false_notice"] = CHECKWORTHY_NOTICE
        if not claim.get("suggested_queries"):
            claim["suggested_queries"] = _default_suggested_queries(claim.get("claim", ""), claim.get("claim_type", "factual"))
        if not claim.get("likely_source_types"):
            claim["likely_source_types"] = _default_likely_source_types(claim.get("claim_type", "factual"))
        if not claim.get("support_contrast_status"):
            claim["support_contrast_status"] = _default_support_contrast_status(claim.get("claim_type", "factual"))
        if not claim.get("uncertainty_note"):
            claim["uncertainty_note"] = _default_uncertainty_note(claim.get("claim_type", "factual"))
        claim["verification_priority_label"] = _display_label(claim.get("verification_priority"), PRIORITY_LABELS)
        claim["support_contrast_label"] = _display_label(claim.get("support_contrast_status"), SUPPORT_CONTRAST_LABELS)

    markdown = checkworthy_claims_markdown({"claims": claims, "status": status})
    return {"claims": claims[:MAX_CHECKWORTHY_CLAIMS], "markdown": markdown, "status": status}


def argument_map_markdown(argument_map: dict[str, Any]) -> str:
    summary = clean_text(argument_map.get("plain_language_summary"))
    claim = clean_text(argument_map.get("central_claim"))
    claim_type = clean_text(argument_map.get("claim_type")) or "factual"
    confidence = clean_text(argument_map.get("confidence")) or "low"
    lines = [
        "# Argument Map",
        "",
        f"**Plain-language summary:** {summary or 'Not supplied.'}",
        f"**Central claim:** {claim or 'Not supplied.'}",
        f"**Claim type:** {claim_type}",
        f"**Confidence:** {confidence}",
        "",
    ]
    sections = [
        ("Supporting reasons", argument_map.get("supporting_reasons", [])),
        ("Objections", argument_map.get("objections", [])),
        ("Assumptions", argument_map.get("assumptions", [])),
        ("Missing voices", argument_map.get("missing_voices", [])),
        ("Evidence gaps", argument_map.get("evidence_gaps", [])),
        ("Next questions", argument_map.get("next_questions", [])),
    ]
    for title, items in sections:
        lines.append(f"## {title}")
        values = [clean_text(item) for item in ensure_list(items)]
        if values:
            lines.extend([f"- {cap_complete_words(value, 40)}" for value in values[:5]])
        else:
            lines.append("- Not supplied.")
        lines.append("")
    return "\n".join(lines).strip()


def argument_map_argdown(argument_map: dict[str, Any]) -> str:
    claim = clean_text(argument_map.get("central_claim")) or "Central claim not supplied."
    lines = [f"({claim})"]
    for reason in ensure_list(argument_map.get("supporting_reasons"))[:MAX_REASONS]:
        text = clean_text(reason)
        if text:
            lines.append(f"  + {text}")
    for objection in ensure_list(argument_map.get("objections"))[:MAX_OBJECTIONS]:
        text = clean_text(objection)
        if text:
            lines.append(f"  - {text}")
    for assumption in ensure_list(argument_map.get("assumptions"))[:MAX_ASSUMPTIONS]:
        text = clean_text(assumption)
        if text:
            lines.append(f"  ? {text}")
    for gap in ensure_list(argument_map.get("evidence_gaps"))[:MAX_GAPS]:
        text = clean_text(gap)
        if text:
            lines.append(f"  ! {text}")
    return "\n".join(lines).strip()


def checkworthy_claims_markdown(checkworthy_claims: dict[str, Any]) -> str:
    claims = ensure_list(checkworthy_claims.get("claims"))
    lines = [
        "# Checkworthy Claims",
        "",
        "Check-worthy means worth verifying, not false.",
        "",
        "| Priority | Claim | Type | Why check | Evidence needed |",
        "| --- | --- | --- | --- | --- |",
    ]
    if not claims:
        lines.append("| Not supplied | Not supplied | Not supplied | Not supplied | Not supplied |")
        return "\n".join(lines).strip()

    for claim in claims:
        if not isinstance(claim, dict):
            claim = _normalize_checkworthy_entry({"claim": claim})
        lines.append(
            "| {priority} | {claim} | {claim_type} | {why} | {evidence} |".format(
                priority=clean_text(claim.get("verification_priority_label")) or _display_label(claim.get("verification_priority"), PRIORITY_LABELS) or "Not ranked",
                claim=_table_cell(claim.get("claim")) or "Not supplied",
                claim_type=clean_text(claim.get("claim_type")) or "factual",
                why=_table_cell(claim.get("why_check")) or "Not supplied",
                evidence=_table_cell(claim.get("evidence_needed")) or "Not supplied",
            )
        )
        queries = "; ".join(_cap_list(claim.get("suggested_queries"), MAX_SUGGESTED_QUERIES, 140))
        source_types = "; ".join(_cap_list(claim.get("likely_source_types"), MAX_LIKELY_SOURCE_TYPES, 90))
        status = clean_text(claim.get("support_contrast_label")) or _display_label(claim.get("support_contrast_status"), SUPPORT_CONTRAST_LABELS)
        uncertainty = clean_text(claim.get("uncertainty_note"))
        if any([queries, source_types, status, uncertainty]):
            lines.append(
                f"  - Evidence plan: queries={_table_cell(queries) or 'Not supplied'}; "
                f"sources={_table_cell(source_types) or 'Not supplied'}; "
                f"support/contrast={_table_cell(status) or 'Not supplied'}; "
                f"uncertainty={_table_cell(uncertainty) or 'Not supplied'}"
            )
    return "\n".join(lines).strip()


def normalize_reasoning_artifacts(data: dict[str, Any], subject_text: Any = "") -> dict[str, Any]:
    return {
        "argument_map": normalize_argument_map(data, subject_text=subject_text),
        "checkworthy_claims": normalize_checkworthy_claims(data, subject_text=subject_text),
    }
