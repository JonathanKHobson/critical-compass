from __future__ import annotations

import re
from pathlib import Path
from typing import Any
from html import escape

from .models import (
    APPENDIX_INLINE_WORD_CAP,
    CIS_BANDS,
    MAX_LENGTHS,
    PAYLOAD_SCHEMA_VERSION,
    RENDER_VERSION,
    TEMPLATE_VERSION,
    ReportOptions,
    cap_chars,
    cap_complete_prose,
    cap_complete_words,
    cap_sentences,
    clean_text,
    dimension_color,
    ensure_list,
    first_text,
    infer_cis_label,
    normalize_audience,
    normalize_depth,
    normalize_display_state,
    normalize_mode,
    report_date,
    utc_now,
    word_count,
)
from .artifacts import normalize_reasoning_artifacts
from .trust import (
    blind_spot_reminder_candidates,
    detect_reasoning_traps,
    human_loop_interruption_triggers,
    normalize_dissent_ledger,
    source_tool_trust_preflight,
)


DEFAULT_DIMENSIONS = [
    ("grounding_scope_fit", "Grounding & Scope Fit"),
    ("assumptions_context", "Assumptions & Context"),
    ("bias_transparency", "Bias Transparency"),
    ("framing_audience_openness", "Framing & Audience Openness"),
    ("positionality_power", "Positionality & Power"),
]

REPORT_FIELD_ALIASES = {
    "cis.plain_language_read": [
        "critical_integrity_snapshot.plain_language_read",
        "critical_integrity_snapshot.plain_language",
        "critical_integrity_snapshot.executive_summary",
        "critical_integrity_snapshot.summary",
        "plain_language_read",
        "plain_language",
        "executive_summary",
        "summary",
    ],
    "cis.label": ["critical_integrity_snapshot.label", "cis.label", "cis_label", "label"],
    "cis.points": ["critical_integrity_snapshot.points", "critical_integrity_snapshot.score", "cis.points", "cis.score", "cis_score", "points", "score"],
    "cis.max_points": ["critical_integrity_snapshot.max_points", "critical_integrity_snapshot.max", "max_points", "max"],
    "cis.before_using_this_text": ["critical_integrity_snapshot.before_using_this_text", "cis.before_using_this_text", "before_using_this_text"],
    "cis.dimensions[].points": ["points", "score"],
    "cis.dimensions[].max_points": ["max_points", "max"],
    "cis.dimensions[].improvement_prompt": ["improvement_prompt", "action", "strengthen_prompt", "improvement", "next_step", "prompt"],
    "findings.biases": ["biases", "bias_rows", "top_biases", "bias_map", "quick_scan_card.top_biases", "findings.biases"],
    "findings.biases[].name": ["name", "bias", "bias_name", "title", "bias_id", "id"],
    "findings.key_tension": ["key_tension", "quick_scan_card.key_tension", "tensions[0]"],
    "findings.recommended_next_step": ["recommended_next_step", "quick_scan_card.recommended_next_step", "findings.recommended_next_step"],
    "assumptions": ["assumptions"],
    "alternative_frames": ["alternative_frames"],
    "questions.probing_or_follow_up": ["probing_questions", "follow_up_questions", "questions.probing", "questions.follow_up"],
    "next_steps": ["next_steps", "suggest_next_steps", "suggest_next_steps.next_steps", "suggest_next_steps.steps"],
    "advanced_audit.agents[].top_finding": ["top_finding", "finding", "key_finding", "primary_finding", "contribution", "key_contribution", "insight", "summary", "analyses[].primary_finding"],
    "advanced_audit.agents[].strongest_disagreement": ["strongest_disagreement", "disagreement", "counterpoint", "objection", "critique", "concern", "primary_disagreement", "analyses[].counterpoint"],
    "argument_map": ["argument_map", "argumentMap", "argument_structure", "reasoning_map"],
    "checkworthy_claims": ["checkworthy_claims", "check_worthy_claims", "claims_to_check", "evidence_needed_next"],
    "checkworthy_claims[].suggested_queries": ["suggested_queries", "queries", "search_queries", "fact_check_queries", "verification_queries"],
    "checkworthy_claims[].likely_source_types": ["likely_source_types", "source_types", "sources_to_check", "evidence_source_types", "likely_sources"],
    "checkworthy_claims[].support_contrast_status": ["support_contrast_status", "support_status", "evidence_status", "support_contrast"],
    "checkworthy_claims[].uncertainty_note": ["uncertainty_note", "uncertainty", "caveat", "limitations"],
    "external_fact_checks": ["external_fact_checks", "factcheck_results", "fact_check_results", "retrieved_fact_checks"],
    "advanced_audit.dissent_ledger": ["advanced_audit.dissent_ledger", "dissent_ledger", "agent_dissent", "disagreements"],
    "reasoning_traps": ["reasoning_traps", "trap_detectors", "reasoning_risks"],
    "source_tool_trust_preflight": ["source_tool_trust_preflight", "trust_preflight", "source_preflight", "source_result"],
    "follow_up_activity": ["follow_up_activity", "followup_activity", "teaching_activity", "activity_follow_up", "practice_suggestions", "quick_scan_card.follow_up_activity"],
    "follow_up_activity.try_this_next": ["try_this_next", "try_next", "quick_activity", "quick_follow_up", "activity"],
    "follow_up_activity.solo_activity": ["solo_activity", "solo", "solo_follow_up", "individual_activity", "personal_activity", "self_guided_activity"],
    "follow_up_activity.group_activity": ["group_activity", "group", "group_follow_up", "team_activity", "workshop_activity", "collaborative_activity"],
}

FIELD_CONSTRAINTS = {
    "cis.plain_language_read": {"max_sentences": 2, "max_words": 40, "tone": "plain, nontechnical"},
    "cis.before_using_this_text": {"max_sentences": 2, "required_prefix": "Before using this text,"},
    "follow_up_activity.try_this_next.content_focus": {"min_words": 5, "max_chars": MAX_LENGTHS["activity_content_focus"]},
    "follow_up_activity.solo_activity.content_focus": {"min_words": 5, "max_chars": MAX_LENGTHS["activity_content_focus"]},
    "follow_up_activity.group_activity.content_focus": {"min_words": 5, "max_chars": MAX_LENGTHS["activity_content_focus"]},
    "follow_up_activity.solo_activity.thinking_focus": {"required_for": "full/advanced reports"},
    "follow_up_activity.solo_activity.source_note": {"required_for": "full/advanced reports"},
    "follow_up_activity.group_activity.thinking_focus": {"required_for": "full/advanced reports"},
    "follow_up_activity.group_activity.source_note": {"required_for": "full/advanced reports"},
    "alternative_frames[].three_cs_lens": {"max_chars": MAX_LENGTHS["alternative_frame_lens"]},
    "follow_up_activity.*.thinking_focus[]": {"max_chars": MAX_LENGTHS["activity_thinking_focus"]},
    "reasoning_traps[].text_specific_check": {"required_when_rendered": True},
}

REPORT_INPUT_CONTRACT = {
    "host_ai_prompt": (
        "Before calling generate_audit_report, provide completed audit data with a Critical Integrity Snapshot, "
        "five dimensions, plain-language read, before-use text, key tension, recommended next step, bias rows, "
        "dimension improvement prompts, assumptions, alternative frames, questions, next steps, and agent top findings when advanced_audit is present. "
        "If audit_data includes human_loop.pending_prompt_ids or human_loop_host_action.must_pause=true, ask only the current "
        "mode-consent, onboarding, judgment, or reflection block before generating the final PDF unless the user explicitly requested a noninteractive test. "
        "Do not submit long prose expecting the renderer to truncate it; rewrite report-facing fields as concise complete sentences or paragraphs. "
        "If any report-critical field is unavailable, tell the user what is missing and ask for re-submission before requesting a final PDF. "
        "Use allow_placeholders=true only when the user explicitly requests a draft placeholder report."
    ),
    "required_for_polished_report": [
        "critical_integrity_snapshot.label and critical_integrity_snapshot.points for scored reports",
        "critical_integrity_snapshot.plain_language_read or alias",
        "critical_integrity_snapshot.before_using_this_text",
        "critical_integrity_snapshot.dimensions[] with name, points/score, max_points/max, rationale, and improvement prompt/alias",
        "biases/top_biases/bias_map rows with name/bias_name and why_it_matters when available",
        "key_tension or first usable tensions[] item",
        "recommended_next_step",
        "assumptions[] with assumption, testable/status, and evidence_needed",
        "alternative_frames[] with name/title, frame/description, and lens",
        "probing_questions/follow_up_questions or questions.probing/questions.follow_up",
        "next_steps",
        "follow_up_activity.try_this_next for quick/readiness-card output; full/advanced reports must include follow_up_activity.solo_activity and follow_up_activity.group_activity",
        "argument_map when available, preserving central_claim, support, objections, missing_voices, evidence_gaps, Markdown, and optional .argdown sidecar export",
        "checkworthy_claims when available, with only factual claims ranked for verification priority, suggested_queries, likely_source_types, support_contrast_status, uncertainty_note, and a clear not-false notice",
        "external_fact_checks only when the explicit opt-in factcheck_lookup tool returned real matches; retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts",
        "advanced_audit.agents[] normalized to agent_name/name, top_finding, strongest_disagreement when available, and confidence",
        "advanced_audit.dissent_ledger when advanced-audit agents disagree or confidence differs materially",
        "reasoning_traps when surfaced, labeled as advisory risks with a next check, not truth verdicts",
        "human_loop.state or human_loop_host_action when an audit returned pending human-loop prompts",
    ],
    "accepted_aliases": REPORT_FIELD_ALIASES,
    "field_constraints": FIELD_CONSTRAINTS,
    "cis_bands": CIS_BANDS,
    "allow_placeholders_policy": (
        "allow_placeholders=true is draft-only. It may permit placeholder override for a user-requested draft, "
        "but it never marks output as polished and cannot bypass renderer availability or reader-facing debug-string QA."
    ),
}


def new_diagnostics() -> dict[str, Any]:
    return {
        "schema_warnings": [],
        "missing_report_fields": [],
        "fallback_fields_used": [],
        "aliases_used": [],
        "accepted_aliases": REPORT_FIELD_ALIASES,
        "input_contract": REPORT_INPUT_CONTRACT,
    }


def is_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(clean_text(value))
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def first_present(mapping: dict[str, Any], aliases: list[str]) -> tuple[Any, str]:
    for alias in aliases:
        if alias in mapping and is_present(mapping[alias]):
            return mapping[alias], alias
    return None, ""


def _path_alias(path: tuple[Any, ...]) -> str:
    alias = ""
    for part in path:
        if isinstance(part, int):
            alias += f"[{part}]"
        else:
            alias += f".{part}" if alias else str(part)
    return alias


def first_present_nested(data: dict[str, Any], candidate_paths: list[tuple[Any, ...]]) -> tuple[Any, str]:
    for path in candidate_paths:
        current: Any = data
        for part in path:
            if isinstance(part, int):
                if not isinstance(current, list) or len(current) <= part:
                    current = None
                    break
                current = current[part]
                continue
            if not isinstance(current, dict) or part not in current:
                current = None
                break
            current = current[part]
        if is_present(current):
            return current, _path_alias(path)
    return None, ""


def record_alias(diagnostics: dict[str, Any], section: str, field: str, alias: str) -> None:
    if not alias or alias == field:
        return
    diagnostics["aliases_used"].append({"section": section, "field": field, "source": alias})


def record_fallback(diagnostics: dict[str, Any], section: str, field: str, accepted_aliases: list[str], fallback_text: str) -> None:
    warning = {
        "section": section,
        "field": field,
        "severity": "warning",
        "accepted_aliases": accepted_aliases,
        "fallback_rendered": True,
        "fallback_text": fallback_text,
        "message": f"{field} was not supplied; report rendered fallback text in {section}.",
        "fix": f"Re-submit audit_data with one of: {', '.join(accepted_aliases)}.",
    }
    diagnostics["schema_warnings"].append(warning)
    diagnostics["missing_report_fields"].append({"section": section, "field": field, "accepted_aliases": accepted_aliases})
    diagnostics["fallback_fields_used"].append(warning)


def record_schema_warning(
    diagnostics: dict[str, Any],
    *,
    section: str,
    field: str,
    message: str,
    fix: str,
    accepted_aliases: list[str] | None = None,
    fallback_rendered: bool = False,
    received_length: int | None = None,
    max_chars: int | None = None,
    suggested_value: str | None = None,
    did_you_mean: str | None = None,
) -> None:
    warning = {
        "section": section,
        "field": field,
        "severity": "warning",
        "accepted_aliases": accepted_aliases or [],
        "fallback_rendered": fallback_rendered,
        "message": message,
        "fix": fix,
    }
    if received_length is not None:
        warning["received_length"] = received_length
    if max_chars is not None:
        warning["max_chars"] = max_chars
    if suggested_value is not None:
        warning["suggested_value"] = suggested_value
    if did_you_mean is not None:
        warning["did_you_mean"] = did_you_mean
    diagnostics["schema_warnings"].append(warning)
    diagnostics["missing_report_fields"].append({"section": section, "field": field, "accepted_aliases": accepted_aliases or []})


def cap_with_warning(diagnostics: dict[str, Any], section: str, field: str, value: Any, max_chars: int) -> str:
    original = clean_text(value)
    capped = cap_complete_prose(original, max_chars)
    if original and capped != original:
        record_schema_warning(
            diagnostics,
            section=section,
            field=field,
            message=f"{field} exceeded the report length cap and was shortened before rendering.",
            fix=f"Re-submit {field} as a concise complete sentence or paragraph at {max_chars} characters or fewer.",
            accepted_aliases=[],
            fallback_rendered=False,
            received_length=len(original),
            max_chars=max_chars,
            suggested_value=capped,
        )
    return capped


def cap_sentences_with_warning(
    diagnostics: dict[str, Any],
    section: str,
    field: str,
    value: Any,
    max_sentences: int,
    max_chars: int,
) -> str:
    original = clean_text(value)
    capped = cap_sentences(original, max_sentences, max_chars)
    if original and capped != original:
        record_schema_warning(
            diagnostics,
            section=section,
            field=field,
            message=f"{field} exceeded the report sentence or length cap and was shortened before rendering.",
            fix=f"Re-submit {field} as {max_sentences} complete sentence(s) and {max_chars} characters or fewer.",
            accepted_aliases=[],
            fallback_rendered=False,
            received_length=len(original),
            max_chars=max_chars,
            suggested_value=capped,
        )
    return capped


def before_using_with_required_prefix(
    diagnostics: dict[str, Any],
    value: Any,
    *,
    field: str = "cis.before_using_this_text",
) -> str:
    capped = cap_sentences_with_warning(
        diagnostics,
        "Before Using This Text",
        field,
        value,
        2,
        MAX_LENGTHS["before_using_this_text"],
    )
    if not capped:
        return capped
    required = "Before using this text,"
    if capped.startswith(required):
        return capped
    lowered = capped.lower()
    for prefix in (
        "before sharing your draft,",
        "before sharing this text,",
        "before publishing this text,",
        "before acting on this text,",
        "before relying on this text,",
        "before citing this text,",
        "before you use this text,",
    ):
        if lowered.startswith(prefix):
            capped = capped[len(prefix):].strip()
            break
    if capped.lower().startswith("ask "):
        repaired = f"{required} {capped[0].lower() + capped[1:]}"
    elif capped.lower().startswith(("check ", "look ", "verify ", "name ", "think ", "consider ")):
        repaired = f"{required} {capped[0].lower() + capped[1:]}"
    else:
        repaired = f"{required} ask whether {capped[0].lower() + capped[1:] if capped else 'the text is ready to use'}"
    repaired = cap_sentences(repaired, 2, MAX_LENGTHS["before_using_this_text"])
    diagnostics["schema_warnings"].append(
        {
            "section": "Before Using This Text",
            "field": field,
            "severity": "warning",
            "accepted_aliases": REPORT_FIELD_ALIASES["cis.before_using_this_text"],
            "fallback_rendered": False,
            "message": "Before Using This Text did not start with the required opener and was normalized before rendering.",
            "fix": "Start the sentence exactly with 'Before using this text,'.",
        }
    )
    return repaired


def reader_facing_before_use(value: Any) -> str:
    text = clean_text(value)
    prefix = "Before using this text,"
    if text.startswith(prefix):
        stripped = text[len(prefix):].strip()
        if stripped:
            return stripped[0].upper() + stripped[1:]
    return text


def cap_plain_language_read(diagnostics: dict[str, Any], value: Any) -> str:
    original = clean_text(value)
    capped = cap_sentences(original, 2, MAX_LENGTHS["plain_language_read"])
    capped = cap_complete_words(capped, 40)
    if original and capped != original:
        record_schema_warning(
            diagnostics,
            section="Plain-Language Read",
            field="cis.plain_language_read",
            message="Plain-Language Read exceeded the two-sentence / 40-word plain-read cap and was shortened before rendering.",
            fix="Re-submit Plain-Language Read as one or two nontechnical sentences, 40 words or fewer.",
            accepted_aliases=REPORT_FIELD_ALIASES["cis.plain_language_read"],
            fallback_rendered=False,
        )
    return capped


EVIDENCE_CONVENTION_LABELS = {
    "authority_based": "Evidence convention: this text relies mainly on practitioner authority, experience, or role-based expertise.",
    "experiential_testimony": "Evidence convention: this text relies mainly on lived or practitioner experience.",
    "citation_based": "Evidence convention: this text relies mainly on cited sources.",
    "institutional_reporting": "Evidence convention: this text relies mainly on institutional records or reporting.",
    "communal_consensus": "Evidence convention: this text relies mainly on community agreement or shared standards.",
    "program_evaluation": "Evidence convention: this text relies mainly on program evidence or evaluation claims.",
    "hybrid": "Evidence convention: this text mixes more than one evidence basis.",
    "unclear": "Evidence convention: the text does not make its evidence basis clear.",
}


def infer_evidence_convention(text: str, current: Any) -> str:
    existing = clean_text(current).lower()
    if existing:
        return existing
    lowered = clean_text(text).lower()
    if re.search(r"\b(years of experience|decades of experience|based on direct observation|developed through practice|from my practice|in my consulting work|clients i have seen|practitioner|consultant|advisor|clinician|professional standard)\b", lowered):
        return "authority_based"
    return ""


def evidence_convention_label(value: Any) -> str:
    key = clean_text(value).lower()
    return EVIDENCE_CONVENTION_LABELS.get(key, f"Evidence convention: {key.replace('_', ' ')}." if key else "")


def normalize_score(item: dict[str, Any], aliases: list[str], default: int) -> tuple[int, str]:
    value, alias = first_present(item, aliases)
    if isinstance(value, bool):
        return default, ""
    if isinstance(value, int):
        return value, alias
    if isinstance(value, float):
        return int(round(value)), alias
    text = clean_text(value)
    if text.isdigit():
        return int(text), alias
    return default, ""


def normalize_options(
    audit_data: dict[str, Any],
    *,
    report_audience: str | None = None,
    report_depth: str | None = None,
    report_mode: str | None = None,
    include_raw_text: bool = False,
    report_title: str | None = None,
    output_path: str | None = None,
) -> ReportOptions:
    cis = extract_cis(audit_data)
    snapshot_mode = first_text(cis.get("snapshot_mode"))
    return ReportOptions(
        report_audience=normalize_audience(report_audience, snapshot_mode=snapshot_mode),
        report_depth=normalize_depth(report_depth),
        report_mode=normalize_mode(report_mode),
        include_raw_text=bool(include_raw_text),
        report_title=cap_chars(report_title, MAX_LENGTHS["report_title"]) if report_title else None,
        output_path=Path(output_path).expanduser().resolve() if output_path else None,
    )


def extract_cis(data: dict[str, Any]) -> dict[str, Any]:
    for key in ("critical_integrity_snapshot", "cis_snapshot", "cis"):
        value = data.get(key)
        if isinstance(value, dict):
            return value
    quick = data.get("quick_scan_card")
    if isinstance(quick, dict) and isinstance(quick.get("critical_integrity_snapshot"), dict):
        return quick["critical_integrity_snapshot"]
    result_payload = data.get("result_payload")
    if isinstance(result_payload, dict):
        return extract_cis(result_payload)
    payload = data.get("payload")
    if isinstance(payload, dict):
        return extract_cis(payload)
    if any(is_present(data.get(key)) for key in ("cis_score", "cis_label")):
        return {
            "points": data.get("cis_score"),
            "label": data.get("cis_label"),
            "max_points": data.get("cis_max_points") or data.get("max_points") or 100,
        }
    return {}


def extract_quick_scan(data: dict[str, Any]) -> dict[str, Any]:
    quick = data.get("quick_scan_card")
    if isinstance(quick, dict):
        return quick
    result_payload = data.get("result_payload")
    if isinstance(result_payload, dict):
        return extract_quick_scan(result_payload)
    payload = data.get("payload")
    if isinstance(payload, dict):
        return extract_quick_scan(payload)
    return {}


def extract_text_type(data: dict[str, Any], quick: dict[str, Any]) -> str:
    return clean_text(data.get("text_type") or quick.get("text_type") or data.get("domain") or "general")


def extract_subject_text(data: dict[str, Any]) -> str:
    for key in ("subject_text", "subject", "text", "full_text"):
        if clean_text(data.get(key)):
            return clean_text(data.get(key))
    result_payload = data.get("result_payload")
    if isinstance(result_payload, dict):
        return extract_subject_text(result_payload)
    payload = data.get("payload")
    if isinstance(payload, dict):
        return extract_subject_text(payload)
    return ""


def nested_payload_candidates(data: dict[str, Any], key: str) -> list[tuple[Any, ...]]:
    return [
        (key,),
        ("payload", key),
        ("result_payload", key),
    ]


def extract_biases(data: dict[str, Any], quick: dict[str, Any], diagnostics: dict[str, Any]) -> list[dict[str, Any]]:
    candidates, source = first_present_nested(
        data,
        [
            ("biases",),
            ("bias_rows",),
            ("top_biases",),
            ("bias_map",),
            ("quick_scan_card", "top_biases"),
            ("findings", "biases"),
            ("payload", "findings", "biases"),
            ("result_payload", "findings", "biases"),
        ],
    )
    if not is_present(candidates):
        candidates, source = first_present(quick, ["top_biases", "biases", "bias_map"])
    if not is_present(candidates):
        candidates, source = data.get("biases_found"), "biases_found"
    if is_present(candidates):
        record_alias(diagnostics, "Top Biases Identified", "findings.biases", source)
    rows: list[dict[str, Any]] = []
    for item in ensure_list(candidates):
        if isinstance(item, str):
            rows.append(
                {
                    "name": cap_chars(item, 60),
                    "kb_id": "",
                    "passage": "",
                    "why_it_matters": "This pattern may shape what the reader notices or ignores.",
                    "three_cs_lens": "Critical",
                }
            )
            continue
        if not isinstance(item, dict):
            continue
        name, name_alias = first_present(item, REPORT_FIELD_ALIASES["findings.biases[].name"])
        record_alias(diagnostics, "Top Biases Identified", "findings.biases[].name", name_alias)
        if name_alias == "bias":
            record_schema_warning(
                diagnostics,
                section="Top Biases Identified",
                field="findings.biases[].name",
                message="bias_rows[].bias was accepted as a natural alias for the canonical bias name field.",
                fix="Prefer findings.biases[].name in final report-ready payloads.",
                accepted_aliases=REPORT_FIELD_ALIASES["findings.biases[].name"],
                did_you_mean="findings.biases[].name",
            )
        passage = item.get("passage") or item.get("claim_passage") or item.get("evidence") or item.get("justification") or ""
        why = item.get("why_it_matters") or item.get("why_it_qualifies") or item.get("reason") or item.get("justification")
        rows.append(
            {
                "name": cap_chars(name, 60),
                "kb_id": cap_chars(item.get("kb_id") or item.get("bias_id") or item.get("id") or item.get("entry_id"), 80),
                "passage": cap_complete_words(passage, 12),
                "why_it_matters": cap_complete_prose(why or "This pattern may shape what the reader notices or ignores.", MAX_LENGTHS["bias_why_it_matters"]),
                "three_cs_lens": cap_chars(item.get("three_cs_lens") or item.get("lens") or "Critical", 24),
            }
        )
    return rows[:5]


def normalize_dimensions(cis: dict[str, Any], diagnostics: dict[str, Any]) -> list[dict[str, Any]]:
    source = ensure_list(cis.get("dimensions"))
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(source[:5]):
        if not isinstance(item, dict):
            continue
        fallback_key, fallback_name = DEFAULT_DIMENSIONS[index] if index < len(DEFAULT_DIMENSIONS) else (f"dimension_{index + 1}", f"Dimension {index + 1}")
        max_points, max_alias = normalize_score(item, ["max_points", "max"], 20)
        points, points_alias = normalize_score(item, ["points", "score"], 0)
        prompt, prompt_alias = first_present(item, REPORT_FIELD_ALIASES["cis.dimensions[].improvement_prompt"])
        if not is_present(prompt):
            prompt = "Name the evidence, assumption, or missing voice a reader should test next."
            record_fallback(
                diagnostics,
                "Dimension Improvement Prompts",
                "cis.dimensions[].improvement_prompt",
                REPORT_FIELD_ALIASES["cis.dimensions[].improvement_prompt"],
                prompt,
            )
        record_alias(diagnostics, "Dimension Deep-Dive", "cis.dimensions[].points", points_alias)
        record_alias(diagnostics, "Dimension Deep-Dive", "cis.dimensions[].max_points", max_alias)
        record_alias(diagnostics, "Dimension Improvement Prompts", "cis.dimensions[].improvement_prompt", prompt_alias)
        rows.append(
            {
                "key": clean_text(item.get("key") or fallback_key),
                "name": cap_chars(item.get("name") or fallback_name, 80),
                "points": max(0, min(int(points), int(max_points or 20))),
                "max_points": int(max_points or 20),
                "rationale": cap_with_warning(
                    diagnostics,
                    "Dimension Deep-Dive",
                    "cis.dimensions[].rationale",
                    item.get("rationale") or "No rationale was provided in the audit output.",
                    MAX_LENGTHS["dimension_rationale"],
                ),
                "trace": [cap_chars(trace, 120) for trace in ensure_list(item.get("trace"))],
                "improvement_prompt": cap_with_warning(
                    diagnostics,
                    "Dimension Improvement Prompts",
                    "cis.dimensions[].improvement_prompt",
                    prompt,
                    MAX_LENGTHS["improvement_prompt"],
                ),
            }
        )
    if rows:
        return rows
    return [
        {
            "key": key,
            "name": name,
            "points": 0,
            "max_points": 20,
            "rationale": "Dimension data was missing from the audit output.",
            "trace": [],
            "improvement_prompt": "Re-run the audit with a Critical Integrity Snapshot before generating a full report.",
        }
        for key, name in DEFAULT_DIMENSIONS
    ]


def normalize_assumptions(data: dict[str, Any], diagnostics: dict[str, Any]) -> list[dict[str, str]]:
    source, source_alias = first_present_nested(
        data,
        [
            *nested_payload_candidates(data, "assumptions"),
            ("findings", "assumptions"),
            ("payload", "findings", "assumptions"),
            ("result_payload", "findings", "assumptions"),
        ],
    )
    if is_present(source):
        record_alias(diagnostics, "Assumption Audit", "assumptions", source_alias)
    else:
        source = []
    rows: list[dict[str, str]] = []
    for item in ensure_list(source)[:8]:
        if isinstance(item, str):
            rows.append(
                {
                    "assumption": cap_with_warning(diagnostics, "Assumption Audit", "assumptions[].assumption", item, MAX_LENGTHS["assumption"]),
                    "testable": "testable",
                    "evidence_needed": "Name the evidence that would confirm or weaken this assumption.",
                }
            )
            continue
        if not isinstance(item, dict):
            continue
        assumption = item.get("assumption") or item.get("claim") or item.get("text") or item.get("name")
        testable = item.get("testable") or item.get("status") or "testable"
        evidence = item.get("evidence_needed") or item.get("what_would_test_this") or item.get("what_evidence_would_test_this") or item.get("test")
        rows.append(
            {
                "assumption": cap_with_warning(diagnostics, "Assumption Audit", "assumptions[].assumption", assumption, MAX_LENGTHS["assumption"]),
                "testable": cap_chars(testable, 40),
                "evidence_needed": cap_with_warning(
                    diagnostics,
                    "Assumption Audit",
                    "assumptions[].evidence_needed",
                    evidence or "Look for direct evidence that would confirm or weaken the assumption.",
                    MAX_LENGTHS["evidence_needed"],
                ),
            }
        )
    return rows


def normalize_frames(data: dict[str, Any], diagnostics: dict[str, Any]) -> list[dict[str, str]]:
    source, source_alias = first_present_nested(
        data,
        [
            *nested_payload_candidates(data, "alternative_frames"),
            ("frames",),
            ("alternative_frame",),
            ("findings", "alternative_frames"),
            ("payload", "findings", "alternative_frames"),
            ("result_payload", "findings", "alternative_frames"),
        ],
    )
    if is_present(source):
        record_alias(diagnostics, "Alternative Frames", "alternative_frames", source_alias)
    else:
        source = []
    rows: list[dict[str, str]] = []
    for item in ensure_list(source)[:6]:
        if isinstance(item, str):
            rows.append(
                {
                    "name": cap_chars(item, 80),
                    "kb_id": "",
                    "frame": "Use this frame to test whether the text closes off a credible alternative.",
                    "three_cs_lens": "Creative",
                }
            )
            continue
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "name": cap_chars(item.get("name") or item.get("title") or item.get("frame_name"), 80),
                "kb_id": cap_chars(item.get("kb_id") or item.get("entry_id") or item.get("id"), 80),
                "frame": cap_with_warning(
                    diagnostics,
                    "Alternative Frames",
                    "alternative_frames[].frame",
                    item.get("frame") or item.get("description") or item.get("applied_frame") or item.get("definition"),
                    MAX_LENGTHS["alternative_frame"],
                ),
                "three_cs_lens": cap_with_warning(
                    diagnostics,
                    "Alternative Frames",
                    "alternative_frames[].three_cs_lens",
                    item.get("three_cs_lens") or item.get("lens") or "Creative",
                    MAX_LENGTHS["alternative_frame_lens"],
                ),
            }
        )
    return rows


def normalize_tension(data: dict[str, Any], quick: dict[str, Any], diagnostics: dict[str, Any]) -> str:
    value, source = first_present_nested(
        data,
        [
            ("key_tension",),
            ("quick_scan_card", "key_tension"),
            ("findings", "key_tension"),
            ("payload", "findings", "key_tension"),
            ("result_payload", "findings", "key_tension"),
        ],
    )
    if not is_present(value):
        value, source = first_present(quick, ["key_tension"])
    if not is_present(value):
        for item in ensure_list(data.get("tensions")):
            if isinstance(item, str) and clean_text(item):
                value = item
                source = "tensions[0]"
                break
            if isinstance(item, dict):
                value, item_source = first_present(item, ["key_tension", "tension", "summary", "description", "name", "label"])
                if is_present(value):
                    source = f"tensions[0].{item_source}"
                    break
    if is_present(value):
        record_alias(diagnostics, "Key Tension", "findings.key_tension", source)
        return cap_sentences_with_warning(diagnostics, "Key Tension", "findings.key_tension", value, 1, MAX_LENGTHS["key_tension"])
    fallback = "No key tension was supplied in the audit output."
    record_fallback(diagnostics, "Key Tension", "findings.key_tension", REPORT_FIELD_ALIASES["findings.key_tension"], fallback)
    return fallback


def normalize_questions(data: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, list[str]]:
    questions, questions_alias = first_present_nested(
        data,
        [
            ("questions",),
            ("payload", "questions"),
            ("result_payload", "questions"),
        ],
    )
    if not isinstance(questions, dict):
        questions = {}
    else:
        record_alias(diagnostics, "Questions Checklist", "questions", questions_alias)
    probing, probing_alias = first_present_nested(
        data,
        [
            ("probing_questions",),
            ("questions", "probing"),
            ("payload", "questions", "probing"),
            ("result_payload", "questions", "probing"),
        ],
    )
    follow_up, follow_alias = first_present_nested(
        data,
        [
            ("follow_up_questions",),
            ("questions", "follow_up"),
            ("payload", "questions", "follow_up"),
            ("result_payload", "questions", "follow_up"),
        ],
    )
    if not is_present(probing):
        probing = questions.get("probing") or []
    if not is_present(follow_up):
        follow_up = questions.get("follow_up") or []
    record_alias(diagnostics, "Probing Questions", "questions.probing", probing_alias)
    record_alias(diagnostics, "Follow-Up Questions", "questions.follow_up", follow_alias)
    return {
        "probing": [cap_with_warning(diagnostics, "Probing Questions", "questions.probing[]", item, MAX_LENGTHS["question"]) for item in ensure_list(probing)[:8]],
        "follow_up": [cap_with_warning(diagnostics, "Follow-Up Questions", "questions.follow_up[]", item, MAX_LENGTHS["question"]) for item in ensure_list(follow_up)[:8]],
    }


def normalize_next_steps(data: dict[str, Any], diagnostics: dict[str, Any]) -> list[str]:
    source, source_alias = first_present_nested(
        data,
        [
            ("next_steps",),
            ("suggest_next_steps",),
            ("suggest_next_steps", "next_steps"),
            ("suggest_next_steps", "steps"),
            ("payload", "next_steps"),
            ("payload", "suggest_next_steps"),
            ("payload", "suggest_next_steps", "next_steps"),
            ("payload", "suggest_next_steps", "steps"),
            ("result_payload", "next_steps"),
            ("result_payload", "suggest_next_steps"),
            ("result_payload", "suggest_next_steps", "next_steps"),
            ("result_payload", "suggest_next_steps", "steps"),
        ],
    )
    record_alias(diagnostics, "Next Steps", "next_steps", source_alias)
    source = source or []
    if isinstance(source, dict):
        source = source.get("next_steps") or source.get("steps") or source.get("recommendations") or []
    return [cap_with_warning(diagnostics, "Next Steps", "next_steps[]", item, MAX_LENGTHS["next_step"]) for item in ensure_list(source)[:8]]


def default_activity_card(role: str) -> dict[str, Any]:
    if role == "group":
        return {
            "title": "Micro Lab Protocol",
            "why_this_fits": "A structured review can test whether the text is clear, supported, and safe to use with the intended audience.",
            "steps": [
                "Give reviewers one passage and one feedback question.",
                "Collect what confused, concerned, or persuaded them.",
                "Turn the feedback into one revision and one verification task.",
            ],
            "content_focus": "Use the passage most likely to affect trust, inclusion, or action.",
            "thinking_focus": ["critical", "compassionate"],
            "source_note": "Curated from Critical Compass.",
            "safety_note": "Use real consultation where lived experience matters; do not ask participants to impersonate affected groups.",
        }
    return {
        "title": "Claim-Support-Question",
        "why_this_fits": "The text depends on a claim whose support should be separated from what remains unresolved.",
        "steps": [
            "Pick the claim doing the most work.",
            "Name the exact support the text gives.",
            "Write one honest question that would need an answer before relying on it.",
        ],
        "content_focus": "Use the claim that carries the most decision weight.",
        "thinking_focus": ["critical"],
        "source_note": "Curated from Critical Compass.",
    }


def _first_activity_card(source: dict[str, Any], keys: list[str]) -> tuple[Any, str]:
    for key in keys:
        value = source.get(key)
        if is_present(value):
            return value, key
    return {}, ""


def _looks_like_activity_card(source: dict[str, Any]) -> bool:
    return any(key in source for key in ("title", "name", "activity", "activity_title", "steps", "instructions", "prompt"))


def sanitize_activity_source_note(value: Any, *, fallback: str = "Curated from Critical Compass.") -> str:
    text = clean_text(value)
    if not text:
        return fallback
    lowered = text.lower()
    if any(token in lowered for token in ("file-o-fun", "file o fun", "knowledge atlas", "beta.", "no live atlas", "local activity pack")):
        return fallback
    return text


def normalize_activity_card(item: Any, diagnostics: dict[str, Any], *, section_label: str, fallback_role: str) -> dict[str, Any]:
    if isinstance(item, str):
        item = {"title": item}
    if not isinstance(item, dict):
        item = {}
    fallback = default_activity_card(fallback_role)
    title = item.get("title") or item.get("name") or item.get("activity_title") or item.get("activity") or fallback["title"]
    why = (
        item.get("why_this_fits")
        or item.get("why_it_fits")
        or item.get("why")
        or item.get("use_when")
        or item.get("rationale")
        or item.get("reason")
        or fallback["why_this_fits"]
    )
    steps = (
        item.get("steps")
        or item.get("prompts")
        or item.get("instructions")
        or item.get("directions")
        or item.get("procedure")
        or item.get("prompt")
        or fallback["steps"]
    )
    if isinstance(steps, str):
        split_steps = [part.strip() for part in steps.replace(";", ".").split(".") if part.strip()]
        steps = split_steps or [steps]
    normalized = {
        "title": cap_with_warning(diagnostics, section_label, "follow_up_activity.title", title, MAX_LENGTHS["activity_title"]),
        "why_this_fits": cap_with_warning(diagnostics, section_label, "follow_up_activity.why_this_fits", why, MAX_LENGTHS["activity_why"]),
        "steps": [
            cap_with_warning(diagnostics, section_label, "follow_up_activity.steps[]", step, MAX_LENGTHS["activity_step"])
            for step in ensure_list(steps)[:4]
        ],
        "content_focus": cap_with_warning(
            diagnostics,
            section_label,
            "follow_up_activity.content_focus",
            item.get("content_focus")
            or item.get("content_focus_template")
            or item.get("passage_focus")
            or item.get("claim_focus")
            or item.get("focus")
            or fallback["content_focus"],
            MAX_LENGTHS["activity_content_focus"],
        ),
        "thinking_focus": [
            cap_with_warning(
                diagnostics,
                section_label,
                "follow_up_activity.thinking_focus[]",
                focus,
                MAX_LENGTHS["activity_thinking_focus"],
            )
            for focus in ensure_list(item.get("thinking_focus") or item.get("skill_focus") or item.get("thinking_mode") or fallback["thinking_focus"])[:3]
        ],
        "source_note": cap_with_warning(
            diagnostics,
            section_label,
            "follow_up_activity.source_note",
            sanitize_activity_source_note(item.get("source_note") or item.get("source") or item.get("origin") or item.get("reference_note") or fallback["source_note"]),
            MAX_LENGTHS["activity_source_note"],
        ),
        "source_id": cap_chars(item.get("source_id") or item.get("activity_id") or item.get("record_id") or item.get("kb_id"), 80),
    }
    safety_note = item.get("safety_note") or fallback.get("safety_note")
    if safety_note:
        normalized["safety_note"] = cap_with_warning(
            diagnostics,
            section_label,
            "follow_up_activity.safety_note",
            safety_note,
            MAX_LENGTHS["activity_safety_note"],
        )
    return normalized


def normalize_activity_fit_check(source: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, str]:
    fit = source.get("fit_check") if isinstance(source.get("fit_check"), dict) else {}
    return {
        "prompt": cap_with_warning(
            diagnostics,
            "Activity Reflection",
            "follow_up_activity.fit_check.prompt",
            fit.get("prompt") or "After trying this activity, note what helped and what you would change.",
            MAX_LENGTHS["activity_safety_note"],
        ),
        "reflection_question": cap_with_warning(
            diagnostics,
            "Activity Reflection",
            "follow_up_activity.fit_check.reflection_question",
            fit.get("reflection_question") or "What worked, what felt mismatched, and what should change before the next review?",
            MAX_LENGTHS["activity_safety_note"],
        ),
        "persistence": cap_chars(fit.get("persistence") or "non_persistent", 40),
        "no_persistence_note": cap_with_warning(
            diagnostics,
            "Activity Reflection",
            "follow_up_activity.fit_check.no_persistence_note",
            fit.get("no_persistence_note") or "Use these notes to choose whether to keep, swap, or skip this activity next time.",
            MAX_LENGTHS["activity_safety_note"],
        ),
    }


def normalize_follow_up_activity(data: dict[str, Any], quick: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, Any]:
    source, source_alias = first_present_nested(
        data,
        [
            ("follow_up_activity",),
            ("followup_activity",),
            ("teaching_activity",),
            ("activity_follow_up",),
            ("quick_scan_card", "follow_up_activity"),
            ("payload", "follow_up_activity"),
            ("result_payload", "follow_up_activity"),
        ],
    )
    if not is_present(source):
        source, source_alias = first_present(quick, ["follow_up_activity"])
    if isinstance(source, list):
        source = {"try_this_next": source[0] if source else {}, "solo_activity": source[0] if source else {}, "group_activity": source[1] if len(source) > 1 else {}}
    if not isinstance(source, dict):
        legacy, legacy_alias = first_present_nested(
            data,
            [
                ("practice_suggestions",),
                ("payload", "practice_suggestions"),
                ("result_payload", "practice_suggestions"),
            ],
        )
        suggestions = ensure_list(legacy)
        source_note = "Generated by host AI from legacy practice suggestions." if suggestions else "Curated from Critical Compass."
        source = {
            "try_this_next": suggestions[0] if suggestions else {},
            "solo_activity": suggestions[0] if suggestions else {},
            "group_activity": suggestions[1] if len(suggestions) > 1 else {},
            "source_note": source_note,
        }
        source_alias = legacy_alias
    if is_present(source):
        record_alias(diagnostics, "Follow-Up Activity", "follow_up_activity", source_alias)
    source_card = source if isinstance(source, dict) and _looks_like_activity_card(source) else {}
    suggestions = ensure_list(source.get("activities") or source.get("activity_suggestions") or source.get("suggestions"))
    try_card, try_alias = _first_activity_card(source, REPORT_FIELD_ALIASES["follow_up_activity.try_this_next"])
    solo_card, solo_alias = _first_activity_card(source, REPORT_FIELD_ALIASES["follow_up_activity.solo_activity"])
    group_card, group_alias = _first_activity_card(source, REPORT_FIELD_ALIASES["follow_up_activity.group_activity"])
    if not is_present(try_card):
        try_card = source_card or (suggestions[0] if suggestions else {})
    if not is_present(solo_card):
        solo_card = source_card or try_card or (suggestions[0] if suggestions else {})
    if not is_present(group_card):
        group_card = suggestions[1] if len(suggestions) > 1 else {}
    record_alias(diagnostics, "Follow-Up Activity", "follow_up_activity.try_this_next", try_alias)
    record_alias(diagnostics, "Solo Follow-Up Activity", "follow_up_activity.solo_activity", solo_alias)
    record_alias(diagnostics, "Group Follow-Up Activity", "follow_up_activity.group_activity", group_alias)
    return {
        "mode": cap_chars(source.get("mode") or "curated_critical_compass", 60),
        "try_this_next": normalize_activity_card(try_card or solo_card, diagnostics, section_label="Follow-Up Activity", fallback_role="solo"),
        "solo_activity": normalize_activity_card(solo_card or try_card, diagnostics, section_label="Solo Follow-Up Activity", fallback_role="solo"),
        "group_activity": normalize_activity_card(group_card, diagnostics, section_label="Group Follow-Up Activity", fallback_role="group"),
        "source_note": cap_with_warning(
            diagnostics,
            "Follow-Up Activity",
            "follow_up_activity.source_note",
            sanitize_activity_source_note(source.get("source_note") or "Curated from Critical Compass."),
            MAX_LENGTHS["activity_source_note"],
        ),
        "guardrails": [
            cap_with_warning(diagnostics, "Follow-Up Activity", "follow_up_activity.guardrails[]", item, MAX_LENGTHS["activity_safety_note"])
            for item in ensure_list(source.get("guardrails"))[:4]
        ],
        "fit_check": normalize_activity_fit_check(source, diagnostics),
    }


def normalize_agents(data: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, Any]:
    advanced = data.get("advanced_audit") if isinstance(data.get("advanced_audit"), dict) else {}
    agents_source = advanced.get("agents") or data.get("agents") or []
    if not agents_source and isinstance(data.get("payload"), dict):
        payload_advanced = data["payload"].get("advanced_audit")
        if isinstance(payload_advanced, dict):
            advanced = payload_advanced
            agents_source = payload_advanced.get("agents") or []
    analyses_by_agent: dict[str, dict[str, Any]] = {}
    for analysis in ensure_list(data.get("analyses")):
        if isinstance(analysis, dict):
            key = clean_text(analysis.get("agent_name") or analysis.get("name") or analysis.get("agent_id"))
            if key:
                analyses_by_agent[key] = analysis
    rows = []
    for item in ensure_list(agents_source)[:6]:
        if isinstance(item, str):
            rows.append({"name": cap_chars(item, 80), "reasoning_style": "", "top_finding": "", "kb_id": ""})
            continue
        if not isinstance(item, dict):
            continue
        name = clean_text(item.get("name") or item.get("agent_name") or item.get("agent_id"))
        analysis = analyses_by_agent.get(name, {})
        finding, finding_alias = first_present(item, ["top_finding", "finding", "key_finding", "primary_finding", "contribution", "key_contribution", "insight", "summary"])
        if not is_present(finding):
            finding, analysis_alias = first_present(analysis, ["top_finding", "primary_finding", "finding", "key_finding", "contribution", "key_contribution", "insight", "summary"])
            finding_alias = f"analyses[].{analysis_alias}" if analysis_alias else ""
        disagreement, disagreement_alias = first_present(item, ["strongest_disagreement", "disagreement", "counterpoint", "objection", "critique", "concern", "primary_disagreement"])
        if not is_present(disagreement):
            disagreement, analysis_disagreement_alias = first_present(analysis, ["strongest_disagreement", "disagreement", "counterpoint", "objection", "critique", "concern", "primary_disagreement"])
            disagreement_alias = f"analyses[].{analysis_disagreement_alias}" if analysis_disagreement_alias else ""
        if not is_present(finding):
            finding = ""
            record_fallback(
                diagnostics,
                "Analytical Lens Attribution",
                "advanced_audit.agents[].top_finding",
                REPORT_FIELD_ALIASES["advanced_audit.agents[].top_finding"],
                "Finding not supplied",
            )
        record_alias(diagnostics, "Analytical Lens Attribution", "advanced_audit.agents[].top_finding", finding_alias)
        record_alias(diagnostics, "Analytical Lens Attribution", "advanced_audit.agents[].strongest_disagreement", disagreement_alias)
        rows.append(
            {
                "agent_name": cap_chars(name, 80),
                "name": cap_chars(name, 80),
                "reasoning_style": cap_chars(item.get("reasoning_style") or item.get("primary_reasoning_style") or item.get("reasoning_philosophy"), 80),
                "top_finding": cap_with_warning(
                    diagnostics,
                    "Analytical Lens Attribution",
                    "advanced_audit.agents[].top_finding",
                    finding,
                    MAX_LENGTHS["agent_top_finding"],
                ),
                "strongest_disagreement": cap_chars(disagreement, 180),
                "confidence": cap_chars(item.get("confidence") or item.get("confidence_level") or analysis.get("confidence") or analysis.get("confidence_level"), 40),
                "kb_id": cap_chars(item.get("kb_id") or analysis.get("kb_id") or analysis.get("bias_id"), 80),
            }
        )
    verdict = advanced.get("verdict_paragraph") or data.get("verdict_paragraph") or ""
    if isinstance(data.get("verdict"), dict):
        verdict = verdict or data["verdict"].get("verdict") or data["verdict"].get("summary") or ""
    elif clean_text(data.get("verdict")):
        verdict = verdict or data.get("verdict")
    return {
        "present": bool(rows or advanced.get("present")),
        "agents": rows,
        "verdict_paragraph": cap_with_warning(
            diagnostics,
            "Verdict Note",
            "advanced_audit.verdict_paragraph",
            verdict,
            MAX_LENGTHS["verdict_paragraph"],
        ),
    }


def extract_dict_recursive(data: dict[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key)
    if isinstance(value, dict):
        return value
    result_payload = data.get("result_payload")
    if isinstance(result_payload, dict):
        nested = extract_dict_recursive(result_payload, key)
        if nested:
            return nested
    human_loop = data.get("human_loop") if isinstance(data.get("human_loop"), dict) else {}
    value = human_loop.get(key)
    if isinstance(value, dict):
        return value
    state = human_loop.get("state") if isinstance(human_loop.get("state"), dict) else {}
    value = state.get(key)
    if isinstance(value, dict):
        return value
    return {}


def extract_list_recursive(data: dict[str, Any], key: str) -> list[Any]:
    value = data.get(key)
    if isinstance(value, list):
        return value
    result_payload = data.get("result_payload")
    if isinstance(result_payload, dict):
        nested = extract_list_recursive(result_payload, key)
        if nested:
            return nested
    human_loop = data.get("human_loop") if isinstance(data.get("human_loop"), dict) else {}
    value = human_loop.get(key)
    if isinstance(value, list):
        return value
    return []


def record_pending_human_loop_warnings(data: dict[str, Any], diagnostics: dict[str, Any]) -> None:
    human_loop = extract_dict_recursive(data, "human_loop")
    host_action = extract_dict_recursive(data, "human_loop_host_action")
    state = human_loop.get("state") if isinstance(human_loop.get("state"), dict) else {}
    pending = ensure_list(human_loop.get("pending_prompt_ids")) or ensure_list(state.get("pending_prompt_ids"))
    must_pause = bool(host_action.get("must_pause"))
    mode = clean_text(human_loop.get("mode") or state.get("human_loop_mode"))
    if (pending or must_pause) and mode != "silent":
        record_schema_warning(
            diagnostics,
            section="Human Loop Layer",
            field="human_loop.pending_prompt_ids",
            accepted_aliases=["human_loop.pending_prompt_ids", "human_loop.state.pending_prompt_ids", "human_loop_host_action.must_pause"],
            fallback_rendered=False,
            message="The audit still has unanswered human-loop prompts; report generation should not be presented as final without user confirmation.",
            fix="Ask the pending mode-consent, onboarding, judgment, or reflection prompts, pass the updated human_loop.state, or explicitly run a noninteractive smoke test and disclose that prompts were skipped.",
        )


def normalize_human_commentary(data: dict[str, Any]) -> dict[str, Any]:
    source = extract_dict_recursive(data, "human_auditor_commentary")
    include = bool(source.get("include_in_report", True))
    text = cap_complete_prose(source.get("commentary_text"), MAX_LENGTHS["human_commentary"])
    response = cap_complete_prose(source.get("ai_response_to_commentary"), MAX_LENGTHS["ai_commentary_response"])
    present = bool(include and (text or response))
    return {
        "present": present,
        "include_in_report": include,
        "user_role": cap_chars(source.get("user_role") or "unknown", 60),
        "commentary_text": text,
        "collected_after_stage": cap_chars(source.get("collected_after_stage") or "findings_frozen", 80),
        "collected_at": cap_chars(source.get("collected_at"), 80),
        "ai_response_to_commentary": response,
        "commentary_bucket": cap_chars(source.get("commentary_bucket") or "commentary", 60),
    }


def normalize_divergence_map(data: dict[str, Any]) -> dict[str, Any]:
    source = extract_dict_recursive(data, "divergence_map")
    items: list[dict[str, str]] = []
    for item in ensure_list(source.get("items"))[:6]:
        if not isinstance(item, dict):
            continue
        ai_position = cap_complete_prose(item.get("ai_audit_position"), MAX_LENGTHS["divergence_field"])
        human_position = cap_complete_prose(item.get("human_auditor_position"), MAX_LENGTHS["divergence_field"])
        if not ai_position and not human_position:
            continue
        items.append(
            {
                "topic": cap_chars(item.get("topic") or "Human-AI divergence", 100),
                "type": cap_chars(item.get("type") or "interpretive", 40),
                "ai_audit_position": ai_position,
                "human_auditor_position": human_position,
                "resolution": cap_complete_prose(item.get("resolution") or "Preserve both positions with provenance.", MAX_LENGTHS["divergence_field"]),
            }
        )
    return {"present": bool(items), "items": items}


def normalize_learning_notes(data: dict[str, Any]) -> list[str]:
    source = extract_list_recursive(data, "learning_notes")
    if not source:
        source_dict = extract_dict_recursive(data, "learning_notes")
        source = source_dict.get("items") if isinstance(source_dict.get("items"), list) else []
    return [cap_complete_prose(item, MAX_LENGTHS["learning_note"]) for item in ensure_list(source)[:5]]


def normalize_provenance_footer(
    data: dict[str, Any],
    human_commentary: dict[str, Any],
    divergence_map: dict[str, Any],
    learning_notes: list[str],
) -> dict[str, Any]:
    source = extract_dict_recursive(data, "provenance_footer")
    human_loop_state = extract_dict_recursive(data, "human_loop_state")
    if not human_loop_state:
        human_loop = data.get("human_loop") if isinstance(data.get("human_loop"), dict) else {}
        human_loop_state = human_loop.get("state") if isinstance(human_loop.get("state"), dict) else {}
    audit_version = source.get("audit_version") or human_loop_state.get("audit_version") or 1
    findings_frozen = source.get("ai_findings_finalized_at") or human_loop_state.get("findings_frozen_at")
    commentary_added = source.get("human_commentary_added_at") or human_commentary.get("collected_at")
    present = bool(source or human_commentary.get("present") or divergence_map.get("present") or learning_notes or human_loop_state)
    return {
        "present": present,
        "ai_findings_finalized_at": cap_chars(findings_frozen, 80),
        "human_commentary_added_at": cap_chars(commentary_added, 80),
        "audit_version": audit_version,
        "findings_rerun": bool(source.get("findings_rerun") or human_loop_state.get("needs_rerun")),
        "payload_hash": cap_chars(source.get("payload_hash"), 100),
    }


def _readiness_checkworthy_claims(payload: dict[str, Any]) -> list[dict[str, Any]]:
    source = payload.get("checkworthy_claims") if isinstance(payload.get("checkworthy_claims"), dict) else {}
    rows = [item for item in ensure_list(source.get("claims")) if isinstance(item, dict)]
    if rows:
        return rows
    for group in ("factual", "interpretive", "causal", "normative", "policy"):
        for item in ensure_list(source.get(group)):
            if isinstance(item, dict):
                row = dict(item)
                row.setdefault("claim_type", group)
                rows.append(row)
    return rows


def build_pressure_test_readiness_card(payload: dict[str, Any]) -> dict[str, str]:
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    argument_map = payload.get("argument_map") if isinstance(payload.get("argument_map"), dict) else {}
    context_lens = cis.get("context_lens") if isinstance(cis.get("context_lens"), dict) else {}
    label = clean_text(cis.get("label")) or "Profile only"
    points = cis.get("points")
    max_points = cis.get("max_points") or 100
    claims = _readiness_checkworthy_claims(payload)
    high_priority_factual = [
        claim
        for claim in claims
        if clean_text(claim.get("claim_type") or claim.get("type")) == "factual"
        and clean_text(claim.get("verification_priority")) == "high"
    ]
    evidence_signal = "No high-confidence factual claims were flagged for independent verification."
    if high_priority_factual:
        evidence_signal = "High-priority factual claim still needs verification."
    elif claims:
        evidence_signal = "Evidence-needed plan is present; use it before treating the text as settled."
    missing_voices = [clean_text(item) for item in ensure_list(argument_map.get("missing_voices")) if clean_text(item)]
    positionality = next(
        (
            item
            for item in ensure_list(cis.get("dimensions"))
            if isinstance(item, dict) and "positionality" in clean_text(item.get("name"))
        ),
        {},
    )
    positionality_points = positionality.get("points") if isinstance(positionality.get("points"), int) else None
    missing_voice_risk = "No explicit missing-voice cue supplied."
    if missing_voices:
        missing_voice_risk = "Missing voices to check: " + "; ".join(missing_voices[:3])
    elif positionality_points is not None and positionality_points < 14:
        missing_voice_risk = "Positionality & Power score suggests audience or affected-stakeholder risk."
    trust_eligible = (
        points is not None
        and points >= 70
        and label in {"Strong Integrity", "Exemplary Integrity"}
        and not missing_voices
        and not (positionality_points is not None and positionality_points < 14)
    )
    if high_priority_factual:
        action = "Verify"
        rationale = "A key factual claim still needs evidence before the text should carry a decision."
    elif label == "Needs Scrutiny" or (points is not None and points < 25):
        action = "Reframe"
        rationale = "The integrity signal is too weak to rely on without reframing the text's purpose, evidence, or audience."
    elif label == "Limited Integrity" or (points is not None and points < 50):
        action = "Reframe" if missing_voices or (positionality_points is not None and positionality_points < 14) else "Revise"
        rationale = "The integrity signal says the text needs substantial revision before use."
    elif label == "Moderate Integrity" or (points is not None and points < 70):
        action = "Verify"
        rationale = "The text has usable parts, but the audit signal is not strong enough to treat it as settled."
    elif missing_voices or (positionality_points is not None and positionality_points < 14):
        action = "Reframe"
        rationale = "The text may need a broader audience, power, or missing-voice frame before use."
    elif trust_eligible:
        action = "Trust"
        rationale = "The current audit signals are strong enough to use carefully while preserving the stated caveats."
    else:
        action = "Verify"
        rationale = "The audit does not show a blocking issue, but the score is not strong enough for a trust recommendation."
    cis_signal = f"{label} ({points}/{max_points})" if points is not None and cis.get("display_state") != "profile_only" else label
    plain = clean_text(cis.get("plain_language_read"))
    next_move = clean_text(findings.get("recommended_next_step"))
    executive_summary_parts = [
        plain,
        f"The main action is {action.lower()}: {rationale[0].lower() + rationale[1:] if rationale else ''}",
        f"Evidence signal: {evidence_signal}",
        f"Next move: {next_move}" if next_move else "",
    ]
    executive_summary = cap_complete_words(" ".join(part for part in executive_summary_parts if part), 85)
    return {
        "decision_action": action,
        "rationale": rationale,
        "cis_signal": cis_signal,
        "evidence_strength_signal": evidence_signal,
        "missing_voice_risk": missing_voice_risk,
        "before_use_caution": reader_facing_before_use(cis.get("before_using_this_text")),
        "next_move": next_move,
        "executive_summary": executive_summary,
        "evidence_convention": clean_text(context_lens.get("evidence_convention")),
    }


def build_kb_coverage_signal(payload: dict[str, Any]) -> dict[str, Any]:
    verified = 0
    total = 0
    unverified: list[str] = []
    for section, rows in (
        ("biases", ensure_list((payload.get("findings") or {}).get("biases")) if isinstance(payload.get("findings"), dict) else []),
        ("alternative_frames", ensure_list(payload.get("alternative_frames"))),
        ("agents", ensure_list((payload.get("advanced_audit") or {}).get("agents")) if isinstance(payload.get("advanced_audit"), dict) else []),
    ):
        for row in rows:
            if not isinstance(row, dict):
                continue
            name = clean_text(row.get("name") or row.get("agent_name") or row.get("title"))
            if not name:
                continue
            total += 1
            if clean_text(row.get("kb_id") or row.get("concept_id") or row.get("entry_id")):
                verified += 1
            else:
                unverified.append(f"{section}: {name}")
    return {
        "verified_items": verified,
        "total_items": total,
        "coverage_ratio": round(verified / total, 2) if total else None,
        "unverified_inferences": unverified[:8],
        "note": "Items without KB IDs should be treated as host-AI inference rather than KB-verified labels.",
        "reader_badge": "Corpus-Grounded" if total and verified / total >= 0.5 else "",
        "warning": "Low KB grounding: named lenses or labels are mostly host inference." if total and verified / total < 0.25 else "",
        "qa_blocking": False,
    }


def default_title(text_type: str, date: str) -> str:
    text_type_label = clean_text(text_type).title() or "General"
    return f"Critical Integrity Report - {text_type_label} - {date}"


def self_plain_language(label: str | None) -> str:
    coaching = {
        "Exemplary Integrity": "Your draft is unusually clear about evidence, standpoint, and reader action. Keep the structure and tighten only what helps someone act.",
        "Strong Integrity": "Your draft is close to usable. Name the remaining gaps before you rely on it or share it with a decision-maker.",
        "Moderate Integrity": "Your draft can work, but the claims carrying the most weight need clearer evidence, limits, or alternative framing.",
        "Limited Integrity": "Your draft needs another pass before it should represent your judgment. Strengthen evidence, alternatives, and positionality first.",
        "Needs Scrutiny": "Your draft is not ready to carry a decision. Slow down and make the hidden assumptions, beneficiaries, and missing voices visible.",
    }
    return coaching.get(label or "", "Use this as coaching: strengthen the visible evidence, assumptions, and reader-facing action before sharing.")


def apply_self_mode(payload: dict[str, Any]) -> None:
    cis = payload["cis"]
    cis["plain_language_read"] = self_plain_language(cis.get("label"))
    before_text = clean_text(cis.get("before_using_this_text"))
    if not before_text.startswith("Before using this text,"):
        before_text = f"Before using this text, ask whether your draft is ready for the audience, evidence standard, and decision it is meant to support."
    cis["before_using_this_text"] = before_text
    for dimension in cis["dimensions"]:
        prompt = dimension.get("improvement_prompt") or ""
        if prompt and not prompt.lower().startswith("your "):
            dimension["improvement_prompt"] = f"Your next revision should: {prompt[0].lower() + prompt[1:] if len(prompt) > 1 else prompt}"


def normalize_reasoning_traps_payload(data: dict[str, Any], subject_text: str) -> list[dict[str, Any]]:
    explicit, _ = first_present_nested(
        data,
        [
            ("reasoning_traps",),
            ("trap_detectors",),
            ("reasoning_risks",),
            ("payload", "reasoning_traps"),
            ("result_payload", "reasoning_traps"),
        ],
    )
    raw_items: list[Any] = []
    if isinstance(explicit, dict):
        raw_items = ensure_list(explicit.get("traps") or explicit.get("items") or explicit.get("risks"))
    elif isinstance(explicit, list):
        raw_items = explicit
    if raw_items:
        traps: list[dict[str, Any]] = []
        for item in raw_items[:5]:
            if isinstance(item, str):
                continue
            if not isinstance(item, dict):
                continue
            label = clean_text(item.get("label") or item.get("name") or item.get("trap") or item.get("id"))
            if not label:
                continue
            signals = [cap_chars(signal, 80) for signal in ensure_list(item.get("signals") or item.get("evidence"))[:4]]
            text_anchor = cap_complete_prose(item.get("text_anchor") or item.get("anchor") or item.get("passage") or first_text(signals), 180)
            if not text_anchor:
                continue
            next_check = cap_complete_prose(item.get("next_check") or item.get("check") or item.get("prompt"), 180)
            text_specific = cap_complete_prose(
                item.get("text_specific_check")
                or item.get("specific_check")
                or f"Use the passage '{text_anchor}' and {next_check[0].lower() + next_check[1:] if next_check else 'name the evidence or perspective that would test it.'}",
                240,
            )
            traps.append(
                {
                    "id": clean_text(item.get("id") or item.get("trap_id")),
                    "label": cap_chars(label, 80),
                    "risk": cap_complete_prose(item.get("risk") or item.get("description") or item.get("why_it_matters"), 220),
                    "next_check": next_check,
                    "text_anchor": text_anchor,
                    "text_specific_check": text_specific,
                    "severity": clean_text(item.get("severity") or item.get("confidence") or "medium"),
                    "signals": signals,
                }
            )
        return traps

    trap_report = detect_reasoning_traps({**data, "subject_text": subject_text})
    normalized: list[dict[str, Any]] = []
    for item in ensure_list(trap_report.get("traps"))[:5] if isinstance(trap_report, dict) else []:
        if not isinstance(item, dict):
            continue
        signals = [cap_chars(signal, 80) for signal in ensure_list(item.get("signals"))[:4]]
        text_anchor = cap_complete_prose(item.get("text_anchor") or first_text(signals), 180)
        if not text_anchor:
            continue
        next_check = cap_complete_prose(item.get("next_check"), 180)
        normalized.append(
            {
                **item,
                "text_anchor": text_anchor,
                "text_specific_check": cap_complete_prose(
                    item.get("text_specific_check")
                    or f"Use the passage '{text_anchor}' and {next_check[0].lower() + next_check[1:] if next_check else 'name the evidence or perspective that would test it.'}",
                    240,
                ),
            }
        )
    return normalized


def normalize_external_fact_checks(data: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, Any]:
    source, source_alias = first_present_nested(
        data,
        [
            ("external_fact_checks",),
            ("factcheck_results",),
            ("fact_check_results",),
            ("retrieved_fact_checks",),
            ("payload", "external_fact_checks"),
            ("payload", "factcheck_results"),
            ("payload", "fact_check_results"),
            ("result_payload", "external_fact_checks"),
            ("result_payload", "factcheck_results"),
            ("result_payload", "fact_check_results"),
        ],
    )
    if not is_present(source):
        return {
            "present": False,
            "results": [],
            "note": "External fact checks were not requested. Core audits do not run external retrieval by default.",
        }
    record_alias(diagnostics, "External Fact Checks", "external_fact_checks", source_alias)
    if isinstance(source, dict):
        raw_results = source.get("results")
        if not isinstance(raw_results, list) and source.get("matches"):
            raw_results = [source]
    elif isinstance(source, list):
        raw_results = source
    else:
        raw_results = []

    results: list[dict[str, Any]] = []
    def caution_label(item: Any) -> str:
        if isinstance(item, dict):
            return clean_text(item.get("message") or item.get("code"))
        return clean_text(item)

    for result in ensure_list(raw_results)[:8]:
        if not isinstance(result, dict):
            continue
        status = clean_text(result.get("status"))
        matches: list[dict[str, Any]] = []
        for match in ensure_list(result.get("matches"))[:6]:
            if not isinstance(match, dict):
                continue
            review = match.get("review") if isinstance(match.get("review"), dict) else {}
            url = clean_text(review.get("url"))
            publisher_site = clean_text(review.get("publisher_site") or review.get("site"))
            if not url or not publisher_site:
                continue
            try:
                confidence = float(match.get("match_confidence", 0.0) or 0.0)
            except (TypeError, ValueError):
                confidence = 0.0
            matches.append(
                {
                    "matched_claim_text": cap_complete_prose(match.get("matched_claim_text") or match.get("claim") or match.get("text"), 240),
                    "claimant": cap_chars(match.get("claimant"), 120),
                    "claim_date": cap_chars(match.get("claim_date"), 40),
                    "review": {
                        "publisher_name": cap_chars(review.get("publisher_name") or review.get("name") or publisher_site, 120),
                        "publisher_site": cap_chars(publisher_site, 120),
                        "url": cap_chars(url, 500),
                        "title": cap_chars(review.get("title"), 180),
                        "review_date": cap_chars(review.get("review_date"), 40),
                        "textual_rating": cap_chars(review.get("textual_rating"), 100),
                        "language_code": cap_chars(review.get("language_code"), 20),
                    },
                    "match_confidence": max(0.0, min(confidence, 1.0)),
                }
            )
        if not matches:
            continue
        if status not in {"match_found", "multiple_matches", "conflicting_reviews"}:
            status = "multiple_matches" if len(matches) > 1 else "match_found"
        results.append(
            {
                "claim_id": cap_chars(result.get("claim_id") or result.get("id"), 80),
                "status": status,
                "summary": cap_complete_prose(result.get("summary"), 240),
                "matches": matches,
                "cautions": [cap_complete_prose(caution_label(item), 180) for item in ensure_list(result.get("cautions"))[:6] if caution_label(item)],
                "provider_notes": [cap_complete_prose(item, 180) for item in ensure_list(result.get("provider_notes"))[:6]],
            }
        )
    return {
        "present": bool(results),
        "results": results,
        "note": "Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.",
    }


def normalize_source_trust_payload(data: dict[str, Any], subject_text: str) -> dict[str, Any]:
    source_info, _ = first_present_nested(
        data,
        [
            ("source_tool_trust_preflight",),
            ("trust_preflight",),
            ("source_preflight",),
            ("source_result",),
            ("prepare_audit_source",),
            ("payload", "source_tool_trust_preflight"),
            ("result_payload", "source_tool_trust_preflight"),
        ],
    )
    if isinstance(source_info, dict) and source_info:
        return source_tool_trust_preflight(source_info)
    if clean_text(data.get("source_path")):
        return source_tool_trust_preflight(
            {
                "source_path": data.get("source_path"),
                "status": data.get("source_status") or "unknown",
                "text": subject_text,
                "text_char_count": len(subject_text),
                "text_word_count": word_count(subject_text),
            }
        )
    return {
        "status": "not_run",
        "warnings": [],
        "consent_boundaries": {
            "local_only": True,
            "external_retrieval_allowed": False,
            "notes": "No source preflight data was supplied; core audits do not perform automatic external retrieval.",
        },
    }


def dimension_bar_svg(dimensions: list[dict[str, Any]]) -> str:
    width = 560
    row_height = 34
    label_width = 210
    bar_width = 260
    score_x = label_width + bar_width + 20
    height = max(1, len(dimensions)) * row_height
    parts = [f'<svg class="dimension-svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Critical Integrity dimension profile">']
    for index, dimension in enumerate(dimensions):
        y = index * row_height + 6
        points = int(dimension.get("points") or 0)
        max_points = int(dimension.get("max_points") or 20)
        fill_width = int(round((points / max(max_points, 1)) * bar_width))
        color = dimension_color(points, max_points)
        name = escape(clean_text(dimension.get("name")))
        score = f"{points}/{max_points}"
        parts.append(f'<text x="0" y="{y + 13}" fill="#222222" font-family="Arial, Helvetica, sans-serif" font-size="11">{name}</text>')
        parts.append(f'<rect x="{label_width}" y="{y}" width="{bar_width}" height="14" rx="3" fill="#E8E8E8" />')
        parts.append(f'<rect x="{label_width}" y="{y}" width="{fill_width}" height="14" rx="3" fill="{color}" />')
        parts.append(f'<text x="{score_x}" y="{y + 13}" fill="#666666" font-family="Arial, Helvetica, sans-serif" font-size="11">{score}</text>')
    parts.append("</svg>")
    return "".join(parts)


def normalize_audit_data(data: dict[str, Any], options: ReportOptions) -> dict[str, Any]:
    diagnostics = new_diagnostics()
    record_pending_human_loop_warnings(data, diagnostics)
    quick = extract_quick_scan(data)
    cis_source = extract_cis(data)
    if isinstance(cis_source, dict):
        cis_source = dict(cis_source)
        if not is_present(cis_source.get("label")) and is_present(data.get("cis_label")):
            cis_source["label"] = data.get("cis_label")
        if not any(is_present(cis_source.get(key)) for key in ("points", "score")) and is_present(data.get("cis_score")):
            cis_source["points"] = data.get("cis_score")
        if not any(is_present(cis_source.get(key)) for key in ("max_points", "max")) and is_present(data.get("cis_max_points")):
            cis_source["max_points"] = data.get("cis_max_points")
    dimensions = normalize_dimensions(cis_source, diagnostics)
    text_type = extract_text_type(data, quick)
    subject_text = extract_subject_text(data)
    date = report_date()
    context_lens = cis_source.get("context_lens") if isinstance(cis_source.get("context_lens"), dict) else data.get("context_lens") if isinstance(data.get("context_lens"), dict) else {}
    evidence_convention = infer_evidence_convention(subject_text, context_lens.get("evidence_convention"))
    knowledge_tradition = clean_text(
        data.get("knowledge_tradition")
        or data.get("rhetorical_tradition")
        or context_lens.get("knowledge_tradition")
        or context_lens.get("rhetorical_tradition")
        or evidence_convention
        or "unspecified"
    )
    display_state = normalize_display_state(cis_source.get("display_state"))
    label, label_source = first_present(cis_source, ["label", "cis_label"])
    label = clean_text(label) or None
    points, points_source = normalize_score(cis_source, ["points", "score"], -1)
    points = points if points >= 0 else None
    max_points, max_points_source = normalize_score(cis_source, ["max_points", "max"], 100)
    if not label and points is not None and display_state != "profile_only":
        label = infer_cis_label(points) or None
        if label:
            record_schema_warning(
                diagnostics,
                section="Critical Integrity Snapshot",
                field="cis.label",
                message="CIS label was missing and was inferred from points using the published CIS band table.",
                fix="Prefer passing critical_integrity_snapshot.label or cis_label with scored reports.",
                accepted_aliases=REPORT_FIELD_ALIASES["cis.label"],
            )
    record_alias(diagnostics, "Critical Integrity Snapshot", "cis.label", label_source)
    record_alias(diagnostics, "Critical Integrity Snapshot", "cis.points", points_source)
    record_alias(diagnostics, "Critical Integrity Snapshot", "cis.max_points", max_points_source)
    plain_language_read, plain_source = first_present_nested(
        data,
        [
            ("critical_integrity_snapshot", "plain_language_read"),
            ("critical_integrity_snapshot", "plain_language"),
            ("critical_integrity_snapshot", "executive_summary"),
            ("critical_integrity_snapshot", "summary"),
            ("cis_snapshot", "plain_language_read"),
            ("cis", "plain_language_read"),
            ("plain_language_read",),
            ("plain_language",),
            ("executive_summary",),
            ("summary",),
            ("payload", "cis", "plain_language_read"),
            ("result_payload", "cis", "plain_language_read"),
        ],
    )
    if not is_present(plain_language_read):
        plain_language_read = ""
        if options.report_mode == "reader":
            record_fallback(
                diagnostics,
                "Plain-Language Read",
                "cis.plain_language_read",
                REPORT_FIELD_ALIASES["cis.plain_language_read"],
                "No plain-language read was supplied.",
            )
    record_alias(diagnostics, "Plain-Language Read", "cis.plain_language_read", plain_source)
    before_using_text, before_source = first_present_nested(
        data,
        [
            ("critical_integrity_snapshot", "before_using_this_text"),
            ("cis_snapshot", "before_using_this_text"),
            ("cis", "before_using_this_text"),
            ("before_using_this_text",),
            ("payload", "cis", "before_using_this_text"),
            ("payload", "critical_integrity_snapshot", "before_using_this_text"),
            ("result_payload", "cis", "before_using_this_text"),
            ("result_payload", "critical_integrity_snapshot", "before_using_this_text"),
        ],
    )
    if not is_present(before_using_text):
        record_schema_warning(
            diagnostics,
            section="Before Using This Text",
            field="cis.before_using_this_text",
            message="cis.before_using_this_text was not supplied; full reports will be blocked until this reader guidance is provided.",
            fix="Re-submit audit_data with critical_integrity_snapshot.before_using_this_text or cis.before_using_this_text.",
            accepted_aliases=REPORT_FIELD_ALIASES["cis.before_using_this_text"],
            fallback_rendered=True,
        )
        before_using_text = ""
    record_alias(diagnostics, "Before Using This Text", "cis.before_using_this_text", before_source)
    recommended_next_step, recommended_source = first_present_nested(
        data,
        [
            ("recommended_next_step",),
            ("quick_scan_card", "recommended_next_step"),
            ("findings", "recommended_next_step"),
            ("payload", "findings", "recommended_next_step"),
            ("result_payload", "findings", "recommended_next_step"),
        ],
    )
    if not is_present(recommended_next_step):
        recommended_next_step = "Use the probing questions before treating the claim as settled."
        record_fallback(
            diagnostics,
            "Recommended Next Step",
            "findings.recommended_next_step",
            REPORT_FIELD_ALIASES["findings.recommended_next_step"],
            recommended_next_step,
        )
    record_alias(diagnostics, "Recommended Next Step", "findings.recommended_next_step", recommended_source)
    raw_word_count = word_count(subject_text)
    appendix_included = bool(options.include_raw_text and subject_text)
    appendix_inline = appendix_included and raw_word_count <= APPENDIX_INLINE_WORD_CAP
    human_commentary = normalize_human_commentary(data)
    divergence_map = normalize_divergence_map(data)
    learning_notes = normalize_learning_notes(data)
    provenance_footer = normalize_provenance_footer(data, human_commentary, divergence_map, learning_notes)
    reasoning_artifacts = normalize_reasoning_artifacts(data, subject_text=subject_text)
    explicit_argument_map, _ = first_present_nested(
        data,
        [
            ("argument_map",),
            ("argumentMap",),
            ("argument_structure",),
            ("reasoning_map",),
            ("payload", "argument_map"),
            ("result_payload", "argument_map"),
        ],
    )
    explicit_checkworthy, _ = first_present_nested(
        data,
        [
            ("checkworthy_claims",),
            ("check_worthy_claims",),
            ("claims_to_check",),
            ("evidence_needed_next",),
            ("payload", "checkworthy_claims"),
            ("result_payload", "checkworthy_claims"),
        ],
    )
    if not is_present(subject_text) and not is_present(explicit_argument_map):
        reasoning_artifacts["argument_map"] = {}
    if not is_present(subject_text) and not is_present(explicit_checkworthy):
        reasoning_artifacts["checkworthy_claims"] = {}
    advanced_audit = normalize_agents(data, diagnostics)
    explicit_dissent, _ = first_present_nested(
        data,
        [
            ("advanced_audit", "dissent_ledger"),
            ("dissent_ledger",),
            ("agent_dissent",),
            ("disagreements",),
            ("payload", "advanced_audit", "dissent_ledger"),
            ("result_payload", "advanced_audit", "dissent_ledger"),
        ],
    )
    dissent_ledger = normalize_dissent_ledger(data)
    if dissent_ledger.get("present") and is_present(explicit_dissent):
        advanced_audit["dissent_ledger"] = ensure_list(dissent_ledger.get("entries"))
    else:
        advanced_audit["dissent_ledger"] = []
    advanced_audit["consensus_only"] = bool(advanced_audit["dissent_ledger"]) and all(
        isinstance(entry, dict)
        and clean_text(entry.get("consensus_note"))
        and not clean_text(entry.get("strongest_disagreement") or entry.get("disagreement"))
        for entry in advanced_audit["dissent_ledger"]
    )
    reasoning_traps = normalize_reasoning_traps_payload(data, subject_text)
    trust_preflight = normalize_source_trust_payload(data, subject_text)
    interruption_triggers = human_loop_interruption_triggers(
        {
            **data,
            "subject_text": subject_text,
            "schema_warnings": diagnostics.get("schema_warnings"),
            "missing_report_fields": diagnostics.get("missing_report_fields"),
        }
    )
    blind_spot_reminders = blind_spot_reminder_candidates(
        {
            "reasoning_traps": reasoning_traps,
            "human_loop_interruption_triggers": interruption_triggers,
        },
        text_type=text_type,
    )
    normalized_before_using = before_using_with_required_prefix(diagnostics, before_using_text)

    payload = {
        "meta": {
            "schema_version": PAYLOAD_SCHEMA_VERSION,
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "locale": "en-US",
            "document_language": "en",
            "brand": "critical-compass",
            "date": date,
            "generated_at": utc_now(),
            "text_type": text_type,
            "knowledge_tradition": knowledge_tradition,
            "mode": "MCP-Enhanced",
            "report_audience": options.report_audience,
            "report_depth": options.report_depth,
            "report_mode": options.report_mode,
            "snapshot_mode": clean_text(cis_source.get("snapshot_mode") or "organizer"),
            "audit_method": "Advanced panel + structured debate" if advanced_audit.get("present") else "Standard audit",
            "report_title": options.report_title or default_title(text_type, date),
            "qa_required": True,
            "render_preview": True,
            "host_inference_heavy": bool(
                data.get("host_inference_heavy")
                or data.get("allow_host_inference_heavy")
                or clean_text(data.get("kb_grounding_override")).lower() == "host_inference_ok"
            ),
        },
        "cis": {
            "label": label,
            "points": points,
            "max_points": max_points,
            "display_state": display_state,
            "score_confidence": clean_text(cis_source.get("score_confidence") or ""),
            "comparability": clean_text(cis_source.get("comparability") or ""),
            "plain_language_read": cap_plain_language_read(diagnostics, plain_language_read),
            "before_using_this_text": normalized_before_using,
            "before_using_display": reader_facing_before_use(normalized_before_using),
            "withheld_reason": clean_text(cis_source.get("withheld_reason") or ""),
            "context_lens": {
                "evidence_convention": evidence_convention,
                "evidence_convention_label": evidence_convention_label(evidence_convention),
                "scoring_note": clean_text(context_lens.get("scoring_note") or ""),
                "sensitive_dimensions": [clean_text(item) for item in ensure_list(context_lens.get("sensitive_dimensions"))],
            },
            "dimensions": dimensions,
        },
        "findings": {
            "biases": extract_biases(data, quick, diagnostics),
            "key_tension": normalize_tension(data, quick, diagnostics),
            "recommended_next_step": cap_sentences_with_warning(
                diagnostics,
                "Recommended Next Step",
                "findings.recommended_next_step",
                recommended_next_step,
                1,
                180,
            ),
        },
        "assumptions": normalize_assumptions(data, diagnostics),
        "alternative_frames": normalize_frames(data, diagnostics),
        "questions": normalize_questions(data, diagnostics),
        "next_steps": normalize_next_steps(data, diagnostics),
        "follow_up_activity": normalize_follow_up_activity(data, quick, diagnostics),
        "argument_map": reasoning_artifacts.get("argument_map", {}),
        "checkworthy_claims": reasoning_artifacts.get("checkworthy_claims", {}),
        "external_fact_checks": normalize_external_fact_checks(data, diagnostics),
        "advanced_audit": advanced_audit,
        "reasoning_traps": reasoning_traps,
        "source_tool_trust_preflight": trust_preflight,
        "human_loop_interruption_triggers": interruption_triggers.get("triggers", []) if isinstance(interruption_triggers, dict) else [],
        "blind_spot_reminders": blind_spot_reminders,
        "human_auditor_commentary": human_commentary,
        "divergence_map": divergence_map,
        "learning_notes": learning_notes,
        "provenance_footer": provenance_footer,
        "appendix": {
            "include_raw_text": appendix_included,
            "inline_raw_text": appendix_inline,
            "raw_word_count": raw_word_count,
            "word_cap": APPENDIX_INLINE_WORD_CAP,
            "subject_text": subject_text,
            "sidecar_path": "",
        },
        "diagnostics": diagnostics,
    }
    if payload["cis"]["display_state"] == "profile_only":
        payload["cis"]["label"] = None
        payload["cis"]["points"] = None
        if not payload["cis"]["withheld_reason"]:
            payload["cis"]["withheld_reason"] = "Aggregate score withheld - text too short or tradition unclear for reliable comparison."
    if payload["meta"]["report_mode"] == "self":
        apply_self_mode(payload)
    payload["pressure_test_readiness_card"] = build_pressure_test_readiness_card(payload)
    payload["kb_coverage_signal"] = build_kb_coverage_signal(payload)
    kb_signal = payload["kb_coverage_signal"]
    if (
        advanced_audit.get("present")
        and payload["meta"]["report_depth"] == "full"
        and kb_signal.get("warning")
        and not payload["meta"]["host_inference_heavy"]
    ):
        kb_signal["qa_blocking"] = True
        diagnostics["kb_grounding_warning"] = kb_signal["warning"]
        record_schema_warning(
            diagnostics,
            section="Corpus Grounding",
            field="kb_coverage_signal",
            message=kb_signal["warning"],
            fix="Call lookup_bias/search_knowledge_base/get_framework during advanced analysis and include kb_id fields, or explicitly pass host_inference_heavy=true for a host-inference draft.",
        )
    payload["cis"]["dimension_bar_svg"] = dimension_bar_svg(payload["cis"]["dimensions"])
    return payload
