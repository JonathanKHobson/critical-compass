from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .models import QA_VERSION, clean_text, ensure_list, issue

FALLBACK_TEXT_CHECKS = [
    ("plain_language_read_fallback", "No plain-language read was supplied.", "Plain-Language Read rendered fallback text."),
    ("dimension_prompt_fallback", "Name the evidence, assumption, or missing voice", "A dimension improvement prompt rendered fallback text."),
    ("agent_finding_fallback", "Finding not supplied", "An agent attribution rendered fallback text."),
    ("bias_rows_fallback", "No bias rows were supplied", "Bias-table fallback text reached the reader-facing report."),
    ("dissent_fallback", "No explicit disagreement", "Dissent placeholder text reached the reader-facing report."),
    ("dissent_template_instruction", "Name the evidence that would change this view", "Dissent template instruction reached the reader-facing report."),
    ("confidence_unknown", "Confidence: unknown", "Unknown confidence placeholder reached the reader-facing report."),
    ("kb_grounding_internal", "KB grounding:", "KB grounding internals reached the reader-facing report."),
    ("kb_grounding_internal_note", "Items without IDs", "KB grounding QA note reached the reader-facing report."),
    ("host_inference_internal", "host_inference", "Host-inference QA metadata reached the reader-facing report."),
    ("host_inference_internal_hyphen", "host-inference", "Host-inference QA metadata reached the reader-facing report."),
    ("source_internal_fileofun", "File-O-Fun", "Internal activity-source name reached the reader-facing report."),
    ("source_internal_atlas", "Knowledge Atlas", "Internal activity-source name reached the reader-facing report."),
    ("beta_internal_note", "beta.8", "Internal beta note reached the reader-facing report."),
    ("beta_internal_note_generic", "beta.", "Internal beta note reached the reader-facing report."),
    ("raw_enum_needs_evidence", "needs_evidence", "Raw enum value reached the reader-facing report."),
    ("raw_enum_not_ranked", "not_ranked_for_truth", "Raw enum value reached the reader-facing report."),
    ("raw_enum_support_contrast", "support_contrast", "Raw enum value reached the reader-facing report."),
    ("debug_supplied_string", "was supplied", "System/debug supplied-string reached the reader-facing report."),
    ("debug_not_supplied_string", "was not supplied", "System/debug supplied-string reached the reader-facing report."),
]


def _text_contains(haystack: str, needle: str) -> bool:
    def normalize_for_pdf_match(value: str) -> str:
        text = clean_text(value)
        text = re.sub(r"(?<=\w)-\s+(?=\w)", "-", text)
        return text.lower()

    normalized_haystack = normalize_for_pdf_match(haystack)
    normalized_needle = normalize_for_pdf_match(needle)
    if normalized_needle in normalized_haystack:
        return True
    return normalized_needle.replace("-", "") in normalized_haystack.replace("-", "")


def render_page_images(report_path: Path, image_dir: Path, dpi: int = 150) -> tuple[int, list[str], list[dict[str, Any]], str]:
    try:
        import fitz
    except ModuleNotFoundError:
        return 0, [], [issue("dependencies", "blocking", "Missing dependency: install pymupdf for report QA.")], ""

    image_dir.mkdir(parents=True, exist_ok=True)
    page_image_paths: list[str] = []
    preview_path = ""
    try:
        doc = fitz.open(str(report_path))
    except Exception as exc:  # pragma: no cover - defensive file-corruption path
        return 0, [], [issue("pdf_open", "blocking", f"Could not open generated PDF: {exc}")], ""
    zoom = dpi / 72
    matrix = fitz.Matrix(zoom, zoom)
    try:
        for index, page in enumerate(doc, start=1):
            pix = page.get_pixmap(matrix=matrix, alpha=False)
            image_path = image_dir / f"page-{index}.png"
            pix.save(str(image_path))
            page_image_paths.append(str(image_path.resolve()))
            if index == 1:
                preview = image_dir / "report-preview-page-1.png"
                pix.save(str(preview))
                preview_path = str(preview.resolve())
        page_count = doc.page_count
    finally:
        doc.close()
    return page_count, page_image_paths, [], preview_path


def extract_pdf_text(report_path: Path) -> tuple[str, list[dict[str, Any]]]:
    try:
        import fitz
    except ModuleNotFoundError:
        return "", [issue("dependencies", "blocking", "Missing dependency: install pymupdf for report QA.")]
    try:
        doc = fitz.open(str(report_path))
    except Exception as exc:  # pragma: no cover - defensive file-corruption path
        return "", [issue("pdf_open", "blocking", f"Could not open generated PDF for text extraction: {exc}")]
    try:
        return "\n".join(page.get_text("text") for page in doc), []
    finally:
        doc.close()


def bias_table_layout_issues(report_path: Path) -> list[dict[str, Any]]:
    try:
        import fitz
    except ModuleNotFoundError:
        return []
    issues: list[dict[str, Any]] = []
    try:
        doc = fitz.open(str(report_path))
    except Exception:
        return []
    try:
        for page_index, page in enumerate(doc, start=1):
            page_text = page.get_text("text")
            if "Top Biases Identified" not in page_text and "Quick-Scan Findings" not in page_text:
                continue
            right_bound = page.rect.width - 72
            left_bound = 72
            words = page.get_text("words")
            for word in words:
                x0, _y0, x1, _y1, text = word[:5]
                if x0 < left_bound - 4 or x1 > right_bound + 4:
                    issues.append(issue("table_text_bounds", "blocking", f"Quick-scan table text exceeds page content bounds: {text[:80]}", page=page_index, fix="Add wrap opportunities or reduce table cell content width."))
                    break
                if len(clean_text(text)) >= 28 and (x1 - x0) > 160:
                    issues.append(issue("table_long_token", "blocking", f"Long quick-scan table token appears unwrapped: {clean_text(text)[:80]}", page=page_index, fix="Apply soft_break_text to long table fields and KB IDs."))
                    break
    finally:
        doc.close()
    return issues


def qa_report(report_path: Path, payload: dict[str, Any], image_dir: Path) -> dict[str, Any]:
    issues: list[dict[str, Any]] = []
    if not report_path.exists():
        return {
            "qa_version": QA_VERSION,
            "qa_status": "blocked",
            "passed": False,
            "issues": [issue("file_exists", "blocking", "Generated PDF does not exist.")],
            "page_count": 0,
            "preview_image_path": "",
            "page_image_paths": [],
        }
    if report_path.stat().st_size == 0:
        issues.append(issue("file_size", "blocking", "Generated PDF is zero bytes."))

    text, text_issues = extract_pdf_text(report_path)
    issues.extend(text_issues)
    issues.extend(bias_table_layout_issues(report_path))
    page_count, page_image_paths, image_issues, preview_path = render_page_images(report_path, image_dir)
    issues.extend(image_issues)
    if page_count <= 0:
        issues.append(issue("page_count", "blocking", "Generated PDF has zero pages."))
    if not page_image_paths:
        issues.append(issue("page_images", "blocking", "Page image generation failed."))

    meta = payload.get("meta", {})
    cis = payload.get("cis", {})
    findings = payload.get("findings", {})
    depth = meta.get("report_depth")
    display_state = cis.get("display_state")

    required_texts = ["Critical Integrity Report", meta.get("report_title"), meta.get("date")]
    if depth != "checklist_only":
        required_texts.extend(["Critical Integrity Snapshot", "Before Using This Text", findings.get("recommended_next_step")])
    if depth == "readiness_card":
        readiness = payload.get("pressure_test_readiness_card") if isinstance(payload.get("pressure_test_readiness_card"), dict) else {}
        required_texts = ["Critical Integrity Report", meta.get("report_title"), meta.get("date"), "Critical Integrity Snapshot", "Before Using This Text", readiness.get("next_move")]
    for required in required_texts:
        if clean_text(required) and not _text_contains(text, required):
            issues.append(issue("required_text", "blocking", f"Required text is missing from PDF: {clean_text(required)[:80]}"))

    for check, fallback_text, message in FALLBACK_TEXT_CHECKS:
        if _text_contains(text, fallback_text):
            issues.append(issue(check, "blocking", message, fix="Fix normalization/template rendering so reader-facing reports suppress internal fallback or debug text."))

    points = cis.get("points")
    label = clean_text(cis.get("label"))
    trust_allowed = (
        isinstance(points, int)
        and points >= 70
        and label in {"Strong Integrity", "Exemplary Integrity"}
    )
    if _text_contains(text, "Primary action: Trust") and not trust_allowed:
        issues.append(
            issue(
                "primary_action_trust_contradiction",
                "blocking",
                "Reader-facing report says Primary action: Trust without a Strong/Exemplary CIS signal.",
                fix="Route low or moderate CIS reports to Revise, Verify, or Reframe before rendering polished output.",
            )
        )

    if depth != "checklist_only":
        if display_state == "scored":
            if cis.get("label") and not _text_contains(text, cis["label"]):
                issues.append(issue("cis_label", "blocking", "Scored report omits the CIS label."))
            if cis.get("points") is not None and not _text_contains(text, str(cis["points"])):
                issues.append(issue("cis_points", "blocking", "Scored report omits CIS points."))
        if display_state == "profile_only":
            if cis.get("label") and _text_contains(text, cis["label"]):
                issues.append(issue("profile_only_label", "blocking", "Profile-only report exposes aggregate label."))
            if cis.get("points") is not None and _text_contains(text, str(cis["points"])):
                issues.append(issue("profile_only_points", "blocking", "Profile-only report exposes aggregate points."))
            if not _text_contains(text, "Aggregate score withheld"):
                issues.append(issue("profile_only_note", "blocking", "Profile-only report omits the withheld-score note."))

        plain = cis.get("plain_language_read")
        if meta.get("report_mode") == "reader" and plain and not _text_contains(text, plain):
            issues.append(issue("plain_language_read", "blocking", "Plain-language read is missing or not verbatim."))

        dimensions = ensure_list(cis.get("dimensions"))
        for dimension in dimensions:
            name = dimension.get("name") if isinstance(dimension, dict) else ""
            if clean_text(name) and not _text_contains(text, name):
                issues.append(issue("dimension_name", "blocking", f"Dimension is missing from report: {clean_text(name)}"))
        if len(dimensions) == 5 and text.lower().count("/20") < 5:
            issues.append(issue("dimension_bars", "blocking", "Expected five visual dimension score labels."))
        if len(ensure_list(findings.get("biases"))) > 5:
            issues.append(issue("bias_rows", "blocking", "Bias table has more than five rows."))

    blocking = [item for item in issues if item.get("severity") == "blocking"]
    cosmetic = [item for item in issues if item.get("severity") != "blocking"]
    qa_status = "blocked" if blocking else "passed_with_cosmetic_issues" if cosmetic else "passed"
    return {
        "qa_version": QA_VERSION,
        "qa_status": qa_status,
        "passed": not blocking,
        "issues": issues,
        "blocking_issues": blocking,
        "cosmetic_issues": cosmetic,
        "page_count": page_count,
        "preview_image_path": preview_path,
        "page_image_paths": page_image_paths,
    }
