Local-only report assets live here.

Do not reference remote fonts, images, or icons from report templates. V1 uses
system fallback fonts so the MCP can render without network access.
