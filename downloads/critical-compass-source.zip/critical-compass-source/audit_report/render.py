from __future__ import annotations

import os
import re
import shutil
import shlex
import subprocess
import sys
import tempfile
import textwrap
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import Protocol

from markupsafe import Markup

from .models import ReportValidationError


PACKAGE_ROOT = Path(__file__).resolve().parent
TEMPLATES_DIR = PACKAGE_ROOT / "templates"
STYLES_DIR = PACKAGE_ROOT / "styles"


def _patch_homebrew_weasyprint_library_loading() -> None:
    """Let system Python find Homebrew's Pango stack on macOS."""
    try:
        import cffi.api
    except Exception:
        return
    if getattr(cffi.api.FFI, "_critical_compass_homebrew_patch", False):
        return

    original_dlopen = cffi.api.FFI.dlopen
    library_dirs = [Path("/opt/homebrew/lib"), Path("/usr/local/lib")]
    library_names = {
        "libgobject-2.0-0": "libgobject-2.0.dylib",
        "gobject-2.0-0": "libgobject-2.0.dylib",
        "gobject-2.0": "libgobject-2.0.dylib",
        "libgobject-2.0.so.0": "libgobject-2.0.dylib",
        "libgobject-2.0.dylib": "libgobject-2.0.dylib",
        "libpango-1.0-0": "libpango-1.0.dylib",
        "pango-1.0-0": "libpango-1.0.dylib",
        "pango-1.0": "libpango-1.0.dylib",
        "libpango-1.0.so.0": "libpango-1.0.dylib",
        "libpango-1.0.dylib": "libpango-1.0.dylib",
        "libharfbuzz-0": "libharfbuzz.0.dylib",
        "harfbuzz": "libharfbuzz.0.dylib",
        "libharfbuzz.so.0": "libharfbuzz.0.dylib",
        "libharfbuzz.0.dylib": "libharfbuzz.0.dylib",
        "libharfbuzz-subset-0": "libharfbuzz-subset.0.dylib",
        "harfbuzz-subset": "libharfbuzz-subset.0.dylib",
        "libharfbuzz-subset.so.0": "libharfbuzz-subset.0.dylib",
        "libharfbuzz-subset.0.dylib": "libharfbuzz-subset.0.dylib",
        "libfontconfig-1": "libfontconfig.1.dylib",
        "fontconfig-1": "libfontconfig.1.dylib",
        "fontconfig": "libfontconfig.1.dylib",
        "libfontconfig.so.1": "libfontconfig.1.dylib",
        "libfontconfig.1.dylib": "libfontconfig.1.dylib",
        "libpangoft2-1.0-0": "libpangoft2-1.0.dylib",
        "pangoft2-1.0-0": "libpangoft2-1.0.dylib",
        "pangoft2-1.0": "libpangoft2-1.0.dylib",
        "libpangoft2-1.0.so.0": "libpangoft2-1.0.dylib",
        "libpangoft2-1.0.dylib": "libpangoft2-1.0.dylib",
    }

    def patched_dlopen(self, name, flags=0):
        mapped_name = library_names.get(str(name))
        if mapped_name:
            for library_dir in library_dirs:
                candidate = library_dir / mapped_name
                if candidate.exists():
                    return original_dlopen(self, str(candidate), flags)
        return original_dlopen(self, name, flags)

    cffi.api.FFI.dlopen = patched_dlopen
    cffi.api.FFI._critical_compass_homebrew_patch = True


class ReportRenderer(Protocol):
    def render(self, html: str, output_path: Path, base_url: Path) -> None:
        ...


class WeasyPrintRenderer:
    def render(self, html: str, output_path: Path, base_url: Path) -> None:
        try:
            _patch_homebrew_weasyprint_library_loading()
            from weasyprint import HTML
        except Exception as exc:
            raise ReportValidationError(f"Missing or incomplete WeasyPrint runtime: {exc}") from exc

        output_path.parent.mkdir(parents=True, exist_ok=True)
        HTML(string=html, base_url=str(base_url)).write_pdf(str(output_path))


class WeasyPrintCliRenderer:
    def __init__(self, command: list[str], *, timeout_seconds: int | None = None) -> None:
        self.command = command
        self.timeout_seconds = timeout_seconds

    def render(self, html: str, output_path: Path, base_url: Path) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = Path(tempfile.mkstemp(prefix="critical-compass-report-", suffix=".html", dir=str(output_path.parent))[1])
        try:
            temp_path.write_text(html, encoding="utf-8")
            try:
                completed = subprocess.run(
                    [*self.command, str(temp_path), str(output_path)],
                    cwd=str(base_url),
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=self.timeout_seconds,
                )
            except subprocess.TimeoutExpired as exc:
                raise ReportValidationError(f"WeasyPrint CLI timed out after {self.timeout_seconds} seconds.") from exc
            if completed.returncode != 0:
                detail = (completed.stderr or completed.stdout or "unknown WeasyPrint CLI error").strip()
                raise ReportValidationError(f"WeasyPrint CLI failed: {detail}")
        finally:
            temp_path.unlink(missing_ok=True)


class _PlainTextExtractor(HTMLParser):
    BLOCK_TAGS = {
        "address",
        "article",
        "aside",
        "blockquote",
        "br",
        "div",
        "dl",
        "fieldset",
        "figcaption",
        "figure",
        "footer",
        "form",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "header",
        "hr",
        "li",
        "main",
        "nav",
        "ol",
        "p",
        "pre",
        "section",
        "table",
        "tbody",
        "td",
        "tfoot",
        "th",
        "thead",
        "tr",
        "ul",
    }

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs) -> None:  # noqa: ANN001
        if tag in {"style", "script"}:
            self._skip_depth += 1
            return
        if tag in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"style", "script"} and self._skip_depth:
            self._skip_depth -= 1
            return
        if tag in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip_depth:
            return
        text = re.sub(r"\s+", " ", data).strip()
        if text:
            self.parts.append(text)

    def text(self) -> str:
        raw = " ".join(self.parts)
        raw = re.sub(r"[ \t]*\n[ \t]*", "\n", raw)
        raw = re.sub(r"\n{3,}", "\n\n", raw)
        return raw.strip()


class PyMuPDFRenderer:
    def render(self, html: str, output_path: Path, base_url: Path) -> None:
        try:
            import fitz
        except ModuleNotFoundError as exc:
            raise ReportValidationError("Missing dependency: install pymupdf for fallback PDF rendering.") from exc

        extractor = _PlainTextExtractor()
        extractor.feed(html)
        text = extractor.text() or "Critical Compass report content was prepared, but the HTML text fallback found no readable text."
        wrapped_lines: list[str] = []
        for paragraph in text.splitlines():
            paragraph = paragraph.strip()
            if not paragraph:
                wrapped_lines.append("")
                continue
            wrapped_lines.extend(textwrap.wrap(paragraph, width=92, replace_whitespace=False) or [""])

        output_path.parent.mkdir(parents=True, exist_ok=True)
        doc = fitz.open()
        width, height = 612, 792
        margin = 54
        line_height = 12
        lines_per_page = max(1, int((height - 2 * margin) / line_height))
        for start in range(0, len(wrapped_lines) or 1, lines_per_page):
            page = doc.new_page(width=width, height=height)
            chunk = "\n".join(wrapped_lines[start : start + lines_per_page])
            page.insert_textbox(
                fitz.Rect(margin, margin, width - margin, height - margin),
                chunk,
                fontsize=9,
                fontname="helv",
                color=(0, 0, 0),
                lineheight=1.25,
            )
        doc.save(str(output_path))
        doc.close()


class PlaywrightRenderer:
    def render(self, html: str, output_path: Path, base_url: Path) -> None:
        raise NotImplementedError("PlaywrightRenderer is reserved for future RTL/browser-parity support.")


def _load_css() -> str:
    css_files = [path for path in sorted(STYLES_DIR.glob("*.css")) if not path.name.startswith("._")]
    return "\n".join(path.read_text(encoding="utf-8") for path in css_files)


def soft_break_text(value: object) -> Markup:
    """Escape text, then add safe break opportunities inside long technical tokens."""
    text = "" if value is None else str(value)
    escaped = escape(text, quote=True)
    for separator in (":", "/", ".", "_", "-"):
        escaped = escaped.replace(separator, f"{separator}<wbr>")
    return Markup(escaped)


def render_html(payload: dict, template_name: str) -> str:
    try:
        from jinja2 import Environment, FileSystemLoader, select_autoescape
    except ModuleNotFoundError as exc:
        raise ReportValidationError("Missing dependency: install jinja2 to render audit report templates.") from exc

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(enabled_extensions=("html", "xml"), default_for_string=True),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["default_text"] = lambda value, fallback="Not supplied": value if value not in (None, "", [], {}) else fallback
    env.filters["soft_break_text"] = soft_break_text
    template = env.get_template(template_name)
    return template.render(payload=payload, css=_load_css())


def template_for_depth(depth: str) -> str:
    if depth == "readiness_card":
        return "readiness_card.html"
    if depth == "overview":
        return "overview_report.html"
    if depth == "checklist_only":
        return "checklist_only.html"
    return "full_report.html"


def _command_display(command: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in command)


def _executable_path(value: str | None) -> str:
    if not value:
        return ""
    resolved = shutil.which(value)
    if resolved:
        return resolved
    path = Path(value).expanduser()
    if path.exists() and os.access(path, os.X_OK):
        return str(path.resolve())
    return ""


def _weasyprint_module_available() -> tuple[bool, str]:
    try:
        _patch_homebrew_weasyprint_library_loading()
        import weasyprint

        version = getattr(weasyprint, "__version__", "unknown")
        return True, f"Python module import succeeded; version={version}."
    except Exception as exc:
        return False, str(exc)


def resolve_weasyprint_command(explicit_binary: str | None = None) -> dict[str, object]:
    for source, candidate in (
        ("explicit_option", explicit_binary),
        ("environment", os.getenv("CRITICAL_COMPASS_WEASYPRINT_BINARY")),
        ("path", shutil.which("weasyprint")),
    ):
        resolved = _executable_path(candidate)
        if resolved:
            return {
                "available": True,
                "source": source,
                "command": [resolved],
                "command_display": resolved,
                "message": "WeasyPrint CLI resolved.",
            }

    module_ok, module_message = _weasyprint_module_available()
    if module_ok:
        command = [sys.executable, "-m", "weasyprint"]
        return {
            "available": True,
            "source": "python_module",
            "command": command,
            "command_display": _command_display(command),
            "message": module_message,
        }
    return {
        "available": False,
        "source": "unavailable",
        "command": [],
        "command_display": "",
        "message": module_message,
    }


def _pymupdf_available() -> tuple[bool, str]:
    try:
        import fitz

        version = getattr(fitz, "__doc__", "").splitlines()[0] if getattr(fitz, "__doc__", "") else "available"
        return True, version
    except Exception as exc:
        return False, str(exc)


def _record_renderer_status(payload: dict, renderer_name: str, status: str, message: str = "") -> None:
    diagnostics = payload.setdefault("diagnostics", {})
    diagnostics["report_renderer"] = {
        "renderer": renderer_name,
        "status": status,
        "message": message,
    }
    if status != "primary":
        diagnostics.setdefault("renderer_warnings", []).append(diagnostics["report_renderer"])


def pdf_render_timeout_seconds() -> int:
    raw = os.getenv("CRITICAL_COMPASS_PDF_RENDER_TIMEOUT_SECONDS", "120")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = 120
    return max(1, value)


def render_pdf(payload: dict, output_path: Path, renderer: ReportRenderer | None = None) -> Path:
    template_name = template_for_depth(payload["meta"]["report_depth"])
    html = render_html(payload, template_name)
    if renderer is not None:
        renderer.render(html, output_path, PACKAGE_ROOT)
        _record_renderer_status(payload, type(renderer).__name__, "custom", "Custom renderer supplied by caller.")
        return output_path

    resolution = resolve_weasyprint_command()
    primary_error = ""
    if resolution["available"]:
        try:
            if resolution["source"] == "python_module":
                WeasyPrintRenderer().render(html, output_path, PACKAGE_ROOT)
            else:
                WeasyPrintCliRenderer(
                    list(resolution["command"]),
                    timeout_seconds=pdf_render_timeout_seconds(),
                ).render(html, output_path, PACKAGE_ROOT)
            _record_renderer_status(
                payload,
                "weasyprint",
                "primary",
                f"Resolved through {resolution['source']}: {resolution['command_display']}",
            )
            return output_path
        except ReportValidationError as exc:
            primary_error = str(exc)
        except Exception as exc:  # pragma: no cover - defensive renderer boundary
            primary_error = f"{type(exc).__name__}: {exc}"
    else:
        primary_error = f"WeasyPrint unavailable: {resolution['message']}"

    if "timed out" in primary_error.lower():
        raise ReportValidationError(primary_error)

    pymupdf_ok, pymupdf_message = _pymupdf_available()
    if pymupdf_ok:
        PyMuPDFRenderer().render(html, output_path, PACKAGE_ROOT)
        _record_renderer_status(
            payload,
            "pymupdf_fallback",
            "fallback",
            f"WeasyPrint did not render ({primary_error}); used PyMuPDF fallback. {pymupdf_message}",
        )
        return output_path

    raise ReportValidationError(
        "No PDF renderer is available. "
        f"WeasyPrint failed or was unavailable ({primary_error}); PyMuPDF fallback is unavailable ({pymupdf_message})."
    )
    return output_path


def renderer_dependency_status() -> dict[str, str]:
    modules = {"jinja2": "jinja2", "weasyprint": "weasyprint", "fitz": "pymupdf"}
    status: dict[str, str] = {}
    for module, package in modules.items():
        try:
            if module == "weasyprint":
                _patch_homebrew_weasyprint_library_loading()
            __import__(module)
            status[package] = "available"
        except Exception as exc:
            status[package] = f"missing_or_incomplete: {exc}"
    resolution = resolve_weasyprint_command()
    status["weasyprint_binary"] = str(resolution["command_display"])
    status["weasyprint_resolution_source"] = str(resolution["source"])
    status["weasyprint_resolution_message"] = str(resolution["message"])
    status["weasyprint_available"] = "yes" if resolution["available"] else "no"
    pymupdf_ok, pymupdf_message = _pymupdf_available()
    status["pymupdf_fallback"] = "available" if pymupdf_ok else f"missing_or_incomplete: {pymupdf_message}"
    return status
