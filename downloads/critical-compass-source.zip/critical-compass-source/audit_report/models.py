from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


PAYLOAD_SCHEMA_VERSION = "v1"
TEMPLATE_VERSION = "v1.0.0"
RENDER_VERSION = "v1.0.0"
QA_VERSION = "v1.0.0"
REPORT_SCHEMA_HASH = hashlib.sha256(
    f"{PAYLOAD_SCHEMA_VERSION}:{TEMPLATE_VERSION}:{RENDER_VERSION}:report-contract-2026-04-28-schema-trust".encode("utf-8")
).hexdigest()[:16]

AUDIENCES = {"organizer", "academic", "executive", "general"}
DEPTHS = {"full", "overview", "checklist_only", "readiness_card"}
MODES = {"reader", "self"}

APPENDIX_INLINE_WORD_CAP = 3500

MAX_LENGTHS = {
    "report_title": 90,
    "plain_language_read": 360,
    "before_using_this_text": 280,
    "bias_why_it_matters": 160,
    "dimension_rationale": 650,
    "improvement_prompt": 180,
    "assumption": 220,
    "evidence_needed": 220,
    "alternative_frame": 360,
    "alternative_frame_lens": 360,
    "key_tension": 220,
    "verdict_paragraph": 900,
    "agent_top_finding": 160,
    "next_step": 160,
    "question": 220,
    "human_commentary": 1400,
    "ai_commentary_response": 700,
    "divergence_field": 320,
    "learning_note": 360,
    "activity_title": 90,
    "activity_why": 240,
    "activity_step": 180,
    "activity_content_focus": 240,
    "activity_thinking_focus": 180,
    "activity_source_note": 220,
    "activity_safety_note": 260,
}

LABEL_COLORS = {
    "Exemplary Integrity": "#2D7D46",
    "Strong Integrity": "#5B8DB8",
    "Moderate Integrity": "#E8A838",
    "Limited Integrity": "#E07B39",
    "Needs Scrutiny": "#C0392B",
}

CIS_BANDS = [
    {"label": "Exemplary Integrity", "min_points": 85, "max_points": 100},
    {"label": "Strong Integrity", "min_points": 70, "max_points": 84},
    {"label": "Moderate Integrity", "min_points": 50, "max_points": 69},
    {"label": "Limited Integrity", "min_points": 25, "max_points": 49},
    {"label": "Needs Scrutiny", "min_points": 0, "max_points": 24},
]


def infer_cis_label(points: int | None) -> str:
    if points is None:
        return ""
    bounded = max(0, min(int(points), 100))
    for band in CIS_BANDS:
        if int(band["min_points"]) <= bounded <= int(band["max_points"]):
            return str(band["label"])
    return ""


class ReportValidationError(ValueError):
    """Raised when report input cannot produce a valid stakeholder report."""


@dataclass(frozen=True)
class ReportOptions:
    report_audience: str = "organizer"
    report_depth: str = "full"
    report_mode: str = "reader"
    include_raw_text: bool = False
    report_title: str | None = None
    output_path: Path | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def report_date() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def report_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")


def make_report_id() -> str:
    return str(uuid4())


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def payload_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(json_dumps(payload).encode("utf-8")).hexdigest()


def first_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for item in value.values():
            text = first_text(item)
            if text:
                return text
        return ""
    if isinstance(value, (list, tuple, set)):
        for item in value:
            text = first_text(item)
            if text:
                return text
        return ""
    return str(value).strip()


def ensure_list(value: Any) -> list[Any]:
    if value in (None, "", [], {}):
        return []
    if isinstance(value, list):
        return [item for item in value if item not in (None, "", [], {})]
    if isinstance(value, tuple):
        return [item for item in value if item not in (None, "", [], {})]
    return [value]


def clean_text(value: Any) -> str:
    text = first_text(value)
    text = text.replace("\u2010", "-").replace("\u2011", "-").replace("\u2012", "-")
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2022", "-")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def cap_chars(value: Any, max_chars: int) -> str:
    text = clean_text(value)
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."


_DANGLING_END_WORDS = {
    "and",
    "or",
    "but",
    "because",
    "why",
    "that",
    "to",
    "with",
    "from",
    "of",
    "for",
    "by",
    "as",
    "in",
    "on",
    "at",
    "into",
    "about",
}


def _remove_ellipsis_tail(text: str) -> str:
    return re.split(r"\.\.\.|…", text, maxsplit=1)[0].strip()


def _strip_dangling_tail(text: str) -> str:
    stripped = _remove_ellipsis_tail(clean_text(text)).rstrip(" \t\r\n-,:;")
    while stripped:
        parts = stripped.rsplit(" ", 1)
        last_word = re.sub(r"[^A-Za-z]", "", parts[-1]).lower()
        if last_word not in _DANGLING_END_WORDS:
            break
        stripped = (parts[0] if len(parts) == 2 else "").rstrip(" \t\r\n-,:;")
    return stripped


def _finish_complete_text(text: str, max_chars: int | None = None) -> str:
    finished = _strip_dangling_tail(text)
    if not finished:
        return ""
    if finished[-1] not in ".!?)]}'\"":
        finished = f"{finished}."
    if max_chars is None or len(finished) <= max_chars:
        return finished

    terminal = finished[-1] if finished[-1] in ".!?" else "."
    base = finished[:-1].rstrip(" \t\r\n-,:;")
    while base and len(f"{base}{terminal}") > max_chars:
        next_base = base.rsplit(" ", 1)[0].rstrip(" \t\r\n-,:;")
        if next_base == base:
            break
        base = _strip_dangling_tail(next_base)
    if not base:
        return ""
    return f"{base}{terminal}"


def _complete_sentence_prefix(text: str, max_chars: int) -> str:
    sentences = [part for part in re.split(r"(?<=[.!?])\s+", text) if part]
    selected: list[str] = []
    for sentence in sentences:
        sentence = clean_text(sentence)
        if not re.search(r"[.!?]$", sentence):
            continue
        candidate = " ".join([*selected, sentence])
        if len(candidate) > max_chars:
            break
        selected.append(sentence)
    return " ".join(selected)


def cap_complete_prose(value: Any, max_chars: int) -> str:
    text = clean_text(value)
    if not text or max_chars <= 0:
        return ""
    if len(text) <= max_chars and "..." not in text and "…" not in text and _strip_dangling_tail(text) == text.rstrip(" \t\r\n-,:;"):
        return text

    text = _remove_ellipsis_tail(text)
    if not text:
        return ""

    sentence_prefix = _complete_sentence_prefix(text, max_chars)
    if sentence_prefix:
        return sentence_prefix

    cut = text[:max_chars].rstrip()
    minimum_boundary = min(40, max(12, max_chars // 3))
    boundary_end = 0
    for match in re.finditer(r"[.!?;:,]|\s-\s", cut):
        if match.end() >= minimum_boundary:
            boundary_end = match.end()
    if boundary_end:
        cut = cut[:boundary_end]
    else:
        cut = cut.rsplit(" ", 1)[0] if " " in cut else cut
    return _finish_complete_text(cut, max_chars)


def cap_sentences(value: Any, max_sentences: int, max_chars: int) -> str:
    text = clean_text(value)
    if not text:
        return ""
    parts = re.split(r"(?<=[.!?])\s+", text)
    sentences: list[str] = []
    for part in parts:
        cleaned = clean_text(part)
        if cleaned:
            sentences.append(cleaned)
        if len(sentences) >= max_sentences:
            break
    capped = " ".join(sentences) if sentences else text
    return cap_complete_prose(capped, max_chars)


def cap_words(value: Any, max_words: int) -> str:
    words = [part for part in clean_text(value).split() if part]
    if len(words) <= max_words:
        return " ".join(words)
    return " ".join(words[:max_words]).rstrip() + "..."


def cap_complete_words(value: Any, max_words: int) -> str:
    words = [part for part in clean_text(value).split() if part]
    if not words or max_words <= 0:
        return ""
    if len(words) <= max_words:
        return " ".join(words)
    return _finish_complete_text(" ".join(words[:max_words]))


def word_count(value: Any) -> int:
    return len([part for part in clean_text(value).split() if part])


def normalize_audience(value: str | None, snapshot_mode: str | None = None) -> str:
    audience = clean_text(value).lower().replace(" ", "_")
    aliases = {
        "research": "academic",
        "reader": "general",
        "author": "general",
        "both": "general",
        "organiser": "organizer",
    }
    audience = aliases.get(audience, audience)
    if audience in AUDIENCES:
        return audience
    if clean_text(snapshot_mode).lower() == "research":
        return "academic"
    return "organizer"


def normalize_depth(value: str | None) -> str:
    depth = clean_text(value).lower().replace(" ", "_")
    aliases = {
        "": "full",
        "standard": "full",
        "deep": "full",
        "quick": "overview",
        "scan": "overview",
        "quick_scan": "overview",
        "readiness": "readiness_card",
        "readiness card": "readiness_card",
        "pressure_test_readiness": "readiness_card",
        "pressure-test-readiness": "readiness_card",
        "checklist": "checklist_only",
        "questions": "checklist_only",
    }
    depth = aliases.get(depth, depth)
    return depth if depth in DEPTHS else "full"


def normalize_mode(value: str | None) -> str:
    mode = clean_text(value).lower().replace(" ", "_")
    aliases = {"": "reader", "stakeholder": "reader", "writer": "self", "coach": "self", "coaching": "self"}
    mode = aliases.get(mode, mode)
    return mode if mode in MODES else "reader"


def normalize_display_state(value: str | None) -> str:
    state = clean_text(value).lower().replace(" ", "_")
    if state in {"full", "scored", "score"}:
        return "scored"
    if state in {"profile_only", "withheld"}:
        return "profile_only"
    return "scored"


def dimension_color(points: int, max_points: int = 20) -> str:
    scaled = points
    if max_points and max_points != 20:
        scaled = int(round((points / max_points) * 20))
    if scaled >= 16:
        return "#2D7D46"
    if scaled >= 11:
        return "#E8A838"
    return "#C0392B"


def validate_payload(payload: dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        raise ReportValidationError("payload must be an object")
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}

    if meta.get("schema_version") != PAYLOAD_SCHEMA_VERSION:
        raise ReportValidationError("payload schema_version must be v1")
    if meta.get("report_audience") not in AUDIENCES:
        raise ReportValidationError("report_audience is invalid")
    if meta.get("report_depth") not in DEPTHS:
        raise ReportValidationError("report_depth is invalid")
    if meta.get("report_mode") not in MODES:
        raise ReportValidationError("report_mode is invalid")

    display_state = cis.get("display_state")
    if display_state not in {"scored", "profile_only"}:
        raise ReportValidationError("cis.display_state must be scored or profile_only")
    if display_state == "scored" and not cis.get("label"):
        raise ReportValidationError("scored reports require cis.label")
    if display_state == "scored" and cis.get("points") is None:
        raise ReportValidationError("scored reports require cis.points")
    if not ensure_list(cis.get("dimensions")):
        raise ReportValidationError("cis.dimensions must include at least one dimension")
    if len(ensure_list(cis.get("dimensions"))) > 5:
        raise ReportValidationError("cis.dimensions may not exceed five dimensions")
    if len(ensure_list(findings.get("biases"))) > 5:
        raise ReportValidationError("findings.biases may not exceed five rows")
    if meta.get("report_depth") == "checklist_only":
        questions = payload.get("questions") if isinstance(payload.get("questions"), dict) else {}
        if not ensure_list(questions.get("probing")) and not ensure_list(questions.get("follow_up")):
            raise ReportValidationError("checklist_only reports require questions")


def issue(check: str, severity: str, message: str, page: int | None = None, fix: str | None = None) -> dict[str, Any]:
    return {
        "check": check,
        "severity": severity,
        "page": page,
        "issue": message,
        "fix": fix,
    }
