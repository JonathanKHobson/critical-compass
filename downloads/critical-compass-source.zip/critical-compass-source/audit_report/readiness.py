from __future__ import annotations

import re
from typing import Any

from .models import clean_text, ensure_list, first_text, word_count
from .normalize import REPORT_FIELD_ALIASES


SENTINEL_TEXTS = {
    "finding not supplied",
    "not supplied",
    "no data",
    "tbd",
    "n/a",
    "none",
    "no plain-language read was supplied.",
    "no key tension was supplied in the audit output.",
    "no assumption table was supplied in the audit output.",
    "no alternative frames were supplied in the audit output.",
    "no rationale was provided in the audit output.",
    "dimension data was missing from the audit output.",
    "name the evidence, assumption, or missing voice a reader should test next.",
    "use the probing questions before treating the claim as settled.",
    "this pattern may shape what the reader notices or ignores.",
}


ACTION_VERBS = {
    "ask",
    "add",
    "check",
    "choose",
    "compare",
    "confirm",
    "collect",
    "define",
    "decide",
    "document",
    "estimate",
    "identify",
    "interview",
    "invite",
    "look",
    "map",
    "mark",
    "name",
    "pair",
    "pick",
    "preserve",
    "publish",
    "quote",
    "reflect",
    "review",
    "revise",
    "run",
    "separate",
    "share",
    "specify",
    "state",
    "surface",
    "test",
    "turn",
    "use",
    "verify",
    "write",
}

SECTION_LABELS = {
    "cis": "Critical Integrity Snapshot",
    "quick_scan": "Quick-Scan Findings",
    "dimensions": "Dimension Deep-Dive",
    "assumptions": "Assumption Audit",
    "frames": "Alternative Frames",
    "questions": "Questions",
    "next_steps": "Next Steps",
    "follow_up_activity": "Follow-Up Activity",
    "agent_findings": "Advanced Audit Agent Findings",
    "argument_map": "Argument Map",
    "checkworthy_claims": "Evidence Needed Next",
    "dissent_ledger": "Where the Analysts Disagreed",
    "reasoning_traps": "Reasoning Trap Checks",
}


def _aliases(field: str) -> list[str]:
    for parent in (
        "follow_up_activity.try_this_next",
        "follow_up_activity.solo_activity",
        "follow_up_activity.group_activity",
        "advanced_audit.agents[].top_finding",
        "advanced_audit.agents[].strongest_disagreement",
        "advanced_audit.dissent_ledger",
    ):
        if field.startswith(f"{parent}."):
            return REPORT_FIELD_ALIASES.get(parent, [parent])
    return REPORT_FIELD_ALIASES.get(field, [field])


def _is_numeric_only(text: str) -> bool:
    return bool(re.fullmatch(r"[\d.\-#)\s]+", clean_text(text)))


def is_meaningful_text(value: Any, *, min_words: int = 3, require_action: bool = False) -> bool:
    text = clean_text(value)
    if not text or _is_numeric_only(text):
        return False
    lowered = text.lower().strip()
    if lowered in SENTINEL_TEXTS:
        return False
    if lowered.startswith("no ") and "supplied" in lowered:
        return False
    if word_count(text) < min_words:
        return False
    if require_action:
        first_word = lowered.split()[0] if lowered.split() else ""
        return first_word in ACTION_VERBS or word_count(text) >= 8
    return True


def _missing(section: str, field: str, reason: str, instruction: str) -> dict[str, Any]:
    return {
        "section": section,
        "field": field,
        "accepted_aliases": _aliases(field),
        "reason": reason,
        "fallback_rendered": False,
        "what_to_resubmit": instruction,
    }


def _append_missing(items: list[dict[str, Any]], section: str, field: str, reason: str, instruction: str) -> None:
    items.append(_missing(section, field, reason, instruction))


def _dimension_is_complete(dimension: dict[str, Any], index: int, missing: list[dict[str, Any]]) -> bool:
    ok = True
    prefix = f"Dimension {index + 1}"
    if not is_meaningful_text(dimension.get("name"), min_words=1):
        ok = False
        _append_missing(missing, prefix, "cis.dimensions[].name", "Dimension name is missing.", "Re-submit each CIS dimension with a name.")
    if dimension.get("points") is None or dimension.get("max_points") is None:
        ok = False
        _append_missing(missing, prefix, "cis.dimensions[].points", "Dimension score is missing.", "Re-submit each CIS dimension with points/score and max_points/max.")
    if not is_meaningful_text(dimension.get("rationale"), min_words=6):
        ok = False
        _append_missing(missing, prefix, "cis.dimensions[].rationale", "Dimension rationale is missing or placeholder-only.", "Re-submit each CIS dimension with a concise rationale.")
    if not is_meaningful_text(dimension.get("improvement_prompt"), min_words=6, require_action=True):
        ok = False
        _append_missing(missing, prefix, "cis.dimensions[].improvement_prompt", "Dimension improvement prompt is missing or placeholder-only.", "Re-submit each dimension with an actionable improvement prompt.")
    return ok


def _bias_is_complete(bias: dict[str, Any], index: int, missing: list[dict[str, Any]]) -> bool:
    ok = True
    prefix = f"Bias Row {index + 1}"
    if not is_meaningful_text(bias.get("name"), min_words=1):
        ok = False
        _append_missing(missing, prefix, "findings.biases[].name", "Bias name is missing.", "Re-submit each bias row with a bias name.")
    if not is_meaningful_text(bias.get("passage"), min_words=2):
        ok = False
        _append_missing(missing, prefix, "findings.biases[].passage", "Bias passage/where field is missing.", "Re-submit each bias row with the passage or source location.")
    if not is_meaningful_text(bias.get("why_it_matters"), min_words=6):
        ok = False
        _append_missing(missing, prefix, "findings.biases[].why_it_matters", "Bias why-it-matters field is missing or generic.", "Re-submit each bias row with a plain-language why-it-matters explanation.")
    if not is_meaningful_text(bias.get("three_cs_lens"), min_words=1):
        ok = False
        _append_missing(missing, prefix, "findings.biases[].three_cs_lens", "Bias lens is missing.", "Re-submit each bias row with a Three Cs lens.")
    return ok


def _meaningful_questions(payload: dict[str, Any]) -> list[str]:
    questions = payload.get("questions") if isinstance(payload.get("questions"), dict) else {}
    values = [*ensure_list(questions.get("probing")), *ensure_list(questions.get("follow_up"))]
    return [clean_text(item) for item in values if is_meaningful_text(item, min_words=4)]


def _meaningful_next_steps(payload: dict[str, Any]) -> list[str]:
    return [clean_text(item) for item in ensure_list(payload.get("next_steps")) if is_meaningful_text(item, min_words=4, require_action=True)]


def _before_using_has_required_prefix(value: Any) -> bool:
    return clean_text(value).startswith("Before using this text,")


def _activity_card_is_complete(
    card: dict[str, Any],
    *,
    section: str,
    path: str,
    missing: list[dict[str, Any]],
    require_steps: bool = True,
    require_full_fields: bool = False,
) -> bool:
    if not isinstance(card, dict):
        _append_missing(missing, section, path, f"{section} payload is missing.", f"Re-submit {path} as an object with title, why_this_fits, steps, content_focus, thinking_focus, and source_note.")
        return False

    ok = True
    checks = [
        ("title", card.get("title"), 1, False, "title"),
        ("why_this_fits", card.get("why_this_fits"), 6, False, "why_this_fits"),
        ("content_focus", card.get("content_focus"), 5, False, "content_focus"),
    ]
    if require_full_fields:
        checks.extend(
            [
                ("thinking_focus", first_text(card.get("thinking_focus")), 1, False, "thinking_focus"),
                ("source_note", card.get("source_note"), 4, False, "source_note"),
            ]
        )
    for field, value, min_words, require_action, label in checks:
        if not is_meaningful_text(value, min_words=min_words, require_action=require_action):
            ok = False
            _append_missing(
                missing,
                section,
                f"{path}.{field}",
                f"{label} is missing or too thin.",
                f"Re-submit {path}.{field} with a meaningful {label.replace('_', ' ')}.",
            )

    steps = [item for item in ensure_list(card.get("steps")) if is_meaningful_text(item, min_words=3, require_action=True)]
    if require_steps and not steps:
        ok = False
        _append_missing(
            missing,
            section,
            f"{path}.steps",
            "steps are missing or not action-oriented.",
            f"Re-submit {path}.steps[] with at least one action-oriented step.",
        )
    return ok


def _follow_up_activity_is_complete(payload: dict[str, Any], depth: str, missing: list[dict[str, Any]]) -> bool:
    activity = payload.get("follow_up_activity") if isinstance(payload.get("follow_up_activity"), dict) else {}
    if not activity:
        _append_missing(missing, "Follow-Up Activity", "follow_up_activity", "Follow-up activity payload is missing.", "Re-submit follow_up_activity with try_this_next; full reports also need solo_activity and group_activity.")
        return False
    try_ok = _activity_card_is_complete(
        activity.get("try_this_next") if isinstance(activity.get("try_this_next"), dict) else {},
        section="Follow-Up Activity",
        path="follow_up_activity.try_this_next",
        missing=missing,
        require_steps=False,
    )
    if depth != "full":
        return try_ok
    solo_ok = _activity_card_is_complete(
        activity.get("solo_activity") if isinstance(activity.get("solo_activity"), dict) else {},
        section="Solo Follow-Up Activity",
        path="follow_up_activity.solo_activity",
        missing=missing,
        require_full_fields=True,
    )
    group_ok = _activity_card_is_complete(
        activity.get("group_activity") if isinstance(activity.get("group_activity"), dict) else {},
        section="Group Follow-Up Activity",
        path="follow_up_activity.group_activity",
        missing=missing,
        require_full_fields=True,
    )
    return try_ok and solo_ok and group_ok


def _argument_map_is_complete(payload: dict[str, Any], missing: list[dict[str, Any]]) -> bool:
    argument_map = payload.get("argument_map") if isinstance(payload.get("argument_map"), dict) else {}
    if not argument_map:
        return True
    ok = True
    if not is_meaningful_text(argument_map.get("central_claim"), min_words=5):
        ok = False
        _append_missing(missing, "Argument Map", "argument_map.central_claim", "Argument map central claim is missing or placeholder-only.", "Re-submit argument_map.central_claim as the text's main claim.")
    if not is_meaningful_text(argument_map.get("plain_language_summary"), min_words=6):
        ok = False
        _append_missing(missing, "Argument Map", "argument_map.plain_language_summary", "Argument map summary is missing or placeholder-only.", "Re-submit argument_map.plain_language_summary in plain language.")
    if not ensure_list(argument_map.get("evidence_gaps")):
        ok = False
        _append_missing(missing, "Argument Map", "argument_map.evidence_gaps", "Argument map needs at least one evidence gap.", "Re-submit argument_map.evidence_gaps with the evidence still needed.")
    if not is_meaningful_text(argument_map.get("markdown"), min_words=6) or not is_meaningful_text(argument_map.get("argdown"), min_words=3):
        ok = False
        _append_missing(missing, "Argument Map", "argument_map.exports", "Argument map Markdown or .argdown export is missing.", "Re-submit argument_map with markdown and argdown export strings.")
    return ok


def _checkworthy_claims_are_complete(payload: dict[str, Any], missing: list[dict[str, Any]]) -> bool:
    source = payload.get("checkworthy_claims")
    claims = []
    if isinstance(source, dict):
        claims = [item for item in ensure_list(source.get("claims")) if isinstance(item, dict)]
        if not claims:
            for group in ("factual", "interpretive", "causal", "normative", "policy"):
                claims.extend(item for item in ensure_list(source.get(group)) if isinstance(item, dict))
    elif isinstance(source, list):
        claims = [item for item in source if isinstance(item, dict)]
    if source in (None, "", [], {}):
        return True
    ok = bool(claims)
    if not claims:
        _append_missing(missing, "Evidence Needed Next", "checkworthy_claims", "Check-worthy claim section is present but empty.", "Re-submit checkworthy_claims.claims[] or remove the empty section.")
        return False
    for index, claim in enumerate(claims[:8]):
        claim_type = clean_text(claim.get("claim_type") or claim.get("type") or "")
        is_factual = bool(claim.get("is_factual")) or claim_type == "factual"
        if not is_meaningful_text(claim.get("claim") or claim.get("text"), min_words=5):
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].claim", "Claim text is missing or placeholder-only.", "Re-submit each check-worthy claim with a concrete claim.")
        if is_factual and clean_text(claim.get("verification_priority")) not in {"high", "medium", "low"}:
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].verification_priority", "Factual claim is missing high/medium/low verification priority.", "Rank factual claims only; non-factual claims should use not_ranked.")
        if not is_factual and clean_text(claim.get("verification_priority") or "not_ranked") != "not_ranked":
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].verification_priority", "Non-factual claims should not be ranked as verification priorities.", "Set verification_priority=not_ranked for interpretive, causal, normative, or policy claims.")
        if not is_meaningful_text(claim.get("evidence_needed"), min_words=4):
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].evidence_needed", "Evidence-needed field is missing or placeholder-only.", "Re-submit evidence_needed for each check-worthy claim.")
        suggested_queries = [item for item in ensure_list(claim.get("suggested_queries")) if is_meaningful_text(item, min_words=2)]
        if not suggested_queries:
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].suggested_queries", "Suggested verification queries are missing.", "Re-submit suggested_queries[] for each check-worthy claim, without performing automatic web lookup.")
        likely_source_types = [item for item in ensure_list(claim.get("likely_source_types")) if is_meaningful_text(item, min_words=1)]
        if not likely_source_types:
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].likely_source_types", "Likely source types are missing.", "Re-submit likely_source_types[] for each check-worthy claim.")
        if not is_meaningful_text(claim.get("support_contrast_status"), min_words=1):
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].support_contrast_status", "Support/contrast status is missing.", "Re-submit support_contrast_status for each check-worthy claim.")
        if not is_meaningful_text(claim.get("uncertainty_note"), min_words=6):
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].uncertainty_note", "Uncertainty note is missing or too thin.", "Re-submit uncertainty_note that explains what is still unknown without implying the claim is false.")
        notice = clean_text(claim.get("not_false_notice")).lower()
        if "not false" not in notice and "not that the claim is false" not in notice:
            ok = False
            _append_missing(missing, f"Check-Worthy Claim {index + 1}", "checkworthy_claims[].not_false_notice", "The check-worthy-is-not-false notice is missing.", "Include the not_false_notice on each claim.")
    return ok


def _dissent_ledger_is_complete(payload: dict[str, Any], missing: list[dict[str, Any]]) -> bool:
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    ledger = [item for item in ensure_list(advanced.get("dissent_ledger")) if isinstance(item, dict)]
    agents = [item for item in ensure_list(advanced.get("agents")) if isinstance(item, dict)]
    if not ledger:
        return True
    ok = True
    for index, entry in enumerate(ledger[:6]):
        consensus_note = entry.get("consensus_note") or entry.get("dissent_note")
        if is_meaningful_text(consensus_note, min_words=5):
            if not is_meaningful_text(entry.get("top_finding") or entry.get("agent_name"), min_words=2):
                ok = False
                _append_missing(missing, f"Analytical Consensus {index + 1}", "advanced_audit.dissent_ledger[].top_finding", "Consensus entry needs a short finding or analyst label.", "Re-submit consensus entries with top_finding or agent_name plus consensus_note.")
            continue
        for field, instruction in (
            ("top_finding", "Re-submit each dissent ledger entry with top_finding."),
            ("strongest_disagreement", "Re-submit each dissent ledger entry with strongest_disagreement."),
            ("what_would_change_mind", "Re-submit what evidence would change the agent's mind."),
        ):
            if not is_meaningful_text(entry.get(field), min_words=5):
                ok = False
                _append_missing(missing, f"Analytical Disagreement {index + 1}", f"advanced_audit.dissent_ledger[].{field}", f"{field} is missing or placeholder-only.", instruction)
    return ok


def _reasoning_traps_are_complete(payload: dict[str, Any], missing: list[dict[str, Any]]) -> bool:
    traps = [item for item in ensure_list(payload.get("reasoning_traps")) if isinstance(item, dict)]
    if not traps:
        return True
    ok = True
    for index, trap in enumerate(traps[:5]):
        if not is_meaningful_text(trap.get("label") or trap.get("name"), min_words=2):
            ok = False
            _append_missing(missing, f"Reasoning Trap {index + 1}", "reasoning_traps[].label", "Trap label is missing.", "Re-submit reasoning_traps[] with a short label.")
        if not is_meaningful_text(trap.get("next_check") or trap.get("check"), min_words=5, require_action=True):
            ok = False
            _append_missing(missing, f"Reasoning Trap {index + 1}", "reasoning_traps[].next_check", "Trap next check is missing or not actionable.", "Re-submit reasoning_traps[] with an action-oriented next_check.")
        if not is_meaningful_text(trap.get("text_anchor"), min_words=1):
            ok = False
            _append_missing(missing, f"Reasoning Trap {index + 1}", "reasoning_traps[].text_anchor", "Trap lacks a specific text anchor.", "Re-submit reasoning_traps[] with text_anchor or remove the generic trap.")
        if not is_meaningful_text(trap.get("text_specific_check"), min_words=6, require_action=True):
            ok = False
            _append_missing(missing, f"Reasoning Trap {index + 1}", "reasoning_traps[].text_specific_check", "Trap text-specific check is missing or generic.", "Re-submit reasoning_traps[] with a check tied to the audited text.")
    return ok


def build_report_preflight_card(
    compiled_sections: dict[str, bool] | None,
    missing_report_fields: list[dict[str, Any]] | None,
    *,
    preflight_status: str = "blocked_missing_fields",
) -> dict[str, Any]:
    compiled_sections = compiled_sections or {}
    missing_report_fields = missing_report_fields or []
    complete_sections = [
        SECTION_LABELS.get(section, section.replace("_", " ").title())
        for section, complete in compiled_sections.items()
        if complete
    ]
    incomplete_sections = [
        SECTION_LABELS.get(section, section.replace("_", " ").title())
        for section, complete in compiled_sections.items()
        if not complete
    ]
    missing_items = [
        {
            "section": clean_text(item.get("section")),
            "field": clean_text(item.get("field")),
            "reason": clean_text(item.get("reason")),
            "fix": clean_text(item.get("what_to_resubmit")),
        }
        for item in missing_report_fields
        if isinstance(item, dict)
    ]
    top_fixes: list[str] = []
    seen: set[str] = set()
    for item in missing_items:
        fix = item["fix"]
        if fix and fix not in seen:
            top_fixes.append(fix)
            seen.add(fix)
        if len(top_fixes) == 3:
            break
    if top_fixes:
        paste_ready = "Please re-submit report-ready audit_data with: " + " ".join(
            f"{index + 1}) {fix}" for index, fix in enumerate(top_fixes)
        )
    else:
        paste_ready = "Report preflight passed. Generate the report from the current canonical audit_data."
    status_label = "ready" if not missing_items and preflight_status == "passed" else "needs_resubmission"
    summary = (
        "Report preflight passed; the payload is ready for rendering."
        if status_label == "ready"
        else f"Report preflight is blocked until {len(missing_items)} report-critical field(s) are completed."
    )
    return {
        "status": status_label,
        "preflight_status": preflight_status,
        "summary": summary,
        "complete_sections": complete_sections,
        "incomplete_sections": incomplete_sections,
        "missing_count": len(missing_items),
        "missing_fields": missing_items,
        "top_fixes": top_fixes,
        "paste_ready_resubmit_prompt": paste_ready,
        "strict_gate_note": "This card explains the existing strict readiness gate; it does not loosen report validation or authorize placeholder output.",
    }


def assess_report_readiness(payload: dict[str, Any], *, allow_placeholders: bool = False) -> dict[str, Any]:
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    depth = clean_text(meta.get("report_depth")) or "full"
    missing: list[dict[str, Any]] = []

    dimensions = [item for item in ensure_list(cis.get("dimensions")) if isinstance(item, dict)]
    biases = [item for item in ensure_list(findings.get("biases")) if isinstance(item, dict)]
    assumptions = [item for item in ensure_list(payload.get("assumptions")) if isinstance(item, dict)]
    frames = [item for item in ensure_list(payload.get("alternative_frames")) if isinstance(item, dict)]
    questions = _meaningful_questions(payload)
    next_steps = _meaningful_next_steps(payload)
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    agents = [item for item in ensure_list(advanced.get("agents")) if isinstance(item, dict)]
    advanced_present = bool(advanced.get("present") or agents)

    compiled = {
        "cis": False,
        "quick_scan": False,
        "dimensions": False,
        "assumptions": False,
        "frames": False,
        "questions": False,
        "next_steps": False,
        "follow_up_activity": False,
        "agent_findings": not advanced_present,
        "argument_map": True,
        "checkworthy_claims": True,
        "dissent_ledger": not advanced_present,
        "reasoning_traps": True,
    }

    if depth != "checklist_only":
        if cis.get("display_state") == "profile_only":
            cis_scored_ok = True
        else:
            cis_scored_ok = bool(cis.get("label") and cis.get("points") is not None)
            if not cis_scored_ok:
                _append_missing(missing, "Critical Integrity Snapshot", "cis.label_or_points", "Scored report is missing label or points.", "Re-submit CIS label and points, or set display_state=profile_only.")
        plain_ok = is_meaningful_text(cis.get("plain_language_read"), min_words=6)
        before_ok = is_meaningful_text(cis.get("before_using_this_text"), min_words=6)
        if not plain_ok:
            _append_missing(missing, "Plain-Language Read", "cis.plain_language_read", "Plain-language read is missing or placeholder-only.", "Re-submit a one- to two-sentence plain-language read.")
        if not before_ok:
            _append_missing(missing, "Before Using This Text", "cis.before_using_this_text", "Before-use guidance is missing or placeholder-only.", "Re-submit one to two sentences starting exactly with 'Before using this text,'.")
        elif not _before_using_has_required_prefix(cis.get("before_using_this_text")):
            before_ok = False
            _append_missing(missing, "Before Using This Text", "cis.before_using_this_text", "Before-use guidance does not start with the required opener.", "Re-submit one to two sentences starting exactly with 'Before using this text,'.")
        compiled["cis"] = cis_scored_ok and plain_ok and before_ok

        if depth != "readiness_card":
            dimension_ok = len(dimensions) == 5
            if len(dimensions) != 5:
                _append_missing(missing, "Dimension Deep-Dive", "cis.dimensions", "Full reports require exactly five CIS dimensions.", "Re-submit all five CIS dimensions.")
            for index, dimension in enumerate(dimensions[:5]):
                dimension_ok = _dimension_is_complete(dimension, index, missing) and dimension_ok
            compiled["dimensions"] = dimension_ok

            bias_ok = bool(biases)
            if not biases:
                _append_missing(missing, "Top Biases Identified", "findings.biases", "Full or overview reports require at least one complete bias row.", "Re-submit at least one bias row with name, where, why-it-matters, and lens.")
            for index, bias in enumerate(biases[:5]):
                bias_ok = _bias_is_complete(bias, index, missing) and bias_ok
            key_ok = is_meaningful_text(findings.get("key_tension"), min_words=8)
            next_ok = is_meaningful_text(findings.get("recommended_next_step"), min_words=4, require_action=True)
            if not key_ok:
                _append_missing(missing, "Key Tension", "findings.key_tension", "Key tension is missing or placeholder-only.", "Re-submit the key tension as one sentence.")
            if not next_ok:
                _append_missing(missing, "Recommended Next Step", "findings.recommended_next_step", "Recommended next step is missing or generic.", "Re-submit one concrete action-oriented next step.")
            compiled["quick_scan"] = bias_ok and key_ok and next_ok

    if depth == "readiness_card":
        card = payload.get("pressure_test_readiness_card") if isinstance(payload.get("pressure_test_readiness_card"), dict) else {}
        compiled["assumptions"] = True
        compiled["frames"] = True
        compiled["questions"] = True
        compiled["next_steps"] = True
        compiled["dimensions"] = True
        compiled["quick_scan"] = bool(
            is_meaningful_text(card.get("decision_action"), min_words=1)
            and is_meaningful_text(card.get("rationale"), min_words=6)
            and is_meaningful_text(card.get("next_move"), min_words=4, require_action=True)
        )
        if not compiled["quick_scan"]:
            _append_missing(
                missing,
                "Audit Summary",
                "pressure_test_readiness_card",
                "Readiness-card reports require a primary action, rationale, and concrete next move.",
                "Re-submit pressure_test_readiness_card with decision_action, rationale, and next_move.",
            )
        compiled["follow_up_activity"] = _follow_up_activity_is_complete(payload, depth, missing)
    elif depth == "full":
        compiled["assumptions"] = bool(assumptions) and all(is_meaningful_text(item.get("assumption"), min_words=5) and is_meaningful_text(item.get("evidence_needed"), min_words=5) for item in assumptions)
        if not compiled["assumptions"]:
            _append_missing(missing, "Assumption Audit", "assumptions", "Full reports require at least one meaningful assumption row.", "Re-submit assumptions[] with assumption, testable/status, and evidence_needed.")
        compiled["frames"] = bool(frames) and all(is_meaningful_text(item.get("name"), min_words=1) and is_meaningful_text(item.get("frame"), min_words=6) for item in frames)
        if not compiled["frames"]:
            _append_missing(missing, "Alternative Frames", "alternative_frames", "Full reports require at least one meaningful alternative frame.", "Re-submit alternative_frames[] with name, frame/description, and lens.")
        compiled["questions"] = len(questions) >= 3
        if not compiled["questions"]:
            _append_missing(missing, "Probing Questions", "questions.probing_or_follow_up", "Full reports require at least three meaningful probing/follow-up questions.", "Re-submit probing_questions/follow_up_questions or questions.probing/questions.follow_up.")
        compiled["next_steps"] = len(next_steps) >= 3
        if not compiled["next_steps"]:
            _append_missing(missing, "Next Steps", "next_steps", "Full reports require at least three meaningful next steps; numeric-only values are rejected.", "Re-submit next_steps[] with three action-oriented steps.")
        if advanced_present:
            compiled["agent_findings"] = bool(agents) and all(is_meaningful_text(item.get("top_finding"), min_words=6) for item in agents)
            if not compiled["agent_findings"]:
                _append_missing(missing, "Analytical Lens Attribution", "advanced_audit.agents[].top_finding", "Advanced-audit report is missing one or more agent top findings.", "Re-submit advanced_audit.agents[] with top_finding/finding/key_finding/contribution.")
            kb_signal = payload.get("kb_coverage_signal") if isinstance(payload.get("kb_coverage_signal"), dict) else {}
            if kb_signal.get("qa_blocking"):
                compiled["kb_grounding"] = False
                _append_missing(
                    missing,
                    "Corpus Grounding",
                    "kb_coverage_signal",
                    kb_signal.get("warning") or "Advanced report has too little KB grounding.",
                    "Add KB IDs from lookup_bias/search_knowledge_base/get_framework, or explicitly mark this as host_inference_heavy for a draft.",
                )
            else:
                compiled["kb_grounding"] = True
        else:
            compiled["kb_grounding"] = True
        compiled["argument_map"] = _argument_map_is_complete(payload, missing)
        compiled["checkworthy_claims"] = _checkworthy_claims_are_complete(payload, missing)
        compiled["dissent_ledger"] = _dissent_ledger_is_complete(payload, missing)
        compiled["reasoning_traps"] = _reasoning_traps_are_complete(payload, missing)
        compiled["follow_up_activity"] = _follow_up_activity_is_complete(payload, depth, missing)
    elif depth == "overview":
        compiled["assumptions"] = True
        compiled["frames"] = True
        compiled["questions"] = True
        compiled["next_steps"] = True
        compiled["follow_up_activity"] = _follow_up_activity_is_complete(payload, depth, missing)
    elif depth == "checklist_only":
        compiled["cis"] = True
        compiled["quick_scan"] = True
        compiled["dimensions"] = True
        compiled["assumptions"] = True
        compiled["frames"] = True
        compiled["next_steps"] = True
        compiled["questions"] = len(questions) >= 3
        compiled["follow_up_activity"] = True
        if not compiled["questions"]:
            _append_missing(missing, "Questions Checklist", "questions.probing_or_follow_up", "Checklist reports require at least three meaningful questions.", "Re-submit at least three probing or follow-up questions.")

    passed = not missing
    preflight_status = "passed" if passed else "placeholder_override" if allow_placeholders else "blocked_missing_fields"
    preflight_card = build_report_preflight_card(compiled, missing, preflight_status=preflight_status)
    return {
        "passed": passed or allow_placeholders,
        "preflight_status": preflight_status,
        "compiled_sections": compiled,
        "missing_report_fields": missing,
        "what_to_resubmit": [item["what_to_resubmit"] for item in missing],
        "report_preflight_card": preflight_card,
        "issues": [
            {
                "check": "report_readiness",
                "severity": "cosmetic" if allow_placeholders else "blocking",
                "page": None,
                "issue": f"{item['section']}: {item['reason']}",
                "fix": item["what_to_resubmit"],
                "field": item["field"],
                "section": item["section"],
                "accepted_aliases": item["accepted_aliases"],
            }
            for item in missing
        ],
    }
