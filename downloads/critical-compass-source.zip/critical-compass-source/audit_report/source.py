from __future__ import annotations

import hashlib
import os
import re
import shutil
from pathlib import Path
from typing import Any

from .models import clean_text, json_dumps, report_timestamp, word_count


OCR_MODES = {"auto", "force", "off"}
OCR_PROVIDERS = {"auto", "apple_vision", "tesseract"}
SPARSE_MIN_CHARS = 500
SPARSE_CHARS_PER_PAGE = 80
SPARSE_MIN_WORDS = 80
SPARSE_WORDS_PER_PAGE = 10
APPLE_VISION_FIX = "On macOS, install pyobjc-framework-Vision, pyobjc-framework-Quartz, and pyobjc-framework-Cocoa in the Critical Compass MCP environment."
TESSERACT_FIX = "Install local Tesseract OCR plus pytesseract/Pillow. Examples: macOS `brew install tesseract`; Ubuntu/Debian `sudo apt-get install tesseract-ocr`; Windows install Tesseract OCR and ensure `tesseract` is on PATH."


def _warning(code: str, message: str, fix: str | None = None) -> dict[str, str]:
    payload = {"code": code, "message": message}
    if fix:
        payload["fix"] = fix
    return payload


def ocr_dependency_guidance() -> dict[str, str]:
    return {
        "apple_vision": APPLE_VISION_FIX,
        "tesseract": TESSERACT_FIX,
        "offline_only": "Critical Compass uses local OCR providers only. No cloud OCR or external document upload is performed by prepare_audit_source.",
    }


def _source_id(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_stem(path: Path) -> str:
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", path.stem).strip("-._")
    return stem or "audit-source"


def _default_output_dir(source_path: Path, source_id: str) -> Path:
    default_reports_dir = Path(__file__).resolve().parents[1] / "reports"
    root = Path(os.getenv("CRITICAL_COMPASS_REPORTS_DIR", str(default_reports_dir))).expanduser() / "source-preflight"
    return root / f"{_safe_stem(source_path)}-{source_id[:12]}-{report_timestamp()}"


def _empty_result(source_path: Path, status: str, warnings: list[dict[str, str]]) -> dict[str, Any]:
    return {
        "status": status,
        "source_path": str(source_path.expanduser().resolve()),
        "source_id": "",
        "page_count": 0,
        "text": "",
        "text_path": "",
        "extraction_method": "",
        "ocr_used": False,
        "ocr_provider": "",
        "available_ocr_providers": [],
        "ocr_provider_status": [],
        "ocr_dependency_guidance": ocr_dependency_guidance(),
        "ocr_language": "",
        "text_char_count": 0,
        "text_word_count": 0,
        "page_image_paths": [],
        "warnings": warnings,
        "source_tool_trust_preflight": {},
        "trust_preflight_path": "",
        "trust_summary": {},
    }


def _trust_summary(preflight: dict[str, Any]) -> dict[str, Any]:
    provenance = preflight.get("source_provenance") if isinstance(preflight.get("source_provenance"), dict) else {}
    ocr = preflight.get("ocr_extraction_confidence") if isinstance(preflight.get("ocr_extraction_confidence"), dict) else {}
    prompt_injection = preflight.get("prompt_injection_checks") if isinstance(preflight.get("prompt_injection_checks"), dict) else {}
    return {
        "status": clean_text(preflight.get("status") or "unknown"),
        "source_id": clean_text(provenance.get("source_id")),
        "extraction_method": clean_text(provenance.get("extraction_method")),
        "ocr_confidence": clean_text(ocr.get("level") or "unknown"),
        "prompt_injection_present": bool(prompt_injection.get("present")),
        "warning_count": len(preflight.get("warnings") if isinstance(preflight.get("warnings"), list) else []),
    }


def _attach_trust_preflight(result: dict[str, Any], target_dir: Path | None) -> dict[str, Any]:
    from .trust import source_tool_trust_preflight  # pylint: disable=import-outside-toplevel

    preflight = source_tool_trust_preflight(result)
    result["source_tool_trust_preflight"] = preflight
    result["trust_summary"] = _trust_summary(preflight)
    result["trust_preflight_path"] = ""
    if target_dir is not None:
        target_dir.mkdir(parents=True, exist_ok=True)
        trust_path = target_dir / "source-trust-preflight.json"
        trust_path.write_text(json_dumps({"trust_preflight": preflight, "trust_summary": result["trust_summary"]}), encoding="utf-8")
        result["trust_preflight_path"] = str(trust_path.resolve())
    return result


def _is_sparse_text(text: str, page_count: int) -> bool:
    chars = len(clean_text(text))
    words = word_count(text)
    return chars < max(SPARSE_MIN_CHARS, page_count * SPARSE_CHARS_PER_PAGE) or words < max(SPARSE_MIN_WORDS, page_count * SPARSE_WORDS_PER_PAGE)


def _extract_pdf_text(doc: Any) -> str:
    parts = []
    for page_number, page in enumerate(doc, start=1):
        text = page.get_text("text")
        if clean_text(text):
            parts.append(f"--- Page {page_number} ---\n{text.strip()}")
    return "\n\n".join(parts)


def _render_page_images(doc: Any, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    import fitz  # pylint: disable=import-error,import-outside-toplevel

    render_matrix = fitz.Matrix(2, 2)
    for index, page in enumerate(doc, start=1):
        image_path = output_dir / f"page-{index:02d}.png"
        pix = page.get_pixmap(matrix=render_matrix, alpha=False)
        pix.save(str(image_path))
        paths.append(image_path)
    return paths


def _load_apple_vision() -> tuple[Any, Any, Any, Any, Any, Any] | None:
    try:
        from Foundation import NSURL  # type: ignore
        from Quartz import CGImageSourceCreateImageAtIndex, CGImageSourceCreateWithURL  # type: ignore
        from Vision import VNImageRequestHandler, VNRecognizeTextRequest, VNRequestTextRecognitionLevelAccurate  # type: ignore
    except Exception:
        return None
    return NSURL, CGImageSourceCreateWithURL, CGImageSourceCreateImageAtIndex, VNImageRequestHandler, VNRecognizeTextRequest, VNRequestTextRecognitionLevelAccurate


def _load_tesseract() -> tuple[Any, str, str] | None:
    binary = shutil.which("tesseract")
    if not binary:
        return None
    try:
        import pytesseract  # type: ignore  # pylint: disable=import-error,import-outside-toplevel
    except Exception:
        return None
    try:
        version = str(pytesseract.get_tesseract_version())
    except Exception:
        version = ""
    return pytesseract, version, binary


def _ocr_provider_status() -> list[dict[str, Any]]:
    vision_available = _load_apple_vision() is not None
    tesseract = _load_tesseract()
    return [
        {
            "provider": "apple_vision",
            "available": vision_available,
            "platform": "macos",
            "fix": "" if vision_available else APPLE_VISION_FIX,
        },
        {
            "provider": "tesseract",
            "available": tesseract is not None,
            "platform": "cross_platform",
            "binary": tesseract[2] if tesseract else "",
            "version": tesseract[1] if tesseract else "",
            "fix": "" if tesseract else TESSERACT_FIX,
        },
    ]


def _available_ocr_providers(status: list[dict[str, Any]] | None = None) -> list[str]:
    status = status or _ocr_provider_status()
    return [str(item["provider"]) for item in status if item.get("available")]


def _normalize_ocr_provider(value: str | None) -> str:
    provider = clean_text(value or "auto").lower().replace("-", "_")
    return provider if provider in OCR_PROVIDERS else "auto"


def _normalize_ocr_language(value: str | None, provider: str) -> str:
    language = clean_text(value or "").strip()
    if language:
        return language
    return "en-US" if provider == "apple_vision" else "eng"


def _select_ocr_provider(provider_request: str, status: list[dict[str, Any]]) -> tuple[str | None, list[dict[str, str]]]:
    available = set(_available_ocr_providers(status))
    if provider_request == "auto":
        if "apple_vision" in available:
            return "apple_vision", []
        if "tesseract" in available:
            return "tesseract", []
        return None, [
            _warning(
                "missing_ocr_provider",
                "No local OCR provider is available for sparse/scanned PDF text.",
                f"{APPLE_VISION_FIX} {TESSERACT_FIX}",
            )
        ]
    if provider_request in available:
        return provider_request, []
    fix = APPLE_VISION_FIX if provider_request == "apple_vision" else TESSERACT_FIX
    return None, [_warning(f"missing_{provider_request}", f"Requested OCR provider `{provider_request}` is unavailable.", fix)]


def _vision_language(language_code: str | None) -> str:
    language = clean_text(language_code or "en-US")
    if language.lower() in {"eng", "en"}:
        return "en-US"
    return language


def _ocr_image_apple_vision(image_path: Path, language_code: str | None = "en-US") -> str:
    vision = _load_apple_vision()
    if vision is None:
        raise RuntimeError(f"Apple Vision OCR dependencies are unavailable. {APPLE_VISION_FIX}")
    NSURL, source_create, image_create, handler_cls, request_cls, accurate_level = vision
    url = NSURL.fileURLWithPath_(str(image_path))
    source = source_create(url, None)
    cgimage = image_create(source, 0, None)
    request = request_cls.alloc().init()
    request.setRecognitionLevel_(accurate_level)
    request.setUsesLanguageCorrection_(True)
    request.setRecognitionLanguages_([_vision_language(language_code)])
    handler = handler_cls.alloc().initWithCGImage_options_(cgimage, {})
    ok, error = handler.performRequests_error_([request], None)
    if not ok:
        raise RuntimeError(str(error))
    items: list[dict[str, Any]] = []
    for observation in request.results() or []:
        candidates = observation.topCandidates_(1)
        if not candidates:
            continue
        text = str(candidates[0].string()).strip()
        if not text:
            continue
        box = observation.boundingBox()
        items.append({"x": float(box.origin.x), "y": float(box.origin.y), "text": text})
    left = [item for item in items if item["x"] < 0.48]
    right = [item for item in items if item["x"] >= 0.48]

    def lines(group: list[dict[str, Any]]) -> list[str]:
        return [item["text"] for item in sorted(group, key=lambda row: (-row["y"], row["x"]))]

    if len(left) >= 6 and len(right) >= 6:
        return "\n".join(lines(left) + lines(right))
    return "\n".join(lines(items))


def _ocr_image_tesseract(image_path: Path, language_code: str | None = "eng") -> str:
    tesseract = _load_tesseract()
    if tesseract is None:
        raise RuntimeError(f"Tesseract OCR is unavailable. {TESSERACT_FIX}")
    pytesseract, _version, _binary = tesseract
    language = clean_text(language_code or "eng") or "eng"
    return str(pytesseract.image_to_string(str(image_path), lang=language)).strip()


def _ocr_image(image_path: Path, provider: str, language_code: str | None = None) -> str:
    if provider == "tesseract":
        return _ocr_image_tesseract(image_path, language_code)
    return _ocr_image_apple_vision(image_path, language_code)


def _ocr_page_images(image_paths: list[Path], provider: str, language_code: str | None = None) -> tuple[str, list[dict[str, str]]]:
    warnings: list[dict[str, str]] = []
    pages: list[str] = []
    for index, image_path in enumerate(image_paths, start=1):
        try:
            text = _ocr_image(image_path, provider, language_code)
        except Exception as exc:  # pragma: no cover - hardware/framework dependent
            warnings.append(_warning("ocr_page_failed", f"OCR failed on page {index}: {exc}", "Inspect the page image and retry after fixing OCR dependencies."))
            text = ""
        pages.append(f"--- Page {index} ---\n{text.strip()}")
    return "\n\n".join(pages), warnings


def prepare_audit_source(
    source_path: str,
    ocr_mode: str | None = "auto",
    ocr_provider: str | None = "auto",
    ocr_language: str | None = "eng",
    output_dir: str | None = None,
    include_page_images: bool = True,
) -> dict[str, Any]:
    path = Path(source_path).expanduser().resolve()
    mode = clean_text(ocr_mode or "auto").lower()
    if mode not in OCR_MODES:
        mode = "auto"
    provider_request = _normalize_ocr_provider(ocr_provider)
    provider_status = _ocr_provider_status()
    available_providers = _available_ocr_providers(provider_status)
    dependency_guidance = ocr_dependency_guidance()
    if not path.exists():
        return _empty_result(path, "blocked", [_warning("missing_source", "Source path does not exist.", "Pass a readable local PDF path.")])
    if path.suffix.lower() != ".pdf":
        return _empty_result(path, "blocked", [_warning("unsupported_source", "Only local PDF source files are supported in v1.", "Convert the source to PDF or pass extracted text directly to audit_text/advanced_audit.")])

    try:
        import fitz  # pylint: disable=import-error,import-outside-toplevel
    except ModuleNotFoundError:
        return _empty_result(path, "needs_ocr_dependency", [_warning("missing_pymupdf", "PyMuPDF is required for PDF source preparation.", "Install pymupdf in the Critical Compass MCP environment.")])

    source_id = _source_id(path)
    target_dir = Path(output_dir).expanduser().resolve() if output_dir else _default_output_dir(path, source_id)
    target_dir.mkdir(parents=True, exist_ok=True)
    text_path = target_dir / f"{_safe_stem(path)}-audit-source.txt"
    image_dir = target_dir / "pages"
    warnings: list[dict[str, str]] = []

    try:
        doc = fitz.open(str(path))
    except Exception as exc:
        return _empty_result(path, "blocked", [_warning("pdf_open_failed", f"Could not open PDF: {exc}", "Verify the file is a readable PDF.")])

    try:
        page_count = doc.page_count
        embedded_text = _extract_pdf_text(doc)
        sparse = _is_sparse_text(embedded_text, page_count)
        image_paths: list[Path] = []
        if include_page_images or sparse or mode == "force":
            image_paths = _render_page_images(doc, image_dir)
    finally:
        doc.close()

    if mode != "force" and not sparse:
        text = embedded_text
        extraction_method = "embedded_text"
        ocr_used = False
        selected_provider = ""
        selected_language = ""
    elif mode == "off":
        warnings.append(_warning("embedded_text_sparse", "Embedded PDF text is too sparse for a reliable audit, and OCR is off.", "Run prepare_audit_source with ocr_mode='auto' or 'force'."))
        return _attach_trust_preflight({
            "status": "blocked",
            "source_path": str(path),
            "source_id": source_id,
            "page_count": page_count,
            "text": embedded_text,
            "text_path": "",
            "extraction_method": "embedded_text",
            "ocr_used": False,
            "ocr_provider": "",
            "available_ocr_providers": available_providers,
            "ocr_provider_status": provider_status,
            "ocr_dependency_guidance": dependency_guidance,
            "ocr_language": "",
            "text_char_count": len(clean_text(embedded_text)),
            "text_word_count": word_count(embedded_text),
            "page_image_paths": [str(item.resolve()) for item in image_paths] if include_page_images else [],
            "warnings": warnings,
        }, target_dir)
    else:
        selected_provider, provider_warnings = _select_ocr_provider(provider_request, provider_status)
        if selected_provider is None:
            warnings.extend(provider_warnings)
            return _attach_trust_preflight({
                "status": "needs_ocr_dependency",
                "source_path": str(path),
                "source_id": source_id,
                "page_count": page_count,
                "text": embedded_text,
                "text_path": "",
                "extraction_method": "embedded_text",
                "ocr_used": False,
                "ocr_provider": "",
                "available_ocr_providers": available_providers,
                "ocr_provider_status": provider_status,
                "ocr_dependency_guidance": dependency_guidance,
                "ocr_language": "",
                "text_char_count": len(clean_text(embedded_text)),
                "text_word_count": word_count(embedded_text),
                "page_image_paths": [str(item.resolve()) for item in image_paths] if include_page_images else [],
                "warnings": warnings,
            }, target_dir)
        selected_language = _normalize_ocr_language(ocr_language, selected_provider)
        provider_label = "Apple Vision" if selected_provider == "apple_vision" else "Tesseract"
        warning_message = f"Embedded PDF text was too sparse; {provider_label} OCR was used." if sparse else f"OCR was forced; {provider_label} OCR was used with embedded text review."
        warnings.append(_warning("embedded_text_sparse", warning_message, "Review OCR text and page images before relying on exact quotations."))
        text, ocr_warnings = _ocr_page_images(image_paths, selected_provider, selected_language)
        warnings.extend(ocr_warnings)
        extraction_method = f"{selected_provider}_ocr" if sparse else "mixed"
        ocr_used = True

    status = "ready"
    if _is_sparse_text(text, page_count):
        status = "blocked"
        warnings.append(_warning("prepared_text_sparse", "Prepared source text is still too sparse for a reliable audit.", "Inspect page images or use a stronger OCR path before auditing."))
    text_path.write_text(text, encoding="utf-8")
    return _attach_trust_preflight({
        "status": status,
        "source_path": str(path),
        "source_id": source_id,
        "page_count": page_count,
        "text": text,
        "text_path": str(text_path.resolve()),
        "extraction_method": extraction_method,
        "ocr_used": ocr_used,
        "ocr_provider": selected_provider,
        "available_ocr_providers": available_providers,
        "ocr_provider_status": provider_status,
        "ocr_dependency_guidance": dependency_guidance,
        "ocr_language": selected_language,
        "text_char_count": len(clean_text(text)),
        "text_word_count": word_count(text),
        "page_image_paths": [str(item.resolve()) for item in image_paths] if include_page_images else [],
        "warnings": warnings,
    }, target_dir)
