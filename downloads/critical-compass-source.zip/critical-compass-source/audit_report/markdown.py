from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .models import clean_text, ensure_list


def _line(value: Any) -> str:
    return clean_text(value)


def _contains(markdown: str, value: Any) -> bool:
    text = clean_text(value)
    if not text:
        return True
    return text.lower() in clean_text(markdown).lower()


def _append_list(lines: list[str], items: list[Any]) -> None:
    for item in items:
        text = _line(item)
        if text:
            lines.append(f"- {text}")


def _append_heading(lines: list[str], heading: str) -> None:
    lines.extend([heading, ""])


def _append_field(lines: list[str], label: str, value: Any) -> None:
    text = _line(value)
    if text:
        lines.append(f"- {label}: {text}")


def _display_before_use(value: Any) -> str:
    text = _line(value)
    prefix = "Before using this text,"
    if text.startswith(prefix):
        stripped = text[len(prefix):].strip()
        if stripped:
            return stripped[0].upper() + stripped[1:]
    return text


def _append_list_field(lines: list[str], label: str, value: Any) -> None:
    items = [_line(item) for item in _optional_list(value)]
    items = [item for item in items if item]
    if items:
        lines.append(f"- {label}: {'; '.join(items)}")


def _has_meaningful_value(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_has_meaningful_value(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(_has_meaningful_value(item) for item in value)
    return bool(_line(value))


def _optional_dict(payload: dict[str, Any], key: str) -> dict[str, Any]:
    value = payload.get(key)
    return value if isinstance(value, dict) else {}


def _optional_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if value in (None, "", [], {}):
        return []
    return [value]


def _render_inline_code_block(lines: list[str], language: str, text: Any) -> None:
    content = _line(text)
    if not content:
        return
    lines.extend([f"```{language}", content, "```", ""])


def _render_bullets(lines: list[str], items: list[Any]) -> None:
    _append_list(lines, items)


def _render_argument_map(lines: list[str], argument_map: dict[str, Any]) -> None:
    if not _has_meaningful_value(argument_map):
        return

    _append_heading(lines, "## Argument Map")
    _append_field(lines, "Central Claim", argument_map.get("central_claim"))
    _append_field(lines, "Claim Type", argument_map.get("claim_type"))
    _append_field(lines, "Confidence", argument_map.get("confidence"))
    _append_field(lines, "Status", argument_map.get("status"))

    for heading, key in [
        ("Supporting Reasons", "supporting_reasons"),
        ("Objections", "objections"),
        ("Assumptions", "assumptions"),
        ("Missing Voices", "missing_voices"),
        ("Evidence Gaps", "evidence_gaps"),
        ("Next Questions", "next_questions"),
    ]:
        items = _optional_list(argument_map.get(key))
        if items:
            lines.extend([f"### {heading}", ""])
            _render_bullets(lines, items)
            lines.append("")

    if _has_meaningful_value(argument_map.get("markdown")):
        lines.extend(["### Markdown Export", ""])
        _render_inline_code_block(lines, "markdown", argument_map.get("markdown"))
    if _has_meaningful_value(argument_map.get("argdown_path")):
        _append_field(lines, "Machine-readable argument export", argument_map.get("argdown_path"))


def _group_checkworthy_claims(checkworthy_claims: Any) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = {
        "factual": [],
        "interpretive": [],
        "causal": [],
        "normative": [],
        "policy": [],
    }
    if isinstance(checkworthy_claims, dict):
        for group_name in groups:
            for item in _optional_list(checkworthy_claims.get(group_name)):
                if isinstance(item, dict):
                    groups[group_name].append(item)
                elif _line(item):
                    groups[group_name].append({"claim": item})
        for item in _optional_list(checkworthy_claims.get("items") or checkworthy_claims.get("claims")):
            if isinstance(item, dict):
                claim_type = _line(item.get("claim_type") or item.get("type")).lower()
                if claim_type not in groups:
                    claim_type = "factual" if clean_text(item.get("verification_priority")) else "interpretive"
                groups[claim_type].append(item)
            elif _line(item):
                groups["factual"].append({"claim": item})
        return groups

    for item in _optional_list(checkworthy_claims):
        if not isinstance(item, dict):
            if _line(item):
                groups["factual"].append({"claim": item})
            continue
        claim_type = _line(item.get("claim_type") or item.get("type")).lower()
        if item.get("is_factual") is True:
            claim_type = "factual"
        if claim_type not in groups:
            claim_type = "factual" if clean_text(item.get("verification_priority")) else "interpretive"
        groups[claim_type].append(item)
    return groups


def _render_checkworthy_claims(lines: list[str], payload: dict[str, Any]) -> None:
    checkworthy_claims = payload.get("checkworthy_claims")
    groups = _group_checkworthy_claims(checkworthy_claims)
    if not any(groups.values()):
        findings = _optional_dict(payload, "findings")
        nested = findings.get("checkworthy_claims")
        groups = _group_checkworthy_claims(nested)
    if not any(groups.values()):
        return

    _append_heading(lines, "## Evidence Needed Next")
    lines.append("Note: check-worthy means worth verifying, not that the claim is false.")
    lines.append("")

    factual_items = groups["factual"]
    if factual_items:
        lines.extend(["### Factual Claims To Verify", ""])
        for item in factual_items:
            claim = _line(item.get("claim") or item.get("text"))
            if not claim:
                continue
            lines.append(f"- {claim}")
            _append_field(lines, "Verification Priority", item.get("verification_priority_label") or item.get("verification_priority") or item.get("priority"))
            _append_field(lines, "Why Check", item.get("why_check") or item.get("why_it_matters"))
            _append_field(lines, "Evidence Needed", item.get("evidence_needed"))
            _append_list_field(lines, "Suggested Queries", item.get("suggested_queries") or item.get("queries"))
            _append_list_field(lines, "Likely Source Types", item.get("likely_source_types") or item.get("source_types"))
            _append_field(lines, "Support/Contrast Status", item.get("support_contrast_label") or item.get("support_contrast_status") or item.get("support_status"))
            _append_field(lines, "Uncertainty Note", item.get("uncertainty_note") or item.get("uncertainty"))
            _append_field(lines, "Source Anchor", item.get("source_anchor") or item.get("trace"))
            _append_field(lines, "Confidence", item.get("confidence"))
        lines.append("")

    for group_name, heading in [
        ("interpretive", "Interpretive Claims"),
        ("causal", "Causal Claims"),
        ("normative", "Normative Claims"),
        ("policy", "Policy Claims"),
    ]:
        items = groups[group_name]
        if not items:
            continue
        lines.extend([f"### {heading}", ""])
        for item in items:
            claim = _line(item.get("claim") or item.get("text"))
            if not claim:
                continue
            lines.append(f"- {claim}")
            _append_field(lines, "Why Check", item.get("why_check") or item.get("why_it_matters"))
            _append_field(lines, "Evidence Needed", item.get("evidence_needed"))
            _append_list_field(lines, "Suggested Queries", item.get("suggested_queries") or item.get("queries"))
            _append_list_field(lines, "Likely Source Types", item.get("likely_source_types") or item.get("source_types"))
            _append_field(lines, "Support/Contrast Status", item.get("support_contrast_label") or item.get("support_contrast_status") or item.get("support_status"))
            _append_field(lines, "Uncertainty Note", item.get("uncertainty_note") or item.get("uncertainty"))
            _append_field(lines, "Source Anchor", item.get("source_anchor") or item.get("trace"))
            _append_field(lines, "Confidence", item.get("confidence"))
        lines.append("")


def _external_fact_check_results(payload: dict[str, Any]) -> list[dict[str, Any]]:
    external = payload.get("external_fact_checks") if isinstance(payload.get("external_fact_checks"), dict) else {}
    rows = []
    for result in _optional_list(external.get("results")):
        if not isinstance(result, dict) or not _optional_list(result.get("matches")):
            continue
        rows.append(result)
    return rows


def _render_external_fact_checks(lines: list[str], payload: dict[str, Any]) -> None:
    results = _external_fact_check_results(payload)
    if not results:
        return
    _append_heading(lines, "## External Fact Checks")
    lines.append("Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts.")
    lines.append("")
    for result in results:
        heading = _line(result.get("claim_id")) or "Retrieved claim"
        lines.extend([f"### {heading}", ""])
        _append_field(lines, "Status", result.get("status"))
        _append_field(lines, "Summary", result.get("summary"))
        for match in _optional_list(result.get("matches")):
            if not isinstance(match, dict):
                continue
            review = match.get("review") if isinstance(match.get("review"), dict) else {}
            publisher = _line(review.get("publisher_name") or review.get("publisher_site"))
            title = _line(review.get("title")) or _line(match.get("matched_claim_text"))
            rating = _line(review.get("textual_rating"))
            url = _line(review.get("url"))
            if not publisher or not url:
                continue
            lines.append(f"- {publisher}: {title}")
            if review.get("review_date"):
                lines.append(f"  Review date: {_line(review.get('review_date'))}")
            if rating:
                lines.append(f"  Publisher rating: \"{rating}\"")
            lines.append(f"  URL: {url}")
            lines.append(f"  Match confidence: {_line(match.get('match_confidence'))}")
        for caution in _optional_list(result.get("cautions")):
            lines.append(f"- Caution: {_line(caution)}")
        lines.append("")


def _render_dissent_ledger(lines: list[str], advanced: dict[str, Any]) -> None:
    dissent_ledger = advanced.get("dissent_ledger")
    if not _has_meaningful_value(dissent_ledger):
        return

    if advanced.get("consensus_only"):
        _append_heading(lines, "## Where the Analysts Reached Consensus")
    else:
        _append_heading(lines, "## Where the Analysts Disagreed")
    for entry in _optional_list(dissent_ledger):
        if not isinstance(entry, dict):
            continue
        heading = _line(entry.get("agent_name") or entry.get("agent") or entry.get("name") or entry.get("role") or entry.get("source"))
        if heading:
            lines.extend([f"### {heading}", ""])
        if entry.get("consensus_note"):
            _append_field(lines, "Shared Finding", entry.get("top_finding") or entry.get("finding") or entry.get("key_finding") or entry.get("contribution"))
            _append_field(lines, "Consensus Note", entry.get("consensus_note"))
        else:
            _append_field(lines, "Top Finding", entry.get("top_finding") or entry.get("finding") or entry.get("key_finding") or entry.get("contribution"))
            _append_field(lines, "Strongest Disagreement", entry.get("strongest_disagreement") or entry.get("disagreement"))
            _append_field(lines, "What Would Change Their Mind", entry.get("what_would_change_its_mind") or entry.get("what_would_change_mind"))
        _append_field(lines, "Confidence", entry.get("confidence"))
        _append_field(lines, "Provenance", entry.get("provenance") or entry.get("source_stage") or entry.get("stage"))
        lines.append("")


def _render_reasoning_traps(lines: list[str], payload: dict[str, Any]) -> None:
    reasoning_traps = payload.get("reasoning_traps")
    if not _has_meaningful_value(reasoning_traps):
        return

    _append_heading(lines, "## Reasoning Trap Checks")
    for entry in _optional_list(reasoning_traps):
        if not isinstance(entry, dict):
            continue
        heading = _line(entry.get("label") or entry.get("name") or entry.get("trap"))
        if heading:
            lines.extend([f"### {heading}", ""])
        _append_field(lines, "Risk", entry.get("risk") or entry.get("description") or entry.get("why_it_matters"))
        _append_field(lines, "Text-Specific Check", entry.get("text_specific_check") or entry.get("next_check") or entry.get("check"))
        _append_field(lines, "Anchor", entry.get("text_anchor"))
        _append_field(lines, "Confidence", entry.get("confidence"))
        _append_field(lines, "Provenance", entry.get("provenance") or entry.get("source_stage") or entry.get("stage"))
        lines.append("")


def _render_source_tool_trust(lines: list[str], payload: dict[str, Any]) -> None:
    preflight = payload.get("source_tool_trust_preflight")
    if not isinstance(preflight, dict) or not preflight or _line(preflight.get("status")) == "not_run":
        return
    provenance = preflight.get("source_provenance") if isinstance(preflight.get("source_provenance"), dict) else {}
    ocr = preflight.get("ocr_extraction_confidence") if isinstance(preflight.get("ocr_extraction_confidence"), dict) else {}
    prompt_injection = preflight.get("prompt_injection_checks") if isinstance(preflight.get("prompt_injection_checks"), dict) else {}
    consent = preflight.get("consent_boundaries") if isinstance(preflight.get("consent_boundaries"), dict) else {}

    _append_heading(lines, "## Source And Tool Trust Preflight")
    _append_field(lines, "Status", preflight.get("status"))
    _append_field(lines, "Source ID", provenance.get("source_id"))
    _append_field(lines, "Extraction Method", provenance.get("extraction_method"))
    _append_field(lines, "OCR Confidence", ocr.get("level"))
    _append_field(lines, "External Retrieval Allowed", consent.get("external_retrieval_allowed"))
    _append_field(lines, "Prompt Injection Signals Present", prompt_injection.get("present"))
    for warning in _optional_list(preflight.get("warnings")):
        if isinstance(warning, dict):
            _append_field(lines, "Warning", warning.get("message") or warning.get("code"))
    lines.append("")


def _render_activity_card(lines: list[str], heading: str, card: dict[str, Any]) -> None:
    if not _has_meaningful_value(card):
        return
    title = _line(card.get("title")) or heading
    lines.extend([f"### {heading}: {title}", ""])
    _append_field(lines, "Why this fits", card.get("why_this_fits"))
    _append_field(lines, "Content focus", card.get("content_focus"))
    _append_list_field(lines, "Thinking focus", card.get("thinking_focus"))
    steps = _optional_list(card.get("steps"))
    if steps:
        lines.extend(["Steps:", ""])
        _render_bullets(lines, steps)
    _append_field(lines, "Safety note", card.get("safety_note"))
    lines.append("")


def _render_follow_up_activity(lines: list[str], payload: dict[str, Any], depth: str) -> None:
    activity = payload.get("follow_up_activity") if isinstance(payload.get("follow_up_activity"), dict) else {}
    if not _has_meaningful_value(activity):
        return
    _append_heading(lines, "## Follow-Up Activity")
    if depth in {"overview", "readiness_card"}:
        _render_activity_card(lines, "Try This Next", activity.get("try_this_next") if isinstance(activity.get("try_this_next"), dict) else {})
    else:
        _render_activity_card(lines, "Solo Activity", activity.get("solo_activity") if isinstance(activity.get("solo_activity"), dict) else {})
        _render_activity_card(lines, "Group Activity", activity.get("group_activity") if isinstance(activity.get("group_activity"), dict) else {})
    _append_field(lines, "Activity source", activity.get("source_note"))
    guardrails = _optional_list(activity.get("guardrails"))
    if guardrails:
        lines.extend(["Guardrails:", ""])
        _render_bullets(lines, guardrails)
    lines.append("")


def _render_pressure_test_readiness_card(lines: list[str], payload: dict[str, Any]) -> None:
    card = payload.get("pressure_test_readiness_card") if isinstance(payload.get("pressure_test_readiness_card"), dict) else {}
    if not _has_meaningful_value(card):
        return
    _append_heading(lines, "## Audit Summary")
    _append_field(lines, "Executive summary", card.get("executive_summary"))
    _append_field(lines, "Primary action", card.get("decision_action"))
    _append_field(lines, "Rationale", card.get("rationale"))
    _append_field(lines, "CIS signal", card.get("cis_signal"))
    _append_field(lines, "Evidence strength signal", card.get("evidence_strength_signal"))
    _append_field(lines, "Missing-voice risk", card.get("missing_voice_risk"))
    _append_field(lines, "Before-use caution", _display_before_use(card.get("before_use_caution")))
    _append_field(lines, "Next move", card.get("next_move"))
    lines.append("")


def render_markdown(payload: dict[str, Any]) -> str:
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    questions = payload.get("questions") if isinstance(payload.get("questions"), dict) else {}
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    depth = _line(meta.get("report_depth")) or "full"

    lines: list[str] = [
        "# Critical Integrity Report",
        "",
        f"Title: {_line(meta.get('report_title'))}",
        f"Date: {_line(meta.get('date'))}",
        f"Text Type: {_line(meta.get('text_type'))}",
        f"Audit Method: {_line(meta.get('audit_method'))}",
        f"Audience: {_line(meta.get('report_audience'))}",
        f"Mode: {_line(meta.get('report_mode'))}",
        "",
    ]
    context_lens = cis.get("context_lens") if isinstance(cis.get("context_lens"), dict) else {}
    if _line(context_lens.get("evidence_convention_label")):
        lines.insert(7, _line(context_lens.get("evidence_convention_label")))

    if depth == "checklist_only":
        lines.extend(["## Questions To Bring To This Text", ""])
        _append_list(lines, [*ensure_list(questions.get("probing")), *ensure_list(questions.get("follow_up"))])
        lines.append("")
        return "\n".join(lines).strip() + "\n"

    lines.extend(["## Critical Integrity Snapshot", ""])
    if cis.get("display_state") == "profile_only":
        lines.append("Aggregate score withheld - text too short or tradition unclear for reliable comparison.")
    else:
        lines.append(f"Label: {_line(cis.get('label'))}")
        lines.append(f"Points: {_line(cis.get('points'))}/{_line(cis.get('max_points'))}")
    lines.append("")

    lines.extend(["## Plain-Language Read", "", _line(cis.get("plain_language_read")), ""])
    lines.extend(["## Before Using This Text", "", _display_before_use(cis.get("before_using_display") or cis.get("before_using_this_text")), ""])
    _render_pressure_test_readiness_card(lines, payload)

    if depth == "readiness_card":
        _render_follow_up_activity(lines, payload, depth)
        return "\n".join(lines).strip() + "\n"

    lines.extend(["## Quick-Scan Findings", "", "### Top Biases Identified", ""])
    for bias in ensure_list(findings.get("biases")):
        if not isinstance(bias, dict):
            continue
        name = _line(bias.get("name"))
        kb_id = _line(bias.get("kb_id"))
        passage = _line(bias.get("passage"))
        why = _line(bias.get("why_it_matters"))
        lens = _line(bias.get("three_cs_lens"))
        lines.append(f"- {name} ({lens})")
        if kb_id:
            lines.append(f"  KB ID: {kb_id}")
        if passage:
            lines.append(f"  Where: {passage}")
        if why:
            lines.append(f"  Why it matters: {why}")
    lines.extend(["", "### Key Tension", "", _line(findings.get("key_tension")), ""])
    lines.extend(["### Recommended Next Step", "", _line(findings.get("recommended_next_step")), ""])

    _render_argument_map(lines, _optional_dict(payload, "argument_map"))
    _render_checkworthy_claims(lines, payload)
    _render_external_fact_checks(lines, payload)

    if depth == "overview":
        _render_follow_up_activity(lines, payload, depth)
        return "\n".join(lines).strip() + "\n"

    lines.extend(["## Dimension Deep-Dive", ""])
    for dimension in ensure_list(cis.get("dimensions")):
        if not isinstance(dimension, dict):
            continue
        lines.append(f"### {_line(dimension.get('name'))} ({_line(dimension.get('points'))}/{_line(dimension.get('max_points'))})")
        lines.append("")
        lines.append(_line(dimension.get("rationale")))
        if ensure_list(dimension.get("trace")):
            lines.append("Finding traced to:")
            _append_list(lines, ensure_list(dimension.get("trace")))
        lines.append(f"Improvement prompt: {_line(dimension.get('improvement_prompt'))}")
        lines.append("")

    lines.extend(["## Assumption Audit", ""])
    for item in ensure_list(payload.get("assumptions")):
        if isinstance(item, dict):
            lines.append(f"- Assumption: {_line(item.get('assumption'))}")
            lines.append(f"  Testable: {_line(item.get('testable'))}")
            lines.append(f"  What would test it: {_line(item.get('evidence_needed'))}")
    lines.append("")

    lines.extend(["## Alternative Frames", ""])
    for item in ensure_list(payload.get("alternative_frames")):
        if isinstance(item, dict):
            name = _line(item.get("name"))
            kb_id = _line(item.get("kb_id"))
            lens = _line(item.get("three_cs_lens"))
            heading = f"- {name}"
            if kb_id:
                heading += f" ({kb_id})"
            if lens:
                heading += f" [{lens}]"
            lines.append(heading)
            lines.append(f"  {_line(item.get('frame'))}")
    lines.append("")

    lines.extend(["## Questions To Bring To This Text", ""])
    _append_list(lines, [*ensure_list(questions.get("probing")), *ensure_list(questions.get("follow_up"))])
    lines.append("")

    if _line(advanced.get("verdict_paragraph")):
        lines.extend(["## Verdict Note", "", _line(advanced.get("verdict_paragraph")), ""])
    _render_dissent_ledger(lines, advanced)

    if advanced.get("present") and ensure_list(advanced.get("agents")):
        lines.extend(["## Analytical Lens Attribution", ""])
        for agent in ensure_list(advanced.get("agents")):
            if isinstance(agent, dict):
                kb = f" -> {_line(agent.get('kb_id'))}" if _line(agent.get("kb_id")) else ""
                style = f" ({_line(agent.get('reasoning_style'))})" if _line(agent.get("reasoning_style")) else ""
                lines.append(f"- {_line(agent.get('name'))}{style} -> {_line(agent.get('top_finding'))}{kb}")
        lines.append("")

    lines.extend(["## Next Steps", ""])
    _append_list(lines, ensure_list(payload.get("next_steps")))
    lines.append("")

    _render_reasoning_traps(lines, payload)
    _render_source_tool_trust(lines, payload)
    _render_follow_up_activity(lines, payload, depth)

    appendix = payload.get("appendix") if isinstance(payload.get("appendix"), dict) else {}
    if appendix.get("include_raw_text"):
        lines.extend(["## Appendix", ""])
        if appendix.get("inline_raw_text"):
            lines.append(_line(appendix.get("subject_text")))
        else:
            lines.append(f"Full audited text saved as sidecar: {_line(appendix.get('sidecar_path'))}")
        lines.append("")

    return "\n".join(lines).strip() + "\n"


def markdown_hash(markdown: str) -> str:
    return hashlib.sha256(markdown.encode("utf-8")).hexdigest()


def write_markdown_report(payload: dict[str, Any], output_path: Path) -> dict[str, str]:
    markdown = render_markdown(payload)
    markdown_path = output_path.with_suffix(".md")
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.write_text(markdown, encoding="utf-8")
    return {
        "markdown": markdown,
        "markdown_path": str(markdown_path.resolve()),
        "markdown_hash": markdown_hash(markdown),
    }


def validate_markdown(markdown: str, payload: dict[str, Any]) -> dict[str, Any]:
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    cis = payload.get("cis") if isinstance(payload.get("cis"), dict) else {}
    findings = payload.get("findings") if isinstance(payload.get("findings"), dict) else {}
    questions = payload.get("questions") if isinstance(payload.get("questions"), dict) else {}
    advanced = payload.get("advanced_audit") if isinstance(payload.get("advanced_audit"), dict) else {}
    argument_map = _optional_dict(payload, "argument_map")
    argument_map_present = _has_meaningful_value(argument_map)
    checkworthy_groups = _group_checkworthy_claims(payload.get("checkworthy_claims"))
    if not any(checkworthy_groups.values()):
        checkworthy_groups = _group_checkworthy_claims(findings.get("checkworthy_claims"))
    checkworthy_present = any(checkworthy_groups.values())
    external_fact_checks_present = bool(_external_fact_check_results(payload))
    dissent_present = _has_meaningful_value(advanced.get("dissent_ledger"))
    reasoning_traps_present = _has_meaningful_value(payload.get("reasoning_traps"))
    trust_preflight = _optional_dict(payload, "source_tool_trust_preflight")
    trust_preflight_present = _has_meaningful_value(trust_preflight) and _line(trust_preflight.get("status")) != "not_run"
    follow_up_activity = _optional_dict(payload, "follow_up_activity")
    depth = _line(meta.get("report_depth")) or "full"
    issues: list[dict[str, Any]] = []

    headings = ["# Critical Integrity Report"]
    if depth == "checklist_only":
        headings.append("## Questions To Bring To This Text")
    elif depth == "readiness_card":
        headings.extend(["## Critical Integrity Snapshot", "## Plain-Language Read", "## Before Using This Text", "## Audit Summary", "## Follow-Up Activity"])
    else:
        headings.extend(["## Critical Integrity Snapshot", "## Plain-Language Read", "## Before Using This Text", "## Audit Summary", "## Quick-Scan Findings"])
        if argument_map_present:
            headings.append("## Argument Map")
        if checkworthy_present:
            headings.append("## Evidence Needed Next")
        if external_fact_checks_present:
            headings.append("## External Fact Checks")
        headings.append("## Follow-Up Activity")
        if depth == "full":
            headings.extend(["## Dimension Deep-Dive", "## Assumption Audit", "## Alternative Frames", "## Questions To Bring To This Text", "## Next Steps"])
            if dissent_present:
                if advanced.get("consensus_only"):
                    headings.append("## Where the Analysts Reached Consensus")
                else:
                    headings.append("## Where the Analysts Disagreed")
            if reasoning_traps_present:
                headings.append("## Reasoning Trap Checks")
            if trust_preflight_present:
                headings.append("## Source And Tool Trust Preflight")
            if advanced.get("present") and ensure_list(advanced.get("agents")):
                headings.append("## Analytical Lens Attribution")

    for heading in headings:
        if heading not in markdown:
            issues.append({"check": "markdown_heading", "severity": "blocking", "issue": f"Markdown is missing required heading: {heading}", "fix": "Regenerate the markdown contract before PDF rendering."})

    required_fields: list[tuple[str, Any]] = []
    if depth == "checklist_only":
        required_fields.extend(("questions.probing_or_follow_up", item) for item in [*ensure_list(questions.get("probing")), *ensure_list(questions.get("follow_up"))])
    else:
        if cis.get("display_state") != "profile_only":
            required_fields.append(("cis.label", cis.get("label")))
        required_fields.extend(
            [
                ("cis.plain_language_read", cis.get("plain_language_read")),
                ("cis.before_using_this_text", _display_before_use(cis.get("before_using_display") or cis.get("before_using_this_text"))),
                ("pressure_test_readiness_card.decision_action", _optional_dict(payload, "pressure_test_readiness_card").get("decision_action")),
                ("pressure_test_readiness_card.next_move", _optional_dict(payload, "pressure_test_readiness_card").get("next_move")),
            ]
        )
        if depth != "readiness_card":
            required_fields.extend(
                [
                    ("findings.key_tension", findings.get("key_tension")),
                    ("findings.recommended_next_step", findings.get("recommended_next_step")),
                ]
            )
        if depth in {"overview", "readiness_card"}:
            try_next = _optional_dict(follow_up_activity, "try_this_next")
            required_fields.extend(
                [
                    ("follow_up_activity.try_this_next.title", try_next.get("title")),
                    ("follow_up_activity.try_this_next.content_focus", try_next.get("content_focus")),
                ]
            )
        if depth != "readiness_card":
            for dimension in ensure_list(cis.get("dimensions")):
                if isinstance(dimension, dict):
                    required_fields.extend(
                        [
                            ("cis.dimensions[].name", dimension.get("name")),
                            ("cis.dimensions[].improvement_prompt", dimension.get("improvement_prompt")),
                        ]
                    )
                    if depth == "full":
                        required_fields.append(("cis.dimensions[].rationale", dimension.get("rationale")))
        if depth == "full":
            for item in ensure_list(payload.get("assumptions")):
                if isinstance(item, dict):
                    required_fields.extend([("assumptions[].assumption", item.get("assumption")), ("assumptions[].evidence_needed", item.get("evidence_needed"))])
            for item in ensure_list(payload.get("alternative_frames")):
                if isinstance(item, dict):
                    required_fields.extend([("alternative_frames[].name", item.get("name")), ("alternative_frames[].frame", item.get("frame"))])
            required_fields.extend(("questions.probing_or_follow_up", item) for item in [*ensure_list(questions.get("probing")), *ensure_list(questions.get("follow_up"))])
            required_fields.extend(("next_steps[]", item) for item in ensure_list(payload.get("next_steps")))
            for activity_key in ("solo_activity", "group_activity"):
                card = _optional_dict(follow_up_activity, activity_key)
                required_fields.extend(
                    [
                        (f"follow_up_activity.{activity_key}.title", card.get("title")),
                        (f"follow_up_activity.{activity_key}.why_this_fits", card.get("why_this_fits")),
                        (f"follow_up_activity.{activity_key}.content_focus", card.get("content_focus")),
                        (f"follow_up_activity.{activity_key}.thinking_focus", _line(card.get("thinking_focus"))),
                        (f"follow_up_activity.{activity_key}.source_note", card.get("source_note")),
                    ]
                )
                for step in _optional_list(card.get("steps")):
                    required_fields.append((f"follow_up_activity.{activity_key}.steps[]", step))
            for agent in ensure_list(advanced.get("agents")):
                if isinstance(agent, dict):
                    required_fields.append(("advanced_audit.agents[].top_finding", agent.get("top_finding")))
            if argument_map_present:
                required_fields.extend(
                    [
                        ("argument_map.central_claim", argument_map.get("central_claim")),
                        ("argument_map.claim_type", argument_map.get("claim_type")),
                        ("argument_map.markdown", argument_map.get("markdown")),
                    ]
                )
            if checkworthy_present:
                required_fields.append(("checkworthy_claims.note", "check-worthy means worth verifying, not that the claim is false."))
                for item in checkworthy_groups["factual"]:
                    required_fields.extend(
                        [
                            ("checkworthy_claims[].claim", item.get("claim") or item.get("text")),
                            ("checkworthy_claims[].evidence_needed", item.get("evidence_needed")),
                            ("checkworthy_claims[].support_contrast_status", item.get("support_contrast_label") or item.get("support_contrast_status")),
                            ("checkworthy_claims[].uncertainty_note", item.get("uncertainty_note")),
                        ]
                    )
                    for source_type in _optional_list(item.get("likely_source_types")):
                        required_fields.append(("checkworthy_claims[].likely_source_types", source_type))
                    for query in _optional_list(item.get("suggested_queries")):
                        required_fields.append(("checkworthy_claims[].suggested_queries", query))
                for group_name in ["interpretive", "causal", "normative", "policy"]:
                    for item in checkworthy_groups[group_name]:
                        required_fields.extend(
                            [
                                ("checkworthy_claims[].claim", item.get("claim") or item.get("text")),
                                ("checkworthy_claims[].evidence_needed", item.get("evidence_needed")),
                                ("checkworthy_claims[].support_contrast_status", item.get("support_contrast_label") or item.get("support_contrast_status")),
                                ("checkworthy_claims[].uncertainty_note", item.get("uncertainty_note")),
                            ]
                        )
                        for source_type in _optional_list(item.get("likely_source_types")):
                            required_fields.append(("checkworthy_claims[].likely_source_types", source_type))
                        for query in _optional_list(item.get("suggested_queries")):
                            required_fields.append(("checkworthy_claims[].suggested_queries", query))
            if external_fact_checks_present:
                required_fields.append(("external_fact_checks.note", "Retrieved fact checks are evidence artifacts, not Critical Compass truth verdicts."))
                for result in _external_fact_check_results(payload):
                    for match in _optional_list(result.get("matches")):
                        if isinstance(match, dict):
                            review = match.get("review") if isinstance(match.get("review"), dict) else {}
                            required_fields.extend(
                                [
                                    ("external_fact_checks[].review.publisher_name", review.get("publisher_name")),
                                    ("external_fact_checks[].review.url", review.get("url")),
                                    ("external_fact_checks[].review.textual_rating", review.get("textual_rating")),
                                ]
                            )
            if dissent_present:
                for item in _optional_list(advanced.get("dissent_ledger")):
                    if isinstance(item, dict):
                        if item.get("consensus_note"):
                            required_fields.append(("advanced_audit.dissent_ledger[].consensus_note", item.get("consensus_note")))
                        else:
                            required_fields.extend(
                                [
                                    ("advanced_audit.dissent_ledger[].top_finding", item.get("top_finding") or item.get("finding") or item.get("key_finding") or item.get("contribution")),
                                    ("advanced_audit.dissent_ledger[].strongest_disagreement", item.get("strongest_disagreement") or item.get("disagreement")),
                                ]
                            )
            if reasoning_traps_present:
                for item in _optional_list(payload.get("reasoning_traps")):
                    if isinstance(item, dict):
                        required_fields.extend(
                            [
                                ("reasoning_traps[].label", item.get("label") or item.get("name") or item.get("trap")),
                                ("reasoning_traps[].text_specific_check", item.get("text_specific_check") or item.get("next_check") or item.get("check")),
                            ]
                        )

    for field, value in required_fields:
        if clean_text(value) and not _contains(markdown, value):
            issues.append({"check": "markdown_content", "severity": "blocking", "field": field, "issue": f"Markdown is missing required payload content for {field}.", "fix": "Regenerate the markdown contract from the normalized payload before rendering PDF."})

    forbidden_reader_text = [
        "No bias rows were supplied",
        "No explicit disagreement",
        "Name the evidence that would change this view",
        "Confidence: unknown",
        "KB grounding:",
        "Items without IDs",
        "host_inference",
        "host-inference",
        "File-O-Fun",
        "Knowledge Atlas",
        "beta.8",
        "beta.",
        "needs_evidence",
        "not_ranked_for_truth",
        "support_contrast",
        "was supplied",
        "was not supplied",
        "Activity reflection:",
    ]
    for forbidden in forbidden_reader_text:
        if _contains(markdown, forbidden):
            issues.append({"check": "markdown_reader_text", "severity": "blocking", "field": "reader_facing_output", "issue": f"Markdown includes reader-facing internal or placeholder text: {forbidden}", "fix": "Fix normalization/template rendering before PDF generation."})

    cis = _optional_dict(payload, "cis")
    points = cis.get("points")
    label = _line(cis.get("label"))
    trust_allowed = isinstance(points, int) and points >= 70 and label in {"Strong Integrity", "Exemplary Integrity"}
    if _contains(markdown, "Primary action: Trust") and not trust_allowed:
        issues.append(
            {
                "check": "markdown_primary_action_trust_contradiction",
                "severity": "blocking",
                "field": "pressure_test_readiness_card.decision_action",
                "issue": "Markdown says Primary action: Trust without a Strong/Exemplary CIS signal.",
                "fix": "Route low or moderate CIS reports to Revise, Verify, or Reframe before rendering polished output.",
            }
        )

    return {
        "passed": not issues,
        "issues": issues,
        "required_headings": headings,
    }
