from __future__ import annotations

import multiprocessing as mp
import os
import queue as queue_module
import traceback
from pathlib import Path
from typing import Any

from .models import (
    CIS_BANDS,
    PAYLOAD_SCHEMA_VERSION,
    REPORT_SCHEMA_HASH,
    RENDER_VERSION,
    TEMPLATE_VERSION,
    ReportValidationError,
    clean_text,
    json_dumps,
    make_report_id,
    payload_hash,
    report_timestamp,
    validate_payload,
)
from .markdown import render_markdown, validate_markdown, write_markdown_report
from .normalize import REPORT_FIELD_ALIASES, REPORT_INPUT_CONTRACT, normalize_audit_data, normalize_options
from .qa import qa_report
from .readiness import assess_report_readiness, build_report_preflight_card
from .render import render_pdf, renderer_dependency_status
from .render import pdf_render_timeout_seconds
from .viewer import generate_audit_artifact_viewer


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS_DIR = Path(os.getenv("CRITICAL_COMPASS_REPORTS_DIR", str(PROJECT_ROOT / "reports"))).expanduser()


def default_output_path() -> Path:
    return (REPORTS_DIR / f"audit-report-{report_timestamp()}.pdf").resolve()


def pdf_qa_timeout_seconds() -> int:
    raw = os.getenv("CRITICAL_COMPASS_PDF_QA_TIMEOUT_SECONDS", "60")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = 60
    return max(1, value)


def _qa_report_worker(result_queue: mp.Queue, report_path: str, payload: dict[str, Any], image_dir: str) -> None:
    try:
        result_queue.put({"ok": True, "result": qa_report(Path(report_path), payload, Path(image_dir))})
    except BaseException as exc:  # pragma: no cover - child-process boundary
        result_queue.put(
            {
                "ok": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
            }
        )


def qa_report_with_timeout(report_path: Path, payload: dict[str, Any], image_dir: Path, timeout_seconds: int | None = None) -> dict[str, Any]:
    timeout = timeout_seconds if timeout_seconds is not None else pdf_qa_timeout_seconds()
    if timeout <= 0:
        return qa_report(report_path, payload, image_dir)

    context_name = "fork" if hasattr(os, "fork") else "spawn"
    context = mp.get_context(context_name)
    result_queue = context.Queue()
    process = context.Process(
        target=_qa_report_worker,
        args=(result_queue, str(report_path), payload, str(image_dir)),
    )
    process.start()
    process.join(timeout)
    if process.is_alive():
        process.terminate()
        process.join(5)
        raise ReportValidationError(f"PDF QA timed out after {timeout} seconds.")
    try:
        message = result_queue.get_nowait()
    except queue_module.Empty as exc:
        raise ReportValidationError("PDF QA process exited without a result.") from exc
    if message.get("ok"):
        return message["result"]
    raise ReportValidationError(f"PDF QA failed: {message.get('error_type')}: {message.get('error')}")


def _render_pdf_worker(result_queue: mp.Queue, payload: dict[str, Any], output_path: str) -> None:
    try:
        render_pdf(payload, Path(output_path))
        diagnostics = payload.get("diagnostics") if isinstance(payload.get("diagnostics"), dict) else {}
        result_queue.put(
            {
                "ok": True,
                "report_renderer": diagnostics.get("report_renderer", {}),
                "renderer_warnings": diagnostics.get("renderer_warnings", []),
            }
        )
    except BaseException as exc:  # pragma: no cover - child-process boundary
        result_queue.put(
            {
                "ok": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
            }
        )


def render_pdf_with_timeout(payload: dict[str, Any], output: Path, timeout_seconds: int | None = None) -> Path:
    timeout = timeout_seconds if timeout_seconds is not None else pdf_render_timeout_seconds()
    if timeout <= 0:
        return render_pdf(payload, output)

    context_name = "fork" if hasattr(os, "fork") else "spawn"
    context = mp.get_context(context_name)
    result_queue = context.Queue()
    process = context.Process(target=_render_pdf_worker, args=(result_queue, payload, str(output)))
    process.start()
    process.join(timeout)
    if process.is_alive():
        process.terminate()
        process.join(5)
        raise ReportValidationError(f"PDF render timed out after {timeout} seconds.")
    try:
        message = result_queue.get_nowait()
    except queue_module.Empty as exc:
        raise ReportValidationError("PDF render process exited without a result.") from exc
    if not message.get("ok"):
        raise ReportValidationError(f"PDF render failed: {message.get('error_type')}: {message.get('error')}")
    diagnostics = payload.setdefault("diagnostics", {})
    if message.get("report_renderer"):
        diagnostics["report_renderer"] = message["report_renderer"]
    if message.get("renderer_warnings"):
        diagnostics["renderer_warnings"] = message["renderer_warnings"]
    return output


def write_render_error_log(
    *,
    output: Path,
    stage: str,
    exc: BaseException,
    digest: str,
    markdown_result: dict[str, Any] | None = None,
) -> Path:
    log_dir = output.parent / "_render_errors"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{output.stem}-{stage}-{report_timestamp()}.log"
    markdown_result = markdown_result or {}
    log_path.write_text(
        "\n".join(
            [
                f"stage={stage}",
                f"report_path={output.resolve()}",
                f"payload_hash={digest}",
                f"markdown_path={markdown_result.get('markdown_path', '')}",
                f"markdown_hash={markdown_result.get('markdown_hash', '')}",
                f"error_type={type(exc).__name__}",
                f"error={exc}",
                "",
                "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
            ]
        ),
        encoding="utf-8",
    )
    return log_path


def write_manifest(path: Path, payload: dict[str, Any], result: dict[str, Any]) -> Path:
    manifest_path = path.with_suffix(".json")
    manifest = {
        "report": result,
        "payload": payload,
    }
    manifest_path.write_text(json_dumps(manifest), encoding="utf-8")
    return manifest_path


def maybe_write_raw_text_sidecar(output_path: Path, payload: dict[str, Any]) -> str:
    appendix = payload.get("appendix") if isinstance(payload.get("appendix"), dict) else {}
    if not appendix.get("include_raw_text") or appendix.get("inline_raw_text"):
        return ""
    subject_text = appendix.get("subject_text")
    if not subject_text:
        return ""
    sidecar_path = output_path.with_name(output_path.stem + "-audited-text.txt")
    sidecar_path.write_text(subject_text, encoding="utf-8")
    appendix["sidecar_path"] = str(sidecar_path.resolve())
    appendix["subject_text"] = ""
    return appendix["sidecar_path"]


def maybe_write_argdown_sidecar(output_path: Path, payload: dict[str, Any]) -> str:
    argument_map = payload.get("argument_map") if isinstance(payload.get("argument_map"), dict) else {}
    argdown = clean_text(argument_map.get("argdown"))
    if not argdown:
        return ""
    sidecar_path = output_path.with_name(output_path.stem + "-argument-map.argdown")
    sidecar_path.write_text(argdown + "\n", encoding="utf-8")
    argument_map["argdown_path"] = str(sidecar_path.resolve())
    return argument_map["argdown_path"]


def tier_ranges(payload: dict[str, Any], page_count: int) -> tuple[str | None, str | None]:
    depth = payload.get("meta", {}).get("report_depth")
    if depth in {"checklist_only", "readiness_card"}:
        return ("1-1" if page_count else None, None)
    if depth == "overview":
        return (f"1-{page_count}" if page_count else None, None)
    tier_1 = "1-2" if page_count >= 2 else f"1-{page_count}" if page_count else None
    tier_2 = f"3-{page_count}" if page_count >= 3 else None
    return tier_1, tier_2


def schema_warning_issues(schema_warnings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "check": "schema_warning",
            "severity": "cosmetic",
            "page": None,
            "issue": warning.get("message", "Report rendered with missing optional data."),
            "fix": warning.get("fix"),
            "field": warning.get("field"),
            "section": warning.get("section"),
            "accepted_aliases": warning.get("accepted_aliases"),
        }
        for warning in schema_warnings
    ]


def payload_trust_summary(payload: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    preflight = payload.get("source_tool_trust_preflight")
    if not isinstance(preflight, dict) or not preflight:
        return {}
    provenance = preflight.get("source_provenance") if isinstance(preflight.get("source_provenance"), dict) else {}
    ocr = preflight.get("ocr_extraction_confidence") if isinstance(preflight.get("ocr_extraction_confidence"), dict) else {}
    prompt_injection = preflight.get("prompt_injection_checks") if isinstance(preflight.get("prompt_injection_checks"), dict) else {}
    return {
        "status": clean_text(preflight.get("status") or "unknown"),
        "source_id": clean_text(provenance.get("source_id")),
        "extraction_method": clean_text(provenance.get("extraction_method")),
        "ocr_confidence": clean_text(ocr.get("level") or "unknown"),
        "prompt_injection_present": bool(prompt_injection.get("present")),
        "warning_count": len(preflight.get("warnings") if isinstance(preflight.get("warnings"), list) else []),
        "external_retrieval_allowed": bool((preflight.get("consent_boundaries") or {}).get("external_retrieval_allowed")) if isinstance(preflight.get("consent_boundaries"), dict) else False,
    }


def report_schema_response(*, output: Path, dependency_status: dict[str, str]) -> dict[str, Any]:
    return {
        "status": "schema_only",
        "qa_status": "schema_only",
        "template_version": TEMPLATE_VERSION,
        "render_version": RENDER_VERSION,
        "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
        "report_schema_hash": REPORT_SCHEMA_HASH,
        "payload_hash": "",
        "preflight_status": "schema_only",
        "compiled_sections": {},
        "report_preflight_card": {
            "title": "Report Payload Schema",
            "status": "schema_only",
            "complete": [],
            "missing": [],
            "top_fixes": [],
            "what_to_resubmit": [],
            "renderer_status": dependency_status,
        },
        "what_to_resubmit": [],
        "qa_issues": [],
        "missing_report_fields": [],
        "schema_warnings": [],
        "normalization_diagnostics": {},
        "markdown_validation": {},
        "renderer_status": dependency_status,
        "dependency_status": dependency_status,
        "intended_report_path": str(output.resolve()),
        "accepted_aliases": REPORT_FIELD_ALIASES,
        "input_contract": REPORT_INPUT_CONTRACT,
        "canonical_schema": {
            "critical_integrity_snapshot": {
                "label": "Exemplary Integrity | Strong Integrity | Moderate Integrity | Limited Integrity | Needs Scrutiny",
                "points": "0-100",
                "max_points": 100,
                "plain_language_read": "1-2 plain sentences, max 40 words",
                "before_using_this_text": "must start with 'Before using this text,'",
                "dimensions": ["name", "points", "max_points", "rationale", "trace", "improvement_prompt"],
            },
            "findings": {
                "biases": ["name", "passage", "why_it_matters", "three_cs_lens", "kb_id"],
                "key_tension": "one sentence",
                "recommended_next_step": "one concrete action",
            },
            "advanced_audit": {
                "agents": ["agent_name", "top_finding", "strongest_disagreement", "confidence"],
                "dissent_ledger": ["agent_name", "top_finding", "strongest_disagreement", "what_would_change_mind", "consensus_note"],
            },
            "follow_up_activity": {
                "try_this_next": ["title", "why_this_fits", "steps", "content_focus", "thinking_focus", "source_note"],
                "solo_activity": ["title", "why_this_fits", "steps", "content_focus", "thinking_focus", "source_note"],
                "group_activity": ["title", "why_this_fits", "steps", "content_focus", "thinking_focus", "source_note"],
            },
        },
        "required_field_checklist": [
            "critical_integrity_snapshot.dimensions[].rationale",
            "advanced_audit.dissent_ledger[].top_finding",
            "advanced_audit.dissent_ledger[].strongest_disagreement",
            "advanced_audit.dissent_ledger[].what_would_change_mind",
            "advanced_audit.dissent_ledger[].consensus_note when strongest_disagreement is null",
        ],
        "consensus_null_state": {
            "strongest_disagreement": None,
            "required_companion_field": "consensus_note",
            "rule": "Use this only when analysts genuinely agree; never invent disagreement to satisfy the schema.",
        },
        "cis_bands": CIS_BANDS,
        "example_payload_shape": {
            "critical_integrity_snapshot": {"label": "Limited Integrity", "points": 36, "max_points": 100},
            "bias_rows": [{"bias": "Demand Characteristics", "why_it_matters": "The study setup may cue desired responses."}],
            "advanced_audit": {"dissent_ledger": [{"agent_name": "Panel", "strongest_disagreement": None, "consensus_note": "Agents agreed the central evidence gap is methodological."}]},
        },
        "writes_files": False,
    }


def blocked_response(
    *,
    output: Path,
    payload: dict[str, Any] | None,
    digest: str,
    issues: list[dict[str, Any]],
    readiness: dict[str, Any] | None = None,
    diagnostics: dict[str, Any] | None = None,
    markdown_result: dict[str, Any] | None = None,
    dependency_status: dict[str, str] | None = None,
) -> dict[str, Any]:
    readiness = readiness or {}
    diagnostics = diagnostics or {}
    markdown_result = markdown_result or {}
    dependency_status = dependency_status or renderer_dependency_status()
    report_preflight_card = readiness.get("report_preflight_card") or build_report_preflight_card(
        readiness.get("compiled_sections", {}),
        [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
        preflight_status=readiness.get("preflight_status", "blocked"),
    )
    report_preflight_card = {**report_preflight_card, "renderer_status": dependency_status}
    return {
        "report_path": "",
        "page_count": 0,
        "tier_1_page_range": None,
        "tier_2_page_range": None,
        "report_id": "",
        "template_version": TEMPLATE_VERSION,
        "render_version": RENDER_VERSION,
        "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
        "report_schema_hash": REPORT_SCHEMA_HASH,
        "payload_hash": digest,
        "qa_status": "blocked",
        "qa_issues": issues,
        "preview_image_path": "",
        "page_image_paths": [],
        "viewer_path": "",
        "artifact_viewer": {},
        "markdown_path": markdown_result.get("markdown_path", ""),
        "markdown_hash": markdown_result.get("markdown_hash", ""),
        "markdown_validation": markdown_result.get("markdown_validation", {}),
        "argdown_path": "",
        "preflight_status": readiness.get("preflight_status", "blocked"),
        "compiled_sections": readiness.get("compiled_sections", {}),
        "report_preflight_card": report_preflight_card,
        "what_to_resubmit": readiness.get("what_to_resubmit", []),
        "normalization_diagnostics": diagnostics,
        "renderer_status": diagnostics.get("report_renderer", {}),
        "schema_warnings": diagnostics.get("schema_warnings", []),
        "missing_report_fields": [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
        "fallback_fields_used": diagnostics.get("fallback_fields_used", []),
        "input_contract": diagnostics.get("input_contract", REPORT_INPUT_CONTRACT),
        "accepted_aliases": diagnostics.get("accepted_aliases", REPORT_FIELD_ALIASES),
        "dependency_status": dependency_status,
        "trust_summary": payload_trust_summary(payload),
        "source_tool_trust_preflight": payload.get("source_tool_trust_preflight", {}) if isinstance(payload, dict) else {},
        "pressure_test_readiness_card": payload.get("pressure_test_readiness_card", {}) if isinstance(payload, dict) else {},
        "intended_report_path": str(output.resolve()),
        "manifest_path": "",
    }


def pdf_failure_response(
    *,
    output: Path,
    payload: dict[str, Any],
    digest: str,
    stage: str,
    exc: BaseException,
    readiness: dict[str, Any],
    diagnostics: dict[str, Any],
    markdown_result: dict[str, Any],
    schema_warnings: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    schema_warnings = schema_warnings or []
    dependency_status = renderer_dependency_status()
    log_path = write_render_error_log(
        output=output,
        stage=stage,
        exc=exc,
        digest=digest,
        markdown_result=markdown_result,
    )
    section = "Renderer" if stage == "pdf_render_failed" else "PDF QA"
    field = "report_renderer" if stage == "pdf_render_failed" else "pdf_qa"
    fix = (
        "Use the returned Markdown artifact now, then retry PDF rendering after fixing the local renderer or reducing report complexity."
        if stage == "pdf_render_failed"
        else "Use the returned Markdown artifact now, then retry PDF QA after fixing the local PyMuPDF/preview environment."
    )
    renderer_missing = [
        {
            "section": section,
            "field": field,
            "reason": str(exc),
            "what_to_resubmit": fix,
        }
    ]
    renderer_card = build_report_preflight_card(
        readiness.get("compiled_sections", {}),
        renderer_missing,
        preflight_status=stage,
    )
    readiness_for_response = {
        **readiness,
        "preflight_status": stage,
        "report_preflight_card": renderer_card,
        "what_to_resubmit": renderer_card["top_fixes"],
    }
    renderer_status = {
        **dependency_status,
        "status": stage,
        "message": str(exc),
        "render_error_log_path": str(log_path.resolve()),
    }
    diagnostics_for_response = {
        **diagnostics,
        "report_renderer": renderer_status,
    }
    response = blocked_response(
        output=output,
        payload=payload,
        digest=digest,
        issues=[
            {
                "check": stage,
                "severity": "blocking",
                "issue": str(exc),
                "page": None,
                "fix": fix,
            },
            *readiness.get("issues", []),
            *schema_warning_issues(schema_warnings),
        ],
        readiness=readiness_for_response,
        diagnostics=diagnostics_for_response,
        markdown_result=markdown_result,
        dependency_status=dependency_status,
    )
    response["preflight_status"] = stage
    response["report_path"] = ""
    response["viewer_path"] = ""
    response["artifact_viewer"] = {}
    response["render_error_log_path"] = str(log_path.resolve())
    response["renderer_status"] = renderer_status
    response["report_preflight_card"] = {
        **response["report_preflight_card"],
        "renderer_status": renderer_status,
    }
    return response


def validate_report_payload(
    audit_data: dict[str, Any],
    report_audience: str | None = None,
    report_depth: str | None = None,
    report_mode: str | None = None,
    include_raw_text: bool = False,
    report_title: str | None = None,
    output_path: str | None = None,
    allow_placeholders: bool = False,
    schema_only: bool = False,
) -> dict[str, Any]:
    """Dry-run report readiness without rendering or writing files."""
    output = Path(output_path).expanduser().resolve() if output_path else default_output_path()
    dependency_status = renderer_dependency_status()
    if schema_only:
        return report_schema_response(output=output, dependency_status=dependency_status)
    if not isinstance(audit_data, dict):
        card = build_report_preflight_card(
            {},
            [
                {
                    "section": "Input",
                    "field": "audit_data",
                    "reason": "audit_data must be an object.",
                    "what_to_resubmit": "Pass a completed audit_data object.",
                }
            ],
            preflight_status="blocked",
        )
        return {
            "status": "blocked",
            "qa_status": "blocked",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": "",
            "preflight_status": "blocked",
            "compiled_sections": {},
            "report_preflight_card": {**card, "renderer_status": dependency_status},
            "what_to_resubmit": ["Pass a completed audit_data object."],
            "qa_issues": [{"check": "input", "severity": "blocking", "issue": "audit_data must be an object.", "page": None, "fix": "Pass a completed audit_data object."}],
            "missing_report_fields": [],
            "schema_warnings": [],
            "normalization_diagnostics": {},
            "markdown_validation": {},
            "renderer_status": dependency_status,
            "dependency_status": dependency_status,
            "intended_report_path": str(output.resolve()),
            "writes_files": False,
        }

    try:
        options = normalize_options(
            audit_data,
            report_audience=report_audience,
            report_depth=report_depth,
            report_mode=report_mode,
            include_raw_text=include_raw_text,
            report_title=report_title,
            output_path=output_path,
        )
        output = options.output_path or output
        payload = normalize_audit_data(audit_data, options)
        validate_payload(payload)
        digest = payload_hash(payload)
        diagnostics = payload.get("diagnostics") if isinstance(payload.get("diagnostics"), dict) else {}
        schema_warnings = diagnostics.get("schema_warnings", [])
        readiness = assess_report_readiness(payload, allow_placeholders=allow_placeholders)
        markdown = render_markdown(payload)
        markdown_validation = validate_markdown(markdown, payload)
        passed = bool(readiness["passed"] and (markdown_validation["passed"] or allow_placeholders))
        markdown_issues = [] if markdown_validation["passed"] else markdown_validation.get("issues", [])
        card = readiness.get("report_preflight_card") or build_report_preflight_card(
            readiness.get("compiled_sections", {}),
            [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
            preflight_status=readiness.get("preflight_status", "blocked"),
        )
        return {
            "status": "ready" if passed else "blocked",
            "qa_status": "preflight_passed" if passed else "blocked",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": digest,
            "preflight_status": readiness["preflight_status"],
            "compiled_sections": readiness["compiled_sections"],
            "report_preflight_card": {**card, "renderer_status": dependency_status},
            "what_to_resubmit": readiness["what_to_resubmit"],
            "qa_issues": [*readiness["issues"], *markdown_issues, *schema_warning_issues(schema_warnings)],
            "missing_report_fields": [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
            "schema_warnings": schema_warnings,
            "normalization_diagnostics": diagnostics,
            "markdown_validation": markdown_validation,
            "renderer_status": dependency_status,
            "dependency_status": dependency_status,
            "intended_report_path": str(output.resolve()),
            "accepted_aliases": diagnostics.get("accepted_aliases", REPORT_FIELD_ALIASES),
            "input_contract": diagnostics.get("input_contract", REPORT_INPUT_CONTRACT),
            "trust_summary": payload_trust_summary(payload),
            "source_tool_trust_preflight": payload.get("source_tool_trust_preflight", {}),
            "pressure_test_readiness_card": payload.get("pressure_test_readiness_card", {}),
            "writes_files": False,
        }
    except ReportValidationError as exc:
        card = build_report_preflight_card(
            {},
            [
                {
                    "section": "Validation",
                    "field": "audit_data",
                    "reason": str(exc),
                    "what_to_resubmit": "Pass a complete audit_data object that satisfies the canonical report schema.",
                }
            ],
            preflight_status="blocked",
        )
        return {
            "status": "blocked",
            "qa_status": "blocked",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": "",
            "preflight_status": "blocked",
            "compiled_sections": {},
            "report_preflight_card": {**card, "renderer_status": dependency_status},
            "what_to_resubmit": card["top_fixes"],
            "qa_issues": [{"check": "validation", "severity": "blocking", "issue": str(exc), "page": None, "fix": "Pass a complete audit_data object."}],
            "missing_report_fields": [],
            "schema_warnings": [],
            "normalization_diagnostics": {},
            "markdown_validation": {},
            "renderer_status": dependency_status,
            "dependency_status": dependency_status,
            "intended_report_path": str(output.resolve()),
            "writes_files": False,
        }


def generate_audit_report(
    audit_data: dict[str, Any],
    report_audience: str | None = None,
    report_depth: str | None = None,
    report_mode: str | None = None,
    include_raw_text: bool = False,
    report_title: str | None = None,
    output_path: str | None = None,
    allow_placeholders: bool = False,
    return_markdown: bool = True,
    preflight_check: bool = False,
) -> dict[str, Any]:
    if preflight_check:
        result = validate_report_payload(
            audit_data,
            report_audience=report_audience,
            report_depth=report_depth,
            report_mode=report_mode,
            include_raw_text=include_raw_text,
            report_title=report_title,
            output_path=output_path,
            allow_placeholders=allow_placeholders,
        )
        return {
            **result,
            "preflight_check": True,
            "writes_files": False,
            "markdown_path": "",
            "markdown_hash": "",
            "report_path": "",
            "viewer_path": "",
        }

    if not isinstance(audit_data, dict):
        return {
            "report_path": "",
            "page_count": 0,
            "tier_1_page_range": None,
            "tier_2_page_range": None,
            "report_id": "",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": "",
            "qa_status": "blocked",
            "qa_issues": [{"check": "input", "severity": "blocking", "issue": "audit_data must be an object.", "page": None, "fix": "Pass a completed audit_text or advanced_audit output object."}],
            "preview_image_path": "",
            "page_image_paths": [],
            "viewer_path": "",
            "artifact_viewer": {},
            "markdown_path": "",
            "markdown_hash": "",
            "markdown_validation": {},
            "argdown_path": "",
            "preflight_status": "blocked",
            "compiled_sections": {},
            "report_preflight_card": build_report_preflight_card(
                {},
                [
                    {
                        "section": "Input",
                        "field": "audit_data",
                        "reason": "audit_data must be an object.",
                        "what_to_resubmit": "Pass a completed audit_data object.",
                    }
                ],
                preflight_status="blocked",
            ),
            "what_to_resubmit": ["Pass a completed audit_data object."],
            "schema_warnings": [],
            "missing_report_fields": [],
            "fallback_fields_used": [],
            "input_contract": REPORT_INPUT_CONTRACT,
            "accepted_aliases": REPORT_FIELD_ALIASES,
            "dependency_status": renderer_dependency_status(),
            "trust_summary": {},
            "source_tool_trust_preflight": {},
        }

    try:
        output = Path(output_path).expanduser().resolve() if output_path else default_output_path()
        options = normalize_options(
            audit_data,
            report_audience=report_audience,
            report_depth=report_depth,
            report_mode=report_mode,
            include_raw_text=include_raw_text,
            report_title=report_title,
            output_path=output_path,
        )
        output = options.output_path or output
        payload = normalize_audit_data(audit_data, options)
        validate_payload(payload)
        digest = payload_hash(payload)
        diagnostics = payload.get("diagnostics") if isinstance(payload.get("diagnostics"), dict) else {}
        schema_warnings = diagnostics.get("schema_warnings", [])
        readiness = assess_report_readiness(payload, allow_placeholders=allow_placeholders)
        if not readiness["passed"]:
            return blocked_response(
                output=output,
                payload=payload,
                digest=digest,
                issues=[*readiness["issues"], *schema_warning_issues(schema_warnings)],
                readiness=readiness,
                diagnostics=diagnostics,
            )

        output.parent.mkdir(parents=True, exist_ok=True)
        maybe_write_raw_text_sidecar(output, payload)
        argdown_path = maybe_write_argdown_sidecar(output, payload)
        markdown_result = write_markdown_report(payload, output)
        markdown_validation = validate_markdown(markdown_result["markdown"], payload)
        markdown_result["markdown_validation"] = markdown_validation
        if not markdown_validation["passed"] and not allow_placeholders:
            return blocked_response(
                output=output,
                payload=payload,
                digest=digest,
                issues=[*markdown_validation["issues"], *readiness["issues"], *schema_warning_issues(schema_warnings)],
                readiness=readiness,
                diagnostics=diagnostics,
                markdown_result=markdown_result,
            )

        report_id = make_report_id()
        try:
            render_pdf_with_timeout(payload, output)
        except ReportValidationError as exc:
            return pdf_failure_response(
                output=output,
                payload=payload,
                digest=digest,
                stage="pdf_render_failed",
                exc=exc,
                readiness=readiness,
                diagnostics=diagnostics,
                markdown_result=markdown_result,
                schema_warnings=schema_warnings,
            )
        except Exception as exc:  # pragma: no cover - renderer boundary safety
            return pdf_failure_response(
                output=output,
                payload=payload,
                digest=digest,
                stage="pdf_render_failed",
                exc=exc,
                readiness=readiness,
                diagnostics=diagnostics,
                markdown_result=markdown_result,
                schema_warnings=schema_warnings,
            )
        qa_dir = output.parent / "_qa" / report_id
        try:
            qa = qa_report_with_timeout(output, payload, qa_dir)
        except ReportValidationError as exc:
            return pdf_failure_response(
                output=output,
                payload=payload,
                digest=digest,
                stage="pdf_qa_failed",
                exc=exc,
                readiness=readiness,
                diagnostics=diagnostics,
                markdown_result=markdown_result,
                schema_warnings=schema_warnings,
            )
        except Exception as exc:  # pragma: no cover - QA boundary safety
            return pdf_failure_response(
                output=output,
                payload=payload,
                digest=digest,
                stage="pdf_qa_failed",
                exc=exc,
                readiness=readiness,
                diagnostics=diagnostics,
                markdown_result=markdown_result,
                schema_warnings=schema_warnings,
            )
        warning_issues = schema_warning_issues(schema_warnings)
        markdown_issues = [
            {**item, "severity": "cosmetic" if allow_placeholders else item.get("severity", "blocking")}
            for item in markdown_validation["issues"]
        ]
        combined_issues = [*qa["issues"], *warning_issues, *readiness["issues"], *markdown_issues]
        final_qa_status = qa["qa_status"]
        if final_qa_status == "passed" and (warning_issues or readiness["preflight_status"] == "placeholder_override" or markdown_issues):
            final_qa_status = "passed_with_cosmetic_issues"
        page_count = int(qa.get("page_count") or 0)
        tier_1, tier_2 = tier_ranges(payload, page_count)
        result = {
            "report_path": str(output.resolve()),
            "page_count": page_count,
            "tier_1_page_range": tier_1,
            "tier_2_page_range": tier_2,
            "report_id": report_id,
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": digest,
            "qa_status": final_qa_status,
            "qa_issues": combined_issues,
            "preview_image_path": qa["preview_image_path"],
            "page_image_paths": qa["page_image_paths"],
            "markdown_path": markdown_result["markdown_path"] if return_markdown else "",
            "markdown_hash": markdown_result["markdown_hash"],
            "markdown_validation": markdown_validation,
            "argdown_path": argdown_path,
            "preflight_status": readiness["preflight_status"],
            "compiled_sections": readiness["compiled_sections"],
            "report_preflight_card": readiness.get("report_preflight_card")
            or build_report_preflight_card(
                readiness["compiled_sections"],
                [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
                preflight_status=readiness["preflight_status"],
            ),
            "what_to_resubmit": readiness["what_to_resubmit"],
            "qa": qa,
            "normalization_diagnostics": diagnostics,
            "renderer_status": diagnostics.get("report_renderer", {}),
            "schema_warnings": schema_warnings,
            "missing_report_fields": [*diagnostics.get("missing_report_fields", []), *readiness.get("missing_report_fields", [])],
            "fallback_fields_used": diagnostics.get("fallback_fields_used", []),
            "input_contract": diagnostics.get("input_contract", REPORT_INPUT_CONTRACT),
            "accepted_aliases": diagnostics.get("accepted_aliases", REPORT_FIELD_ALIASES),
            "dependency_status": renderer_dependency_status(),
            "trust_summary": payload_trust_summary(payload),
            "source_tool_trust_preflight": payload.get("source_tool_trust_preflight", {}),
            "external_fact_checks": payload.get("external_fact_checks", {}),
            "follow_up_activity": payload.get("follow_up_activity", {}),
            "pressure_test_readiness_card": payload.get("pressure_test_readiness_card", {}),
            "save_audit_result_link": {
                "result_payload": {
                    "report_id": report_id,
                    "report_path": str(output.resolve()),
                    "template_version": TEMPLATE_VERSION,
                    "render_version": RENDER_VERSION,
                    "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
                    "report_schema_hash": REPORT_SCHEMA_HASH,
                    "payload_hash": digest,
                    "markdown_path": markdown_result["markdown_path"],
                    "markdown_hash": markdown_result["markdown_hash"],
                    "argdown_path": argdown_path,
                    "preflight_status": readiness["preflight_status"],
                    "trust_summary": payload_trust_summary(payload),
                    "source_tool_trust_preflight": payload.get("source_tool_trust_preflight", {}),
                    "external_fact_checks": payload.get("external_fact_checks", {}),
                    "follow_up_activity": payload.get("follow_up_activity", {}),
                    "pressure_test_readiness_card": payload.get("pressure_test_readiness_card", {}),
                }
            },
        }
        manifest_path = write_manifest(output, payload, result)
        result["manifest_path"] = str(manifest_path.resolve())
        viewer = generate_audit_artifact_viewer(str(manifest_path))
        result["viewer_path"] = viewer.get("viewer_path", "")
        result["artifact_viewer"] = viewer
        if viewer.get("status") == "ready":
            result["save_audit_result_link"]["result_payload"]["viewer_path"] = viewer.get("viewer_path", "")
            result["save_audit_result_link"]["result_payload"]["ui_version"] = viewer.get("ui_version", "")
            write_manifest(output, payload, result)
        return result
    except ReportValidationError as exc:
        reason = str(exc)
        renderer_related = any(token in reason.lower() for token in ("weasyprint", "pymupdf", "renderer", "pdf rendering"))
        dependency_status = renderer_dependency_status()
        preflight_card = build_report_preflight_card(
            {},
            [
                {
                    "section": "Renderer" if renderer_related else "Validation",
                    "field": "report_renderer" if renderer_related else "audit_data",
                    "reason": reason,
                    "what_to_resubmit": (
                        "Fix the local PDF renderer environment or allow the built-in PyMuPDF fallback; do not hand-build a separate manual PDF unless the user explicitly asks for a placeholder."
                        if renderer_related
                        else "Install missing dependencies or pass a complete audit payload."
                    ),
                }
            ],
            preflight_status="blocked",
        )
        preflight_card = {**preflight_card, "renderer_status": dependency_status}
        return {
            "report_path": str(Path(output_path).expanduser().resolve()) if output_path else "",
            "page_count": 0,
            "tier_1_page_range": None,
            "tier_2_page_range": None,
            "report_id": "",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": "",
            "qa_status": "blocked",
            "qa_issues": [{"check": "validation", "severity": "blocking", "issue": str(exc), "page": None, "fix": "Install missing dependencies or pass a complete audit payload."}],
            "preview_image_path": "",
            "page_image_paths": [],
            "viewer_path": "",
            "artifact_viewer": {},
            "markdown_path": "",
            "markdown_hash": "",
            "markdown_validation": {},
            "argdown_path": "",
            "preflight_status": "blocked",
            "compiled_sections": {},
            "report_preflight_card": preflight_card,
            "what_to_resubmit": preflight_card["top_fixes"],
            "schema_warnings": [],
            "missing_report_fields": [],
            "fallback_fields_used": [],
            "input_contract": REPORT_INPUT_CONTRACT,
            "accepted_aliases": REPORT_FIELD_ALIASES,
            "dependency_status": dependency_status,
            "trust_summary": {},
            "source_tool_trust_preflight": {},
        }
    except Exception as exc:  # pragma: no cover - last-resort MCP safety
        dependency_status = renderer_dependency_status()
        preflight_card = build_report_preflight_card(
            {},
            [
                {
                    "section": "Renderer",
                    "field": "generate_audit_report",
                    "reason": f"{type(exc).__name__}: {exc}",
                    "what_to_resubmit": "Inspect server logs and retry after fixing the renderer error; do not hand-build a separate manual PDF unless the user explicitly asks for a placeholder.",
                }
            ],
            preflight_status="blocked",
        )
        preflight_card = {**preflight_card, "renderer_status": dependency_status}
        return {
            "report_path": str(Path(output_path).expanduser().resolve()) if output_path else "",
            "page_count": 0,
            "tier_1_page_range": None,
            "tier_2_page_range": None,
            "report_id": "",
            "template_version": TEMPLATE_VERSION,
            "render_version": RENDER_VERSION,
            "payload_schema_version": PAYLOAD_SCHEMA_VERSION,
            "report_schema_hash": REPORT_SCHEMA_HASH,
            "payload_hash": "",
            "qa_status": "blocked",
            "qa_issues": [{"check": "unexpected_error", "severity": "blocking", "issue": f"{type(exc).__name__}: {exc}", "page": None, "fix": "Inspect server logs and retry after fixing the renderer error."}],
            "preview_image_path": "",
            "page_image_paths": [],
            "viewer_path": "",
            "artifact_viewer": {},
            "markdown_path": "",
            "markdown_hash": "",
            "markdown_validation": {},
            "argdown_path": "",
            "preflight_status": "blocked",
            "compiled_sections": {},
            "report_preflight_card": preflight_card,
            "what_to_resubmit": preflight_card["top_fixes"],
            "schema_warnings": [],
            "missing_report_fields": [],
            "fallback_fields_used": [],
            "input_contract": REPORT_INPUT_CONTRACT,
            "accepted_aliases": REPORT_FIELD_ALIASES,
            "dependency_status": dependency_status,
            "trust_summary": {},
            "source_tool_trust_preflight": {},
        }
