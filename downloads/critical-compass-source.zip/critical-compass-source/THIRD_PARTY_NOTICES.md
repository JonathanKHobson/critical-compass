# Third-Party Notices

This file records third-party notice policy for Critical Compass.

Third-party dependencies declared in package metadata, lockfiles, bundled dependency folders, or runtime environment files retain their own licenses and notices. Do not rewrite those dependency licenses as Compass licenses.

If future public packages bundle third-party assets, datasets, copied documentation, generated screenshots, external examples, fonts, icons, or vendor libraries outside normal package-manager metadata, list them here with source, version, license, and attribution requirements.

Current package note: no additional third-party notices are declared here beyond dependencies and resources already carrying their own metadata, unless a product-specific section below says otherwise.
