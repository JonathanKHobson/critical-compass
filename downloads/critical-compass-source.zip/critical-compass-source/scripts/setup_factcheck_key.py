#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import os
import stat
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from factcheck.config import DEFAULT_USER_ENV, config_status, parse_env_file  # noqa: E402


KEYS = {
    "google": "GOOGLE_FACT_CHECK_API_KEY",
    "brave": "BRAVE_SEARCH_API_KEY",
}


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def _read_key(args: argparse.Namespace) -> str:
    if args.api_key:
        return args.api_key.strip()
    if args.stdin:
        return sys.stdin.read().strip()
    return getpass.getpass("Paste API key: ").strip()


def _write_env(path: Path, key_name: str, key_value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = parse_env_file(path)
    existing["CRITICAL_COMPASS_FACTCHECK_PROVIDER"] = "guided_research"
    existing[key_name] = key_value
    lines = [
        "# Critical Compass fact-check retrieval configuration.",
        "# Managed by scripts/setup_factcheck_key.py. Do not commit this file.",
    ]
    for key in sorted(existing):
        lines.append(f"{key}={existing[key]}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def status(_: argparse.Namespace) -> int:
    info = config_status()
    print("Critical Compass fact-check provider status")
    print(f"  effective_provider: {info['effective_provider']}")
    print(f"  google_api_key_available: {info['google_api_key_available']}")
    print(f"  google_api_key_source: {info['google_api_key_source'] or '(none)'}")
    print(f"  brave_api_key_available: {info['brave_api_key_available']}")
    print(f"  cache_enabled: {info['cache_enabled']}")
    print(f"  cache_dir: {info['cache_dir']}")
    print(f"  claimreview_index_path: {info['claimreview_index_path']}")
    print("  env_file_candidates:")
    for path in info["env_file_candidates"]:
        marker = "exists" if Path(path).exists() else "missing"
        print(f"    - {path} ({marker})")
    print("  default behavior:")
    print("    guided_research is the shipped default and performs no retrieval.")
    print("    local_claimreview searches a configured local index without external calls.")
    print("    External retrieval providers require explicit provider names plus allow_external_calls=true.")
    return 0


def write(args: argparse.Namespace) -> int:
    provider = args.provider
    key_name = KEYS[provider]
    key_value = _read_key(args)
    if not key_value:
        print("No API key was supplied.", file=sys.stderr)
        return 2
    target = Path(args.path).expanduser().resolve() if args.path else DEFAULT_USER_ENV
    _write_env(target, key_name, key_value)
    os.environ[key_name] = key_value
    print(f"Wrote {provider} key {_mask(key_value)} to {target}")
    print("Restart/reload the MCP host process so the new key is visible to live tools.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Configure optional Critical Compass fact-check provider keys.")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status").set_defaults(func=status)

    write_parser = sub.add_parser("write")
    write_parser.add_argument("--provider", choices=sorted(KEYS), required=True)
    write_parser.add_argument("--api-key", help="API key value. Prefer --stdin for shell history safety.")
    write_parser.add_argument("--stdin", action="store_true", help="Read the key from stdin.")
    write_parser.add_argument("--path", help=f"Destination env file. Defaults to {DEFAULT_USER_ENV}.")
    write_parser.set_defaults(func=write)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
