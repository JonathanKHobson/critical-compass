#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import types
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SMOKE_MANIFEST = ROOT / "reports" / "smoke-36-questions" / "36-questions-smoke-report.json"
REQUIRED_RESOURCE_IDS = {
    "tool_inventory",
    "demo_runbook",
    "live_qa_runbook",
    "beta_calibration_intake",
    "classroom_standard_audit_prompt",
}


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return
    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def contains_text(value: Any, needle: str) -> bool:
    return needle in json.dumps(value, sort_keys=True)


def check(condition: bool, name: str, fix: str) -> dict[str, Any]:
    return {
        "check": name,
        "passed": bool(condition),
        "fix": "" if condition else fix,
    }


def load_smoke_manifest() -> dict[str, Any]:
    if not SMOKE_MANIFEST.exists():
        return {}
    try:
        data = json.loads(SMOKE_MANIFEST.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def run_repo_local_checks() -> dict[str, Any]:
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))

    from server import critical_compass_overview_payload  # pylint: disable=import-error,import-outside-toplevel

    overview = critical_compass_overview_payload(topic="overview", audience="host_ai")
    reports = critical_compass_overview_payload(topic="reports", audience="host_ai")
    app_ui = critical_compass_overview_payload(topic="app_ui", audience="host_ai")
    smoke_manifest = load_smoke_manifest()
    smoke_report = smoke_manifest.get("report") if isinstance(smoke_manifest.get("report"), dict) else {}
    smoke_viewer_path = smoke_report.get("viewer_path")
    smoke_manifest_viewer_ok = bool(smoke_viewer_path and Path(str(smoke_viewer_path)).exists())
    resources = app_ui.get("workflow_resources") or reports.get("workflow_resources") or {}
    resource_ids = {item.get("id") for item in resources.get("resources", []) if isinstance(item, dict)}
    report_contract = reports.get("report_readiness_contract") or {}

    checks = [
        check(
            contains_text(overview, "generate_audit_artifact_viewer"),
            "overview_mentions_artifact_viewer",
            "Refresh critical_compass_overview overview/tool_map and restart the attached MCP session.",
        ),
        check(
            contains_text(reports, "generate_audit_artifact_viewer") and contains_text(reports, "prepare_audit_source"),
            "reports_topic_has_source_to_report_to_viewer_flow",
            "Update reports overview workflows/case studies so source prep, report generation, and viewer handoff are visible.",
        ),
        check(
            app_ui.get("topic") == "app_ui" and contains_text(app_ui, "generate_audit_artifact_viewer"),
            "app_ui_topic_routes_to_artifact_viewer",
            "Update app_ui aliases/topic routing and overview_topic_filter.",
        ),
        check(
            REQUIRED_RESOURCE_IDS <= resource_ids,
            "scaffold_manifest_has_surface_refresh_resources",
            "Add tool inventory, demo runbook, live QA runbook, and beta calibration intake to scaffold resources.",
        ),
        check(
            contains_text(report_contract, "viewer_path") and contains_text(report_contract, "generate_audit_artifact_viewer"),
            "report_contract_mentions_viewer_handoff",
            "Update report_readiness_contract post-call rules to include manifest/viewer handoff.",
        ),
        check(
            smoke_manifest_viewer_ok,
            "smoke_report_manifest_has_viewer_path",
            "Run scripts/smoke_36_questions_report.py and confirm the generated manifest includes an existing viewer_path.",
        ),
    ]
    passed = all(item["passed"] for item in checks)
    return {
        "status": "passed" if passed else "needs_review",
        "repo_root": str(ROOT),
        "checks": checks,
        "attached_mcp_manual_checks": [
            "Call critical_compass_overview(topic='overview') from the attached Codex MCP and confirm generate_audit_artifact_viewer appears.",
            "Call critical_compass_overview(topic='reports') from the attached Codex MCP and confirm prepare_audit_source -> generate_audit_report -> generate_audit_artifact_viewer appears.",
            "Call critical_compass_overview(topic='app_ui') from the attached Codex MCP and confirm the topic resolves to the read-only artifact viewer.",
            "If any attached MCP response is stale, restart/rebind the MCP client before running deeper report QA.",
        ],
    }


def main() -> int:
    result = run_repo_local_checks()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
