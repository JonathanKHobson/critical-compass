#!/usr/bin/env python3
"""Read-only scanner for the local MCP study library.

The scanner emits candidate pattern-learning evidence. It never imports studied
repos, runs MCP servers, installs packages, or performs network calls.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


DEFAULT_STUDY_LIBRARY = Path("/Volumes/Kyle SSD II/ExternalApplications/mcp-study-library")
IGNORED_DIRS = {".git", "node_modules", "__pycache__", ".pytest_cache", "dist", "build", ".venv", "venv"}
DOC_NAMES = {
    "readme.md",
    "claude.md",
    "gemini.md",
    "usage.md",
    "security.md",
    "contributing.md",
    "manifest.json",
    "server.json",
    "glama.json",
    "llms.txt",
    "package.json",
    "pyproject.toml",
}
DOC_DIR_HINTS = {
    ".claude",
    ".cursor",
    ".github",
    "docs",
    "examples",
    "rules",
    "templates",
    "skills",
}
SAFE_EXTENSIONS = {".md", ".json", ".toml", ".txt", ".mdc", ".yml", ".yaml"}


def _is_under(path: Path, names: set[str]) -> bool:
    return any(part.lower() in names for part in path.parts)


def _is_candidate_file(relative_path: Path) -> bool:
    parts = {part.lower() for part in relative_path.parts}
    name = relative_path.name.lower()
    suffix = relative_path.suffix.lower()

    if any(part in IGNORED_DIRS for part in parts):
        return False
    if name in DOC_NAMES:
        return True
    if "schema" in name and suffix in {".json", ".ts", ".py"}:
        return True
    if "golden" in name and suffix in {".json", ".md", ".txt"}:
        return True
    if _is_under(relative_path, DOC_DIR_HINTS) and suffix in SAFE_EXTENSIONS:
        return True
    return False


def _lesson_type_hint(relative_path: Path) -> str:
    path_text = str(relative_path).lower()
    name = relative_path.name.lower()
    if "security" in path_text or "guard" in path_text or "shield" in path_text:
        return "security_guardrail"
    if "schema" in name or name in {"server.json", "manifest.json", "package.json", "pyproject.toml"}:
        return "schema_contract"
    if "golden" in name or "test" in path_text or "eval" in path_text:
        return "eval_fixture"
    if name in {"claude.md", "gemini.md"} or "instructions" in name or "prompt" in path_text:
        return "system_prompt"
    if "example" in path_text or "template" in path_text or "skill" in path_text:
        return "scaffold_resource"
    return "repo_structure"


def _iter_repositories(study_library: Path) -> Iterable[Path]:
    for root_name in ("repos", "package-sources"):
        root = study_library / root_name
        if not root.exists():
            continue
        for child in sorted(root.iterdir()):
            if child.is_dir():
                yield child


def scan_repository(repo_path: Path, *, limit_per_repo: int = 40) -> dict[str, object]:
    candidate_files: list[dict[str, object]] = []
    for file_path in sorted(repo_path.rglob("*")):
        if not file_path.is_file():
            continue
        relative_path = file_path.relative_to(repo_path)
        if not _is_candidate_file(relative_path):
            continue
        candidate_files.append(
            {
                "path": str(relative_path),
                "lesson_type_hint": _lesson_type_hint(relative_path),
                "size_bytes": file_path.stat().st_size,
            }
        )
        if len(candidate_files) >= limit_per_repo:
            break
    return {
        "source_id": repo_path.name,
        "source_path": str(repo_path),
        "source_type": "package_source" if repo_path.parent.name == "package-sources" else "repo",
        "candidate_file_count": len(candidate_files),
        "candidate_files": candidate_files,
    }


def scan_study_library(study_library: Path, *, limit_per_repo: int = 40) -> dict[str, object]:
    repositories = [scan_repository(repo_path, limit_per_repo=limit_per_repo) for repo_path in _iter_repositories(study_library)]
    return {
        "schema_version": "v1",
        "resource_id": "critical_compass.mcp_study_library_scan.v1",
        "scanned_at": datetime.now(timezone.utc).isoformat(),
        "study_library_path": str(study_library),
        "repository_count": len(repositories),
        "repositories": repositories,
        "guardrails": [
            "Scanner output is candidate evidence only.",
            "Do not import, install, execute, or call studied MCP repos from scanner output.",
            "Rewrite any adopted guidance in original Critical Compass language.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan the local MCP study library for soft-learning candidate files.")
    parser.add_argument("--study-library", default=str(DEFAULT_STUDY_LIBRARY), help="Path to the local MCP study library.")
    parser.add_argument("--limit-per-repo", type=int, default=40, help="Maximum candidate files to report per repo.")
    parser.add_argument("--output", help="Optional path to write the JSON scan. Defaults to stdout.")
    args = parser.parse_args()

    payload = scan_study_library(Path(args.study_library), limit_per_repo=max(args.limit_per_repo, 1))
    output = json.dumps(payload, indent=2, sort_keys=True)
    if args.output:
        Path(args.output).write_text(output + "\n", encoding="utf-8")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
