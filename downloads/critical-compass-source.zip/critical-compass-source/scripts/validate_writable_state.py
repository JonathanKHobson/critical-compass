#!/usr/bin/env python3
"""Validate Critical Compass writable state tools against a temporary state DB."""

from __future__ import annotations

import tempfile
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SAMPLE_TEXT = (
    "Our community report argues that the agency must change intake rules because families define safety "
    "as staying near kin and school networks."
)


def main() -> None:
    sys.path.insert(0, str(ROOT))
    if "audit_report" not in sys.modules:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.generate_audit_artifact_viewer = lambda *_args, **_kwargs: {"status": "not_run", "viewer_path": None}
        audit_report_module.generate_audit_report = lambda *_args, **_kwargs: {"qa_status": "not_run", "report_path": None}
        audit_report_module.prepare_audit_source = lambda *_args, **_kwargs: {"status": "not_run", "text": ""}
        sys.modules["audit_report"] = audit_report_module
    if "mcp.server.fastmcp" not in sys.modules:
        mcp = types.ModuleType("mcp")
        server_module = types.ModuleType("mcp.server")
        fastmcp_module = types.ModuleType("mcp.server.fastmcp")
        types_module = types.ModuleType("mcp.types")

        class FakeFastMCP:
            def __init__(self, *_args, **_kwargs):
                pass

            def tool(self, *_args, **_kwargs):
                def decorator(func):
                    return func

                return decorator

        class FakeToolAnnotations:
            def __init__(self, **kwargs):
                self.kwargs = kwargs

        fastmcp_module.FastMCP = FakeFastMCP
        types_module.ToolAnnotations = FakeToolAnnotations
        sys.modules["mcp"] = mcp
        sys.modules["mcp.server"] = server_module
        sys.modules["mcp.server.fastmcp"] = fastmcp_module
        sys.modules["mcp.types"] = types_module
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        DEFAULT_DB_PATH,
        Repository,
        StateStore,
        audit_text_payload,
        canonical_duplicate_candidates,
    )

    temp_root = Path(tempfile.mkdtemp(prefix="critical-compass-state-"))
    state = StateStore(temp_root / "state.sqlite", temp_root / "user-additions.pack.json")
    repo = Repository(DEFAULT_DB_PATH)

    audit = audit_text_payload(
        repo,
        SAMPLE_TEXT,
        text_type="advocacy",
        snapshot_mode="organizer",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    progress = state.save_audit_progress(
        subject_text=SAMPLE_TEXT,
        text_type="advocacy",
        stage="agent_definition",
        resume_from="independent_analysis",
        progress_payload={"agents": [{"name": "Methodologist"}]},
        cis_revision_event={
            "stage": "agent_definition",
            "prior_label": "Strong Integrity",
            "prior_points": 78,
            "new_label": "Moderate Integrity",
            "new_points": 72,
            "prior_confidence": "high",
            "new_confidence": "medium",
            "comparability": "qualified",
            "reason": "Checkpoint test revision.",
            "evidence_ref": "agents[0]",
        },
        notes="checkpoint",
    )
    loaded = state.get_audit_progress(progress["audit_id"])
    assert loaded["found"]
    assert loaded["prior_stage_payload"]["agents"][0]["name"] == "Methodologist"
    timeline = state.get_cis_revision_timeline(progress["audit_id"])
    assert timeline["revision_event_count"] == 1
    assert timeline["timeline"][0]["flags"]["confidence_dropped"]
    assert timeline["timeline"][0]["flags"]["score_revised_downward"]

    result = state.save_audit_result(
        subject_text=SAMPLE_TEXT,
        audit_id=progress["audit_id"],
        text_type="advocacy",
        critical_integrity_snapshot=audit["critical_integrity_snapshot"],
        biases_found=audit["bias_map"],
        verdict={"verdict": "test"},
        replication_readiness=audit["replication_readiness"],
        result_payload=audit,
        knowledge_tradition="testimonial",
    )
    assert result["saved"]
    assert result["rhetorical_tradition"] == "testimonial"
    assert state.list_audit_results(text_type="advocacy", cis_score_below=100)["count"] == 1
    assert state.list_audit_results(dimension_name="Framing & Audience Openness", dimension_score_below=21)["count"] == 1

    pattern = state.save_entity_pattern(
        entity_type="bias",
        entity_id="ct:biases:ai:framing-effect",
        text_type="advocacy",
        frequency=2,
        context_note="framing appeared twice",
    )
    assert pattern["pattern"]["frequency"] == 2
    assert state.get_pattern_summary(entity_type="bias", text_type="advocacy")["count"] == 1

    exact, _ = canonical_duplicate_candidates(repo, "Confirmation bias", [], category="biases")
    assert exact

    addition = state.save_kb_addition(
        payload={
            "title": "Community Consent Blind Spot",
            "definition": "A test addition for writable-state validation.",
            "category": "biases",
            "kind": "bias",
            "aliases": ["consent blind spot"],
            "rhetorical_tradition": "testimonial",
        },
        status="active",
        confirm_active=False,
    )
    assert addition["status"] == "draft"
    assert state.lookup_kb_addition("Community Consent Blind Spot", category="biases") is None
    assert state.update_kb_addition(addition["addition_id"], status="active", confirm_active=True)["status"] == "active"
    assert state.lookup_kb_addition("Community Consent Blind Spot", category="biases")
    assert state.soft_delete_kb_addition(addition["addition_id"])["deleted"]
    assert state.lookup_kb_addition("Community Consent Blind Spot", category="biases") is None

    print("writable state validation ok")
    print(f"temp state db: {temp_root / 'state.sqlite'}")


if __name__ == "__main__":
    main()
