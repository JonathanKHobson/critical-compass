#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import json
import sys
import types
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CASES_PATH = ROOT / "support" / "evals" / "beta_audit_cases.json"
OUTPUT_DIR = ROOT / "reports" / "beta-calibration"
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def install_fake_mcp_modules() -> None:
    if "mcp.server.fastmcp" in sys.modules:
        return
    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def ensure_real_audit_report_package() -> None:
    module = sys.modules.get("audit_report")
    if module is not None and not hasattr(module, "__path__"):
        del sys.modules["audit_report"]
        importlib.invalidate_caches()


def load_cases(path: Path = CASES_PATH) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return [item for item in data.get("cases", []) if isinstance(item, dict)]


def _ids(items: Any) -> set[str]:
    values: set[str] = set()
    if not isinstance(items, list):
        return values
    for item in items:
        if isinstance(item, dict) and item.get("id"):
            values.add(str(item["id"]))
    return values


def _norm_label(value: Any) -> str:
    return " ".join(str(value or "").lower().replace(":", " ").replace("_", " ").replace("-", " ").split())


def _lens_family_from_id(value: Any) -> str:
    text = _norm_label(value)
    if any(term in text for term in ["indigenous", "ocap", "care indigenous", "food sovereignty", "data erasure", "misclassification", "relational accountability"]):
        return "indigenous_data_governance"
    if any(term in text for term in ["community led", "stakeholder harm", "harm benefit", "service design", "missing voice", "frontstage", "backstage"]):
        return "community_power"
    if any(term in text for term in ["ethical data stewardship", "data trust", "community irb", "data governance", "ai governance"]):
        return "data_governance"
    if any(term in text for term in ["construct validity", "external validity", "internal validity", "replicability", "sampling", "generalizability", "reproducibility"]):
        return "methodology_validity"
    if any(term in text for term in ["argument mapping", "ladder of inference", "steelman", "argument from expert opinion"]):
        return "argumentation"
    return "general_lens"


def _selected_lens_families(result: dict[str, Any]) -> dict[str, str]:
    families: dict[str, str] = {}
    for card in result.get("selected_lens_cards") or []:
        if isinstance(card, dict) and card.get("lens_id"):
            lens_id = str(card["lens_id"])
            families[lens_id] = str(card.get("lens_family") or _lens_family_from_id(lens_id))
    for lens_id in result.get("selected_lens_ids") or []:
        if lens_id:
            families.setdefault(str(lens_id), _lens_family_from_id(lens_id))
    return families


def _before_use_quality(value: Any) -> dict[str, Any]:
    text = str(value or "").strip()
    lowered = " ".join(text.lower().rstrip(".!? ").split())
    bad_endings = [
        "about moved",
        "about answer",
        "about capacity",
        "about coach",
        "about example",
        "about district",
        "about equity",
        "about preregistered",
        "about framework",
    ]
    issues = []
    if not lowered.startswith("before using this text,"):
        issues.append("missing_required_prefix")
    for ending in bad_endings:
        if lowered.endswith(ending):
            issues.append(f"fragmented_keyword_ending:{ending}")
    return {"passed": not issues, "issues": issues, "text": text}


def _audit_labels(result: dict[str, Any], trap_ids: set[str], trigger_ids: set[str]) -> set[str]:
    labels = set(trap_ids) | set(trigger_ids)
    for item in result.get("bias_map") or []:
        if isinstance(item, dict):
            for key in ("bias_id", "id", "bias_name", "name", "title"):
                value = item.get(key)
                if value:
                    labels.add(str(value))
    for item in result.get("alternative_frames") or []:
        if isinstance(item, dict):
            for key in ("id", "name", "frame"):
                value = item.get(key)
                if value:
                    labels.add(str(value))
    for item in result.get("selected_lens_ids") or []:
        if item:
            labels.add(str(item))
    return {_norm_label(label) for label in labels if _norm_label(label)}


def _cis_range_result(result: dict[str, Any], expected_range: Any) -> dict[str, Any]:
    if not (isinstance(expected_range, list) and len(expected_range) == 2):
        return {"checked": False, "passed": None, "expected": None, "actual": None}
    snapshot = result.get("critical_integrity_snapshot") if isinstance(result.get("critical_integrity_snapshot"), dict) else {}
    points = snapshot.get("points")
    try:
        actual = int(points)
        low = int(expected_range[0])
        high = int(expected_range[1])
    except (TypeError, ValueError):
        return {"checked": True, "passed": False, "expected": expected_range, "actual": points}
    return {"checked": True, "passed": low <= actual <= high, "expected": expected_range, "actual": actual}


def _readiness_misses(audit_result: dict[str, Any]) -> list[str]:
    ensure_real_audit_report_package()
    from audit_report.normalize import normalize_audit_data, normalize_options
    from audit_report.readiness import assess_report_readiness

    payload = normalize_audit_data(audit_result, normalize_options(audit_result))
    readiness = assess_report_readiness(payload)
    return sorted({str(item.get("field")) for item in readiness.get("missing_report_fields", []) if isinstance(item, dict)})


def _factcheck_framing_result(case: dict[str, Any]) -> dict[str, Any]:
    claims = case.get("factcheck_claims")
    if not isinstance(claims, list) or not claims:
        return {
            "claim_count": 0,
            "framing": [],
            "caution_codes": [],
            "missing_expected_cautions": [],
            "domain_mismatches": [],
        }
    from factcheck.tool import factcheck_lookup  # pylint: disable=import-outside-toplevel

    result = factcheck_lookup(claims)
    caution_codes = sorted({str(item.get("code")) for item in result.get("cautions", []) if isinstance(item, dict) and item.get("code")})
    framing = result.get("epistemic_framing") if isinstance(result.get("epistemic_framing"), list) else []
    expected_cautions = set(case.get("expected_factcheck_cautions") or [])
    expected_domains = case.get("expected_factcheck_domains") if isinstance(case.get("expected_factcheck_domains"), dict) else {}
    by_id = {str(item.get("claim_id")): item for item in framing if isinstance(item, dict)}
    domain_mismatches = []
    for claim_id, expected_domain in expected_domains.items():
        actual = by_id.get(str(claim_id), {}).get("domain")
        if actual != expected_domain:
            domain_mismatches.append({"claim_id": claim_id, "expected": expected_domain, "actual": actual})
    return {
        "claim_count": len(claims),
        "framing": framing,
        "caution_codes": caution_codes,
        "missing_expected_cautions": sorted(expected_cautions - set(caution_codes)),
        "domain_mismatches": domain_mismatches,
    }


def run_calibration(cases_path: Path = CASES_PATH, output_dir: Path = OUTPUT_DIR) -> dict[str, Any]:
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    ensure_real_audit_report_package()

    from server import Repository, audit_text_payload  # pylint: disable=import-error,import-outside-toplevel

    cases = load_cases(cases_path)
    repo = Repository(DB_PATH)
    rows: list[dict[str, Any]] = []
    try:
        for case in cases:
            result = audit_text_payload(
                repo,
                str(case.get("text") or ""),
                text_type=str(case.get("text_type") or "general"),
                human_loop_mode="silent",
                human_loop_state={"noninteractive_smoke_test": True},
                depth="standard",
            )
            trap_ids = _ids(result.get("reasoning_traps"))
            trigger_ids = _ids(result.get("human_loop_interruption_triggers"))
            expected_traps = set(case.get("expected_traps") or [])
            expected_triggers = set(case.get("expected_triggers") or [])
            expected_absent = set(case.get("expected_absent_traps") or [])
            output_labels = _audit_labels(result, trap_ids, trigger_ids)
            expected_findings = {_norm_label(item) for item in case.get("expected_findings") or []}
            expected_non_findings = {_norm_label(item) for item in case.get("expected_non_findings") or []}
            expected_lens_ids = {str(item) for item in case.get("expected_lens_ids") or []}
            selected_lens_ids = {str(item) for item in result.get("selected_lens_ids") or []}
            selected_lens_families = _selected_lens_families(result)
            forbidden_lens_ids = {str(item) for item in case.get("forbidden_lens_ids") or []}
            forbidden_lens_families = {str(item) for item in case.get("forbidden_lens_families") or []}
            forbidden_traps = {str(item) for item in case.get("forbidden_traps") or []}
            max_selected_lens_count = case.get("max_selected_lens_count")
            forbidden_lens_violations = sorted(forbidden_lens_ids & selected_lens_ids)
            forbidden_lens_family_violations = sorted(
                lens_id
                for lens_id, family in selected_lens_families.items()
                if family in forbidden_lens_families
            )
            max_lens_count_exceeded = (
                isinstance(max_selected_lens_count, int)
                and len(selected_lens_ids) > max_selected_lens_count
            )
            cis_range = _cis_range_result(result, case.get("acceptable_cis_range"))
            factcheck_framing = _factcheck_framing_result(case)
            readiness_misses = _readiness_misses(result)
            report_requested = bool(case.get("report_requested"))
            before_use_quality = _before_use_quality(result.get("critical_integrity_snapshot", {}).get("before_using_this_text"))
            rows.append(
                {
                    "id": case.get("id"),
                    "text_type": case.get("text_type"),
                    "status": result.get("status"),
                    "trap_ids": sorted(trap_ids),
                    "trigger_ids": sorted(trigger_ids),
                    "expected_traps": sorted(expected_traps),
                    "expected_triggers": sorted(expected_triggers),
                    "missing_expected_traps": sorted(expected_traps - trap_ids),
                    "missing_expected_triggers": sorted(expected_triggers - trigger_ids),
                    "unexpected_absent_traps_present": sorted(expected_absent & trap_ids),
                    "expected_findings": sorted(expected_findings),
                    "missing_expected_findings": sorted(expected_findings - output_labels),
                    "expected_non_findings": sorted(expected_non_findings),
                    "expected_non_finding_violations": sorted(expected_non_findings & output_labels),
                    "expected_lens_ids": sorted(expected_lens_ids),
                    "selected_lens_ids": sorted(selected_lens_ids),
                    "selected_lens_families": selected_lens_families,
                    "missing_expected_lens_ids": sorted(expected_lens_ids - selected_lens_ids),
                    "forbidden_lens_ids": sorted(forbidden_lens_ids),
                    "forbidden_lens_families": sorted(forbidden_lens_families),
                    "forbidden_lens_violations": forbidden_lens_violations,
                    "forbidden_lens_family_violations": forbidden_lens_family_violations,
                    "irrelevant_lens_count": len(set(forbidden_lens_violations) | set(forbidden_lens_family_violations)),
                    "max_selected_lens_count": max_selected_lens_count,
                    "max_lens_count_exceeded": max_lens_count_exceeded,
                    "forbidden_traps": sorted(forbidden_traps),
                    "forbidden_trap_violations": sorted(forbidden_traps & trap_ids),
                    "cis_range": cis_range,
                    "fairness_to_text": result.get("fairness_to_text"),
                    "factcheck_framing": factcheck_framing,
                    "report_requested": report_requested,
                    "report_readiness_misses": readiness_misses,
                    "report_readiness_blockers": readiness_misses if report_requested else [],
                    "plain_language_read": result.get("critical_integrity_snapshot", {}).get("plain_language_read"),
                    "before_using_this_text": result.get("critical_integrity_snapshot", {}).get("before_using_this_text"),
                    "before_use_quality": before_use_quality,
                }
            )
    finally:
        repo.close()

    blocking = [
        row
        for row in rows
        if row["missing_expected_traps"]
        or row["missing_expected_triggers"]
        or row["unexpected_absent_traps_present"]
        or row["missing_expected_findings"]
        or row["expected_non_finding_violations"]
        or row["missing_expected_lens_ids"]
        or row["forbidden_lens_violations"]
        or row["forbidden_lens_family_violations"]
        or row["max_lens_count_exceeded"]
        or row["forbidden_trap_violations"]
        or not row["before_use_quality"]["passed"]
        or row["report_readiness_blockers"]
        or (row["cis_range"]["checked"] and not row["cis_range"]["passed"])
        or row["factcheck_framing"]["missing_expected_cautions"]
        or row["factcheck_framing"]["domain_mismatches"]
    ]
    expected_finding_total = sum(len(row["expected_findings"]) for row in rows)
    expected_finding_hits = sum(len(row["expected_findings"]) - len(row["missing_expected_findings"]) for row in rows)
    non_finding_total = sum(len(row["expected_non_findings"]) for row in rows)
    non_finding_violations = sum(len(row["expected_non_finding_violations"]) for row in rows)
    expected_lens_total = sum(len(row["expected_lens_ids"]) for row in rows)
    expected_lens_hits = sum(len(row["expected_lens_ids"]) - len(row["missing_expected_lens_ids"]) for row in rows)
    selected_lens_total = sum(len(row["selected_lens_ids"]) for row in rows)
    irrelevant_lens_total = sum(int(row["irrelevant_lens_count"]) for row in rows)
    forbidden_lens_violations = sum(len(row["forbidden_lens_violations"]) + len(row["forbidden_lens_family_violations"]) for row in rows)
    unexpected_trap_count = sum(len(row["unexpected_absent_traps_present"]) + len(row["forbidden_trap_violations"]) for row in rows)
    before_use_checked = len(rows)
    before_use_passed = sum(1 for row in rows if row["before_use_quality"]["passed"])
    report_readiness_blocker_count = sum(len(row["report_readiness_blockers"]) for row in rows)
    cis_checked = sum(1 for row in rows if row["cis_range"]["checked"])
    cis_passed = sum(1 for row in rows if row["cis_range"]["checked"] and row["cis_range"]["passed"])
    precision_denominator = expected_finding_hits + non_finding_violations
    metrics = {
        "precision": round(expected_finding_hits / precision_denominator, 3) if precision_denominator else 1.0,
        "recall": round(expected_finding_hits / expected_finding_total, 3) if expected_finding_total else 1.0,
        "false_positive_rate": round(non_finding_violations / non_finding_total, 3) if non_finding_total else 0.0,
        "expected_non_finding_violations": non_finding_violations,
        "lens_retrieval_hit_rate": round(expected_lens_hits / expected_lens_total, 3) if expected_lens_total else 1.0,
        "lens_precision_at_k": round((selected_lens_total - irrelevant_lens_total) / selected_lens_total, 3) if selected_lens_total else 1.0,
        "irrelevant_lens_count": irrelevant_lens_total,
        "forbidden_lens_violations": forbidden_lens_violations,
        "unexpected_trap_count": unexpected_trap_count,
        "before_use_quality_pass_rate": round(before_use_passed / before_use_checked, 3) if before_use_checked else 1.0,
        "report_readiness_blocker_count": report_readiness_blocker_count,
        "cis_range_pass_rate": round(cis_passed / cis_checked, 3) if cis_checked else 1.0,
        "expected_finding_total": expected_finding_total,
        "expected_lens_total": expected_lens_total,
        "selected_lens_total": selected_lens_total,
    }
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    output_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "status": "passed" if not blocking else "needs_review",
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "case_count": len(rows),
        "blocking_count": len(blocking),
        "metrics": metrics,
        "rows": rows,
        "notes": [
            "This calibration harness uses local fixture texts only.",
            "Fact-check framing rows exercise scaffold-first epistemic cautions without live retrieval.",
            "Report-readiness misses are blockers only for cases marked report_requested=true.",
            "Check-worthy and trap outputs are advisory and must not be treated as truth verdicts.",
            "Beta.9 metrics include expected non-findings, forbidden lenses/traps, lens precision, before-use quality, and CIS range pass rate so calibration can catch over-critique as well as missed critique.",
        ],
    }
    json_path = output_dir / f"beta-audit-calibration-{timestamp}.json"
    md_path = output_dir / f"beta-audit-calibration-{timestamp}.md"
    json_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    md_lines = [
        "# Critical Compass Beta Audit Calibration",
        "",
        f"Status: {report['status']}",
        f"Cases: {len(rows)}",
        f"Needs review: {len(blocking)}",
        "",
        "| Case | Traps | Triggers | Misses | Lens IDs | CIS range | Fact-check framing | Report-readiness fields |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        misses = (
            row["missing_expected_traps"]
            + row["missing_expected_triggers"]
            + row["unexpected_absent_traps_present"]
            + row["missing_expected_findings"]
            + row["expected_non_finding_violations"]
            + row["missing_expected_lens_ids"]
            + row["forbidden_lens_violations"]
            + row["forbidden_lens_family_violations"]
            + row["forbidden_trap_violations"]
            + row["before_use_quality"]["issues"]
            + row["report_readiness_blockers"]
        )
        framing_misses = row["factcheck_framing"]["missing_expected_cautions"] + [
            f"{item['claim_id']}:{item['expected']}!={item['actual']}" for item in row["factcheck_framing"]["domain_mismatches"]
        ]
        md_lines.append(
            "| {case} | {traps} | {triggers} | {misses} | {lens} | {cis} | {framing} | {readiness} |".format(
                case=row["id"],
                traps=", ".join(row["trap_ids"]) or "none",
                triggers=", ".join(row["trigger_ids"]) or "none",
                misses=", ".join(misses) or "none",
                lens=", ".join(row["selected_lens_ids"]) or "none",
                cis=(
                    "unchecked"
                    if not row["cis_range"]["checked"]
                    else f"{row['cis_range']['actual']} in {row['cis_range']['expected']}: {row['cis_range']['passed']}"
                ),
                framing=", ".join(framing_misses) or f"{row['factcheck_framing']['claim_count']} claims",
                readiness=", ".join(row["report_readiness_misses"]) or "none",
            )
        )
    md_path.write_text("\n".join(md_lines) + "\n", encoding="utf-8")
    report["json_path"] = str(json_path.resolve())
    report["markdown_path"] = str(md_path.resolve())
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run local Critical Compass beta audit calibration cases.")
    parser.add_argument(
        "--cases",
        type=Path,
        default=CASES_PATH,
        help="Path to a JSON file with a top-level cases array. Defaults to support/evals/beta_audit_cases.json.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help="Directory for calibration JSON/Markdown output. Defaults to reports/beta-calibration.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    report = run_calibration(cases_path=args.cases.expanduser().resolve(), output_dir=args.output_dir.expanduser().resolve())
    print(json.dumps({k: report[k] for k in ["status", "case_count", "blocking_count", "json_path", "markdown_path"]}, indent=2))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
