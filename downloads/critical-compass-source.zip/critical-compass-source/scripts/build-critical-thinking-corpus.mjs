import fs from "fs";
import path from "path";
import vm from "vm";

const ROOT = "/Volumes/KyleSSD/CriticalThinking";
const OUT = "/Volumes/KyleSSD/CriticalThinking";

const SOURCE_ROOTS = {
  raw: path.join(ROOT, "incoming/raw/source-critical-thinker-biases-data"),
  glossaryJs: path.join(ROOT, "incoming/raw/source-glossary-js"),
  glossary: path.join(ROOT, "incoming/raw/database/glossary"),
  patterns: path.join(ROOT, "incoming/raw/database/patterns"),
  tasks: path.join(ROOT, "incoming/raw/database/tasks"),
  library: path.join(ROOT, "support/library"),
  taxonomy: path.join(ROOT, "support/taxonomy"),
  exports: path.join(ROOT, "incoming/raw/source-exports")
};

const FILE_SELECT_RE = /bias|reason|thinking|heuristic|fallacy|framework|socratic|first-principles|analogical|abductive|deductive|inductive|causal|argument|logic|decision|reflect|dialectic|systems|divergent|design|counterfactual|calibration|probabilistic|bayesian|pre-mortem|premortem|red-team|postmortem|synthesis|critical|heuristics-biases|evaluation|debias|metacog|overconfidence|prompt|fairness|rubric|check|audit|reconcil|truth|uncertainty|confidence|hallucination|transcript|research|synthesize/i;

const RAW_RELEVANT_EXTS = new Set([".js", ".json", ".html", ".txt", ".md", ".yaml", ".yml"]);

const SOURCE_JS_FILES = [
  path.join(SOURCE_ROOTS.glossaryJs, "glossary.data.js"),
  path.join(SOURCE_ROOTS.glossaryJs, "templates.data.js"),
  path.join(SOURCE_ROOTS.glossaryJs, "templates.tasks.data.js"),
  path.join(SOURCE_ROOTS.glossaryJs, "biases.data.js"),
  path.join(SOURCE_ROOTS.glossaryJs, "persona.data.js")
];

const SOURCE_EXPORT_FILES = [
  path.join(SOURCE_ROOTS.exports, "templates.json"),
  path.join(SOURCE_ROOTS.exports, "database/templates.json")
];

const SUPPORT_FILES = [
  "support/library/library.metadata.json",
  "support/library/library.records.json",
  "support/library/critical-compass.additions.json",
  "support/library/non-western-epistemologies.pack.json",
  "support/library/phase2-step1-gaps.pack.json",
  "support/library/advanced-audit-mvp-coverage.pack.json",
  "support/library/library.records.schema.json",
  "support/reasoning-flows/reasoning-flow.schema.json",
  "support/reasoning-flows/advanced-audit.spec.md",
  "incoming/raw/source-exports/root-templates.json",
  "incoming/raw/source-exports/database-templates.json",
  "support/taxonomy/aliases.yaml",
  "support/taxonomy/categories_proposal.md",
  "support/taxonomy/categories_proposal.yaml",
  "support/taxonomy/categories_taxonomy-reference.md",
  "support/taxonomy/discovery.report.md",
  "support/taxonomy/kind_taxonomy-reference.md",
  "support/taxonomy/tags_proposal.md",
  "support/taxonomy/tags_registry.yml",
  "support/taxonomy/taxonomy-reference_tags-only.md",
  "support/taxonomy/patterns/categories_key.yml",
  "support/taxonomy/patterns/categories_registry.yml",
  "support/taxonomy/patterns/full_taxonomy-templates.yml",
  "support/taxonomy/patterns/kind_registry.yml",
  "support/taxonomy/patterns/tags_registry.yml",
  "support/taxonomy/tasks/categories_registry.yml",
  "support/taxonomy/tasks/tags_registry.yml",
  "support/taxonomy/tasks/taxonomy.yml",
  "support/taxonomy/terms/taxonomy-glossary.yml"
];

const HTML_SOURCE_ROOTS = [
  SOURCE_ROOTS.glossary,
  SOURCE_ROOTS.patterns,
  SOURCE_ROOTS.tasks
];

const SOURCE_PRIORITY = {
  biasCollection: 0,
  pattern: 1,
  task: 2,
  glossary: 3,
  txt: 4,
  persona: 5
};

const OTHER_SUBDOMAIN_PRIORITY = [
  "paradoxes",
  "prompting",
  "decision-cases",
  "social-dynamics",
  "ai-governance",
  "adjacent"
];

const STANDALONE_LIBRARY_PHASES = new Set([
  "phase2-step1-gaps",
  "advanced-audit-mvp-coverage"
]);

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function exists(filePath) {
  try {
    fs.accessSync(filePath, fs.constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function isSidecar(name) {
  return name === ".DS_Store" || name.startsWith("._");
}

function slugify(input) {
  return String(input)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-{2,}/g, "-");
}

function titleCaseFromSlug(slug) {
  return String(slug)
    .split("-")
    .filter(Boolean)
    .map((part) => {
      if (/^\d+$/.test(part)) return part;
      return part.charAt(0).toUpperCase() + part.slice(1);
    })
    .join(" ");
}

function stripHtml(input) {
  return String(input)
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/\s+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}

function trimText(input) {
  return String(input || "").replace(/\s+/g, " ").trim();
}

function csvEscape(value) {
  const str = value == null ? "" : String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function uniqueStrings(values) {
  return [...new Set((values || []).map((value) => trimText(value)).filter(Boolean))];
}

function normalizedBlob(meta) {
  return [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

function tagBlob(meta) {
  return uniqueStrings(meta.tags || [])
    .join(" ")
    .toLowerCase();
}

function confidenceForRecord(normalized) {
  let confidence = normalized.category === "other" ? 0.7 : 0.92;
  if (normalized.category === "other" && normalized.subcategory === "adjacent") confidence = 0.45;
  if (normalized.category === "other" && normalized.subcategory === "legacy") confidence = 0.6;
  if (normalized.category === "other" && normalized.subcategory === "transcripts") confidence = 0.58;
  if (normalized.kind === "transcript") confidence = Math.min(confidence, 0.58);
  if (normalized.kind === "note") confidence = Math.min(confidence, 0.6);
  if ((normalized.quality_flags || []).some((flag) => flag.severity === "warning")) confidence -= 0.12;
  if ((normalized.quality_flags || []).some((flag) => flag.code === "ambiguous-routing")) confidence -= 0.08;
  return Number(Math.max(0.1, Math.min(0.99, confidence)).toFixed(2));
}

function otherRouting(meta) {
  const blob = normalizedBlob(meta);
  const tags = tagBlob(meta);
  const promptHints = [
    "prompt",
    "context",
    "meta-prompt",
    "self-discover",
    "continuous prompts",
    "constraint prompting",
    "contextual prompter",
    "detailed prompter",
    "explorative prompter",
    "expansion prompting",
    "parallel prompting",
    "prompt architect",
    "prompt architecture",
    "master prompts",
    "mega-prompt",
    "indirect prompt injection"
  ];
  const decisionHints = [
    "decision",
    "tradeoff",
    "trade-off",
    "dilemma",
    "choice",
    "choices",
    "trolley",
    "weighted",
    "matrix",
    "versus",
    "vs ",
    "vs.",
    "end-of-life",
    "autonomy",
    "beneficence",
    "double effect",
    "whistleblowing",
    "privacy vs security",
    "free speech vs harm",
    "environment vs economic development",
    "resource allocation",
    "ethical consumerism",
    "moral luck",
    "omelas",
    "consent",
    "fairness",
    "kill criteria",
    "dissent"
  ];
  const socialHints = [
    "social",
    "community",
    "group",
    "culture",
    "communication",
    "status",
    "authority",
    "power",
    "radicalization",
    "echo chamber",
    "incentive",
    "norm",
    "trust",
    "conflict",
    "representation",
    "inclusion",
    "equity",
    "voice",
    "coordination",
    "leadership",
    "emotion",
    "ei framework",
    "competing values",
    "truth & reconciliation",
    "truth reconciliation",
    "bias suppression",
    "persuasion"
  ];
  const aiGovernanceHints = [
    "ai",
    "llm",
    "model",
    "training data",
    "data privacy",
    "privacy",
    "consent",
    "accountability",
    "responsibility",
    "moderation",
    "safety",
    "alignment",
    "transparency",
    "fairness",
    "bias amplification",
    "governance",
    "ethic",
    "policy",
    "copyright",
    "licensing",
    "surveillance",
    "human oversight",
    "accessibility",
    "inclusivity",
    "misinformation",
    "manipulation",
    "ethical drift",
    "model misuse",
    "dual use",
    "disclosure",
    "interpretability",
    "trust",
    "economic disparity",
    "responsibility for model actions"
  ];
  const paradoxHints = [
    "paradox",
    "impossibility",
    "puzzle",
    "backward-induction",
    "bootstrap",
    "bertrand",
    "braess",
    "arrow",
    "allais",
    "condorcet",
    "curry",
    "banach",
    "borel",
    "drinker",
    "ellsberg",
    "godel",
    "sorites",
    "berkson",
    "birthday",
    "coastline",
    "bell",
    "black hole",
    "boltzmann",
    "buridan",
    "burali",
    "ehrenfest",
    "galton",
    "newcomb",
    "unexpected hanging",
    "three prisoners",
    "alabama",
    "berry",
    "barber",
    "bilking",
    "athletes",
    "cantor",
    "c-value",
    "crocodile",
    "doomsday",
    "st petersburg",
    "fitch",
    "gettier",
    "gibbs",
    "giffen",
    "friendship paradox",
    "goodhart",
    "goodman",
    "gibson",
    "gibbard",
    "frauchiger",
    "fermi",
    "el farol"
  ];

  if (tags.includes("class:paradox") || hasAny(blob, paradoxHints) || /class:paradox/.test(tags)) {
    return {
      subfolder: "paradoxes",
      routeReason: "paradox signal or paradox class tag",
      confidenceBias: 0.95
    };
  }
  if (tags.includes("phase:prompting") || tags.includes("topic:prompt") || hasAny(blob, promptHints)) {
    return {
      subfolder: "prompting",
      routeReason: "prompting signal or prompt-related tag",
      confidenceBias: 0.9
    };
  }
  if (tags.includes("type:dilemma") || tags.includes("topic:decision") || tags.includes("class:ethics") && hasAny(blob, decisionHints)) {
    return {
      subfolder: "decision-cases",
      routeReason: "decision/dilemma signal or ethics tradeoff",
      confidenceBias: 0.88
    };
  }
  if (tags.includes("domain:social") || tags.includes("domain:social-choice") || hasAny(blob, socialHints)) {
    return {
      subfolder: "social-dynamics",
      routeReason: "social, communication, or coordination signal",
      confidenceBias: 0.84
    };
  }
  if (tags.includes("class:ethics") || tags.includes("topic:ai") || hasAny(blob, aiGovernanceHints)) {
    return {
      subfolder: "ai-governance",
      routeReason: "AI governance / ethics signal",
      confidenceBias: 0.82
    };
  }

  return {
    subfolder: "adjacent",
    routeReason: "no explicit high-confidence family; left as adjacent",
    confidenceBias: 0.45
  };
}

function normalizedExtension(normalized) {
  if (normalized.category === "other" && (normalized.subcategory === "legacy" || normalized.subcategory === "transcripts")) {
    return "md";
  }
  if (normalized.kind === "transcript" || normalized.kind === "note") {
    return "md";
  }
  return "json";
}

function normalizedSections(normalized) {
  const sections = [
    { title: "When to use", items: normalized.when_to_use || [] },
    { title: "Signals", items: normalized.signals || [] },
    { title: "Failure modes", items: normalized.failure_modes || [] },
    { title: "Anti-patterns", items: normalized.anti_patterns || [] },
    { title: "Indicators", items: normalized.indicators || [] },
    { title: "Examples", items: normalized.examples || [] },
    { title: "Countermeasures", items: normalized.countermeasures || [] },
    { title: "Related", items: normalized.related || [] },
    { title: "Aliases", items: normalized.aliases || [] }
  ];
  return sections.filter((section) => Array.isArray(section.items) && section.items.length);
}

function normalizedCatalogRow(normalized, sourcePath, normalizedPath) {
  const renderFormat = path.extname(normalizedPath).slice(1).toLowerCase() || "json";
  const quality = (normalized.quality_flags || []).map((flag) => flag.code).join(",") || "clean";
  const reviewStatus = normalized.category === "other" && normalized.subcategory === "adjacent" ? "review" : (normalized.confidence ?? 0) < 0.6 ? "review" : "ready";
  return {
    entry_id: normalized.entry_id,
    title: normalized.title,
    category: normalized.category,
    subcategory: normalized.subcategory,
    kind: normalized.kind || "",
    source_path: sourcePath,
    normalized_path: normalizedPath,
    render_format: renderFormat,
    confidence: normalized.confidence ?? null,
    alias_count: (normalized.aliases || []).length,
    related_count: (normalized.related || []).length,
    quality,
    review_status: reviewStatus,
    source_type: normalized.source?.source_type || "",
    route_reason: normalized.provenance?.route_reason || ""
  };
}

function writeNormalizedArtifact(normalized, normalizedPath, rawText = "") {
  const renderFormat = path.extname(normalizedPath).slice(1).toLowerCase() || "json";
  if (renderFormat === "md") {
    if (rawText) {
      writeText(normalizedPath, textNoteToMarkdown(normalized, rawText));
      return;
    }
    writeText(normalizedPath, toMarkdownRecord(normalized, normalizedSections(normalized)));
    return;
  }
  writeJson(normalizedPath, normalized);
}

function valueFacet(value) {
  return trimText(value).toLowerCase();
}

function addFacetEntry(map, facet, value, entry) {
  const key = valueFacet(value);
  if (!key) return;
  if (!map.has(key)) {
    map.set(key, {
      key,
      facet,
      entry_ids: [],
      titles: []
    });
  }
  const bucket = map.get(key);
  bucket.entry_ids.push(entry.entry_id);
  bucket.titles.push(entry.title);
}

function buildFacetIndex(records, facet) {
  const buckets = new Map();
  for (const record of records) {
    if (facet === "use") {
      for (const value of uniqueStrings([...(record.when_to_use || []), ...((record.tags || []).filter((tag) => tag.startsWith("use:")).map((tag) => tag.slice(4))) ])) {
        addFacetEntry(buckets, facet, value, record);
      }
      continue;
    }
    if (facet === "topic") {
      for (const value of uniqueStrings((record.tags || []).filter((tag) => tag.startsWith("topic:") || tag.startsWith("domain:") || tag.startsWith("class:") || tag.startsWith("lens:")).map((tag) => tag.split(":").slice(1).join(":")))) {
        addFacetEntry(buckets, facet, value, record);
      }
      continue;
    }
    if (facet === "phase") {
      for (const value of uniqueStrings((record.tags || []).filter((tag) => tag.startsWith("phase:")).map((tag) => tag.slice(6)))) {
        addFacetEntry(buckets, facet, value, record);
      }
      continue;
    }
    if (facet === "kind") {
      const kindValue = record.kind || "unknown";
      addFacetEntry(buckets, facet, kindValue, record);
      continue;
    }
    if (facet === "category") {
      addFacetEntry(buckets, facet, record.category, record);
      addFacetEntry(buckets, facet, `${record.category}/${record.subcategory}`, record);
    }
  }

  const out = {};
  for (const [key, bucket] of [...buckets.entries()].sort((a, b) => b[1].entry_ids.length - a[1].entry_ids.length || a[0].localeCompare(b[0]))) {
    out[key] = {
      count: bucket.entry_ids.length,
      entry_ids: bucket.entry_ids,
      titles: uniqueStrings(bucket.titles).slice(0, 25)
    };
  }
  return out;
}

function buildAliasRegistry(records) {
  const aliasToEntry = {};
  const entryToAliases = {};
  const collisions = [];

  for (const record of records) {
    const aliases = uniqueStrings([
      record.title,
      record.slug,
      record.source?.source_slug,
      ...(record.aliases || []),
      slugify(record.title || ""),
      (record.title || "").toLowerCase()
    ]);
    entryToAliases[record.entry_id] = aliases;
    for (const alias of aliases) {
      const key = alias.toLowerCase();
      if (aliasToEntry[key] && aliasToEntry[key].entry_id !== record.entry_id) {
        collisions.push({
          alias: key,
          existing: aliasToEntry[key].entry_id,
          incoming: record.entry_id
        });
        continue;
      }
      aliasToEntry[key] = {
        entry_id: record.entry_id,
        title: record.title,
        category: record.category,
        subcategory: record.subcategory,
        kind: record.kind || ""
      };
    }
  }

  return {
    total_aliases: Object.keys(aliasToEntry).length,
    alias_to_entry: aliasToEntry,
    entry_to_aliases: entryToAliases,
    collisions
  };
}

function resolveRelatedReference(reference, aliasRegistry, knownIds) {
  const raw = trimText(reference);
  if (!raw) return null;
  if (knownIds.has(raw)) return raw;

  const aliasMap = aliasRegistry?.alias_to_entry || {};
  const variants = uniqueStrings([
    raw,
    raw.toLowerCase(),
    slugify(raw),
    raw.replace(/^ct:/i, ""),
    raw.replace(/^ct:/i, "").toLowerCase(),
    slugify(raw.replace(/^ct:/i, ""))
  ]);

  for (const variant of variants) {
    const hit = aliasMap[variant.toLowerCase()];
    if (hit?.entry_id && knownIds.has(hit.entry_id)) {
      return hit.entry_id;
    }
  }
  return null;
}

function buildConceptGraph(records, aliasRegistry) {
  const nodes = [];
  const edges = [];
  const seenNodeIds = new Set();
  const knownIds = new Set(records.map((record) => record.entry_id));
  const addNode = (node) => {
    if (seenNodeIds.has(node.id)) return;
    seenNodeIds.add(node.id);
    nodes.push(node);
  };
  const addEdge = (from, to, type) => {
    edges.push({ from, to, type });
  };

  for (const record of records) {
    addNode({
      id: record.entry_id,
      type: "entry",
      title: record.title,
      category: record.category,
      subcategory: record.subcategory,
      kind: record.kind || "",
      confidence: record.confidence ?? null
    });

    const categoryNodeId = `ct:category:${record.category}`;
    const subcategoryNodeId = `ct:subcategory:${record.category}:${record.subcategory}`;

    addNode({
      id: categoryNodeId,
      type: "category",
      title: record.category
    });
    addNode({
      id: subcategoryNodeId,
      type: "subcategory",
      title: record.subcategory,
      parent: categoryNodeId
    });

    addEdge(record.entry_id, subcategoryNodeId, "parent");
    addEdge(subcategoryNodeId, record.entry_id, "child");
    addEdge(subcategoryNodeId, categoryNodeId, "parent");
    addEdge(categoryNodeId, subcategoryNodeId, "child");

    for (const related of record.related || []) {
      const resolved = resolveRelatedReference(related, aliasRegistry, knownIds);
      if (resolved) {
        addEdge(record.entry_id, resolved, "see-also");
      }
    }
  }

  return {
    nodes,
    edges,
    counts: {
      nodes: nodes.length,
      edges: edges.length
    }
  };
}

function buildValidationReport(records, aliasRegistry, graph) {
  const knownIds = new Set(records.map((record) => record.entry_id));
  const invalidIds = records.filter((record) => !/^ct:[a-z-]+:[a-z-]+:[a-z0-9-]+$/.test(record.entry_id)).map((record) => ({ entry_id: record.entry_id, title: record.title }));
  const missingSource = records.filter((record) => !record.source?.original_path).map((record) => ({ entry_id: record.entry_id, title: record.title }));
  const brokenRelatedLinks = [];
  for (const record of records) {
    for (const related of record.related || []) {
      const resolved = resolveRelatedReference(related, aliasRegistry, knownIds);
      if (!resolved) {
        brokenRelatedLinks.push({ entry_id: record.entry_id, related });
      }
    }
  }

  const emptyContent = records
    .filter((record) => !trimText(record.summary) && !trimText(record.definition) && !(record.indicators || []).length && !(record.examples || []).length && !(record.countermeasures || []).length)
    .map((record) => ({ entry_id: record.entry_id, title: record.title }));

  const ambiguousRouting = records
    .filter((record) => record.category === "other" && record.subcategory === "adjacent")
    .map((record) => ({
      entry_id: record.entry_id,
      title: record.title,
      confidence: record.confidence ?? null,
      source_path: record.source?.original_path || "",
      route_reason: record.provenance?.route_reason || "adjacent"
    }));

  return {
    invalid_ids: invalidIds,
    missing_source_references: missingSource,
    broken_related_links: brokenRelatedLinks,
    empty_content: emptyContent,
    ambiguous_routing: ambiguousRouting,
    alias_collisions: aliasRegistry.collisions,
    graph_stats: graph.counts
  };
}

function writeText(filePath, content) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, content, "utf8");
}

function writeJson(filePath, data) {
  writeText(filePath, `${JSON.stringify(data, null, 2)}\n`);
}

function yamlScalar(value) {
  if (value === null || value === undefined) return "null";
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  const str = String(value);
  if (str === "") return '""';
  if (/^[A-Za-z0-9_./:-]+$/.test(str) && !/^(true|false|null|~|yes|no|on|off)$/i.test(str)) {
    return str;
  }
  return JSON.stringify(str);
}

function toYaml(value, indent = 0) {
  const pad = "  ".repeat(indent);
  if (Array.isArray(value)) {
    if (!value.length) return `${pad}[]`;
    return value
      .map((item) => {
        if (item && typeof item === "object") {
          return `${pad}-\n${toYaml(item, indent + 1)}`;
        }
        return `${pad}- ${yamlScalar(item)}`;
      })
      .join("\n");
  }
  if (value && typeof value === "object") {
    const entries = Object.entries(value);
    if (!entries.length) return `${pad}{}`;
    return entries
      .map(([key, child]) => {
        const safeKey = /^[A-Za-z0-9_./-]+$/.test(key) ? key : JSON.stringify(key);
        if (child && typeof child === "object") {
          return `${pad}${safeKey}:\n${toYaml(child, indent + 1)}`;
        }
        return `${pad}${safeKey}: ${yamlScalar(child)}`;
      })
      .join("\n");
  }
  return `${pad}${yamlScalar(value)}`;
}

function copyFile(srcPath, destPath) {
  if (path.resolve(srcPath) === path.resolve(destPath)) return;
  ensureDir(path.dirname(destPath));
  fs.copyFileSync(srcPath, destPath);
}

function listFilesRecursive(rootDir) {
  const out = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (isSidecar(entry.name)) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        out.push(full);
      }
    }
  }
  walk(rootDir);
  return out;
}

function removeNoiseFiles(rootDir) {
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
        continue;
      }
      if (entry.isFile() && isSidecar(entry.name)) {
        fs.rmSync(full, { force: true });
      }
    }
  }
  if (exists(rootDir)) {
    walk(rootDir);
  }
}

function fileKind(filePath) {
  const rel = path.relative(ROOT, filePath);
  const base = path.basename(filePath);
  if (rel.startsWith("incoming/raw/source-critical-thinker-biases-data/")) {
    if (base === "biases.data.js") return "biasCollection";
    if (base === "persona.data.js") return "persona";
    if (base.endsWith(".txt")) return "txt";
    return path.extname(base).slice(1).toLowerCase();
  }
  if (rel.startsWith("incoming/raw/source-glossary-js/")) {
    if (base === "glossary.data.js") return "glossaryJs";
    if (base === "templates.data.js") return "templatesJs";
    if (base === "templates.tasks.data.js") return "tasksJs";
    if (base === "biases.data.js") return "biasesJs";
    if (base === "persona.data.js") return "personaJs";
    return path.extname(base).slice(1).toLowerCase();
  }
  if (rel.startsWith("incoming/raw/database/glossary/")) return "glossary";
  if (rel.startsWith("incoming/raw/database/patterns/")) return "pattern";
  if (rel.startsWith("incoming/raw/database/tasks/")) return "task";
  if (rel === "incoming/raw/source-exports/root-templates.json") return "templatesExport";
  if (rel === "incoming/raw/source-exports/database-templates.json") return "templatesDatabaseExport";
  if (rel.startsWith("support/library/")) return "library";
  if (rel.startsWith("support/taxonomy/")) return "taxonomy";
  return "other";
}

function fileFormat(filePath) {
  const ext = path.extname(filePath).slice(1).toLowerCase();
  return ext || "no-ext";
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function parseJsonLd(html) {
  const match = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/i);
  if (!match) return [];
  try {
    const parsed = JSON.parse(match[1]);
    if (Array.isArray(parsed)) return parsed;
    if (parsed && typeof parsed === "object" && Array.isArray(parsed["@graph"])) {
      return parsed["@graph"];
    }
    return [parsed];
  } catch {
    return [];
  }
}

function findTitle(html) {
  const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (h1) return stripHtml(h1[1]);
  const og = html.match(/<meta property="og:title" content="([^"]+)"/i);
  if (og) return og[1].replace(/\s*\|\s*Prompt Builder$/i, "").replace(/\s*[—-]\s*glossary term$/i, "").replace(/\s*[—-]\s*template$/i, "").replace(/\s*[—-]\s*Design task$/i, "").trim();
  const title = html.match(/<title>([\s\S]*?)<\/title>/i);
  return title ? stripHtml(title[1]).replace(/\s*\|\s*Prompt Builder$/i, "").trim() : "";
}

function findMetaDescription(html) {
  const desc = html.match(/<meta name="description" content="([^"]*)"/i);
  if (desc) return trimText(desc[1]);
  const og = html.match(/<meta property="og:description" content="([^"]*)"/i);
  if (og) return trimText(og[1]);
  const ld = parseJsonLd(html);
  const candidate = ld.find((item) => typeof item?.description === "string");
  return candidate ? trimText(candidate.description) : "";
}

function listItemsFromSection(html, heading) {
  const pattern = new RegExp(`<h[23][^>]*>${heading}<\\/h[23]>\\s*<ul>([\\s\\S]*?)<\\/ul>`, "i");
  const match = html.match(pattern);
  if (!match) return [];
  const items = [];
  for (const li of match[1].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
    const text = stripHtml(li[1]);
    if (text) items.push(text);
  }
  return items;
}

function extractMainParagraph(html) {
  const body = html.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
  const scope = body ? body[1] : html;
  const paragraphs = [];
  for (const match of scope.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)) {
    const text = stripHtml(match[1]);
    if (text) paragraphs.push(text);
  }
  return paragraphs;
}

function parseHtmlSource(filePath) {
  const html = fs.readFileSync(filePath, "utf8");
  const title = findTitle(html) || titleCaseFromSlug(path.basename(filePath, path.extname(filePath)));
  const description = findMetaDescription(html);
  const paragraphs = extractMainParagraph(html);
  const ld = parseJsonLd(html);
  const creative = ld.find((item) => Array.isArray(item?.["@type"]) ? item["@type"].includes("CreativeWork") : item?.["@type"] === "CreativeWork") || {};
  const definedTerm = ld.find((item) => Array.isArray(item?.["@type"]) ? item["@type"].includes("DefinedTerm") : item?.["@type"] === "DefinedTerm") || {};
  const tags = listItemsFromSection(html, "Tags");
  const categories = listItemsFromSection(html, "Categories");
  const useCases = listItemsFromSection(html, "Use cases");
  const boosters = listItemsFromSection(html, "Boosters");
  const fields = [];
  const fieldsMatch = html.match(/<details><summary>Fields<\/summary><ul>([\s\S]*?)<\/ul><\/details>/i);
  if (fieldsMatch) {
    for (const li of fieldsMatch[1].matchAll(/<li><strong>([\s\S]*?)<\/strong>\s*—\s*<code>([\s\S]*?)<\/code><\/li>/gi)) {
      fields.push({ label: stripHtml(li[1]), type: stripHtml(li[2]) });
    }
  }

  return {
    title,
    description,
    summary: trimText(definedTerm.description || creative.description || description || paragraphs[0] || ""),
    definition: trimText(definedTerm.description || creative.description || paragraphs[0] || description || ""),
    paragraphs,
    tags,
    categories,
    useCases,
    boosters,
    fields,
    ld,
    canonicalUrl: (html.match(/<link rel="canonical" href="([^"]+)"/i) || [])[1] || "",
    sourceType: definedTerm?.["@type"] ? "glossary" : creative?.["@type"] ? "framework" : "html"
  };
}

function loadLibraryRecords() {
  const recordsPath = path.join(ROOT, "support/library/library.records.json");
  const additionsPath = path.join(ROOT, "support/library/critical-compass.additions.json");
  const records = readJson(recordsPath);
  if (exists(additionsPath)) {
    const additions = readJson(additionsPath);
    if (Array.isArray(additions)) {
      records.push(...additions);
    }
  }
  const libraryDir = path.join(ROOT, "support/library");
  for (const fileName of fs
    .readdirSync(libraryDir)
    .filter((name) => name.endsWith(".pack.json") && !name.startsWith("._") && name !== ".DS_Store")
    .sort()) {
    const packPath = path.join(libraryDir, fileName);
    const packRecords = readJson(packPath);
    if (Array.isArray(packRecords)) {
      records.push(
        ...packRecords.map((record, index) => ({
          ...record,
          __support_source_path: packPath,
          __support_source_index: index
        }))
      );
    }
  }
  const bySlug = new Map();
  for (const record of records) {
    const slug = record?.source_slug || record?.slug || record?.entry_id || record?.id;
    if (!slug) continue;
    const existing = bySlug.get(slug);
    if (!existing) {
      bySlug.set(slug, record);
      continue;
    }
    const order = { published: 0, verified: 1, draft: 2, duplicate_candidate: 3 };
    const recordIsTargetedOverride = STANDALONE_LIBRARY_PHASES.has(record?.provenance?.phase);
    const existingIsTargetedOverride = STANDALONE_LIBRARY_PHASES.has(existing?.provenance?.phase);
    if (
      (order[record.status] ?? 99) < (order[existing.status] ?? 99)
      || (recordIsTargetedOverride && !existingIsTargetedOverride)
    ) {
      bySlug.set(record.source_slug, record);
    }
  }
  return { records, bySlug };
}

function loadBiasCollection() {
  const filePath = path.join(SOURCE_ROOTS.raw, "biases.data.js");
  const text = fs.readFileSync(filePath, "utf8");
  const match = text.match(/const\s+BIASES\s*=\s*(\[[\s\S]*?\n\s*\]\s*;)/);
  if (!match) {
    throw new Error("Could not locate BIASES array in biases.data.js");
  }
  const arraySource = match[1].replace(/;\s*$/, "");
  const collection = vm.runInNewContext(`(${arraySource})`, {});
  if (!Array.isArray(collection)) {
    throw new Error("Parsed biases collection is not an array");
  }
  return collection;
}

function hasAny(text, patterns) {
  const value = String(text || "").toLowerCase();
  return patterns.some((pattern) => value.includes(pattern));
}

function subfolderForBias(entry) {
  const blob = [
    entry.id,
    entry.name,
    entry.category,
    entry.kind,
    entry.summary,
    entry.definition,
    ...(entry.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (entry.kind === "llm-bias" || hasAny(blob, ["llm", "ai", "model", "prompt", "algorithmic", "training data", "dataset", "automation", "machine learning"])) {
    return "ai";
  }
  if (hasAny(blob, ["cultural", "social", "media", "political", "law", "language", "ethics", "economics", "gender", "historical", "geographical", "ideological", "western", "popular culture"])) {
    return "cultural";
  }
  return "cognitive";
}

function categoryForBias(entry) {
  if (entry.kind === "technique") return "methodology-checks";
  if (entry.kind === "dilemma") return "other";
  return "biases";
}

function subfolderForTechnique(entry) {
  const blob = [
    entry.id,
    entry.name,
    entry.category,
    entry.summary,
    entry.definition,
    ...(entry.indicators || []),
    ...(entry.contexts || []),
    ...(entry.mitigations || []),
    ...(entry.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["red team", "red-team", "pre-mortem", "premortem", "attack", "adversarial", "failure", "stop condition"])) {
    return "red-team";
  }
  if (hasAny(blob, ["calibrat", "confidence", "probabil", "overconfidence", "uncertainty", "bayes"])) {
    return "calibration";
  }
  if (hasAny(blob, ["audit", "assessment", "review", "documentation", "evaluation", "rubric", "measure", "checklist", "synthesize", "finding", "fairness", "impact"])) {
    return "audit";
  }
  return "preflight";
}

function subfolderForReasoning(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["uncertainty", "confidence", "calibration", "probabilistic", "probability", "bayesian", "overconfidence"])) {
    return "uncertainty";
  }
  if (hasAny(blob, ["argument", "argumentation", "socratic", "mapping", "toulmin", "discourse", "debate", "counterargument", "reasoning model", "critical thinking", "logic", "syllog", "reflective reasoning", "meta-reasoning"])) {
    return "argumentation";
  }
  return "inference";
}

function subfolderForThinking(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["systems", "complex adaptive", "ecological", "viable system", "rhizomatic", "network", "cybernetic", "critical systems"])) {
    return "systems";
  }
  if (hasAny(blob, ["reflect", "reflexive", "self-discover", "mindful", "journaling", "postmortem", "truth reconciliation", "working out loud", "introspection", "metacognitive"])) {
    return "reflective";
  }
  if (hasAny(blob, ["dialectic", "naive dialecticism", "paradox", "both and", "contradiction", "tension", "dialogic"])) {
    return "dialectical";
  }
  if (hasAny(blob, ["design", "service design", "human-centered design", "inclusive design", "design science", "design justice", "double diamond"])) {
    return "design";
  }
  return "creative";
}

function subfolderForHeuristics(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["decision", "decision matrix", "head heart gut", "vroom", "rapid decision", "choice", "tradeoff", "satisfic", "rule of thumb"])) {
    return "decision";
  }
  return "judgment";
}

function subfolderForMethodology(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["red-team", "red team", "premortem", "pre-mortem", "failure", "attack", "adversarial", "stop condition"])) {
    return "red-team";
  }
  if (hasAny(blob, ["calibrat", "confidence", "probabil", "uncertainty", "overconfidence", "bayes"])) {
    return "calibration";
  }
  if (hasAny(blob, ["preflight", "mitigation", "awareness", "interrupter", "bias correction", "debias", "bias mitigation"])) {
    return "preflight";
  }
  return "audit";
}

function subfolderForFallacy(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (hasAny(blob, ["affirming the consequent", "denying the antecedent", "modus ponens", "modus tollens", "syllog", "formal"])) {
    return "formal";
  }
  return "informal";
}

function topCategoryForMeta(meta) {
  const blob = [
    meta.title,
    meta.slug,
    meta.summary,
    meta.definition,
    ...(meta.categories || []),
    ...(meta.tags || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  if (hasAny(blob, ["fallacy", "circular reasoning", "gambler"])) return "fallacies";
  if (hasAny(blob, ["heuristic", "heuristics and biases"])) return "heuristics";
  if (hasAny(blob, ["bias", "stereotype"])) {
    if (hasAny(blob, ["mitigation", "awareness", "audit", "documentation", "interrupter", "impact assessment", "assessment", "evaluation", "rubric", "checklist", "pre-mortem", "premortem", "red-team", "calibration", "confidence", "overconfidence", "truth reconciliation", "reproducibility"])) {
      return "methodology-checks";
    }
    return "biases";
  }
  if (hasAny(blob, ["socratic", "argument mapping", "argument-map", "toulmin", "probabilistic", "bayesian", "counterfactual", "inductive", "deductive", "abductive", "analogical", "causal", "reasoning", "logic", "first principles", "critical thinking", "meta-reasoning", "reflective reasoning", "morphological analysis", "quantum reasoning", "syllogistic", "interdisciplinary reasoning"])) {
    return "reasoning-frameworks";
  }
  if (hasAny(blob, ["systems", "reflect", "dialectic", "design thinking", "divergent", "lateral", "speculative", "creative", "constructivist", "sentipensar", "holistic", "rhizomatic", "biomimetic", "paradoxical", "anarchic"])) {
    return "thinking-lenses";
  }
  if (hasAny(blob, ["audit", "pre-mortem", "premortem", "red-team", "calibration", "confidence", "mitigation", "bias awareness", "bias interrupter", "bias correction", "postmortem", "checklist", "review", "synthesize", "evaluation", "rubric", "assessment", "evidence robustness", "reproducibility", "fairness"])) {
    return "methodology-checks";
  }
  return "other";
}

function subfolderForOther(meta) {
  return otherRouting(meta).subfolder;
}

function createNormalizedRecord(meta) {
  const source = meta.source || {};
  const provenance = meta.provenance || {};
  return {
    entry_id: meta.entryId,
    slug: meta.slug || meta.source?.source_slug || slugify(meta.title || meta.entryId),
    kind: meta.kind || null,
    category: meta.category,
    subcategory: meta.subcategory,
    title: meta.title,
    summary: meta.summary,
    definition: meta.definition,
    indicators: meta.indicators || [],
    examples: meta.examples || [],
    countermeasures: meta.countermeasures || [],
    related: meta.related || [],
    aliases: meta.aliases || [],
    source: meta.source,
    quality_flags: meta.qualityFlags || [],
    tags: meta.tags || [],
    categories: meta.categories || [],
    when_to_use: meta.whenToUse || [],
    failure_modes: meta.failureModes || [],
    signals: meta.signals || [],
    anti_patterns: meta.antiPatterns || [],
    confidence: meta.confidence ?? null,
    provenance: {
      ...provenance,
      source_path: source.original_path || "",
      source_type: source.source_type || "",
      source_collection: source.source_collection || "",
      source_slug: source.source_slug || "",
      source_title: source.source_title || "",
      original_index: source.original_index ?? null,
      canonical_url: source.canonical_url || "",
      library_entry_id: source.library_entry_id || "",
      duplicate_of: source.duplicate_of || null
    }
  };
}

function sourceRecord(filePath, extras = {}) {
  const rel = path.relative(ROOT, filePath);
  const base = path.basename(filePath);
  const kind = fileKind(filePath);
  const format = fileFormat(filePath);
  return {
    source_path: filePath,
    relative_path: rel,
    filename: base,
    kind,
    format,
    ...extras
  };
}

function normalizeBiasEntry(entry, sourcePath, sourceIndex) {
  const category = categoryForBias(entry);
  const slug = slugify(entry.id || entry.name);
  const otherMeta = {
    title: entry.name || titleCaseFromSlug(slug),
    slug,
    summary: trimText(entry.summary || entry.definition || ""),
    definition: trimText(entry.definition || entry.summary || ""),
    categories: entry.category ? [entry.category] : [],
    tags: Array.isArray(entry.tags) ? entry.tags : []
  };
  const otherRoute = category === "other" ? otherRouting(otherMeta) : null;
  const subcategory =
    category === "biases"
      ? subfolderForBias(entry)
      : category === "methodology-checks"
      ? subfolderForTechnique(entry)
      : otherRoute?.subfolder || "adjacent";
  const entryId = `ct:${category}:${subcategory}:${slug}`;
  const source = {
    original_path: sourcePath,
    source_type: "js",
    source_collection: "biases",
    source_slug: slug,
    source_title: entry.name || titleCaseFromSlug(slug),
    original_index: sourceIndex,
    canonical_url: "",
    source_record: "",
    duplicate_of: null
  };

  const routeReason =
    category === "biases"
      ? `bias collection -> biases/${subcategory}`
      : otherRoute?.routeReason || "bias collection dilemma -> other/adjacent";

  const qualityFlags = [];
  if (entry.kind === "dilemma" && subcategory === "adjacent") {
    qualityFlags.push({
      code: "adjacent-dilemma",
      severity: "info",
      message: "Ethical dilemma / scenario record routed to other/adjacent."
    });
  }
  if (entry.kind === "technique") {
    qualityFlags.push({
      code: "countermeasure",
      severity: "info",
      message: "Technique entry routed to methodology checks as a countermeasure scaffold."
    });
  }
  if (!entry.category) {
    qualityFlags.push({
      code: "missing-category",
      severity: "warning",
      message: "Source bias record has no category."
    });
  }
  if (category === "biases" && subcategory === "cognitive") {
    qualityFlags.push({
      code: "routed-bias-cognitive",
      severity: "info",
      message: "Bias routed to biases/cognitive."
    });
  }

  const normalized = createNormalizedRecord({
    entryId,
    kind: entry.kind || null,
    category,
    subcategory,
    title: entry.name || titleCaseFromSlug(slug),
    summary: trimText(entry.summary || entry.definition || ""),
    definition: trimText(entry.definition || entry.summary || ""),
    indicators: Array.isArray(entry.indicators) ? entry.indicators : [],
    examples: Array.isArray(entry.examples) ? entry.examples : [],
    countermeasures: Array.isArray(entry.mitigations) ? entry.mitigations : [],
    related: Array.isArray(entry.related) ? entry.related : [],
    aliases: [entry.id, entry.name].filter(Boolean).filter((v, i, arr) => arr.indexOf(v) === i),
    source,
    qualityFlags,
    tags: Array.isArray(entry.tags) ? entry.tags : [],
    categories: entry.category ? [entry.category] : [],
    whenToUse: [],
    failureModes: [],
    signals: uniqueStrings(Array.isArray(entry.indicators) ? entry.indicators : []),
    antiPatterns: [],
    confidence: null,
    provenance: {
      route_reason: routeReason,
      source_kind: "bias-collection",
      source_index: sourceIndex
    }
  });

  normalized.confidence = confidenceForRecord({ ...normalized, confidence: normalized.confidence ?? 0.9 });

  return { normalized, slug, category, subcategory };
}

function normalizeLibraryRecord(record, sourcePath, sourceType, sourceIndex, htmlMeta = null) {
  const title = trimText(record.title || htmlMeta?.title || titleCaseFromSlug(record.source_slug));
  const slug = slugify(record.source_slug || record.entry_id || title);
  const explicitCategory = trimText(record.category || "");
  const explicitSubcategory = trimText(record.subcategory || record.subgroup || "");
  const category = explicitCategory || topCategoryForMeta({
    title,
    slug,
    summary: record.definition || record.help || htmlMeta?.summary || "",
    definition: record.definition || htmlMeta?.definition || "",
    categories: record.categories || htmlMeta?.categories || [],
    tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
  });
  const otherRoute = category === "other"
    ? otherRouting({
        title,
        slug,
        summary: record.definition || record.help || htmlMeta?.summary || "",
        definition: record.help || record.definition || htmlMeta?.definition || "",
        categories: record.categories || htmlMeta?.categories || [],
        tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta?.tags || [])
      })
    : null;
  const subcategory = explicitSubcategory || (
    category === "biases"
      ? subfolderForBias({
          id: slug,
          name: title,
          kind: record.kind || null,
          category: (record.categories || []).join(" "),
          summary: record.definition || "",
          definition: record.help || "",
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : category === "reasoning-frameworks"
      ? subfolderForReasoning({
          title,
          slug,
          summary: record.definition || record.help || "",
          definition: record.help || record.definition || "",
          categories: record.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : category === "thinking-lenses"
      ? subfolderForThinking({
          title,
          slug,
          summary: record.definition || record.help || "",
          definition: record.help || record.definition || "",
          categories: record.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : category === "heuristics"
      ? subfolderForHeuristics({
          title,
          slug,
          summary: record.definition || record.help || "",
          definition: record.help || record.definition || "",
          categories: record.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : category === "methodology-checks"
      ? subfolderForMethodology({
          title,
          slug,
          summary: record.definition || record.help || "",
          definition: record.help || record.definition || "",
          categories: record.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : category === "fallacies"
      ? subfolderForFallacy({
          title,
          slug,
          summary: record.definition || record.help || "",
          definition: record.help || record.definition || "",
          categories: record.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
        })
      : otherRoute?.subfolder || "adjacent");

  const entryId = trimText(record.entry_id || "") || `ct:${category}:${subcategory}:${slug}`;
  const qualityFlags = [...(record.quality_flags || []).map((flag) => ({
    code: flag.code || "quality-flag",
    severity: flag.severity || "info",
    message: flag.message || "Imported from library record."
  }))];
  if (record.status && record.status !== "published" && record.status !== "verified") {
    qualityFlags.push({
      code: "non-published",
      severity: "warning",
      message: `Library record status is ${record.status}.`
    });
  }
  if (category === "other" && subcategory === "adjacent") {
    qualityFlags.push({
      code: "ambiguous-routing",
      severity: "warning",
      message: "Entry remained in other/adjacent after routing heuristics."
    });
  }

  const tags = (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`);
  const indicators = Array.isArray(htmlMeta?.tags) ? htmlMeta.tags : tags.filter((tag) => tag.startsWith("topic:"));
  const examples = Array.isArray(record.use_cases) ? record.use_cases.slice(0, 8) : [];
  const countermeasures = Array.isArray(record.boosters) ? record.boosters.slice(0, 8) : [];
  const aliases = [record.source_slug, ...((record.aliases || []) || [])].filter(Boolean);
  const related = Array.isArray(record.related_entry_ids) ? record.related_entry_ids : [];
  const whenToUse = Array.isArray(record.use_cases) ? uniqueStrings(record.use_cases) : [];
  const lensCard = record.lens_card && typeof record.lens_card === "object" ? record.lens_card : {};
  const doNotUseWhen = Array.isArray(record.do_not_use_when)
    ? uniqueStrings(record.do_not_use_when)
    : Array.isArray(lensCard.do_not_use_when)
    ? uniqueStrings(lensCard.do_not_use_when)
    : [];
  const misuseWarning = trimText(record.misuse_warning || lensCard.misuse_warning || "");
  const tokenBudget = (record.token_budget && typeof record.token_budget === "object")
    ? record.token_budget
    : (lensCard.token_budget && typeof lensCard.token_budget === "object" ? lensCard.token_budget : {});
  const sourceConfidence = trimText(record.source_confidence || lensCard.source_confidence || "");
  const lensCardMetadata = {
    schema_version: "lens-card.v1",
    use_when: whenToUse.slice(0, 5),
    do_not_use_when: doNotUseWhen.slice(0, 5),
    misuse_warning: misuseWarning,
    token_budget: {
      short: Number(tokenBudget.short || 80),
      standard: Number(tokenBudget.standard || 220),
      full: Number(tokenBudget.full || 700)
    },
    source_confidence: sourceConfidence
  };
  const signals = uniqueStrings([
    ...(Array.isArray(htmlMeta?.tags) ? htmlMeta.tags : []),
    ...tags.filter((tag) => tag.startsWith("topic:") || tag.startsWith("phase:") || tag.startsWith("use:")),
    ...(Array.isArray(record.fields) ? record.fields.map((field) => field.label).filter(Boolean) : [])
  ]);
  const routeReason = category === "other" ? `other/${subcategory}` : `${category}/${subcategory}`;

  const source = {
    original_path: sourcePath,
    source_type: sourceType,
    source_collection: record.collection || "",
    source_slug: record.source_slug || slug,
    source_title: title,
    canonical_url: htmlMeta?.canonicalUrl || "",
    library_entry_id: record.entry_id || "",
    original_index: sourceIndex,
    duplicate_of: null
  };

  const summary = trimText(record.definition || record.help || htmlMeta?.summary || htmlMeta?.description || "");
  const definition = trimText(record.definition || htmlMeta?.definition || summary);
  const provisionalNormalized = {
    entry_id: entryId,
    kind: record.kind || null,
    category,
    subcategory,
    title,
    summary,
    definition,
    indicators,
    examples,
    countermeasures,
    related,
    aliases: aliases.filter((item, idx) => aliases.indexOf(item) === idx),
    source,
    quality_flags: qualityFlags,
    tags,
    categories: record.categories || [],
    when_to_use: whenToUse,
    failure_modes: misuseWarning ? [misuseWarning] : [],
    signals,
    anti_patterns: doNotUseWhen,
    confidence: null,
    provenance: {
      route_reason: routeReason,
      source_kind: sourceType,
      source_index: sourceIndex,
      source_collection: record.collection || "",
      lens_card_metadata: lensCardMetadata
    }
  };

  return {
    normalized: {
      ...createNormalizedRecord({
        entryId,
        kind: record.kind || null,
        category,
        subcategory,
        title,
        summary,
        definition,
        indicators,
        examples,
        countermeasures,
        related,
        aliases: aliases.filter((item, idx) => aliases.indexOf(item) === idx),
        source,
        qualityFlags,
        tags,
        categories: record.categories || [],
        whenToUse,
        failureModes: misuseWarning ? [misuseWarning] : [],
        signals,
        antiPatterns: doNotUseWhen,
        confidence: null,
        provenance: {
          route_reason: routeReason,
          source_kind: sourceType,
          source_index: sourceIndex,
          source_collection: record.collection || "",
          lens_card_metadata: lensCardMetadata
        }
      }),
      confidence: confidenceForRecord(provisionalNormalized)
    },
    category,
    subcategory,
    slug
  };
}

function normalizeTextNote(filePath, sourceType, sourceIndex) {
  const raw = fs.readFileSync(filePath, "utf8").trim();
  const slug = path.basename(filePath, path.extname(filePath)).toLowerCase().replace(/\s+/g, "-");
  const title = titleCaseFromSlug(slug);
  const category = "other";
  const subcategory = sourceType === "transcript" ? "transcripts" : "legacy";
  const entryId = `ct:${category}:${subcategory}:${slug}`;
  const normalized = createNormalizedRecord({
    entryId,
    kind: sourceType,
    category,
    subcategory,
    title,
    summary: raw.split(/\n\n/)[0].slice(0, 500),
    definition: raw,
    indicators: [],
    examples: [],
    countermeasures: [],
    related: [],
    aliases: [title].filter(Boolean),
    source: {
      original_path: filePath,
      source_type: "txt",
      source_collection: "critical-thinker-biases-data",
      source_slug: slug,
      source_title: title,
      original_index: sourceIndex,
      canonical_url: "",
      library_entry_id: "",
      duplicate_of: null
    },
    qualityFlags: sourceType === "transcript" ? [{ code: "transcript", severity: "info", message: "Legacy transcript material." }] : [{ code: "legacy-note", severity: "info", message: "Legacy note material." }],
    tags: [],
    categories: [],
    whenToUse: [],
    failureModes: [],
    signals: [],
    antiPatterns: [],
    confidence: null,
    provenance: {
      route_reason: sourceType === "transcript" ? "legacy transcript note" : "legacy note"
    }
  });
  normalized.confidence = confidenceForRecord(normalized);
  return { normalized, slug, category, subcategory };
}

function htmlSourceMeta(filePath, htmlMeta, record) {
  const slug = path.basename(filePath, path.extname(filePath));
  const kind = record?.kind || htmlMeta?.sourceType || "html";
  const blob = [
    htmlMeta?.title || record?.title || slug,
    htmlMeta?.summary || record?.definition || "",
    ...(record?.categories || htmlMeta?.categories || []),
    ...(record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`),
    ...(htmlMeta?.tags || []),
    ...(htmlMeta?.categories || [])
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  const category = topCategoryForMeta({
    title: htmlMeta?.title || record?.title || slug,
    slug,
    summary: htmlMeta?.summary || record?.definition || "",
    definition: htmlMeta?.definition || record?.help || "",
    categories: htmlMeta?.categories || record?.categories || [],
    tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
  });
  const otherRoute = category === "other"
    ? otherRouting({
        title: htmlMeta?.title || record?.title || slug,
        slug,
        summary: htmlMeta?.summary || record?.definition || "",
        definition: htmlMeta?.definition || record?.help || "",
        categories: htmlMeta?.categories || record?.categories || [],
        tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
      })
    : null;
  const subcategory =
    category === "reasoning-frameworks"
      ? subfolderForReasoning({
          title: htmlMeta?.title || record?.title || slug,
          slug,
          summary: htmlMeta?.summary || record?.definition || "",
          definition: htmlMeta?.definition || record?.help || "",
          categories: htmlMeta?.categories || record?.categories || [],
          tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
        })
      : category === "thinking-lenses"
      ? subfolderForThinking({
          title: htmlMeta?.title || record?.title || slug,
          slug,
          summary: htmlMeta?.summary || record?.definition || "",
          definition: htmlMeta?.definition || record?.help || "",
          categories: htmlMeta?.categories || record?.categories || [],
          tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
        })
      : category === "heuristics"
      ? subfolderForHeuristics({
          title: htmlMeta?.title || record?.title || slug,
          slug,
          summary: htmlMeta?.summary || record?.definition || "",
          definition: htmlMeta?.definition || record?.help || "",
          categories: htmlMeta?.categories || record?.categories || [],
          tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
        })
      : category === "methodology-checks"
      ? subfolderForMethodology({
          title: htmlMeta?.title || record?.title || slug,
          slug,
          summary: htmlMeta?.summary || record?.definition || "",
          definition: htmlMeta?.definition || record?.help || "",
          categories: htmlMeta?.categories || record?.categories || [],
          tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
        })
      : category === "fallacies"
      ? subfolderForFallacy({
          title: htmlMeta?.title || record?.title || slug,
          slug,
          summary: htmlMeta?.summary || record?.definition || "",
          definition: htmlMeta?.definition || record?.help || "",
          categories: htmlMeta?.categories || record?.categories || [],
          tags: [...(htmlMeta?.tags || []), ...((record?.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`))]
        })
      : category === "biases"
      ? (blob.includes("llm") || blob.includes("ai") || blob.includes("model") || blob.includes("prompt") || blob.includes("training data") || blob.includes("algorithmic")) ? "ai" : (blob.includes("cultural") || blob.includes("social") || blob.includes("media") || blob.includes("political") || blob.includes("language") || blob.includes("ethics") || blob.includes("economics") ? "cultural" : "cognitive")
      : category === "other" && /transcript|00:00:|00:01:|conversation|dialogue/.test(blob)
      ? "transcripts"
      : otherRoute?.subfolder || "adjacent";
  return { category, subcategory, kind };
}

function recordToMeta(record, htmlMeta = null) {
  return {
    title: record.title || htmlMeta?.title || "",
    slug: record.source_slug || "",
    summary: record.definition || record.help || htmlMeta?.summary || "",
    definition: record.definition || htmlMeta?.definition || "",
    categories: record.categories || htmlMeta?.categories || [],
    tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`),
    useCases: record.use_cases || htmlMeta?.useCases || [],
    boosters: record.boosters || htmlMeta?.boosters || [],
    kind: record.kind || null
  };
}

function textNoteToMarkdown(normalized, rawText) {
  const frontmatter = [
    "---",
    `entry_id: ${JSON.stringify(normalized.entry_id)}`,
    `title: ${JSON.stringify(normalized.title)}`,
    `kind: ${JSON.stringify(normalized.kind || "")}`,
    `category: ${JSON.stringify(normalized.category)}`,
    `subcategory: ${JSON.stringify(normalized.subcategory)}`,
    `source_path: ${JSON.stringify(normalized.source.original_path)}`,
    `source_type: ${JSON.stringify(normalized.source.source_type)}`,
    `quality: ${JSON.stringify((normalized.quality_flags || []).map((flag) => flag.code).join(",") || "clean")}`,
    `confidence: ${JSON.stringify(normalized.confidence ?? null)}`,
    `route_reason: ${JSON.stringify(normalized.provenance?.route_reason || "")}`,
    "---",
    ""
  ].join("\n");
  return `${frontmatter}# ${normalized.title}\n\n${rawText.trim()}\n`;
}

function toMarkdownRecord(normalized, bodySections = []) {
  const frontmatterLines = [
    "---",
    `entry_id: ${JSON.stringify(normalized.entry_id)}`,
    `title: ${JSON.stringify(normalized.title)}`,
    `kind: ${JSON.stringify(normalized.kind || "")}`,
    `category: ${JSON.stringify(normalized.category)}`,
    `subcategory: ${JSON.stringify(normalized.subcategory)}`,
    `source_path: ${JSON.stringify(normalized.source.original_path)}`,
    `source_type: ${JSON.stringify(normalized.source.source_type)}`,
    `source_slug: ${JSON.stringify(normalized.source.source_slug || "")}`,
    `quality: ${JSON.stringify((normalized.quality_flags || []).map((flag) => flag.code).join(",") || "clean")}`,
    `confidence: ${JSON.stringify(normalized.confidence ?? null)}`,
    `route_reason: ${JSON.stringify(normalized.provenance?.route_reason || "")}`,
    "---",
    ""
  ];
  let body = `# ${normalized.title}\n\n`;
  if (normalized.summary) body += `${normalized.summary}\n\n`;
  for (const section of bodySections) {
    if (!section.items || !section.items.length) continue;
    body += `## ${section.title}\n`;
    body += section.items.map((item) => `- ${item}`).join("\n");
    body += "\n\n";
  }
  if ((normalized.failure_modes || []).length) {
    body += "## Failure modes\n";
    body += normalized.failure_modes.map((item) => `- ${item}`).join("\n");
    body += "\n\n";
  }
  if ((normalized.anti_patterns || []).length) {
    body += "## Anti-patterns\n";
    body += normalized.anti_patterns.map((item) => `- ${item}`).join("\n");
    body += "\n\n";
  }
  return `${frontmatterLines.join("\n")}${body}`.trimEnd() + "\n";
}

function writeCsv(filePath, rows) {
  if (!rows.length) {
    writeText(filePath, "");
    return;
  }
  const headers = Object.keys(rows[0]);
  const lines = [headers.map(csvEscape).join(",")];
  for (const row of rows) {
    lines.push(headers.map((header) => csvEscape(row[header])).join(","));
  }
  writeText(filePath, `${lines.join("\n")}\n`);
}

function renderMarkdownTable(rows, headers) {
  const headerLine = `| ${headers.join(" | ")} |`;
  const divider = `| ${headers.map(() => "---").join(" | ")} |`;
  const lines = [headerLine, divider];
  for (const row of rows) {
    lines.push(`| ${headers.map((header) => String(row[header] ?? "").replace(/\|/g, "\\|")).join(" | ")} |`);
  }
  return `${lines.join("\n")}\n`;
}

function relativeOut(...parts) {
  return path.join(OUT, ...parts);
}

function sourceCopyPath(srcPath) {
  return srcPath;
}

function normalizedCopyPath(meta) {
  const extension = normalizedExtension(meta);
  return relativeOut("normalized", meta.category, meta.subcategory, `${meta.slug}.${extension}`);
}

function normalizedCollectionPath(category, subcategory, slug = "index") {
  return relativeOut("normalized", category, subcategory, `${slug}.json`);
}

function buildReadme(summary, treeText) {
  return `# Critical Thinking Corpus\n\n${summary}\n\n## Layout\n\n\`\`\`text\n${treeText}\n\`\`\`\n\n## Notes\n\n- Canonical root: \`${OUT}\`.\n- \`scripts/build-critical-thinking-corpus.mjs\` is the standalone generator and source of truth.\n- \`incoming/raw\` preserves the local source bundle for rebuilds.\n- \`normalized\` holds the canonical machine-readable records.\n- \`indexes\` holds source manifests, retrieval indexes, graphs, and review reports.\n- \`support\` holds schema, taxonomy, registry, and usage references.\n`;
}

function categoryTreeText() {
  return [
    "CriticalThinking/",
    "  scripts/",
    "  incoming/",
    "    raw/",
    "      source-critical-thinker-biases-data/",
    "      source-glossary-js/",
    "      source-exports/",
    "      database/",
    "        glossary/",
    "        patterns/",
    "        tasks/",
    "  normalized/",
    "    biases/",
    "      cognitive/",
    "      ai/",
    "      cultural/",
    "    reasoning-frameworks/",
    "      inference/",
    "      argumentation/",
    "      uncertainty/",
    "    thinking-lenses/",
    "      systems/",
    "      reflective/",
    "      dialectical/",
    "      design/",
    "      creative/",
    "    fallacies/",
    "      formal/",
    "      informal/",
    "    heuristics/",
    "      judgment/",
    "      decision/",
    "    methodology-checks/",
    "      audit/",
    "      preflight/",
    "      red-team/",
    "      calibration/",
    "    other/",
      "      legacy/",
      "      transcripts/",
      "      paradoxes/",
      "      prompting/",
      "      decision-cases/",
      "      social-dynamics/",
      "      ai-governance/",
    "      adjacent/",
    "  indexes/",
    "    graph/",
    "    reverse/",
    "  support/",
    "    library/",
    "    taxonomy/",
    "    registry/",
    "    schema/"
  ].join("\n");
}

function collectSourceFiles() {
  const out = [];
  for (const filePath of listFilesRecursive(SOURCE_ROOTS.raw)) {
    const base = path.basename(filePath);
    const ext = path.extname(base).toLowerCase();
    if (isSidecar(base)) continue;
    if (!RAW_RELEVANT_EXTS.has(ext)) continue;
    out.push(filePath);
  }
  for (const filePath of SOURCE_JS_FILES) {
    if (exists(filePath)) out.push(filePath);
  }
  for (const filePath of SOURCE_EXPORT_FILES) {
    if (exists(filePath)) out.push(filePath);
  }
  for (const sourceRoot of HTML_SOURCE_ROOTS) {
    for (const filePath of listFilesRecursive(sourceRoot)) {
      const base = path.basename(filePath);
      if (isSidecar(base)) continue;
      if (!FILE_SELECT_RE.test(base)) continue;
      out.push(filePath);
    }
  }
  return out;
}

function sourcePriority(filePath) {
  const kind = fileKind(filePath);
  switch (kind) {
    case "biasCollection":
      return SOURCE_PRIORITY.biasCollection;
    case "glossaryJs":
    case "templatesJs":
    case "tasksJs":
    case "biasesJs":
    case "personaJs":
      return 0.5;
    case "pattern":
      return SOURCE_PRIORITY.pattern;
    case "task":
      return SOURCE_PRIORITY.task;
    case "glossary":
      return SOURCE_PRIORITY.glossary;
    case "txt":
      return SOURCE_PRIORITY.txt;
    case "persona":
      return SOURCE_PRIORITY.persona;
    case "templatesExport":
    case "templatesDatabaseExport":
      return 1.5;
    default:
      return 99;
  }
}

function clearGeneratedOutputs() {
  const targets = [
    path.join(OUT, "normalized"),
    path.join(OUT, "indexes"),
    path.join(OUT, "support", "registry", "aliases.yaml"),
    path.join(OUT, "support", "registry", "README.md"),
    path.join(OUT, "support", "schema"),
    path.join(OUT, "support", "README.md"),
    path.join(OUT, "support", "taxonomy", "corpus-map.md"),
    path.join(OUT, "support", "taxonomy", "retrieval-guide.md")
  ];
  for (const target of targets) {
    fs.rmSync(target, { recursive: true, force: true });
  }
}

function main() {
  ensureDir(OUT);
  clearGeneratedOutputs();

  const { records: libraryRecords, bySlug: libraryBySlug } = loadLibraryRecords();
  const biasCollection = loadBiasCollection();
  const biasBySlug = new Map(biasCollection.map((entry, index) => [slugify(entry.id || entry.name), { entry, index }]));

  const supportCopied = [];
  for (const rel of SUPPORT_FILES) {
    const src = path.join(ROOT, rel);
    if (!exists(src)) continue;
    const dest = sourceCopyPath(src);
    copyFile(src, dest);
    supportCopied.push({
      filename: path.basename(src),
      source_path: src,
      copied_path: dest,
      format: fileFormat(src),
      kind: fileKind(src),
      category: "other",
      subcategory: "support",
      quality: "clean",
      normalized_count: 0,
      normalized_path: "",
      notes: "Support schema / taxonomy file."
    });
  }

  const rawSources = collectSourceFiles().sort((a, b) => sourcePriority(a) - sourcePriority(b) || a.localeCompare(b));
  const sourceRows = [];
  const normalizedRecords = [];
  const normalizedFiles = [];
  const normalizedByKey = new Map();

  // Copy source files into incoming/raw or support.
  for (const src of rawSources) {
    const kind = fileKind(src);
    const dest = sourceCopyPath(src);
    if (kind !== "library" && kind !== "taxonomy") {
      copyFile(src, dest);
    }

    const rel = path.relative(ROOT, src);
    const base = path.basename(src);
    const ext = path.extname(src).toLowerCase();
    const row = {
      filename: base,
      source_path: src,
      format: ext ? ext.slice(1) : "no-ext",
      category: "other",
      subcategory: "",
      quality: "usable",
      copied_path: dest,
      normalized_path: "",
      normalized_count: 0,
      notes: ""
    };

    if (kind === "biasCollection") {
      row.category = "biases";
      row.subcategory = "collection";
      row.quality = "clean";
      row.normalized_count = biasCollection.length;
      row.normalized_path = "normalized/biases/{cognitive|ai|cultural}/*.json";
    } else if (kind === "biasesJs") {
      row.category = "biases";
      row.subcategory = "collection";
      row.quality = "clean";
      row.normalized_count = biasCollection.length;
      row.normalized_path = "normalized/biases/{cognitive|ai|cultural}/*.json";
    } else if (kind === "glossaryJs" || kind === "templatesJs" || kind === "tasksJs" || kind === "personaJs" || kind === "templatesExport" || kind === "templatesDatabaseExport") {
      row.category = "other";
      row.subcategory = "adjacent";
      row.quality = kind === "personaJs" ? "usable" : "clean";
      row.normalized_count = 0;
      row.notes = "Structured source export retained for provenance and rebuilds.";
    } else if (kind === "persona") {
      row.category = "other";
      row.subcategory = "adjacent";
      row.quality = "usable";
      row.normalized_count = 0;
      row.notes = "Out of scope for critical-thinking normalization; retained as source-only context.";
    } else if (kind === "txt") {
      const lowered = base.toLowerCase();
      row.category = "other";
      row.subcategory = lowered.includes("part 2") ? "transcripts" : "legacy";
      row.quality = lowered.includes("part 2") ? "messy" : "usable";
      row.normalized_count = 1;
      row.normalized_path = "normalized/other/{legacy|transcripts}/*.md";
      row.notes = lowered.includes("part 2") ? "Legacy transcript note routed to other/transcripts." : "Legacy note routed to other/legacy.";
    } else if (kind === "html" && rel.startsWith("incoming/raw/source-critical-thinker-biases-data/")) {
      const htmlMeta = parseHtmlSource(src);
      const meta = {
        title: htmlMeta.title,
        slug: base,
        summary: htmlMeta.summary,
        definition: htmlMeta.definition,
        categories: htmlMeta.categories,
        tags: htmlMeta.tags
      };
      row.category = topCategoryForMeta(meta);
      const otherRoute = row.category === "other" ? otherRouting(meta) : null;
      row.subcategory =
        row.category === "reasoning-frameworks"
          ? subfolderForReasoning(meta)
          : row.category === "thinking-lenses"
          ? subfolderForThinking(meta)
          : row.category === "heuristics"
          ? subfolderForHeuristics(meta)
          : row.category === "methodology-checks"
          ? subfolderForMethodology(meta)
          : row.category === "fallacies"
          ? subfolderForFallacy(meta)
          : row.category === "biases"
          ? subfolderForBias({
              id: base,
              name: meta.title,
              kind: null,
              category: "",
              summary: meta.summary,
              definition: meta.definition,
              tags: meta.tags
            })
          : otherRoute?.subfolder || subfolderForOther(meta);
      row.quality = "messy";
      row.normalized_count = 0;
      row.notes = otherRoute?.routeReason || "Legacy raw HTML copy; normalized concept lives in the database source tree.";
    } else if (kind === "glossary" || kind === "pattern" || kind === "task") {
      const slug = path.basename(src, ext);
      const record = libraryBySlug.get(slug);
      if (record) {
        const htmlMeta = parseHtmlSource(src);
        const cat = topCategoryForMeta({
          title: record.title || htmlMeta.title,
          slug,
          summary: record.definition || record.help || htmlMeta.summary || "",
          definition: record.definition || htmlMeta.definition || "",
          categories: record.categories || htmlMeta.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
        });
        const otherRoute = cat === "other" ? otherRouting({
          title: record.title || htmlMeta.title,
          slug,
          summary: record.definition || record.help || htmlMeta.summary || "",
          definition: record.help || record.definition || htmlMeta.definition || "",
          categories: record.categories || htmlMeta.categories || [],
          tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
        }) : null;
        row.category = cat;
        row.subcategory =
          cat === "biases"
            ? subfolderForBias({
                id: slug,
                name: record.title || htmlMeta.title,
                kind: record.kind || null,
                category: (record.categories || []).join(" "),
                summary: record.definition || "",
                definition: record.help || "",
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`)
              })
            : cat === "reasoning-frameworks"
            ? subfolderForReasoning({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              })
            : cat === "thinking-lenses"
            ? subfolderForThinking({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              })
            : cat === "heuristics"
            ? subfolderForHeuristics({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              })
            : cat === "methodology-checks"
            ? subfolderForMethodology({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              })
            : cat === "fallacies"
            ? subfolderForFallacy({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              })
            : otherRoute?.subfolder || subfolderForOther({
                title: record.title || htmlMeta.title,
                slug,
                summary: record.definition || record.help || htmlMeta.summary || "",
                definition: record.help || record.definition || htmlMeta.definition || "",
                categories: record.categories || htmlMeta.categories || [],
                tags: (record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`).concat(htmlMeta.tags || [])
              });
        row.quality = record.status === "published" || record.status === "verified" ? "clean" : "usable";
        row.normalized_count = 1;
        row.normalized_path = path.relative(OUT, normalizedCopyPath({
          category: row.category,
          subcategory: row.subcategory,
          slug,
          kind: record.kind || null
        }));
        if (otherRoute) {
          row.notes = otherRoute.routeReason;
        }

        // Duplicate bias pages are legacy views over the bias collection.
        if (biasBySlug.has(slug) && kind !== "pattern" && kind !== "task" && kind !== "glossary") {
          row.normalized_count = 0;
          row.normalized_path = "";
          row.notes = "Duplicate of bias collection; retained as source copy only.";
        }
      } else {
        const htmlMeta = parseHtmlSource(src);
        const meta = recordToMeta({
          title: htmlMeta.title,
          source_slug: slug,
          definition: htmlMeta.definition,
          help: "",
          categories: htmlMeta.categories,
          tags: htmlMeta.tags.map((tag) => ({ raw: tag, namespace: tag.split(":")[0] || "topic", value: tag.split(":").slice(1).join(":") || tag }))
        }, htmlMeta);
        const cat = topCategoryForMeta(meta);
        const otherRoute = cat === "other" ? otherRouting(meta) : null;
        row.category = cat;
        row.subcategory =
          cat === "reasoning-frameworks"
            ? subfolderForReasoning(meta)
            : cat === "thinking-lenses"
            ? subfolderForThinking(meta)
            : cat === "heuristics"
            ? subfolderForHeuristics(meta)
            : cat === "methodology-checks"
            ? subfolderForMethodology(meta)
            : cat === "fallacies"
            ? subfolderForFallacy(meta)
            : cat === "biases"
            ? subfolderForBias({
                id: slug,
                name: meta.title,
                kind: null,
                category: "",
                summary: meta.summary,
                definition: meta.definition,
                tags: meta.tags
              })
            : otherRoute?.subfolder || subfolderForOther(meta);
        row.quality = "clean";
        row.normalized_count = 1;
        row.normalized_path = path.relative(OUT, normalizedCopyPath({
          category: row.category,
          subcategory: row.subcategory,
          slug,
          kind: "html"
        }));
        if (otherRoute) {
          row.notes = otherRoute.routeReason;
        }
      }
    } else {
      row.category = "other";
      row.subcategory = "adjacent";
      row.quality = "usable";
      row.notes = "Unclassified source artifact kept as adjacent.";
    }

    sourceRows.push(row);
  }

  // Normalize the bias collection entries.
  for (const [slug, { entry, index }] of biasBySlug.entries()) {
    const sourcePath = path.join(SOURCE_ROOTS.raw, "biases.data.js");
    const { normalized } = normalizeBiasEntry(entry, sourcePath, index);
    if (normalizedByKey.has(normalized.entry_id)) continue;
    const normalizedPath = normalizedCopyPath(normalized);
    writeNormalizedArtifact(normalized, normalizedPath);
    normalizedRecords.push({ ...normalized, normalized_path: normalizedPath });
    normalizedFiles.push(normalizedCatalogRow(normalized, sourcePath, normalizedPath));
    normalizedByKey.set(normalized.entry_id, normalizedPath);
  }

  // Normalize the selected HTML and TXT sources.
  for (const src of rawSources) {
    const kind = fileKind(src);
    const ext = path.extname(src);
    const base = path.basename(src, ext);

    if (kind === "txt") {
      const rawText = fs.readFileSync(src, "utf8");
      const noteType = base.toLowerCase().includes("part 2") ? "transcript" : "note";
      const normalized = normalizeTextNote(src, noteType, sourceRows.findIndex((row) => row.source_path === src));
      if (normalizedByKey.has(normalized.normalized.entry_id)) continue;
      const dest = normalizedCopyPath({
        category: normalized.normalized.category,
        subcategory: normalized.normalized.subcategory,
        slug: normalized.slug,
        kind: normalized.normalized.kind
      });
      writeNormalizedArtifact(normalized.normalized, dest, rawText);
      normalizedRecords.push({ ...normalized.normalized, normalized_path: dest });
      normalizedFiles.push(normalizedCatalogRow(normalized.normalized, src, dest));
      normalizedByKey.set(normalized.normalized.entry_id, dest);
      continue;
    }

    if (kind !== "glossary" && kind !== "pattern" && kind !== "task") continue;

    const slug = base;
    if (biasBySlug.has(slug)) {
      continue;
    }

    const record = libraryBySlug.get(slug);
    const htmlMeta = parseHtmlSource(src);
    const metaRecord = record || {
      entry_id: `${kind}:${slug}`,
      collection: kind,
      source_slug: slug,
      title: htmlMeta.title,
      kind: null,
      status: "verified",
      definition: htmlMeta.definition,
      help: "",
      notes: "",
      aliases: [],
      categories: htmlMeta.categories,
      tags: htmlMeta.tags.map((tag) => {
        const [namespace, ...rest] = tag.split(":");
        return { raw: tag, namespace: namespace || "topic", value: rest.join(":") || tag };
      }),
      use_cases: htmlMeta.useCases,
      boosters: htmlMeta.boosters,
      fields: htmlMeta.fields,
      related_entry_ids: [],
      quality_flags: [],
      provenance: {},
      search_text: ""
    };
    const normalizedMeta = normalizeLibraryRecord(metaRecord, src, kind, sourceRows.findIndex((row) => row.source_path === src), htmlMeta);
    const normalized = normalizedMeta.normalized;
    if (normalizedByKey.has(normalized.entry_id)) continue;
    const dest = normalizedCopyPath({ ...normalized, slug });
    writeNormalizedArtifact(normalized, dest);
    normalizedRecords.push({ ...normalized, normalized_path: dest });
    normalizedFiles.push(normalizedCatalogRow(normalized, src, dest));
    normalizedByKey.set(normalized.entry_id, dest);
  }

  // Normalize standalone support records from targeted packs that do not have a matching HTML source.
  for (const record of libraryRecords.filter((item) => STANDALONE_LIBRARY_PHASES.has(item?.provenance?.phase))) {
    const sourcePath = record.__support_source_path || path.join(ROOT, "support/library", `${record.provenance.phase}.pack.json`);
    const sourceType = record.provenance?.source_type || record.provenance?.source_kind || "library-pack";
    const sourceIndex = record.__support_source_index ?? sourceRows.findIndex((row) => row.source_path === sourcePath);
    const normalizedMeta = normalizeLibraryRecord(record, sourcePath, sourceType, sourceIndex, null);
    const normalized = normalizedMeta.normalized;
    if (normalizedByKey.has(normalized.entry_id)) continue;
    const dest = normalizedCopyPath(normalized);
    writeNormalizedArtifact(normalized, dest);
    normalizedRecords.push({ ...normalized, normalized_path: dest });
    normalizedFiles.push(normalizedCatalogRow(normalized, sourcePath, dest));
    normalizedByKey.set(normalized.entry_id, dest);
  }

  // Build source inventory outputs.
  const inventoryRows = [...supportCopied, ...sourceRows];

  const sourceCsvRows = inventoryRows.map((row) => ({
    filename: row.filename,
    format: row.format,
    category: row.category,
    subcategory: row.subcategory,
    quality: row.quality,
    source_path: row.source_path,
    copied_path: row.copied_path,
    normalized_count: row.normalized_count,
    normalized_path: row.normalized_path,
    notes: row.notes
  }));

  writeCsv(path.join(OUT, "indexes", "source-inventory.csv"), sourceCsvRows);
  writeText(
    path.join(OUT, "indexes", "source-inventory.md"),
    renderMarkdownTable(
      sourceCsvRows.map((row) => ({
        filename: row.filename,
        format: row.format,
        category: row.category,
        quality: row.quality,
        normalized: row.normalized_path || "-"
      })),
      ["filename", "format", "category", "quality", "normalized"]
    )
  );
  writeJson(path.join(OUT, "indexes", "source-inventory.json"), sourceCsvRows);

  writeCsv(path.join(OUT, "indexes", "normalized-catalog.csv"), normalizedFiles);
  writeJson(path.join(OUT, "indexes", "normalized-catalog.json"), normalizedFiles);

  const aliasRegistry = buildAliasRegistry(normalizedRecords);
  const reverseIndexes = {
    use: buildFacetIndex(normalizedRecords, "use"),
    topic: buildFacetIndex(normalizedRecords, "topic"),
    phase: buildFacetIndex(normalizedRecords, "phase"),
    kind: buildFacetIndex(normalizedRecords, "kind"),
    category: buildFacetIndex(normalizedRecords, "category")
  };
  const conceptGraph = buildConceptGraph(normalizedRecords, aliasRegistry);
  const validationReport = buildValidationReport(normalizedRecords, aliasRegistry, conceptGraph);
  const reviewHoldout = validationReport.ambiguous_routing;

  const summary = {
    built_at: new Date().toISOString(),
    source_file_count: inventoryRows.length,
    normalized_entry_count: normalizedFiles.length,
    category_counts: inventoryRows.reduce((acc, row) => {
      acc[row.category] = (acc[row.category] || 0) + 1;
      return acc;
    }, {}),
    normalized_category_counts: normalizedFiles.reduce((acc, row) => {
      acc[row.category] = (acc[row.category] || 0) + 1;
      return acc;
    }, {}),
    normalized_subcategory_counts: normalizedRecords.reduce((acc, record) => {
      const key = `${record.category}/${record.subcategory}`;
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {}),
    other_subcategory_counts: normalizedRecords.reduce((acc, record) => {
      if (record.category !== "other") return acc;
      acc[record.subcategory] = (acc[record.subcategory] || 0) + 1;
      return acc;
    }, {}),
    source_type_counts: inventoryRows.reduce((acc, row) => {
      acc[row.format] = (acc[row.format] || 0) + 1;
      return acc;
    }, {}),
    source_priority_order: ["biasCollection", "pattern", "task", "glossary", "txt", "persona"],
    alias_count: aliasRegistry.total_aliases,
    review_holdout_count: reviewHoldout.length,
    confidence_bands: normalizedRecords.reduce((acc, record) => {
      const confidence = record.confidence ?? 0;
      const band = confidence >= 0.8 ? "high" : confidence >= 0.6 ? "medium" : "low";
      acc[band] = (acc[band] || 0) + 1;
      return acc;
    }, {}),
    graph_nodes: conceptGraph.counts.nodes,
    graph_edges: conceptGraph.counts.edges
  };
  writeJson(path.join(OUT, "indexes", "summary.json"), summary);

  // Corpus snapshot notes. Keep the root README as the product/release surface.
  const readme = buildReadme(
    `This corpus snapshot contains ${summary.source_file_count} source files and ${summary.normalized_entry_count} normalized entries, organized for AI-first critical-thinking retrieval.`,
    categoryTreeText()
  );
  writeText(path.join(OUT, "indexes", "corpus-snapshot.md"), readme);

  const indexNotes = [
    "# Indexes",
    "",
    `- Source inventory rows: ${inventoryRows.length}`,
    `- Normalized entries: ${normalizedFiles.length}`,
    `- Alias entries: ${aliasRegistry.total_aliases}`,
    `- Review holdout entries: ${reviewHoldout.length}`,
    "",
    "## Files",
    "",
    "- `source-inventory.csv` / `.md` / `.json`",
    "- `normalized-catalog.csv` / `.json`",
    "- `normalized-paths.json`",
    "- `aliases.json`",
    "- `reverse/`",
    "- `graph/`",
    "- `validation-report.json`",
    "- `review-holdout.json`",
    "- `summary.json`"
  ].join("\n");
  writeText(path.join(OUT, "indexes", "README.md"), `${indexNotes}\n`);

  // Save a compact manifest of the normalized corpus for convenience.
  writeJson(path.join(OUT, "indexes", "normalized-paths.json"), Object.fromEntries(normalizedFiles.map((row) => [row.entry_id, row.normalized_path])));

  // Retrieval / validation artifacts.
  writeJson(path.join(OUT, "indexes", "aliases.json"), aliasRegistry);
  writeJson(path.join(OUT, "indexes", "reverse", "use.json"), reverseIndexes.use);
  writeJson(path.join(OUT, "indexes", "reverse", "topic.json"), reverseIndexes.topic);
  writeJson(path.join(OUT, "indexes", "reverse", "phase.json"), reverseIndexes.phase);
  writeJson(path.join(OUT, "indexes", "reverse", "kind.json"), reverseIndexes.kind);
  writeJson(path.join(OUT, "indexes", "reverse", "category.json"), reverseIndexes.category);
  writeText(
    path.join(OUT, "indexes", "reverse", "README.md"),
    [
      "# Reverse Indexes",
      "",
      "- `use.json`",
      "- `topic.json`",
      "- `phase.json`",
      "- `kind.json`",
      "- `category.json`"
    ].join("\n") + "\n"
  );

  writeJson(path.join(OUT, "indexes", "graph", "concept-graph.json"), conceptGraph);
  writeText(
    path.join(OUT, "indexes", "graph", "concept-graph.md"),
    [
      "# Concept Graph",
      "",
      `- Nodes: ${conceptGraph.counts.nodes}`,
      `- Edges: ${conceptGraph.counts.edges}`,
      "",
      "The graph links canonical entries to their categories, subcategories, and see-also relationships."
    ].join("\n") + "\n"
  );
  writeText(
    path.join(OUT, "indexes", "graph", "README.md"),
    [
      "# Graph",
      "",
      "- `concept-graph.json`",
      "- `concept-graph.md`"
    ].join("\n") + "\n"
  );

  writeJson(path.join(OUT, "indexes", "validation-report.json"), validationReport);
  writeText(
    path.join(OUT, "indexes", "validation-report.md"),
    [
      "# Validation Report",
      "",
      `- Invalid IDs: ${validationReport.invalid_ids.length}`,
      `- Missing source references: ${validationReport.missing_source_references.length}`,
      `- Broken related links: ${validationReport.broken_related_links.length}`,
      `- Empty content records: ${validationReport.empty_content.length}`,
      `- Ambiguous routing records: ${validationReport.ambiguous_routing.length}`,
      `- Alias collisions: ${validationReport.alias_collisions.length}`
    ].join("\n") + "\n"
  );

  writeJson(path.join(OUT, "indexes", "review-holdout.json"), reviewHoldout);
  writeText(
    path.join(OUT, "indexes", "review-holdout.md"),
    renderMarkdownTable(
      reviewHoldout.map((row) => ({
        entry_id: row.entry_id,
        title: row.title,
        confidence: row.confidence ?? "",
        route_reason: row.route_reason
      })),
      ["entry_id", "title", "confidence", "route_reason"]
    )
  );

  writeText(path.join(OUT, "support", "registry", "aliases.yaml"), `${toYaml(aliasRegistry)}\n`);
  writeText(
    path.join(OUT, "support", "registry", "README.md"),
    [
      "# Alias Registry",
      "",
      `- Total aliases: ${aliasRegistry.total_aliases}`,
      `- Collisions: ${aliasRegistry.collisions.length}`,
      "",
      "Generated alias registry for canonical lookup, exact-match aliases, and near-synonym access."
    ].join("\n") + "\n"
  );

  writeText(
    path.join(OUT, "support", "schema", "normalized-record.schema.yaml"),
    [
      "record:",
      "  entry_id: string",
      "  slug: string",
      "  kind: string|null",
      "  category: string",
      "  subcategory: string",
      "  title: string",
      "  summary: string",
      "  definition: string",
      "  indicators: [string]",
      "  examples: [string]",
      "  countermeasures: [string]",
      "  related: [string]",
      "  aliases: [string]",
      "  when_to_use: [string]",
      "  failure_modes: [string]",
      "  signals: [string]",
      "  anti_patterns: [string]",
      "  confidence: number|null",
      "  source: object",
      "  provenance: object",
      "  quality_flags: [object]",
      "  tags: [string]",
      "  categories: [string]"
    ].join("\n") + "\n"
  );
  writeText(
    path.join(OUT, "support", "schema", "retrieval-index.schema.yaml"),
    [
      "aliases:",
      "  alias_to_entry: object",
      "  entry_to_aliases: object",
      "reverse_indexes:",
      "  use: object",
      "  topic: object",
      "  phase: object",
      "  kind: object",
      "  category: object",
      "graph:",
      "  nodes: [object]",
      "  edges: [object]",
      "validation_report: object"
    ].join("\n") + "\n"
  );
  writeText(
    path.join(OUT, "support", "schema", "README.md"),
    [
      "# Schema",
      "",
      "- `normalized-record.schema.yaml`",
      "- `retrieval-index.schema.yaml`"
    ].join("\n") + "\n"
  );

  writeText(
    path.join(OUT, "support", "taxonomy", "corpus-map.md"),
    [
      "# Corpus Map",
      "",
      "## Top-level categories",
      "",
      "- biases",
      "- reasoning-frameworks",
      "- thinking-lenses",
      "- fallacies",
      "- heuristics",
      "- methodology-checks",
      "- other",
      "",
      "## other subdomains",
      "",
      "- paradoxes",
      "- prompting",
      "- decision-cases",
      "- social-dynamics",
      "- ai-governance",
      "- adjacent",
      "",
      "## Retrieval tips",
      "",
      "- Search by alias first, then use/topic/phase facets.",
      "- Use `indexes/reverse/*.json` for deterministic lookup.",
      "- Use `indexes/graph/concept-graph.json` for parent, child, and see-also paths.",
      "- Use `indexes/review-holdout.json` to inspect ambiguous routing."
    ].join("\n") + "\n"
  );
  writeText(
    path.join(OUT, "support", "taxonomy", "retrieval-guide.md"),
    [
      "# Retrieval Guide",
      "",
      "1. Resolve a concept by alias or exact title.",
      "2. Expand with reverse indexes by use, topic, phase, kind, or category.",
      "3. Walk related edges in the concept graph for adjacent concepts.",
      "4. Review the holdout list when confidence is low or routing is adjacent."
    ].join("\n") + "\n"
  );

  writeText(
    path.join(OUT, "support", "README.md"),
    [
      "# Support",
      "",
      "## Subfolders",
      "",
      "- `library/` local source metadata and schemas",
      "- `taxonomy/` local taxonomy source copies plus corpus guidance",
      "- `registry/` generated alias registry",
      "- `schema/` generated record and index schema docs"
    ].join("\n") + "\n"
  );

  removeNoiseFiles(OUT);

  // Print a concise run summary.
  console.log(JSON.stringify(summary, null, 2));
}

main();
