#!/usr/bin/env python3
"""Validate deterministic audit report rendering against golden fixtures."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "audit_report" / "fixtures"


def main() -> None:
    sys.path.insert(0, str(ROOT))
    from audit_report.tool import generate_audit_report  # pylint: disable=import-error,import-outside-toplevel
    from audit_report.qa import bias_table_layout_issues, extract_pdf_text  # pylint: disable=import-error,import-outside-toplevel

    temp_root = Path(tempfile.mkdtemp(prefix="critical-compass-report-"))
    fixture_names = ["minimal", "max_content", "profile_only", "advanced_full", "table_overlap", "complete_report_ready", "long_sentence_caps"]
    for name in fixture_names:
        data = json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))
        output = temp_root / f"{name}.pdf"
        result = generate_audit_report(data, output_path=str(output), include_raw_text=name == "max_content")
        assert result["qa_status"] in {"passed", "passed_with_cosmetic_issues"}, (name, result["qa_status"], result["qa_issues"])
        assert result["preflight_status"] == "passed", (name, result["preflight_status"], result["qa_issues"])
        assert Path(result["report_path"]).exists(), name
        assert Path(result["markdown_path"]).exists(), name
        assert Path(result["viewer_path"]).exists(), name
        assert result["artifact_viewer"]["status"] == "ready", name
        assert result["markdown_hash"], name
        assert result["markdown_validation"]["passed"], (name, result["markdown_validation"])
        assert result["page_count"] >= 1, name
        assert result["preview_image_path"], name
        assert result["page_image_paths"], name
        assert result["payload_hash"], name
        if name == "long_sentence_caps":
            assert result["schema_warnings"], result
        if name == "table_overlap":
            assert len(result["page_image_paths"]) >= 2, result
            text, text_issues = extract_pdf_text(Path(result["report_path"]))
            assert not text_issues, text_issues
            assert not bias_table_layout_issues(Path(result["report_path"])), result["qa_issues"]
            for fallback in [
                "No plain-language read was supplied.",
                "Name the evidence, assumption, or missing voice a reader should test next.",
                "Finding not supplied",
            ]:
                assert fallback not in text, fallback

    checklist_data = json.loads((FIXTURES / "minimal.json").read_text(encoding="utf-8"))
    checklist = generate_audit_report(checklist_data, report_depth="checklist_only", output_path=str(temp_root / "checklist.pdf"))
    assert checklist["qa_status"] in {"passed", "passed_with_cosmetic_issues"}, checklist["qa_issues"]
    assert checklist["tier_2_page_range"] is None
    assert checklist["markdown_hash"], checklist
    assert Path(checklist["viewer_path"]).exists(), checklist

    self_mode = generate_audit_report(checklist_data, report_mode="self", output_path=str(temp_root / "self.pdf"))
    assert self_mode["qa_status"] in {"passed", "passed_with_cosmetic_issues"}, self_mode["qa_issues"]
    assert self_mode["preflight_status"] == "passed", self_mode["qa_issues"]

    alias_data = json.loads((FIXTURES / "alias_regression.json").read_text(encoding="utf-8"))
    alias_report = generate_audit_report(alias_data, output_path=str(temp_root / "alias_regression.pdf"))
    assert alias_report["qa_status"] == "passed", alias_report["qa_issues"]
    assert alias_report["preflight_status"] == "passed", alias_report["qa_issues"]
    assert Path(alias_report["markdown_path"]).exists(), alias_report
    alias_text, alias_text_issues = extract_pdf_text(Path(alias_report["report_path"]))
    assert not alias_text_issues, alias_text_issues
    for fallback in [
        "No plain-language read was supplied.",
        "Name the evidence, assumption, or missing voice a reader should test next.",
        "Finding not supplied",
    ]:
        assert fallback not in alias_text, fallback
    assert alias_report["normalization_diagnostics"]["aliases_used"], alias_report["normalization_diagnostics"]

    missing_data = json.loads((FIXTURES / "missing_fields.json").read_text(encoding="utf-8"))
    missing_report = generate_audit_report(missing_data, output_path=str(temp_root / "missing_fields.pdf"))
    assert missing_report["qa_status"] == "blocked", missing_report["qa_issues"]
    assert missing_report["preflight_status"] == "blocked_missing_fields", missing_report
    assert missing_report["report_path"] == "", missing_report
    assert missing_report["markdown_path"] == "", missing_report
    assert not (temp_root / "missing_fields.pdf").exists()
    assert missing_report["schema_warnings"], missing_report
    missing_fields = {item["field"] for item in missing_report["missing_report_fields"]}
    assert "cis.plain_language_read" in missing_fields, missing_fields
    assert "cis.dimensions[].improvement_prompt" in missing_fields, missing_fields
    assert "advanced_audit.agents[].top_finding" in missing_fields, missing_fields
    assert missing_report["accepted_aliases"], missing_report

    failed_data = json.loads((FIXTURES / "failed_v2_incomplete_report.json").read_text(encoding="utf-8"))
    failed_report = generate_audit_report(failed_data, output_path=str(temp_root / "failed_v2.pdf"))
    assert failed_report["qa_status"] == "blocked", failed_report
    assert failed_report["report_path"] == "", failed_report
    assert failed_report["markdown_path"] == "", failed_report
    assert not (temp_root / "failed_v2.pdf").exists()
    failed_fields = {item["field"] for item in failed_report["missing_report_fields"]}
    for field in {"cis.before_using_this_text", "assumptions", "alternative_frames", "questions.probing_or_follow_up", "next_steps"}:
        assert field in failed_fields, failed_fields
    assert any(item.get("field") == "next_steps" for item in failed_report["qa_issues"]), failed_report["qa_issues"]

    placeholder_data = json.loads((FIXTURES / "placeholder_override.json").read_text(encoding="utf-8"))
    placeholder_report = generate_audit_report(placeholder_data, output_path=str(temp_root / "placeholder_override.pdf"), allow_placeholders=True)
    assert placeholder_report["qa_status"] == "blocked", placeholder_report["qa_issues"]
    assert placeholder_report["preflight_status"] == "placeholder_override", placeholder_report
    assert Path(placeholder_report["report_path"]).exists(), placeholder_report
    assert Path(placeholder_report["markdown_path"]).exists(), placeholder_report
    assert any(item.get("check") in {"plain_language_read_fallback", "dimension_prompt_fallback"} for item in placeholder_report["qa_issues"]), placeholder_report["qa_issues"]

    print("audit report renderer validation ok")
    print(f"temp reports: {temp_root}")


if __name__ == "__main__":
    main()
