#!/usr/bin/env python3
"""Validate high-risk Critical Compass public surfaces stay synchronized."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

SHIP_NEXT_TERMS = [
    "Host-AI Quickstart / Current State Context",
    "client-specific one-line hints",
    "tool trigger matrix",
    "surface sync checklist",
]

MISSION_TERMS = [
    "pressure-test text before",
    "mission-driven organizations",
    "weak evidence",
    "overly narrow Western framing",
]

ROADMAP_MISSION_TERMS = [
    "mission-audience-purpose-charter.md",
    "Pressure-Test Readiness",
    "public users and nonprofit",
    "trust, revise, verify, or reframe",
]

COMMON_TERMS = SHIP_NEXT_TERMS + [
    "output requirements",
    "tool inventory",
]

PRE_RELEASE_TERMS = [
    "get_started",
    "quick_scan",
    "list_agent_personas",
    "compare_audit_results",
    "social_media",
    "academic_abstract",
    "product_copy",
    "ai_generated",
]

PUBLIC_PAGE_TERMS = [
    'data-tab-target="about"',
    'data-tab-target="faq"',
    'id="tab-about"',
    'id="tab-faq"',
    "What Is Critical Compass?",
    "Frequently Asked Questions",
    "validate_report_payload first",
    "Download Skill Zip",
    "I want a fast first read",
    "Skill File or Skill Zip",
    "Download source files",
    "Advanced: Verify Download",
    "compass-public-visual-system: uxhc-v1",
    "0.1.0-beta.10",
]

HUMAN_LOOP_WIDGET_TERMS = [
    "Ask_User_Input_V0",
    "ask_user_input widget",
    "single-select",
    "multi-select",
    "rank-priority",
]

HUMAN_LOOP_CONTRACT_TERMS = HUMAN_LOOP_WIDGET_TERMS + [
    "plain_text_questions_valid",
    "widget_compliance_check",
    "tool_compliance_signal",
    "repair_instruction",
]

SURFACE_REQUIREMENTS = {
    "README.md": COMMON_TERMS + MISSION_TERMS + PRE_RELEASE_TERMS + HUMAN_LOOP_CONTRACT_TERMS + [
        "docs/public/why-critical-compass.md",
        "mission-audience-purpose-charter.md",
        "validate_mcp_surface_sync.py",
        "First-share default",
        'report_depth="readiness_card"',
        "debug metadata",
    ],
    "AGENTS.md": [
        "separate `About` and `FAQ` tabs",
        "no combined `About & FAQ` tab",
        "build_shareable_release.py --pages-only",
        'report_depth="readiness_card"',
        "package rebuild, public-site edit, or publish step",
    ],
    "docs/public/why-critical-compass.md": MISSION_TERMS + [
        "does not verify truth",
        "does not replace human judgment",
        "does not guarantee that non-Western",
        "does not prevent biased outputs",
        "local-first",
    ],
    "server.py": MISSION_TERMS + PRE_RELEASE_TERMS + HUMAN_LOOP_CONTRACT_TERMS + ["teaching_alignment_contract", "No retrieval was performed", "output requirements"],
    "support/resources/scaffolds/v1/tool-inventory.md": COMMON_TERMS + PRE_RELEASE_TERMS + HUMAN_LOOP_WIDGET_TERMS + ["plain-text questions are invalid"],
    "support/resources/scaffolds/v1/server-instructions.md": SHIP_NEXT_TERMS + PRE_RELEASE_TERMS + HUMAN_LOOP_WIDGET_TERMS + ["pressure-test text before", "widget_compliance_check", "tool_compliance_signal", "repair_instruction"],
    "support/resources/scaffolds/v1/host-ai-quickstart-current-state.md": [
        "Current Shipped State",
        "Freshness Checks",
        "Default Host Path",
        "pressure-test-readiness-kit.md",
    ] + MISSION_TERMS + PRE_RELEASE_TERMS + HUMAN_LOOP_WIDGET_TERMS + ["plain_text_questions_valid", "first-share report", 'report_depth="readiness_card"'],
    "support/resources/scaffolds/v1/client-host-hints.md": [
        "Claude",
        "Codex",
        "Cursor-Style Coding Hosts",
        "General Host Rule",
        "trusted, revised, verified, or reframed before use",
    ] + PRE_RELEASE_TERMS[:4] + HUMAN_LOOP_WIDGET_TERMS + ["widget_compliance_check", "tool_compliance_signal", "repair_instruction", "compact report default"],
    "support/resources/scaffolds/v1/tool-trigger-matrix.md": [
        "Call When",
        "Do Not Call When",
        "Ask First",
        "Output Label",
        "trust, revise, verify, or reframe",
    ] + PRE_RELEASE_TERMS[:4] + HUMAN_LOOP_WIDGET_TERMS + ["widget_compliance_check", "tool_compliance_signal", "repair_instruction"],
    "support/resources/scaffolds/v1/surface-sync-checklist.md": [
        "Required Surface Checks",
        "Planning-Hygiene Checks",
        "Validation Command",
        "Pressure-Test Readiness",
        "does not do",
        "direct",
        "qualified",
        "weak",
        "not_comparable",
    ],
    "support/resources/scaffolds/v1/pressure-test-readiness-kit.md": [
        "Pressure-Test Readiness Kit",
        "trust, revise, verify, or reframe",
        "Bias Mitigation Next-Step",
        "KB No-Result Recovery",
        "AI/Data Audit Language",
        "Current Output Audit",
        "Curated Gap-Fill",
        "Persona Seeds And Practice Pilot",
        "Practice Activity Tool Gate",
        "Routing Cheat Sheet",
        "Ethical Dilemma Teaching Examples",
    ],
    "support/evals/atlas_pressure_test_scenarios.json": [
        "critical_compass.atlas_pressure_test_scenarios.v1",
        "advocacy_copy_missing_voice",
        "public_statement_accountability_gap",
        "grant_impact_claim_metric_bias",
        "article_review_source_gap",
        "ai_generated_summary_provenance_gap",
        "research_adjacent_summary_external_validity",
    ],
    "support/evals/atlas_pressure_test_output_audit.json": [
        "critical_compass.atlas_pressure_test_output_audit.v1",
        "check-worthy language means worth verifying, not false",
        "advocacy_copy_missing_voice",
        "public_statement_accountability_gap",
        "grant_impact_claim_metric_bias",
        "article_review_source_gap",
        "ai_generated_summary_provenance_gap",
        "research_adjacent_summary_external_validity",
    ],
    "support/evals/practice_activity_tool_gate.json": [
        "critical_compass.practice_activity_tool_gate.v1",
        "defer_standalone_tool",
        "No new Now-phase MCP tool",
        "No automatic web search",
        "No external archive runtime dependency",
    ],
    "support/library/atlas-curated-gap-fill.pack.json": [
        "atlas-informed-curated-gap-fill-pack",
        "Hallucination-confidence risk",
        "Provenance-gap risk",
        "Metric or benchmark bias",
        "Dataset shift",
        "Citation bias",
        "Spin bias",
        "Outcome reporting bias",
        "Sponsorship bias",
    ],
    "support/resources/scaffolds/v1/mcpb-install-diagnostics-prompt.md": [
        "MCPB/Desktop Extension",
        "Settings > Extensions",
        "Do not add Google/Brave/provider keys",
        "lookup_performed=true",
    ],
    "docs/planning/mcp-study-library-soft-learner.md": [
        "MSL-01",
        "MSL-02",
        "MSL-03",
        "MSL-04",
        "Current Active Phase",
    ] + ROADMAP_MISSION_TERMS[1:],
    "docs/planning/mission-audience-purpose-charter.md": MISSION_TERMS + [
        "Pressure-test this before I use it",
        "Decision Filter For Future Work",
        "What Not To Build Next",
    ],
    "docs/planning/master-roadmap.md": ROADMAP_MISSION_TERMS + [
        "PTR-01",
        "PTR-02",
        "PTR-03",
        "PTR-04",
        "support infrastructure",
    ],
    "docs/tickets/top-10-prioritized-tickets.md": ROADMAP_MISSION_TERMS[1:] + [
        "PTR-01",
        "PTR-02",
        "PTR-03",
        "PTR-04",
        "Done / MSL-01",
        "Done / MSL-04",
    ],
    "docs/planning/implementation-status-and-idea-drift-review-2026-04-15.md": [
        "Mission Alignment Review",
        "Pressure-Test Readiness",
        "infrastructure drift",
        "trust, revise, verify, or reframe",
    ],
    "docs/planning/mcp-composition-strategy.md": [
        "Mission Alignment Pause",
        "support infrastructure",
        "pressure-test text before use",
    ],
    "tests/test_release_surface_upgrades.py": PRE_RELEASE_TERMS + ["No retrieval was performed", "does not verify truth"],
    "tests/test_human_loop_gates.py": HUMAN_LOOP_CONTRACT_TERMS + ["violates the Critical Compass interaction contract"],
    "tests/test_agentic_flow_contract.py": HUMAN_LOOP_WIDGET_TERMS + ["plain_text_questions_valid", "tool_compliance_signal"],
    "critical-compass/SKILL.md": HUMAN_LOOP_WIDGET_TERMS + ["widget_compliance_check", "tool_compliance_signal", "repair_instruction", "first-share report", 'report_depth="readiness_card"'],
    "scripts/build_shareable_release.py": PUBLIC_PAGE_TERMS + [
        "critical-compass-github-pages-kit",
    ],
    "tests/test_shareable_release.py": [
        'data-tab-target="about"',
        'data-tab-target="faq"',
        "What Is Critical Compass?",
        "Frequently Asked Questions",
        "About &amp; FAQ",
        "not in github_html",
        "not in manual_html",
    ],
    "dist/share/github-pages/index.html": PUBLIC_PAGE_TERMS,
    "dist/share/manual-share/START_HERE.html": PUBLIC_PAGE_TERMS,
}

FORBIDDEN_SURFACE_TERMS = {
    "scripts/build_shareable_release.py": ["About &amp; FAQ", "Tool Overview", "Advanced: Release Downloads and Checksums"],
    "dist/share/github-pages/index.html": ["About &amp; FAQ", "Tool Overview", "Advanced: Release Downloads and Checksums"],
    "dist/share/manual-share/START_HERE.html": ["About &amp; FAQ", "Tool Overview", "Advanced: Release Downloads and Checksums"],
}

MANIFEST_IDS = {
    "host_ai_quickstart_current_state",
    "client_host_hints",
    "tool_trigger_matrix",
    "surface_sync_checklist",
    "mcpb_install_diagnostics_prompt",
    "pressure_test_readiness_kit",
}


def _contains(text: str, term: str) -> bool:
    return term.casefold() in text.casefold()


def _validate_text_surfaces() -> list[str]:
    failures: list[str] = []
    for relative_path, terms in SURFACE_REQUIREMENTS.items():
        path = ROOT / relative_path
        if not path.exists():
            failures.append(f"{relative_path}: missing file")
            continue
        text = path.read_text(encoding="utf-8")
        for term in terms:
            if not _contains(text, term):
                failures.append(f"{relative_path}: missing {term!r}")
        for term in FORBIDDEN_SURFACE_TERMS.get(relative_path, []):
            if _contains(text, term):
                failures.append(f"{relative_path}: forbidden stale public-page term {term!r}")
    return failures


def _validate_manifest() -> list[str]:
    failures: list[str] = []
    manifest_path = ROOT / "support" / "resources" / "scaffolds" / "v1" / "manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"support/resources/scaffolds/v1/manifest.json: unreadable manifest: {exc}"]
    resources = manifest.get("resources")
    if not isinstance(resources, list):
        return ["support/resources/scaffolds/v1/manifest.json: resources must be a list"]
    ids = {item.get("id") for item in resources if isinstance(item, dict)}
    for resource_id in sorted(MANIFEST_IDS - ids):
        failures.append(f"support/resources/scaffolds/v1/manifest.json: missing resource id {resource_id!r}")
    for item in resources:
        if not isinstance(item, dict) or item.get("id") not in MANIFEST_IDS:
            continue
        path = item.get("path")
        if not path or not (manifest_path.parent / path).exists():
            failures.append(f"support/resources/scaffolds/v1/manifest.json: resource {item.get('id')!r} path does not exist")
    return failures


def validate_surface_sync() -> dict[str, object]:
    failures = _validate_text_surfaces() + _validate_manifest()
    return {
        "status": "passed" if not failures else "failed",
        "failures": failures,
        "checked_files": sorted(SURFACE_REQUIREMENTS) + ["support/resources/scaffolds/v1/manifest.json"],
    }


def main() -> int:
    result = validate_surface_sync()
    if result["status"] != "passed":
        for failure in result["failures"]:
            print(failure)
        return 1
    print("mcp surface sync validation passed")
    for path in result["checked_files"]:
        print(f"- {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
