#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import re
import sqlite3
from pathlib import Path
from typing import Any


ROOT = Path("/Volumes/KyleSSD/CriticalThinking")
DEFAULT_DB_PATH = ROOT / "db" / "critical-compass.sqlite"
PROJECT_REFERENCES_DIR = ROOT / "references"
DEFAULT_SKILL_DIR = Path("/Users/jonathanhobson/.codex/skills/critical-compass")
DEFAULT_SKILL_REFERENCES_DIR = DEFAULT_SKILL_DIR / "references"
STANDALONE_SKILL_DIR = ROOT / "critical-compass"
STATIC_STANDALONE_REFERENCE_NAMES = [
    "critical-integrity-snapshot.md",
    "decision-layer.md",
    "activity-layer.md",
    "disambiguation-rules.md",
    "methodology-checks.md",
    "output-templates.md",
    "examples.md",
    "mcp-bridge.md",
]

ICON_CRITICAL = "🔍"
ICON_COMPASSIONATE = "🤝"
ICON_CREATIVE = "🌀"


BIAS_SELECTIONS = {
    "cognitive": [
        "ct:biases:cognitive:confirmation-bias",
        "ct:biases:cognitive:anchoring-bias",
        "ct:biases:cognitive:sunk-cost-fallacy",
        "ct:biases:cognitive:status-quo-bias",
        "ct:biases:cognitive:negativity-bias",
        "ct:biases:cognitive:belief-bias",
        "ct:biases:cognitive:choice-supportive-bias",
        "ct:biases:cognitive:disconfirmation-bias",
        "ct:biases:cognitive:information-bias",
        "ct:biases:cognitive:attentional-bias",
        "ct:biases:cognitive:bias-blind-spot",
        "ct:biases:cognitive:actor-observer-bias",
        "ct:biases:cognitive:groupthink",
        "ct:biases:cognitive:selection-bias",
        "ct:biases:cognitive:neglect-of-probability",
    ],
    "cultural": [
        "ct:biases:cultural:authority-bias",
        "ct:biases:cultural:ingroup-bias",
        "ct:biases:cultural:egocentric-bias",
        "ct:biases:cultural:omission-bias",
        "ct:biases:cultural:dehumanization-bias",
        "ct:biases:cultural:height-bias",
        "ct:biases:cultural:bandwagon-effect",
    ],
    "ai": [
        "ct:biases:ai:availability-heuristic",
        "ct:biases:ai:anthropomorphism-bias",
        "ct:biases:ai:hindsight-bias",
        "ct:biases:ai:attractiveness-bias",
        "ct:biases:ai:framing-effect",
        "ct:biases:ai:survivorship-bias",
        "ct:biases:ai:self-serving-bias",
        "ct:biases:ai:halo-effect",
        "ct:biases:ai-data:hallucination-confidence-risk",
        "ct:biases:ai-data:provenance-gap-risk",
        "ct:biases:ai-data:sycophancy-risk",
        "ct:biases:ai-data:metric-or-benchmark-bias",
        "ct:biases:ai-data:dataset-shift",
        "ct:biases:ai-data:evaluation-bias",
        "ct:biases:ai-data:representation-bias",
    ],
    "methodology": [
        "ct:biases:methodology:weird-bias",
        "ct:biases:methodology:demand-characteristics",
        "ct:biases:methodology:social-desirability-bias",
        "ct:biases:methodology:overgeneralization",
        "ct:biases:methodology:publication-bias",
        "ct:biases:methodology:p-hacking",
        "ct:biases:methodology:harking",
        "ct:biases:methodology:nonresponse-bias",
        "ct:biases:methodology:attrition-bias",
        "ct:biases:research-evidence:citation-bias",
        "ct:biases:research-evidence:spin-bias",
        "ct:biases:research-evidence:outcome-reporting-bias",
        "ct:biases:research-evidence:sponsorship-bias",
        "ct:biases:research-evidence:recall-bias",
        "ct:biases:research-evidence:source-monitoring-error",
    ],
}

VALIDITY_SELECTIONS = [
    "ct:methodology:validity:construct-validity",
    "ct:methodology:validity:external-validity",
    "ct:methodology:validity:measurement-validity",
    "ct:methodology:validity:internal-validity",
    "ct:methodology:reproducibility:replicability",
]


FALLACY_SELECTIONS = [
    {
        "title": "False dilemma",
        "kb_id": "ct:fallacies:informal:false-dilemma",
        "source": "Live KB",
        "aliases": ["false dichotomy", "either-or fallacy"],
        "steelman_risk": "Real decisions can still be binary once the constraints are explicit.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Ad hominem",
        "kb_id": "ct:fallacies:informal:ad-hominem",
        "source": "Live KB",
        "aliases": ["personal attack"],
        "steelman_risk": "A person's credibility can matter if the claim depends on expertise or conflicts of interest.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Straw man",
        "kb_id": "ct:fallacies:informal:straw-man",
        "source": "Live KB",
        "aliases": ["strawman"],
        "steelman_risk": "People sometimes compress a view before engaging it; check the strongest version first.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Slippery slope",
        "kb_id": "ct:fallacies:informal:slippery-slope",
        "source": "Live KB",
        "aliases": [],
        "steelman_risk": "Some chains really do have plausible escalation; ask for mechanism and probability at each step.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Appeal to authority",
        "kb_id": "ct:fallacies:informal:appeal-to-authority",
        "source": "Live KB",
        "aliases": ["authority bias"],
        "steelman_risk": "Expert testimony is valid when the authority is in-scope and the evidence is transparent.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Hasty generalization",
        "kb_id": "ct:fallacies:informal:hasty-generalization",
        "source": "Live KB",
        "aliases": ["generalization"],
        "steelman_risk": "A small sample can still be suggestive when it is representative and properly bounded.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Circular reasoning",
        "kb_id": "ct:fallacies:informal:circular-reasoning",
        "source": "Live KB",
        "aliases": ["begging the question"],
        "steelman_risk": "A conclusion can appear circular only because the premises were paraphrased too loosely.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Bandwagon",
        "kb_id": "ct:fallacies:informal:bandwagon",
        "source": "Live KB",
        "aliases": ["appeal to popularity"],
        "steelman_risk": "Popularity can be a useful proxy when the crowd has relevant expertise or evidence.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Causal overreach",
        "kb_id": "ct:fallacies:informal:causal-overreach",
        "source": "Live KB",
        "aliases": ["correlation/causation confusion", "false cause", "post hoc"],
        "steelman_risk": "Temporal order and correlation can sometimes point to cause when mechanism is strong.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Unsupported certainty",
        "kb_id": "ct:fallacies:informal:unsupported-certainty",
        "source": "Live KB",
        "aliases": ["certainty inflation"],
        "steelman_risk": "Confidence can be appropriate when the evidence base is unusually strong and direct.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Argument from ignorance",
        "kb_id": "ct:fallacies:informal:argument-from-ignorance",
        "source": "Live KB",
        "aliases": [],
        "steelman_risk": "Lack of evidence against a claim is not always decisive when evidence is genuinely hard to obtain.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Red herring",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": ["distraction"],
        "definition": "Introducing a distracting side issue that does not address the main claim.",
        "signal": "The text shifts to a side issue instead of the original claim.",
        "example": "We should not talk about emissions because the building project is already behind schedule.",
        "steelman_risk": "A side issue can be relevant if it actually changes the conclusion.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Appeal to emotion",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": ["emotion appeal"],
        "definition": "Using emotion as the main support for a conclusion instead of evidence.",
        "signal": "The argument tries to make the reader feel, not verify.",
        "example": "You have to support this policy because imagine how heartbreaking failure would be.",
        "steelman_risk": "Emotion can indicate stakes, values, or harms even if it is not proof by itself.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Appeal to nature",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": [],
        "definition": "Treating something as good because it is natural, or bad because it is unnatural.",
        "signal": "The text treats 'natural' as automatically better or safer.",
        "example": "This option must be best because it is natural.",
        "steelman_risk": "Nature can be a relevant clue when mechanism, safety, or context is also shown.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Loaded question",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": ["complex question"],
        "definition": "Asking a question that smuggles in an unproven assumption.",
        "signal": "The question presupposes the very thing under dispute.",
        "example": "Why did you stop ignoring the evidence?",
        "steelman_risk": "The presupposition may already have been established elsewhere in the exchange.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Modus tollens abuse",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": ["failed prediction fallacy"],
        "definition": "Treating one failed prediction as if it fully falsified the broader theory.",
        "signal": "One missed prediction is treated as total disproof.",
        "example": "The prediction failed, so the whole model is useless.",
        "steelman_risk": "A failed prediction may reveal a bad premise, boundary condition, or measurement issue rather than a dead theory.",
        "three_cs": ICON_CRITICAL,
    },
    {
        "title": "Survivorship bias",
        "kb_id": None,
        "source": "Supplemental",
        "aliases": ["survivorship reasoning"],
        "definition": "Overweighting the cases that survived and missing the cases that failed.",
        "signal": "The text only talks about winners or survivors.",
        "example": "We should copy this strategy because every successful founder used it.",
        "steelman_risk": "Survivor data can be appropriate when survivors are the exact population of interest.",
        "three_cs": ICON_CRITICAL,
    },
]


LENS_SELECTIONS = [
    {
        "name": "Systems Thinking",
        "kb_id": "ct:reasoning-frameworks:argumentation:systems-thinking",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What feedback loops, delays, or leverage points are missing?",
        "best_for": "policy memos, causal claims, org change, messy systems",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Socratic Questioning",
        "kb_id": "ct:reasoning-frameworks:argumentation:socratic-questioning",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What assumption would have to be true for this to hold?",
        "best_for": "single claims, threads, interviews, weakly supported assertions",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Cross-Cultural Competency",
        "kb_id": "ct:methodology-checks:preflight:cross-cultural-competency-training",
        "type": "technique",
        "source": "Live KB",
        "prompt": "What cultural norm, translation gap, or projection could be distorting this?",
        "best_for": "cross-cultural interpretation, localization, identity-sensitive text, global teams",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Ubuntu — Relational personhood & communal ethics",
        "kb_id": "ct:thinking-lenses:systems:ubuntu",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What changes if dignity and judgment are treated as communal rather than purely individual?",
        "best_for": "relational ethics, community accountability, social repair, governance",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Whakapapa — Genealogical epistemology",
        "kb_id": "ct:thinking-lenses:systems:whakapapa",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What lineages, places, or obligations make this claim intelligible?",
        "best_for": "contextual reasoning, ancestry, place-based accountability, relational knowledge",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Sulh — Reconciliation and peaceful settlement",
        "kb_id": "ct:thinking-lenses:systems:sulh",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What would repair, dignity, and peace require here?",
        "best_for": "conflict repair, mediation, settlement, harm reduction",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Shura — Consultative deliberation",
        "kb_id": "ct:thinking-lenses:systems:shura",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who should be consulted, and how does counsel shape authority?",
        "best_for": "deliberation, governance, leadership accountability, communal decision-making",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Zhengming — Rectification of Names",
        "kb_id": "ct:thinking-lenses:systems:zhengming",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Do the labels, roles, and words match the reality and responsibility?",
        "best_for": "precision of language, role clarity, category drift, ethical naming",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Seven Generations Principle",
        "kb_id": "ct:thinking-lenses:systems:seven-generations-principle",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Would this still be defensible seven generations from now?",
        "best_for": "intergenerational stewardship, policy, ecology, long-horizon planning",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Nahua Nepantla — In-between reasoning",
        "kb_id": "ct:thinking-lenses:systems:nepantla",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What becomes visible only in the in-between?",
        "best_for": "liminality, contradiction, hybridity, identity transitions",
        "three_cs": ICON_CREATIVE,
    },
    {
        "name": "Ayni — Reciprocity and mutual aid",
        "kb_id": "ct:thinking-lenses:systems:ayni",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What must be given back, and to whom, for this relationship to stay balanced?",
        "best_for": "reciprocity, mutual aid, stewardship, relational accountability",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Buen Vivir / Sumak Kawsay",
        "kb_id": "ct:thinking-lenses:systems:buen-vivir",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What does flourishing look like for the community and land together?",
        "best_for": "collective flourishing, ecological balance, policy, wellbeing",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Hawaiian — Hāloa / Pono",
        "kb_id": "ct:thinking-lenses:systems:haloa-pono",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What relationships, nourishment, or balance are missing if land and people are treated separately?",
        "best_for": "AI ethics, land relations, intergenerational governance, reciprocity checks",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Cree — Wahkohtowin",
        "kb_id": "ct:thinking-lenses:systems:wahkohtowin",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who is in the kinship circle, and what accountability follows from that framing?",
        "best_for": "kinship reasoning, language framing, colonial-scale AI governance, accountability audits",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Lakota — Wakȟáŋ",
        "kb_id": "ct:thinking-lenses:systems:wakan-sacred-mystery",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What material, ecological, or sacred obligations vanish if this is treated as only mechanical?",
        "best_for": "material provenance, non-human agency, sacred limits, AI ethics",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Relationality / All My Relations",
        "kb_id": "ct:thinking-lenses:systems:relationality-all-my-relations",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What relationships, obligations, or non-human stakeholders disappear in the human-centered framing?",
        "best_for": "AI ethics, ecology, place-based policy, kinship-aware analysis",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Reciprocity / Stewardship",
        "kb_id": "ct:thinking-lenses:systems:reciprocity-stewardship",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What mutual care, consent, or accountability is owed back here?",
        "best_for": "governance, stewardship, community agreements, long-horizon decisions",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Ganma — Knowledge Confluence (Yolŋu)",
        "kb_id": "framework:ganma-knowledge-confluence",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Where do two knowledge streams meet without erasing their differences?",
        "best_for": "co-design, cross-tradition dialogue, education, stewardship",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Kaitiakitanga — Guardianship & Stewardship (Māori)",
        "kb_id": "framework:kaitiakitanga-guardianship",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What guardianship, care, and intergenerational responsibility does this require?",
        "best_for": "environmental stewardship, governance, community care, AI ethics",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Two-Eyed Seeing (Etuaptmumk): Braiding Indigenous and Western knowledge",
        "kb_id": "framework:two-eyed-seeing-etuaptmumk",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What can each knowledge system contribute without collapsing one into the other?",
        "best_for": "research synthesis, policy, community partnership, mixed-method reasoning",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "OCAP - First Nations data governance",
        "kb_id": "ct:thinking-lenses:systems:ocap-first-nations-data-governance",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who owns, controls, accesses, and possesses the data?",
        "best_for": "First Nations data governance, research ethics, community data agreements",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "CARE Principles - Indigenous data governance",
        "kb_id": "ct:thinking-lenses:systems:care-indigenous-data-governance",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What collective benefit, authority, responsibility, and ethics govern this data use?",
        "best_for": "Indigenous data governance, FAIR-plus-CARE checks, research and evaluation",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Data erasure and misclassification risk",
        "kb_id": "ct:methodology-checks:audit:data-erasure-misclassification-risk",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who disappears because of the categories, denominators, or aggregation choices?",
        "best_for": "public-health data, demographic categories, dashboards, urban Indigenous visibility",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Indigenous food sovereignty and health equity",
        "kb_id": "ct:thinking-lenses:systems:indigenous-food-sovereignty-health-equity",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who governs the food system, and who defines health and success?",
        "best_for": "health equity, food systems, recovery, land and community wellbeing",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Kaupapa Māori Research — By/with/for Māori communities; sovereignty at the core",
        "kb_id": "ct:thinking-lenses:design:kaupapa-maori-research-sovereignty-centered",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Who has authority, whose knowledge is centered, and what sovereignty is protected?",
        "best_for": "community research, sovereignty-aware analysis, ethics review, partnership design",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Community Capitals",
        "kb_id": "ct:thinking-lenses:systems:community-capitals-framework-seven-capitals",
        "type": "framework",
        "source": "Live KB",
        "prompt": "Which capital is being strengthened, depleted, or ignored?",
        "best_for": "community planning, grant strategy, place-based policy, asset mapping",
        "three_cs": ICON_COMPASSIONATE,
    },
    {
        "name": "Facione's six-skill model",
        "kb_id": "ct:reasoning-frameworks:argumentation:faciones-core-critical-thinking-skills",
        "type": "framework",
        "source": "Live KB",
        "prompt": "What is the claim, what is the evidence, and what would weaken it?",
        "best_for": "research summaries, peer review, argument audits, decision memos",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Scenario-Based Deliberative reasoning",
        "kb_id": "framework:scenario-based-deliberative",
        "type": "framework",
        "source": "Live KB",
        "prompt": "If we reason deliberately from the concrete situation, what assumptions and actions matter most?",
        "best_for": "coaching, policy-sensitive prompts, decision support, edge cases",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Argument Mapping",
        "kb_id": "ct:reasoning-frameworks:argumentation:argument-mapping",
        "type": "strategy",
        "source": "Live KB",
        "prompt": "What is the claim, the reasons, the objections, and the rejoinders?",
        "best_for": "debates, essays, strategy memos, legal or policy arguments",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "Pre-mortem",
        "kb_id": "ct:thinking-lenses:systems:pre-mortem-future-failure-safeguards",
        "type": "strategy",
        "source": "Live KB",
        "prompt": "If this fails, what will have caused it?",
        "best_for": "plans, roadmaps, launches, high-risk decisions",
        "three_cs": ICON_CREATIVE,
    },
    {
        "name": "[Claude-native] Long-term / intergenerational",
        "kb_id": None,
        "type": "lens",
        "source": "Claude-native",
        "description": "Zooms out from immediate wins to second- and third-order effects over time. Use it when a choice may trade present convenience for future burden, resilience, or trust.",
        "prompt": "What changes if we optimize for people one, five, and twenty years from now?",
        "best_for": "strategy, climate, infrastructure, family systems, policy",
        "three_cs": ICON_CREATIVE,
    },
    {
        "name": "[Claude-native] Economic / incentive",
        "kb_id": None,
        "type": "lens",
        "source": "Claude-native",
        "description": "Asks how incentives, costs, and benefits shape behavior behind the stated position. Use it when apparent preferences may be responses to rewards, penalties, or risk.",
        "prompt": "Who bears the cost, who captures the benefit, and what incentives are in play?",
        "best_for": "organizational decisions, policy, business models, behavior change",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "[Claude-native] Historical precedent",
        "kb_id": None,
        "type": "lens",
        "source": "Claude-native",
        "description": "Checks whether the current case really resembles a prior case and what transferred across contexts. Use it when arguments rely on analogy, precedent, or 'we've seen this before' reasoning.",
        "prompt": "What similar case has already happened, and what really transferred?",
        "best_for": "history, policy, legal analogy, strategy, risk review",
        "three_cs": ICON_CRITICAL,
    },
    {
        "name": "[Claude-native] Power & stakeholder mapping",
        "kb_id": None,
        "type": "lens",
        "source": "Claude-native",
        "description": "Identifies who has decision power, who bears consequences, and who is missing from the frame. Use it when the text hides asymmetries, missing voices, or governance gaps.",
        "prompt": "Who has power, who is affected, and who is missing from the table?",
        "best_for": "community decisions, negotiations, governance, team conflicts",
        "three_cs": ICON_COMPASSIONATE,
    },
]


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def connect(db_path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(str(db_path))
    connection.row_factory = sqlite3.Row
    return connection


def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def short_phrase(text: str | None, max_words: int = 14) -> str:
    if not text:
        return ""
    words = normalize_whitespace(text).split()
    return " ".join(words[:max_words]).strip()


def parse_json_list(raw: Any) -> list[str]:
    if not raw:
        return []
    if isinstance(raw, list):
        return [str(item).strip() for item in raw if str(item).strip()]
    if not isinstance(raw, str):
        return []
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item).strip() for item in parsed if str(item).strip()]


def looks_like_metadata_token(text: str) -> bool:
    return bool(re.match(r"^(type|topic|phase|category|kind|status):", text.strip().lower()))


def cue_phrase_from_row(row: sqlite3.Row, max_words: int = 10) -> str:
    signals = [
        signal
        for signal in parse_json_list(row["signals_json"] if "signals_json" in row.keys() else None)
        if not looks_like_metadata_token(signal)
    ]
    if signals:
        return "; ".join(short_phrase(signal, max_words) for signal in signals[:2])
    examples = parse_json_list(row["examples_json"] if "examples_json" in row.keys() else None)
    if examples:
        return short_phrase(examples[0], max_words)
    return short_phrase(row["summary"] or row["definition"], max_words)


def first_sentence(text: str | None) -> str:
    if not text:
        return ""
    normalized = normalize_whitespace(text)
    parts = re.split(r"(?<=[.!?])\s+", normalized)
    return parts[0].strip()


def render_bullet(label: str, value: str) -> str:
    return f"- **{label}:** {value.strip()}"


def render_bias_section(conn: sqlite3.Connection, category: str, ids: list[str]) -> str:
    heading = {
        "cognitive": "## Cognitive",
        "cultural": "## Cultural",
        "ai": "## AI",
        "methodology": "## Research Methodology",
    }[category]
    lines = [heading, ""]
    for concept_id in ids:
        row = conn.execute("select * from concepts where concept_id = ?", (concept_id,)).fetchone()
        if row is None:
            raise RuntimeError(f"Missing bias concept: {concept_id}")
        title = row["title"]
        summary = row["summary"] or row["definition"] or ""
        example = row["example"] or row["summary"] or ""
        mitigation = row["mitigation"] or ""
        confidence = row["confidence_weight"] or "medium"
        three_cs = ICON_CRITICAL
        lines.extend(
            [
                f"### {title}",
                render_bullet("ID", concept_id),
                render_bullet("Definition", row["definition"] or summary),
                render_bullet("Signal phrase", cue_phrase_from_row(row)),
                render_bullet("Example", example),
                render_bullet("Mitigation", mitigation or "—"),
                render_bullet("Confidence", confidence),
                render_bullet("Three Cs", three_cs),
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def render_bias_library(conn: sqlite3.Connection) -> str:
    header = """# Bias Library

Curated offline mini-KB for the Critical Compass skill.

## Contents

- Cognitive
- Cultural
- AI
- Research Methodology

- Source of truth: `/Volumes/KyleSSD/CriticalThinking/db/critical-compass.sqlite`
- Use this when the MCP is unavailable or when you want a fast human-readable lookup.
- Signal phrases are KB-derived cues from signals, examples, or summaries, not invented labels.

"""
    parts = [header]
    for category in ("cognitive", "cultural", "ai", "methodology"):
        parts.append(render_bias_section(conn, category, BIAS_SELECTIONS[category]))
    parts.append(render_bias_section(conn, "methodology", VALIDITY_SELECTIONS).replace("## Research Methodology", "## Research Validity Companion"))
    return "".join(parts)


def render_live_fallacy(conn: sqlite3.Connection, item: dict[str, Any]) -> str:
    row = conn.execute("select * from concepts where concept_id = ?", (item["kb_id"],)).fetchone()
    if row is None:
        slug = item["kb_id"].rsplit(":", 1)[-1]
        row = conn.execute(
            "select * from concepts where concept_id like ? and category = 'fallacies' order by concept_id limit 1",
            (f"%{slug}",),
        ).fetchone()
    if row is None:
        row = conn.execute(
            "select * from concepts where lower(title) = lower(?) and category = 'fallacies' order by concept_id limit 1",
            (item["title"],),
        ).fetchone()
    if row is None:
        raise RuntimeError(f"Missing fallacy concept: {item['kb_id']}")
    aliases = sorted({alias for alias in json.loads(row["aliases_json"] or "[]") if alias})
    alias_text = ", ".join(aliases or item.get("aliases", [])) or "—"
    signal = item.get("signal") or cue_phrase_from_row(row, max_words=12)
    steelman = item["steelman_risk"]
    source = item["source"]
    lines = [
        f"### {item['title']}",
        render_bullet("Aliases", alias_text),
        render_bullet("Definition", row["definition"] or row["summary"] or ""),
        render_bullet("Signal", signal),
        render_bullet("Example", row["example"] or row["summary"] or ""),
        render_bullet("Steelman risk", steelman),
        render_bullet("Three Cs", item["three_cs"]),
        render_bullet("Source", source),
        render_bullet("KB ID", row["concept_id"] or item["kb_id"]),
        "",
    ]
    return "\n".join(lines)


def render_supplemental_fallacy(item: dict[str, Any]) -> str:
    aliases = ", ".join(item.get("aliases") or []) or "—"
    lines = [
        f"### {item['title']}",
        render_bullet("Aliases", aliases),
        render_bullet("Definition", item["definition"]),
        render_bullet("Signal", item["signal"]),
        render_bullet("Example", item["example"]),
        render_bullet("Steelman risk", item["steelman_risk"]),
        render_bullet("Three Cs", item["three_cs"]),
        render_bullet("Source", item["source"]),
        render_bullet("KB ID", "Supplemental"),
        "",
    ]
    return "\n".join(lines)


def render_fallacy_library(conn: sqlite3.Connection) -> str:
    header = """# Fallacy Library

Offline claim-interrogation reference. Live KB fallacies appear first; supplemental entries are clearly marked so Claude does not confuse them with live corpus data.

## Contents

- Live KB
- Supplemental

"""
    parts = [header, "## Live KB\n\n"]
    live_items = [item for item in FALLACY_SELECTIONS if item["source"] == "Live KB"]
    supplemental_items = [item for item in FALLACY_SELECTIONS if item["source"] != "Live KB"]
    for item in live_items:
        parts.append(render_live_fallacy(conn, item))
    parts.append("## Supplemental\n\n")
    for item in supplemental_items:
        parts.append(render_supplemental_fallacy(item))
    return "".join(parts)


def render_live_lens(conn: sqlite3.Connection, item: dict[str, Any]) -> str:
    row = conn.execute("select * from concepts where concept_id = ?", (item["kb_id"],)).fetchone()
    if row is None:
        slug = item["kb_id"].rsplit(":", 1)[-1]
        row = conn.execute(
            "select * from concepts where concept_id like ? and category in ('reasoning-frameworks', 'thinking-lenses', 'methodology-checks', 'other') order by concept_id limit 1",
            (f"%{slug}",),
        ).fetchone()
    if row is None:
        row = conn.execute(
            "select * from concepts where lower(title) = lower(?) and category in ('reasoning-frameworks', 'thinking-lenses', 'methodology-checks', 'other') order by concept_id limit 1",
            (item["name"],),
        ).fetchone()
    if row is None:
        raise RuntimeError(f"Missing lens concept: {item['kb_id']}")
    description = row["summary"] or row["definition"] or ""
    best_for = item["best_for"]
    prompt = item["prompt"]
    lines = [
        f"### {item['name']}",
        render_bullet("KB ID", row["concept_id"] or item["kb_id"]),
        render_bullet("Type", item["type"]),
        render_bullet("Description", description),
        render_bullet("Prompt", prompt),
        render_bullet("Best for", best_for),
        render_bullet("Three Cs", item["three_cs"]),
        "",
    ]
    return "\n".join(lines)


def render_native_lens(item: dict[str, Any]) -> str:
    lines = [
        f"### {item['name']}",
        render_bullet("KB ID", "[Claude-native]"),
        render_bullet("Type", item["type"]),
        render_bullet("Description", item["description"]),
        render_bullet("Prompt", item["prompt"]),
        render_bullet("Best for", item["best_for"]),
        render_bullet("Three Cs", item["three_cs"]),
        "",
    ]
    return "\n".join(lines)


def render_thinking_lenses(conn: sqlite3.Connection) -> str:
    header = """# Thinking Lenses

Offline reframing frames for the Critical Compass skill.

## Contents

- Live KB
- Claude-native

- Live KB frames come first.
- The live set now includes relational, cultural, and non-Western epistemology frameworks alongside the core reasoning lenses.
- `[Claude-native]` lenses are explicitly marked fallback helpers, not live corpus entries.

"""
    parts = [header, "## Live KB\n\n"]
    live_items = [item for item in LENS_SELECTIONS if item["source"] == "Live KB"]
    native_items = [item for item in LENS_SELECTIONS if item["source"] != "Live KB"]
    for item in live_items:
        parts.append(render_live_lens(conn, item))
    parts.append("## Claude-native\n\n")
    for item in native_items:
        parts.append(render_native_lens(item))
    return "".join(parts)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.exists() else None
    if existing == text:
        return
    path.write_text(text, encoding="utf-8")


def read_static_skill_body(project_root: Path, skill_dir: Path) -> str:
    candidates = [
        project_root / "critical-compass" / "SKILL.md",
        STANDALONE_SKILL_DIR / "SKILL.md",
        skill_dir / "SKILL.md",
    ]
    for path in candidates:
        if path.exists():
            return path.read_text(encoding="utf-8")
    raise FileNotFoundError("Could not find standalone critical-compass/SKILL.md to export")


def read_static_references(project_root: Path, skill_dir: Path) -> dict[str, str]:
    candidates = [
        project_root / "critical-compass" / "references",
        STANDALONE_SKILL_DIR / "references",
        skill_dir / "references",
    ]
    refs: dict[str, str] = {}
    for name in STATIC_STANDALONE_REFERENCE_NAMES:
        for directory in candidates:
            path = directory / name
            if path.exists():
                refs[name] = path.read_text(encoding="utf-8")
                break
        if name not in refs:
            raise FileNotFoundError(f"Could not find standalone reference to export: {name}")
    return refs


def cleanup_noise(root: Path) -> None:
    for pattern in ("._*", ".DS_Store"):
        for path in root.rglob(pattern):
            if path.is_file():
                path.unlink()


def sync_skill_bundle(project_refs: dict[str, str], skill_dir: Path, skill_body: str) -> None:
    skill_references = skill_dir / "references"
    skill_references.mkdir(parents=True, exist_ok=True)
    expected_names = set(project_refs)
    for path in skill_references.glob("*.md"):
        if path.name not in expected_names:
            path.unlink()
    for name, text in project_refs.items():
        write_text(skill_references / name, text)
    write_text(skill_dir / "SKILL.md", skill_body)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export the offline Critical Compass skill KB.")
    parser.add_argument("--db-path", default=str(DEFAULT_DB_PATH))
    parser.add_argument("--project-root", default=str(ROOT))
    parser.add_argument("--skill-dir", default=str(DEFAULT_SKILL_DIR))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(args.project_root).expanduser().resolve()
    db_path = Path(args.db_path).expanduser().resolve()
    skill_dir = Path(args.skill_dir).expanduser().resolve()
    conn = connect(db_path)

    bias_text = render_bias_library(conn)
    fallacy_text = render_fallacy_library(conn)
    lens_text = render_thinking_lenses(conn)
    static_refs = read_static_references(project_root, skill_dir)
    skill_body = read_static_skill_body(project_root, skill_dir)

    refs_dir = project_root / "references"
    write_text(refs_dir / "bias-library.md", bias_text)
    write_text(refs_dir / "fallacy-library.md", fallacy_text)
    write_text(refs_dir / "thinking-lenses.md", lens_text)

    sync_skill_bundle(
        {
            "bias-library.md": bias_text,
            "fallacy-library.md": fallacy_text,
            "thinking-lenses.md": lens_text,
            **static_refs,
        },
        skill_dir,
        skill_body,
    )
    cleanup_noise(project_root)
    cleanup_noise(skill_dir)

    print(
        json.dumps(
            {
                "project_root": str(project_root),
                "references": str(refs_dir),
                "skill_dir": str(skill_dir),
                "bias_entries": sum(len(v) for v in BIAS_SELECTIONS.values()),
                "fallacy_entries": len(FALLACY_SELECTIONS),
                "lens_entries": len(LENS_SELECTIONS),
                "static_references": len(static_refs),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
