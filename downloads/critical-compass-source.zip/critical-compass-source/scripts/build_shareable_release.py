#!/usr/bin/env python3
"""Build GitHub and manual-share release kits for Critical Compass."""

from __future__ import annotations

import hashlib
import html
import argparse
import json
import re
import shutil
import subprocess
import sys
import textwrap
import zipfile
from pathlib import Path

from PIL import Image

from build_mcpb_bundle import stage_bundle


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audit_report.models import cap_complete_prose
from critical_course_resources import CLASSROOM_STANDARD_AUDIT_PROMPT

DIST = ROOT / "dist"
SHARE_DIR = DIST / "share"

PLUGIN_SOURCE_DIR = DIST / "plugins" / "critical-compass-plugin"
PLUGIN_ZIP = DIST / "plugins" / "critical-compass-plugin.zip"
STANDALONE_SKILL_SOURCE_DIR = ROOT / "critical-compass"
MCPB_FILE = DIST / "mcpb" / "critical-compass-0.1.0.mcpb"
SKILL_FILE = DIST / "mcpb" / "critical-compass.skill"
SKILL_ZIP = DIST / "mcpb" / "skill.zip"
ROOT_SKILL_FILE = ROOT / "critical-compass.skill"
SOURCE_ZIP = DIST / "source" / "critical-compass-source.zip"
DIAGNOSTIC_PROMPT = ROOT / "packaging" / "mcpb" / "INSTALLER_DIAGNOSTIC_PROMPT.md"
RAW_EXAMPLE_HTML = ROOT / "reports" / "audit-report-20260417-182829-viewer.html"
RAW_EXAMPLE_MARKDOWN = ROOT / "reports" / "audit-report-20260417-182829.md"
RAW_EXAMPLE_PDF = ROOT / "reports" / "audit-report-20260417-182829.pdf"
RAW_EXAMPLE_SCREENSHOTS = tuple(
    Path("/Users/jonathanhobson/Pictures/Screenshots") / f"{index}.png" for index in range(1, 5)
)
PUBLIC_EXAMPLES_SOURCE = ROOT / "packaging" / "examples" / "public"
EXAMPLE_TITLE = "Redacted Nonprofit Policy Draft - Critical Compass Example Audit"
EXAMPLE_NOTE = "This public example is redacted to protect unpublished source material."
EXAMPLE_HTML = "critical-compass-example-report.html"
EXAMPLE_PDF = "critical-compass-example-report.pdf"
EXAMPLE_MARKDOWN = "critical-compass-example-report.md"
EXAMPLE_SCREENSHOT = "critical-compass-claude-output-screenshot.png"
EXAMPLE_SCREENSHOT_ALT = "Stitched screenshot of a Claude conversation showing Critical Compass quick feedback output"
MCP_EXPLAINER_SOURCE = Path("/Volumes/KyleSSD/What is an MCP?")
MCP_INFOGRAPHIC_SOURCE = MCP_EXPLAINER_SOURCE / "infographic"
MCP_EXPLAINER_HTML = "what-is-an-mcp.html"
MCP_EXPLAINER_PUBLIC_URL = "https://jonathankhobson.github.io/what-is-an-mcp/"
MCP_EXPLAINER_SITE_DIR = SHARE_DIR / "mcp-explainer-site"
MCP_INFOGRAPHIC_DIR_NAME = "mcp-infographic"
MCP_INFOGRAPHIC_FILES = ("full.png", "1.png", "2.png", "3.png", "4.png")
MCP_INFOGRAPHIC_MAX_WIDTHS = {"full": 1600, "1": 1400, "2": 1400, "3": 1400, "4": 1400}
AUTHOR_IMAGE_SOURCE = ROOT / "packaging" / "assets" / "author" / "jonathan-kyle-hobson.png"
AUTHOR_IMAGE_OUTPUT_DIR = "assets"
AUTHOR_IMAGE_FILENAME = "jonathan-kyle-hobson.png"
INSTALL_GUIDE_SOURCE = ROOT / "packaging" / "assets" / "install-guide"
INSTALL_GUIDE_OUTPUT_DIR = "install-guide"
INSTALL_GUIDE_GROUPS = {
    "plugin": [
        ("plugin-01-open-claude-code.png", "Open Claude Code or Claude Cowork.", "Claude Code or Claude Cowork open before plugin installation"),
        ("plugin-02-customize.png", "Open Customize from the left sidebar.", "Customize entry point in Claude Code or Claude Cowork"),
        ("plugin-03-personal-plugins.png", "Confirm you can see Personal Plugins.", "Customize screen showing Personal Plugins"),
        ("plugin-04-plus-hover.png", "Hover over the plus button until Add Plugin appears.", "Personal Plugins plus button hover state"),
        ("plugin-05-add-menu.png", "Click the plus button to open the plugin menu.", "Plugin add menu opened from Personal Plugins"),
        ("plugin-06-upload-plugin-menu.png", "Choose Create Plugin, then Upload Plugin.", "Create Plugin menu with Upload Plugin option"),
        ("plugin-07-upload-local-plugin.png", "Choose the local upload option.", "Upload local plugin screen"),
        ("plugin-08-drop-plugin-zip.png", "Drag in critical-compass-plugin.zip.", "Plugin upload area with drag and drop target"),
        ("plugin-09-installed.png", "Confirm Critical Compass appears as installed.", "Critical Compass plugin installed confirmation"),
    ],
    "mcpb": [
        ("mcpb-01-download.png", "Download the Critical Compass .mcpb file.", "Critical Compass MCPB file ready for install"),
        ("mcpb-02-open-settings.png", "Open Claude Desktop settings.", "Claude Desktop settings entry point"),
        ("mcpb-03-extensions.png", "Open the Extensions area if your build has it.", "Claude Desktop Extensions area"),
        ("mcpb-04-drop-file.png", "Drag the .mcpb file into the Extensions panel.", "MCPB drag and drop install area"),
        ("mcpb-05-installed.png", "Confirm the extension is installed.", "Critical Compass extension installed confirmation"),
    ],
    "skill": [
        ("skill-01-open-skills.png", "Open the Skills area.", "Claude Skills area before upload"),
        ("skill-02-plus-button.png", "Click the plus button.", "Skills plus button"),
        ("skill-03-upload-skill-menu.png", "Choose Create Skill, then Upload Skill.", "Create Skill menu with Upload Skill option"),
        ("skill-04-select-file.png", "Select critical-compass.skill or skill.zip.", "Skill file selection screen"),
        ("skill-05-installed.png", "Confirm Critical Compass is available as a skill.", "Critical Compass skill installed confirmation"),
    ],
}
AUTHOR_LINKEDIN_URL = "https://www.linkedin.com/in/jonathankylehobson/"
LEGAL_PACKAGE_FILES = (
    "LICENSE",
    "LICENSE-DOCS-CC-BY-SA-4.0.md",
    "NOTICE",
    "BRAND-AND-ATTRIBUTION.md",
    "THIRD_PARTY_NOTICES.md",
)
CLAUDE_ARTIFACT_URL = "https://claude.ai/public/artifacts/9e50e78b-3877-40c0-855b-07031eb15c95"
SHARED_FAVICON = "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 rx=%278%27 fill=%27%23f8fbf9%27/%3E%3Ccircle cx=%2732%27 cy=%2732%27 r=%2723%27 fill=%27none%27 stroke=%27%230f766e%27 stroke-width=%275%27/%3E%3Cpath d=%27M40 12 34 34 52 46 30 39z%27 fill=%27%23d95f43%27/%3E%3Cpath d=%27M24 52 30 30 12 18 34 25z%27 fill=%27%23527a39%27/%3E%3Ccircle cx=%2732%27 cy=%2732%27 r=%274%27 fill=%27%2317211f%27/%3E%3C/svg%3E"
SHARED_BADGE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 120'%3E%3Crect width='120' height='120' rx='16' fill='%23f8fbf9'/%3E%3Ccircle cx='60' cy='60' r='44' fill='none' stroke='%230f766e' stroke-width='8'/%3E%3Cpath d='M76 18 64 63 98 80 56 69z' fill='%23d95f43'/%3E%3Cpath d='M44 102 56 57 22 40 64 51z' fill='%23527a39'/%3E%3Ccircle cx='60' cy='60' r='7' fill='%2317211f'/%3E%3C/svg%3E"
SUITE_FOOTER_CSS = """
    .suite-footer-card {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.72);
      box-shadow: var(--shadow);
      padding: 22px;
    }
    .suite-footer-note { margin: 0 0 16px; padding: 0 0 16px; border-bottom: 1px solid var(--line); }
    .suite-footer-heading { margin: 0 0 4px; color: var(--ink); font-weight: 900; }
    .suite-footer-purpose,
    .suite-footer-legal { margin: 0; }
    .suite-footer-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 18px; margin: 18px 0; }
    .suite-footer-group h2 { margin: 0 0 8px; color: var(--ink); font-size: 0.94rem; }
    .suite-footer-links { display: grid; gap: 6px; }
    .suite-footer-links a { display: inline-flex; align-items: center; min-height: 44px; width: fit-content; max-width: 100%; overflow-wrap: anywhere; }
"""
SUITE_FOOTER_MOBILE_CSS = """
      .suite-footer-grid { grid-template-columns: 1fr; gap: 12px; }
"""
AI_INSTALL_PROMPT = """You are a careful, technically conservative AI install assistant. Your job is to help me add or install Critical Compass - optionally including the plugin, MCPB/Desktop extension, skill, or local MCP source - safely, without modifying unrelated configuration or introducing unexpected dependencies. Do not delete anything; only add.

Critical Compass is a critical-thinking toolbox for pressure-testing written work before publication or submission.

Release page: https://jonathankhobson.github.io/critical-compass/

PHASE 1 - Understand my environment
Before doing anything, ask me:
1. Which AI client are you using? (Claude Cowork, Claude Code, Claude Desktop, Codex, or other)
2. Which operating system are you on? (macOS, Windows, Linux, WSL, or other)
3. Have you installed any MCPs, plugins, or skills before? (yes / no / unsure)
4. What do you want added or installed? (local MCP source / plugin / MCPB Desktop extension / skill / all)

Do not proceed to Phase 2 until I answer all four questions.

PHASE 2 - Identify the right install path
Based on my answers, recommend the appropriate install path(s). Multiple paths can be installed together.

Install methods and what you can automate:
- Plugin zip - add/install support depends on the client. Download and inspect the plugin zip, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.
- MCPB/Desktop extension file - add/install support depends on the client. Download and inspect the MCPB file, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.
- Skill or skill zip - add/install support depends on the client. Download and inspect the skill file, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.
- Local MCP source zip - technical fallback only. Use it only if I have installed MCPs this way before or I explicitly confirm I want a config-based install after the UI paths fail.

Important distinction:
- Treat plugin, MCPB/Desktop extension, and skill upload as the preferred user paths when the visible UI supports them.
- For plugin, MCPB/Desktop extension, and skill files, do not assume the add/install method. Check the current client, current docs, local files, and visible UI. Do as much safely as you can, then guide me through any step that requires my action.
- Treat local MCP source and manual config edits as a technical fallback, not the beginner path.
- If the UI or install method has changed, use the current official docs or the client's visible UI rather than stale instructions.

For each path you recommend, state in one sentence what you can do automatically and what I may need to do manually. Ask me to confirm before proceeding.

PHASE 3 - Review before installing
Open the release page and identify the current version.
Download only the file(s) needed for the confirmed install path(s).
Before installing, check for:
- Unexpected network calls or external API dependencies
- Hidden API keys or credential requirements
- Suspicious scripts or broad file system access
- Unrelated services bundled in

If you find anything concerning, STOP. Describe the concern clearly and ask me how to proceed. Do not install until I confirm.

PHASE 4 - Install safely
For a local MCP source install:
- Prefer a stable local install folder and avoid running directly from a temporary download folder.
- Read existing config files before editing them.
- Preserve all unrelated MCP servers and settings.
- Back up any config file before changing it.
- Prefer a direct interpreter command with absolute paths instead of shell wrappers.
- If writing Claude Desktop JSON on Windows, write UTF-8 without a byte-order mark. Do not use Windows PowerShell 5.x Set-Content -Encoding UTF8 for the final config write.
- After writing, verify the first three bytes are not EF BB BF and verify every pre-existing mcpServers entry is still present.

Common config locations to check, then verify against current docs and the actual client:
- Claude Desktop on macOS: ~/Library/Application Support/Claude/claude_desktop_config.json
- Claude Desktop on Windows: %APPDATA%\\Claude\\claude_desktop_config.json
- Claude Desktop on Linux or unofficial builds: location may vary; check current docs and the app config directory before editing.
- Codex on macOS/Linux: ~/.codex/config.toml
- Codex on Windows: %USERPROFILE%\\.codex\\config.toml
- Claude Code project MCP config: .mcp.json in the workspace root

Known local-MCP troubleshooting rules:
- Existing Codex sessions usually do not hot-load new MCP config; start a fresh session after editing.
- Claude Desktop usually needs a full quit/reopen after config changes.
- For Codex, validate the config if a validator is available before restarting.
- For Claude Code, confirm the user opened the workspace root that contains .mcp.json.
- If files live on /Volumes or another external drive, avoid shell wrappers when possible and prefer a direct interpreter command.
- If Python behaves strangely on macOS external drives, check for AppleDouble sidecars such as ._* or .__* and consider keeping the runtime in a stable home-directory path while pointing it at the project/data.

For plugin, MCPB/Desktop extension, or skill installs:
- Do not hand-edit installed plugin, extension, or skill cache folders.
- Download and inspect the package, then determine the current add/install method for the user's client.
- If a UI step is required, guide me through it clearly and wait for me to confirm completion.
- If the expected UI path is missing, stop. Do not improvise in Connectors unless that surface clearly accepts the exact file type being installed.
- Do not add paid services, external APIs, provider keys, or unrelated servers unless I explicitly ask.

PHASE 5 - Smoke test
After installing, confirm Critical Compass is available:
- If you installed the local MCP source on Claude Desktop, Claude Code, or Codex, remind me to restart or start a fresh session before expecting the MCP to appear.
- If MCP tools are active: call get_started or critical_compass_overview.
- If I had other MCPs before install, confirm they are still present. If any disappeared, stop and restore from the pre-install backup.
- If only the skill is available: ask Critical Compass to pressure-test this sentence: "Our program has demonstrated significant impact across diverse communities."
- If install fails: tell me whether the issue is package validation, MCP launch, config syntax, missing dependency, wrong workspace root, client restart needed, or unsupported-client behavior - and suggest one concrete next step.

Constraints throughout:
- One phase at a time. Do not skip ahead.
- Ask rather than assume when uncertain.
- Prefer the most conservative option when two paths are equally valid.
- Preserve unrelated configuration. Do not delete anything; only add.
- Use current docs or visible client UI when the install method is unclear.
"""

FIRST_PROMPT_CARDS = [
    {
        "id": "skill-audit",
        "label": "Skill Audit",
        "when_to_use": "You have the Critical Compass skill installed and want a full audit without the MCP.",
        "prompt": textwrap.dedent(
            """\
            I have the Critical Compass skill installed.

            Before you begin the audit, ask me the following questions one at a time
            so you can calibrate your analysis:

            1. What type of content is this? (e.g., article, social post, study,
               speech, email, memo, draft I wrote)
            2. What domain does it fall under? (e.g., health, politics, AI, business,
               education, general)
            3. What was your relationship to this text - did you write it, read it,
               or receive it?
            4. What's your take going in - did anything already feel off, biased,
               or unsupported when you read it?
            5. What kind of feedback are you looking for - do you want to improve it,
               decide whether to trust it, share it, or act on it?

            After I answer, run a full Critical Compass audit using the skill. Return:
            - Critical Integrity Snapshot (plain-language read + five-dimension table)
            - Before Using This Text (one practical caution before I act on, share,
              or publish this)
            - Decision Read: Trust, Revise, Verify, or Reframe - one action with rationale
            - Top concerns (bias, fallacy, assumptions, evidence gaps) with confidence levels
            - What holds up
            - What would change your mind
            - 3 follow-up questions and 3 next steps

            Text to audit:
            \"\"\"
            [Paste the text, claim, article, or argument here.]
            \"\"\"
            """
        ).strip(),
    },
    {
        "id": "quick-audit-mcp",
        "label": "Quick Audit with MCP",
        "when_to_use": "You have the MCP connector or extension active and want a faster, knowledge-base-backed audit.",
        "prompt": textwrap.dedent(
            """\
            I have the Critical Compass MCP connector/extension active.

            Start by calling critical_compass_overview to orient yourself on the available
            tools and confirm the right path for a standard audit. You can also use
            quick_scan as part of your orientation if helpful.

            Then ask me these questions before running the audit:
            - What type of content is this?
            - What's the domain? (health / politics / AI / business / education / general)
            - Why are you auditing it - trust check, deciding to share, fact-checking,
              other?
            - Anything you already noticed that felt off?

            After I answer, run audit_text on the content below. Return:
            - Critical Integrity Snapshot (plain-language read + five-dimension table)
            - Before Using This Text
            - Decision Read: one primary action (Trust / Revise / Verify / Reframe)
              with one rationale sentence and one concrete next move
            - Top 3-5 concerns with match confidence and source confidence
            - What holds up
            - 3 follow-up questions and 3 next steps

            Content to audit:
            \"\"\"
            [Paste the text here.]
            \"\"\"
            """
        ).strip(),
    },
    {
        "id": "classroom-bias-audit",
        "label": "Classroom Bias Audit",
        "when_to_use": "You are using Critical Compass in a course or assignment and need stable section order for peer discussion.",
        "prompt": CLASSROOM_STANDARD_AUDIT_PROMPT,
    },
    {
        "id": "full-standard-audit-mcp",
        "label": "Full Standard Audit with MCP",
        "when_to_use": "You want a full structured audit with the MCP connector or extension, but not the multi-agent pipeline.",
        "prompt": textwrap.dedent(
            """\
            I have the Critical Compass MCP connector/extension active.

            Call critical_compass_overview first to confirm the right audit path and
            available tools for a full standard audit.

            Then ask me the following before running anything:
            - Content type: (article / study / policy doc / memo / email / post / other)
            - Domain: (health / politics / AI / business / research / education / general)
            - Your relationship to the text: did you write it, read it, or receive it?
            - Anything you already noticed that felt off, biased, or unsupported?
            - Stakes: what are you deciding - publish it, share it, act on it, cite it?
            - Sensitivity flag: does this touch health, identity, politics, religion,
              or legal topics? (yes / no / unsure)

            After I answer, run audit_text on the content below. Return the full audit:
            - Critical Integrity Snapshot (plain-language read + five-dimension table)
            - Before Using This Text
            - Decision Read: Trust / Revise / Verify / Reframe with rationale and
              one concrete next move
            - Top concerns with match confidence and source confidence
            - Argument map (if a central claim is present)
            - Assumptions (testable and not testable)
            - Evidence Needed Next
            - Reasoning Trap Checks (if visible cues exist)
            - Alternative frames (1-2)
            - What would change your mind
            - 3 follow-up questions and 3 next steps

            Content to audit:
            \"\"\"
            [Paste the full content here.]
            \"\"\"
            """
        ).strip(),
    },
    {
        "id": "advanced-audit-multi-agent",
        "label": "Advanced Audit with Multi-Agent Support",
        "when_to_use": "You want the full advanced pipeline with multi-agent support, human-in-the-loop pauses, and report-ready output.",
        "prompt": textwrap.dedent(
            """\
            I have the Critical Compass MCP connector/extension active.

            I want to run an advanced audit with multi-agent support and human-in-the-loop
            review on the content below. This is the full advanced audit pipeline, not
            a standard audit_text call.

            Step 1 - Orient: Call critical_compass_overview to confirm tools and routing
            for advanced audit mode.

            Step 2 - Define agents: Call define_audit_agents for this content. Before
            proceeding, show me the proposed analyst personas and pause for my approval.
            I want to be in the loop before any analysis runs.

            Step 3 - Independent analyses: Call run_independent_audit_analysis for each
            agent. Each analyst should work independently from its distinct perspective
            and use lookup_bias, challenge_claim, and get_framework as needed.

            Step 4 - Map tensions: Call map_audit_tensions to surface where agents
            disagree, where evidence is thin, and which findings could change the verdict.

            Step 5 - Structured debate: Call run_audit_debate on the highest-tension finding.

            Step 6 - Synthesize: Call synthesize_audit_verdict to produce a final verdict,
            confirm or revise the Critical Integrity Snapshot, and identify what holds
            across agents versus where genuine disagreement remains.

            Step 7 - Human-in-the-loop: Pause before report generation. Surface the
            human-loop questions from the audit pipeline and wait for my responses
            before proceeding.

            Step 8 - Report: After human-in-the-loop is complete, use the
            report_ready_payload from synthesize_audit_verdict, run
            validate_report_payload first, and only then call generate_audit_report
            with the validated audit data.

            The primary report output is a PDF. Tell me when the PDF is ready and provide
            the file path.

            If I also want a Markdown version, generate that alongside the PDF.

            If I want a browser-friendly version too, provide the generated viewer
            path or call generate_audit_artifact_viewer if a separate viewer is needed.

            Pause at every step where my judgment is needed. Do not proceed past a
            human-in-the-loop gate without my input.

            Content to audit:
            \"\"\"
            [Paste the full content here.]
            \"\"\"

            Context:
            - Content type: [article / study / policy doc / speech / report / other]
            - Domain: [health / politics / AI / business / research / other]
            - Why this matters: [e.g., about to publish / present / make a decision based on it]
            - Preferred agent types (optional): [leave blank to let the MCP select, or name lenses - e.g., policy analyst, methodologist, steelman advocate, community voice, missing-perspective reviewer]
            - Desired report outputs: [PDF only / PDF + Markdown / PDF + Markdown + viewer]
            """
        ).strip(),
    },
    {
        "id": "coaching-mode-skill",
        "label": "Coaching Mode (Skill Only)",
        "when_to_use": "You wrote the text and want help strengthening it without running a full audit.",
        "prompt": textwrap.dedent(
            """\
            I have the Critical Compass skill installed.

            I want coaching mode - not an audit of someone else's writing. I wrote
            this and I want help making it stronger, fairer, and more credible to a
            skeptical reader. Don't tear it apart - calibrate it.

            Before you start, ask me:
            1. Who is my intended audience?
            2. What am I trying to accomplish with this piece?
            3. What am I most uncertain or worried about in it?

            After I answer, use the Critical Compass coaching rewrite mode. Give me:
            - What holds up and should stay as-is
            - What's overclaimed or unsupported (and why)
            - A stronger version (clearer, more persuasive without overclaiming)
            - A more evidence-calibrated version (preserves my core point, signals
              what's known vs. uncertain)
            - The single most important revision to make first

            What I wrote:
            \"\"\"
            [Paste your draft, argument, post, or claim here.]
            \"\"\"

            My goal with this writing:
            \"\"\"
            [e.g., I'm trying to persuade my team / submit this as a proposal / post this publicly / use this in a report.]
            \"\"\"
            """
        ).strip(),
    },
]

GITHUB_DIR = SHARE_DIR / "github-pages"
GITHUB_DOWNLOADS = GITHUB_DIR / "downloads"
GITHUB_EXAMPLES = GITHUB_DIR / "examples"
GITHUB_KIT_ZIP = SHARE_DIR / "critical-compass-github-pages-kit.zip"

MANUAL_DIR = SHARE_DIR / "manual-share"
MANUAL_DOWNLOADS = MANUAL_DIR / "downloads"
MANUAL_EXAMPLES = MANUAL_DIR / "examples"
MANUAL_SHARE_ZIP = SHARE_DIR / "critical-compass-manual-share.zip"

DOWNLOAD_ARTIFACTS = [
    ("critical-compass-plugin.zip", PLUGIN_ZIP),
    ("critical-compass-0.1.0.mcpb", MCPB_FILE),
    ("critical-compass.skill", SKILL_FILE),
    ("skill.zip", SKILL_ZIP),
    ("critical-compass-source.zip", SOURCE_ZIP),
]

BAD_NAMES = {".DS_Store", "__pycache__"}
BAD_SUFFIXES = {".pyc", ".pyo"}
SOURCE_EXCLUDED_DIRS = {
    ".git",
    ".mypy_cache",
    ".playwright-cli",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "critical-compass-workspace",
    "dist",
    "evaluations",
    "incoming",
    "indexes",
    "normalized",
    "node_modules",
    "output",
    "reports",
    "test report data",
    "venv",
}
SOURCE_EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
EXAMPLE_REPLACEMENTS = [
    ("Nonprofit AI Policy Framework - Practitioner Tool Audit", EXAMPLE_TITLE),
    ("Nonprofit AI Policy Framework", "Redacted Nonprofit Policy Draft"),
    ("Sarah", "the author"),
    ("Let AI support, not replace, the relationships that define nonprofit impact", "[redacted source excerpt]"),
    ("That's not a compliance problem", "[redacted source excerpt]"),
    ("AI has fundamentally changed how decisions get made", "[redacted source excerpt]"),
    ("AI has changed how decisions, knowledge, trust, and risk work inside organizations", "[redacted source claim]"),
    ("Seven Failure Patterns", "redacted source pattern set"),
    ("Seven documented failure patterns show that compliance-first approaches don't work", "[redacted source claim]"),
    ("Five Shifts", "redacted source section"),
    ("What Makes This Different", "redacted source section"),
    ("Getting Started section", "redacted implementation section"),
    ("Getting Started", "redacted implementation section"),
    ("Eight Steps", "redacted source process"),
    ("Human Judgment principle", "redacted source principle"),
    ("Most staff don't understand where data goes when they use AI tools", "A factual claim from the draft about staff AI literacy"),
    ("In the nonprofit sector, trust erosion is an existential threat", "A causal claim from the draft about organizational trust"),
    (
        "AI policy is a change leadership problem disguised as a technology problem - and Canadian nonprofits need a mission-centered, capacity-aware governance framework rather than compliance checklists.",
        "The draft argues that responsible AI governance should be treated as an organizational change challenge, not only a technical or compliance task.",
    ),
    ("AI policy is a change leadership problem disguised as a technology problem", "Responsible AI governance is an organizational change challenge"),
]


def _skip_path(path: Path) -> bool:
    return (
        path.name.startswith("._")
        or path.name.startswith(".__")
        or path.name in BAD_NAMES
        or path.suffix in BAD_SUFFIXES
    )


def _remove_tree(path: Path) -> None:
    if path.exists():
        def onerror(_func, _path, exc_info):  # type: ignore[no-untyped-def]
            if exc_info and issubclass(exc_info[0], FileNotFoundError):
                return
            raise exc_info[1]

        shutil.rmtree(path, onerror=onerror)


def _clean_sidecars(base: Path) -> None:
    if not base.exists():
        return
    for path in sorted(base.rglob("*"), reverse=True):
        if _skip_path(path):
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
            else:
                path.unlink(missing_ok=True)


def _clear_xattrs(path: Path) -> None:
    if sys.platform != "darwin" or not path.exists():
        return
    subprocess.run(["xattr", "-c", str(path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _remove_sidecar_for(path)


def _remove_sidecar_for(path: Path) -> None:
    for prefix in ("._", ".__"):
        sidecar = path.with_name(prefix + path.name)
        if sidecar.exists():
            if sidecar.is_dir():
                shutil.rmtree(sidecar, ignore_errors=True)
            else:
                sidecar.unlink(missing_ok=True)


def _zip_directory(source_dir: Path, output_zip: Path, *, archive_root: str) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    if output_zip.exists():
        output_zip.unlink()
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(source_dir, archive_root + "/")
        for path in sorted(source_dir.rglob("*")):
            if _skip_path(path):
                continue
            arcname = Path(archive_root) / path.relative_to(source_dir)
            if path.is_dir():
                zf.write(path, str(arcname) + "/")
            else:
                zf.write(path, str(arcname))
    _clear_xattrs(output_zip)


def _zip_directory_contents(source_dir: Path, output_zip: Path) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    if output_zip.exists():
        output_zip.unlink()
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(source_dir.rglob("*")):
            if _skip_path(path):
                continue
            arcname = path.relative_to(source_dir)
            if path.is_dir():
                zf.write(path, str(arcname) + "/")
            else:
                zf.write(path, str(arcname))
    _clear_xattrs(output_zip)


def _skip_source_path(path: Path) -> bool:
    try:
        relative = path.relative_to(ROOT)
    except ValueError:
        return True
    if any(part in SOURCE_EXCLUDED_DIRS for part in relative.parts):
        return True
    if any(part.startswith("._") or part.startswith(".__") for part in relative.parts):
        return True
    if path.name in BAD_NAMES or path.name.startswith(".env"):
        return True
    if path.suffix in SOURCE_EXCLUDED_SUFFIXES:
        return True
    state_db_names = {"critical-compass-state.sqlite", "state.sqlite", "state.sqlite3", "state.db"}
    if path.name in state_db_names:
        return True
    return False


def _build_source_zip() -> None:
    SOURCE_ZIP.parent.mkdir(parents=True, exist_ok=True)
    if SOURCE_ZIP.exists():
        SOURCE_ZIP.unlink()
    with zipfile.ZipFile(SOURCE_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(ROOT, "critical-compass-source/")
        for path in sorted(ROOT.rglob("*")):
            if _skip_source_path(path):
                continue
            arcname = Path("critical-compass-source") / path.relative_to(ROOT)
            if path.is_dir():
                zf.write(path, str(arcname) + "/")
            else:
                zf.write(path, str(arcname))
    _clear_xattrs(SOURCE_ZIP)
    _remove_sidecar_for(SOURCE_ZIP)


def _sync_plugin_skill() -> None:
    if not STANDALONE_SKILL_SOURCE_DIR.exists():
        raise FileNotFoundError(f"Missing standalone skill source folder: {STANDALONE_SKILL_SOURCE_DIR}")
    target = PLUGIN_SOURCE_DIR / "skills" / "critical-compass"
    _remove_tree(target)
    shutil.copytree(STANDALONE_SKILL_SOURCE_DIR, target, ignore=shutil.ignore_patterns("._*", ".__*", ".DS_Store"))
    _clean_sidecars(target)


def _sync_plugin_legal_files() -> None:
    for filename in LEGAL_PACKAGE_FILES:
        source = ROOT / filename
        if not source.exists():
            raise FileNotFoundError(f"Missing legal/imprint file: {source}")
        shutil.copy2(source, PLUGIN_SOURCE_DIR / filename)
        _clear_xattrs(PLUGIN_SOURCE_DIR / filename)
        _remove_sidecar_for(PLUGIN_SOURCE_DIR / filename)


def _build_standalone_skill_artifacts() -> None:
    if not STANDALONE_SKILL_SOURCE_DIR.exists():
        raise FileNotFoundError(f"Missing standalone skill source folder: {STANDALONE_SKILL_SOURCE_DIR}")
    _zip_directory(STANDALONE_SKILL_SOURCE_DIR, SKILL_FILE, archive_root="critical-compass")
    _zip_directory_contents(STANDALONE_SKILL_SOURCE_DIR, SKILL_ZIP)
    shutil.copy2(SKILL_FILE, ROOT_SKILL_FILE)
    _clear_xattrs(ROOT_SKILL_FILE)
    _remove_sidecar_for(ROOT_SKILL_FILE)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy_artifacts(download_dir: Path) -> dict[str, str]:
    download_dir.mkdir(parents=True, exist_ok=True)
    checksums: dict[str, str] = {}
    for filename, source in DOWNLOAD_ARTIFACTS:
        if not source.exists():
            raise FileNotFoundError(f"Missing release artifact: {source}")
        target = download_dir / filename
        shutil.copy2(source, target)
        _clear_xattrs(target)
        _remove_sidecar_for(target)
        checksums[filename] = _sha256(target)
    (download_dir / "checksums.txt").write_text(_format_checksums(checksums), encoding="utf-8")
    return checksums


def _read_existing_checksums(download_dir: Path) -> dict[str, str]:
    checksum_path = download_dir / "checksums.txt"
    if checksum_path.exists():
        checksums: dict[str, str] = {}
        for line in checksum_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            digest, filename = line.split(None, 1)
            checksums[filename.strip()] = digest.strip()
        return checksums
    checksums = {}
    for filename, _source in DOWNLOAD_ARTIFACTS:
        artifact = download_dir / filename
        if not artifact.exists():
            raise FileNotFoundError(f"Missing generated download artifact: {artifact}")
        checksums[filename] = _sha256(artifact)
    checksum_path.write_text(_format_checksums(checksums), encoding="utf-8")
    return checksums


def _read_existing_plugin_manifest() -> dict:
    plugin_manifest = PLUGIN_SOURCE_DIR / ".claude-plugin" / "plugin.json"
    if plugin_manifest.exists():
        return json.loads(plugin_manifest.read_text(encoding="utf-8"))
    return {"version": "0.1.0-beta.11"}


def _suite_footer(note: str | None = None) -> str:
    note_html = f'\n      <p class="suite-footer-note">{html.escape(note)}</p>' if note else ""
    return f"""  <footer class="suite-footer" role="contentinfo">
    <div class="suite-footer-card">{note_html}
      <p class="suite-footer-heading">Compass Suite is created and maintained by Jonathan Kyle Hobson.</p>
      <p class="suite-footer-purpose">Local-first AI tools for reasoning, prompt work, UX review, and evidence-bound workflows.</p>
      <nav class="suite-footer-grid" aria-label="Compass network footer">
        <section class="suite-footer-group" aria-labelledby="footer-start-here">
          <h2 id="footer-start-here">Start Here</h2>
          <div class="suite-footer-links">
            <a href="https://jonathankhobson.github.io/compass-suite/">Compass Suite Home</a>
            <a href="https://jonathankhobson.github.io/compass-suite/#install">Install Guide</a>
            <a href="https://jonathankhobson.github.io/what-is-an-mcp/">MCP Basics</a>
          </div>
        </section>
        <section class="suite-footer-group" aria-labelledby="footer-public-compasses">
          <h2 id="footer-public-compasses">Public Compasses</h2>
          <div class="suite-footer-links">
            <a href="https://jonathankhobson.github.io/critical-compass/">Critical Compass</a>
            <a href="https://jonathankhobson.github.io/prompt-compass/">Prompt Compass</a>
            <a href="https://jonathankhobson.github.io/ux-heuristic-compass/">UX Heuristics Compass</a>
          </div>
        </section>
        <section class="suite-footer-group" aria-labelledby="footer-trust">
          <h2 id="footer-trust">Trust &amp; Attribution</h2>
          <div class="suite-footer-links">
            <a href="https://jonathankhobson.github.io/compass-suite/about/">About the Author</a>
            <a href="https://jonathankhobson.github.io/compass-suite/license/">License &amp; Attribution</a>
            <a href="https://www.linkedin.com/in/jonathankylehobson/" target="_blank" rel="noopener">LinkedIn</a>
          </div>
        </section>
      </nav>
      <p class="suite-footer-legal">&copy; 2026 Jonathan Kyle Hobson. Code AGPL-3.0-only; docs, prompts, skills, and methodology CC BY-SA 4.0 unless otherwise noted. Compass names, logos, author photo, and official trade dress reserved.</p>
    </div>
  </footer>"""


def _copy_examples(example_dir: Path) -> None:
    example_dir.mkdir(parents=True, exist_ok=True)
    for filename in (EXAMPLE_HTML, EXAMPLE_PDF, EXAMPLE_MARKDOWN, EXAMPLE_SCREENSHOT):
        source = PUBLIC_EXAMPLES_SOURCE / filename
        if not source.exists():
            raise FileNotFoundError(f"Missing public example artifact: {source}")
        target = example_dir / filename
        shutil.copy2(source, target)
        _clear_xattrs(target)
        _remove_sidecar_for(target)


def _normalize_rgb(image: Image.Image) -> Image.Image:
    if image.mode in {"RGBA", "LA"}:
        background = Image.new("RGB", image.size, (255, 255, 255))
        background.paste(image, mask=image.getchannel("A"))
        return background
    return image.convert("RGB")


def _resize_down(image: Image.Image, max_width: int) -> Image.Image:
    if image.width <= max_width:
        return image
    ratio = max_width / image.width
    target_size = (max_width, max(1, round(image.height * ratio)))
    resampling = getattr(Image, "Resampling", Image).LANCZOS
    return image.resize(target_size, resampling)


def _build_example_output_screenshot(output_path: Path) -> None:
    missing = [str(path) for path in RAW_EXAMPLE_SCREENSHOTS if not path.exists()]
    if missing:
        if output_path.exists():
            _clear_xattrs(output_path)
            _remove_sidecar_for(output_path)
            return
        raise FileNotFoundError(f"Missing Claude output screenshots used to build public example: {missing}")

    images: list[Image.Image] = []
    try:
        for path in RAW_EXAMPLE_SCREENSHOTS:
            with Image.open(path) as original:
                images.append(_normalize_rgb(original))

        target_width = max(image.width for image in images)
        total_height = sum(image.height for image in images)
        stitched = Image.new("RGB", (target_width, total_height), (255, 255, 255))
        offset = 0
        for image in images:
            stitched.paste(image, (0, offset))
            offset += image.height

        output_path.parent.mkdir(parents=True, exist_ok=True)
        stitched.save(output_path, "PNG", optimize=True)
        _clear_xattrs(output_path)
        _remove_sidecar_for(output_path)
    finally:
        for image in images:
            image.close()


def _build_mcp_infographic(target_dir: Path) -> dict[str, dict[str, object]]:
    infographic_dir = target_dir / MCP_INFOGRAPHIC_DIR_NAME
    _remove_tree(infographic_dir)
    infographic_dir.mkdir(parents=True, exist_ok=True)
    metadata: dict[str, dict[str, int | str]] = {}
    for filename in MCP_INFOGRAPHIC_FILES:
        source = MCP_INFOGRAPHIC_SOURCE / filename
        if not source.exists():
            raise FileNotFoundError(f"Missing MCP infographic image: {source}")
        stem = Path(filename).stem
        with Image.open(source) as original:
            image = _resize_down(_normalize_rgb(original), MCP_INFOGRAPHIC_MAX_WIDTHS[stem])
            webp_name = f"{stem}.webp"
            jpg_name = f"{stem}.jpg"
            webp_target = infographic_dir / webp_name
            jpg_target = infographic_dir / jpg_name
            image.save(webp_target, "WEBP", quality=82, method=6)
            image.save(jpg_target, "JPEG", quality=84, optimize=True, progressive=True)
            for target in (webp_target, jpg_target):
                _clear_xattrs(target)
                _remove_sidecar_for(target)
            metadata[stem] = {
                "webp": f"{MCP_INFOGRAPHIC_DIR_NAME}/{webp_name}",
                "jpg": f"{MCP_INFOGRAPHIC_DIR_NAME}/{jpg_name}",
                "width": image.width,
                "height": image.height,
            }
    return metadata


def _copy_author_assets(target_dir: Path) -> None:
    if not AUTHOR_IMAGE_SOURCE.exists():
        raise FileNotFoundError(f"Missing author image: {AUTHOR_IMAGE_SOURCE}")
    assets_dir = target_dir / AUTHOR_IMAGE_OUTPUT_DIR
    assets_dir.mkdir(parents=True, exist_ok=True)
    target = assets_dir / AUTHOR_IMAGE_FILENAME
    shutil.copy2(AUTHOR_IMAGE_SOURCE, target)
    _clear_xattrs(target)
    _remove_sidecar_for(target)


def _copy_install_guide_assets(target_dir: Path) -> None:
    install_dir = target_dir / INSTALL_GUIDE_OUTPUT_DIR
    _remove_tree(install_dir)
    install_dir.mkdir(parents=True, exist_ok=True)
    for group, screenshots in INSTALL_GUIDE_GROUPS.items():
        group_dir = install_dir / group
        group_dir.mkdir(parents=True, exist_ok=True)
        for filename, _caption, _alt in screenshots:
            source = INSTALL_GUIDE_SOURCE / group / filename
            if not source.exists():
                raise FileNotFoundError(f"Missing install-guide screenshot: {source}")
            target = group_dir / filename
            shutil.copy2(source, target)
            _clear_xattrs(target)
            _remove_sidecar_for(target)
    _clean_sidecars(install_dir)


def _format_checksums(checksums: dict[str, str]) -> str:
    return "".join(f"{digest}  {filename}\n" for filename, digest in sorted(checksums.items()))


def _replace_public_example_phrase(text: str, old: str, new: str) -> str:
    variants = {
        old,
        html.escape(old),
        html.escape(old, quote=True),
        old.replace("'", "&#x27;"),
        html.escape(old, quote=True).replace("&#x27;", "&apos;"),
    }
    for variant in sorted(variants, key=len, reverse=True):
        text = re.sub(re.escape(variant), new, text, flags=re.IGNORECASE)
    return text


def _sanitize_example_text(text: str) -> str:
    for old, new in EXAMPLE_REPLACEMENTS:
        text = _replace_public_example_phrase(text, old, new)
    text = re.sub(r"audit-report-20260417-182829[-\w.]*", "critical-compass-example-report", text, flags=re.IGNORECASE)
    text = re.sub(r"/Volumes/[^\"'<\s]+", "[redacted-local-path]", text)
    text = re.sub(r"(?m)^(\s*Where:\s*).+$", r"\1[redacted source excerpt]", text)
    text = re.sub(r"(?m)^(\s*Finding traced to:\s*).+$", r"\1[redacted source evidence; analysis retained]", text)
    text = re.sub(r"(?m)^(\s*Improvement prompt:\s*).+$", r"\1[redacted source-specific prompt; recommendation retained in summary]", text)
    text = re.sub(r"(?m)(Title:\s*).+$", rf"\1{EXAMPLE_TITLE}", text, count=1)
    return text


def _complete_public_fragment(value: str) -> str:
    marker_positions = [pos for marker in ("...", "…") if (pos := value.find(marker)) >= 0]
    if not marker_positions:
        return value
    return cap_complete_prose(value, max(24, min(marker_positions)))


def _complete_public_example_html_fragments(text: str) -> str:
    def replace_text_node(match: re.Match[str]) -> str:
        raw_text = html.unescape(match.group(1))
        leading_space = " " if raw_text[:1].isspace() else ""
        completed = _complete_public_fragment(raw_text)
        return f">{leading_space}{html.escape(completed)}<"

    return re.sub(r">([^<>]*(?:\.\.\.|…)[^<>]*)<", replace_text_node, text)


def _complete_public_example_markdown_fragments(text: str) -> str:
    completed_lines: list[str] = []
    for line in text.splitlines():
        if "..." not in line and "…" not in line:
            completed_lines.append(line)
            continue
        indent = line[: len(line) - len(line.lstrip())]
        completed_lines.append(f"{indent}{_complete_public_fragment(line.strip())}")
    return "\n".join(completed_lines) + ("\n" if text.endswith("\n") else "")


def _install_screenshot_list(group: str) -> str:
    screenshots = INSTALL_GUIDE_GROUPS[group]
    figure_html = []
    for index, (filename, caption, alt) in enumerate(screenshots, start=1):
        src = f"{INSTALL_GUIDE_OUTPUT_DIR}/{group}/{filename}"
        figure_html.append(
            f"""            <li>
              <figure class="install-step-shot">
                <img src="{html.escape(src)}" alt="{html.escape(alt)}" loading="lazy" decoding="async">
                <figcaption>Step {index}: {html.escape(caption)}</figcaption>
              </figure>
            </li>"""
        )
    return "\n".join(figure_html)


def _sanitize_example_html(raw_html: str) -> str:
    sanitized = _sanitize_example_text(raw_html)
    sanitized = re.sub(r'<body data-critical-compass="[^"]*">', "<body>", sanitized)
    if 'rel="icon"' not in sanitized:
        sanitized = sanitized.replace(
            "</title>",
            '</title>\n  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 rx=%278%27 fill=%27%23f7f8f9%27/%3E%3Ccircle cx=%2732%27 cy=%2732%27 r=%2722%27 fill=%27none%27 stroke=%27%233f6f9f%27 stroke-width=%275%27/%3E%3Cpath d=%27M39 14 33 35 15 42l16-14z%27 fill=%27%23b56f00%27/%3E%3C/svg%3E">',
            1,
        )
    sanitized = sanitized.replace("    .artifact-links div, .claim-item, .ledger-item, .trap-item {", "    .claim-item, .ledger-item, .trap-item {")
    sanitized = re.sub(r"\n    \.artifact-links a \{[^}]+\}", "", sanitized)
    sanitized = sanitized.replace(
        "    main {\n"
        "      display: grid;\n"
        "      grid-template-columns: minmax(180px, 240px) minmax(0, 920px);\n"
        "      gap: 28px;\n"
        "      padding: 24px 28px 56px;\n"
        "    }",
        "    main {\n"
        "      display: grid;\n"
        "      grid-template-columns: minmax(190px, 240px) minmax(0, 1fr);\n"
        "      gap: 28px;\n"
        "      max-width: 1180px;\n"
        "      margin: 0 auto;\n"
        "      padding: 24px 28px 56px;\n"
        "    }\n"
        "    main > div { min-width: 0; }",
    )
    sanitized = re.sub(
        r'\s*<section class="callout" id="public-example-note">.*?</section>',
        "",
        sanitized,
        flags=re.DOTALL,
    )
    sanitized = re.sub(
        r'\s*<h3>Artifacts</h3>\s*<div class="artifact-links">.*?</div>\s*</section>',
        "\n    </section>",
        sanitized,
        flags=re.DOTALL,
    )
    sanitized = sanitized.replace(
        '<p class="meta">Read-only Critical Compass artifact viewer · v1.0.0</p>',
        '<p class="meta">Read-only Critical Compass artifact viewer · public redacted example</p>\n'
        '    <div class="before-use" id="public-example-note">'
        f"<strong>Public example note:</strong> {html.escape(EXAMPLE_NOTE)}"
        "</div>\n"
        '    <p class="meta"><a href="https://jonathankhobson.github.io/critical-compass/">'
        "&larr; Back to Critical Compass download page"
        "</a></p>",
    )
    sanitized = _prune_missing_example_nav_links(sanitized)
    return _complete_public_example_html_fragments(sanitized)


def _prune_missing_example_nav_links(sanitized_html: str) -> str:
    ids = set(re.findall(r'id="([^"]+)"', sanitized_html))

    def prune_nav(match: re.Match[str]) -> str:
        nav_html = match.group(0)

        def prune_link(link_match: re.Match[str]) -> str:
            target_id = link_match.group(1)
            return link_match.group(0) if target_id in ids else ""

        return re.sub(r'<a href="#([^"]+)">[^<]+</a>', prune_link, nav_html)

    return re.sub(r'<nav aria-label="Artifact sections">.*?</nav>', prune_nav, sanitized_html, flags=re.DOTALL)


def _sanitize_example_markdown(raw_markdown: str, *, complete_fragments: bool = True) -> str:
    sanitized = _sanitize_example_text(raw_markdown)
    if EXAMPLE_NOTE not in sanitized:
        sanitized = sanitized.replace(
            "# Critical Integrity Report\n",
            f"# {EXAMPLE_TITLE}\n\n> {EXAMPLE_NOTE}\n\n",
            1,
        )
    if complete_fragments:
        return _complete_public_example_markdown_fragments(sanitized)
    return sanitized


def _build_public_examples() -> None:
    if not RAW_EXAMPLE_HTML.exists() or not RAW_EXAMPLE_MARKDOWN.exists() or not RAW_EXAMPLE_PDF.exists():
        raise FileNotFoundError("Missing raw report example files used to build public examples.")
    PUBLIC_EXAMPLES_SOURCE.mkdir(parents=True, exist_ok=True)
    html_text = _sanitize_example_html(RAW_EXAMPLE_HTML.read_text(encoding="utf-8"))
    raw_markdown = RAW_EXAMPLE_MARKDOWN.read_text(encoding="utf-8")
    markdown_text = _sanitize_example_markdown(raw_markdown)
    (PUBLIC_EXAMPLES_SOURCE / EXAMPLE_HTML).write_text(html_text, encoding="utf-8")
    (PUBLIC_EXAMPLES_SOURCE / EXAMPLE_MARKDOWN).write_text(markdown_text, encoding="utf-8")
    shutil.copy2(RAW_EXAMPLE_PDF, PUBLIC_EXAMPLES_SOURCE / EXAMPLE_PDF)
    _build_example_output_screenshot(PUBLIC_EXAMPLES_SOURCE / EXAMPLE_SCREENSHOT)
    _clean_sidecars(PUBLIC_EXAMPLES_SOURCE)


def _validate_plugin_zip(path: Path) -> dict:
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        roots = sorted({name.split("/", 1)[0] for name in names if "/" in name})
        if roots != ["critical-compass-plugin"]:
            raise RuntimeError(f"Plugin zip must contain one top-level critical-compass-plugin folder, got {roots}")
        manifest = json.loads(zf.read("critical-compass-plugin/.claude-plugin/plugin.json"))
        agent_files = [
            name for name in names if name.startswith("critical-compass-plugin/agents/") and name.endswith(".md")
        ]
        if len(agent_files) != 5:
            raise RuntimeError(f"Expected 5 agent files in plugin zip, got {len(agent_files)}")
        for name in agent_files:
            frontmatter = zf.read(name).decode("utf-8").split("---", 2)[1]
            for required in ["name:", "description: >", "model:", "color:"]:
                if required not in frontmatter:
                    raise RuntimeError(f"{name} missing strict agent frontmatter field: {required}")
            if "<example>" in frontmatter:
                raise RuntimeError(f"{name} contains loose example markup in YAML frontmatter")
    return manifest


def _assert_clean_output(path: Path) -> None:
    offenders: list[str] = []
    if path.is_dir():
        for item in path.rglob("*"):
            if _skip_path(item):
                offenders.append(str(item.relative_to(path)))
    else:
        with zipfile.ZipFile(path) as zf:
            for name in zf.namelist():
                parts = Path(name).parts
                if (
                    any(part.startswith("._") or part.startswith(".__") for part in parts)
                    or any(part in BAD_NAMES for part in parts)
                    or Path(name).suffix in BAD_SUFFIXES
                ):
                    offenders.append(name)
    if offenders:
        raise RuntimeError(f"Forbidden files included in {path}: {offenders}")


def _build_plugin_zip() -> dict:
    if not PLUGIN_SOURCE_DIR.exists():
        raise FileNotFoundError(f"Missing plugin source folder: {PLUGIN_SOURCE_DIR}")
    _sync_plugin_skill()
    _sync_plugin_legal_files()
    stage_bundle(PLUGIN_SOURCE_DIR / "mcp")
    _clean_sidecars(PLUGIN_SOURCE_DIR)
    _zip_directory(PLUGIN_SOURCE_DIR, PLUGIN_ZIP, archive_root="critical-compass-plugin")
    return _validate_plugin_zip(PLUGIN_ZIP)


def _mcp_picture(image_meta: dict[str, dict[str, object]], stem: str, alt: str, *, eager: bool = False) -> str:
    meta = image_meta[stem]
    loading = "eager" if eager else "lazy"
    priority = ' fetchpriority="high"' if eager else ""
    return (
        f'<picture>'
        f'<source srcset="{html.escape(str(meta["webp"]))}" type="image/webp">'
        f'<img src="{html.escape(str(meta["jpg"]))}" alt="{html.escape(alt)}" '
        f'width="{int(meta["width"])}" height="{int(meta["height"])}" '
        f'loading="{loading}" decoding="async"{priority}>'
        f'</picture>'
    )


def _mcp_explainer_redirect_page() -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>What is an MCP?</title>
  <link rel="canonical" href="{MCP_EXPLAINER_PUBLIC_URL}">
  <meta http-equiv="refresh" content="0; url={MCP_EXPLAINER_PUBLIC_URL}">
  <style>
    /* compass-public-visual-system: uxhc-v1 */
    :root {{
      color-scheme: light;
      --bg: #f7faf7;
      --paper: #ffffff;
      --ink: #17211f;
      --muted: #5f6f6a;
      --teal: #0f766e;
      --teal-dark: #0b5f59;
      --coral: #d95f43;
      --leaf: #527a39;
      --gold: #d99c2b;
      --line: #d9e5df;
      --soft: #eef6f1;
      --shadow: 0 18px 50px rgba(23, 33, 31, 0.08);
    }}
    * {{ box-sizing: border-box; }}
    html {{ scroll-behavior: smooth; }}
    body {{
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--ink);
      background:
        linear-gradient(180deg, rgba(15, 118, 110, 0.06), transparent 340px),
        var(--bg);
      line-height: 1.58;
      letter-spacing: 0;
    }}
    a {{ color: var(--teal-dark); font-weight: 700; }}
    a:focus-visible,
    button:focus-visible,
    summary:focus-visible {{
      outline: 3px solid rgba(217, 95, 67, 0.35);
      outline-offset: 3px;
    }}
    header, main, footer {{ width: min(1120px, calc(100% - 32px)); margin: 0 auto; }}
    header {{ padding: 44px 0 24px; display: grid; gap: 20px; }}
    .brand {{ display: flex; align-items: center; gap: 18px; }}
    .brand img {{ width: 86px; height: 86px; border-radius: 8px; border: 1px solid var(--line); box-shadow: var(--shadow); }}
    h1, h2, h3, p {{ margin-top: 0; }}
    h1 {{ margin-bottom: 12px; font-size: clamp(2rem, 4vw, 4rem); line-height: 1.02; letter-spacing: 0; }}
    h2 {{ font-size: 1.45rem; line-height: 1.2; margin-bottom: 10px; }}
    h3 {{ font-size: 1.05rem; }}
    p {{ margin-bottom: 12px; }}
    .lead {{ max-width: 880px; margin: 0; color: var(--muted); font-size: 1.18rem; }}
    .header-actions {{ display: flex; flex-wrap: wrap; gap: 8px; }}
    .header-actions .button {{ margin: 0; }}
    .tag {{
      display: inline-flex;
      align-items: center;
      width: fit-content;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 6px 10px;
      background: var(--soft);
      color: var(--teal-dark);
      font-weight: 800;
      font-size: 0.83rem;
    }}
    .tab-nav {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin: 10px 0 22px;
      border-bottom: 1px solid var(--line);
    }}
    .tab-nav button {{
      appearance: none;
      border: 1px solid var(--line);
      border-bottom: 0;
      border-radius: 8px 8px 0 0;
      padding: 12px 15px;
      background: #edf5f0;
      color: var(--ink);
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }}
    .tab-nav button[aria-selected="true"] {{ background: var(--paper); color: var(--teal-dark); box-shadow: 0 -3px 0 var(--coral) inset; }}
    .tab-panel[hidden] {{ display: none; }}
    .tab-panel {{ animation: fade 160ms ease-out; }}
    @keyframes fade {{ from {{ opacity: 0; transform: translateY(4px); }} to {{ opacity: 1; transform: translateY(0); }} }}
    section {{ padding: 20px 0; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 18px; }}
    .card, details.card {{
      margin: 0 0 18px;
      padding: 22px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--paper);
      box-shadow: var(--shadow);
    }}
    .tab-panel > .card,
    .tab-panel > details.card {{ margin: 0 0 18px; }}
    .card p:last-child,
    .card ol:last-child,
    .card ul:last-child,
    .card table:last-child,
    .card textarea:last-child {{ margin-bottom: 0; }}
    .notice {{ border-left: 4px solid var(--gold); }}
    .button {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 44px;
      margin: 4px 8px 4px 0;
      border: 1px solid var(--teal);
      border-radius: 8px;
      padding: 11px 15px;
      background: var(--teal);
      color: #fff;
      font: inherit;
      font-weight: 800;
      text-decoration: none;
      cursor: pointer;
    }}
    .button.secondary {{ border-color: var(--coral); background: var(--coral); }}
    .button.ghost,
    .button.quiet {{ background: transparent; color: var(--teal-dark); }}
    .button.disabled,
    .button:disabled {{ border-color: #a9b8b2; background: #e4ebe7; color: #5e6f68; cursor: not-allowed; }}
    ol, ul {{ padding-left: 22px; }}
    li {{ margin: 0 0 8px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
    td, th {{ border-top: 1px solid var(--line); padding: 12px; text-align: left; vertical-align: top; }}
    code {{
      overflow-wrap: anywhere;
      padding: 2px 5px;
      border-radius: 6px;
      background: #edf5f0;
      color: var(--teal-dark);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size: 0.93em;
    }}
    textarea {{
      width: 100%;
      min-height: 260px;
      resize: vertical;
      margin-top: 12px;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 14px;
      background: #fbfdfb;
      color: var(--ink);
      font: 0.94rem/1.52 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    }}
    .prompt-card textarea {{ min-height: 330px; }}
    .author-card {{ display: grid; grid-template-columns: 112px 1fr; gap: 20px; align-items: start; }}
    .author-photo {{ width: 112px; height: 112px; object-fit: cover; border-radius: 8px; border: 1px solid var(--line); }}
    .about-link {{ margin: 0 0 24px; }}
    .section-heading {{ margin: 0 0 18px; padding: 0; }}
    .tool-breakdown {{ margin: 16px 0 0; }}
    .tool-breakdown dt {{ margin: 14px 0 6px; font-weight: 800; }}
    .tool-breakdown dd {{ margin: 0; padding: 12px; border: 1px solid var(--line); border-radius: 8px; background: #fbfdfb; }}
    .example-lead {{ max-width: 780px; color: var(--muted); font-size: 1.04rem; }}
    .example-quote {{ margin: 12px 0 16px; padding: 14px 16px; border-left: 4px solid var(--coral); background: #fff7f4; border-radius: 8px; color: var(--ink); }}
    .example-actions {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0 0; }}
    .example-output {{ margin: 0 0 18px; }}
    .example-output-image {{ display: block; width: 100%; height: auto; border: 1px solid var(--line); border-radius: 8px; background: #fff; box-shadow: var(--shadow); }}
    .example-caption {{ margin-top: 8px; color: var(--muted); font-size: 0.92rem; }}
    .install-warning {{ border-left-color: var(--coral); }}
    .install-walkthrough {{ display: grid; gap: 18px; margin: 16px 0 0; padding: 0; list-style: none; }}
    .install-walkthrough li {{ margin: 0; }}
    .install-step-shot {{ margin: 0; }}
    .install-step-shot img {{ display: block; width: 100%; height: auto; border: 1px solid var(--line); border-radius: 8px; background: #fff; box-shadow: 0 12px 36px rgba(23, 33, 31, 0.1); }}
    .install-step-shot figcaption {{ margin-top: 8px; color: var(--muted); font-size: 0.93rem; }}
    .install-subnote {{ margin: 10px 0 0; color: var(--muted); font-size: 0.94rem; }}
    .footer-author {{ margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--line); }}
    details {{ border: 1px solid var(--line); border-radius: 8px; padding: 14px; background: #fbfdfb; }}
    summary {{ font-weight: 800; cursor: pointer; }}
{SUITE_FOOTER_CSS}
    footer {{ padding: 28px 0 44px; color: var(--muted); }}
    @media (max-width: 720px) {{
      header, main, footer {{ width: min(100% - 24px, 1120px); }}
      header {{ padding-top: 32px; }}
      .brand {{ align-items: flex-start; }}
      .brand img {{ width: 64px; height: 64px; }}
      .tab-nav {{ gap: 6px; }}
      .tab-nav button {{ flex: 1 1 140px; border-radius: 8px; border: 1px solid var(--line); }}
      .author-card {{ grid-template-columns: 1fr; }}
      .author-photo {{ width: 88px; height: 88px; }}
      td, th {{ display: block; width: 100%; }}
{SUITE_FOOTER_MOBILE_CSS}
    }}
  </style>
</head>
<body>
  <p>The MCP explainer has moved to <a href="{MCP_EXPLAINER_PUBLIC_URL}">{MCP_EXPLAINER_PUBLIC_URL}</a>.</p>
</body>
</html>
"""


def _mcp_explainer_page(image_meta: dict[str, dict[str, object]]) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>What is an MCP?</title>
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 rx=%278%27 fill=%27%23f8fbf9%27/%3E%3Ccircle cx=%2732%27 cy=%2732%27 r=%2723%27 fill=%27none%27 stroke=%27%230f766e%27 stroke-width=%275%27/%3E%3Cpath d=%27M39 14 33 35 15 42l16-14z%27 fill=%27%23d95f43%27/%3E%3C/svg%3E">
  <style>
    :root {{
      color-scheme: light;
      --ink: #17211f;
      --muted: #54615e;
      --paper: #f8fbf9;
      --line: #cbd8d3;
      --teal: #0f766e;
      --coral: #d95f43;
      --leaf: #527a39;
      --gold: #b7791f;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: var(--paper);
      color: var(--ink);
      line-height: 1.55;
      letter-spacing: 0;
    }}
    header, main, footer {{ width: min(1040px, calc(100% - 32px)); margin: 0 auto; }}
    header {{ padding: 44px 0 18px; display: grid; gap: 18px; }}
    h1 {{ margin: 0; font-size: 2.35rem; line-height: 1.1; }}
    h2 {{ margin: 0 0 10px; font-size: 1.35rem; }}
    h3 {{ margin: 0 0 8px; font-size: 1rem; }}
    p {{ margin: 0 0 12px; }}
    a {{ color: var(--teal); font-weight: 700; }}
    .lead {{ max-width: 780px; color: var(--muted); font-size: 1.08rem; }}
    .card {{ border: 1px solid var(--line); border-left: 4px solid var(--teal); border-radius: 8px; padding: 20px; background: #fff; margin: 0 0 20px; }}
    .notice {{ border-left-color: var(--gold); }}
    .risk {{ border-left-color: var(--coral); }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }}
    .button {{
      display: inline-block;
      margin: 6px 8px 0 0;
      padding: 10px 13px;
      border-radius: 8px;
      background: var(--teal);
      color: #fff;
      text-decoration: none;
      font-weight: 700;
    }}
    .button.secondary {{ background: var(--coral); }}
    .tag {{ display: inline-block; color: #fff; background: var(--teal); border-radius: 8px; padding: 4px 8px; font-size: .85rem; }}
    section {{ padding: 16px 0; }}
    img {{ display: block; width: 100%; height: auto; border: 1px solid var(--line); border-radius: 8px; background: #fff; }}
    figure {{ margin: 0 0 20px; }}
    figcaption {{ color: var(--muted); font-size: .9rem; margin-top: 8px; }}
    ol, ul {{ padding-left: 22px; }}
{SUITE_FOOTER_CSS}
    footer {{ padding: 28px 0 44px; color: var(--muted); }}
    @media (max-width: 720px) {{
      header, main, footer {{ width: min(100% - 24px, 1040px); }}
{SUITE_FOOTER_MOBILE_CSS}
    }}
  </style>
</head>
<body>
  <header>
    <span class="tag">Plain-language MCP explainer</span>
    <h1>What is an MCP?</h1>
    <p class="lead">MCP stands for <strong>Model Context Protocol</strong>. It is a shared way for an AI assistant to connect to tools, files, and structured knowledge without custom wiring every time.</p>
    <p><a class="button" href="https://jonathankhobson.github.io/compass-suite/">Back to Compass Suite</a></p>
    <p><a href="#short-version">Keep scrolling &darr;</a></p>
  </header>
  <main>
    <section id="short-version" class="card">
      <h2>The Short Version</h2>
      <p>Think of an MCP as giving AI a <strong>toolbox</strong> and a <strong>filing cabinet</strong> in the same room. The toolbox is what the AI can do. The filing cabinet is what the AI can find.</p>
      <p>Depending on the app, you may see the same idea called an <strong>MCP</strong>, <strong>connector</strong>, or <strong>extension</strong>. Those words can mean slightly different things in different products, but here they all point to the same basic idea: a trusted connection between an AI assistant and a useful local or remote capability.</p>
    </section>

    <section class="grid">
      <div class="card">
        <h2>Toolbox</h2>
        <p>The toolbox side lets AI take actions through approved tools. That might mean creating a PDF, searching an index, summarizing a file, checking a local database, or preparing a report.</p>
      </div>
      <div class="card">
        <h2>Filing Cabinet</h2>
        <p>The filing cabinet side gives AI organized information to look through. Instead of guessing from a giant pile of text, it can move from category to subcategory to record to answer.</p>
      </div>
    </section>

    <section class="card">
      <h2>1. Before MCP: Isolated Brilliance</h2>
      <figure>
        {_mcp_picture(image_meta, "1", "AI isolated from tools and documents before MCP")}
      </figure>
      <p>Before MCP, every connection between an AI assistant and a tool often needed custom code. That made useful integrations expensive, fragile, and hard for regular people to install or trust.</p>
    </section>

    <section class="card">
      <h2>2. MCP Creates a Shared Room</h2>
      <figure>
        {_mcp_picture(image_meta, "2", "MCP as AI toolbox and filing cabinet connected to records and tools")}
      </figure>
      <p>An MCP creates a shared room where the AI can see what tools and information are available. The AI still needs permission and a clear task, but it no longer has to guess where everything lives.</p>
    </section>

    <section class="card">
      <h2>3. Precise Navigation, Not Guessing</h2>
      <figure>
        {_mcp_picture(image_meta, "3", "AI moving from category to subcategory to record to answer")}
      </figure>
      <p>A good MCP helps the AI narrow the search. It can move from a broad category to a specific record, like a librarian finding the right shelf, folder, page, and answer.</p>
    </section>

    <section class="card">
      <h2>4. Real-World Power</h2>
      <figure>
        {_mcp_picture(image_meta, "4", "MCP examples including spreadsheets, meeting agendas, and complex reports")}
      </figure>
      <p>That connection lets AI do practical work: summarize spreadsheets, find meeting details, review reports, create tasks, generate documents, or use a specialized Compass tool.</p>
    </section>

    <section>
      <figure>
        {_mcp_picture(image_meta, "full", "Full infographic explaining MCP as giving AI the keys to the office")}
        <figcaption>The whole picture after the pieces: MCP helps AI move from isolated answers to connected action.</figcaption>
      </figure>
    </section>

    <section id="mcp-risks" class="card risk">
      <h2>MCP Risks: What to Watch For</h2>
      <p>MCPs can be local or remote, and they are powerful because they can give an AI access to tools or selected information. That is why you should treat an unknown MCP like any downloaded software or connected service.</p>
      <p>Possible risks include malicious code, unexpected file access, hidden external API calls, broad permissions, or prompt injection inside connected files and tools. Install MCPs only from trusted sources, and review what they can access before using them on private or sensitive work.</p>
      <ul>
        <li>Check whether the MCP runs locally, connects to a remote server, or does both.</li>
        <li>Look for API keys, paid services, broad file access, or unexpected network calls.</li>
        <li>Ask Claude, Codex, or a trusted technical reviewer to inspect the files if you are unsure.</li>
        <li>Prefer clear, narrow tools that explain what they access and why.</li>
      </ul>
    </section>

    <section class="card">
      <h2>Diving Deeper: What files might I see inside an MCP?</h2>
      <p>An MCP package can look strange if you are not used to developer files. These are common file types and what they usually mean:</p>
      <ul>
        <li><strong><code>.json</code></strong>: settings, manifests, tool definitions, or structured data.</li>
        <li><strong><code>.yaml</code> / <code>.yml</code></strong>: configuration written in a human-readable format.</li>
        <li><strong><code>.py</code>, <code>.ts</code>, <code>.js</code></strong>: code that may run MCP tools.</li>
        <li><strong><code>.md</code></strong>: instructions, documentation, prompts, or reference text.</li>
        <li><strong><code>.csv</code></strong>: spreadsheet-like table data.</li>
        <li><strong><code>.sql</code>, <code>.sqlite</code>, <code>.db</code></strong>: database queries or bundled local databases and indexes.</li>
        <li><strong><code>.env</code></strong>: secret or machine-specific settings. Public bundles should not include these.</li>
      </ul>
    </section>

    <section class="card">
      <h2>Quick FAQ</h2>
      <h3>Can an MCP be local or remote?</h3>
      <p>Yes. Some MCPs run on your computer through stdio. Others connect over HTTP to a remote server. Some products support both patterns.</p>
      <h3>Is an MCP the same as a plugin or skill?</h3>
      <p>No. An MCP is the tool-and-context connection. A plugin can bundle MCPs, skills, and other pieces together. A skill is usually instructions or reference material the AI can read.</p>
      <h3>What should I check before installing one?</h3>
      <p>Check the source, what files it can access, whether it makes network calls, whether it needs secrets or API keys, and whether sensitive actions require your confirmation.</p>
      <p>For technical readers, the official MCP docs describe JSON/schema-based messages, tools, resources, HTTP authorization, and stdio transport behavior: <a href="https://modelcontextprotocol.io/specification/draft/basic">MCP basics</a> and <a href="https://modelcontextprotocol.io/specification/draft/server/tools">MCP tools</a>.</p>
    </section>

    <section class="card notice">
      <h2>How This Applies to the Compass Suite</h2>
      <p>The Compass Suite uses the MCP idea to give AI focused local toolboxes and bundled filing cabinets for specific kinds of work. Each Compass keeps its own scope: Critical Compass audits claims and reasoning, Prompt Compass improves prompts, UX Heuristics Compass reviews interfaces, and future Compasses add their own bounded capabilities.</p>
      <p><a class="button secondary" href="https://jonathankhobson.github.io/compass-suite/">Return to Compass Suite</a></p>
    </section>
  </main>
{_suite_footer("Educational support for the Compass Suite. This page does not change install files or create a new release.")}
</body>
</html>
"""


def _html_page(*, title: str, manual: bool, manifest: dict, checksums: dict[str, str]) -> str:
    raw_version = str(manifest.get("version", "unknown"))
    plugin_version = html.escape(raw_version)
    checksum_rows = "\n".join(
        f"<tr><td>{html.escape(filename)}</td><td><code>{digest}</code></td></tr>"
        for filename, digest in sorted(checksums.items())
    )
    first_prompt_cards = "\n".join(
        f"""        <div class="card">
          <h2>{html.escape(card["label"])}</h2>
          <p><strong>When to use:</strong> {html.escape(card["when_to_use"])}</p>
          <button class="button secondary" type="button" id="copy-{card["id"]}">Copy prompt</button>
          <textarea id="prompt-{card["id"]}" readonly>{html.escape(card["prompt"])}</textarea>
        </div>"""
        for card in FIRST_PROMPT_CARDS
    )
    prompt_copy_wiring = "\n".join(
        f'    wireCopyButton("copy-{card["id"]}", "prompt-{card["id"]}");'
        for card in FIRST_PROMPT_CARDS
    )
    tool_breakdown = "\n".join(
        f"""        <dt><code>{html.escape(name)}</code></dt>
        <dd>
          <p>{html.escape(description)}</p>
          <p><strong>Say:</strong> &ldquo;{html.escape(example)}&rdquo;</p>
        </dd>"""
        for name, description, example in [
            (
                "get_started",
                "First-session onboarding: clarifies goal, intended audience, and audit depth, then routes to the right tool.",
                "I'm new - help me get started with Critical Compass.",
            ),
            (
                "critical_compass_overview",
                "Friendly map of workflows, routing rules, case examples, and starter prompts.",
                "Give me an overview of Critical Compass.",
            ),
            (
                "quick_scan",
                "Lightweight gut-check with a Critical Integrity Snapshot, top risks, key tension, and one next action.",
                "Quick-scan this text before I decide whether it needs a full audit.",
            ),
            (
                "audit_text",
                "Full audit for assumptions, bias patterns, evidence gaps, argument structure, check-worthy claims, alternative frames, and audience fit.",
                "Run a full Critical Compass audit on this text.",
            ),
            (
                "advanced_audit",
                "High-stakes multi-perspective review with analyst roles, tension mapping, debate, dissent, and synthesis.",
                "Run an advanced audit on this draft.",
            ),
            (
                "lookup_bias / get_framework / search_knowledge_base",
                "Knowledge-base lookup tools for verified bias definitions, thinking lenses, frameworks, and reasoning flows.",
                "Search Critical Compass for this concept before citing it.",
            ),
            (
                "save_audit_result / compare_audit_results",
                "Saved-result tools for longitudinal review, score comparison, bias changes, and framing-drift scaffolding.",
                "Save this audit result, then compare it to the revised version.",
            ),
            (
                "validate_report_payload",
                "Read-only dry run for report schema, field constraints, renderer diagnostics, and preflight blockers before rendering.",
                "Validate this report payload before generating the PDF.",
            ),
            (
                "generate_audit_report",
                "Turns completed audit data into a stakeholder-ready PDF, Markdown file, manifest, and local viewer.",
                "Generate a PDF report from this completed audit.",
            ),
        ]
    )
    diagnostics_prompt = html.escape(DIAGNOSTIC_PROMPT.read_text(encoding="utf-8"))
    ai_install_prompt = html.escape(AI_INSTALL_PROMPT)
    plugin_screenshots = _install_screenshot_list("plugin")
    mcpb_screenshots = _install_screenshot_list("mcpb")
    skill_screenshots = _install_screenshot_list("skill")
    release_url = f"https://github.com/JonathanKHobson/critical-compass/releases/tag/v{raw_version}"
    download_base = "downloads/" if manual else f"https://github.com/JonathanKHobson/critical-compass/releases/download/v{raw_version}/"
    plugin_href = html.escape(download_base + "critical-compass-plugin.zip")
    desktop_href = html.escape(download_base + "critical-compass-0.1.0.mcpb")
    skill_href = html.escape(download_base + "critical-compass.skill")
    skill_zip_href = html.escape(download_base + "skill.zip")
    source_href = html.escape(download_base + "critical-compass-source.zip")
    favicon_href = html.escape(SHARED_FAVICON)
    badge_src = html.escape(SHARED_BADGE)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <link rel="icon" href="{favicon_href}">
  <style>
    /* compass-public-visual-system: uxhc-v1 */
    :root {{
      color-scheme: light;
      --bg: #f7faf7;
      --paper: #ffffff;
      --ink: #17211f;
      --muted: #5f6f6a;
      --teal: #0f766e;
      --teal-dark: #0b5f59;
      --coral: #d95f43;
      --leaf: #527a39;
      --gold: #d99c2b;
      --line: #d9e5df;
      --soft: #eef6f1;
      --shadow: 0 18px 50px rgba(23, 33, 31, 0.08);
    }}
    * {{ box-sizing: border-box; }}
    html {{ scroll-behavior: smooth; }}
    body {{
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--ink);
      background:
        linear-gradient(180deg, rgba(15, 118, 110, 0.06), transparent 340px),
        var(--bg);
      line-height: 1.58;
      letter-spacing: 0;
    }}
    a {{ color: var(--teal-dark); font-weight: 700; }}
    a:focus-visible,
    button:focus-visible,
    summary:focus-visible {{
      outline: 3px solid rgba(217, 95, 67, 0.35);
      outline-offset: 3px;
    }}
    header, main, footer {{ width: min(1120px, calc(100% - 32px)); margin: 0 auto; }}
    header {{ padding: 44px 0 24px; display: grid; gap: 20px; }}
    .brand {{ display: flex; align-items: center; gap: 18px; }}
    .brand img {{ width: 86px; height: 86px; border-radius: 8px; border: 1px solid var(--line); box-shadow: var(--shadow); }}
    h1, h2, h3, p {{ margin-top: 0; }}
    h1 {{ margin-bottom: 12px; font-size: clamp(2rem, 4vw, 4rem); line-height: 1.02; letter-spacing: 0; }}
    h2 {{ font-size: 1.45rem; line-height: 1.2; margin-bottom: 10px; }}
    h3 {{ font-size: 1.05rem; }}
    p {{ margin-bottom: 12px; }}
    .lead {{ max-width: 880px; margin: 0; color: var(--muted); font-size: 1.18rem; }}
    .header-actions {{ display: flex; flex-wrap: wrap; gap: 8px; }}
    .header-actions .button {{ margin: 0; }}
    .tag {{
      display: inline-flex;
      align-items: center;
      width: fit-content;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 6px 10px;
      background: var(--soft);
      color: var(--teal-dark);
      font-weight: 800;
      font-size: 0.83rem;
    }}
    .tab-nav {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin: 10px 0 22px;
      border-bottom: 1px solid var(--line);
    }}
    .tab-nav button {{
      appearance: none;
      border: 1px solid var(--line);
      border-bottom: 0;
      border-radius: 8px 8px 0 0;
      padding: 12px 15px;
      background: #edf5f0;
      color: var(--ink);
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }}
    .tab-nav button[aria-selected="true"] {{ background: var(--paper); color: var(--teal-dark); box-shadow: 0 -3px 0 var(--coral) inset; }}
    .tab-panel[hidden] {{ display: none; }}
    .tab-panel {{ animation: fade 160ms ease-out; }}
    @keyframes fade {{ from {{ opacity: 0; transform: translateY(4px); }} to {{ opacity: 1; transform: translateY(0); }} }}
    section {{ padding: 20px 0; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 18px; }}
    .card, details.card {{
      margin: 0 0 18px;
      padding: 22px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--paper);
      box-shadow: var(--shadow);
    }}
    .tab-panel > .card,
    .tab-panel > details.card {{ margin: 0 0 18px; }}
    .card p:last-child,
    .card ol:last-child,
    .card ul:last-child,
    .card table:last-child,
    .card textarea:last-child {{ margin-bottom: 0; }}
    .notice {{ border-left: 4px solid var(--gold); }}
    .button {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 44px;
      margin: 4px 8px 4px 0;
      border: 1px solid var(--teal);
      border-radius: 8px;
      padding: 11px 15px;
      background: var(--teal);
      color: #fff;
      font: inherit;
      font-weight: 800;
      text-decoration: none;
      cursor: pointer;
    }}
    .button.secondary {{ border-color: var(--coral); background: var(--coral); }}
    .button.ghost,
    .button.quiet {{ background: transparent; color: var(--teal-dark); }}
    .button.disabled,
    .button:disabled {{ border-color: #a9b8b2; background: #e4ebe7; color: #5e6f68; cursor: not-allowed; }}
    ol, ul {{ padding-left: 22px; }}
    li {{ margin: 0 0 8px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
    td, th {{ border-top: 1px solid var(--line); padding: 12px; text-align: left; vertical-align: top; }}
    code {{
      overflow-wrap: anywhere;
      padding: 2px 5px;
      border-radius: 6px;
      background: #edf5f0;
      color: var(--teal-dark);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size: 0.93em;
    }}
    textarea {{
      width: 100%;
      min-height: 260px;
      resize: vertical;
      margin-top: 12px;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 14px;
      background: #fbfdfb;
      color: var(--ink);
      font: 0.94rem/1.52 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    }}
    .prompt-card textarea {{ min-height: 330px; }}
    .author-card {{ display: grid; grid-template-columns: 112px 1fr; gap: 20px; align-items: start; }}
    .author-photo {{ width: 112px; height: 112px; object-fit: cover; border-radius: 8px; border: 1px solid var(--line); }}
    .about-link {{ margin: 0 0 24px; }}
    .section-heading {{ margin: 0 0 18px; padding: 0; }}
    .tool-breakdown {{ margin: 16px 0 0; }}
    .tool-breakdown dt {{ margin: 14px 0 6px; font-weight: 800; }}
    .tool-breakdown dd {{ margin: 0; padding: 12px; border: 1px solid var(--line); border-radius: 8px; background: #fbfdfb; }}
    .example-lead {{ max-width: 780px; color: var(--muted); font-size: 1.04rem; }}
    .example-quote {{ margin: 12px 0 16px; padding: 14px 16px; border-left: 4px solid var(--coral); background: #fff7f4; border-radius: 8px; color: var(--ink); }}
    .example-actions {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0 0; }}
    .example-output {{ margin: 0 0 18px; }}
    .example-output-image {{ display: block; width: 100%; height: auto; border: 1px solid var(--line); border-radius: 8px; background: #fff; box-shadow: var(--shadow); }}
    .example-caption {{ margin-top: 8px; color: var(--muted); font-size: 0.92rem; }}
    .install-warning {{ border-left-color: var(--coral); }}
    .install-walkthrough {{ display: grid; gap: 18px; margin: 16px 0 0; padding: 0; list-style: none; }}
    .install-walkthrough li {{ margin: 0; min-width: 0; }}
    .install-step-shot {{ margin: 0; min-width: 0; }}
    .install-step-shot img {{ display: block; width: 100%; max-width: 100%; height: auto; border: 1px solid var(--line); border-radius: 8px; background: #fff; box-shadow: 0 12px 36px rgba(23, 33, 31, 0.1); }}
    .install-step-shot figcaption {{ margin-top: 8px; color: var(--muted); font-size: 0.93rem; }}
    .install-subnote {{ margin: 10px 0 0; color: var(--muted); font-size: 0.94rem; }}
    .footer-author {{ margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--line); }}
    details {{ border: 1px solid var(--line); border-radius: 8px; padding: 14px; background: #fbfdfb; }}
    summary {{ font-weight: 800; cursor: pointer; }}
{SUITE_FOOTER_CSS}
    footer {{ padding: 28px 0 44px; color: var(--muted); }}
    @media (max-width: 720px) {{
      header, main, footer {{ width: min(100% - 24px, 1120px); }}
      header {{ padding-top: 32px; }}
      .brand {{ align-items: flex-start; }}
      .brand img {{ width: 64px; height: 64px; }}
      .tab-nav {{ gap: 6px; }}
      .tab-nav button {{ flex: 1 1 140px; border-radius: 8px; border: 1px solid var(--line); }}
      .author-card {{ grid-template-columns: 1fr; }}
      .author-photo {{ width: 88px; height: 88px; }}
      td, th {{ display: block; width: 100%; }}
{SUITE_FOOTER_MOBILE_CSS}
    }}
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <img alt="Compass badge" src="{badge_src}">
      <div>
        <span class="tag">Critical Compass {plugin_version}</span>
        <h1>{html.escape(title)}</h1>
      </div>
    </div>
    <p class="lead">Critical Compass helps nonprofits, advocacy teams, grant writers, and public-facing communicators pressure-test written work before it has to hold up under scrutiny.</p>
    <div class="header-actions">
      <a class="button ghost" href="https://jonathankhobson.github.io/compass-suite/">Back to Compass Suite</a>
    </div>
  </header>
  <main>
    <nav class="tab-nav" role="tablist" aria-label="Critical Compass download sections">
      <button id="tab-get-started" role="tab" aria-controls="get-started" aria-selected="true" data-tab-target="get-started">Get Started</button>
      <button id="tab-about" role="tab" aria-controls="about" aria-selected="false" data-tab-target="about">About</button>
      <button id="tab-install" role="tab" aria-controls="install" aria-selected="false" data-tab-target="install">Install Guide</button>
      <button id="tab-example" role="tab" aria-controls="example" aria-selected="false" data-tab-target="example">Example</button>
      <button id="tab-faq" role="tab" aria-controls="faq" aria-selected="false" data-tab-target="faq">FAQ</button>
      <button id="tab-advanced" role="tab" aria-controls="advanced" aria-selected="false" data-tab-target="advanced">Advanced</button>
    </nav>

    <section id="get-started" class="tab-panel" role="tabpanel" aria-labelledby="tab-get-started">
      <div class="card">
        <h2>What is Critical Compass?</h2>
        <p>Critical Compass is a critical-thinking toolbox for people who need written work to hold up under scrutiny. Paste in a grant narrative, advocacy draft, public statement, report, or article, and it helps spot weak evidence, hidden assumptions, framing gaps, missing voices, and claims to verify before you publish or submit. It can be used through the plugin, MCP/extension, or skill files below.</p>
      </div>

      <section class="grid">
        <div class="card">
          <h2>Claude Cowork Plugin</h2>
          <p>Best for Claude Cowork or Claude Code. This bundle includes the Critical Compass MCP/extension, skill, and predefined agents.</p>
          <p><span class="tag">v{plugin_version}</span></p>
          <a class="button" href="{plugin_href}" download>Download Plugin</a>
          <p><a href="#install-cowork">&rarr; How to install</a></p>
        </div>
        <div class="card">
          <h2>Claude Desktop Extension</h2>
          <p>Best if you use Claude Desktop. This is the MCP connector installed through Settings &rarr; Extensions.</p>
          <p><span class="tag">v{plugin_version}</span></p>
          <a class="button secondary" href="{desktop_href}" download>Download Extension</a>
          <p><a href="#install-desktop">&rarr; How to install</a></p>
        </div>
        <div class="card">
          <h2>Skill / Prompt-Only Alternative</h2>
          <p>A standalone skill Claude can read without the MCP connector. Useful on its own or alongside the plugin or extension.</p>
          <p><span class="tag">v{plugin_version}</span></p>
          <a class="button ghost" href="{skill_href}" download>Download Skill</a>
          <a class="button ghost" href="{skill_zip_href}" download>Download Skill Zip</a>
          <p><a href="#install-skill">&rarr; How to install</a></p>
        </div>
      </section>

      <div class="card">
        <h2>Pick Your Path</h2>
        <p>Downloads are live for v{plugin_version}. Choose the plugin for Claude Cowork or Claude Code, the MCPB/Desktop Extension for Claude Desktop, or the standalone skill when tool access is unavailable.</p>
        <table>
          <tr><td><strong>I want a fast first read</strong></td><td>Use the quick audit prompt for a plain-language risk read, the top concerns, and one next action before you share or cite a text.</td></tr>
          <tr><td><strong>I am teaching a class</strong></td><td>Use the classroom bias-audit prompt so students supply the same audience, intended use, text type, audit depth, and output section order.</td></tr>
          <tr><td><strong>I need the full audit</strong></td><td>Use the full standard audit prompt for the Critical Integrity Snapshot, evidence gaps, reasoning traps, assumptions, missing voices, and what holds up.</td></tr>
          <tr><td><strong>I want questions and calibration</strong></td><td>Use the advanced human-loop prompt when context, sensitivity, stakeholder perspective, or report readiness needs user input before the audit is finalized.</td></tr>
          <tr><td><strong>I need a shareable deliverable</strong></td><td>Use the report-ready workflow after an audit payload has been validated, then generate Markdown, HTML, or PDF artifacts.</td></tr>
          <tr><td><strong>I only want the prompt layer</strong></td><td>Install the skill or skill zip when the MCP connector is unavailable, or keep it alongside the plugin/extension as a lightweight fallback.</td></tr>
        </table>
        <p><strong>You can install more than one.</strong> Start with the plugin, extension, or skill that matches your Claude surface, then use the path above to decide what to do after install.</p>
        <p>Want your AI assistant to help install this? <a href="#ai-install-prompt">Use the AI-assisted install prompt.</a> Using Codex? See the FAQ tab for technical-user guidance.</p>
      </div>

      <div class="card">
        <h2>Your First Prompt</h2>
        <p>Once Critical Compass is installed, copy one of these prompts into your AI to get started right away.</p>
      </div>

      <section class="grid">
{first_prompt_cards}
      </section>

      <div class="card author-card">
        <img class="author-photo" src="{AUTHOR_IMAGE_OUTPUT_DIR}/{AUTHOR_IMAGE_FILENAME}" alt="Jonathan Kyle Hobson">
        <div>
          <h2>About the author</h2>
          <p><strong>Jonathan Kyle Hobson</strong> is a UX researcher, product strategist, and AI tool builder with 10+ years of experience across design, storytelling, and emerging technology. He holds a master's degree in User Experience from Arizona State University. Kyle created Critical Compass to give nonprofits, advocacy teams, and public communicators a practical, rigorous way to pressure-test their work, because high-stakes writing deserves the same scrutiny as high-stakes decisions.</p>
          <p><a href="{html.escape(AUTHOR_LINKEDIN_URL)}" target="_blank" rel="noopener">Connect on LinkedIn</a></p>
        </div>
      </div>
      <p class="about-link"><a href="#about">Read more about this project &rarr;</a></p>
    </section>

    <section id="about" class="tab-panel" role="tabpanel" aria-labelledby="tab-about" hidden>
      <div class="card">
        <h2>What Is Critical Compass?</h2>
        <p>Critical Compass is a local critical-thinking assistant for pressure-testing written work before it is published, submitted, shared, or used to make a decision. It is designed for drafts that need to hold up under scrutiny: grant narratives, advocacy writing, public statements, reports, articles, policy arguments, and other high-stakes text.</p>
        <p>It does not just proofread. Critical Compass looks for the reasoning underneath the writing: the central claims, evidence gaps, assumptions, possible bias patterns, missing stakeholder perspectives, framing risks, audience fit, and claims that need verification. It helps answer a practical question: if someone smart and skeptical read this, where would it hold up and where would it break?</p>
        <p>For non-technical users, it works like a structured review partner. For technical users, it exposes a local audit workflow with tools for quick scans, full audits, claim stress tests, reasoning-framework lookup, saved audit results, report validation, report generation, and advanced multi-perspective review.</p>
      </div>

      <div class="card">
        <h2>How It's Built</h2>
        <p>Critical Compass is distributed as a local MCP/extension, a Claude Cowork or Claude Code plugin, and a prompt-only skill. The MCP exposes tools for onboarding, routing, quick scans, full audits, advanced audits, claim stress tests, fact-check planning, knowledge-base lookup, saved results, pattern tracking, report validation, and report generation.</p>
        <p>Under the hood, it combines structured audit workflows with a critical-thinking knowledge base. That knowledge base includes biases, fallacies, reasoning frameworks, thinking lenses, methodology checks, reasoning flows, and reusable audit scaffolds. The workflow layer turns those resources into repeatable review steps instead of asking the model to invent an audit process from scratch.</p>
        <p>The system is local-first and scaffold-first by default. It can help identify what should be verified, but it does not require Google, Brave, provider keys, or live retrieval for its core audit workflows. Advanced audit paths add role and persona scaffolds for multi-perspective review while keeping the user in control of the final judgment.</p>
      </div>

      <div class="card">
        <h2>What's Inside</h2>
        <p>A compact map of the major MCP surfaces &mdash; what they do and how to ask for them.</p>
        <dl class="tool-breakdown">
{tool_breakdown}
        </dl>
      </div>

      <div class="card">
        <h2>How I Use It</h2>
        <p>I use Critical Compass when I want to slow down before trusting, publishing, citing, sharing, or acting on a piece of writing. It is especially useful for articles, research papers, drafts, or other writing someone sends me when I need to know whether the evidence, assumptions, framing, and audience fit are actually strong enough.</p>
        <p>For quick reads, I use a quick scan for the plain-language read, the Before Using This Text caution, and the one action worth taking next. For important drafts, I use a full audit so the tool can map claims, surface evidence gaps, flag reasoning traps, and suggest what would make the argument more credible. For high-stakes or politically sensitive work, I use advanced audit mode because multiple perspectives are better than one confident pass.</p>
        <p>I use it as a decision-support tool, not as an automatic judge. Claude is strong at conversational synthesis and stakeholder-sensitive framing; Codex is useful when I want the audit turned into structured artifacts, reports, or implementation-ready follow-up work. In both cases, Critical Compass gives the model a disciplined review path instead of leaving the critique up to vibes.</p>
        <p class="about-link"><a href="#example">See examples &rarr;</a></p>
      </div>
    </section>

    <section id="example" class="tab-panel" role="tabpanel" aria-labelledby="tab-example" hidden>
      <div class="card">
        <h2>Example</h2>
        <p>See what a finished Critical Compass audit can look like.</p>
        <p>This public example is redacted to protect unpublished source material.</p>
      </div>
      <div class="card">
        <h2>Finished Audit Snapshot</h2>
        <p><strong>Verdict:</strong> Moderate Integrity · <strong>Score:</strong> 71/100</p>
        <p>The example shows how Critical Compass turns a draft into a reader-ready pressure test: plain-language risk summary, evidence gaps, missing voices, assumptions, reasoning traps, and concrete next steps.</p>
        <ul>
          <li>Flags claims that need stronger evidence before publication.</li>
          <li>Names missing stakeholder perspectives and framing limits.</li>
          <li>Separates check-worthy claims from claims that are actually false.</li>
          <li>Gives revision prompts that help strengthen the text without flattening its purpose.</li>
        </ul>
        <a class="button" href="examples/{EXAMPLE_HTML}" target="_blank" rel="noopener">Open HTML Example (new tab)</a>
        <a class="button secondary" href="examples/{EXAMPLE_PDF}" download>Download PDF Example</a>
        <a class="button ghost" href="examples/{EXAMPLE_MARKDOWN}" target="_blank" rel="noopener">View Markdown Example (new tab)</a>
      </div>
      <div class="card">
        <h2>Claude Conversation Snapshot</h2>
        <p>This is a direct screenshot from Jonathan's Claude conversation using Critical Compass, included to show the kind of quick feedback brief the tool can produce.</p>
      </div>
      <figure class="example-output">
        <img class="example-output-image" src="examples/{EXAMPLE_SCREENSHOT}" alt="{html.escape(EXAMPLE_SCREENSHOT_ALT)}" loading="lazy">
      </figure>
    </section>

    <section id="install" class="tab-panel" role="tabpanel" aria-labelledby="tab-install" hidden>
      <div class="section-heading">
        <h2>Install Guide</h2>
        <p>Choose the install path for the Claude surface you use. These screenshots show the tested UI. If your app does not show this path, stop and use the diagnostic prompt instead of improvising.</p>
      </div>

      <section class="card notice">
        <h2>Tested Claude Surfaces</h2>
        <p>The screenshots below reflect the Claude Code, Claude Cowork, and Claude Desktop surfaces available during testing. Claude's install UI can differ by platform, account, and version. Local MCP/plugin and Desktop extension installs are not claimed for Claude.ai in a web browser.</p>
      </section>

      <section class="card notice install-warning">
        <h2>Before Manual Config Edits</h2>
        <p>Do not hand-edit Claude config, or let an assistant rewrite it, unless it first backs up the file, reads the existing server names, merges only <code>critical-compass</code>, writes UTF-8 without a BOM, and verifies that no existing MCPs disappeared.</p>
      </section>

      <section class="grid">
        <div class="card" id="install-cowork">
          <h2>Claude Cowork Plugin</h2>
          <ol>
            <li>Download <code>critical-compass-plugin.zip</code>.</li>
            <li>Open Claude Cowork or Claude Code.</li>
            <li>Click <strong>Customize</strong> in the left sidebar.</li>
            <li>Under <strong>Personal Plugins</strong>, click the <strong>+</strong> button.</li>
            <li>Hover over <strong>Create Plugin</strong>, then click <strong>Upload Plugin</strong>.</li>
            <li>Drag the zip file into the upload area.</li>
            <li>Use <code>critical_compass_overview</code> or one of the first prompts on the Get Started tab.</li>
          </ol>
          <p class="install-subnote">If you only see Skills and Connectors, and Connectors only accepts a remote MCP URL, stop. That is not the plugin upload path.</p>
          <ol class="install-walkthrough" aria-label="Claude Cowork plugin install screenshots">
{plugin_screenshots}
          </ol>
        </div>
        <div class="card" id="install-desktop">
          <h2>Claude Desktop Extension</h2>
          <ol>
            <li>Download <code>critical-compass-0.1.0.mcpb</code>.</li>
            <li>Open the Claude Desktop app.</li>
            <li>Go to <strong>Settings</strong> &rarr; <strong>Extensions</strong>.</li>
            <li>Drag the downloaded file into the Extensions panel.</li>
            <li>Approve the standard local-extension warning.</li>
            <li>Ask Claude to use Critical Compass for a quick or full audit.</li>
          </ol>
          <p class="install-subnote">If your Claude Desktop build does not show Settings &rarr; Extensions, do not hand-edit config as a beginner workaround. Use the diagnostic prompt.</p>
          <ol class="install-walkthrough" aria-label="Claude Desktop extension install screenshots">
{mcpb_screenshots}
          </ol>
        </div>
        <div class="card" id="install-skill">
          <h2>Skill File or Skill Zip</h2>
          <ol>
            <li>Download <code>critical-compass.skill</code> or <code>skill.zip</code>.</li>
            <li>Open Claude or Claude Code.</li>
            <li>Go to <strong>Skills</strong>, then click the <strong>+</strong> button.</li>
            <li>Hover over <strong>Create Skill</strong>, then click <strong>Upload Skill</strong>.</li>
            <li>Drag in your downloaded file.</li>
            <li>Use this on its own, or install it alongside the plugin or extension when you want the prompt-only version available too.</li>
          </ol>
          <p class="install-subnote">Use the skill when the MCP/plugin path is unavailable, or keep it as a prompt-only fallback alongside the tool connection.</p>
          <ol class="install-walkthrough" aria-label="Critical Compass skill install screenshots">
{skill_screenshots}
          </ol>
        </div>
      </section>

      <section class="grid">
        <div class="card">
          <h2>After Install, Verify</h2>
          <ol>
            <li>Fully restart Claude if the tool list does not refresh.</li>
            <li>Start a new chat.</li>
            <li>Ask for <code>get_started</code> or <code>critical_compass_overview</code>.</li>
            <li>If you had other MCPs installed before, confirm they still appear.</li>
          </ol>
        </div>
        <div class="card">
          <h2>If the Expected UI Is Missing</h2>
          <p>Do not improvise in Connectors unless that surface clearly accepts the exact file type you downloaded. Use the skill/reference path or the diagnostic prompt instead.</p>
        </div>
        <div class="card">
          <h2>Back Out Safely</h2>
          <p>Restore the latest config backup or remove only the <code>critical-compass</code> entry from <code>mcpServers</code>. Never reset the whole Claude config to remove one MCP.</p>
        </div>
      </section>

      <section class="card notice">
        <h2>If Install Fails</h2>
        <p>Use the <a href="#diagnostics-prompt">diagnostic prompt</a> in the Advanced tab before editing any files manually. Manual config install is a technical fallback for people who have installed MCPs this way before.</p>
      </section>
    </section>

    <section id="faq" class="tab-panel" role="tabpanel" aria-labelledby="tab-faq" hidden>
      <div class="section-heading">
        <h2>Frequently Asked Questions</h2>
        <p>Quick answers about what Critical Compass does, how the files differ, and what to expect during install.</p>
      </div>
      <div class="card">
        <h2>What does Critical Compass actually do?</h2>
        <p>Critical Compass is a reasoning layer, not a spell-checker. It asks the hard questions your reader may ask about evidence quality, claim strength, hidden assumptions, framing bias, missing voices, and language that could overstate your case.</p>
      </div>
      <div class="card">
        <h2>Who is it for?</h2>
        <p>It is for nonprofits, grant writers, advocacy communicators, policy teams, public affairs staff, and anyone who submits, publishes, or presents written work that needs to hold up under scrutiny.</p>
      </div>
      <div class="card">
        <h2>What is an MCP connector or extension?</h2>
        <p>MCP means Model Context Protocol. In this context, Claude may call the local tool connection an MCP, connector, or extension. Critical Compass's extension is the MCP connector: it gives Claude tools plus bundled indexes and resources for pressure-testing text. <a href="{MCP_EXPLAINER_PUBLIC_URL}" target="_blank" rel="noopener">Learn more about MCPs.</a></p>
      </div>
      <div class="card">
        <h2>What is the difference between the plugin, extension, and skill?</h2>
        <p><strong>Plugin zip:</strong> the Claude Cowork or Claude Code bundle. It includes the MCP/extension, skill, and predefined agents. <strong>Extension file:</strong> the Claude Desktop MCP connector, which gives Claude tools and bundled resources so it can do more with fewer tokens. <strong>Skill:</strong> the prompt-only alternative Claude can read without the MCP, though it may use more context. You can install more than one.</p>
      </div>
      <div class="card">
        <h2>Does this work with Codex?</h2>
        <p>Yes. Critical Compass can work with Codex because Codex can use local MCPs, skills, and plugins. This page does not yet provide a one-click Codex install path; technical Codex users can use the source zip or the AI-assisted install prompt in Advanced.</p>
      </div>
      <div class="card">
        <h2>Is Critical Compass safe to install?</h2>
        <p>Downloading anything from the internet carries real risk: malicious code, data collection, hidden scripts. Critical Compass is designed to reduce that surface area: it runs locally on your machine, requires no API key, bundles its own files, and does no background scanning. That said, no third-party tool is zero risk. Before installing, you're encouraged to review the source files or have a trusted technical contact look them over. Claude's warning is the standard prompt it shows for all locally shared third-party plugins, not a flag specific to this tool. <a href="{MCP_EXPLAINER_PUBLIC_URL}#mcp-risks" target="_blank" rel="noopener">Learn more about MCP risks.</a></p>
      </div>
      <div class="card">
        <h2>Do I need a GitHub account to download?</h2>
        <p>No. The download buttons go directly to the files. GitHub is only where the files are hosted.</p>
      </div>
    </section>

    <section id="advanced" class="tab-panel" role="tabpanel" aria-labelledby="tab-advanced" hidden>
      <div class="card">
        <h2>Advanced</h2>
        <p>This section is for IT reviewers, security-conscious users, and anyone troubleshooting installation.</p>
        <p><a class="button" href="{html.escape(release_url)}">View full release notes</a></p>
        <section>
          <h2>Download source files</h2>
          <p>Use this zip if you want to inspect, modify, or rebuild Critical Compass yourself. It excludes private reports, generated release files, local state, env files, caches, and machine-specific artifacts.</p>
          <p><a class="button ghost" href="{source_href}" download>Download Source Zip</a></p>
        </section>
        <details>
          <summary>Advanced: Verify Download</summary>
          <p>These SHA-256 checksums help technical reviewers confirm that downloaded files match this release.</p>
          <table>{checksum_rows}</table>
        </details>
      </div>
      <div id="ai-install-prompt" class="card">
        <h2>AI-Assisted Install Prompt</h2>
        <p>Use this with a coding assistant that can inspect downloads, check your computer setup, and guide client-specific UI steps. Manual config edits are a technical fallback only; the assistant should preserve existing configuration and stop if the expected install surface is missing.</p>
        <button class="button" type="button" id="copy-ai-install">Copy install prompt</button>
        <textarea id="ai-install-text" readonly>{ai_install_prompt}</textarea>
      </div>
      <div class="card">
        <h2>Diagnostics Prompt</h2>
        <p>If installation fails, copy this prompt into Claude, Claude Code, or Codex and attach the file you tried to install.</p>
        <button class="button" type="button" id="copy-diagnostics">Copy diagnostics prompt</button>
        <textarea id="diagnostics-prompt" readonly>{diagnostics_prompt}</textarea>
      </div>
      <div class="card">
        <h2>Alternative Share Link</h2>
        <p>A Claude Artifact mirror is available as a secondary way to preview this page. Downloads still point to the GitHub release files.</p>
        <p><a href="{html.escape(CLAUDE_ARTIFACT_URL)}" target="_blank" rel="noopener">View Claude Artifact mirror</a></p>
      </div>
    </section>
  </main>
{_suite_footer("Fact-checking is scaffold-first by default: no Google, Brave, or provider key is required.")}
  <script>
    const tabButtons = Array.from(document.querySelectorAll("[data-tab-target]"));
    const tabPanels = Array.from(document.querySelectorAll(".tab-panel"));
    const installAnchorIds = new Set(["install-cowork", "install-desktop", "install-skill"]);
    const advancedAnchorIds = new Set(["ai-install-prompt", "diagnostics-prompt"]);

    function showTab(tabId, updateHash = true) {{
      const targetPanel = document.getElementById(tabId) || document.getElementById("get-started");
      tabButtons.forEach((button) => {{
        const selected = button.dataset.tabTarget === targetPanel.id;
        button.setAttribute("aria-selected", String(selected));
      }});
      tabPanels.forEach((panel) => {{
        panel.hidden = panel.id !== targetPanel.id;
      }});
      if (updateHash) {{
        history.replaceState(null, "", "#" + targetPanel.id);
      }}
    }}

    function routeHash(updateHash = false) {{
      const hash = window.location.hash.replace("#", "");
      const panelId = installAnchorIds.has(hash) ? "install" : (advancedAnchorIds.has(hash) ? "advanced" : (hash || "get-started"));
      showTab(panelId, updateHash);
      if (installAnchorIds.has(hash) || advancedAnchorIds.has(hash)) {{
        const target = document.getElementById(hash);
        if (target) {{
          if ("open" in target) {{
            target.open = true;
          }}
          window.requestAnimationFrame(() => {{
            target.scrollIntoView({{ behavior: "smooth", block: "start" }});
          }});
        }}
      }}
    }}

    tabButtons.forEach((button) => {{
      button.addEventListener("click", () => showTab(button.dataset.tabTarget));
    }});

    window.addEventListener("hashchange", () => {{
      routeHash(false);
    }});

    const installSteps = Array.from(document.querySelectorAll("#install details"));
    const openInstallStepsOnMobile = () => {{
      const openOnMobile = window.matchMedia("(max-width: 720px)").matches;
      installSteps.forEach((details) => {{
        details.open = openOnMobile;
      }});
    }};
    openInstallStepsOnMobile();
    routeHash(false);

    function wireCopyButton(buttonId, textareaId) {{
      const copyButton = document.getElementById(buttonId);
      const promptText = document.getElementById(textareaId);
      if (!copyButton || !promptText) {{
        return;
      }}
      const defaultLabel = copyButton.textContent;
      copyButton.addEventListener("click", async () => {{
        promptText.select();
        try {{
          await navigator.clipboard.writeText(promptText.value);
          copyButton.textContent = "Copied";
        }} catch (_error) {{
          document.execCommand("copy");
          copyButton.textContent = "Copied";
        }}
        window.setTimeout(() => {{
          copyButton.textContent = defaultLabel;
        }}, 1600);
      }});
    }}
{prompt_copy_wiring}
    wireCopyButton("copy-ai-install", "ai-install-text");
    wireCopyButton("copy-diagnostics", "diagnostics-prompt");
  </script>
</body>
</html>
"""


def _start_here_markdown() -> str:
    return """# Start Here: Critical Compass Share Pack

Critical Compass helps nonprofits, advocacy teams, grant writers, and public-facing communicators pressure-test written work before it has to hold up under scrutiny.

## Pick Your Starting Point

- Use `downloads/critical-compass-plugin.zip` for Claude Cowork or Claude Code. It bundles the MCP/extension, skill, and agents.
- Use `downloads/critical-compass-0.1.0.mcpb` for the Claude Desktop app. This is the MCP connector installed through Extensions.
- Use `downloads/critical-compass.skill` or `downloads/skill.zip` for the skill / prompt-only alternative.
- Use the AI-assisted install prompt in `START_HERE.html` if the visible UI differs from the screenshots or you want a coding assistant to inspect files.

You can install more than one. Start with the file that matches how you use Claude, then add the skill too if you want the prompt-only version available.

## Expected Warning

Claude may warn that this plugin is not verified by Anthropic and may access local files. That warning is expected for locally shared tools. Only install if you trust the source.

## If Install Fails

Open `mcpb-install-diagnostics-prompt.md` and paste it into Claude, Claude Code, or Codex. Do not edit Claude's installed files by hand unless the diagnostic prompt tells you exactly what to check.

Manual config install is a technical fallback only. If you use it, back up the config first, merge only `critical-compass`, write UTF-8 without a BOM, and verify all pre-existing MCP servers are still present.
"""


def _release_notes(manifest: dict) -> str:
    version = manifest.get("version", "unknown")
    return f"""# Critical Compass {version} Release Notes

This beta.11 release is a course-reliability update on top of beta.10. It preserves the delivery-layer hotfixes while adding a standardized classroom audit path, clearer score-delta guidance, and public prompt-card support for instructors.

- Claude Cowork plugin zip for Claude Cowork and Claude Code.
- Claude Desktop extension file for Claude Desktop Settings > Extensions.
- Skill files for prompt-only alternative use.
- `classroom_standard_audit_prompt` scaffold for course assignments that need stable audience, intended-use, text-type, audit-depth, and section-order framing.
- `get_started` and `critical_compass_overview` route classroom/course users to standard `audit_text`, not advanced panel review by default.
- Public landing page includes a Classroom Bias Audit prompt card for students and instructors.
- Standalone skill guidance includes the same classroom prompt for ChatGPT/skill-only use.
- `compare_audit_results` frames score movement as a diagnostic signal, not proof of improvement.
- `validate_report_payload` with `schema_only=true` for dry-run diagnostics, schema discovery, renderer status, and field constraints before PDF generation.
- `generate_audit_report(preflight_check=true)` as compatibility sugar for hosts that look for preflight inside the report tool.
- `report_ready_payload` support from advanced synthesis so host AIs fill gaps instead of hand-assembling complex report data from scratch.
- Stable report preflight cards, renderer diagnostics, Markdown-first PDF failure recovery, renderer timeout logging, WeasyPrint/PyMuPDF fallback behavior, and canonical follow-up activity paths.
- Natural-key normalization for common host payloads such as `cis_score`, `bias_rows`, and `bias`.
- Explicit CIS bands and safer action routing so low-scoring reports do not render `Trust` as the primary action.
- Human-loop guidance that highlights `PAUSE_REQUIRED` and asks Claude hosts to use native `Ask_User_Input_V0` / conversational UI widgets.
- Teaching-layer outputs: plain-language read, before-use caution, solo/group follow-up activities, and Critical Compass activity attribution.
- Planning-leak cleanup: no external MCP orchestration, no third-party MCP dependency map, and no planning-registry material in runtime bundles.
- Reader-facing report cleanup for placeholder/debug strings, raw enum values, empty sections, and KB-grounding internals.
- Refreshed standalone Critical Compass skill references.
- Redacted public example audit in HTML, PDF, and Markdown.
- Source zip for technical reviewers who want to inspect or rebuild the project.
- AI-assisted install prompt for technical local MCP source installs.
- Diagnostics prompt for install troubleshooting.
- Checksums for all downloadable artifacts.

Critical Compass runs locally and does not orchestrate other MCPs. Fact-checking remains scaffold-first by default. No Google, Brave, provider key, runtime external-archive dependency, or separate activity database is required.
"""


def _github_release_body() -> str:
    return """# Critical Compass v0.1.0-beta.11

Beta.11 is a course-reliability release on top of beta.10. It adds a standardized classroom audit prompt/resource, routes course users toward standard `audit_text`, keeps advanced panel review optional, and strengthens score-delta interpretation so class discussions focus on findings, severity, and revision decisions rather than small point changes.

## Download Guide

- `critical-compass-plugin.zip`: Claude Cowork and Claude Code plugin upload.
- `critical-compass-0.1.0.mcpb`: Claude Desktop extension install through Settings > Extensions.
- `critical-compass.skill` and `skill.zip`: skill / prompt-only alternative.
- `critical-compass-source.zip`: source files for inspection, modification, or rebuilds.
- `critical-compass-example-report.html` and `critical-compass-example-report.pdf`: redacted public example audit.
- `checksums.txt`: SHA-256 checksums.

## What's New

- `classroom_standard_audit_prompt` scaffold for Week 2 / classroom bias-audit assignments.
- `get_started` and `critical_compass_overview` now surface the classroom standard-audit path.
- Public landing page includes a Classroom Bias Audit prompt card.
- Standalone skill guidance includes the classroom prompt for prompt-only use.
- `compare_audit_results` warns that score movement is diagnostic, not improvement proof by itself.
- `validate_report_payload` dry-runs report payloads before rendering and can return schema docs with `schema_only=true`.
- `generate_audit_report(preflight_check=true)` runs the same dry-run checks without writing files.
- Advanced synthesis returns a `report_ready_payload` so host AIs have less brittle payload assembly work.
- Advanced synthesis confirms accepted silent mode with `human_loop_confirmation`.
- Markdown is written before PDF rendering; renderer or QA timeout failures preserve `markdown_path`, `markdown_hash`, and `render_error_log_path`.
- PDF/HTML reports suppress placeholder/debug strings, raw enum values, and reader-facing internal notes.
- CIS bands and action routing are explicit; low-score reports cannot render `Trust` as the primary action.
- Human-loop guidance now foregrounds `PAUSE_REQUIRED` and Claude's native `Ask_User_Input_V0` style question UI.
- Runtime bundles exclude planning-registry material and do not rely on external MCP orchestration.

Claude's unverified developer/access warning is expected for locally shared plugins and extensions. A Claude Artifact mirror is available at https://claude.ai/public/artifacts/9e50e78b-3877-40c0-855b-07031eb15c95.
"""


def build_shareable_pages_only() -> dict[str, str]:
    """Refresh public-page HTML and share-kit zips from existing release artifacts."""

    manifest = _read_existing_plugin_manifest()
    github_checksums = _read_existing_checksums(GITHUB_DOWNLOADS)
    manual_checksums = _read_existing_checksums(MANUAL_DOWNLOADS)

    for path in [
        GITHUB_DIR,
        MANUAL_DIR,
        GITHUB_DIR / AUTHOR_IMAGE_OUTPUT_DIR / AUTHOR_IMAGE_FILENAME,
        MANUAL_DIR / AUTHOR_IMAGE_OUTPUT_DIR / AUTHOR_IMAGE_FILENAME,
    ]:
        if not path.exists():
            raise FileNotFoundError(f"Missing generated share-kit dependency: {path}")

    (GITHUB_DIR / "index.html").write_text(
        _html_page(title="Download Critical Compass", manual=False, manifest=manifest, checksums=github_checksums),
        encoding="utf-8",
    )
    (MANUAL_DIR / "START_HERE.html").write_text(
        _html_page(title="Start Here", manual=True, manifest=manifest, checksums=manual_checksums),
        encoding="utf-8",
    )
    (MANUAL_DIR / "START_HERE.md").write_text(_start_here_markdown(), encoding="utf-8")

    _copy_install_guide_assets(GITHUB_DIR)
    _copy_install_guide_assets(MANUAL_DIR)
    _clean_sidecars(GITHUB_DIR)
    _clean_sidecars(MANUAL_DIR)
    _remove_tree(MCP_EXPLAINER_SITE_DIR)
    MCP_EXPLAINER_SITE_DIR.mkdir(parents=True)
    mcp_image_meta = _build_mcp_infographic(MCP_EXPLAINER_SITE_DIR)
    (MCP_EXPLAINER_SITE_DIR / "index.html").write_text(_mcp_explainer_page(mcp_image_meta), encoding="utf-8")
    (MCP_EXPLAINER_SITE_DIR / ".nojekyll").write_text("", encoding="utf-8")
    _clean_sidecars(MCP_EXPLAINER_SITE_DIR)
    _assert_clean_output(GITHUB_DIR)
    _assert_clean_output(MANUAL_DIR)
    _assert_clean_output(MCP_EXPLAINER_SITE_DIR)
    _zip_directory(GITHUB_DIR, GITHUB_KIT_ZIP, archive_root="critical-compass-github-pages-kit")
    _zip_directory(MANUAL_DIR, MANUAL_SHARE_ZIP, archive_root="critical-compass-manual-share")
    _remove_sidecar_for(GITHUB_KIT_ZIP)
    _remove_sidecar_for(MANUAL_SHARE_ZIP)
    _assert_clean_output(GITHUB_KIT_ZIP)
    _assert_clean_output(MANUAL_SHARE_ZIP)

    return {
        "github_pages": str(GITHUB_DIR),
        "github_zip": str(GITHUB_KIT_ZIP),
        "manual_share": str(MANUAL_DIR),
        "manual_zip": str(MANUAL_SHARE_ZIP),
        "mcp_explainer_site": str(MCP_EXPLAINER_SITE_DIR),
    }


def build_shareable_release() -> dict[str, str]:
    _clean_sidecars(DIST)
    manifest = _build_plugin_zip()
    _build_standalone_skill_artifacts()
    _build_public_examples()
    _build_source_zip()
    for _filename, artifact in DOWNLOAD_ARTIFACTS[1:]:
        if not artifact.exists():
            raise FileNotFoundError(f"Missing release artifact: {artifact}")

    _remove_tree(GITHUB_DIR)
    _remove_tree(MANUAL_DIR)
    _remove_tree(MCP_EXPLAINER_SITE_DIR)
    GITHUB_DIR.mkdir(parents=True)
    MANUAL_DIR.mkdir(parents=True)
    MCP_EXPLAINER_SITE_DIR.mkdir(parents=True)

    github_checksums = _copy_artifacts(GITHUB_DOWNLOADS)
    manual_checksums = _copy_artifacts(MANUAL_DOWNLOADS)
    _copy_examples(GITHUB_EXAMPLES)
    _copy_examples(MANUAL_EXAMPLES)
    mcp_image_meta = _build_mcp_infographic(MCP_EXPLAINER_SITE_DIR)
    _copy_author_assets(GITHUB_DIR)
    _copy_author_assets(MANUAL_DIR)
    _copy_install_guide_assets(GITHUB_DIR)
    _copy_install_guide_assets(MANUAL_DIR)

    (GITHUB_DIR / "index.html").write_text(
        _html_page(title="Download Critical Compass", manual=False, manifest=manifest, checksums=github_checksums),
        encoding="utf-8",
    )
    (GITHUB_DIR / MCP_EXPLAINER_HTML).write_text(_mcp_explainer_redirect_page(), encoding="utf-8")
    (GITHUB_DIR / "release-notes.md").write_text(_release_notes(manifest), encoding="utf-8")
    (GITHUB_DIR / "github-release-body.md").write_text(_github_release_body(), encoding="utf-8")

    (MANUAL_DIR / "START_HERE.html").write_text(
        _html_page(title="Start Here", manual=True, manifest=manifest, checksums=manual_checksums),
        encoding="utf-8",
    )
    (MANUAL_DIR / MCP_EXPLAINER_HTML).write_text(_mcp_explainer_redirect_page(), encoding="utf-8")
    (MANUAL_DIR / "START_HERE.md").write_text(_start_here_markdown(), encoding="utf-8")
    shutil.copy2(DIAGNOSTIC_PROMPT, MANUAL_DIR / "mcpb-install-diagnostics-prompt.md")
    (MCP_EXPLAINER_SITE_DIR / "index.html").write_text(_mcp_explainer_page(mcp_image_meta), encoding="utf-8")
    (MCP_EXPLAINER_SITE_DIR / ".nojekyll").write_text("", encoding="utf-8")

    _clean_sidecars(SHARE_DIR)
    _assert_clean_output(GITHUB_DIR)
    _assert_clean_output(MANUAL_DIR)
    _assert_clean_output(MCP_EXPLAINER_SITE_DIR)
    _zip_directory(GITHUB_DIR, GITHUB_KIT_ZIP, archive_root="critical-compass-github-pages-kit")
    _zip_directory(MANUAL_DIR, MANUAL_SHARE_ZIP, archive_root="critical-compass-manual-share")
    _remove_sidecar_for(GITHUB_KIT_ZIP)
    _remove_sidecar_for(MANUAL_SHARE_ZIP)
    _assert_clean_output(GITHUB_KIT_ZIP)
    _assert_clean_output(MANUAL_SHARE_ZIP)

    return {
        "github_pages": str(GITHUB_DIR),
        "github_zip": str(GITHUB_KIT_ZIP),
        "manual_share": str(MANUAL_DIR),
        "manual_zip": str(MANUAL_SHARE_ZIP),
        "mcp_explainer_site": str(MCP_EXPLAINER_SITE_DIR),
        "plugin_zip": str(PLUGIN_ZIP),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Critical Compass public share/release kits.")
    parser.add_argument(
        "--pages-only",
        action="store_true",
        help="Refresh GitHub Pages/manual-share HTML and share-kit zips from existing release artifacts.",
    )
    args = parser.parse_args()
    try:
        outputs = build_shareable_pages_only() if args.pages_only else build_shareable_release()
    except Exception as exc:  # pylint: disable=broad-exception-caught
        print(f"build_shareable_release failed: {exc}", file=sys.stderr)
        return 1
    for key, value in outputs.items():
        print(f"{key}={value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
