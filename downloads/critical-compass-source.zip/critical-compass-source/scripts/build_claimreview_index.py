#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from factcheck.local_index import build_claimreview_index, configured_index_path  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a local ClaimReview index for Critical Compass factcheck_lookup.")
    parser.add_argument("source", type=Path, help="ClaimReview JSON, JSONL, CSV, or Google-style claims payload.")
    parser.add_argument(
        "--output",
        type=Path,
        default=configured_index_path(),
        help="Output index path. Defaults to CRITICAL_COMPASS_CLAIMREVIEW_INDEX_PATH or support/registry/local_claimreview_index.json.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    index = build_claimreview_index(args.source.expanduser().resolve(), args.output.expanduser().resolve())
    print(
        json.dumps(
            {
                "status": "built",
                "index_path": index["index_path"],
                "record_count": index["record_count"],
                "source_path": index["source_path"],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
