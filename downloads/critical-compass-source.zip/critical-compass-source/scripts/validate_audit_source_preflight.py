#!/usr/bin/env python3
"""Smoke-test PDF source preflight on a local PDF."""

from __future__ import annotations

import argparse
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = Path("/Users/jonathanhobson/Downloads/36 Questions Experiment.pdf")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_path", nargs="?", default=str(DEFAULT_SOURCE), help="Local PDF to prepare for auditing.")
    parser.add_argument("--output-dir", default="", help="Directory for extracted text and page images.")
    args = parser.parse_args()

    import sys

    sys.path.insert(0, str(ROOT))
    from audit_report.source import prepare_audit_source  # pylint: disable=import-error,import-outside-toplevel

    source_path = Path(args.source_path).expanduser()
    if not source_path.exists():
        raise SystemExit(f"source PDF missing: {source_path}")
    output_dir = Path(args.output_dir).expanduser() if args.output_dir else Path(tempfile.mkdtemp(prefix="critical-compass-source-"))
    result = prepare_audit_source(str(source_path), output_dir=str(output_dir), include_page_images=True)
    assert result["status"] == "ready", result
    assert result["page_count"] >= 1, result
    assert result["text_word_count"] >= 80, result
    assert result["text_path"], result
    assert Path(result["text_path"]).exists(), result
    assert result["page_image_paths"], result
    assert result["extraction_method"] in {"embedded_text", "apple_vision_ocr", "mixed"}, result
    print("audit source preflight validation ok")
    print(f"method: {result['extraction_method']}; ocr_used: {result['ocr_used']}; words: {result['text_word_count']}; pages: {result['page_count']}")
    print(f"artifacts: {output_dir}")


if __name__ == "__main__":
    main()
