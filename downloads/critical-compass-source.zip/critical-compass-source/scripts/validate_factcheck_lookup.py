#!/usr/bin/env python3
from __future__ import annotations

import os
import tempfile
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys

sys.path.insert(0, str(ROOT))

from factcheck.providers import ProviderError  # noqa: E402
from factcheck.local_index import build_claimreview_index  # noqa: E402
from factcheck.tool import factcheck_lookup  # noqa: E402


class FixtureProvider:
    provider_name = "google_fact_check_tools"

    def __init__(self, responses: dict[str, dict] | None = None, error: ProviderError | None = None):
        self.responses = responses or {}
        self.error = error
        self.calls = []

    def search(self, claim_text, options):
        self.calls.append((claim_text, options.publisher_site))
        if self.error:
            raise self.error
        return self.responses.get(options.publisher_site, {"claims": []})


def payload(site: str, rating: str, url: str) -> dict:
    return {
        "claims": [
            {
                "text": "The city reduced bus fares by 25 percent in 2024.",
                "claimant": "Example claimant",
                "claimDate": "2024-11-12",
                "claimReview": [
                    {
                        "publisher": {"name": site, "site": site},
                        "url": url,
                        "title": "Fact-check fixture",
                        "reviewDate": "2025-01-01",
                        "textualRating": rating,
                        "languageCode": "en",
                    }
                ],
            }
        ]
    }


def claim(text: str = "The city reduced bus fares by 25 percent in 2024.") -> dict:
    return {
        "claim_id": "fixture-claim",
        "text": text,
        "claim_type": "factual",
        "is_factual": True,
        "verification_priority": "high",
    }


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["CRITICAL_COMPASS_FACTCHECK_CACHE_DIR"] = str(Path(tmp) / "cache")
        provider = FixtureProvider(
            {
                "factcheck.org": payload("factcheck.org", "Mostly True", "https://factcheck.org/fixture"),
                "politifact.com": payload("politifact.com", "False", "https://politifact.com/fixture"),
            }
        )
        scaffold = factcheck_lookup([claim()], publisher_sites=["factcheck.org"], provider_client=provider)
        assert scaffold["status"] == "scaffold_ready"
        assert scaffold["lookup_performed"] is False
        assert scaffold["mode"] == "guided_research"
        assert provider.calls == []

        deprecated_auto = factcheck_lookup([claim()], provider="auto")
        assert any(item.get("code") == "provider_auto_deprecated" for item in deprecated_auto["warnings"])

        source = Path(tmp) / "claimreview-source.json"
        index_path = Path(tmp) / "claimreview-index.json"
        source.write_text(
            json.dumps(
                {
                    "claims": [
                        {
                            "text": "The city reduced bus fares by 25 percent in 2024.",
                            "claimant": "Example claimant",
                            "claimDate": "2024-11-12",
                            "claimReview": [
                                {
                                    "publisher": {"name": "FactCheck.org", "site": "factcheck.org"},
                                    "url": "https://factcheck.org/local-fixture",
                                    "title": "Local ClaimReview fixture",
                                    "reviewDate": "2025-01-01",
                                    "textualRating": "Mostly True",
                                    "languageCode": "en",
                                }
                            ],
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        built = build_claimreview_index(source, index_path)
        os.environ["CRITICAL_COMPASS_CLAIMREVIEW_INDEX_PATH"] = str(index_path)
        local = factcheck_lookup([claim()], provider="local_claimreview", publisher_sites=["factcheck.org"])
        assert built["record_count"] == 1
        assert local["mode"] == "local_retrieval"
        assert local["lookup_performed"] is True
        assert local["results"][0]["status"] == "match_found"

        blocked = factcheck_lookup([claim()], provider="google_fact_check_tools", publisher_sites=["factcheck.org"], provider_client=provider)
        assert blocked["status"] == "blocked"
        assert provider.calls == []

        conflict = factcheck_lookup(
            [claim()],
            provider="google_fact_check_tools",
            publisher_sites=["factcheck.org", "politifact.com"],
            allow_external_calls=True,
            provider_client=provider,
        )
        assert conflict["results"][0]["status"] == "conflicting_reviews"
        assert len(conflict["results"][0]["matches"]) == 2

        sensitive = factcheck_lookup(
            [claim("John Smith was fired for stealing from his employer.")],
            provider="google_fact_check_tools",
            publisher_sites=["factcheck.org"],
            allow_external_calls=True,
            provider_client=provider,
        )
        assert sensitive["results"][0]["status"] == "sensitive_blocked"

        normative = factcheck_lookup(
            [{"claim_id": "n1", "text": "This policy is unfair.", "claim_type": "normative", "verification_priority": "not_ranked"}],
            provider="google_fact_check_tools",
            publisher_sites=["factcheck.org"],
            allow_external_calls=True,
            provider_client=provider,
        )
        assert normative["results"][0]["status"] == "no_trusted_match"

        error = factcheck_lookup(
            [claim()],
            provider="google_fact_check_tools",
            publisher_sites=["factcheck.org"],
            allow_external_calls=True,
            provider_client=FixtureProvider(error=ProviderError("rate_limited", "Provider rate limit.")),
        )
        assert error["results"][0]["status"] == "provider_error"

    print("factcheck_lookup validation passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
