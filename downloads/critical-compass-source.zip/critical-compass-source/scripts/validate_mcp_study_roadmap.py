#!/usr/bin/env python3
"""Validate MCP study-library roadmap visibility across public planning surfaces."""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

REQUIRED_TERMS = [
    "MCP Study Library Implementation Roadmap",
    "Completed ship-next",
    "Host-AI Quickstart / Current State Context",
    "Client-specific one-line hints",
    "Tool trigger matrix",
    "Surface sync checklist",
    "Use for local ClaimReview phase",
    "Good next phase",
    "Defer until examples prove need",
    "Later / high effort",
    "Reject / scaffold-only",
]

MISSION_TERMS = [
    "mission-audience-purpose-charter.md",
    "Pressure-Test Readiness",
    "pressure-test text before use",
    "trust, revise, verify, or reframe",
]

PTR_TERMS = ["PTR-01", "PTR-02", "PTR-03", "PTR-04"]

SURFACES = {
    "docs/planning/master-roadmap.md": REQUIRED_TERMS + MISSION_TERMS + PTR_TERMS + ["support infrastructure"],
    "docs/planning/mcp-study-library-soft-learner.md": REQUIRED_TERMS + ["MSL-01", "MSL-02", "MSL-03", "MSL-04", "Current Active Phase", "Pressure-Test Readiness"],
    "docs/planning/mcp-composition-strategy.md": ["Mission Alignment Pause", "support infrastructure", "pressure-test text before use"],
    "docs/planning/mcp-integration-decision-matrix.md": REQUIRED_TERMS + ["Pressure-Test Readiness", "MSL-01 through MSL-04 are complete"],
    "docs/planning/implementation-status-and-idea-drift-review-2026-04-15.md": [
        "Mission Alignment Review",
        "Pressure-Test Readiness",
        "infrastructure drift",
        "trust, revise, verify, or reframe",
        "Done - `MSL-01`",
    ],
    "docs/tickets/top-10-prioritized-tickets.md": REQUIRED_TERMS + PTR_TERMS + ["Done / MSL-01", "Done / MSL-04", "MSL-12"],
}


def validate_surfaces() -> dict[str, object]:
    failures: list[str] = []
    checked: list[str] = []
    for relative_path, terms in SURFACES.items():
        path = ROOT / relative_path
        checked.append(relative_path)
        if not path.exists():
            failures.append(f"{relative_path}: missing file")
            continue
        text = path.read_text(encoding="utf-8")
        text_folded = text.casefold()
        for term in terms:
            if term.casefold() not in text_folded:
                failures.append(f"{relative_path}: missing {term!r}")
    return {
        "status": "passed" if not failures else "failed",
        "checked": checked,
        "failures": failures,
    }


def main() -> int:
    result = validate_surfaces()
    if result["status"] != "passed":
        for failure in result["failures"]:
            print(failure)
        return 1
    print("mcp study roadmap and pressure-test readiness validation passed")
    for path in result["checked"]:
        print(f"- {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
