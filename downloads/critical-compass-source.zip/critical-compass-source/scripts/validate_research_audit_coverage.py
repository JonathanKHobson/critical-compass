#!/usr/bin/env python3
"""Validate research-audit coverage and scaffold contracts for Critical Compass."""

from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_GLOSSARY = Path("/Volumes/KyleSSD/Websites/AIGlossary/glossary/js/biases.data.js")
METHODOLOGY_BIASES = [
    "WEIRD bias",
    "demand characteristics",
    "social desirability bias",
    "overgeneralization",
    "publication bias",
    "p-hacking",
    "HARKing",
    "nonresponse bias",
    "attrition bias",
]
METHODOLOGY_CONCEPTS = [
    "construct validity",
    "external validity",
    "measurement validity",
    "internal validity",
    "replicability",
    "preregistration",
    "statistical power",
]
DEFERRED_AIGLOSSARY_GAP_FILL_BATCH = "new_bias_gap_fill_entries_2026-04-27"
RESEARCH_SAMPLE = (
    "A randomized study of 42 U.S. college students found that the intervention improved empathy. "
    "Participants knew the study examined empathy and self-reported socially desirable behavior. "
    "The authors conclude the intervention works for all communities."
)


def load_server_module() -> None:
    sys.path.insert(0, str(ROOT))
    if "audit_report" not in sys.modules:
        audit_report_module = types.ModuleType("audit_report")
        audit_report_module.__path__ = [str(ROOT / "audit_report")]

        def fake_generate_audit_report(*_args, **_kwargs):
            return {"qa_status": "not_run", "report_path": None}

        def fake_prepare_audit_source(*_args, **_kwargs):
            return {"status": "not_run", "text": ""}

        def fake_generate_audit_artifact_viewer(*_args, **_kwargs):
            return {"status": "not_run", "viewer_path": None}

        def fake_validate_report_payload(*_args, **_kwargs):
            return {"qa_status": "not_run", "writes_files": False}

        audit_report_module.generate_audit_artifact_viewer = fake_generate_audit_artifact_viewer
        audit_report_module.generate_audit_report = fake_generate_audit_report
        audit_report_module.prepare_audit_source = fake_prepare_audit_source
        audit_report_module.validate_report_payload = fake_validate_report_payload
        sys.modules["audit_report"] = audit_report_module

    if "mcp.server.fastmcp" in sys.modules:
        return

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args, **_kwargs):
            pass

        def tool(self, *_args, **_kwargs):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules["mcp"] = mcp
    sys.modules["mcp.server"] = server_module
    sys.modules["mcp.server.fastmcp"] = fastmcp_module
    sys.modules["mcp.types"] = types_module


def load_aiglossary_rows(path: Path) -> list[dict]:
    script = (
        "const fs=require('fs'),vm=require('vm');"
        "const s=fs.readFileSync(process.argv[1],'utf8');"
        "const ctx={globalThis:{}};"
        "vm.createContext(ctx);"
        "vm.runInContext(s,ctx);"
        "const rows=ctx.BIASES||ctx.globalThis.BIASES||[];"
        "console.log(JSON.stringify(rows));"
    )
    output = subprocess.check_output(["node", "-e", script, str(path)], text=True)
    rows = json.loads(output)
    return [row for row in rows if row.get("kind") in {"bias", "llm-bias"}]


def glossary_bias_is_covered(cursor: sqlite3.Cursor, row: dict) -> bool:
    title = (row.get("title") or row.get("name") or "").strip()
    glossary_id = row.get("id", "").strip()
    synonyms = row.get("meta", {}).get("synonyms", [])
    patterns = [title, *synonyms]
    if glossary_id:
        patterns.append(glossary_id.split(":")[-1].replace("-", " "))
    for pattern in patterns:
        if not pattern:
            continue
        like = f"%{pattern.lower()}%"
        match = cursor.execute(
            """
            select concept_id
            from concepts
            where category='biases'
              and (lower(title)=? or lower(title) like ? or lower(aliases_json) like ?)
            limit 1
            """,
            (pattern.lower(), like, like),
        ).fetchone()
        if match:
            return True
    return False


def is_deferred_aiglossary_row(row: dict) -> bool:
    return row.get("meta", {}).get("gap_fill_batch") == DEFERRED_AIGLOSSARY_GAP_FILL_BATCH


def main() -> None:
    load_server_module()
    from server import (  # pylint: disable=import-error,import-outside-toplevel
        DEFAULT_DB_PATH,
        Repository,
        advanced_audit_payload,
        audit_text_payload,
        map_audit_tensions_payload,
        propose_mitigation_rewrite_payload,
        run_independent_audit_analysis_payload,
        synthesize_audit_verdict_payload,
    )

    repo = Repository(DEFAULT_DB_PATH)
    for name in METHODOLOGY_BIASES:
        payload = repo.lookup_bias_public(name)
        assert payload["found"], name
        assert payload["id"].startswith("ct:biases:methodology:"), payload
    for name in METHODOLOGY_CONCEPTS:
        payload = repo.search_public(name, limit=5)
        assert any(name in (row.get("title") or "").lower() for row in payload["results"]), payload

    conn = sqlite3.connect(DEFAULT_DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = load_aiglossary_rows(DEFAULT_GLOSSARY)
    deferred_rows = [row for row in rows if is_deferred_aiglossary_row(row)]
    baseline_rows = [row for row in rows if not is_deferred_aiglossary_row(row)]
    missing = [row for row in baseline_rows if not glossary_bias_is_covered(conn.cursor(), row)]
    deferred_missing = [row for row in deferred_rows if not glossary_bias_is_covered(conn.cursor(), row)]
    assert not missing, missing[:10]

    audit = audit_text_payload(
        repo,
        RESEARCH_SAMPLE,
        text_type="research",
        snapshot_mode="organizer",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    assert audit["retrieval_profile"] == "research_methodology"
    assert audit["research_methodology_hits"]["hits"]
    assert "critical_integrity_snapshot" in audit["quick_scan_card"]
    assert "display_policy" in audit["critical_integrity_snapshot"]
    assert audit["replication_readiness"]["applicable"] is True
    plain_read = audit["critical_integrity_snapshot"]["plain_language_read"]
    before_use = audit["critical_integrity_snapshot"]["before_using_this_text"]
    assert plain_read and plain_read.endswith(".") and len(plain_read.split()) <= 24, plain_read
    assert before_use.startswith("Before using this text, ") and len(before_use.split()) <= 24, before_use
    assert audit["report_readiness_contract"]["canonical_payload_rule"].startswith("Use the canonical keys")
    assert "critical_integrity_snapshot" in audit["report_readiness_contract"]["canonical_audit_data_template"]
    assert "Plain-Language Read" in audit["report_readiness_contract"]["markdown_checkpoint_template"]
    assert "complete_payload_example" in audit["report_readiness_contract"]
    profile_only_audit = audit_text_payload(
        repo,
        "Trust us.",
        text_type="general",
        snapshot_mode="organizer",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    profile_plain = profile_only_audit["critical_integrity_snapshot"]["plain_language_read"]
    profile_before = profile_only_audit["critical_integrity_snapshot"]["before_using_this_text"]
    assert profile_plain and profile_only_audit["critical_integrity_snapshot"]["display_state"] == "profile_only"
    assert profile_before.startswith("Before using this text, ")

    advanced = advanced_audit_payload(
        repo,
        RESEARCH_SAMPLE,
        "agent",
        text_type="research",
        depth="standard",
        scaffold_detail="handoff",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    assert advanced["status"] == "agentic_plan_review_required"
    advanced = advanced_audit_payload(
        repo,
        RESEARCH_SAMPLE,
        "agent",
        text_type="research",
        depth="standard",
        scaffold_detail="handoff",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
        agentic_state={"plan_approved": True, "approved_plan_hash": advanced["agentic_plan_hash"]},
    )
    assert advanced["retrieval_profile"] == "research_methodology"
    assert advanced["prepopulated_replication_readiness"]["applicable"] is True
    assert "Replication Readiness" in advanced["candidate_model_pool"][0]["title"]
    assert "report_readiness_contract" in advanced
    assert "advanced_audit" in advanced["report_readiness_contract"]["canonical_audit_data_template"]
    assert not any(
        banned in str(advanced["candidate_model_pool"]).lower()
        for banned in ["job search", "resume", "woop", "targeting matrix"]
    )

    analysis = run_independent_audit_analysis_payload(
        RESEARCH_SAMPLE,
        [{"agent_id": "agent_1", "name": "Methodologist"}],
        text_type="research",
        scaffold_detail="handoff",
        retrieval_profile="auto",
    )
    assert analysis["stage_handoff"]["stage"] == "independent_analysis"
    assert analysis["retrieval_profile"] == "research_methodology"
    assert "snapshot_dimension_evidence" in str(analysis["required_output_fields"])

    tensions = map_audit_tensions_payload(
        [{"agent_id": "agent_1", "agent_name": "Methodologist"}],
        subject=RESEARCH_SAMPLE,
        scaffold_detail="compact",
    )
    assert "snapshot_impact" in str(tensions["output_schema"])

    synth = synthesize_audit_verdict_payload(
        RESEARCH_SAMPLE,
        [{"agent_id": "agent_1"}],
        [{"agent_id": "agent_1"}],
        [{"tension_id": "tension_1"}],
        {"debate_exchange": []},
        text_type="research",
        biases_found=["WEIRD bias"],
        snapshot_mode="organizer",
        scaffold_detail="handoff",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    assert "cis_revision_trace" in str(synth["required_output_fields"])
    assert "display_policy" in str(synth["required_output_fields"])
    assert "agent_contribution_matrix" in str(synth["required_output_fields"])
    assert "replication_readiness" in str(synth["required_output_fields"])
    assert "report_ready_materials" in str(synth["required_output_fields"])
    assert synth["report_readiness_contract"]["stage"] == "synthesize_audit_verdict"
    assert "canonical_payload_template" in synth["optional_report_generation"]
    assert any("Markdown checkpoint" in item for item in synth["report_readiness_contract"]["pre_call_checklist"])
    assert propose_mitigation_rewrite_payload(RESEARCH_SAMPLE)["tool"] == "propose_mitigation_rewrite"

    print("research audit coverage validation ok")
    print(f"aiglossary baseline bias/llm-bias rows covered: {len(baseline_rows)}")
    if deferred_rows:
        print(
            "deferred AIGlossary draft gap-fill rows: "
            f"{len(deferred_rows)} total, {len(deferred_missing)} not yet in the Critical Compass beta.10 corpus"
        )
    print(f"advanced top flow: {advanced['candidate_model_pool'][0]['title']}")
    print(
        "replication readiness: "
        f"{audit['replication_readiness']['label']} ({audit['replication_readiness']['points']} points)"
    )


if __name__ == "__main__":
    main()
