import fs from "fs";
import path from "path";
import vm from "vm";

const ROOT = "/Volumes/KyleSSD/CriticalThinking";
const TEMPLATE_FILES = [
  {
    path: "/Volumes/KyleSSD/Websites/AIGlossary/glossary/js/templates.data.js",
    collection: "template"
  },
  {
    path: "/Volumes/KyleSSD/Websites/AIGlossary/glossary/js/templates.tasks.data.js",
    collection: "task"
  }
];
const PACK_PATH = path.join(ROOT, "support/library/phase2-step1-gaps.pack.json");
const FLOW_DIR = path.join(ROOT, "support/reasoning-flows");
const FLOW_PATH = path.join(FLOW_DIR, "phase2-step1-gaps.flows.json");
const FLOW_SCHEMA_PATH = path.join(FLOW_DIR, "reasoning-flow.schema.json");
const FLOW_README_PATH = path.join(FLOW_DIR, "README.md");
const NORMALIZED_CATALOG_PATH = path.join(ROOT, "indexes/normalized-catalog.json");

const FLOW_NAMESPACES = {
  EPISTEMIC_CORE: "epistemic_core",
  APPLIED_REASONING: "applied_reasoning"
};

const APPLIED_REASONING_TITLES = new Set([
  "BDD (Given–When–Then) → Tests → Code — Reusable Template",
  "User Stories & Acceptance Criteria → Developer-Ready Brief"
]);

const MISSING_TITLES = [
  "2-Minute Rule (David Allen)",
  "FAB — Feature · Advantage · Benefit",
  "PAR — Problem · Action · Result",
  "Pomodoro Scaffold",
  "RAP — Result · Action · Problem",
  "RICE — Reach × Impact × Confidence ÷ Effort",
  "Role Storming — Ideation as different personas",
  "Synesthetic Brainstorm — Color · Sound · Texture",
  "Wishing — Imagine ideal solutions",
  "WOOP (Wish–Outcome–Obstacle–Plan)",
  "Playback Theatre — Confession Line",
  "Clown ‘Flop’ — Failure Seen Safely",
  "Contact Improv — Listening Duet",
  "Story Spine + One Naked Sentence",
  "OKRs — With Kill Criteria",
  "Ikigai — Purpose Map",
  "Collective Impact — Common Agenda, Shared Measurement, Backbone",
  "Public Narrative (Marshall Ganz) — Story of Self, Us, Now",
  "Public Narrative - Structure shared story and call to action",
  "Personal Kanban + WIP Limits — Backlog → Doing (limit 1–3) → Done",
  "User Stories & Acceptance Criteria → Developer-Ready Brief",
  "Targeting Matrix: Role × Industry × Location × Company Size",
  "Value Proposition Canvas (Personal)",
  "BDD (Given–When–Then) → Tests → Code — Reusable Template",
  "STAR / SOAR Stories (Job Search)",
  "Pipeline Kanban — Leads → Applied → Interviewing → Offer → Closed",
  "Informational-Interview Ladder — 2/day → 5/week → 50/quarter (Ask for insights, not jobs)",
  "OKRs (Job Search) — Land X Offers",
  "Email — Draft & Polish",
  "DM — Outreach & Follow-up",
  "Memo — TL;DR + Recommendation",
  "Letter — Formal / Personal",
  "Announcement — Change & Action",
  "Press Release — AP Style",
  "Resume — Tailor / Rewrite / Feedback",
  "Cover Letter — Tailor / Rewrite / Feedback",
  "Social Media Post — Tailor / Write / Brainstorm",
  "Survey — Plan — Design",
  "Questionnaire — Write",
  "Screener — Create Criteria",
  "Interviews — Plan & Questions — Write",
  "Usability Test — Plan",
  "Task Scenarios — Write",
  "UX Microcopy — Write",
  "PRD — Write",
  "Backlog — Prioritize",
  "Travel — Door-to-Door Planner",
  "Health — Symptom Log & Clinician Brief",
  "Jobs — Alignment, Targeting, Stories & Pipeline",
  "Week Planning — Focus, Triage & Motivation",
  "Product — Plain Words → Specs → Code",
  "Language Optimizer — ATS · Domain · SEO · AIEO",
  "Branding Strategy & Visual Identity",
  "Website Metadata & SEO Builder",
  "Comprehensive Competitive Landscape — Market-Wide SWOT+"
];

const MANUAL_GAPS = [
  {
    source_slug: "dependent-origination-pratityasamutpada",
    title: "Buddhist Dependent Origination / Pratityasamutpada",
    kind: "framework",
    categories: ["thinking-lenses", "systems", "buddhist-philosophy", "causal-interdependence"],
    tags: [
      "topic:systems",
      "topic:causality",
      "topic:interdependence",
      "tradition:buddhist",
      "use:attribution-error-reduction",
      "use:sensemaking"
    ],
    aliases: ["Dependent Origination", "Pratityasamutpada", "Pratītyasamutpāda", "Paticca-samuppada"],
    use_cases: [
      "Map how conditions co-produce an outcome instead of assigning single-cause blame.",
      "Identify intervention points in a reinforcing pattern.",
      "Reduce person-centered over-attribution by separating actors from conditioning factors."
    ],
    boosters: [
      "List the conditions that make the outcome possible.",
      "Mark which conditions are controllable, influenceable, or contextual.",
      "Name one intervention that changes a condition rather than blaming an actor."
    ],
    definition:
      "A Buddhist analysis of phenomena as arising through dependent conditions rather than isolated essence or single causes. As a Critical Compass lens, it helps map conditionality, reduce blame-first explanations, and identify leverage points in systems.",
    help:
      "Use this when a situation looks like one person, event, or root cause is being over-weighted. Build a condition map, test how each condition contributes, and choose an intervention that changes the pattern.",
    notes:
      "Attribution: Buddhist philosophical traditions, with Pali and Sanskrit formulations of dependent arising. Caution: this is a critical-thinking adaptation, not an authoritative religious teaching; do not treat Buddhist traditions as interchangeable or use this entry to summarize sacred, lineage-specific, or restricted instruction."
  },
  {
    source_slug: "madhyamaka-catuskoti-buddhist-tetralemma",
    title: "Madhyamaka Catuskoti / Buddhist Tetralemma",
    kind: "framework",
    categories: ["reasoning-frameworks", "argumentation", "buddhist-philosophy", "logic"],
    tags: [
      "topic:argumentation",
      "topic:logic",
      "topic:paradox",
      "tradition:madhyamaka",
      "use:false-binary-check",
      "use:perspective-diversity"
    ],
    aliases: ["Catuskoti", "Catuṣkoṭi", "Buddhist Tetralemma", "Fourfold Negation"],
    use_cases: [
      "Interrogate false binaries or rigid yes/no framings.",
      "Test whether a claim depends on an assumed essence or excluded middle.",
      "Open alternative positions before choosing a working stance."
    ],
    boosters: [
      "State the claim in four modes: is, is not, both, neither.",
      "Record what each mode reveals or makes impossible.",
      "Choose a provisional stance and name its limits."
    ],
    definition:
      "A four-cornered Madhyamaka reasoning pattern that examines a proposition as true, false, both, and neither. In critical-thinking use, it exposes brittle binaries and clarifies where a category, identity, or claim may be over-reified.",
    help:
      "Use when a debate is trapped in either/or language. Work through the four alternatives, note what each exposes, then produce a provisional judgment rather than a metaphysical conclusion.",
    notes:
      "Attribution: Madhyamaka Buddhist philosophical traditions associated with figures such as Nagarjuna. Caution: this is a reasoning aid, not a substitute for textual study, teacher guidance, or lineage-specific interpretation; do not flatten Buddhist schools into one generic view."
  },
  {
    source_slug: "intersectionality",
    title: "Intersectionality",
    kind: "framework",
    categories: ["thinking-lenses", "systems", "structural-analysis", "equity"],
    tags: [
      "topic:power",
      "topic:identity",
      "topic:systems",
      "topic:structural-analysis",
      "use:blindspot-reduction",
      "use:co-leadership"
    ],
    aliases: ["Intersectional analysis", "Intersectional lens"],
    use_cases: [
      "Analyze how overlapping structures of power shape risk, access, credibility, or harm.",
      "Avoid treating one identity category as a complete explanation.",
      "Design decisions that account for people located at multiple structural margins."
    ],
    boosters: [
      "List the relevant power structures, not just identity labels.",
      "Identify who is made invisible by single-axis analysis.",
      "Name one decision change that reduces compounded harm."
    ],
    definition:
      "A framework for analyzing how systems of power interact across race, gender, class, disability, sexuality, and other social positions. It belongs in Critical Compass because it detects single-axis blind spots and improves harm forecasting in decisions.",
    help:
      "Use when a policy, product, claim, or team process risks averaging away people at compounded margins. Compare single-axis and intersectional readings, then revise the decision or evidence plan.",
    notes:
      "Attribution: Kimberle Crenshaw's legal scholarship and Black feminist thought, with broader roots in women-of-color feminist organizing. Caution: do not reduce intersectionality to identity checklists; center structures, context, and situated evidence."
  },
  {
    source_slug: "conscientization-critical-consciousness",
    title: "Conscientization / Critical Consciousness",
    kind: "framework",
    categories: ["thinking-lenses", "reflective", "critical-pedagogy", "praxis"],
    tags: [
      "topic:reflection",
      "topic:praxis",
      "topic:power",
      "topic:education",
      "use:co-leadership",
      "use:liberatory-learning"
    ],
    aliases: ["Critical consciousness", "Conscientizacao", "Conscientização", "Paulo Freire praxis"],
    use_cases: [
      "Move from private frustration to structural analysis and accountable action.",
      "Design learning, facilitation, or leadership practices that connect reflection with praxis.",
      "Check whether a process invites agency or trains compliance."
    ],
    boosters: [
      "Name the lived problem and the structure that reproduces it.",
      "Separate charity, service, advocacy, and power-sharing options.",
      "Commit to one reflection-action loop with affected people."
    ],
    definition:
      "A critical pedagogy concept describing the development of awareness about social, political, and economic contradictions, paired with action to transform oppressive conditions. In Critical Compass it supports structural diagnosis, agency, and reflection-action loops.",
    help:
      "Use when a learning, leadership, or change process risks stopping at awareness. Convert observations into structural questions, then define a concrete praxis loop.",
    notes:
      "Attribution: Paulo Freire and Latin American critical pedagogy traditions. Caution: this entry is a critical-thinking adaptation and should not be detached from its anti-oppressive, dialogical, and community-rooted commitments."
  },
  {
    source_slug: "ladder-of-inference",
    title: "Ladder of Inference",
    kind: "framework",
    categories: ["reasoning-frameworks", "inference", "metacognition", "sensemaking"],
    tags: [
      "topic:inference",
      "topic:assumptions",
      "topic:metacognition",
      "use:inference-error-reduction",
      "use:decision-quality"
    ],
    aliases: ["Argyris Ladder of Inference", "Inference ladder"],
    use_cases: [
      "Debug how raw observations became assumptions, meanings, conclusions, and actions.",
      "Slow down team conflict by separating data from interpretation.",
      "Identify missing evidence before acting on a confident story."
    ],
    boosters: [
      "Write the observed data before interpretation.",
      "Mark the selected data and assumptions.",
      "Test one alternate meaning before choosing an action."
    ],
    definition:
      "A reasoning model associated with Chris Argyris that traces how people move from observable data to selected facts, interpretations, assumptions, conclusions, beliefs, and actions. It helps expose hidden inference jumps and reduce overconfident narratives.",
    help:
      "Use when a conclusion feels obvious but the evidence chain is unclear. Climb down to observable data, inspect each inference rung, and revise the action if a rung is weak.",
    notes:
      "Attribution: Chris Argyris and organizational learning work popularized in systems-thinking practice. Caution: use it to inspect reasoning, not to dismiss emotion or lived experience."
  },
  {
    source_slug: "cynefin-framework",
    title: "Cynefin Framework — Domain-sensitive sensemaking",
    kind: "framework",
    categories: ["thinking-lenses", "systems", "complexity", "sensemaking"],
    tags: [
      "topic:complexity",
      "topic:sensemaking",
      "topic:systems",
      "use:decision-quality",
      "use:uncertainty"
    ],
    aliases: ["Cynefin", "Cynefin Framework"],
    use_cases: [
      "Choose different decision methods for clear, complicated, complex, chaotic, or confused domains.",
      "Avoid over-applying best practices to emergent or high-uncertainty situations.",
      "Select whether to sense-categorize-respond, sense-analyze-respond, probe-sense-respond, or act-sense-respond."
    ],
    boosters: [
      "Classify the domain using evidence, not preference.",
      "Choose the matching action mode for that domain.",
      "Name a trigger that would move the situation to another domain."
    ],
    definition:
      "A sensemaking framework developed by Dave Snowden and collaborators for matching action to domain type: clear, complicated, complex, chaotic, and confused. It belongs in Critical Compass because it prevents category errors in uncertainty, expertise, and intervention design.",
    help:
      "Use when people are arguing over whether to analyze, experiment, standardize, or act immediately. Classify the decision environment, choose the matching response pattern, and define a domain-change trigger.",
    notes:
      "Attribution: Dave Snowden and The Cynefin Centre/Cognitive Edge body of work. Caution: do not use the domains as personality labels or fixed taxonomies; treat them as situated sensemaking states."
  }
];

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`);
}

function slugify(input) {
  return String(input || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-{2,}/g, "-");
}

function uniqueStrings(values) {
  return [...new Set((values || []).map((value) => String(value || "").trim()).filter(Boolean))];
}

function plainText(value) {
  if (value == null) return "";
  if (Array.isArray(value)) return value.map(plainText).filter(Boolean).join(" ");
  if (typeof value === "object") return Object.values(value).map(plainText).filter(Boolean).join(" ");
  return String(value).replace(/\s+/g, " ").trim();
}

function tagObject(rawInput) {
  const raw = String(rawInput || "").trim();
  if (!raw) return null;
  const [namespacePart, ...rest] = raw.split(":");
  const namespace = rest.length ? namespacePart.trim() || "topic" : "topic";
  const value = rest.length ? rest.join(":").trim() : slugify(raw);
  return {
    raw,
    namespace,
    value: value || slugify(raw)
  };
}

function tagsFrom(values) {
  const seen = new Set();
  const tags = [];
  for (const value of values || []) {
    const tag = tagObject(value);
    if (!tag || seen.has(tag.raw)) continue;
    seen.add(tag.raw);
    tags.push(tag);
  }
  return tags.sort((a, b) => a.raw.localeCompare(b.raw));
}

function fieldObject(field, index) {
  const label = String(field?.label || field?.key || `Input ${index + 1}`).trim();
  const key = slugify(field?.key || label).replace(/-/g, "_") || `input_${index + 1}`;
  const options = Array.isArray(field?.options)
    ? field.options.map((option) => {
        if (typeof option === "object" && option) return plainText(option.label || option.value || option.name);
        return plainText(option);
      }).filter(Boolean)
    : [];
  return {
    label,
    key,
    type: String(field?.type || "text").trim(),
    description: String(field?.description || field?.desc || "").trim(),
    placeholder: String(field?.placeholder || field?.ph || "").trim(),
    options
  };
}

function buildSearchText(record) {
  return uniqueStrings([
    record.title,
    record.source_slug,
    record.definition,
    record.help,
    record.notes,
    ...(record.aliases || []),
    ...(record.categories || []),
    ...(record.tags || []).map((tag) => tag.raw || `${tag.namespace}:${tag.value}`),
    ...(record.use_cases || []),
    ...(record.boosters || []),
    ...(record.fields || []).flatMap((field) => [field.label, field.description, field.placeholder])
  ]).join(" ").toLowerCase();
}

function baseRecord(input) {
  const sourceSlug = slugify(input.source_slug || input.slug || input.label || input.title);
  const kind = input.kind || null;
  const tags = tagsFrom([
    ...(input.tags || []),
    kind ? `kind:${kind}` : null,
    "source:phase2-step1-gap"
  ].filter(Boolean));
  const record = {
    entry_id: `phase2:${sourceSlug}`,
    collection: "framework",
    source_slug: sourceSlug,
    title: input.title || input.label,
    kind,
    status: "verified",
    definition: String(input.definition || "").trim(),
    help: String(input.help || "").trim(),
    notes: String(input.notes || "").trim(),
    aliases: uniqueStrings([sourceSlug, input.id, input.slug, ...(input.aliases || [])]),
    categories: uniqueStrings(input.categories || []),
    tags,
    use_cases: uniqueStrings(input.use_cases || []),
    boosters: uniqueStrings(input.boosters || []),
    fields: (input.fields || []).map(fieldObject),
    related_entry_ids: uniqueStrings(input.related_entry_ids || []),
    relationships: [],
    provenance: {
      source_kind: input.source_kind || "knowledge-architect-gap-audit",
      source_path: input.source_path || "",
      source_type: input.source_type || "",
      source_collection: input.source_collection || "",
      source_slug: sourceSlug,
      source_title: input.title || input.label,
      phase: "phase2-step1-gaps"
    },
    quality_flags: [
      {
        code: "phase2-step1-gap",
        severity: "info",
        message: input.quality_message || "Imported from the Step 1 gap audit for Phase 2."
      }
    ],
    search_text: ""
  };
  record.search_text = buildSearchText(record);
  return record;
}

function loadTemplateFile(filePath) {
  const code = fs.readFileSync(filePath, "utf8");
  const context = {
    console,
    module: { exports: {} },
    exports: {}
  };
  vm.createContext(context);
  vm.runInContext(code, context, { filename: filePath });
  const candidates = [
    context.module?.exports,
    context.TEMPLATES,
    context.FRAMEWORKS,
    context.TASK_TEMPLATES,
    context.TASKS
  ];
  const match = candidates.find(Array.isArray);
  if (!match) {
    throw new Error(`Could not load template array from ${filePath}`);
  }
  return match;
}

function buildConceptPack() {
  const missingSet = new Set(MISSING_TITLES);
  const found = [];
  const sourceCounts = {};
  for (const source of TEMPLATE_FILES) {
    const items = loadTemplateFile(source.path);
    sourceCounts[source.collection] = items.length;
    for (const item of items) {
      if (!missingSet.has(item.label)) continue;
      found.push(
        baseRecord({
          ...item,
          title: item.label,
          source_path: source.path,
          source_type: "js",
          source_collection: source.collection,
          source_kind: "phase2-step1-js-gap"
        })
      );
    }
  }

  const foundTitles = new Set(found.map((record) => record.title));
  const missingFromSources = MISSING_TITLES.filter((title) => !foundTitles.has(title));
  if (missingFromSources.length) {
    throw new Error(`Could not find ${missingFromSources.length} Step 1 titles in JS sources:\n${missingFromSources.join("\n")}`);
  }

  const duplicateTitles = found
    .map((record) => record.title)
    .filter((title, index, titles) => titles.indexOf(title) !== index);
  if (duplicateTitles.length) {
    throw new Error(`Duplicate Step 1 titles found in JS sources: ${uniqueStrings(duplicateTitles).join(", ")}`);
  }

  const manualRecords = MANUAL_GAPS.map((gap) => baseRecord(gap));
  const records = [...found, ...manualRecords].sort((a, b) => a.title.localeCompare(b.title));
  if (records.length !== 61) {
    throw new Error(`Expected 61 Phase 2 records, got ${records.length}`);
  }

  writeJson(PACK_PATH, records);
  console.log(JSON.stringify({
    wrote: PACK_PATH,
    records: records.length,
    js_records: found.length,
    manual_records: manualRecords.length,
    template_count: sourceCounts.template,
    task_count: sourceCounts.task
  }, null, 2));
}

function step(stepId, name, instruction, whyThisStep, inputRequired, outputFormat, completionCheck, ifStuck) {
  return {
    step_id: String(stepId),
    name,
    instruction,
    why_this_step: whyThisStep,
    input_required: inputRequired,
    output_format: outputFormat,
    completion_check: completionCheck,
    if_stuck: ifStuck
  };
}

function classifyFlow(record) {
  const routingTags = (record.tags || [])
    .map((tag) => tag.raw || "")
    .filter((tag) => /^(kind|topic|use|phase|type|tradition|level):/.test(tag));
  const blob = [
    record.title,
    record.kind,
    record.definition,
    record.help,
    ...(record.categories || []),
    ...routingTags,
    ...(record.use_cases || [])
  ].join(" ").toLowerCase();
  return {
    cultural: /buddhist|madhyamaka|catuskoti|pratityasamutpada|ikigai|theatre|clown|contact improv|intersectionality|conscientization|critical consciousness|public narrative|collective impact/.test(blob),
    planning: /prioritize|planning|kanban|okr|rice|pipeline|targeting|backlog|week planning|jobs|travel|roadmap|competitive|score|matrix|wip|offers|portfolio/.test(blob),
    communication: /email|dm|memo|letter|announcement|press release|resume|cover letter|social media|microcopy|language optimizer|branding|metadata|seo|narrative|story|questionnaire|interviews|survey|prd|brief|write|draft|polish/.test(blob),
    health: /health|symptom|clinician|medical/.test(blob),
    task: record.kind === "task",
    compact: ["heuristic", "tool"].includes(record.kind)
  };
}

function flowNamespaceFor(record) {
  if (record.kind === "task") return FLOW_NAMESPACES.APPLIED_REASONING;
  if (APPLIED_REASONING_TITLES.has(record.title)) return FLOW_NAMESPACES.APPLIED_REASONING;
  return FLOW_NAMESPACES.EPISTEMIC_CORE;
}

function culturalCautionStep(stepId) {
  return step(
    stepId,
    "Confirm attribution and boundaries",
    "State the named tradition, community, or source lineage used by this lens. Write one caution sentence that limits generalization, excludes sacred or restricted knowledge claims, and frames the lens as a critical-thinking aid.",
    "Culturally grounded entries need source discipline before the model applies them.",
    "The source entry notes plus the user's context.",
    "Two bullets: `Attribution:` and `Caution:`.",
    "The output names a specific tradition or source and includes a clear anti-flattening caution.",
    "If the source is unclear, write `Attribution uncertain from available entry` and proceed only with the non-sacred operational framing."
  );
}

function communicationSteps(record) {
  return [
    step(1, "Define audience and job", "Identify the audience, the action you want from them, the relationship context, and the channel constraints. Do not draft yet.", "Writing quality depends on audience, intent, and constraints before phrasing.", "User goal, audience, channel, constraints, and source material.", "A four-row table: `Audience`, `Desired action`, `Relationship/context`, `Constraints`.", "Each row has a specific value or is marked `missing`.", "Ask for only the missing item that blocks drafting; otherwise make a labeled assumption."),
    step(2, "Extract source points", "List the facts, claims, asks, examples, and required details that must appear in the output. Mark each item as `given`, `inferred`, or `needs verification`.", "This prevents polished language from outrunning the evidence.", "Any notes, rough draft, links, or context supplied by the user.", "A bullet list with source status labels.", "No important supplied detail is omitted; unverifiable details are flagged.", "If source material is thin, create a minimal assumption ledger instead of inventing facts."),
    step(3, "Choose structure", "Select the smallest structure that fits the task. Name the opening, middle, close, and call-to-action before drafting.", "A visible structure keeps the output operational rather than merely stylish.", "Audience table and source points.", "A numbered outline with section purpose and key points.", "The outline contains a clear CTA or final decision point.", "Use a simple TL;DR, context, recommendation, next step structure."),
    step(4, "Draft the output", "Write the complete draft in the requested format and tone. Use plain language, keep the ask explicit, and avoid unsupported claims.", "The flow must produce a usable artifact, not just analysis.", "Chosen structure and source points.", "A complete draft ready for user review.", "The draft includes all required points and no items marked `needs verification` as facts.", "If tone is unspecified, use concise, professional, human language."),
    step(5, "Revise against constraints", "Run a final pass for clarity, length, audience fit, risk, and actionability. List the changes made and provide the final version.", "Revision is where the draft becomes shippable.", "Draft and constraints.", "A short QA checklist followed by `Final:`.", "Every constraint is checked pass/fail and failures are corrected or disclosed.", "If a constraint conflicts with another, state the tradeoff and choose the safer option.")
  ];
}

function planningSteps(record) {
  return [
    step(1, "Frame the decision", "State the objective, scope, deadline, available capacity, and what will not be considered in this pass.", "Planning tools fail when the target and boundaries stay vague.", "Goal, options, constraints, and timeline.", "A five-row framing table.", "The objective and exclusion boundary are explicit.", "If the scope is too wide, narrow to the next seven days or the next decision."),
    step(2, "Inventory options", "List each candidate item, task, stakeholder, lead, or option. Add one sentence of evidence or context for each.", "The model needs a visible option set before prioritization.", "Backlog, notes, candidates, or rough ideas.", "A table with `Option`, `Evidence/context`, and `Unknowns`.", "Every option is distinct and unknowns are marked.", "If there are too many options, cluster them and keep the top 10 by urgency or value."),
    step(3, "Set criteria", "Choose 3 to 5 criteria from the source entry or the user's stated goal. Define the scoring scale for each criterion before scoring.", "Criteria prevent vibes-based prioritization and make tradeoffs reviewable.", "Objective and option inventory.", "A criteria table with scale definitions.", "Each criterion has a clear high and low anchor.", "Default to value, urgency, confidence, effort, and risk when no criteria are given."),
    step(4, "Score and compare", "Score every option against the criteria, show the total or ranking logic, and identify ties or low-confidence scores.", "Visible scoring exposes hidden assumptions and helps users challenge the result.", "Criteria table and option inventory.", "A scoring table plus a ranked list.", "Each rank is traceable to criteria rather than preference alone.", "If evidence is missing, mark the score as provisional instead of filling it with certainty."),
    step(5, "Apply tie-breaks and kill criteria", "Apply any kill criteria, WIP limits, disqualifiers, or tie-break rules. Remove or defer items that fail the gate.", "Good prioritization also says what not to do.", "Ranked list and constraints.", "A `Do`, `Defer`, `Drop`, and `Watch` list.", "At least one concrete non-action or defer decision is named when the list is crowded.", "If nothing can be dropped, reduce the active WIP to the smallest viable next step."),
    step(6, "Commit next action", "Write the next physical action, owner, due date, and evidence that will show progress.", "The flow should end in execution, not more organizing.", "Final prioritized list.", "One action line: `Do X by Y; owner Z; proof of progress P`.", "The action can be started without further planning.", "If the action is still abstract, rewrite it as a 15-minute task.")
  ];
}

function taskSteps(record) {
  return [
    step(1, "Frame the judgment and artifact", "State the artifact or plan to produce, the decision or communication judgment it requires, the audience or stakeholder, success criteria, and what is out of scope.", "Applied flows should start by naming the reasoning job behind the deliverable, not by drafting.", "User request, target artifact, audience or stakeholder, and available context.", "A `Judgment contract` table with `Artifact`, `Decision/judgment`, `Audience/stakeholder`, `Success criteria`, and `Out of scope`.", "The artifact and the judgment it depends on are both explicit.", "If the user request is broad, choose the smallest useful artifact and label the assumption."),
    step(2, "Surface assumptions, stakes, and risks", "List the assumptions, audience stakes, constraints, tradeoffs, and plausible harms or failure modes. Mark each item as provided, inferred, or unknown.", "Professional artifacts encode choices; this step makes those choices reviewable before polish hides them.", "Judgment contract plus notes, documents, policies, examples, and prior drafts.", "A ledger grouped under `Assumptions`, `Stakes`, `Constraints`, `Tradeoffs`, and `Risks`.", "No inferred item is presented as provided, and at least one risk or tradeoff is named.", "If context is thin, create a provisional ledger and mark confidence low instead of inventing facts."),
    step(3, "Check evidence and missing inputs", "Extract the facts, claims, examples, metrics, or source details that support the artifact. Name missing inputs that would materially change the output and decide whether to proceed, narrow scope, or ask for one blocker.", "This prevents document production from outrunning evidence.", "Source material, evidence ledger, user constraints, and known uncertainties.", "A table with `Claim/detail`, `Evidence status`, `Use in artifact`, and `Missing input`.", "Each major claim or detail is supported, caveated, or excluded.", "If evidence is missing, write a safe placeholder or narrower version rather than filling the gap with certainty."),
    step(4, "Choose the artifact strategy", "Select the structure, stance, prioritization, or messaging strategy that best fits the evidence, audience, risks, and constraints. Reject at least one plausible alternative and explain why.", "A visible strategy choice keeps the output from becoming generic template text.", "Judgment contract, risk ledger, and evidence table.", "A brief `Chosen strategy` note plus one `Rejected alternative`.", "The strategy follows from the evidence and constraints rather than style preference alone.", "If alternatives tie, choose the option with lower risk, clearer ask, or stronger evidence."),
    step(5, "Produce the artifact", "Create the requested artifact, plan, draft, table, or checklist using only supported claims and explicitly caveated assumptions. Keep the requested format and make the main ask or recommendation visible.", "The flow still ships the practical output after the reasoning pass.", "Chosen strategy and supported source details.", "The requested artifact or plan in its final working format.", "The artifact is usable now and does not present unknowns as facts.", "If the artifact cannot be completed, provide the strongest safe partial and name the single missing input that would complete it."),
    step(6, "Run the quality gate", "Check the artifact against success criteria, risks, audience stakes, and evidence limits. State what would change the recommendation or output, then provide one next action.", "Applied reasoning needs a final falsifiability and safety check, not just polish.", "Produced artifact, judgment contract, and risk ledger.", "A `Quality gate` checklist followed by `Would change if:` and `Next action:`.", "Every failed check is fixed or disclosed, and the next action is concrete.", "If criteria conflict, prefer accuracy, safety, and user intent over polish.")
  ];
}

function compactSteps(record) {
  return [
    step(1, "Name the target", "State the specific decision, task, habit, idea, or problem this tool will act on.", "Compact tools need a tight target to stay useful.", "User context and goal.", "One sentence beginning `Target:`.", "The target is concrete and bounded.", "If broad, narrow to the next action or next decision."),
    step(2, "Run the checklist", "Apply the tool's core rule or checklist to the target. Show each check and its result.", "A visible checklist makes the heuristic operational.", "Target plus any relevant constraints.", "A short table with `Check`, `Result`, and `Evidence`.", "Every check has an evidence-backed result.", "If evidence is missing, mark the row `unknown` and continue."),
    step(3, "Choose the move", "Select the best next move implied by the checklist and explain why it beats the nearest alternative.", "The user needs a decision, not only reflection.", "Checklist results.", "A recommendation with one rejected alternative.", "The recommendation follows from the checklist.", "If there is a tie, choose the lower-risk or lower-effort move."),
    step(4, "Define completion proof", "Name what visible proof will show the move is done.", "Completion proof prevents open-ended self-management loops.", "Recommended move.", "One line: `Done when:`.", "The proof is observable.", "If proof is vague, make it a file, message, calendar block, or sent artifact.")
  ];
}

function genericSteps(record) {
  return [
    step(1, "Frame the problem", "State the claim, question, decision, or system to examine. Include scope, stakeholders, and what output is required.", "The lens needs a bounded object before analysis.", "User context, claim, decision, or problem.", "A framing table with `Object`, `Scope`, `Stakeholders`, and `Required output`.", "The object of analysis is unambiguous.", "If the user gives multiple objects, choose the one with the highest consequence or nearest deadline."),
    step(2, "Extract evidence and assumptions", "List the facts, interpretations, uncertainties, and assumptions currently in play. Label each item by evidence status.", "This separates what is known from what is being inferred.", "Available notes, claims, observations, or data.", "A ledger with columns `Item`, `Type`, `Evidence status`.", "At least one uncertainty or assumption is explicitly named.", "If evidence is absent, proceed with a provisional ledger and mark confidence low."),
    step(3, "Apply the lens", "Use the source entry's core move to transform the problem. Extract the conditions, contrasts, categories, claims, or perspectives the lens requires.", "This is where the framework changes the user's view rather than restating it.", "Framing table and evidence ledger.", "A structured analysis table tailored to the lens.", "The table contains lens-specific outputs, not generic reflections.", "If the core move is unclear, use the definition and boosters as the required operations."),
    step(4, "Test alternatives", "Generate at least two alternative interpretations, decisions, or intervention points. Compare them against the evidence and assumptions.", "Good reasoning tests the first reading against plausible rivals.", "Lens analysis table.", "A comparison table with `Alternative`, `Support`, `Risk`, and `Confidence`.", "Each alternative has a confidence judgment and at least one risk.", "If alternatives are weak, steelman the strongest opposing view."),
    step(5, "Synthesize judgment", "Write the provisional conclusion, confidence level, key caveat, and what would change the conclusion.", "The output should be decisive while preserving uncertainty.", "Alternative comparison.", "Four bullets: `Conclusion`, `Confidence`, `Caveat`, `Would change if`.", "The conclusion is actionable and not overstated.", "If confidence is low, recommend an evidence-gathering step instead of a decision."),
    step(6, "Choose next action", "Name one concrete next action, owner, and visible output that follows from the judgment.", "Reasoning flows should close the loop into action.", "Synthesis judgment.", "One action line with owner and output.", "The action can be started now.", "If no owner is known, assign `user` or `decision owner` explicitly.")
  ];
}

function flowStepsFor(record) {
  const flags = classifyFlow(record);
  const namespace = flowNamespaceFor(record);
  let steps;
  if (namespace === FLOW_NAMESPACES.APPLIED_REASONING) steps = taskSteps(record);
  else if (flags.compact) steps = compactSteps(record);
  else if (flags.planning) steps = planningSteps(record);
  else if (flags.communication) steps = communicationSteps(record);
  else steps = genericSteps(record);

  if (!flags.cultural) return steps;

  const caution = culturalCautionStep(2);
  const [first, ...rest] = steps;
  const resequenced = [first, caution, ...rest];
  return resequenced.map((item, index) => ({ ...item, step_id: String(index + 1) }));
}

function outputContractFor(record) {
  if (flowNamespaceFor(record) === FLOW_NAMESPACES.APPLIED_REASONING) {
    return "Return a visible judgment audit, then the requested artifact or plan, then a quality gate naming what would change the output and one next action.";
  }
  if (classifyFlow(record).compact) {
    return "Return a compact checklist result, one recommended move, and observable completion proof.";
  }
  if (record.kind === "task") {
    return "Return the requested artifact first, followed by a concise QA checklist and one next action.";
  }
  if (classifyFlow(record).planning) {
    return "Return a prioritized table, explicit defer/drop decisions, and one committed next action.";
  }
  if (classifyFlow(record).communication) {
    return "Return the final draft or content artifact, plus a brief constraints check.";
  }
  return "Return a structured reasoning trace with evidence status, lens application, provisional judgment, and next action.";
}

function buildReasoningFlows() {
  if (!fs.existsSync(PACK_PATH)) throw new Error(`Missing concept pack: ${PACK_PATH}`);
  if (!fs.existsSync(NORMALIZED_CATALOG_PATH)) throw new Error(`Missing normalized catalog: ${NORMALIZED_CATALOG_PATH}. Run the corpus build first.`);

  const records = readJson(PACK_PATH);
  const catalog = readJson(NORMALIZED_CATALOG_PATH);
  const byTitle = new Map(catalog.map((row) => [row.title, row]));
  const flows = records.map((record) => {
    const catalogRow = byTitle.get(record.title);
    if (!catalogRow) {
      throw new Error(`Could not resolve normalized catalog row for ${record.title}`);
    }
    const steps = flowStepsFor(record);
    const flags = classifyFlow(record);
    const namespace = flowNamespaceFor(record);
    return {
      flow_id: `flow:${catalogRow.entry_id}`,
      entry_id: catalogRow.entry_id,
      entry_title: catalogRow.title,
      category: catalogRow.category,
      subcategory: catalogRow.subcategory,
      kind: catalogRow.kind || record.kind || "",
      namespace,
      purpose: namespace === FLOW_NAMESPACES.APPLIED_REASONING
        ? `Use ${catalogRow.title} as an applied reasoning protocol that audits judgment, evidence, constraints, risks, and tradeoffs before producing the requested artifact or plan.`
        : `Use ${catalogRow.title} as an executable reasoning protocol that produces a visible output and a concrete next action.`,
      best_used_when: (record.use_cases || []).slice(0, 5),
      inputs: [
        "User goal, claim, decision, task, or problem statement.",
        "Relevant source material, constraints, examples, and known uncertainties.",
        namespace === FLOW_NAMESPACES.APPLIED_REASONING || flags.communication
          ? "Audience, stakeholders, channel, tone, desired action, and artifact constraints."
          : "Decision criteria, evidence, or context when available."
      ],
      output_contract: outputContractFor(record),
      steps,
      quality_checks: [
        "Each step produces visible output before moving on.",
        "Assumptions are labeled and not presented as facts.",
        "The final recommendation or artifact traces back to the evidence and constraints.",
        namespace === FLOW_NAMESPACES.APPLIED_REASONING
          ? "The artifact appears only after the judgment, evidence, risk, and tradeoff checks."
          : flags.cultural
            ? "Culturally grounded material includes attribution and an anti-flattening caution."
            : "The flow does not add unnecessary reflection-only steps."
      ],
      failure_modes: [
        "Skipping the evidence or constraint ledger.",
        "Producing a polished answer without showing how the lens changed the reasoning.",
        "Ending with broad advice instead of one concrete next action.",
        namespace === FLOW_NAMESPACES.APPLIED_REASONING
          ? "Treating the flow as document production instead of applied critical judgment."
          : flags.cultural
            ? "Flattening a named tradition, community, or source into a generic cultural label."
            : "Over-expanding the scope beyond the user's immediate deliverable."
      ],
      anti_patterns: [
        "Vague instruction such as `consider the context` without a required output.",
        "Hidden chain-of-thought instead of visible tables, ledgers, scores, bullets, or artifacts.",
        "More planning after a shippable next action is already clear.",
        "Inventing facts, sources, or certainty to make the flow feel complete."
      ],
      source_entry: {
        id: catalogRow.entry_id,
        title: catalogRow.title,
        source_slug: record.source_slug
      }
    };
  }).sort((a, b) => a.entry_title.localeCompare(b.entry_title));

  if (flows.length !== 61) {
    throw new Error(`Expected 61 reasoning flows, got ${flows.length}`);
  }
  ensureDir(FLOW_DIR);
  writeJson(FLOW_PATH, flows);
  console.log(JSON.stringify({ wrote: FLOW_PATH, flows: flows.length }, null, 2));
}

function writeFlowSchemaAndReadme() {
  const schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    title: "Critical Compass Reasoning Flow Pack",
    type: "array",
    items: {
      type: "object",
      required: [
        "flow_id",
        "entry_id",
        "entry_title",
        "category",
        "subcategory",
        "kind",
        "namespace",
        "purpose",
        "best_used_when",
        "inputs",
        "output_contract",
        "steps",
        "quality_checks",
        "failure_modes",
        "anti_patterns",
        "source_entry"
      ],
      properties: {
        flow_id: { type: "string", pattern: "^flow:" },
        entry_id: { type: "string", minLength: 1 },
        entry_title: { type: "string", minLength: 1 },
        category: { type: "string", minLength: 1 },
        subcategory: { type: "string" },
        kind: { type: "string" },
        namespace: { enum: [FLOW_NAMESPACES.EPISTEMIC_CORE, FLOW_NAMESPACES.APPLIED_REASONING] },
        purpose: { type: "string", minLength: 1 },
        best_used_when: { type: "array", items: { type: "string" } },
        inputs: { type: "array", items: { type: "string" } },
        output_contract: { type: "string", minLength: 1 },
        steps: {
          type: "array",
          minItems: 3,
          items: {
            type: "object",
            required: [
              "step_id",
              "name",
              "instruction",
              "why_this_step",
              "input_required",
              "output_format",
              "completion_check",
              "if_stuck"
            ],
            properties: {
              step_id: { type: "string", minLength: 1 },
              name: { type: "string", minLength: 1 },
              instruction: { type: "string", minLength: 1 },
              why_this_step: { type: "string", minLength: 1 },
              input_required: { type: "string", minLength: 1 },
              output_format: { type: "string", minLength: 1 },
              completion_check: { type: "string", minLength: 1 },
              if_stuck: { type: "string", minLength: 1 }
            },
            additionalProperties: false
          }
        },
        quality_checks: { type: "array", items: { type: "string" } },
        failure_modes: { type: "array", items: { type: "string" } },
        anti_patterns: { type: "array", items: { type: "string" } },
        source_entry: {
          type: "object",
          required: ["id", "title", "source_slug"],
          properties: {
            id: { type: "string", minLength: 1 },
            title: { type: "string", minLength: 1 },
            source_slug: { type: "string", minLength: 1 }
          },
          additionalProperties: false
        }
      },
      additionalProperties: false
    }
  };
  writeJson(FLOW_SCHEMA_PATH, schema);
  fs.writeFileSync(FLOW_README_PATH, `# Critical Compass Reasoning Flows

Reasoning flows are file-backed, read-only executable protocols for Critical Compass concepts. They are intentionally stored outside the SQLite concept corpus so flow iteration does not require a schema migration.

## Files

- \`reasoning-flow.schema.json\` defines the required flow and step fields.
- \`phase2-step1-gaps.flows.json\` contains one flow for each Phase 2 Step 1 concept addition.

## Namespaces

- \`epistemic_core\` is the default Compass lane for reasoning lenses, bias-reduction models, argumentation, uncertainty, systems, structural, ethical, and methodology flows.
- \`applied_reasoning\` is the artifact lane for professional documents, communication, product, career, planning, and execution templates. These flows must audit judgment, evidence, constraints, risks, and tradeoffs before producing an artifact.

## Regeneration

1. Run \`node scripts/build-phase2-step1-gaps.mjs\` to rebuild the concept pack and flow schema/docs.
2. Run \`node scripts/build-critical-thinking-corpus.mjs\`.
3. Run \`node scripts/build-phase2-step1-gaps.mjs --flows\` so flows use normalized \`ct:<category>:<subcategory>:<slug>\` entry IDs.
4. Run \`seed_db.py\` to refresh the read-only MCP database.

Do not hand-edit generated Phase 2 flows unless the generator is updated to preserve the change.
`);
}

function main() {
  ensureDir(path.dirname(PACK_PATH));
  ensureDir(FLOW_DIR);
  const flowsOnly = process.argv.includes("--flows");
  if (flowsOnly) {
    buildReasoningFlows();
    return;
  }
  buildConceptPack();
  writeFlowSchemaAndReadme();
}

main();
