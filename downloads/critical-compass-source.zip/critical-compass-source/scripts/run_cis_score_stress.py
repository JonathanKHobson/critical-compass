#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.run_beta_audit_calibration import ensure_real_audit_report_package, install_fake_mcp_modules

CASES_PATH = ROOT / "support" / "evals" / "cis_score_stress_cases.json"
OUTPUT_DIR = ROOT / "reports" / "cis-score-stress"
DB_PATH = ROOT / "db" / "critical-compass.sqlite"


def _snapshot_row(case: dict[str, Any], result: dict[str, Any], *, run_index: int | None = None) -> dict[str, Any]:
    snapshot = result.get("critical_integrity_snapshot") if isinstance(result.get("critical_integrity_snapshot"), dict) else {}
    return {
        "id": case.get("id"),
        "run_index": run_index,
        "expected_band": case.get("expected_band"),
        "status": result.get("status"),
        "points": snapshot.get("points"),
        "label": snapshot.get("label"),
        "display_state": snapshot.get("display_state"),
        "score_confidence": snapshot.get("score_confidence"),
        "comparability": snapshot.get("comparability"),
        "audit_method": "audit_text silent local fixture",
    }


def _points(rows: list[dict[str, Any]]) -> list[int]:
    values: list[int] = []
    for row in rows:
        try:
            values.append(int(row.get("points")))
        except (TypeError, ValueError):
            continue
    return values


def _points_by_id(rows: list[dict[str, Any]]) -> dict[str, int]:
    values: dict[str, int] = {}
    for row in rows:
        try:
            values[str(row.get("id"))] = int(row.get("points"))
        except (TypeError, ValueError):
            continue
    return values


def run_score_stress(cases_path: Path = CASES_PATH, output_dir: Path = OUTPUT_DIR) -> dict[str, Any]:
    install_fake_mcp_modules()
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    ensure_real_audit_report_package()

    from server import Repository, audit_text_payload  # pylint: disable=import-error,import-outside-toplevel

    data = json.loads(cases_path.read_text(encoding="utf-8"))
    repeat = data.get("repeat") if isinstance(data.get("repeat"), dict) else {}
    minimum_score_gap = int(data.get("minimum_score_gap") or 8)
    pairwise_expected_order = [item for item in data.get("pairwise_expected_order") or [] if isinstance(item, list) and len(item) == 2]
    cases = [item for item in data.get("cases", []) if isinstance(item, dict)]
    rows: list[dict[str, Any]] = []
    repeat_rows: list[dict[str, Any]] = []

    repo = Repository(DB_PATH)
    try:
        for index in range(max(1, int(repeat.get("runs") or 5))):
            result = audit_text_payload(
                repo,
                str(repeat.get("text") or ""),
                text_type=str(repeat.get("text_type") or "general"),
                human_loop_mode="silent",
                human_loop_state={"noninteractive_smoke_test": True},
                depth="standard",
            )
            repeat_rows.append(_snapshot_row(repeat, result, run_index=index + 1))
        for case in cases:
            result = audit_text_payload(
                repo,
                str(case.get("text") or ""),
                text_type=str(case.get("text_type") or "general"),
                human_loop_mode="silent",
                human_loop_state={"noninteractive_smoke_test": True},
                depth="standard",
            )
            rows.append(_snapshot_row(case, result))
    finally:
        repo.close()

    all_points = _points(rows)
    repeat_points = _points(repeat_rows)
    spread = max(all_points) - min(all_points) if all_points else 0
    repeat_stable = len(set(repeat_points)) <= 1
    ordered_rows = {str(row.get("expected_band")): row for row in rows}
    weak = ordered_rows.get("weak", {}).get("points")
    moderate = ordered_rows.get("moderate", {}).get("points")
    strong = ordered_rows.get("strong", {}).get("points")
    exemplary = ordered_rows.get("exemplary", {}).get("points")
    ordered = (
        isinstance(weak, int)
        and isinstance(moderate, int)
        and isinstance(strong, int)
        and weak <= moderate <= strong
    )
    if isinstance(exemplary, int):
        ordered = ordered and strong <= exemplary
    by_id = _points_by_id(rows)
    pairwise_failures = []
    minimum_gap_failures = []
    for lower_id, higher_id in pairwise_expected_order:
        lower_points = by_id.get(str(lower_id))
        higher_points = by_id.get(str(higher_id))
        if lower_points is None or higher_points is None:
            pairwise_failures.append({"lower_id": lower_id, "higher_id": higher_id, "reason": "missing_points", "lower_points": lower_points, "higher_points": higher_points})
            continue
        if lower_points >= higher_points:
            pairwise_failures.append({"lower_id": lower_id, "higher_id": higher_id, "reason": "ordering_failed", "lower_points": lower_points, "higher_points": higher_points})
        if higher_points - lower_points < minimum_score_gap:
            minimum_gap_failures.append({"lower_id": lower_id, "higher_id": higher_id, "minimum_score_gap": minimum_score_gap, "actual_gap": higher_points - lower_points})
    cis_monotonicity_pass = ordered and not pairwise_failures
    report = {
        "status": "measured" if repeat_stable and spread >= minimum_score_gap * 3 and cis_monotonicity_pass and not minimum_gap_failures else "needs_review",
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "case_count": len(rows),
        "repeat_runs": len(repeat_rows),
        "repeat_stable": repeat_stable,
        "score_spread": spread,
        "minimum_score_gap": minimum_score_gap,
        "ordered_weak_moderate_strong": ordered,
        "cis_monotonicity_pass": cis_monotonicity_pass,
        "pairwise_expected_order": pairwise_expected_order,
        "pairwise_failures": pairwise_failures,
        "minimum_gap_failures": minimum_gap_failures,
        "repeat_rows": repeat_rows,
        "rows": rows,
        "notes": [
            "This is a measurement harness, not a scoring retune.",
            "Use these distributions before changing CIS weights.",
            "Audit-method provenance is recorded so quick and advanced scores are not interpreted as equally deep.",
        ],
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    json_path = output_dir / f"cis-score-stress-{timestamp}.json"
    md_path = output_dir / f"cis-score-stress-{timestamp}.md"
    json_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "# Critical Compass CIS Score Stress",
        "",
        f"Status: {report['status']}",
        f"Repeat stable: {report['repeat_stable']}",
        f"Score spread: {report['score_spread']}",
        f"Minimum score gap: {report['minimum_score_gap']}",
        f"Ordered weak/moderate/strong: {report['ordered_weak_moderate_strong']}",
        f"Pairwise failures: {len(report['pairwise_failures'])}",
        f"Minimum-gap failures: {len(report['minimum_gap_failures'])}",
        "",
        "| Case | Expected | Points | Label | Confidence | Comparability |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            f"| {row['id']} | {row['expected_band']} | {row['points']} | {row['label']} | {row['score_confidence']} | {row['comparability']} |"
        )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report["json_path"] = str(json_path.resolve())
    report["markdown_path"] = str(md_path.resolve())
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CIS score stress measurement fixtures.")
    parser.add_argument("--cases", type=Path, default=CASES_PATH)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    print(json.dumps(run_score_stress(args.cases, args.output_dir), indent=2, sort_keys=True))
