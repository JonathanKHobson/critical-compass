#!/usr/bin/env python3
"""Safe Claude Desktop config helper for Critical Compass technical installs."""

from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any


UTF8_BOM = b"\xef\xbb\xbf"
DEFAULT_SERVER_NAME = "critical-compass"


def has_utf8_bom(path: Path) -> bool:
    if not path.exists():
        return False
    return path.read_bytes()[:3] == UTF8_BOM


def load_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig")
    if not text.strip():
        return {}
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("Claude config root must be a JSON object.")
    return data


def server_names(config: dict[str, Any]) -> list[str]:
    servers = config.get("mcpServers", {})
    if servers is None:
        return []
    if not isinstance(servers, dict):
        raise ValueError("Claude config mcpServers must be a JSON object when present.")
    return sorted(str(name) for name in servers.keys())


def write_config_no_bom(path: Path, config: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    if has_utf8_bom(path):
        raise RuntimeError(f"Refusing to leave BOM-prefixed config at {path}")


def backup_config(path: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup_path = path.with_name(f"{path.name}.backup-{stamp}.json")
    shutil.copy2(path, backup_path)
    return backup_path


def merge_server_entry(config_path: Path, server_name: str, entry: dict[str, Any]) -> dict[str, Any]:
    config = load_config(config_path)
    before = server_names(config)
    servers = config.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise ValueError("Claude config mcpServers must be a JSON object.")
    servers[server_name] = entry
    after = server_names(config)
    missing = sorted(set(before) - set(after))
    if missing:
        raise RuntimeError(f"Merge would drop existing MCP servers: {missing}")
    backup_path = backup_config(config_path)
    write_config_no_bom(config_path, config)
    return {
        "action": "merge",
        "server_name": server_name,
        "backup_path": str(backup_path) if backup_path else None,
        "before_servers": before,
        "after_servers": server_names(load_config(config_path)),
        "utf8_bom": has_utf8_bom(config_path),
    }


def remove_server_entry(config_path: Path, server_name: str) -> dict[str, Any]:
    config = load_config(config_path)
    before = server_names(config)
    servers = config.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise ValueError("Claude config mcpServers must be a JSON object.")
    servers.pop(server_name, None)
    expected_after = sorted(name for name in before if name != server_name)
    backup_path = backup_config(config_path)
    write_config_no_bom(config_path, config)
    after = server_names(load_config(config_path))
    if after != expected_after:
        raise RuntimeError(f"Remove changed unrelated MCP servers: before={before} after={after}")
    return {
        "action": "remove",
        "server_name": server_name,
        "backup_path": str(backup_path) if backup_path else None,
        "before_servers": before,
        "after_servers": after,
        "utf8_bom": has_utf8_bom(config_path),
    }


def restore_latest_backup(config_path: Path) -> dict[str, Any]:
    backups = sorted(config_path.parent.glob(f"{config_path.name}.backup-*.json"), key=lambda item: item.stat().st_mtime)
    if not backups:
        raise FileNotFoundError(f"No backups found next to {config_path}")
    latest = backups[-1]
    shutil.copy2(latest, config_path)
    return {
        "action": "restore-latest",
        "restored_from": str(latest),
        "after_servers": server_names(load_config(config_path)),
        "utf8_bom": has_utf8_bom(config_path),
    }


def health_check(config_path: Path) -> dict[str, Any]:
    exists = config_path.exists()
    payload: dict[str, Any] = {
        "action": "health",
        "config_path": str(config_path),
        "exists": exists,
        "utf8_bom": has_utf8_bom(config_path),
        "size_bytes": config_path.stat().st_size if exists else 0,
        "json_valid": False,
        "server_names": [],
    }
    try:
        config = load_config(config_path)
    except Exception as exc:  # pylint: disable=broad-exception-caught
        payload["error"] = str(exc)
        return payload
    payload["json_valid"] = True
    payload["server_names"] = server_names(config)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Safely inspect or update Claude Desktop MCP config for Critical Compass.")
    parser.add_argument("action", choices=["health", "merge", "remove", "restore-latest"])
    parser.add_argument("--config", required=True, type=Path, help="Path to claude_desktop_config.json")
    parser.add_argument("--server-name", default=DEFAULT_SERVER_NAME)
    parser.add_argument("--entry-json", type=Path, help="JSON file containing the MCP server entry for merge")
    args = parser.parse_args()

    if args.action == "health":
        result = health_check(args.config)
    elif args.action == "merge":
        if not args.entry_json:
            parser.error("--entry-json is required for merge")
        entry = json.loads(args.entry_json.read_text(encoding="utf-8"))
        if not isinstance(entry, dict):
            raise ValueError("--entry-json must contain a JSON object")
        result = merge_server_entry(args.config, args.server_name, entry)
    elif args.action == "remove":
        result = remove_server_entry(args.config, args.server_name)
    else:
        result = restore_latest_backup(args.config)

    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
