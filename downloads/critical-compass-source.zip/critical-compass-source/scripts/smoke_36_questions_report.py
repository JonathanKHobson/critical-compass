#!/usr/bin/env python3
"""Run the 36 Questions OCR -> audit -> advanced scaffold -> PDF report smoke test."""

from __future__ import annotations

import json
import os
import shutil
import sys
import types
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SOURCE_PDF_CANDIDATES = [
    Path(os.environ["CRITICAL_COMPASS_SMOKE_SOURCE_PDF"])
    if os.environ.get("CRITICAL_COMPASS_SMOKE_SOURCE_PDF")
    else None,
    Path("/Users/jonathanhobson/Downloads/36 Questions Experiment.pdf"),
    Path("/Volumes/KyleSSD/Downloads/Archive/2026/DownloadsApr19_2026/36 Questions Experiment.pdf"),
]
SOURCE_PDF = next((path for path in SOURCE_PDF_CANDIDATES if path and path.exists()), SOURCE_PDF_CANDIDATES[1])
OUTPUT_DIR = ROOT / "reports" / "smoke-36-questions"
SOURCE_DIR = OUTPUT_DIR / "source"
REPORT_PATH = OUTPUT_DIR / "36-questions-smoke-report.pdf"
SUMMARY_PATH = OUTPUT_DIR / "smoke-summary.json"
GOLDEN_DIR = OUTPUT_DIR / "golden-report-artifacts"
GOLDEN_MANIFEST_PATH = GOLDEN_DIR / "golden-report-artifacts.json"


def ensure_mcp_import_stub() -> None:
    """Allow direct script execution when FastMCP is not installed in test Python."""

    try:
        import mcp.server.fastmcp  # type: ignore  # noqa: F401
        import mcp.types  # type: ignore  # noqa: F401
        return
    except Exception:
        pass

    mcp = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    types_module = types.ModuleType("mcp.types")

    class FakeFastMCP:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        def tool(self, *_args: Any, **_kwargs: Any):
            def decorator(func):
                return func

            return decorator

    class FakeToolAnnotations:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    fastmcp_module.FastMCP = FakeFastMCP
    types_module.ToolAnnotations = FakeToolAnnotations
    sys.modules.update(
        {
            "mcp": mcp,
            "mcp.server": server_module,
            "mcp.server.fastmcp": fastmcp_module,
            "mcp.types": types_module,
        }
    )


def evidence_needed_for_assumption(text: str) -> str:
    text_lower = text.lower()
    if "representative" in text_lower or "cherry" in text_lower:
        return "Sampling notes, inclusion criteria, and a comparison of represented versus unrepresented participants."
    if "complete" in text_lower:
        return "The full study text, appendices, and missing methodological details."
    if "conclusion" in text_lower:
        return "Effect sizes, null results, and limitations that bound the conclusion."
    if "value" in text_lower:
        return "A short note naming which value judgment is being made and who authorizes it."
    return "A source note, comparison, or method detail that would test this assumption."


def report_biases(audit: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in audit.get("bias_map", [])[:5]:
        rows.append(
            {
                "name": item.get("bias_name") or item.get("name") or "Bias risk",
                "kb_id": item.get("bias_id") or item.get("kb_id") or "",
                "passage": item.get("claim_passage") or item.get("evidence") or "source passage",
                "why_it_matters": item.get("impact_on_reader") or item.get("why_it_qualifies") or "This affects how much scope the reader should trust.",
                "three_cs_lens": item.get("three_cs_lens") or "Critical",
            }
        )
    return rows


def report_assumptions(audit: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in audit.get("assumptions", [])[:5]:
        assumption = item.get("assumption") if isinstance(item, dict) else str(item)
        rows.append(
            {
                "assumption": assumption,
                "testable": item.get("status", "testable") if isinstance(item, dict) else "testable",
                "evidence_needed": evidence_needed_for_assumption(assumption),
            }
        )
    return rows


def report_frames(audit: dict[str, Any]) -> list[dict[str, Any]]:
    frames: list[dict[str, Any]] = []
    for item in audit.get("alternative_frames", [])[:3]:
        frames.append(
            {
                "name": item.get("name") or "Alternative frame",
                "kb_id": item.get("kb_id") or item.get("id") or "",
                "frame": item.get("frame") or item.get("description") or "Use this frame to test what the main reading leaves out.",
                "three_cs_lens": item.get("three_cs_lens") or "Critical",
            }
        )
    return frames


def report_argument_map(audit: dict[str, Any]) -> dict[str, Any]:
    argument_map = dict(audit.get("argument_map") or {})
    if not argument_map.get("missing_voices"):
        argument_map["missing_voices"] = [
            "Participants outside a college-student laboratory setting.",
            "People evaluating whether temporary closeness transfers to durable relationships.",
        ]
    if not argument_map.get("objections"):
        argument_map["objections"] = [
            "The procedure may create temporary felt closeness without establishing durable real-world intimacy.",
            "Null findings in later studies should limit how broadly the method is applied.",
        ]
    if not argument_map.get("evidence_gaps"):
        argument_map["evidence_gaps"] = [
            "Field replication evidence with diverse participants and longer follow-up.",
            "Evidence separating temporary closeness ratings from lasting relationship outcomes.",
        ]
    return argument_map


def compile_report_data(
    *,
    source_result: dict[str, Any],
    audit: dict[str, Any],
    advanced: dict[str, Any],
    synthesis: dict[str, Any],
) -> dict[str, Any]:
    quick = audit.get("quick_scan_card", {})
    cis = audit.get("critical_integrity_snapshot", {})
    agents = [
        {
            "name": "Research Methodologist",
            "reasoning_style": "replication-readiness review",
            "top_finding": "The paper reports a useful laboratory procedure, but broad application should stay bounded by the student-sample and self-report design.",
            "kb_id": "ct:methodology-checks:replication-readiness",
        },
        {
            "name": "Framing Reviewer",
            "reasoning_style": "scope and audience review",
            "top_finding": "The most important reader risk is treating temporary laboratory closeness as evidence for durable real-world relationship formation.",
            "kb_id": "ct:biases:methodology:overgeneralization",
        },
    ]
    dissent_ledger = [
        {
            "agent_name": "Research Methodologist",
            "top_finding": agents[0]["top_finding"],
            "strongest_disagreement": "The method is stronger as a research procedure than as a general relationship intervention.",
            "confidence": "high",
            "what_would_change_mind": "Field replications with diverse participants and longer follow-up would reduce this concern.",
            "provenance": {"stage": "synthesis", "source": "smoke_36_questions_report"},
        },
        {
            "agent_name": "Framing Reviewer",
            "top_finding": agents[1]["top_finding"],
            "strongest_disagreement": "The report should not let the popular '36 questions' framing outrun the original study limits.",
            "confidence": "medium",
            "what_would_change_mind": "A report that foregrounds temporary closeness, sample limits, and null follow-up findings would change the framing concern.",
            "provenance": {"stage": "synthesis", "source": "smoke_36_questions_report"},
        },
    ]
    return {
        "subject_text": source_result["text"],
        "source_result": source_result,
        "text_type": "research",
        "quick_scan_card": quick,
        "critical_integrity_snapshot": cis,
        "biases": report_biases(audit),
        "key_tension": "The paper offers a practical laboratory procedure for temporary closeness, but readers may overextend it into broad claims about durable real-world intimacy.",
        "recommended_next_step": "Use the procedure as a bounded research tool and foreground sample, setting, and follow-up limits before applying it elsewhere.",
        "assumptions": report_assumptions(audit),
        "alternative_frames": report_frames(audit),
        "probing_questions": audit.get("probing_questions", [])[:3],
        "follow_up_questions": audit.get("follow_up_questions", [])[:3],
        "next_steps": [
            "Name the student-sample and laboratory-setting limits before citing the procedure.",
            "Separate temporary felt closeness from claims about durable relationship formation.",
            "Check whether follow-up, field, or diverse-sample replications support the intended use.",
        ],
        "argument_map": report_argument_map(audit),
        "checkworthy_claims": audit.get("checkworthy_claims", {}),
        "advanced_audit": {
            "present": True,
            "agents": agents,
            "dissent_ledger": dissent_ledger,
            "verdict_paragraph": "The audit supports using the study as a carefully bounded method paper, not as proof that scripted disclosure reliably creates durable closeness outside the experimental frame.",
        },
        "reasoning_traps": audit.get("reasoning_traps", [])
        or [
            {
                "label": "Scope-leap risk",
                "risk": "Risk of treating a laboratory closeness procedure as a broad real-world relationship claim.",
                "next_check": "Ask what setting, sample, and follow-up limits belong beside the claim.",
                "severity": "medium",
                "signals": ["laboratory procedure", "real-world intimacy"],
            }
        ],
        "advanced_scaffold_status": advanced.get("status"),
        "synthesis_scaffold_status": synthesis.get("status"),
    }


def write_golden_artifacts(report: dict[str, Any]) -> dict[str, Any]:
    """Copy stable page images for the new report artifact sections."""

    try:
        import fitz
    except ModuleNotFoundError as exc:  # pragma: no cover - environment issue
        raise AssertionError("PyMuPDF is required to index golden report artifacts.") from exc

    section_queries = {
        "argument_map": "Argument Map",
        "evidence_needed_next": "Evidence Needed Next",
        "dissent_ledger": "Where the Analysts Disagreed",
        "reasoning_traps": "Reasoning Trap Checks",
    }
    report_path = Path(report["report_path"])
    page_image_paths = [Path(path) for path in report.get("page_image_paths", [])]
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    for stale in GOLDEN_DIR.glob("*.png"):
        stale.unlink(missing_ok=True)
    for sidecar in GOLDEN_DIR.glob("._*"):
        sidecar.unlink(missing_ok=True)

    artifacts: dict[str, Any] = {}
    with fitz.open(str(report_path)) as doc:
        for slug, query in section_queries.items():
            matched_page: int | None = None
            for index, page in enumerate(doc, start=1):
                lines = [line.strip().lower() for line in page.get_text("text").splitlines()]
                if query.lower() in lines:
                    matched_page = index
                    break
            if matched_page is None:
                raise AssertionError(f"Report section not found for golden artifact: {query}")
            source_image = page_image_paths[matched_page - 1]
            target_image = GOLDEN_DIR / f"{slug}-page-{matched_page}.png"
            shutil.copyfile(source_image, target_image)
            artifacts[slug] = {
                "section": query,
                "page": matched_page,
                "image_path": str(target_image.resolve()),
            }

    manifest = {
        "report_path": report["report_path"],
        "report_id": report.get("report_id"),
        "payload_hash": report.get("payload_hash"),
        "sections": artifacts,
    }
    GOLDEN_MANIFEST_PATH.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    for sidecar in GOLDEN_DIR.glob("._*"):
        sidecar.unlink(missing_ok=True)
    return manifest


def validate_golden_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    required = {"argument_map", "evidence_needed_next", "dissent_ledger", "reasoning_traps"}
    sections = manifest.get("sections") if isinstance(manifest.get("sections"), dict) else {}
    missing = sorted(required - set(sections))
    issues: list[dict[str, Any]] = []
    if missing:
        issues.append({"check": "sections", "severity": "blocking", "missing": missing})
    for slug, item in sections.items():
        image_path = Path(str(item.get("image_path", "")))
        if not image_path.exists():
            issues.append({"check": "image_exists", "severity": "blocking", "section": slug, "image_path": str(image_path)})
        if image_path.suffix.lower() != ".png":
            issues.append({"check": "image_format", "severity": "blocking", "section": slug, "image_path": str(image_path)})
        if int(item.get("page") or 0) <= 0:
            issues.append({"check": "page_number", "severity": "blocking", "section": slug, "page": item.get("page")})
        if not str(item.get("section", "")).strip():
            issues.append({"check": "section_label", "severity": "blocking", "section": slug})
    return {
        "passed": not issues,
        "required_sections": sorted(required),
        "issues": issues,
    }


def main() -> None:
    ensure_mcp_import_stub()
    sys.path.insert(0, str(ROOT))

    from audit_report import generate_audit_report, prepare_audit_source
    from server import DEFAULT_DB_PATH, Repository, advanced_audit_payload, audit_text_payload, synthesize_audit_verdict_payload

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    source_result = prepare_audit_source(str(SOURCE_PDF), ocr_mode="auto", output_dir=str(SOURCE_DIR), include_page_images=True)
    assert source_result["status"] == "ready", source_result
    assert source_result["ocr_used"] is True, source_result

    repo = Repository(DEFAULT_DB_PATH)
    text = source_result["text"]
    audit = audit_text_payload(
        repo,
        text,
        text_type="research",
        snapshot_mode="organizer",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    assert audit["status"] == "audit_ready", audit.get("status")

    advanced = advanced_audit_payload(
        repo,
        text,
        "agent",
        text_type="research",
        depth="standard",
        scaffold_detail="handoff",
        retrieval_profile="auto",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    if advanced.get("status") == "agentic_plan_review_required":
        advanced = advanced_audit_payload(
            repo,
            text,
            "agent",
            text_type="research",
            depth="standard",
            scaffold_detail="handoff",
            retrieval_profile="auto",
            human_loop_mode="silent",
            human_loop_state={"noninteractive_smoke_test": True},
            agentic_state={"plan_approved": True, "approved_plan_hash": advanced["agentic_plan_hash"]},
        )
    assert advanced["tool"] == "advanced_audit", advanced
    assert advanced["status"] in {"agent_scaffold_ready", "audit_ready", "scaffold_ready"}, advanced.get("status")

    synthesis = synthesize_audit_verdict_payload(
        text,
        [{"agent_id": "agent_1", "name": "Research Methodologist"}],
        [{"agent_id": "agent_1", "agent_name": "Research Methodologist", "primary_finding": "Scope claims need tighter bounds."}],
        [{"tension_id": "scope", "summary": "Lab method versus real-world use."}],
        {"debate_exchange": []},
        text_type="research",
        synthesis_audience="reader",
        biases_found=[item.get("bias_name") for item in audit.get("bias_map", [])[:3] if item.get("bias_name")],
        depth="standard",
        snapshot_mode="organizer",
        scaffold_detail="handoff",
        human_loop_mode="silent",
        human_loop_state={"noninteractive_smoke_test": True},
    )
    assert synthesis["tool"] == "synthesize_audit_verdict", synthesis

    report_data = compile_report_data(source_result=source_result, audit=audit, advanced=advanced, synthesis=synthesis)
    report = generate_audit_report(
        report_data,
        report_audience="academic",
        report_depth="full",
        report_mode="reader",
        include_raw_text=False,
        report_title="36 Questions Experiment Smoke Report",
        output_path=str(REPORT_PATH),
        allow_placeholders=False,
        return_markdown=True,
    )
    assert report["qa_status"] in {"passed", "passed_with_cosmetic_issues"}, report
    assert report["report_path"], report
    assert report["page_count"] >= 3, report
    assert report["preview_image_path"], report
    assert report.get("viewer_path"), report
    golden_artifacts = write_golden_artifacts(report)
    golden_validation = validate_golden_manifest(golden_artifacts)
    assert golden_validation["passed"], golden_validation

    summary = {
        "source_pdf": str(SOURCE_PDF),
        "source_status": source_result["status"],
        "source_text_path": source_result["text_path"],
        "ocr_used": source_result["ocr_used"],
        "source_word_count": source_result["text_word_count"],
        "advanced_status": advanced.get("status"),
        "synthesis_status": synthesis.get("status"),
        "report_status": report["qa_status"],
        "report_path": report["report_path"],
        "markdown_path": report.get("markdown_path"),
        "manifest_path": report.get("manifest_path"),
        "viewer_path": report.get("viewer_path"),
        "preview_image_path": report["preview_image_path"],
        "page_image_paths": report["page_image_paths"],
        "page_count": report["page_count"],
        "qa_issues": report.get("qa_issues", []),
        "golden_manifest_path": str(GOLDEN_MANIFEST_PATH.resolve()),
        "golden_artifacts": golden_artifacts["sections"],
        "golden_validation": golden_validation,
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
