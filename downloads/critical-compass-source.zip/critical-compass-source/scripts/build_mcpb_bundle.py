#!/usr/bin/env python3
"""Stage and optionally pack the Critical Compass MCPB bundle."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tool_tiers import apply_tool_tiers_to_manifest

TEMPLATE_DIR = ROOT / "packaging" / "mcpb" / "critical-compass"
DEFAULT_OUTPUT_DIR = ROOT / "dist" / "mcpb"

RUNTIME_PACKAGE_DIRS = {
    "audit_report": {"fixtures"},
    "factcheck": set(),
}
RUNTIME_DIRS = [
    "support",
    "references",
]
RUNTIME_FILES = [
    "server.py",
    "tool_tiers.py",
    "README.md",
    "LICENSE",
    "LICENSE-DOCS-CC-BY-SA-4.0.md",
    "NOTICE",
    "BRAND-AND-ATTRIBUTION.md",
    "THIRD_PARTY_NOTICES.md",
    "FACTCHECK_STATE_OF_THE_WORLD.md",
    "config/factcheck.env.example",
    "docs/public/why-critical-compass.md",
    "docs/specs/factcheck_lookup_contract.md",
]

DEV_ONLY_RUNTIME_FILES = [
    "support/registry/mcp_capabilities.json",
    "support/registry/mcp_capability_registry.schema.json",
    "support/registry/mcp_study_lessons.json",
    "support/registry/mcp_study_lessons.schema.json",
    "support/registry/comparable_tools.json",
    "support/registry/comparable_tools.md",
    "support/registry/comparable_tools_evaluations.json",
]


def _skip_name(name: str) -> bool:
    return (
        name in {"__pycache__", ".pytest_cache", ".mypy_cache", ".DS_Store"}
        or name.startswith("._")
        or name.startswith(".__")
        or name.endswith(".pyc")
        or name.endswith(".pyo")
    )


def _remove_tree(path: Path) -> None:
    def onerror(_func, _path, exc_info):  # type: ignore[no-untyped-def]
        if exc_info and issubclass(exc_info[0], FileNotFoundError):
            return
        raise exc_info[1]

    shutil.rmtree(path, onerror=onerror)


def _copy_file(relative_path: str, stage_dir: Path) -> None:
    source = ROOT / relative_path
    if not source.exists():
        return
    target = stage_dir / relative_path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _ignore_factory(extra_excluded_dirs: set[str] | None = None):
    extra_excluded_dirs = extra_excluded_dirs or set()

    def ignore(_dir: str, names: list[str]) -> set[str]:
        ignored: set[str] = set()
        for name in names:
            if _skip_name(name) or name in extra_excluded_dirs:
                ignored.add(name)
        return ignored

    return ignore


def _copy_tree(relative_path: str, stage_dir: Path, *, excluded_dirs: set[str] | None = None) -> None:
    source = ROOT / relative_path
    if not source.exists():
        return
    target = stage_dir / relative_path
    if target.exists():
        _remove_tree(target)
    shutil.copytree(source, target, ignore=_ignore_factory(excluded_dirs))


def _copy_template_files(stage_dir: Path) -> dict:
    for source in TEMPLATE_DIR.iterdir():
        if _skip_name(source.name):
            continue
        target = stage_dir / source.name
        if source.is_dir():
            if target.exists():
                _remove_tree(target)
            shutil.copytree(source, target, ignore=_ignore_factory())
        else:
            shutil.copy2(source, target)
    manifest_path = stage_dir / "manifest.json"
    manifest = apply_tool_tiers_to_manifest(json.loads(manifest_path.read_text(encoding="utf-8")))
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def _copy_database(stage_dir: Path) -> None:
    db_source = ROOT / "db" / "critical-compass.sqlite"
    if not db_source.exists():
        raise FileNotFoundError(f"Missing canonical database: {db_source}")
    db_target = stage_dir / "db" / "critical-compass.sqlite"
    db_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(db_source, db_target)


def _remove_sidecars(stage_dir: Path) -> None:
    for path in sorted(stage_dir.rglob("*"), reverse=True):
        if path.name.startswith("._") or path.name.startswith(".__"):
            if not path.exists():
                continue
            try:
                if path.is_dir():
                    _remove_tree(path)
                else:
                    path.unlink()
            except FileNotFoundError:
                continue


def _remove_dev_only_runtime_files(stage_dir: Path) -> None:
    for relative_path in DEV_ONLY_RUNTIME_FILES:
        target = stage_dir / relative_path
        if target.exists():
            target.unlink()


def _assert_clean_stage(stage_dir: Path) -> None:
    forbidden_parts = {
        "tests",
        "__pycache__",
        ".pytest_cache",
        "incoming",
        "normalized",
        "indexes",
        "evaluations",
        "reports",
        "test report data",
    }
    errors: list[str] = []
    for path in stage_dir.rglob("*"):
        relative = path.relative_to(stage_dir)
        if any(part in forbidden_parts for part in relative.parts):
            errors.append(f"forbidden path included: {relative}")
        if path.name.startswith("._") or path.name.startswith(".__"):
            errors.append(f"AppleDouble sidecar included: {relative}")
        if path.name == "critical-compass-state.sqlite":
            errors.append(f"writable state DB included: {relative}")
        if str(relative) in DEV_ONLY_RUNTIME_FILES:
            errors.append(f"dev-only planning registry included: {relative}")
    if not (stage_dir / "manifest.json").exists():
        errors.append("manifest.json missing")
    if not (stage_dir / "pyproject.toml").exists():
        errors.append("pyproject.toml missing")
    if not (stage_dir / "db" / "critical-compass.sqlite").exists():
        errors.append("canonical read-only database missing")
    if errors:
        raise RuntimeError("\n".join(errors))


def stage_bundle(output_dir: Path) -> tuple[Path, dict]:
    stage_dir = output_dir / "critical-compass"
    if stage_dir.exists():
        _remove_tree(stage_dir)
    stage_dir.mkdir(parents=True, exist_ok=True)

    manifest = _copy_template_files(stage_dir)
    _copy_database(stage_dir)

    for package_dir, excluded_dirs in RUNTIME_PACKAGE_DIRS.items():
        _copy_tree(package_dir, stage_dir, excluded_dirs=excluded_dirs)
    for runtime_dir in RUNTIME_DIRS:
        _copy_tree(runtime_dir, stage_dir)
    for runtime_file in RUNTIME_FILES:
        _copy_file(runtime_file, stage_dir)

    _remove_dev_only_runtime_files(stage_dir)
    _remove_sidecars(stage_dir)
    _assert_clean_stage(stage_dir)
    return stage_dir, manifest


def pack_bundle(stage_dir: Path, output_file: Path) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    command = ["npx", "-y", "@anthropic-ai/mcpb", "pack", str(stage_dir), str(output_file)]
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage and optionally pack the Critical Compass MCPB bundle.")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help="Directory that will receive the staged bundle.")
    parser.add_argument("--pack", action="store_true", help="Run the official @anthropic-ai/mcpb pack command after staging.")
    parser.add_argument("--artifact", default="", help="Optional output .mcpb path when --pack is used.")
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser().resolve()
    try:
        stage_dir, manifest = stage_bundle(output_dir)
        artifact = Path(args.artifact).expanduser().resolve() if args.artifact else output_dir / f"critical-compass-{manifest['version']}.mcpb"
        if args.pack:
            pack_bundle(stage_dir, artifact)
            print(f"packed_mcpb={artifact}")
        print(f"staged_bundle={stage_dir}")
        print(f"manifest_version={manifest.get('manifest_version')}")
        print(f"package_version={manifest.get('version')}")
        return 0
    except Exception as exc:  # pylint: disable=broad-exception-caught
        print(f"build_mcpb_bundle failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
