from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


CONTRACT_SCHEMA_VERSION = "critical-compass.contracts.v1"

Confidence = Literal["low", "medium", "high"]
Severity = Literal["info", "warning", "error"]
MemoryLayer = Literal["semantic", "episodic", "procedural", "reflective"]


@dataclass(frozen=True)
class Finding:
    finding_id: str
    label: str
    category: str
    passage: str = ""
    rationale: str = ""
    match_confidence: Confidence = "medium"
    source_confidence: Confidence = "medium"
    evidence_refs: list[str] = field(default_factory=list)
    expected_non_finding: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ScoreCard:
    label: str | None
    points: int | None
    max_points: int = 100
    display_state: str = "scored"
    score_confidence: Confidence = "medium"
    dimensions: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LensCard:
    lens_id: str
    name: str
    short: str
    standard: str = ""
    full: str = ""
    use_when: list[str] = field(default_factory=list)
    do_not_use_when: list[str] = field(default_factory=list)
    misuse_warning: str = ""
    related_lenses: list[str] = field(default_factory=list)
    token_budget: dict[str, int] = field(default_factory=lambda: {"short": 80, "standard": 220, "full": 700})

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RetrievalBundle:
    mode: str
    max_lens_cards: int
    max_findings: int
    max_scaffold_chars: int
    selected_lens_refs: list[dict[str, Any]] = field(default_factory=list)
    retrieval_profile: str = "general"
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    severity: Severity
    message: str
    path: str = ""
    fix: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class OutputPackage:
    tool: str
    payload: dict[str, Any]
    retrieval_budget: dict[str, Any]
    selected_lens_refs: list[dict[str, Any]]
    postflight_validation: dict[str, Any]
    schema_version: str = CONTRACT_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MemoryPatchProposal:
    proposal_id: str
    target_path: str
    proposed_change: str
    source_reference: str
    rationale: str
    memory_layer: MemoryLayer = "reflective"
    confidence: Confidence = "medium"
    sensitivity: str = "standard"
    status: str = "proposed"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EvalTrace:
    case_id: str
    mode: str
    expected_findings: list[str]
    expected_non_findings: list[str]
    observed_findings: list[str]
    cis_points: int | None = None
    cis_band: str | None = None
    passed: bool = False
    failures: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


RETRIEVAL_BUDGETS: dict[str, dict[str, Any]] = {
    "quick_scan": {
        "mode": "quick_scan",
        "max_lens_cards": 3,
        "max_findings": 2,
        "max_scaffold_chars": 1200,
        "carry_forward_policy": "summary_only",
        "notes": ["Tiny lens bundle; no deep scaffolds."],
    },
    "audit_text": {
        "mode": "audit_text",
        "max_lens_cards": 8,
        "max_findings": 5,
        "max_scaffold_chars": 4500,
        "carry_forward_policy": "compact_findings",
        "notes": ["Moderate bundle; only relevant bias, fallacy, methodology, and lens candidates."],
    },
    "advanced_audit": {
        "mode": "advanced_audit",
        "max_lens_cards": 14,
        "max_findings": 8,
        "max_scaffold_chars": 9000,
        "carry_forward_policy": "compact_artifacts_between_phases",
        "notes": ["Larger staged bundle; carry compact artifacts instead of full transcripts."],
    },
    "research_methodology": {
        "mode": "research_methodology",
        "max_lens_cards": 10,
        "max_findings": 7,
        "max_scaffold_chars": 6500,
        "carry_forward_policy": "methodology_first",
        "notes": ["Methodology-first bundle; preserve research-profile behavior."],
    },
    "search_knowledge_base": {
        "mode": "search_knowledge_base",
        "max_lens_cards": 10,
        "max_findings": 10,
        "max_scaffold_chars": 4000,
        "carry_forward_policy": "result_refs_only",
        "notes": ["Manual exploration bundle; return compact refs, not always-loaded scaffolds."],
    },
}
