from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REGISTRY_PATH = ROOT / "support" / "registry" / "mcp_capabilities.json"
DEFAULT_STUDY_LESSONS_PATH = ROOT / "support" / "registry" / "mcp_study_lessons.json"

INTEGRATION_MODES = {
    "merged_internal",
    "wrapped_internal",
    "orchestrated_external",
    "prompt_scaffold_only",
    "rejected",
}

CURRENT_STATUSES = {
    "proposed",
    "reviewed",
    "approved",
    "experimental",
    "implemented",
    "deferred",
    "rejected",
}

REQUIRED_CAPABILITY_FIELDS = {
    "mcp_id",
    "name",
    "source_url",
    "summary",
    "primary_domain",
    "capabilities",
    "integration_mode",
    "strategic_value",
    "architecture_fit",
    "licensing_notes",
    "trust_risk",
    "maintenance_burden",
    "epistemic_fit",
    "plurality_fit",
    "fallback_mode",
    "current_status",
    "owner",
    "notes",
}

LESSON_TYPES = {
    "repo_structure",
    "tool_description",
    "system_prompt",
    "scaffold_resource",
    "schema_contract",
    "eval_fixture",
    "security_guardrail",
    "release_process",
    "negative_pattern",
}

ADAPTATION_MODES = {
    "adopt_pattern",
    "adapt_language",
    "document_only",
    "reject",
}

COPY_POLICIES = {
    "no_code_copy",
    "summarize_only",
    "original_rewrite_required",
}

LESSON_STATUSES = {
    "candidate",
    "accepted",
    "deferred",
    "rejected",
}

REQUIRED_STUDY_LESSON_FIELDS = {
    "lesson_id",
    "source_mcp_id",
    "source_repo_path",
    "source_files",
    "lesson_type",
    "pattern_summary",
    "critical_compass_application",
    "adaptation_mode",
    "copy_policy",
    "license_caution",
    "runtime_dependency",
    "implementation_target",
    "status",
    "notes",
}

INTERNAL_MODES = {"merged_internal", "wrapped_internal"}
EXTERNAL_READY_STATUSES = {"approved", "experimental", "implemented"}


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _norm(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().replace("_", " ").replace("-", " ").split())


def load_mcp_capability_registry(path: str | Path | None = None) -> dict[str, Any]:
    registry_path = Path(path) if path else DEFAULT_REGISTRY_PATH
    try:
        payload = json.loads(registry_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        payload = {
            "schema_version": "v1",
            "resource_id": "critical_compass.mcp_capabilities.v1",
            "capabilities": [],
        }
    if not isinstance(payload, dict):
        payload = {
            "schema_version": "v1",
            "resource_id": "critical_compass.mcp_capabilities.v1",
            "capabilities": [],
        }
    payload.setdefault("path", str(registry_path))
    return payload


def load_mcp_study_lessons(path: str | Path | None = None) -> dict[str, Any]:
    lessons_path = Path(path) if path else DEFAULT_STUDY_LESSONS_PATH
    try:
        payload = json.loads(lessons_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        payload = {
            "schema_version": "v1",
            "resource_id": "critical_compass.mcp_study_lessons.v1",
            "lessons": [],
        }
    if not isinstance(payload, dict):
        payload = {
            "schema_version": "v1",
            "resource_id": "critical_compass.mcp_study_lessons.v1",
            "lessons": [],
        }
    payload.setdefault("path", str(lessons_path))
    return payload


def validate_mcp_capability_registry(registry: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(registry, dict):
        return {"valid": False, "errors": ["registry must be an object"], "warnings": [], "record_count": 0}
    capabilities = registry.get("capabilities")
    if not isinstance(capabilities, list):
        errors.append("capabilities must be a list")
        capabilities = []
    seen: set[str] = set()
    for index, capability in enumerate(capabilities):
        if not isinstance(capability, dict):
            errors.append(f"capabilities[{index}] must be an object")
            continue
        missing = sorted(field for field in REQUIRED_CAPABILITY_FIELDS if field not in capability)
        if missing:
            errors.append(f"{capability.get('mcp_id', f'capabilities[{index}]')} missing required fields: {', '.join(missing)}")
        mcp_id = str(capability.get("mcp_id") or "").strip()
        if not mcp_id:
            errors.append(f"capabilities[{index}] missing non-empty mcp_id")
        elif mcp_id in seen:
            errors.append(f"duplicate mcp_id: {mcp_id}")
        seen.add(mcp_id)
        mode = str(capability.get("integration_mode") or "")
        if mode not in INTEGRATION_MODES:
            errors.append(f"{mcp_id or index} has unsupported integration_mode: {mode}")
        status = str(capability.get("current_status") or "")
        if status not in CURRENT_STATUSES:
            errors.append(f"{mcp_id or index} has unsupported current_status: {status}")
        if not isinstance(capability.get("capabilities"), list) or not capability.get("capabilities"):
            errors.append(f"{mcp_id or index} must list at least one capability")
        if mode == "orchestrated_external" and not capability.get("fallback_mode"):
            errors.append(f"{mcp_id or index} must define fallback_mode for external orchestration")
        if mode == "rejected" and status != "rejected":
            warnings.append(f"{mcp_id or index} is rejected but current_status is {status}")
    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "record_count": len(capabilities),
    }


def _license_requires_summary_only(license_caution: Any) -> bool:
    license_text = str(license_caution or "").lower()
    return any(term in license_text for term in ("agpl", "unknown", "copyright", "legal review", "no direct code"))


def validate_mcp_study_lessons(registry: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(registry, dict):
        return {"valid": False, "errors": ["study lessons registry must be an object"], "warnings": [], "record_count": 0}
    lessons = registry.get("lessons")
    if not isinstance(lessons, list):
        errors.append("lessons must be a list")
        lessons = []
    seen: set[str] = set()
    for index, lesson in enumerate(lessons):
        if not isinstance(lesson, dict):
            errors.append(f"lessons[{index}] must be an object")
            continue
        missing = sorted(field for field in REQUIRED_STUDY_LESSON_FIELDS if field not in lesson)
        if missing:
            errors.append(f"{lesson.get('lesson_id', f'lessons[{index}]')} missing required fields: {', '.join(missing)}")
        lesson_id = str(lesson.get("lesson_id") or "").strip()
        if not lesson_id:
            errors.append(f"lessons[{index}] missing non-empty lesson_id")
        elif lesson_id in seen:
            errors.append(f"duplicate lesson_id: {lesson_id}")
        seen.add(lesson_id)
        lesson_type = str(lesson.get("lesson_type") or "")
        if lesson_type not in LESSON_TYPES:
            errors.append(f"{lesson_id or index} has unsupported lesson_type: {lesson_type}")
        adaptation_mode = str(lesson.get("adaptation_mode") or "")
        if adaptation_mode not in ADAPTATION_MODES:
            errors.append(f"{lesson_id or index} has unsupported adaptation_mode: {adaptation_mode}")
        copy_policy = str(lesson.get("copy_policy") or "")
        if copy_policy not in COPY_POLICIES:
            errors.append(f"{lesson_id or index} has unsupported copy_policy: {copy_policy}")
        status = str(lesson.get("status") or "")
        if status not in LESSON_STATUSES:
            errors.append(f"{lesson_id or index} has unsupported status: {status}")
        if lesson.get("runtime_dependency") is not False:
            errors.append(f"{lesson_id or index} must set runtime_dependency=false")
        if not isinstance(lesson.get("source_files"), list) or not lesson.get("source_files"):
            errors.append(f"{lesson_id or index} must list at least one source_file")
        if not isinstance(lesson.get("implementation_target"), list) or not lesson.get("implementation_target"):
            errors.append(f"{lesson_id or index} must list at least one implementation_target")
        if _license_requires_summary_only(lesson.get("license_caution")) and copy_policy not in {"summarize_only", "original_rewrite_required"}:
            errors.append(f"{lesson_id or index} has license caution and must use summarize_only or original_rewrite_required")
        if adaptation_mode == "reject" and str(lesson.get("status") or "") == "rejected":
            warnings.append(f"{lesson_id or index} is fully rejected; keep it out of route planning")
    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "record_count": len(lessons),
    }


def summarize_mcp_capability_registry(registry: dict[str, Any]) -> dict[str, Any]:
    capabilities = [item for item in _as_list(registry.get("capabilities")) if isinstance(item, dict)]
    modes = Counter(str(item.get("integration_mode") or "unclassified") for item in capabilities)
    statuses = Counter(str(item.get("current_status") or "unknown") for item in capabilities)
    source_types = Counter(str(item.get("source_type") or "unspecified") for item in capabilities)
    return {
        "resource_id": registry.get("resource_id") or "critical_compass.mcp_capabilities.v1",
        "schema_version": registry.get("schema_version") or "v1",
        "path": registry.get("path") or str(DEFAULT_REGISTRY_PATH),
        "record_count": len(capabilities),
        "integration_mode_counts": dict(sorted(modes.items())),
        "status_counts": dict(sorted(statuses.items())),
        "source_type_counts": dict(sorted(source_types.items())),
        "guardrails": _as_list(registry.get("guardrails")),
        "study_library_reference": registry.get("study_library_reference"),
    }


def summarize_mcp_study_lessons(registry: dict[str, Any]) -> dict[str, Any]:
    lessons = [item for item in _as_list(registry.get("lessons")) if isinstance(item, dict)]
    lesson_types = Counter(str(item.get("lesson_type") or "unclassified") for item in lessons)
    modes = Counter(str(item.get("adaptation_mode") or "unclassified") for item in lessons)
    copy_policies = Counter(str(item.get("copy_policy") or "unspecified") for item in lessons)
    statuses = Counter(str(item.get("status") or "unknown") for item in lessons)
    sources = Counter(str(item.get("source_mcp_id") or "unknown") for item in lessons)
    accepted_targets: Counter[str] = Counter()
    for lesson in lessons:
        if lesson.get("status") == "accepted":
            accepted_targets.update(str(item) for item in _as_list(lesson.get("implementation_target")))
    return {
        "resource_id": registry.get("resource_id") or "critical_compass.mcp_study_lessons.v1",
        "schema_version": registry.get("schema_version") or "v1",
        "path": registry.get("path") or str(DEFAULT_STUDY_LESSONS_PATH),
        "record_count": len(lessons),
        "lesson_type_counts": dict(sorted(lesson_types.items())),
        "adaptation_mode_counts": dict(sorted(modes.items())),
        "copy_policy_counts": dict(sorted(copy_policies.items())),
        "status_counts": dict(sorted(statuses.items())),
        "source_mcp_counts": dict(sorted(sources.items())),
        "accepted_implementation_targets": dict(sorted(accepted_targets.items())),
        "guardrails": _as_list(registry.get("guardrails")),
        "study_library_reference": registry.get("study_library_reference"),
        "rule": "Study-library lessons are original Critical Compass summaries. They are not runtime dependencies, install instructions, or permission to call external MCPs.",
    }


def _record_matches(record: dict[str, Any], requested: set[str]) -> bool:
    haystack = {
        _norm(record.get("mcp_id")),
        _norm(record.get("name")),
        _norm(record.get("primary_domain")),
    }
    haystack.update(_norm(item) for item in _as_list(record.get("capabilities")))
    return bool(requested & haystack)


def _route_for_record(record: dict[str, Any], *, allow_external_mcp: bool, sensitivity: str) -> dict[str, Any]:
    mode = str(record.get("integration_mode") or "")
    status = str(record.get("current_status") or "")
    mcp_id = str(record.get("mcp_id") or "")
    fallback = str(record.get("fallback_mode") or "prompt_scaffold_only")
    sensitive = _norm(sensitivity) in {"sensitive", "high", "private"}

    if mode == "rejected" or status == "rejected":
        selected_path = "not_available"
        decision = "rejected"
        provenance = "rejected_candidate"
        reason = "The registry marks this MCP as rejected for Critical Compass use."
    elif mode in INTERNAL_MODES and status in {"implemented", "approved", "reviewed", "experimental"}:
        selected_path = "internal"
        decision = "use_internal"
        provenance = "internal Critical Compass module"
        reason = "A native or wrapped Critical Compass capability is preferred over external orchestration."
    elif mode == "orchestrated_external" and allow_external_mcp and status in EXTERNAL_READY_STATUSES and not sensitive:
        selected_path = "external_mcp"
        decision = "orchestrate_external"
        provenance = "external MCP orchestration"
        reason = "External orchestration is explicitly allowed and the registry permits this candidate."
    elif mode == "orchestrated_external":
        selected_path = fallback
        decision = "fallback"
        provenance = "prompt scaffold only" if fallback == "prompt_scaffold_only" else "fallback capability"
        reason = "External orchestration is not allowed, not ready, or not appropriate for the sensitivity level."
    elif mode == "prompt_scaffold_only":
        selected_path = "prompt_scaffold_only"
        decision = "use_scaffold"
        provenance = "prompt scaffold only"
        reason = "The useful value is a pattern or workflow contract, not direct integration."
    else:
        selected_path = fallback or "prompt_scaffold_only"
        decision = "fallback"
        provenance = "fallback capability"
        reason = "No direct integration path is currently selected."

    return {
        "mcp_id": mcp_id,
        "name": record.get("name"),
        "integration_mode": mode,
        "current_status": status,
        "selected_path": selected_path,
        "decision": decision,
        "provenance_label": provenance,
        "requires_user_consent": selected_path == "external_mcp",
        "fallback_mode": fallback,
        "rationale": reason,
    }


def plan_capability_route(
    registry: dict[str, Any] | None = None,
    *,
    capability_ids: list[str] | None = None,
    required_capabilities: list[str] | None = None,
    task_domain: str | None = None,
    allow_external_mcp: bool = False,
    sensitivity: str = "normal",
) -> dict[str, Any]:
    registry_payload = registry or load_mcp_capability_registry()
    capabilities = [item for item in _as_list(registry_payload.get("capabilities")) if isinstance(item, dict)]
    requested = {_norm(item) for item in _as_list(capability_ids) + _as_list(required_capabilities) + _as_list(task_domain) if _norm(item)}
    if not requested:
        requested = {"critical compass orchestration"}

    matches = [record for record in capabilities if _record_matches(record, requested)]
    routes = [_route_for_record(record, allow_external_mcp=allow_external_mcp, sensitivity=sensitivity) for record in matches]
    return {
        "status": "route_ready" if routes else "no_capability_match",
        "allow_external_mcp": allow_external_mcp,
        "sensitivity": sensitivity,
        "requested": sorted(requested),
        "routes": routes,
        "provenance_rule": "Always label whether output came from an internal Critical Compass module, external MCP orchestration, prompt scaffold only, host browsing, or an experimental provider path.",
        "unavailable_behavior": "Return a structured not-available route and the next-best scaffold; do not silently call unreviewed MCPs.",
    }
