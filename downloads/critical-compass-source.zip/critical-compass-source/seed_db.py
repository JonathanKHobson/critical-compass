#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parent
DEFAULT_DB_PATH = ROOT / "db" / "critical-compass.sqlite"
DEFAULT_SCHEMA_PATH = ROOT / "schema.sql"
NORMALIZED_CATALOG_PATH = ROOT / "indexes" / "normalized-catalog.json"
NORMALIZED_ROOT = ROOT / "normalized"
LIBRARY_RECORDS_PATH = ROOT / "support" / "library" / "library.records.json"
LIBRARY_ADDITIONS_PATH = ROOT / "support" / "library" / "critical-compass.additions.json"
TEMPLATES_DATA_PATH = ROOT / "incoming" / "raw" / "source-glossary-js" / "templates.data.js"


FALLACY_SEEDS = [
    {
        "slug": "false-dilemma",
        "title": "False dilemma",
        "subcategory": "informal",
        "definition": "Presenting two options as if they are the only possible choices.",
        "example": "Either we do this now or everything will fail.",
        "impact": "Narrows reasoning and hides better alternatives.",
        "mitigation": "Search for missing options, hybrids, and tradeoffs.",
        "aliases": ["false dilemma", "false dichotomy", "either-or fallacy"],
    },
    {
        "slug": "causal-overreach",
        "title": "Causal overreach",
        "subcategory": "informal",
        "definition": "Treating correlation, sequence, or weak evidence as proof of cause.",
        "example": "The update happened before the dip, so the update caused it.",
        "impact": "Creates overconfident causal stories from thin evidence.",
        "mitigation": "Separate timing, correlation, mechanism, and controlled evidence.",
        "aliases": ["causal overreach", "false cause", "post hoc"],
    },
    {
        "slug": "unsupported-certainty",
        "title": "Unsupported certainty",
        "subcategory": "informal",
        "definition": "Stating a claim with more certainty than the evidence supports.",
        "example": "This will definitely work.",
        "impact": "Pushes readers toward overconfidence and away from calibration.",
        "mitigation": "Ask what evidence would justify the level of certainty.",
        "aliases": ["unsupported certainty", "certainty inflation"],
    },
    {
        "slug": "straw-man",
        "title": "Straw man",
        "subcategory": "informal",
        "definition": "Misrepresenting an opposing view so it is easier to attack.",
        "example": "They want safety, so they must want no progress.",
        "impact": "Reduces the quality of disagreement and hides the strongest counterpoint.",
        "mitigation": "Restate the opposing view in its strongest form first.",
        "aliases": ["straw man", "strawman"],
    },
    {
        "slug": "ad-hominem",
        "title": "Ad hominem",
        "subcategory": "informal",
        "definition": "Attacking a person instead of addressing the claim.",
        "example": "Ignore the argument because the speaker is unlikeable.",
        "impact": "Shifts attention away from evidence and reasoning.",
        "mitigation": "Separate the person from the proposition.",
        "aliases": ["ad hominem", "personal attack"],
    },
    {
        "slug": "appeal-to-authority",
        "title": "Appeal to authority",
        "subcategory": "informal",
        "definition": "Treating an authority as decisive when the supporting evidence is not shown.",
        "example": "It must be true because an expert said so.",
        "impact": "Substitutes status for evidence.",
        "mitigation": "Check the actual evidence, scope, and dissenting views.",
        "aliases": ["appeal to authority", "authority bias"],
    },
    {
        "slug": "bandwagon",
        "title": "Bandwagon",
        "subcategory": "informal",
        "definition": "Assuming a claim is right because many people believe it.",
        "example": "Everyone is doing it, so it must be right.",
        "impact": "Turns popularity into a substitute for justification.",
        "mitigation": "Ask whether popularity is evidence or only social pressure.",
        "aliases": ["bandwagon", "appeal to popularity"],
    },
    {
        "slug": "hasty-generalization",
        "title": "Hasty generalization",
        "subcategory": "informal",
        "definition": "Drawing a broad conclusion from too little or too narrow evidence.",
        "example": "One bad meeting means the whole team is incompetent.",
        "impact": "Overextends limited evidence into a rule.",
        "mitigation": "Check sample size, diversity, and counterexamples.",
        "aliases": ["hasty generalization", "generalization"],
    },
    {
        "slug": "cherry-picking",
        "title": "Cherry picking",
        "subcategory": "informal",
        "definition": "Selecting only the evidence that supports the preferred conclusion.",
        "example": "Citing the one favorable metric and ignoring the rest.",
        "impact": "Produces a distorted picture of the evidence.",
        "mitigation": "Look for missing data and disconfirming cases.",
        "aliases": ["cherry picking", "selective evidence"],
    },
    {
        "slug": "slippery-slope",
        "title": "Slippery slope",
        "subcategory": "informal",
        "definition": "Arguing that one step will inevitably trigger a long chain of worsening outcomes without support.",
        "example": "If we allow this exception, everything will collapse.",
        "impact": "Exaggerates downstream consequences.",
        "mitigation": "Ask for mechanisms and probabilities at each step.",
        "aliases": ["slippery slope"],
    },
    {
        "slug": "equivocation",
        "title": "Equivocation",
        "subcategory": "formal",
        "definition": "Using the same word with different meanings mid-argument.",
        "example": "It is natural, therefore it is good.",
        "impact": "Smuggles in conclusions through word-shifts.",
        "mitigation": "Define the key term and keep its meaning stable.",
        "aliases": ["equivocation"],
    },
    {
        "slug": "circular-reasoning",
        "title": "Circular reasoning",
        "subcategory": "formal",
        "definition": "The conclusion is assumed in the premises.",
        "example": "It is trustworthy because it always tells the truth.",
        "impact": "Looks like proof without adding evidence.",
        "mitigation": "Separate the claim from the evidence for it.",
        "aliases": ["circular reasoning", "begging the question"],
    },
    {
        "slug": "argument-from-ignorance",
        "title": "Argument from ignorance",
        "subcategory": "informal",
        "definition": "Treating lack of evidence against a claim as evidence for it.",
        "example": "No one has disproved it, so it must be true.",
        "impact": "Turns missing evidence into a false signal.",
        "mitigation": "Ask what positive evidence would be needed.",
        "aliases": ["argument from ignorance"],
    },
    {
        "slug": "sunk-cost-fallacy",
        "title": "Sunk cost fallacy",
        "subcategory": "informal",
        "definition": "Continuing a losing course because of prior investment.",
        "example": "We have already spent so much, so we cannot stop.",
        "impact": "Locks decision-making to past costs instead of future value.",
        "mitigation": "Separate recoverable value from irrecoverable cost.",
        "aliases": ["sunk cost fallacy", "sunk cost"],
    },
    {
        "slug": "base-rate-neglect",
        "title": "Base rate neglect",
        "subcategory": "formal",
        "definition": "Ignoring background frequencies when interpreting a case.",
        "example": "Treating a vivid story as if it were typical.",
        "impact": "Overweights the anecdote and underweights the base rate.",
        "mitigation": "Ask for prevalence and reference classes.",
        "aliases": ["base rate neglect", "base-rate neglect"],
    },
    {
        "slug": "selection-bias",
        "title": "Selection bias",
        "subcategory": "methodological",
        "definition": "The sample or evidence pool is not representative of the target population.",
        "example": "Surveying only the happiest customers.",
        "impact": "Skews results toward the sampled subset.",
        "mitigation": "Check how cases entered the sample.",
        "aliases": ["selection bias"],
    },
    {
        "slug": "confirmation-bias",
        "title": "Confirmation bias",
        "subcategory": "cognitive",
        "definition": "Favoring evidence that supports an existing belief and discounting contrary evidence.",
        "example": "Noticing only the facts that support a preferred theory.",
        "impact": "Narrows the evidence search and hardens prior beliefs.",
        "mitigation": "Actively seek disconfirming evidence.",
        "aliases": ["confirmation bias"],
    },
]


STRONG_IMPORT_TERMS = {
    "bias",
    "biases",
    "fallacy",
    "fallacies",
    "argument",
    "arguments",
    "evidence",
    "evidential",
    "reasoning",
    "logic",
    "logical",
    "socratic",
    "toulmin",
    "premortem",
    "pre-mortem",
    "red team",
    "red-team",
    "triangulation",
    "reproducibility",
    "methodology",
    "uncertainty",
    "calibration",
    "causal",
    "causality",
    "first principles",
    "root cause",
    "steelman",
    "counterexample",
    "debias",
    "reflection",
    "reflective",
    "systems",
    "systemic",
    "design justice",
    "critical",
    "analysis",
    "audit",
    "auditing",
    "checklist",
    "question",
    "inference",
    "ethics",
    "equity",
    "cross-cultural",
    "inclusive",
    "fairness",
    "prompting",
    "framework",
    "frameworks",
    "decision",
    "compare",
    "compare and contrast",
    "model",
    "falsif",
}

MODERATE_IMPORT_TERMS = {
    "clarity",
    "clarify",
    "prompt",
    "prompts",
    "check",
    "review",
    "evaluate",
    "evaluation",
    "study",
    "survey",
    "research",
    "analysis",
    "compare",
    "decision",
    "tradeoff",
    "trade-offs",
    "uncertain",
    "uncertainty",
    "bias",
    "logic",
    "questioning",
    "counter",
    "test",
    "reflection",
    "inclusive",
    "fair",
    "ethic",
    "power",
}

STRONG_DENY_TERMS = {
    "marketing",
    "sales",
    "seo",
    "job search",
    "resume",
    "career",
    "recruiting",
    "interview",
    "travel",
    "prices",
    "pricing",
    "growth hack",
    "brand",
    "email marketing",
    "press release",
    "social media post",
    "outreach",
    "pipeline",
    "copywriting",
    "storytelling",
}

EXTRA_ALLOW_IDS = {
    "pattern-picker",
    "ct:thinking-lenses:systems:relationality-all-my-relations",
    "ct:thinking-lenses:systems:reciprocity-stewardship",
    "ct:methodology-checks:preflight:cross-cultural-anti-flattening",
}


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def normalize_text(value: str | None) -> str:
    if not value:
        return ""
    text = unicodedata.normalize("NFKC", value)
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def trim_sentences(text: str, max_sentences: int) -> str:
    sentences = [piece.strip() for piece in re.split(r"(?<=[.!?])\s+|\n+", text.strip()) if piece.strip()]
    if not sentences:
        return re.sub(r"\s+", " ", text.strip())
    return " ".join(sentences[:max_sentences]).strip()


def slugify(value: str | None) -> str:
    if not value:
        return ""
    text = unicodedata.normalize("NFKD", value)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = re.sub(r"-{2,}", "-", text).strip("-")
    return text


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return [item for item in value if item not in (None, "", [], {})]
    if isinstance(value, tuple):
        return [item for item in value if item not in (None, "", [], {})]
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    return [value]


def flatten_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        pieces = [flatten_text(v) for v in value.values()]
        return " ".join(piece for piece in pieces if piece)
    if isinstance(value, (list, tuple, set)):
        pieces = [flatten_text(v) for v in value]
        return " ".join(piece for piece in pieces if piece)
    return str(value)


def first_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for item in value.values():
            text = first_text(item)
            if text:
                return text
        return ""
    if isinstance(value, (list, tuple, set)):
        for item in value:
            text = first_text(item)
            if text:
                return text
        return ""
    return str(value).strip()


def json_text(value: Any) -> str:
    if value is None:
        return "[]"
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def confidence_weight(value: Any) -> str:
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"low", "medium", "high"}:
            return lowered
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return "medium"
    if numeric >= 0.85:
        return "high"
    if numeric >= 0.65:
        return "medium"
    return "low"


def infer_three_cs(category: str, subcategory: str, kind: str, title: str) -> str:
    category = (category or "").lower()
    subcategory = (subcategory or "").lower()
    kind = (kind or "").lower()
    title_lower = (title or "").lower()
    if any(term in title_lower for term in ("relational", "reciprocity", "steward", "ganma", "kaitiakitanga", "two-eyed", "kaupapa", "cross-cultural", "all my relations", "community capitals", "storywork")):
        return "Compassionate"
    if category == "thinking-lenses":
        if subcategory == "reflective" or "reflect" in title_lower:
            return "Compassionate"
        if subcategory in {"creative", "design"} or "creative" in title_lower or "design" in title_lower:
            return "Creative"
    if category == "methodology-checks" and any(term in title_lower for term in ("culture", "interpretive", "anti-flattening", "protocol")):
        return "Compassionate"
    if category in {"biases", "fallacies", "methodology-checks", "reasoning-frameworks", "heuristics"}:
        return "Critical"
    if kind in {"helper", "pattern", "methodology", "framework"} and ("prompt" in title_lower or "question" in title_lower):
        return "Creative"
    return "Critical"


def public_schema(category: str, subcategory: str, kind: str) -> str:
    category = (category or "").lower()
    subcategory = (subcategory or "").lower()
    kind = (kind or "").lower()
    if category == "biases":
        return "bias"
    if category == "fallacies":
        return "fallacy"
    if category == "heuristics":
        return "heuristic"
    if category in {"reasoning-frameworks", "thinking-lenses", "methodology-checks"}:
        return "framework"
    if category == "other" and kind in {"framework", "pattern", "methodology", "technique", "helper"}:
        return "framework"
    if "audit" in subcategory or "check" in subcategory:
        return "framework"
    return "other"


def document_id_for(source_path: str) -> str:
    return f"doc:{sha256_text(source_path)[:16]}"


def parse_tags(raw_tags: Any) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for tag in ensure_list(raw_tags):
        if isinstance(tag, dict):
            namespace = str(tag.get("namespace") or "").strip()
            value = str(tag.get("value") or "").strip()
            if namespace and value:
                pairs.append((namespace, value))
            continue
        text = str(tag).strip()
        if not text:
            continue
        if ":" in text:
            namespace, value = text.split(":", 1)
            namespace = namespace.strip()
            value = value.strip()
            if namespace and value:
                pairs.append((namespace, value))
    return pairs


def extract_js_array_text(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    marker = "const arr = ["
    start = text.find(marker)
    if start == -1:
        raise ValueError(f"Unable to locate array start in {path}")
    idx = text.find("[", start)
    if idx == -1:
        raise ValueError(f"Unable to locate opening bracket in {path}")
    depth = 0
    quote: str | None = None
    escaped = False
    for pos in range(idx, len(text)):
        ch = text[pos]
        if quote is not None:
            if escaped:
                escaped = False
                continue
            if ch == "\\":
                escaped = True
                continue
            if ch == quote:
                quote = None
            continue
        if ch in {'"', "'", "`"}:
            quote = ch
            continue
        if ch == "[":
            depth += 1
            continue
        if ch == "]":
            depth -= 1
            if depth == 0:
                return text[idx : pos + 1]
    raise ValueError(f"Unable to locate closing bracket in {path}")


def parse_js_array(path: Path) -> list[dict[str, Any]]:
    array_text = extract_js_array_text(path)
    array_text = re.sub(r",\s*([}\]])", r"\1", array_text)
    return json.loads(array_text)


def build_corpus_digest(paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted({Path(p) for p in paths}, key=lambda p: str(p)):
        digest.update(str(path).encode("utf-8"))
        if path.exists():
            digest.update(sha256_file(path).encode("utf-8"))
    return digest.hexdigest()


def text_blob(*values: Any) -> str:
    pieces: list[str] = []
    for value in values:
        text = flatten_text(value)
        if text:
            pieces.append(text)
    return " ".join(pieces).strip()


def canonical_lookup_key(value: str | None) -> str:
    return normalize_text(value)


def has_positive_terms(text: str, terms: set[str]) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in terms)


def import_score(text: str) -> int:
    lowered = text.lower()
    score = 0
    score += sum(2 for term in STRONG_IMPORT_TERMS if term in lowered)
    score += sum(1 for term in MODERATE_IMPORT_TERMS if term in lowered)
    score -= sum(3 for term in STRONG_DENY_TERMS if term in lowered)
    return score


def should_import_extra_record(record: dict[str, Any]) -> bool:
    record_id = str(record.get("entry_id") or record.get("id") or record.get("slug") or "")
    if normalize_text(record_id) in {normalize_text(value) for value in EXTRA_ALLOW_IDS}:
        return True
    text = text_blob(
        record.get("id"),
        record.get("slug"),
        record.get("label"),
        record.get("title"),
        record.get("definition"),
        record.get("summary"),
        record.get("help"),
        record.get("search_text"),
        record.get("categories"),
        record.get("tags"),
        record.get("use_cases"),
        record.get("boosters"),
        record.get("fields"),
        record.get("facets"),
    )
    return import_score(text) >= 3


def infer_category_and_subcategory(record: dict[str, Any]) -> tuple[str, str]:
    explicit_category = first_text(record.get("category") or record.get("forced_category"))
    explicit_subcategory = first_text(record.get("subcategory") or record.get("subgroup"))
    entry_id = first_text(record.get("entry_id") or record.get("id"))
    if explicit_category:
        return explicit_category, explicit_subcategory or "general"
    if entry_id.startswith("ct:biases:"):
        parts = entry_id.split(":")
        return "biases", parts[2] if len(parts) > 3 and parts[2] else "general"
    if entry_id.startswith("ct:fallacies:"):
        parts = entry_id.split(":")
        return "fallacies", parts[2] if len(parts) > 3 and parts[2] else "informal"
    text = text_blob(
        entry_id,
        record.get("slug"),
        record.get("title"),
        record.get("label"),
        record.get("definition"),
        record.get("summary"),
        record.get("help"),
        record.get("categories"),
        record.get("tags"),
        record.get("use_cases"),
        record.get("boosters"),
        record.get("fields"),
        record.get("facets"),
    ).lower()
    if any(term in text for term in ["cross-cultural anti-flattening", "anti-flattening", "interpretive humility", "no universalizing", "restricted knowledge", "who can authorize interpretation"]):
        return "methodology-checks", "preflight"
    if any(term in text for term in ["relationality", "all my relations", "reciprocity", "stewardship", "ganma", "kaitiakitanga", "two-eyed seeing", "kaupapa māori", "kaupapa maori", "indigenous storywork"]):
        return "thinking-lenses", "systems"
    if any(term in text for term in ["bias", "fallacy", "evidence", "audit", "check", "reproducibility", "red team", "red-team", "methodology", "calibration"]):
        if "audit" in text or "check" in text or "reproducibility" in text or "methodology" in text or "calibration" in text:
            return "methodology-checks", "audit" if "audit" in text else "preflight"
    if any(term in text for term in ["systems", "systemic", "soft systems", "dialectic", "reflect", "empathy", "inclusive", "cross-cultural", "equity", "design justice", "participatory", "community", "ethic", "guardianship", "stewardship", "power", "kaitiakitanga", "two-eyed seeing", "relationality", "reciprocity", "all my relations", "ganma", "kaupapa māori", "kaupapa maori"]):
        if "reflect" in text or "reflection" in text or "mindfulness" in text:
            return "thinking-lenses", "reflective"
        if "design" in text:
            return "thinking-lenses", "design"
        if "creative" in text or "brainstorm" in text or "lateral" in text:
            return "thinking-lenses", "creative"
        return "thinking-lenses", "systems"
    if any(term in text for term in ["argument", "reasoning", "logic", "inference", "uncertainty", "causal", "bayesian", "socratic", "toulmin", "compare", "decision matrix", "root cause", "first principles", "falsif", "steelman", "questioning", "thesis", "counterexample"]):
        if "uncertainty" in text or "calibration" in text or "bayesian" in text:
            return "reasoning-frameworks", "uncertainty"
        if "argument" in text or "toulmin" in text or "socratic" in text or "thesis" in text:
            return "reasoning-frameworks", "argumentation"
        return "reasoning-frameworks", "inference"
    if any(term in text for term in ["heuristic", "rule of thumb", "shortcut", "checklist", "decision aid", "quick score", "weighted mini-matrix", "ice", "rice", "wsjf"]):
        return "heuristics", "decision"
    if "fallacy" in text:
        return "fallacies", "informal"
    if "prompt" in text or "question" in text:
        return "other", "prompting"
    return "other", "adjacent"


def normalize_examples(record: dict[str, Any]) -> list[str]:
    if "examples" in record:
        examples = [first_text(item) for item in ensure_list(record.get("examples"))]
        return [example for example in examples if example]
    if "use_cases" in record:
        examples = [first_text(item) for item in ensure_list(record.get("use_cases"))]
        return [example for example in examples if example]
    return []


def normalize_when_to_use(record: dict[str, Any]) -> list[str]:
    if "when_to_use" in record:
        values = [first_text(item) for item in ensure_list(record.get("when_to_use"))]
        return [value for value in values if value]
    if "use_cases" in record:
        values = [first_text(item) for item in ensure_list(record.get("use_cases"))]
        return [value for value in values if value]
    return []


def normalize_list_field(record: dict[str, Any], field: str) -> list[str]:
    values = [first_text(item) for item in ensure_list(record.get(field))]
    return [value for value in values if value]


def source_record_to_document(source_path: str, source_type: str | None, source_collection: str | None, source_slug: str | None, source_title: str | None, provenance_json: str | None, content_hash: str | None) -> tuple[str, dict[str, Any]]:
    document_id = document_id_for(source_path)
    return document_id, {
        "document_id": document_id,
        "source_path": source_path,
        "source_type": source_type,
        "source_collection": source_collection,
        "source_slug": source_slug,
        "source_title": source_title,
        "content_hash": content_hash,
        "provenance_json": provenance_json,
    }


def concept_search_text(*values: Any) -> str:
    return " ".join(part for part in [normalize_text(text_blob(*values))] if part).strip()


def merge_record_fields(record: dict[str, Any], fallback: dict[str, Any]) -> dict[str, Any]:
    merged = dict(fallback)
    for key, value in record.items():
        if value not in (None, "", [], {}):
            merged[key] = value
    return merged


def classify_kind(record: dict[str, Any]) -> str:
    for key in ("kind", "type"):
        value = record.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "framework"


def build_concept_record(
    record: dict[str, Any],
    *,
    source_kind: str,
    source_path: str,
    source_type: str | None,
    source_collection: str | None,
    source_slug: str | None,
    source_title: str | None,
    document_id: str,
    normalized_path: str | None = None,
    render_format: str | None = None,
    forced_category: str | None = None,
    forced_subcategory: str | None = None,
    forced_kind: str | None = None,
    forced_concept_id: str | None = None,
) -> dict[str, Any]:
    title = first_text(record.get("title") or record.get("label") or record.get("name") or record.get("heading") or source_title)
    slug = slugify(first_text(record.get("slug") or record.get("id") or source_slug or title))
    entry_id = first_text(record.get("entry_id") or record.get("id") or forced_concept_id or "")
    if not entry_id:
        if source_kind == "template":
            entry_id = f"ct:template:{slug}"
        elif source_kind == "library":
            entry_id = f"ct:library:{slug}"
        elif source_kind == "fallacy":
            entry_id = f"ct:fallacies:{forced_subcategory or 'informal'}:{slug}"
        else:
            entry_id = f"ct:{forced_category or 'other'}:{forced_subcategory or 'adjacent'}:{slug}"
    category = forced_category or first_text(record.get("category") or record.get("collection") or source_collection or "other")
    subcategory = forced_subcategory or first_text(record.get("subcategory") or record.get("subgroup") or "")
    if not category or category == "framework":
        category = "other"
    kind = forced_kind or classify_kind(record)
    summary = first_text(record.get("summary") or record.get("definition") or record.get("help") or record.get("description") or title)
    definition = first_text(record.get("definition") or summary)
    examples = normalize_examples(record)
    example = first_text(record.get("example") or examples or record.get("help") or summary)
    impact = first_text(record.get("impact") or record.get("effect") or record.get("why") or summary)
    mitigation = first_text(record.get("mitigation") or record.get("countermeasures") or record.get("countermeasure") or record.get("anti_patterns") or record.get("anti_patterns"))
    if not mitigation and isinstance(record.get("boosters"), list):
        mitigation = first_text(record.get("boosters"))
    confidence = record.get("confidence")
    try:
        confidence_value = float(confidence) if confidence is not None else None
    except (TypeError, ValueError):
        confidence_value = None
    confidence_label = confidence_weight(confidence if confidence is not None else confidence_value)
    aliases = []
    aliases.extend(normalize_list_field(record, "aliases"))
    if title:
        aliases.append(title)
    if slug:
        aliases.append(slug)
    if source_slug:
        aliases.append(source_slug)
    related = normalize_list_field(record, "related")
    if not related:
        related = normalize_list_field(record, "related_entry_ids")
    when_to_use = normalize_when_to_use(record)
    failure_modes = normalize_list_field(record, "failure_modes")
    signals = normalize_list_field(record, "signals")
    anti_patterns = normalize_list_field(record, "anti_patterns")
    quality_flags = ensure_list(record.get("quality_flags"))
    explicit_three_cs = first_text(record.get("three_cs_lens") or record.get("three_cs"))
    inferred_three_cs = infer_three_cs(category, subcategory, kind, title)
    three_cs_lens = explicit_three_cs
    if three_cs_lens:
        if three_cs_lens == "Critical" and inferred_three_cs != "Critical":
            three_cs_lens = inferred_three_cs
    else:
        three_cs_lens = inferred_three_cs
    provenance = record.get("provenance") or {
        "source_kind": source_kind,
        "source_path": source_path,
        "source_type": source_type,
        "source_collection": source_collection,
        "source_slug": source_slug,
        "source_title": source_title,
    }
    tags = record.get("tags") or []
    search_text = concept_search_text(
        title,
        slug,
        entry_id,
        summary,
        definition,
        example,
        impact,
        mitigation,
        examples,
        when_to_use,
        failure_modes,
        signals,
        anti_patterns,
        tags,
        record.get("use_cases"),
        record.get("boosters"),
        record.get("fields"),
        record.get("help"),
        record.get("description"),
    )
    return {
        "entry_id": entry_id,
        "slug": slug,
        "title": title or entry_id,
        "kind": kind,
        "category": category,
        "subcategory": subcategory or "general",
        "public_schema": public_schema(category, subcategory, kind),
        "summary": summary,
        "definition": definition,
        "example": example,
        "examples": examples,
        "impact": impact,
        "mitigation": mitigation,
        "confidence": confidence_value,
        "confidence_weight": confidence_label,
        "three_cs_lens": three_cs_lens,
        "aliases": aliases,
        "related": related,
        "when_to_use": when_to_use,
        "failure_modes": failure_modes,
        "signals": signals,
        "anti_patterns": anti_patterns,
        "quality_flags": quality_flags,
        "provenance": provenance,
        "source_document_id": document_id,
        "source_path": source_path,
        "source_type": source_type,
        "source_collection": source_collection,
        "source_slug": source_slug,
        "source_title": source_title,
        "normalized_path": normalized_path,
        "render_format": render_format,
        "content_text": text_blob(
            title,
            summary,
            definition,
            example,
            impact,
            mitigation,
            examples,
            when_to_use,
            failure_modes,
            signals,
            anti_patterns,
            record.get("tags"),
            record.get("use_cases"),
            record.get("boosters"),
            record.get("help"),
            record.get("fields"),
        ),
        "search_text": search_text,
        "tags": tags,
    }


def load_normalized_records(root: Path) -> list[dict[str, Any]]:
    catalog = read_json(root / "indexes" / "normalized-catalog.json")
    records: list[dict[str, Any]] = []
    for item in sorted(catalog, key=lambda row: row["entry_id"]):
        normalized_path = Path(item["normalized_path"])
        if normalized_path.suffix.lower() == ".json":
            raw = read_json(normalized_path)
        else:
            raw = parse_markdown_record(normalized_path, item)
        merged = dict(raw)
        merged.setdefault("entry_id", item["entry_id"])
        merged.setdefault("title", item["title"])
        merged.setdefault("category", item["category"])
        merged.setdefault("subcategory", item["subcategory"])
        merged.setdefault("kind", item["kind"])
        merged.setdefault("confidence", item.get("confidence"))
        merged.setdefault("quality_flags", raw.get("quality_flags") or [])
        merged["source_catalog_entry"] = item
        records.append(merged)
    return records


def parse_markdown_record(path: Path, catalog_item: dict[str, Any]) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    metadata: dict[str, str] = {}
    body = text
    lines = text.splitlines()
    if lines and lines[0].strip() == "---":
        try:
            end_index = next(index for index, line in enumerate(lines[1:], start=1) if line.strip() == "---")
        except StopIteration:
            end_index = -1
        if end_index > 0:
            header = lines[1:end_index]
            body = "\n".join(lines[end_index + 1 :])
            for line in header:
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                value = value.strip().strip('"').strip("'")
                metadata[key.strip()] = value
    body_without_headings = re.sub(r"^\s*#{1,6}\s*", "", body, flags=re.M)
    body_without_headings = re.sub(r"^\s*[-*+]\s*", "", body_without_headings, flags=re.M)
    summary = trim_sentences(body_without_headings, 2)
    title = metadata.get("title") or catalog_item.get("title") or path.stem.replace("-", " ")
    kind = metadata.get("kind") or catalog_item.get("kind") or "note"
    category = metadata.get("category") or catalog_item.get("category") or "other"
    subcategory = metadata.get("subcategory") or catalog_item.get("subcategory") or "legacy"
    source_path = metadata.get("source_path") or str(path)
    source_type = metadata.get("source_type") or ("txt" if source_path.endswith(".txt") else "md")
    confidence = metadata.get("confidence") or catalog_item.get("confidence")
    quality = metadata.get("quality") or catalog_item.get("quality")
    return {
        "entry_id": metadata.get("entry_id") or catalog_item.get("entry_id"),
        "title": title,
        "kind": kind,
        "category": category,
        "subcategory": subcategory,
        "source_path": source_path,
        "source_type": source_type,
        "summary": summary,
        "definition": summary,
        "example": summary,
        "examples": [],
        "impact": summary,
        "mitigation": "",
        "confidence": confidence,
        "aliases": [title, path.stem],
        "related": [],
        "when_to_use": [],
        "failure_modes": [],
        "signals": [],
        "anti_patterns": [],
        "quality_flags": [{"code": quality or "legacy-md", "severity": "info", "message": metadata.get("route_reason") or "legacy markdown record"}],
        "provenance": {
            "route_reason": metadata.get("route_reason") or catalog_item.get("route_reason"),
            "source_kind": metadata.get("source_type") or catalog_item.get("source_type") or "md",
            "source_index": catalog_item.get("source_index"),
            "source_path": source_path,
            "source_type": source_type,
            "source_collection": metadata.get("category") or catalog_item.get("category") or "other",
            "source_slug": metadata.get("entry_id") or catalog_item.get("entry_id"),
            "source_title": title,
        },
        "content_text": text,
        "search_text": text_blob(title, summary, body, metadata),
    }


def load_library_records(root: Path) -> list[dict[str, Any]]:
    library_dir = root / "support" / "library"
    records = list(read_json(library_dir / "library.records.json"))
    additions_path = library_dir / "critical-compass.additions.json"
    if additions_path.exists():
        additions = read_json(additions_path)
        if isinstance(additions, list):
            records.extend(additions)
    for pack_path in sorted(library_dir.glob("*.pack.json")):
        if pack_path.name.startswith("._") or pack_path.name == ".DS_Store":
            continue
        pack_records = read_json(pack_path)
        if isinstance(pack_records, list):
            records.extend(pack_records)
    deduped: dict[str, dict[str, Any]] = {}
    for record in records:
        key = canonical_lookup_key(first_text(record.get("entry_id") or record.get("id") or record.get("source_slug") or record.get("slug") or record.get("title")))
        if not key:
            continue
        deduped[key] = record
    return list(deduped.values())


def load_template_records(root: Path) -> list[dict[str, Any]]:
    return parse_js_array(root / "incoming" / "raw" / "source-glossary-js" / "templates.data.js")


def source_fingerprint_paths(root: Path) -> list[Path]:
    library_dir = root / "support" / "library"
    paths = [
        root / "indexes" / "normalized-catalog.json",
        root / "indexes" / "aliases.json",
        root / "indexes" / "normalized-paths.json",
        root / "indexes" / "summary.json",
        library_dir / "library.records.json",
        library_dir / "critical-compass.additions.json",
        library_dir / "library.records.schema.json",
        root / "incoming" / "raw" / "source-glossary-js" / "templates.data.js",
    ]
    paths.extend(sorted(library_dir.glob("*.pack.json")))
    paths.extend(sorted((root / "normalized").rglob("*.json")))
    return paths


def create_connection(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(str(path))
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = OFF")
    connection.execute("PRAGMA synchronous = OFF")
    connection.execute("PRAGMA temp_store = MEMORY")
    return connection


def insert_document(connection: sqlite3.Connection, document: dict[str, Any]) -> None:
    connection.execute(
        """
        INSERT INTO documents (
          document_id,
          source_path,
          source_type,
          source_collection,
          source_slug,
          source_title,
          content_hash,
          provenance_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            document["document_id"],
            document["source_path"],
            document.get("source_type"),
            document.get("source_collection"),
            document.get("source_slug"),
            document.get("source_title"),
            document.get("content_hash"),
            document.get("provenance_json"),
        ),
    )


def insert_concept(connection: sqlite3.Connection, concept: dict[str, Any]) -> int:
    cursor = connection.execute(
        """
        INSERT INTO concepts (
          concept_id,
          entry_id,
          slug,
          title,
          kind,
          category,
          subcategory,
          public_schema,
          summary,
          definition,
          example,
          examples_json,
          impact,
          mitigation,
          confidence,
          confidence_weight,
          three_cs_lens,
          aliases_json,
          related_json,
          when_to_use_json,
          failure_modes_json,
          signals_json,
          anti_patterns_json,
          quality_flags_json,
          provenance_json,
          source_document_id,
          source_path,
          normalized_path,
          render_format,
          content_text,
          search_text
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            concept["entry_id"],
            concept["entry_id"],
            concept["slug"],
            concept["title"],
            concept["kind"],
            concept["category"],
            concept["subcategory"],
            concept["public_schema"],
            concept["summary"],
            concept["definition"],
            concept["example"],
            json_text(concept["examples"]),
            concept["impact"],
            concept["mitigation"],
            concept["confidence"],
            concept["confidence_weight"],
            concept["three_cs_lens"],
            json_text(sorted({alias for alias in concept["aliases"] if alias})),
            json_text(sorted({related for related in concept["related"] if related})),
            json_text(concept["when_to_use"]),
            json_text(concept["failure_modes"]),
            json_text(concept["signals"]),
            json_text(concept["anti_patterns"]),
            json_text(concept["quality_flags"]),
            json_text(concept["provenance"]),
            concept["source_document_id"],
            concept["source_path"],
            concept["normalized_path"],
            concept["render_format"],
            concept["content_text"],
            concept["search_text"],
        ),
    )
    return int(cursor.lastrowid)


def insert_aliases(connection: sqlite3.Connection, concept_id: str, aliases: Iterable[str], alias_kind: str, source: str | None = None) -> int:
    inserted = 0
    seen: set[str] = set()
    for alias in aliases:
        alias = alias.strip()
        if not alias:
            continue
        alias_norm = canonical_lookup_key(alias)
        if not alias_norm or alias_norm in seen:
            continue
        seen.add(alias_norm)
        connection.execute(
            "INSERT OR IGNORE INTO aliases (alias_norm, alias, concept_id, alias_kind, source) VALUES (?, ?, ?, ?, ?)",
            (alias_norm, alias, concept_id, alias_kind, source),
        )
        inserted += 1
    return inserted


def insert_facets(connection: sqlite3.Connection, concept_id: str, record: dict[str, Any]) -> int:
    inserted = 0
    category = record.get("category")
    subcategory = record.get("subcategory")
    kind = record.get("kind")
    for facet_type, facet_value in (
        ("category", category),
        ("subcategory", subcategory),
        ("kind", kind),
        ("public_schema", record.get("public_schema")),
    ):
        if facet_value:
            connection.execute(
                "INSERT OR IGNORE INTO concept_facets (facet_type, facet_value, concept_id, source) VALUES (?, ?, ?, ?)",
                (facet_type, str(facet_value), concept_id, "derived"),
            )
            inserted += 1
    for namespace, value in parse_tags(record.get("tags")):
        connection.execute(
            "INSERT OR IGNORE INTO concept_facets (facet_type, facet_value, concept_id, source) VALUES (?, ?, ?, ?)",
            (namespace, value, concept_id, "tags"),
        )
        inserted += 1
    return inserted


def fallback_relation_targets(record: dict[str, Any]) -> list[tuple[str, str | None]]:
    results: list[tuple[str, str | None]] = []
    for target in ensure_list(record.get("related")):
        text = first_text(target)
        if text:
            results.append(("related", text))
    for target in ensure_list(record.get("related_entry_ids")):
        text = first_text(target)
        if text:
            results.append(("related", text))
    relationships = record.get("relationships")
    if isinstance(relationships, dict):
        relationships = [relationships]
    for item in ensure_list(relationships):
        if isinstance(item, dict):
            relation_type = str(item.get("type") or item.get("relation_type") or "related").strip() or "related"
            target_ref = first_text(item.get("target") or item.get("target_id") or item.get("related") or item.get("entry_id") or item.get("to"))
            if target_ref:
                results.append((relation_type, target_ref))
        elif isinstance(item, str) and item.strip():
            results.append(("related", item.strip()))
    return results


def resolve_concept_id(concept_index: dict[str, str], alias_index: dict[str, str], ref: str) -> str | None:
    if not ref:
        return None
    ref_norm = canonical_lookup_key(ref)
    if not ref_norm:
        return None
    if ref in concept_index:
        value = concept_index[ref]
        if isinstance(value, dict):
            return str(value.get("entry_id") or value.get("concept_id") or ref)
        return str(value)
    if ref_norm in alias_index:
        return str(alias_index[ref_norm])
    if ref_norm in concept_index:
        value = concept_index[ref_norm]
        if isinstance(value, dict):
            return str(value.get("entry_id") or value.get("concept_id") or ref)
        return str(value)
    return None


def choose_seed_fallacy_id(record: dict[str, Any]) -> str | None:
    text = text_blob(record.get("title"), record.get("definition"), record.get("summary"), record.get("help"), record.get("search_text")).lower()
    if any(token in text for token in ["either", "or", "only two", "false dilemma", "false dichotomy"]):
        return "false-dilemma"
    if any(token in text for token in ["because", "therefore", "caused", "post hoc", "correlation", "after"]):
        return "causal-overreach"
    if any(token in text for token in ["definitely", "certainly", "always", "never", "guaranteed", "absolutely"]):
        return "unsupported-certainty"
    if any(token in text for token in ["because they", "he is", "she is", "they are", "ad hominem", "attack"]):
        return "ad-hominem"
    return None


def seed_database(root: Path, db_path: Path, schema_path: Path) -> dict[str, Any]:
    if not schema_path.exists():
        raise FileNotFoundError(f"Missing schema: {schema_path}")

    db_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = db_path.with_suffix(db_path.suffix + ".tmp")
    if temp_path.exists():
        temp_path.unlink()

    connection = create_connection(temp_path)
    try:
        connection.executescript(schema_path.read_text(encoding="utf-8"))

        documents_by_path: dict[str, dict[str, Any]] = {}
        source_paths_for_digest = source_fingerprint_paths(root)

        normalized_records = load_normalized_records(root)
        library_records = load_library_records(root)
        template_records = load_template_records(root)

        normalized_records = sorted(normalized_records, key=lambda item: item.get("entry_id") or "")
        library_records = sorted(library_records, key=lambda item: item.get("entry_id") or item.get("id") or "")
        template_records = sorted(template_records, key=lambda item: item.get("id") or item.get("slug") or "")

        normalized_source_paths = {
            str((Path(item["source_catalog_entry"]["normalized_path"]) if item.get("source_catalog_entry") else Path(item.get("normalized_path", "")))).strip()
            for item in normalized_records
        }
        extra_seen_keys: set[str] = set()
        inserted_rows: list[dict[str, Any]] = []

        def ensure_document(source_path: str, source_type: str | None, source_collection: str | None, source_slug: str | None, source_title: str | None, provenance: Any) -> str:
            if source_path not in documents_by_path:
                document_id, row = source_record_to_document(
                    source_path=source_path,
                    source_type=source_type,
                    source_collection=source_collection,
                    source_slug=source_slug,
                    source_title=source_title,
                    provenance_json=json.dumps(provenance, ensure_ascii=False, sort_keys=True) if provenance is not None else None,
                    content_hash=sha256_file(Path(source_path)) if Path(source_path).exists() else None,
                )
                documents_by_path[source_path] = row
                insert_document(connection, row)
            return documents_by_path[source_path]["document_id"]

        def should_skip_duplicate(concept: dict[str, Any]) -> bool:
            candidate_keys = {
                canonical_lookup_key(concept["entry_id"]),
                canonical_lookup_key(concept["slug"]),
                canonical_lookup_key(concept["title"]),
            }
            candidate_keys.discard("")
            return any(key in extra_seen_keys for key in candidate_keys)

        def mark_keys(concept: dict[str, Any]) -> None:
            for value in [concept["entry_id"], concept["slug"], concept["title"], *concept["aliases"]]:
                key = canonical_lookup_key(value)
                if key:
                    extra_seen_keys.add(key)

        # Seed the normalized corpus first.
        for record in normalized_records:
            source_catalog = record.get("source_catalog_entry") or {}
            normalized_path = str(source_catalog.get("normalized_path") or record.get("normalized_path") or "")
            source_path = str(record.get("source_path") or source_catalog.get("source_path") or normalized_path)
            source_type = str(record.get("source_type") or source_catalog.get("source_type") or "json")
            source_collection = str(record.get("category") or source_catalog.get("category") or record.get("collection") or "")
            source_slug = str(record.get("slug") or source_catalog.get("slug") or source_catalog.get("source_slug") or "")
            source_title = str(record.get("title") or source_catalog.get("title") or "")
            document_id = ensure_document(
                source_path=source_path or normalized_path,
                source_type=source_type,
                source_collection=source_collection,
                source_slug=source_slug,
                source_title=source_title,
                provenance=record.get("provenance"),
            )
            concept = build_concept_record(
                record,
                source_kind=str(record.get("provenance", {}).get("source_kind") or "normalized"),
                source_path=source_path or normalized_path,
                source_type=source_type,
                source_collection=source_collection,
                source_slug=source_slug,
                source_title=source_title,
                document_id=document_id,
                normalized_path=normalized_path or None,
                render_format=str(source_catalog.get("render_format") or record.get("render_format") or "json"),
                forced_category=str(record.get("category") or source_catalog.get("category") or "other"),
                forced_subcategory=str(record.get("subcategory") or source_catalog.get("subcategory") or "general"),
                forced_kind=str(record.get("kind") or source_catalog.get("kind") or "framework"),
            )
            if should_skip_duplicate(concept):
                continue
            rowid = insert_concept(connection, concept)
            insert_aliases(connection, concept["entry_id"], concept["aliases"], "source", str(source_path))
            insert_facets(connection, concept["entry_id"], {**concept, "tags": record.get("tags")})
            inserted_rows.append({**concept, "rowid": rowid, "source_record": record})
            mark_keys(concept)

        normalized_lookup = {
            canonical_lookup_key(row["entry_id"]): row["entry_id"]
            for row in inserted_rows
        }
        normalized_lookup.update({canonical_lookup_key(row["slug"]): row["entry_id"] for row in inserted_rows})
        normalized_lookup.update({canonical_lookup_key(row["title"]): row["entry_id"] for row in inserted_rows})

        # Seed a curated slice of library records.
        for record in library_records:
            if not should_import_extra_record(record):
                continue
            source_path = str(record.get("provenance", {}).get("source_path") or LIBRARY_RECORDS_PATH)
            source_type = str(record.get("provenance", {}).get("source_type") or "json")
            source_collection = str(record.get("collection") or record.get("kind") or "library")
            source_slug = str(record.get("source_slug") or record.get("slug") or record.get("entry_id") or "")
            source_title = str(record.get("title") or record.get("name") or "")
            document_id = ensure_document(
                source_path=source_path,
                source_type=source_type,
                source_collection=source_collection,
                source_slug=source_slug,
                source_title=source_title,
                provenance=record.get("provenance"),
            )
            category, subcategory = infer_category_and_subcategory(record)
            concept_id = str(record.get("entry_id") or f"ct:imported:{slugify(record.get('title') or record.get('source_slug') or record.get('slug') or 'untitled')}")
            if canonical_lookup_key(concept_id) in extra_seen_keys:
                continue
            concept = build_concept_record(
                record,
                source_kind="library",
                source_path=source_path,
                source_type=source_type,
                source_collection=source_collection,
                source_slug=source_slug,
                source_title=source_title,
                document_id=document_id,
                normalized_path=None,
                render_format="json",
                forced_category=category,
                forced_subcategory=subcategory,
                forced_kind=str(record.get("kind") or record.get("collection") or "framework"),
                forced_concept_id=concept_id,
            )
            if should_skip_duplicate(concept):
                continue
            rowid = insert_concept(connection, concept)
            insert_aliases(connection, concept["entry_id"], concept["aliases"], "source", str(source_path))
            insert_facets(connection, concept["entry_id"], {**concept, "tags": record.get("tags")})
            inserted_rows.append({**concept, "rowid": rowid, "source_record": record})
            mark_keys(concept)

        # Seed selectively imported templates from the local glossary export.
        for record in template_records:
            if not should_import_extra_record(record):
                continue
            source_path = str(TEMPLATES_DATA_PATH)
            document_id = ensure_document(
                source_path=source_path,
                source_type="js",
                source_collection="templates",
                source_slug=str(record.get("slug") or record.get("id") or ""),
                source_title=str(record.get("label") or record.get("title") or record.get("slug") or ""),
                provenance={"source_kind": "template", "source_path": source_path},
            )
            category, subcategory = infer_category_and_subcategory(record)
            concept_id = str(record.get("entry_id") or record.get("id") or f"ct:template:{slugify(record.get('slug') or record.get('label') or 'untitled')}")
            if canonical_lookup_key(concept_id) in extra_seen_keys:
                continue
            title = first_text(record.get("label") or record.get("title") or record.get("slug"))
            template_record = dict(record)
            template_record.setdefault("title", title)
            template_record.setdefault("summary", first_text(record.get("definition") or record.get("help") or title))
            template_record.setdefault("definition", first_text(record.get("definition") or record.get("help") or title))
            template_record.setdefault("examples", record.get("use_cases") or [])
            template_record.setdefault("when_to_use", record.get("use_cases") or [])
            template_record.setdefault("kind", record.get("kind") or "helper")
            concept = build_concept_record(
                template_record,
                source_kind="template",
                source_path=source_path,
                source_type="js",
                source_collection="templates",
                source_slug=str(record.get("slug") or record.get("id") or ""),
                source_title=title,
                document_id=document_id,
                normalized_path=None,
                render_format="json",
                forced_category=category,
                forced_subcategory=subcategory,
                forced_kind=str(template_record.get("kind") or "helper"),
                forced_concept_id=concept_id,
            )
            if should_skip_duplicate(concept):
                continue
            rowid = insert_concept(connection, concept)
            insert_aliases(connection, concept["entry_id"], concept["aliases"], "source", source_path)
            insert_facets(connection, concept["entry_id"], {**concept, "tags": record.get("tags")})
            inserted_rows.append({**concept, "rowid": rowid, "source_record": record})
            mark_keys(concept)

        # Seed a compact fallacy catalog so claim challenges always have a named risk.
        for item in FALLACY_SEEDS:
            source_path = str(ROOT / "seed_db.py")
            document_id = ensure_document(
                source_path=source_path,
                source_type="py",
                source_collection="fallacy-seed",
                source_slug=item["slug"],
                source_title=item["title"],
                provenance={"source_kind": "seed", "source_path": source_path},
            )
            record = {
                "entry_id": f"ct:fallacies:{item['subcategory']}:{item['slug']}",
                "slug": item["slug"],
                "title": item["title"],
                "summary": item["definition"],
                "definition": item["definition"],
                "examples": [item["example"]],
                "when_to_use": [item["mitigation"]],
                "kind": "fallacy",
                "category": "fallacies",
                "subcategory": item["subcategory"],
                "confidence": 0.99,
                "aliases": item["aliases"],
                "related": [],
                "impact": item["impact"],
                "mitigation": item["mitigation"],
                "quality_flags": [{"code": "seeded-fallacy", "severity": "info", "message": "Seeded fallback fallacy entry."}],
                "provenance": {
                    "source_kind": "seed",
                    "source_path": source_path,
                    "source_slug": item["slug"],
                    "source_title": item["title"],
                },
            }
            concept = build_concept_record(
                record,
                source_kind="seed",
                source_path=source_path,
                source_type="py",
                source_collection="fallacy-seed",
                source_slug=item["slug"],
                source_title=item["title"],
                document_id=document_id,
                normalized_path=None,
                render_format="json",
                forced_category="fallacies",
                forced_subcategory=item["subcategory"],
                forced_kind="fallacy",
                forced_concept_id=record["entry_id"],
            )
            if should_skip_duplicate(concept):
                continue
            rowid = insert_concept(connection, concept)
            insert_aliases(connection, concept["entry_id"], concept["aliases"], "seed", source_path)
            insert_facets(connection, concept["entry_id"], {**concept, "tags": []})
            inserted_rows.append({**concept, "rowid": rowid, "source_record": record})
            mark_keys(concept)

        concept_by_id = {row["entry_id"]: row for row in inserted_rows}
        alias_index = {}
        for row in inserted_rows:
            for alias in row["aliases"]:
                key = canonical_lookup_key(alias)
                if key and key not in alias_index:
                    alias_index[key] = row["entry_id"]
            for alias in [row["entry_id"], row["slug"], row["title"]]:
                key = canonical_lookup_key(alias)
                if key and key not in alias_index:
                    alias_index[key] = row["entry_id"]

        relation_count = 0
        for row in inserted_rows:
            source_record = row.get("source_record") or {}
            for relation_type, target_ref in fallback_relation_targets(source_record):
                target_id = resolve_concept_id(concept_by_id, alias_index, target_ref)
                connection.execute(
                    """
                    INSERT INTO relations (
                      source_concept_id,
                      relation_type,
                      target_concept_id,
                      target_ref,
                      confidence,
                      metadata_json
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["entry_id"],
                        relation_type,
                        target_id,
                        target_ref,
                        float(source_record.get("confidence") or row.get("confidence") or 0.0) if (source_record.get("confidence") is not None or row.get("confidence") is not None) else None,
                        json.dumps({"source_kind": row.get("provenance", {}).get("source_kind") if isinstance(row.get("provenance"), dict) else None}, ensure_ascii=False, sort_keys=True),
                    ),
                )
                relation_count += 1

        # Build the FTS index last so rowids are stable.
        for row in inserted_rows:
            connection.execute(
                "INSERT INTO concept_fts (rowid, concept_id, title, aliases, summary, definition, example, impact, mitigation, content_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    row["rowid"],
                    row["entry_id"],
                    row["title"],
                    " ".join(row["aliases"]),
                    row["summary"],
                    row["definition"],
                    row["example"],
                    row["impact"],
                    row["mitigation"],
                    row["content_text"],
                ),
            )

        built_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        corpus_digest = build_corpus_digest(source_paths_for_digest)
        metadata = {
            "schema_version": "1",
            "built_at": built_at,
            "root": str(root),
            "corpus_digest": corpus_digest,
            "source_file_count": str(len(source_paths_for_digest)),
            "imported_concepts": str(len(inserted_rows)),
            "imported_biases": str(sum(1 for row in inserted_rows if row["category"] == "biases")),
            "imported_frameworks": str(sum(1 for row in inserted_rows if row["public_schema"] == "framework")),
            "imported_fallacies": str(sum(1 for row in inserted_rows if row["category"] == "fallacies")),
            "alias_count": str(connection.execute("SELECT COUNT(*) FROM aliases").fetchone()[0]),
            "relation_count": str(relation_count),
            "facet_count": str(connection.execute("SELECT COUNT(*) FROM concept_facets").fetchone()[0]),
        }
        connection.execute("DELETE FROM metadata")
        for key, value in metadata.items():
            connection.execute("INSERT INTO metadata (key, value) VALUES (?, ?)", (key, value))

        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()

    os.replace(temp_path, db_path)
    return {
        "db_path": str(db_path),
        "corpus_digest": corpus_digest,
        "imported_concepts": len(inserted_rows),
        "imported_documents": len(documents_by_path),
        "relation_count": relation_count,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Seed the standalone Critical Compass SQLite database.")
    parser.add_argument("--root", default=str(ROOT), help="Standalone CriticalThinking root.")
    parser.add_argument("--db-path", default=str(DEFAULT_DB_PATH), help="Output SQLite database path.")
    parser.add_argument("--schema-path", default=str(DEFAULT_SCHEMA_PATH), help="Schema file path.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = seed_database(Path(args.root).expanduser().resolve(), Path(args.db_path).expanduser().resolve(), Path(args.schema_path).expanduser().resolve())
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
